#!/bin/bash

echo "========================================"
echo "  Kotlin Learning Tutorial Launcher"
echo "========================================"
echo

# Check if Gradle is available
if ! command -v gradle &> /dev/null; then
    echo "ERROR: Gradle is not installed or not in PATH"
    echo "Please follow the setup guide in docs/kotlin-setup-windows.md"
    exit 1
fi

# Check if Java is available
if ! command -v java &> /dev/null; then
    echo "ERROR: Java is not installed or not in PATH"
    echo "Please follow the setup guide in docs/kotlin-setup-windows.md"
    exit 1
fi

echo "Gradle and Java are available!"
echo

show_menu() {
    echo "Choose an option:"
    echo "1. Run the main tutorial application"
    echo "2. Run basic examples"
    echo "3. Run OOP examples"
    echo "4. Run advanced examples"
    echo "5. Build the project"
    echo "6. Clean the project"
    echo "7. Open setup guide"
    echo "8. Open tutorial documentation"
    echo "9. Exit"
    echo
}

while true; do
    show_menu
    read -p "Enter your choice (1-9): " choice
    
    case $choice in
        1)
            echo
            echo "Running main tutorial application..."
            gradle run
            ;;
        2)
            echo
            echo "Choose a basic example:"
            echo "1. Variables and Data Types"
            echo "2. Functions"
            echo "3. Control Flow"
            echo "4. Collections"
            echo
            read -p "Enter choice (1-4): " basic_choice
            
            case $basic_choice in
                1)
                    echo "Running Variables Example..."
                    gradle run --args="basics.VariablesExampleKt"
                    ;;
                2)
                    echo "Running Functions Example..."
                    gradle run --args="basics.FunctionsExampleKt"
                    ;;
                3)
                    echo "Running Control Flow Example..."
                    gradle run --args="basics.ControlFlowExampleKt"
                    ;;
                4)
                    echo "Running Collections Example..."
                    gradle run --args="basics.CollectionsExampleKt"
                    ;;
                *)
                    echo "Invalid choice."
                    ;;
            esac
            ;;
        3)
            echo
            echo "Running OOP Examples..."
            gradle run --args="oop.ClassesExampleKt"
            ;;
        4)
            echo
            echo "Choose an advanced example:"
            echo "1. Coroutines"
            echo "2. Functional Programming"
            echo
            read -p "Enter choice (1-2): " adv_choice
            
            case $adv_choice in
                1)
                    echo "Running Coroutines Example..."
                    gradle run --args="advanced.CoroutinesExampleKt"
                    ;;
                2)
                    echo "Running Functional Programming Example..."
                    gradle run --args="advanced.FunctionalExampleKt"
                    ;;
                *)
                    echo "Invalid choice."
                    ;;
            esac
            ;;
        5)
            echo
            echo "Building the project..."
            gradle build
            ;;
        6)
            echo
            echo "Cleaning the project..."
            gradle clean
            ;;
        7)
            echo
            echo "Opening setup guide..."
            if command -v xdg-open &> /dev/null; then
                xdg-open docs/kotlin-setup-windows.md
            elif command -v open &> /dev/null; then
                open docs/kotlin-setup-windows.md
            else
                echo "Please open docs/kotlin-setup-windows.md manually"
            fi
            ;;
        8)
            echo
            echo "Opening tutorial documentation..."
            if command -v xdg-open &> /dev/null; then
                xdg-open docs/kotlin-tutorial.md
            elif command -v open &> /dev/null; then
                open docs/kotlin-tutorial.md
            else
                echo "Please open docs/kotlin-tutorial.md manually"
            fi
            ;;
        9)
            echo
            echo "Thank you for using the Kotlin Learning Tutorial!"
            echo "Happy coding! 🚀"
            exit 0
            ;;
        *)
            echo "Invalid choice. Please try again."
            ;;
    esac
    
    echo
    echo "Operation completed."
    echo
    read -p "Press Enter to continue..."
    echo
done
