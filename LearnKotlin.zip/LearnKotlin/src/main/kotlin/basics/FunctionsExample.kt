package basics

/**
 * Functions Examples
 * 
 * This file demonstrates Kotlin function syntax, default parameters,
 * named arguments, and various function types.
 */

fun main() {
    println("=== Kotlin Functions ===\n")
    
    // Basic function calls
    val sum = add(5, 3)
    println("5 + 3 = $sum")
    
    // Single expression function
    val product = multiply(4, 7)
    println("4 * 7 = $product")
    
    // Functions with default parameters
    greet("Alice")
    greet("Bob", "Hi")
    greet("Charlie", "Hey", "!")
    
    // Named arguments
    println("\nNamed Arguments:")
    createUser(name = "John", email = "john@example.com", age = 25)
    createUser(email = "jane@example.com", name = "Jane", age = 30, isActive = false)
    
    // Variable arguments (varargs)
    println("\nVariable Arguments:")
    val numbers = intArrayOf(1, 2, 3, 4, 5)
    printNumbers(10, 20, 30)
    printNumbers(*numbers)  // Spread operator
    
    // Higher-order functions
    println("\nHigher-Order Functions:")
    val result1 = calculate(10, 5) { a, b -> a + b }
    val result2 = calculate(10, 5) { a, b -> a * b }
    println("10 + 5 = $result1")
    println("10 * 5 = $result2")
    
    // Local functions
    demonstrateLocalFunctions()
    
    // Extension functions
    demonstrateExtensionFunctions()
}

// Basic function with explicit return type
fun add(a: Int, b: Int): Int {
    return a + b
}

// Single expression function (return type inferred)
fun multiply(a: Int, b: Int) = a * b

// Function with default parameters
fun greet(name: String, greeting: String = "Hello", punctuation: String = ".") {
    println("$greeting, $name$punctuation")
}

// Function with named parameters
fun createUser(name: String, age: Int, email: String, isActive: Boolean = true) {
    println("Created user: $name, age: $age, email: $email, active: $isActive")
}

// Function with variable arguments
fun printNumbers(vararg numbers: Int) {
    print("Numbers: ")
    for (number in numbers) {
        print("$number ")
    }
    println()
}

// Higher-order function (function as parameter)
fun calculate(a: Int, b: Int, operation: (Int, Int) -> Int): Int {
    return operation(a, b)
}

// Function returning a function
fun getOperation(operationType: String): (Int, Int) -> Int {
    return when (operationType) {
        "add" -> { a, b -> a + b }
        "subtract" -> { a, b -> a - b }
        "multiply" -> { a, b -> a * b }
        "divide" -> { a, b -> if (b != 0) a / b else 0 }
        else -> { _, _ -> 0 }
    }
}

fun demonstrateLocalFunctions() {
    println("\nLocal Functions:")
    
    fun processData(data: List<String>): List<String> {
        // Local function - only accessible within processData
        fun isValid(item: String): Boolean {
            return item.isNotEmpty() && item.length >= 2
        }
        
        fun capitalize(item: String): String {
            return item.replaceFirstChar { it.uppercase() }
        }
        
        return data.filter { isValid(it) }
                   .map { capitalize(it) }
    }
    
    val data = listOf("", "a", "hello", "world", "kotlin")
    val processed = processData(data)
    println("Original: $data")
    println("Processed: $processed")
}

// Extension functions - adding functionality to existing classes
fun String.removeSpaces(): String = this.replace(" ", "")

fun String.truncate(maxLength: Int): String {
    return if (this.length <= maxLength) this else this.substring(0, maxLength) + "..."
}

fun List<Int>.average(): Double {
    return if (this.isEmpty()) 0.0 else this.sum().toDouble() / this.size
}

fun demonstrateExtensionFunctions() {
    println("\nExtension Functions:")
    
    val text = "Hello World"
    println("Original: '$text'")
    println("Without spaces: '${text.removeSpaces()}'")
    println("Truncated: '${text.truncate(8)}'")
    
    val numbers = listOf(1, 2, 3, 4, 5)
    println("Numbers: $numbers")
    println("Average: ${numbers.average()}")
}

// Infix functions - can be called with infix notation
infix fun Int.power(exponent: Int): Int {
    var result = 1
    repeat(exponent) {
        result *= this
    }
    return result
}

// Operator overloading example
data class Point(val x: Int, val y: Int) {
    operator fun plus(other: Point): Point = Point(x + other.x, y + other.y)
    operator fun minus(other: Point): Point = Point(x - other.x, y - other.y)
    operator fun times(scalar: Int): Point = Point(x * scalar, y * scalar)
}

fun demonstrateInfixAndOperators() {
    println("\nInfix Functions:")
    val result = 2 power 3  // Instead of 2.power(3)
    println("2 power 3 = $result")
    
    println("\nOperator Overloading:")
    val p1 = Point(1, 2)
    val p2 = Point(3, 4)
    println("Point 1: $p1")
    println("Point 2: $p2")
    println("Sum: ${p1 + p2}")
    println("Difference: ${p1 - p2}")
    println("Scaled: ${p1 * 3}")
}
