package basics

/**
 * Collections Examples
 * 
 * This file demonstrates Kotlin's collection types including
 * lists, sets, maps, and their operations.
 */

fun main() {
    println("=== Kotlin Collections ===\n")
    
    // Lists
    demonstrateLists()
    
    // Sets
    demonstrateSets()
    
    // Maps
    demonstrateMaps()
    
    // Collection operations
    demonstrateCollectionOperations()
    
    // Sequences for lazy evaluation
    demonstrateSequences()
}

fun demonstrateLists() {
    println("=== Lists ===")
    
    // Immutable list (read-only)
    val fruits = listOf("apple", "banana", "orange", "apple")
    println("Fruits: $fruits")
    println("First fruit: ${fruits[0]}")
    println("Last fruit: ${fruits.last()}")
    println("Size: ${fruits.size}")
    
    // Check if contains
    println("Contains 'banana': ${"banana" in fruits}")
    println("Contains 'grape': ${"grape" in fruits}")
    
    // Mutable list
    val mutableFruits = mutableListOf("apple", "banana")
    println("\nMutable fruits (initial): $mutableFruits")
    
    mutableFruits.add("orange")
    mutableFruits.add(1, "grape")  // Insert at index
    println("After adding: $mutableFruits")
    
    mutableFruits.remove("apple")
    mutableFruits.removeAt(0)      // Remove at index
    println("After removing: $mutableFruits")
    
    // List creation with constructor
    val numbers = List(5) { it * 2 }  // [0, 2, 4, 6, 8]
    println("Generated numbers: $numbers")
    
    // ArrayList specifically
    val arrayList = ArrayList<String>()
    arrayList.addAll(listOf("a", "b", "c"))
    println("ArrayList: $arrayList")
    
    println()
}

fun demonstrateSets() {
    println("=== Sets ===")
    
    // Immutable set (read-only)
    val colors = setOf("red", "green", "blue", "red")  // Duplicates removed
    println("Colors: $colors")
    println("Size: ${colors.size}")
    
    // Check membership
    println("Contains 'red': ${"red" in colors}")
    println("Contains 'yellow': ${"yellow" in colors}")
    
    // Mutable set
    val mutableColors = mutableSetOf("red", "green")
    println("\nMutable colors (initial): $mutableColors")
    
    mutableColors.add("blue")
    mutableColors.add("red")       // Won't add duplicate
    println("After adding: $mutableColors")
    
    mutableColors.remove("green")
    println("After removing green: $mutableColors")
    
    // Set operations
    val primaryColors = setOf("red", "blue", "yellow")
    val secondaryColors = setOf("green", "orange", "purple")
    val someColors = setOf("red", "green", "pink")
    
    println("\nSet Operations:")
    println("Primary: $primaryColors")
    println("Secondary: $secondaryColors")
    println("Some: $someColors")
    
    // Union
    val allColors = primaryColors union secondaryColors
    println("Union: $allColors")
    
    // Intersection
    val commonColors = primaryColors intersect someColors
    println("Intersection (primary ∩ some): $commonColors")
    
    // Difference
    val uniqueToPrimary = primaryColors subtract someColors
    println("Difference (primary - some): $uniqueToPrimary")
    
    println()
}

fun demonstrateMaps() {
    println("=== Maps ===")
    
    // Immutable map (read-only)
    val ages = mapOf("Alice" to 25, "Bob" to 30, "Charlie" to 35)
    println("Ages: $ages")
    println("Alice's age: ${ages["Alice"]}")
    println("Unknown person: ${ages["David"]}")  // Returns null
    
    // Safe access with default
    println("David's age (with default): ${ages.getOrDefault("David", 0)}")
    
    // Mutable map
    val mutableAges = mutableMapOf("Alice" to 25, "Bob" to 30)
    println("\nMutable ages (initial): $mutableAges")
    
    mutableAges["Charlie"] = 35        // Add new entry
    mutableAges.put("David", 40)       // Alternative way to add
    println("After adding: $mutableAges")
    
    mutableAges["Alice"] = 26          // Update existing
    println("After updating Alice: $mutableAges")
    
    mutableAges.remove("Bob")
    println("After removing Bob: $mutableAges")
    
    // Iterating over maps
    println("\nIterating over map:")
    for ((name, age) in ages) {
        println("$name is $age years old")
    }
    
    // Keys and values
    println("Names: ${ages.keys}")
    println("Ages: ${ages.values}")
    
    // Map creation with constructor
    val squares = (1..5).associateWith { it * it }
    println("Squares: $squares")
    
    val nameToLength = listOf("Alice", "Bob", "Charlie").associateWith { it.length }
    println("Name lengths: $nameToLength")
    
    println()
}

fun demonstrateCollectionOperations() {
    println("=== Collection Operations ===")
    
    val numbers = listOf(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
    println("Numbers: $numbers")
    
    // Filter
    val evenNumbers = numbers.filter { it % 2 == 0 }
    println("Even numbers: $evenNumbers")
    
    val numbersGreaterThan5 = numbers.filter { it > 5 }
    println("Numbers > 5: $numbersGreaterThan5")
    
    // Map (transform)
    val squared = numbers.map { it * it }
    println("Squared: $squared")
    
    val doubled = numbers.map { it * 2 }
    println("Doubled: $doubled")
    
    // Filter and map combined
    val evenSquares = numbers.filter { it % 2 == 0 }.map { it * it }
    println("Even squares: $evenSquares")
    
    // Find
    val firstEven = numbers.find { it % 2 == 0 }
    val firstGreaterThan15 = numbers.find { it > 15 }
    println("First even: $firstEven")
    println("First > 15: $firstGreaterThan15")
    
    // Any, all, none
    val hasEven = numbers.any { it % 2 == 0 }
    val allPositive = numbers.all { it > 0 }
    val noneNegative = numbers.none { it < 0 }
    println("Has even: $hasEven")
    println("All positive: $allPositive")
    println("None negative: $noneNegative")
    
    // Reduce and fold
    val sum = numbers.reduce { acc, element -> acc + element }
    val product = numbers.fold(1) { acc, element -> acc * element }
    println("Sum: $sum")
    println("Product: $product")
    
    // GroupBy
    val grouped = numbers.groupBy { it % 3 }
    println("Grouped by remainder when divided by 3: $grouped")
    
    // Partition
    val (evens, odds) = numbers.partition { it % 2 == 0 }
    println("Evens: $evens")
    println("Odds: $odds")
    
    // Take and drop
    val first3 = numbers.take(3)
    val last3 = numbers.takeLast(3)
    val without3 = numbers.drop(3)
    println("First 3: $first3")
    println("Last 3: $last3")
    println("Without first 3: $without3")
    
    // Sorting
    val names = listOf("Charlie", "Alice", "Bob", "David")
    println("Names: $names")
    println("Sorted: ${names.sorted()}")
    println("Sorted by length: ${names.sortedBy { it.length }}")
    println("Sorted descending: ${names.sortedDescending()}")
    
    // Distinct
    val numbersWithDuplicates = listOf(1, 2, 2, 3, 3, 3, 4, 4, 4, 4)
    println("With duplicates: $numbersWithDuplicates")
    println("Distinct: ${numbersWithDuplicates.distinct()}")
    
    // Zip
    val letters = listOf("a", "b", "c", "d")
    val zipped = numbers.take(4).zip(letters)
    println("Zipped: $zipped")
    
    println()
}

fun demonstrateSequences() {
    println("=== Sequences (Lazy Evaluation) ===")
    
    // Regular collection - eager evaluation
    val eagerResult = (1..1000000)
        .map { it * 2 }
        .filter { it % 3 == 0 }
        .take(10)
        .toList()
    
    // Sequence - lazy evaluation (more efficient for large datasets)
    val lazyResult = (1..1000000).asSequence()
        .map { it * 2 }
        .filter { it % 3 == 0 }
        .take(10)
        .toList()
    
    println("Eager result: $eagerResult")
    println("Lazy result: $lazyResult")
    
    // Creating sequences
    val infiniteSequence = generateSequence(1) { it + 1 }
    val first10 = infiniteSequence.take(10).toList()
    println("First 10 from infinite sequence: $first10")
    
    // Fibonacci sequence
    val fibonacci = generateSequence(Pair(0, 1)) { Pair(it.second, it.first + it.second) }
        .map { it.first }
    val first10Fibonacci = fibonacci.take(10).toList()
    println("First 10 Fibonacci numbers: $first10Fibonacci")
    
    println()
}

// Practical example: Working with collections
fun practicalExample() {
    println("=== Practical Example: Student Management ===")
    
    data class Student(val name: String, val age: Int, val grade: Double, val major: String)
    
    val students = listOf(
        Student("Alice", 20, 3.8, "Computer Science"),
        Student("Bob", 19, 3.2, "Mathematics"),
        Student("Charlie", 21, 3.9, "Computer Science"),
        Student("Diana", 20, 3.5, "Physics"),
        Student("Eve", 22, 3.7, "Mathematics")
    )
    
    println("All students:")
    students.forEach { println("- ${it.name}, ${it.age}, GPA: ${it.grade}, Major: ${it.major}") }
    
    // Find honor students (GPA >= 3.5)
    val honorStudents = students.filter { it.grade >= 3.5 }
    println("\nHonor students (GPA >= 3.5):")
    honorStudents.forEach { println("- ${it.name}: ${it.grade}") }
    
    // Group by major
    val byMajor = students.groupBy { it.major }
    println("\nStudents by major:")
    byMajor.forEach { (major, studentList) ->
        println("$major: ${studentList.map { it.name }}")
    }
    
    // Average GPA by major
    val avgGpaByMajor = students.groupBy { it.major }
        .mapValues { (_, studentList) -> 
            studentList.map { it.grade }.average()
        }
    println("\nAverage GPA by major:")
    avgGpaByMajor.forEach { (major, avgGpa) ->
        println("$major: %.2f".format(avgGpa))
    }
    
    // Top student
    val topStudent = students.maxByOrNull { it.grade }
    println("\nTop student: ${topStudent?.name} with GPA ${topStudent?.grade}")
    
    // Students' names sorted by GPA (descending)
    val sortedByGpa = students.sortedByDescending { it.grade }.map { "${it.name} (${it.grade})" }
    println("\nStudents sorted by GPA:")
    sortedByGpa.forEach { println("- $it") }
}
