package basics

/**
 * Variables and Data Types Examples
 * 
 * This file demonstrates Kotlin variable declarations, type inference,
 * and basic data types compared to Java.
 */

fun main() {
    println("=== Kotlin Variables and Data Types ===\n")
    
    // Immutable variables (val) - like final in Java
    val name: String = "John Doe"
    val age: Int = 25
    val isStudent: Boolean = true
    
    // Type inference - Kotlin can infer types
    val city = "New York"  // String inferred
    val salary = 50000.0   // Double inferred
    val isEmployed = true  // Boolean inferred
    
    println("Immutable Variables:")
    println("Name: $name")
    println("Age: $age")
    println("Is Student: $isStudent")
    println("City: $city")
    println("Salary: $salary")
    println("Is Employed: $isEmployed")
    
    // Mutable variables (var)
    var counter = 0
    var message = "Initial message"
    
    println("\nMutable Variables (before changes):")
    println("Counter: $counter")
    println("Message: $message")
    
    // Modifying mutable variables
    counter = 10
    message = "Updated message"
    
    println("\nMutable Variables (after changes):")
    println("Counter: $counter")
    println("Message: $message")
    
    // String templates
    println("\nString Templates:")
    println("Hello, my name is $name and I'm $age years old.")
    println("Next year I'll be ${age + 1} years old.")
    
    // Nullable types
    var nullableName: String? = "Jane"
    var nullableAge: Int? = null
    
    println("\nNullable Types:")
    println("Nullable Name: $nullableName")
    println("Nullable Age: $nullableAge")
    
    // Safe calls
    println("Name length: ${nullableName?.length}")
    println("Age plus 1: ${nullableAge?.plus(1)}")
    
    // Elvis operator
    val nameLength = nullableName?.length ?: 0
    val ageOrDefault = nullableAge ?: 0
    
    println("Name length (with default): $nameLength")
    println("Age (with default): $ageOrDefault")
    
    // Numeric types
    demonstrateNumericTypes()
    
    // Type conversion
    demonstrateTypeConversion()
}

fun demonstrateNumericTypes() {
    println("\n=== Numeric Types ===")
    
    val byteValue: Byte = 127
    val shortValue: Short = 32767
    val intValue: Int = 2147483647
    val longValue: Long = 9223372036854775807L
    val floatValue: Float = 3.14f
    val doubleValue: Double = 3.14159265359
    
    println("Byte: $byteValue")
    println("Short: $shortValue")
    println("Int: $intValue")
    println("Long: $longValue")
    println("Float: $floatValue")
    println("Double: $doubleValue")
    
    // Number literals
    val binary = 0b1010        // Binary
    val hex = 0xFF             // Hexadecimal
    val scientific = 1.5e10    // Scientific notation
    
    println("\nNumber Literals:")
    println("Binary (1010): $binary")
    println("Hexadecimal (FF): $hex")
    println("Scientific (1.5e10): $scientific")
}

fun demonstrateTypeConversion() {
    println("\n=== Type Conversion ===")
    
    val intValue = 42
    
    // Explicit type conversion (no implicit widening like Java)
    val longValue = intValue.toLong()
    val floatValue = intValue.toFloat()
    val doubleValue = intValue.toDouble()
    val stringValue = intValue.toString()
    
    println("Original Int: $intValue")
    println("To Long: $longValue")
    println("To Float: $floatValue")
    println("To Double: $doubleValue")
    println("To String: $stringValue")
    
    // String to number conversion
    val numberString = "123"
    val numberFromString = numberString.toInt()
    val safeConversion = numberString.toIntOrNull() ?: 0
    
    println("\nString to Number:")
    println("String: $numberString")
    println("To Int: $numberFromString")
    println("Safe conversion: $safeConversion")
    
    // Unsafe conversion (will throw exception)
    try {
        val invalidNumber = "abc".toInt()
        println("This won't print: $invalidNumber")
    } catch (e: NumberFormatException) {
        println("Caught exception: ${e.message}")
    }
}
