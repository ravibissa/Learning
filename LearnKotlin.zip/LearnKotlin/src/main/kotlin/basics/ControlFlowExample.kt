package basics

/**
 * Control Flow Examples
 * 
 * This file demonstrates Kotlin's control flow statements including
 * if expressions, when expressions, loops, and ranges.
 */

fun main() {
    println("=== Kotlin Control Flow ===\n")
    
    // If expressions
    demonstrateIfExpressions()
    
    // When expressions (replacement for switch)
    demonstrateWhenExpressions()
    
    // Loops and ranges
    demonstrateLoops()
    
    // Break and continue with labels
    demonstrateLabels()
}

fun demonstrateIfExpressions() {
    println("=== If Expressions ===")
    
    val a = 10
    val b = 20
    
    // if as expression (returns value)
    val max = if (a > b) a else b
    println("Max of $a and $b is: $max")
    
    // Multi-line if expression
    val result = if (a > b) {
        println("a is greater")
        a
    } else {
        println("b is greater or equal")
        b
    }
    println("Result: $result")
    
    // Nested if expressions
    val score = 85
    val grade = if (score >= 90) {
        "A"
    } else if (score >= 80) {
        "B"
    } else if (score >= 70) {
        "C"
    } else if (score >= 60) {
        "D"
    } else {
        "F"
    }
    println("Score: $score, Grade: $grade")
    
    // If with null checks
    val nullableString: String? = "Hello"
    val length = if (nullableString != null) nullableString.length else 0
    println("String length: $length")
    
    println()
}

fun demonstrateWhenExpressions() {
    println("=== When Expressions ===")
    
    val day = 3
    
    // Basic when expression
    val dayName = when (day) {
        1 -> "Monday"
        2 -> "Tuesday"
        3 -> "Wednesday"
        4 -> "Thursday"
        5 -> "Friday"
        6 -> "Saturday"
        7 -> "Sunday"
        else -> "Invalid day"
    }
    println("Day $day is: $dayName")
    
    // Multiple values in one branch
    val dayType = when (day) {
        1, 2, 3, 4, 5 -> "Weekday"
        6, 7 -> "Weekend"
        else -> "Invalid"
    }
    println("Day type: $dayType")
    
    // Range checks in when
    val age = 25
    val category = when (age) {
        in 0..12 -> "Child"
        in 13..17 -> "Teenager"
        in 18..64 -> "Adult"
        in 65..120 -> "Senior"
        else -> "Invalid age"
    }
    println("Age: $age, Category: $category")
    
    // Type checks with when
    fun describe(obj: Any): String = when (obj) {
        is String -> "String of length ${obj.length}"
        is Int -> "Integer: $obj"
        is Double -> "Double: $obj"
        is List<*> -> "List with ${obj.size} elements"
        else -> "Unknown type: ${obj::class.simpleName}"
    }
    
    println("Describe 'Hello': ${describe("Hello")}")
    println("Describe 42: ${describe(42)}")
    println("Describe 3.14: ${describe(3.14)}")
    println("Describe list: ${describe(listOf(1, 2, 3))}")
    
    // When without argument (replacement for if-else chain)
    val temperature = 25
    val description = when {
        temperature < 0 -> "Freezing"
        temperature < 15 -> "Cold"
        temperature < 25 -> "Cool"
        temperature < 35 -> "Warm"
        else -> "Hot"
    }
    println("Temperature: ${temperature}°C is $description")
    
    println()
}

fun demonstrateLoops() {
    println("=== Loops and Ranges ===")
    
    // For loop with range
    println("Counting 1 to 5:")
    for (i in 1..5) {
        print("$i ")
    }
    println()
    
    // For loop with until (exclusive)
    println("Counting 0 until 5:")
    for (i in 0 until 5) {
        print("$i ")
    }
    println()
    
    // For loop with step
    println("Even numbers 0 to 10:")
    for (i in 0..10 step 2) {
        print("$i ")
    }
    println()
    
    // For loop downTo
    println("Countdown from 5:")
    for (i in 5 downTo 1) {
        print("$i ")
    }
    println()
    
    // For loop with collections
    val fruits = listOf("apple", "banana", "orange")
    println("Fruits:")
    for (fruit in fruits) {
        println("- $fruit")
    }
    
    // For loop with index
    println("Fruits with index:")
    for ((index, fruit) in fruits.withIndex()) {
        println("$index: $fruit")
    }
    
    // For loop with map
    val ages = mapOf("Alice" to 25, "Bob" to 30, "Charlie" to 35)
    println("Ages:")
    for ((name, age) in ages) {
        println("$name is $age years old")
    }
    
    // While loop
    println("While loop example:")
    var counter = 1
    while (counter <= 3) {
        println("Counter: $counter")
        counter++
    }
    
    // Do-while loop
    println("Do-while loop example:")
    var value = 5
    do {
        println("Value: $value")
        value--
    } while (value > 3)
    
    println()
}

fun demonstrateLabels() {
    println("=== Labels with Break and Continue ===")
    
    // Nested loops with labels
    outer@ for (i in 1..3) {
        inner@ for (j in 1..3) {
            if (i == 2 && j == 2) {
                println("Breaking outer loop at i=$i, j=$j")
                break@outer
            }
            println("i=$i, j=$j")
        }
    }
    
    println("Continue example:")
    loop@ for (i in 1..5) {
        for (j in 1..3) {
            if (j == 2) {
                println("Continuing outer loop at i=$i, j=$j")
                continue@loop
            }
            println("Processing i=$i, j=$j")
        }
    }
    
    // Return from lambda with label
    val numbers = listOf(1, 2, 3, 4, 5)
    println("Return from lambda:")
    numbers.forEach lit@{ number ->
        if (number == 3) {
            println("Skipping $number")
            return@lit
        }
        println("Processing $number")
    }
    
    println()
}

// Additional examples
fun demonstrateRanges() {
    println("=== Range Operations ===")
    
    val range1 = 1..10          // Inclusive range
    val range2 = 1 until 10     // Exclusive end
    val range3 = 10 downTo 1    // Descending range
    val range4 = 1..10 step 2   // With step
    
    println("1..10 contains 5: ${5 in range1}")
    println("1..10 contains 15: ${15 in range1}")
    
    // Character ranges
    val alphabet = 'a'..'z'
    println("'m' in alphabet: ${'m' in alphabet}")
    
    // Range as collection
    val evenNumbers = (2..10 step 2).toList()
    println("Even numbers 2-10: $evenNumbers")
    
    println()
}

// Exception handling
fun demonstrateExceptionHandling() {
    println("=== Exception Handling ===")
    
    // Try-catch expression
    val result = try {
        val input = "123"
        input.toInt()
    } catch (e: NumberFormatException) {
        println("Invalid number format")
        0
    } finally {
        println("Cleanup code here")
    }
    
    println("Result: $result")
    
    // Try as expression with multiple catch blocks
    fun safeDivide(a: Int, b: Int): Double {
        return try {
            a.toDouble() / b
        } catch (e: ArithmeticException) {
            println("Division by zero!")
            0.0
        } catch (e: Exception) {
            println("Unexpected error: ${e.message}")
            0.0
        }
    }
    
    println("10 / 2 = ${safeDivide(10, 2)}")
    println("10 / 0 = ${safeDivide(10, 0)}")
}
