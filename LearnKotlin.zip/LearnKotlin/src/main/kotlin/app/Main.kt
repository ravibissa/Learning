package app

import basics.*
import oop.*
import advanced.*
import kotlinx.coroutines.runBlocking

/**
 * Main Application
 * 
 * This is the entry point for the Kotlin learning tutorial.
 * It provides a menu system to run different examples and demonstrates
 * a simple task management application.
 */

fun main() {
    println("🎉 Welcome to Kotlin Learning Tutorial! 🎉")
    println("=========================================")
    
    while (true) {
        showMenu()
        
        print("Enter your choice (1-8, 0 to exit): ")
        val choice = readLine()?.toIntOrNull() ?: continue
        
        println()
        
        when (choice) {
            0 -> {
                println("Thank you for learning Kotlin! Happy coding! 🚀")
                break
            }
            1 -> runExample("Variables and Data Types") { VariablesExample.main() }
            2 -> runExample("Functions") { FunctionsExample.main() }
            3 -> runExample("Control Flow") { ControlFlowExample.main() }
            4 -> runExample("Collections") { CollectionsExample.main() }
            5 -> runExample("Object-Oriented Programming") { ClassesExample.main() }
            6 -> runExample("Coroutines") { CoroutinesExample.main() }
            7 -> runExample("Functional Programming") { FunctionalExample.main() }
            8 -> runTaskManagerApp()
            else -> println("❌ Invalid choice. Please try again.")
        }
        
        if (choice != 0) {
            println("\nPress Enter to continue...")
            readLine()
        }
    }
}

private fun showMenu() {
    println("\n📚 Choose a topic to explore:")
    println("1. Variables and Data Types")
    println("2. Functions")
    println("3. Control Flow")
    println("4. Collections")
    println("5. Object-Oriented Programming")
    println("6. Coroutines (Async Programming)")
    println("7. Functional Programming")
    println("8. Task Manager Application (Demo)")
    println("0. Exit")
    println("-".repeat(40))
}

private fun runExample(title: String, example: () -> Unit) {
    println("🔍 Running: $title")
    println("=".repeat(50))
    
    try {
        example()
    } catch (e: Exception) {
        println("❌ Error running example: ${e.message}")
        e.printStackTrace()
    }
    
    println("=".repeat(50))
    println("✅ Completed: $title")
}

private fun runTaskManagerApp() {
    println("🎯 Task Manager Application Demo")
    println("=".repeat(50))
    
    val taskManager = TaskManager()
    
    while (true) {
        taskManager.showMenu()
        
        print("Enter your choice: ")
        val choice = readLine()?.toIntOrNull() ?: continue
        
        when (choice) {
            0 -> {
                println("👋 Exiting Task Manager...")
                break
            }
            1 -> taskManager.addTask()
            2 -> taskManager.listTasks()
            3 -> taskManager.completeTask()
            4 -> taskManager.deleteTask()
            5 -> taskManager.searchTasks()
            6 -> taskManager.showStatistics()
            else -> println("❌ Invalid choice. Please try again.")
        }
        
        println()
    }
}

/**
 * Simple Task Manager Application
 * 
 * This demonstrates a practical Kotlin application using various concepts
 * learned in the tutorial including data classes, collections, functions,
 * and object-oriented programming.
 */
class TaskManager {
    
    private val tasks = mutableListOf<Task>()
    private var nextId = 1
    
    data class Task(
        val id: Int,
        val title: String,
        val description: String,
        val priority: Priority,
        val createdAt: Long = System.currentTimeMillis(),
        var isCompleted: Boolean = false,
        var completedAt: Long? = null
    ) {
        enum class Priority(val displayName: String) {
            LOW("Low"),
            MEDIUM("Medium"),
            HIGH("High"),
            URGENT("Urgent")
        }
        
        fun markCompleted() {
            isCompleted = true
            completedAt = System.currentTimeMillis()
        }
        
        fun getAge(): Long = System.currentTimeMillis() - createdAt
        
        override fun toString(): String {
            val status = if (isCompleted) "✅" else "⏳"
            val ageHours = getAge() / (1000 * 60 * 60)
            return "$status [$id] ${priority.displayName} - $title (${ageHours}h ago)"
        }
    }
    
    fun showMenu() {
        println("\n📋 Task Manager Menu:")
        println("1. Add Task")
        println("2. List Tasks")
        println("3. Complete Task")
        println("4. Delete Task")
        println("5. Search Tasks")
        println("6. Show Statistics")
        println("0. Back to Main Menu")
        println("-".repeat(30))
    }
    
    fun addTask() {
        print("📝 Task title: ")
        val title = readLine()?.trim() ?: return
        
        if (title.isBlank()) {
            println("❌ Title cannot be empty!")
            return
        }
        
        print("📄 Task description: ")
        val description = readLine()?.trim() ?: ""
        
        print("⚡ Priority (1-Low, 2-Medium, 3-High, 4-Urgent): ")
        val priorityInput = readLine()?.toIntOrNull() ?: 2
        
        val priority = when (priorityInput) {
            1 -> Task.Priority.LOW
            2 -> Task.Priority.MEDIUM
            3 -> Task.Priority.HIGH
            4 -> Task.Priority.URGENT
            else -> Task.Priority.MEDIUM
        }
        
        val task = Task(nextId++, title, description, priority)
        tasks.add(task)
        
        println("✅ Task added successfully! ID: ${task.id}")
    }
    
    fun listTasks() {
        if (tasks.isEmpty()) {
            println("📭 No tasks found!")
            return
        }
        
        print("Show (1-All, 2-Pending, 3-Completed): ")
        val filter = readLine()?.toIntOrNull() ?: 1
        
        val filteredTasks = when (filter) {
            2 -> tasks.filter { !it.isCompleted }
            3 -> tasks.filter { it.isCompleted }
            else -> tasks
        }
        
        if (filteredTasks.isEmpty()) {
            println("📭 No tasks match the filter!")
            return
        }
        
        println("\n📋 Tasks:")
        println("-".repeat(50))
        
        filteredTasks
            .sortedWith(compareBy<Task> { it.isCompleted }
                .thenByDescending { it.priority.ordinal }
                .thenBy { it.createdAt })
            .forEach { task ->
                println(task)
                if (task.description.isNotEmpty()) {
                    println("   📄 ${task.description}")
                }
            }
    }
    
    fun completeTask() {
        if (tasks.none { !it.isCompleted }) {
            println("📭 No pending tasks to complete!")
            return
        }
        
        println("\n⏳ Pending tasks:")
        tasks.filter { !it.isCompleted }
            .forEach { println("${it.id}: ${it.title}") }
        
        print("Enter task ID to complete: ")
        val id = readLine()?.toIntOrNull() ?: return
        
        val task = tasks.find { it.id == id && !it.isCompleted }
        
        if (task != null) {
            task.markCompleted()
            println("🎉 Task '${task.title}' completed!")
        } else {
            println("❌ Task not found or already completed!")
        }
    }
    
    fun deleteTask() {
        if (tasks.isEmpty()) {
            println("📭 No tasks to delete!")
            return
        }
        
        listTasks()
        
        print("Enter task ID to delete: ")
        val id = readLine()?.toIntOrNull() ?: return
        
        val task = tasks.find { it.id == id }
        
        if (task != null) {
            tasks.remove(task)
            println("🗑️ Task '${task.title}' deleted!")
        } else {
            println("❌ Task not found!")
        }
    }
    
    fun searchTasks() {
        if (tasks.isEmpty()) {
            println("📭 No tasks to search!")
            return
        }
        
        print("🔍 Enter search term: ")
        val searchTerm = readLine()?.trim()?.lowercase() ?: return
        
        val matchingTasks = tasks.filter { task ->
            task.title.lowercase().contains(searchTerm) ||
            task.description.lowercase().contains(searchTerm)
        }
        
        if (matchingTasks.isEmpty()) {
            println("❌ No tasks found matching '$searchTerm'")
        } else {
            println("\n🔍 Search results for '$searchTerm':")
            println("-".repeat(40))
            matchingTasks.forEach { println(it) }
        }
    }
    
    fun showStatistics() {
        if (tasks.isEmpty()) {
            println("📭 No tasks for statistics!")
            return
        }
        
        val totalTasks = tasks.size
        val completedTasks = tasks.count { it.isCompleted }
        val pendingTasks = totalTasks - completedTasks
        val completionRate = if (totalTasks > 0) (completedTasks * 100.0 / totalTasks) else 0.0
        
        val priorityStats = Task.Priority.values().associateWith { priority ->
            tasks.count { it.priority == priority }
        }
        
        val averageCompletionTime = tasks
            .filter { it.isCompleted && it.completedAt != null }
            .map { (it.completedAt!! - it.createdAt) / (1000 * 60 * 60) } // hours
            .let { if (it.isNotEmpty()) it.average() else 0.0 }
        
        println("\n📊 Task Statistics:")
        println("-".repeat(30))
        println("Total Tasks: $totalTasks")
        println("Completed: $completedTasks")
        println("Pending: $pendingTasks")
        println("Completion Rate: %.1f%%".format(completionRate))
        
        println("\nBy Priority:")
        priorityStats.forEach { (priority, count) ->
            println("  ${priority.displayName}: $count")
        }
        
        if (averageCompletionTime > 0) {
            println("Average Completion Time: %.1f hours".format(averageCompletionTime))
        }
        
        // Top 3 oldest pending tasks
        val oldestPending = tasks
            .filter { !it.isCompleted }
            .sortedBy { it.createdAt }
            .take(3)
        
        if (oldestPending.isNotEmpty()) {
            println("\n⚠️ Oldest Pending Tasks:")
            oldestPending.forEach { task ->
                val ageHours = task.getAge() / (1000 * 60 * 60)
                println("  ${task.title} (${ageHours}h old)")
            }
        }
    }
}

// Additional utility classes for demonstration
object Utils {
    fun formatDuration(milliseconds: Long): String {
        val hours = milliseconds / (1000 * 60 * 60)
        val minutes = (milliseconds % (1000 * 60 * 60)) / (1000 * 60)
        
        return when {
            hours > 0 -> "${hours}h ${minutes}m"
            minutes > 0 -> "${minutes}m"
            else -> "< 1m"
        }
    }
    
    fun getCurrentTimestamp(): String {
        return java.time.LocalDateTime.now().toString()
    }
}

// Extension functions demonstration
fun String.toTitleCase(): String {
    return this.split(" ")
        .joinToString(" ") { word ->
            word.lowercase().replaceFirstChar { it.uppercase() }
        }
}

fun <T> List<T>.second(): T? = if (this.size >= 2) this[1] else null
