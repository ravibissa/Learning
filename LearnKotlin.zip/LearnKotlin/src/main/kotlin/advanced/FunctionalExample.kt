package advanced

/**
 * Functional Programming Examples
 * 
 * This file demonstrates Kotlin's functional programming features including
 * lambda expressions, higher-order functions, and functional patterns.
 */

fun main() {
    println("=== Kotlin Functional Programming ===\n")
    
    // Lambda expressions
    demonstrateLambdas()
    
    // Higher-order functions
    demonstrateHigherOrderFunctions()
    
    // Function composition
    demonstrateFunctionComposition()
    
    // Inline functions
    demonstrateInlineFunctions()
    
    // Function types and references
    demonstrateFunctionTypes()
    
    // Practical functional examples
    practicalFunctionalExamples()
}

fun demonstrateLambdas() {
    println("=== Lambda Expressions ===")
    
    // Basic lambda syntax
    val add = { a: Int, b: Int -> a + b }
    val multiply = { a: Int, b: Int -> a * b }
    
    println("5 + 3 = ${add(5, 3)}")
    println("5 * 3 = ${multiply(5, 3)}")
    
    // Lambda with single parameter (using 'it')
    val numbers = listOf(1, 2, 3, 4, 5)
    val doubled = numbers.map { it * 2 }
    println("Doubled: $doubled")
    
    // Lambda with multiple statements
    val processAndPrint = { value: Int ->
        val processed = value * value + 1
        println("Processing $value -> $processed")
        processed
    }
    
    val processed = numbers.map(processAndPrint)
    println("Processed: $processed")
    
    // Lambda as last parameter (trailing lambda syntax)
    numbers.filter { it % 2 == 0 }
           .forEach { println("Even number: $it") }
    
    println()
}

fun demonstrateHigherOrderFunctions() {
    println("=== Higher-Order Functions ===")
    
    // Function taking another function as parameter
    fun operateOnList(list: List<Int>, operation: (Int) -> Int): List<Int> {
        return list.map(operation)
    }
    
    val numbers = listOf(1, 2, 3, 4, 5)
    
    val squared = operateOnList(numbers) { it * it }
    val cubed = operateOnList(numbers) { it * it * it }
    
    println("Original: $numbers")
    println("Squared: $squared")
    println("Cubed: $cubed")
    
    // Function returning another function
    fun createMultiplier(factor: Int): (Int) -> Int {
        return { value -> value * factor }
    }
    
    val triple = createMultiplier(3)
    val quintuple = createMultiplier(5)
    
    println("Triple 4: ${triple(4)}")
    println("Quintuple 4: ${quintuple(4)}")
    
    // Function taking and returning functions
    fun compose(f: (Int) -> Int, g: (Int) -> Int): (Int) -> Int {
        return { x -> f(g(x)) }
    }
    
    val addOne = { x: Int -> x + 1 }
    val timeTwo = { x: Int -> x * 2 }
    
    val addThenMultiply = compose(timeTwo, addOne)
    val multiplyThenAdd = compose(addOne, timeTwo)
    
    println("(5 + 1) * 2 = ${addThenMultiply(5)}")
    println("(5 * 2) + 1 = ${multiplyThenAdd(5)}")
    
    println()
}

fun demonstrateFunctionComposition() {
    println("=== Function Composition ===")
    
    // Extension function for composition
    infix fun <A, B, C> ((B) -> C).compose(f: (A) -> B): (A) -> C {
        return { x -> this(f(x)) }
    }
    
    val addTwo = { x: Int -> x + 2 }
    val multiplyByThree = { x: Int -> x * 3 }
    val toString = { x: Int -> x.toString() }
    
    // Compose functions
    val pipeline = toString compose multiplyByThree compose addTwo
    val result = pipeline(5)  // ((5 + 2) * 3).toString() = "21"
    
    println("Pipeline result for 5: $result")
    
    // Functional pipeline for data processing
    data class Person(val name: String, val age: Int, val salary: Double)
    
    val people = listOf(
        Person("Alice", 30, 50000.0),
        Person("Bob", 25, 45000.0),
        Person("Charlie", 35, 60000.0),
        Person("Diana", 28, 55000.0)
    )
    
    val processedPeople = people
        .filter { it.age > 26 }
        .map { it.copy(salary = it.salary * 1.1) }  // 10% raise
        .sortedByDescending { it.salary }
    
    println("Processed people:")
    processedPeople.forEach { println("${it.name}: $${it.salary}") }
    
    println()
}

// Inline functions for performance optimization
inline fun <T> measure(operation: () -> T): T {
    val start = System.currentTimeMillis()
    val result = operation()
    val time = System.currentTimeMillis() - start
    println("Operation took ${time}ms")
    return result
}

inline fun <T> List<T>.customFilter(predicate: (T) -> Boolean): List<T> {
    val result = mutableListOf<T>()
    for (item in this) {
        if (predicate(item)) {
            result.add(item)
        }
    }
    return result
}

fun demonstrateInlineFunctions() {
    println("=== Inline Functions ===")
    
    val result = measure {
        Thread.sleep(100)  // Simulate some work
        "Operation completed"
    }
    println("Result: $result")
    
    val numbers = (1..1000).toList()
    val evens = measure {
        numbers.customFilter { it % 2 == 0 }
    }
    println("Found ${evens.size} even numbers")
    
    println()
}

fun demonstrateFunctionTypes() {
    println("=== Function Types and References ===")
    
    // Function type declarations
    val stringProcessor: (String) -> String = { it.uppercase() }
    val numberChecker: (Int) -> Boolean = { it > 0 }
    val calculator: (Int, Int, (Int, Int) -> Int) -> Int = { a, b, op -> op(a, b) }
    
    println("Uppercase 'hello': ${stringProcessor("hello")}")
    println("Is 5 positive? ${numberChecker(5)}")
    println("Calculate 10 + 5: ${calculator(10, 5) { a, b -> a + b }}")
    
    // Function references
    fun isEven(n: Int): Boolean = n % 2 == 0
    fun square(n: Int): Int = n * n
    
    val numbers = listOf(1, 2, 3, 4, 5, 6)
    
    // Method reference
    val evens = numbers.filter(::isEven)
    val squares = numbers.map(::square)
    
    println("Numbers: $numbers")
    println("Evens: $evens")
    println("Squares: $squares")
    
    // Property reference
    data class User(val name: String, val age: Int)
    val users = listOf(User("Alice", 30), User("Bob", 25), User("Charlie", 35))
    
    val names = users.map(User::name)
    val ages = users.map(User::age)
    
    println("Names: $names")
    println("Ages: $ages")
    
    println()
}

fun practicalFunctionalExamples() {
    println("=== Practical Functional Examples ===")
    
    // Example 1: Data validation pipeline
    data class User(val name: String, val email: String, val age: Int)
    
    val validators = listOf<(User) -> String?>(
        { user -> if (user.name.isBlank()) "Name cannot be blank" else null },
        { user -> if (!user.email.contains("@")) "Invalid email format" else null },
        { user -> if (user.age < 0) "Age cannot be negative" else null },
        { user -> if (user.age > 150) "Age seems unrealistic" else null }
    )
    
    fun validateUser(user: User): List<String> {
        return validators.mapNotNull { it(user) }
    }
    
    val users = listOf(
        User("Alice", "alice@example.com", 30),
        User("", "bob@example.com", 25),
        User("Charlie", "invalid-email", 35),
        User("Diana", "diana@example.com", -5)
    )
    
    println("User validation:")
    users.forEach { user ->
        val errors = validateUser(user)
        if (errors.isEmpty()) {
            println("✓ ${user.name} is valid")
        } else {
            println("✗ ${user.name}: ${errors.joinToString(", ")}")
        }
    }
    
    // Example 2: Functional error handling
    sealed class Result<out T> {
        data class Success<T>(val value: T) : Result<T>()
        data class Failure(val error: String) : Result<Nothing>()
    }
    
    fun <T> T?.toResult(errorMessage: String): Result<T> {
        return if (this != null) Result.Success(this) else Result.Failure(errorMessage)
    }
    
    fun <T, R> Result<T>.map(transform: (T) -> R): Result<R> {
        return when (this) {
            is Result.Success -> Result.Success(transform(value))
            is Result.Failure -> this
        }
    }
    
    fun <T, R> Result<T>.flatMap(transform: (T) -> Result<R>): Result<R> {
        return when (this) {
            is Result.Success -> transform(value)
            is Result.Failure -> this
        }
    }
    
    fun parseAge(input: String): Result<Int> {
        return try {
            val age = input.toInt()
            if (age >= 0) Result.Success(age) else Result.Failure("Age must be non-negative")
        } catch (e: NumberFormatException) {
            Result.Failure("Invalid number format")
        }
    }
    
    fun categorizeAge(age: Int): String {
        return when (age) {
            in 0..12 -> "Child"
            in 13..17 -> "Teenager"
            in 18..64 -> "Adult"
            else -> "Senior"
        }
    }
    
    println("\nFunctional error handling:")
    val ageInputs = listOf("25", "abc", "-5", "150")
    
    ageInputs.forEach { input ->
        val result = parseAge(input)
            .map { categorizeAge(it) }
        
        when (result) {
            is Result.Success -> println("'$input' -> ${result.value}")
            is Result.Failure -> println("'$input' -> Error: ${result.error}")
        }
    }
    
    // Example 3: Currying and partial application
    fun curriedAdd(a: Int): (Int) -> (Int) -> Int {
        return { b -> { c -> a + b + c } }
    }
    
    val addFive = curriedAdd(5)
    val addFiveAndThree = addFive(3)
    
    println("\nCurrying example:")
    println("5 + 3 + 2 = ${addFiveAndThree(2)}")
    
    // Partial application
    fun <A, B, C> ((A, B) -> C).partial(a: A): (B) -> C {
        return { b -> this(a, b) }
    }
    
    val multiply = { a: Int, b: Int -> a * b }
    val double = multiply.partial(2)
    val triple = multiply.partial(3)
    
    println("Double 7: ${double(7)}")
    println("Triple 7: ${triple(7)}")
    
    println()
}
