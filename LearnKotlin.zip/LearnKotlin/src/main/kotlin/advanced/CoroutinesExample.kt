package advanced

import kotlinx.coroutines.*
import kotlin.system.measureTimeMillis

/**
 * Coroutines Examples
 * 
 * This file demonstrates Kotlin coroutines for asynchronous programming,
 * including basic coroutines, async/await, and different coroutine scopes.
 */

fun main() {
    println("=== Kotlin Coroutines ===\n")
    
    // Basic coroutines
    demonstrateBasicCoroutines()
    
    // Async and await
    demonstrateAsyncAwait()
    
    // Coroutine scopes and contexts
    demonstrateScopes()
    
    // Exception handling
    demonstrateExceptionHandling()
    
    // Practical example
    practicalExample()
}

fun demonstrateBasicCoroutines() {
    println("=== Basic Coroutines ===")
    
    runBlocking {
        println("Main thread: ${Thread.currentThread().name}")
        
        // Launch a new coroutine
        launch {
            delay(1000)  // Non-blocking delay
            println("Coroutine 1: ${Thread.currentThread().name}")
        }
        
        launch {
            delay(500)
            println("Coroutine 2: ${Thread.currentThread().name}")
        }
        
        println("Main coroutine continues...")
        delay(1500)  // Wait for coroutines to complete
        println("All coroutines completed")
    }
    
    println()
}

// Suspend functions
suspend fun fetchData(id: Int): String {
    println("Fetching data for ID: $id")
    delay(1000)  // Simulate network call
    return "Data for ID: $id"
}

suspend fun processData(data: String): String {
    println("Processing: $data")
    delay(500)   // Simulate processing time
    return "Processed: $data"
}

suspend fun saveData(data: String): Boolean {
    println("Saving: $data")
    delay(300)   // Simulate database operation
    return true
}

fun demonstrateAsyncAwait() {
    println("=== Async and Await ===")
    
    runBlocking {
        // Sequential execution
        println("Sequential execution:")
        val time1 = measureTimeMillis {
            val data1 = fetchData(1)
            val data2 = fetchData(2)
            val data3 = fetchData(3)
            println("Results: $data1, $data2, $data3")
        }
        println("Sequential time: ${time1}ms\n")
        
        // Concurrent execution with async
        println("Concurrent execution:")
        val time2 = measureTimeMillis {
            val deferred1 = async { fetchData(1) }
            val deferred2 = async { fetchData(2) }
            val deferred3 = async { fetchData(3) }
            
            val results = listOf(deferred1.await(), deferred2.await(), deferred3.await())
            println("Results: $results")
        }
        println("Concurrent time: ${time2}ms\n")
        
        // Pipeline processing
        println("Pipeline processing:")
        val time3 = measureTimeMillis {
            val data = fetchData(4)
            val processed = processData(data)
            val saved = saveData(processed)
            println("Pipeline completed successfully: $saved")
        }
        println("Pipeline time: ${time3}ms")
    }
    
    println()
}

fun demonstrateScopes() {
    println("=== Coroutine Scopes and Contexts ===")
    
    runBlocking {
        println("Main context: ${coroutineContext}")
        
        // Different dispatchers
        launch(Dispatchers.Default) {
            println("Default dispatcher: ${Thread.currentThread().name}")
            // CPU-intensive work
            val result = (1..1000000).sum()
            println("Computation result: $result")
        }
        
        launch(Dispatchers.IO) {
            println("IO dispatcher: ${Thread.currentThread().name}")
            // IO operations (file, network, database)
            delay(100)
            println("IO operation completed")
        }
        
        // Using withContext to switch contexts
        withContext(Dispatchers.IO) {
            println("Switched to IO context: ${Thread.currentThread().name}")
            delay(100)
        }
        
        println("Back to main context: ${Thread.currentThread().name}")
        
        delay(1000)  // Wait for all coroutines
    }
    
    // Custom scope
    val customScope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    
    customScope.launch {
        delay(500)
        println("Custom scope coroutine executed")
    }
    
    // Don't forget to cancel the scope when done
    Thread.sleep(1000)  // Wait for completion
    customScope.cancel()
    
    println()
}

fun demonstrateExceptionHandling() {
    println("=== Exception Handling in Coroutines ===")
    
    runBlocking {
        // Exception in launch
        try {
            launch {
                delay(100)
                throw RuntimeException("Exception in launch")
            }.join()  // Wait for completion
        } catch (e: Exception) {
            println("Caught launch exception: ${e.message}")
        }
        
        // Exception in async
        try {
            val deferred = async {
                delay(100)
                throw RuntimeException("Exception in async")
            }
            deferred.await()
        } catch (e: Exception) {
            println("Caught async exception: ${e.message}")
        }
        
        // CoroutineExceptionHandler
        val handler = CoroutineExceptionHandler { _, exception ->
            println("Caught by handler: ${exception.message}")
        }
        
        val job = launch(handler) {
            throw RuntimeException("Unhandled exception")
        }
        
        job.join()
        
        // SupervisorJob - one child failure doesn't affect others
        supervisorScope {
            launch {
                delay(100)
                throw RuntimeException("Child 1 failed")
            }
            
            launch {
                delay(200)
                println("Child 2 completed successfully")
            }
            
            launch {
                delay(300)
                println("Child 3 completed successfully")
            }
            
            delay(400)
        }
    }
    
    println()
}

// Practical example: API client with caching
class ApiClient {
    private val cache = mutableMapOf<String, String>()
    
    suspend fun fetchUser(userId: String): User {
        return withContext(Dispatchers.IO) {
            // Check cache first
            cache[userId]?.let { cachedData ->
                println("Cache hit for user $userId")
                return@withContext User(userId, cachedData, "cached@example.com")
            }
            
            // Simulate API call
            println("Fetching user $userId from API...")
            delay(1000)
            
            val userData = "User $userId Data"
            cache[userId] = userData
            
            User(userId, userData, "$userId@example.com")
        }
    }
    
    suspend fun fetchUserPosts(userId: String): List<Post> {
        return withContext(Dispatchers.IO) {
            println("Fetching posts for user $userId...")
            delay(800)
            
            listOf(
                Post("$userId-1", "First post by user $userId"),
                Post("$userId-2", "Second post by user $userId")
            )
        }
    }
    
    suspend fun fetchUserProfile(userId: String): UserProfile {
        return coroutineScope {
            // Launch concurrent requests
            val userDeferred = async { fetchUser(userId) }
            val postsDeferred = async { fetchUserPosts(userId) }
            
            // Wait for both results
            val user = userDeferred.await()
            val posts = postsDeferred.await()
            
            UserProfile(user, posts)
        }
    }
}

data class User(val id: String, val name: String, val email: String)
data class Post(val id: String, val content: String)
data class UserProfile(val user: User, val posts: List<Post>)

fun practicalExample() {
    println("=== Practical Example: API Client ===")
    
    val apiClient = ApiClient()
    
    runBlocking {
        // Fetch single user
        println("Fetching single user:")
        val user = apiClient.fetchUser("123")
        println("User: $user")
        
        println("\nFetching user profile (concurrent requests):")
        val time = measureTimeMillis {
            val profile = apiClient.fetchUserProfile("456")
            println("Profile: ${profile.user}")
            println("Posts: ${profile.posts}")
        }
        println("Profile fetch time: ${time}ms")
        
        // Demonstrate caching
        println("\nDemonstrating cache:")
        val cachedUser = apiClient.fetchUser("123")  // Should be cached
        println("Cached user: $cachedUser")
        
        // Fetch multiple users concurrently
        println("\nFetching multiple users concurrently:")
        val multipleUsersTime = measureTimeMillis {
            val userIds = listOf("100", "200", "300", "400", "500")
            
            val users = userIds.map { userId ->
                async { apiClient.fetchUser(userId) }
            }.awaitAll()
            
            users.forEach { println("Fetched: ${it.name}") }
        }
        println("Multiple users fetch time: ${multipleUsersTime}ms")
    }
    
    println()
}

// Flow example (alternative to coroutines for streams of data)
suspend fun demonstrateFlow() {
    println("=== Flow Example ===")
    
    // Simple flow
    val numbers = flow {
        for (i in 1..5) {
            delay(100)
            emit(i)
        }
    }
    
    println("Collecting flow:")
    numbers.collect { value ->
        println("Received: $value")
    }
    
    println()
}
