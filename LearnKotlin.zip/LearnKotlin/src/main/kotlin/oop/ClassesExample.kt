package oop

/**
 * Object-Oriented Programming Examples
 * 
 * This file demonstrates Kotlin's OOP features including classes,
 * inheritance, interfaces, and data classes.
 */

fun main() {
    println("=== Kotlin Object-Oriented Programming ===\n")
    
    // Basic classes
    demonstrateBasicClasses()
    
    // Data classes
    demonstrateDataClasses()
    
    // Inheritance
    demonstrateInheritance()
    
    // Interfaces
    demonstrateInterfaces()
    
    // Object declarations and expressions
    demonstrateObjects()
    
    // Sealed classes
    demonstrateSealedClasses()
}

// Basic class with primary constructor
class Person(private val firstName: String, private val lastName: String, var age: Int) {
    
    // Property with custom getter
    val fullName: String
        get() = "$firstName $lastName"
    
    // Property with custom getter and setter
    var displayName: String = fullName
        get() = field.uppercase()
        set(value) {
            field = value.trim()
        }
    
    // Secondary constructor
    constructor(firstName: String, lastName: String) : this(firstName, lastName, 0)
    
    // Init block
    init {
        println("Person created: $fullName")
    }
    
    // Methods
    fun introduce() {
        println("Hi, I'm $fullName and I'm $age years old.")
    }
    
    fun haveBirthday() {
        age++
        println("Happy birthday! Now I'm $age years old.")
    }
    
    // Override toString
    override fun toString(): String {
        return "Person(name='$fullName', age=$age)"
    }
}

// Class with only primary constructor properties
class SimplePerson(val name: String, var age: Int) {
    fun greet() = println("Hello, I'm $name!")
}

fun demonstrateBasicClasses() {
    println("=== Basic Classes ===")
    
    val person1 = Person("John", "Doe", 25)
    person1.introduce()
    person1.haveBirthday()
    println("Display name: ${person1.displayName}")
    
    val person2 = Person("Jane", "Smith")  // Using secondary constructor
    person2.introduce()
    
    val simplePerson = SimplePerson("Alice", 30)
    simplePerson.greet()
    println("Simple person: $simplePerson")
    
    println()
}

// Data class - automatically provides equals, hashCode, toString, copy, componentN
data class User(val id: Int, val name: String, val email: String, var isActive: Boolean = true)

data class Address(val street: String, val city: String, val zipCode: String)

data class Employee(
    val id: Int,
    val name: String,
    val department: String,
    val salary: Double,
    val address: Address
)

fun demonstrateDataClasses() {
    println("=== Data Classes ===")
    
    val user1 = User(1, "John Doe", "john@example.com")
    val user2 = User(2, "Jane Smith", "jane@example.com", false)
    val user3 = User(1, "John Doe", "john@example.com")
    
    println("User 1: $user1")
    println("User 2: $user2")
    
    // Equality (automatically generated)
    println("user1 == user3: ${user1 == user3}")  // true
    println("user1 === user3: ${user1 === user3}")  // false (different objects)
    
    // Copy with modifications
    val updatedUser = user1.copy(email = "john.doe@example.com")
    println("Updated user: $updatedUser")
    
    // Destructuring
    val (id, name, email, isActive) = user1
    println("Destructured: id=$id, name=$name, email=$email, active=$isActive")
    
    // Complex data class
    val address = Address("123 Main St", "Anytown", "12345")
    val employee = Employee(1, "Alice Johnson", "Engineering", 75000.0, address)
    println("Employee: $employee")
    
    // Destructuring nested objects
    val (empId, empName, dept, salary, empAddress) = employee
    val (street, city, zip) = empAddress
    println("Employee lives at $street, $city $zip")
    
    println()
}

// Base class (must be marked 'open' to be inherited)
open class Animal(protected val name: String, protected val species: String) {
    
    open fun makeSound() {
        println("$name makes a generic animal sound")
    }
    
    open fun move() {
        println("$name moves around")
    }
    
    fun sleep() {
        println("$name is sleeping")
    }
    
    // Final method (cannot be overridden)
    final fun breathe() {
        println("$name is breathing")
    }
}

// Derived class
class Dog(name: String, private val breed: String) : Animal(name, "Canine") {
    
    override fun makeSound() {
        println("$name barks: Woof! Woof!")
    }
    
    override fun move() {
        println("$name runs on four legs")
    }
    
    fun fetch() {
        println("$name fetches the ball")
    }
    
    fun wagTail() {
        println("$name wags tail happily")
    }
}

class Cat(name: String, private val isIndoor: Boolean = true) : Animal(name, "Feline") {
    
    override fun makeSound() {
        println("$name meows: Meow!")
    }
    
    override fun move() {
        val location = if (isIndoor) "around the house" else "outdoors"
        println("$name prowls $location")
    }
    
    fun purr() {
        println("$name purrs contentedly")
    }
}

// Abstract class
abstract class Vehicle(protected val brand: String, protected val model: String) {
    
    abstract fun start()
    abstract fun stop()
    
    open fun honk() {
        println("Beep beep!")
    }
    
    fun getInfo() = "$brand $model"
}

class Car(brand: String, model: String, private val fuelType: String) : Vehicle(brand, model) {
    
    override fun start() {
        println("$brand $model engine starts with $fuelType")
    }
    
    override fun stop() {
        println("$brand $model engine stops")
    }
    
    override fun honk() {
        println("Car horn: HONK HONK!")
    }
}

fun demonstrateInheritance() {
    println("=== Inheritance ===")
    
    val dog = Dog("Buddy", "Golden Retriever")
    val cat = Cat("Whiskers", false)
    
    println("=== Dog ===")
    dog.makeSound()
    dog.move()
    dog.fetch()
    dog.wagTail()
    dog.sleep()
    dog.breathe()
    
    println("\n=== Cat ===")
    cat.makeSound()
    cat.move()
    cat.purr()
    cat.sleep()
    
    // Polymorphism
    println("\n=== Polymorphism ===")
    val animals: List<Animal> = listOf(dog, cat)
    
    for (animal in animals) {
        animal.makeSound()  // Calls overridden method
        animal.move()       // Calls overridden method
    }
    
    // Abstract class example
    println("\n=== Abstract Class ===")
    val car = Car("Toyota", "Camry", "gasoline")
    println("Vehicle: ${car.getInfo()}")
    car.start()
    car.honk()
    car.stop()
    
    println()
}

// Interface definition
interface Drawable {
    fun draw()
    
    // Interface with default implementation
    fun prepare() {
        println("Preparing to draw...")
    }
    
    // Property in interface
    val color: String
        get() = "default color"
}

interface Clickable {
    fun click()
    
    // Default implementation
    fun showClick() {
        println("Element clicked!")
    }
}

// Interface with properties
interface Named {
    val name: String
    val displayName: String
        get() = name.uppercase()
}

// Class implementing multiple interfaces
class Button(override val name: String, private val backgroundColor: String) : Drawable, Clickable, Named {
    
    override val color: String = backgroundColor
    
    override fun draw() {
        println("Drawing button '$name' with color $color")
    }
    
    override fun click() {
        println("Button '$name' was clicked!")
        showClick()
    }
}

class Circle(private val radius: Double, override val color: String = "red") : Drawable {
    
    override fun draw() {
        println("Drawing a $color circle with radius $radius")
    }
}

fun demonstrateInterfaces() {
    println("=== Interfaces ===")
    
    val button = Button("Submit", "blue")
    val circle = Circle(5.0, "green")
    
    // Interface polymorphism
    val drawables: List<Drawable> = listOf(button, circle)
    
    for (drawable in drawables) {
        drawable.prepare()
        drawable.draw()
        println("Color: ${drawable.color}")
        println()
    }
    
    // Multiple interface implementation
    button.click()
    println("Button display name: ${button.displayName}")
    
    println()
}

// Object declaration (Singleton)
object MathUtils {
    const val PI = 3.14159
    
    fun circleArea(radius: Double): Double = PI * radius * radius
    
    fun rectangleArea(width: Double, height: Double): Double = width * height
}

// Object expression (anonymous object)
class EventManager {
    
    interface EventListener {
        fun onEvent(event: String)
    }
    
    private val listeners = mutableListOf<EventListener>()
    
    fun addEventListener(listener: EventListener) {
        listeners.add(listener)
    }
    
    fun fireEvent(event: String) {
        listeners.forEach { it.onEvent(event) }
    }
}

// Companion object (like static in Java)
class DatabaseConfig {
    companion object {
        const val DEFAULT_PORT = 5432
        const val DEFAULT_HOST = "localhost"
        
        fun createDefaultConfig(): DatabaseConfig {
            return DatabaseConfig()
        }
        
        fun isValidPort(port: Int): Boolean = port in 1..65535
    }
    
    var host: String = DEFAULT_HOST
    var port: Int = DEFAULT_PORT
    
    override fun toString(): String = "DatabaseConfig(host='$host', port=$port)"
}

fun demonstrateObjects() {
    println("=== Object Declarations and Expressions ===")
    
    // Object declaration (singleton)
    println("Circle area (radius=5): ${MathUtils.circleArea(5.0)}")
    println("Rectangle area (3x4): ${MathUtils.rectangleArea(3.0, 4.0)}")
    println("PI constant: ${MathUtils.PI}")
    
    // Object expression (anonymous object)
    val eventManager = EventManager()
    
    val logger = object : EventManager.EventListener {
        override fun onEvent(event: String) {
            println("Log: Event occurred - $event")
        }
    }
    
    val emailNotifier = object : EventManager.EventListener {
        override fun onEvent(event: String) {
            println("Email: Sending notification for event - $event")
        }
    }
    
    eventManager.addEventListener(logger)
    eventManager.addEventListener(emailNotifier)
    eventManager.fireEvent("User Login")
    
    // Companion object
    println("\nCompanion Object:")
    val config = DatabaseConfig.createDefaultConfig()
    println("Default config: $config")
    println("Is port 8080 valid? ${DatabaseConfig.isValidPort(8080)}")
    println("Default port: ${DatabaseConfig.DEFAULT_PORT}")
    
    println()
}

// Sealed class - restricted class hierarchy
sealed class Result<out T>
data class Success<T>(val data: T) : Result<T>()
data class Error(val message: String, val exception: Throwable? = null) : Result<Nothing>()
object Loading : Result<Nothing>()

// Sealed class for UI states
sealed class UiState {
    object Loading : UiState()
    data class Success(val data: List<String>) : UiState()
    data class Error(val message: String) : UiState()
}

fun demonstrateSealedClasses() {
    println("=== Sealed Classes ===")
    
    fun handleResult(result: Result<String>) {
        when (result) {
            is Success -> println("Success: ${result.data}")
            is Error -> println("Error: ${result.message}")
            Loading -> println("Loading...")
            // No else clause needed - compiler knows all cases
        }
    }
    
    fun handleUiState(state: UiState) {
        when (state) {
            is UiState.Loading -> println("UI: Loading...")
            is UiState.Success -> println("UI: Data loaded - ${state.data}")
            is UiState.Error -> println("UI: Error occurred - ${state.message}")
        }
    }
    
    // Examples
    val results = listOf(
        Success("Data loaded successfully"),
        Error("Network error"),
        Loading,
        Success("User profile updated")
    )
    
    results.forEach { handleResult(it) }
    
    println()
    
    val uiStates = listOf(
        UiState.Loading,
        UiState.Success(listOf("Item 1", "Item 2", "Item 3")),
        UiState.Error("Failed to load data")
    )
    
    uiStates.forEach { handleUiState(it) }
    
    println()
}
