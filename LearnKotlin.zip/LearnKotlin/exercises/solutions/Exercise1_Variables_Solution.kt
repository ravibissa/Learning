/*
 * Solution: Exercise 1 - Variables and Data Types
 */

package exercises.solutions

fun main() {
    println("=== Exercise 1 Solutions: Variables and Data Types ===")
    
    exercise1Solution()
    exercise2Solution()
    exercise3Solution()
    exercise4Solution()
    exercise5Solution()
}

fun exercise1Solution() {
    println("\n--- Exercise 1.1 Solution: Variable Declarations ---")
    
    // Immutable and mutable variable declarations
    val name = "Alice Johnson"          // Immutable
    var age = 28                        // Mutable
    val isStudent = false               // Immutable
    var city = "San Francisco"          // Mutable
    
    // Print initial values
    println("Initial values:")
    println("Name: $name, Age: $age, Student: $isStudent, City: $city")
    
    // Update mutable variables
    age = 29
    city = "Seattle"
    
    // Print updated values
    println("Updated values:")
    println("Name: $name, Age: $age, Student: $isStudent, City: $city")
}

fun exercise2Solution() {
    println("\n--- Exercise 1.2 Solution: Type Inference vs Explicit Types ---")
    
    // Type inference
    val numberInferred = 42
    val decimalInferred = 3.14
    
    // Explicit type declaration
    val numberExplicit: Int = 42
    val decimalExplicit: Double = 3.14
    
    println("Type inferred - Number: $numberInferred, Decimal: $decimalInferred")
    println("Explicit types - Number: $numberExplicit, Decimal: $decimalExplicit")
    
    // Verify they work the same way
    println("Numbers equal: ${numberInferred == numberExplicit}")
    println("Decimals equal: ${decimalInferred == decimalExplicit}")
}

fun exercise3Solution() {
    println("\n--- Exercise 1.3 Solution: String Operations ---")
    
    val firstName = "John"
    val lastName = "Doe"
    
    // String concatenation
    val fullNameConcat = firstName + " " + lastName
    
    // String template
    val fullNameTemplate = "$firstName $lastName"
    
    // Complex string template with expressions
    val age = 25
    val message = "Hello, my name is $fullNameTemplate and I am $age years old. Next year I'll be ${age + 1}."
    
    println("First name: $firstName")
    println("Last name: $lastName")
    println("Full name (concatenation): $fullNameConcat")
    println("Full name (template): $fullNameTemplate")
    println("Complex message: $message")
}

fun exercise4Solution() {
    println("\n--- Exercise 1.4 Solution: Nullable Types ---")
    
    // Nullable variables
    var nullableString: String? = null
    val nullableInteger: Int? = 42
    
    println("Nullable string: $nullableString")
    println("Nullable integer: $nullableInteger")
    
    // Safe call operator
    val stringLength = nullableString?.length
    println("String length (safe call): $stringLength")
    
    // Update nullable string
    nullableString = "Hello Kotlin"
    val newStringLength = nullableString?.length
    println("Updated string: $nullableString")
    println("New string length: $newStringLength")
    
    // Elvis operator for default values
    val lengthOrDefault = nullableString?.length ?: 0
    val valueOrDefault = nullableInteger ?: 0
    
    println("Length with default: $lengthOrDefault")
    println("Value with default: $valueOrDefault")
    
    // This would cause compilation error (uncommented):
    // val nonNullable: String = null  // Error: Null can not be a value of a non-null type
}

fun exercise5Solution() {
    println("\n--- Exercise 1.5 Solution: Type Conversion ---")
    
    val numberString = "123"
    val invalidString = "abc"
    val numberInt = 42
    
    // Safe string to int conversion
    val convertedNumber = numberString.toIntOrNull()
    println("'$numberString' to Int: $convertedNumber")
    
    // Handle invalid conversion
    val invalidConversion = invalidString.toIntOrNull()
    println("'$invalidString' to Int: $invalidConversion")
    
    // Safe conversion with default
    val safeConversion = invalidString.toIntOrNull() ?: 0
    println("'$invalidString' to Int (with default): $safeConversion")
    
    // Convert int to other types
    val intToLong = numberInt.toLong()
    val intToDouble = numberInt.toDouble()
    val intToFloat = numberInt.toFloat()
    val intToString = numberInt.toString()
    
    println("Int $numberInt conversions:")
    println("  To Long: $intToLong")
    println("  To Double: $intToDouble")
    println("  To Float: $intToFloat")
    println("  To String: '$intToString'")
    
    // Try-catch approach for unsafe conversion
    try {
        val unsafeConversion = invalidString.toInt()
        println("Unsafe conversion result: $unsafeConversion")
    } catch (e: NumberFormatException) {
        println("Caught exception: ${e.message}")
    }
}
