/*
 * Exercise 1: Variables and Data Types
 * 
 * Practice with Kotlin variable declarations, type inference,
 * and basic data type operations.
 */

package exercises.basic

fun main() {
    println("=== Exercise 1: Variables and Data Types ===")
    
    // TODO: Complete the exercises below
    
    exercise1()
    exercise2()
    exercise3()
    exercise4()
    exercise5()
}

/*
 * Exercise 1.1: Variable Declarations
 * 
 * Create the following variables:
 * - An immutable variable 'name' with your name
 * - A mutable variable 'age' with your age
 * - An immutable variable 'isStudent' indicating if you're a student
 * - A mutable variable 'city' with your city name
 */
fun exercise1() {
    println("\n--- Exercise 1.1: Variable Declarations ---")
    
    // TODO: Declare the variables here
    
    // TODO: Print all variables in the format:
    // "Name: [name], Age: [age], Student: [isStudent], City: [city]"
    
    // TODO: Update the mutable variables and print them again
}

/*
 * Exercise 1.2: Type Inference vs Explicit Types
 * 
 * Create variables using both type inference and explicit type declaration:
 * - A number using type inference
 * - The same number using explicit type declaration
 * - A decimal using type inference
 * - The same decimal using explicit type declaration
 */
fun exercise2() {
    println("\n--- Exercise 1.2: Type Inference vs Explicit Types ---")
    
    // TODO: Create variables with type inference
    
    // TODO: Create the same variables with explicit types
    
    // TODO: Print all variables and verify they work the same way
}

/*
 * Exercise 1.3: String Operations
 * 
 * Work with strings and string templates:
 * - Create firstName and lastName variables
 * - Create a fullName using string concatenation (+)
 * - Create another fullName using string template
 * - Create a message with multiple variables in string template
 */
fun exercise3() {
    println("\n--- Exercise 1.3: String Operations ---")
    
    // TODO: Create firstName and lastName variables
    
    // TODO: Create fullName using concatenation
    
    // TODO: Create fullName using string template
    
    // TODO: Create a complex message using string template with expressions
    // Example: "Hello, my name is [fullName] and I am [age] years old."
}

/*
 * Exercise 1.4: Nullable Types
 * 
 * Practice with nullable variables:
 * - Create a nullable string that is initially null
 * - Create a nullable integer with a value
 * - Use safe call operator to get string length
 * - Use Elvis operator to provide default values
 */
fun exercise4() {
    println("\n--- Exercise 1.4: Nullable Types ---")
    
    // TODO: Create nullable variables
    
    // TODO: Use safe call operator (?.) to safely access nullable string length
    
    // TODO: Use Elvis operator (?:) to provide default values
    
    // TODO: Demonstrate null safety by trying to assign null to non-nullable variable (comment it out)
}

/*
 * Exercise 1.5: Type Conversion
 * 
 * Practice converting between different types:
 * - Convert string to int (safely)
 * - Convert int to different numeric types
 * - Handle conversion errors gracefully
 */
fun exercise5() {
    println("\n--- Exercise 1.5: Type Conversion ---")
    
    val numberString = "123"
    val invalidString = "abc"
    val numberInt = 42
    
    // TODO: Convert numberString to Int safely
    
    // TODO: Convert invalidString to Int safely (handle the error)
    
    // TODO: Convert numberInt to Long, Double, Float, and String
    
    // TODO: Print all conversion results
}

/*
 * HINTS:
 * 
 * 1. Use 'val' for immutable and 'var' for mutable variables
 * 2. Kotlin can infer types: val name = "John" (String inferred)
 * 3. Explicit types: val name: String = "John"
 * 4. String templates: "Hello, $name" or "Result: ${2 + 3}"
 * 5. Nullable types: String? can hold null, String cannot
 * 6. Safe call: nullableString?.length
 * 7. Elvis operator: nullableValue ?: defaultValue
 * 8. Safe conversion: "123".toIntOrNull()
 * 9. Type conversion methods: toInt(), toLong(), toDouble(), toString()
 * 
 * EXPECTED OUTPUT:
 * The exercises should demonstrate all the concepts above with clear output
 * showing variable values, null safety in action, and type conversions.
 */
