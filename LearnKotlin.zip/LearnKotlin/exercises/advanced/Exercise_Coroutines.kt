/*
 * Advanced Exercise: Coroutines and Async Programming
 * 
 * Practice with Kotlin coroutines, async/await, and concurrent programming.
 */

package exercises.advanced

import kotlinx.coroutines.*
import kotlin.system.measureTimeMillis

fun main() {
    println("=== Advanced Exercise: Coroutines ===")
    
    // TODO: Complete the exercises below
    
    runBlocking {
        exercise1()
        exercise2()
        exercise3()
        exercise4()
    }
}

/*
 * Exercise 1: Basic Coroutines
 * 
 * Create a simple coroutine that:
 * - Prints "Starting task"
 * - Waits for 1 second (use delay)
 * - Prints "Task completed"
 * 
 * Also create multiple coroutines that run concurrently.
 */
suspend fun exercise1() {
    println("\n--- Exercise 1: Basic Coroutines ---")
    
    // TODO: Create a simple coroutine using launch
    
    // TODO: Create 3 coroutines that run concurrently
    // Each should have a different delay (500ms, 1000ms, 1500ms)
    // and print their completion with an ID
}

/*
 * Exercise 2: Async and Await
 * 
 * Create functions that simulate:
 * - Fetching user data (takes 1 second)
 * - Fetching user posts (takes 800ms)
 * - Fetching user friends (takes 600ms)
 * 
 * Compare sequential vs concurrent execution times.
 */
suspend fun exercise2() {
    println("\n--- Exercise 2: Async and Await ---")
    
    // TODO: Create suspend functions for fetching data
    
    // TODO: Implement sequential execution and measure time
    
    // TODO: Implement concurrent execution using async/await and measure time
    
    // TODO: Compare the execution times
}

/*
 * Exercise 3: Error Handling in Coroutines
 * 
 * Create coroutines that might fail and practice different
 * error handling strategies:
 * - Try-catch in coroutines
 * - CoroutineExceptionHandler
 * - SupervisorJob for independent failures
 */
suspend fun exercise3() {
    println("\n--- Exercise 3: Error Handling ---")
    
    // TODO: Create a coroutine that throws an exception after a delay
    
    // TODO: Handle the exception with try-catch
    
    // TODO: Use CoroutineExceptionHandler
    
    // TODO: Demonstrate SupervisorJob behavior
}

/*
 * Exercise 4: Practical Application - Parallel Data Processing
 * 
 * Create a system that processes a list of numbers in parallel:
 * - Each number should be processed by a separate coroutine
 * - Processing involves expensive calculation (simulate with delay)
 * - Collect all results and display them
 * - Handle potential failures in individual processors
 */
suspend fun exercise4() {
    println("\n--- Exercise 4: Parallel Data Processing ---")
    
    val numbers = listOf(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
    
    // TODO: Create a suspend function that processes a single number
    // It should:
    // - Take some time (delay based on number)
    // - Return the number squared
    // - Occasionally fail (e.g., for even numbers > 6)
    
    // TODO: Process all numbers in parallel using async
    
    // TODO: Collect results, handling failures gracefully
    
    // TODO: Display successful results and count failures
}

// Helper functions you can use:

suspend fun fetchUserData(userId: Int): String {
    delay(1000)
    return "User data for $userId"
}

suspend fun fetchUserPosts(userId: Int): List<String> {
    delay(800)
    return listOf("Post 1 by $userId", "Post 2 by $userId")
}

suspend fun fetchUserFriends(userId: Int): List<String> {
    delay(600)
    return listOf("Friend 1 of $userId", "Friend 2 of $userId")
}

/*
 * HINTS:
 * 
 * 1. Use launch { } for fire-and-forget coroutines
 * 2. Use async { } when you need to return a value
 * 3. Call await() on Deferred to get the result
 * 4. Use delay() instead of Thread.sleep() in coroutines
 * 5. measureTimeMillis { } to measure execution time
 * 6. runBlocking { } to bridge regular and suspend functions
 * 7. Try-catch works inside coroutines for exception handling
 * 8. CoroutineExceptionHandler can handle uncaught exceptions
 * 9. SupervisorJob prevents child failures from cancelling siblings
 * 10. Use awaitAll() to wait for multiple Deferred results
 * 
 * CONCEPTS TO PRACTICE:
 * - Coroutine basics (launch, async, runBlocking)
 * - Suspend functions
 * - Concurrent vs sequential execution
 * - Exception handling in async code
 * - Practical patterns for parallel processing
 */
