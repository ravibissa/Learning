# Getting Started with Kotlin Learning Tutorial

Welcome! This guide will help you get started with learning Kotlin, especially if you have Java experience.

## 🚀 Quick Start

### 1. Setup Your Environment

Follow the detailed setup guide: [Windows Setup Guide](docs/kotlin-setup-windows.md)

**Quick setup checklist:**
- ✅ Install JDK 11 or later
- ✅ Install Kotlin compiler
- ✅ Install IntelliJ IDEA (recommended) or VS Code
- ✅ Install Gradle (for building projects)

### 2. Run the Tutorial

**Option A: Use the launcher scripts**
```bash
# On Windows
run.bat

# On Unix/Linux/Mac
./run.sh
```

**Option B: Use Gradle directly**
```bash
# Run the main application
gradle run

# Build the project
gradle build

# Run specific examples
gradle run --args="basics.VariablesExampleKt"
```

**Option C: Use your IDE**
- Open the project in IntelliJ IDEA
- Navigate to `src/main/kotlin/app/Main.kt`
- Click the run button

### 3. Learning Path

1. **📖 Read the Tutorial**: Start with [docs/kotlin-tutorial.md](docs/kotlin-tutorial.md)
2. **🎯 Run Examples**: Use the main application to explore different concepts
3. **💻 Practice**: Try the exercises in the `exercises/` directory
4. **🔨 Build**: Create your own Kotlin applications

## 📁 Project Structure

```
LearnKotlin/
├── 📄 README.md                    # Project overview
├── 📄 GETTING_STARTED.md          # This file
├── 📄 build.gradle.kts             # Build configuration
├── 📄 run.bat / run.sh             # Launcher scripts
├── 📁 docs/                        # Documentation
│   ├── kotlin-setup-windows.md     # Setup guide
│   └── kotlin-tutorial.md          # Complete tutorial
├── 📁 src/main/kotlin/             # Source code
│   ├── basics/                     # Basic concepts
│   ├── oop/                        # Object-oriented programming
│   ├── advanced/                   # Advanced features
│   └── app/                        # Main application
└── 📁 exercises/                   # Practice exercises
    ├── basic/                      # Basic exercises
    ├── advanced/                   # Advanced exercises
    └── solutions/                  # Exercise solutions
```

## 🎯 What You'll Learn

### Basic Concepts
- ✅ Variables and data types
- ✅ Functions and parameters
- ✅ Control flow (if, when, loops)
- ✅ Collections (lists, sets, maps)
- ✅ Null safety

### Object-Oriented Programming
- ✅ Classes and objects
- ✅ Inheritance and interfaces
- ✅ Data classes
- ✅ Sealed classes
- ✅ Object declarations

### Advanced Features
- ✅ Coroutines (async programming)
- ✅ Higher-order functions
- ✅ Extension functions
- ✅ Lambda expressions
- ✅ Functional programming patterns

### Practical Application
- ✅ Task management application
- ✅ Real-world examples
- ✅ Best practices
- ✅ Java interoperability

## 🛠️ Command Reference

### Building and Running
```bash
# Build the project
gradle build

# Run the main application
gradle run

# Clean build artifacts
gradle clean

# Run tests
gradle test

# Create JAR file
gradle jar
```

### Running Specific Examples
```bash
# Basic examples
gradle run --args="basics.VariablesExampleKt"
gradle run --args="basics.FunctionsExampleKt"
gradle run --args="basics.ControlFlowExampleKt"
gradle run --args="basics.CollectionsExampleKt"

# OOP examples
gradle run --args="oop.ClassesExampleKt"

# Advanced examples
gradle run --args="advanced.CoroutinesExampleKt"
gradle run --args="advanced.FunctionalExampleKt"
```

## 🎓 Learning Tips

### For Java Developers
- **Similarities**: Many concepts are familiar (classes, inheritance, interfaces)
- **Key differences**: Null safety, extension functions, coroutines
- **New features**: Data classes, sealed classes, smart casts
- **Mindset shift**: More functional, less boilerplate

### Best Practices
1. **Start small**: Begin with basic examples
2. **Practice regularly**: Consistency is key
3. **Read error messages**: They're usually very helpful
4. **Experiment**: Try modifying the examples
5. **Use the REPL**: Great for quick experiments

### Useful Resources
- [Official Kotlin Documentation](https://kotlinlang.org/docs/)
- [Kotlin Playground](https://play.kotlinlang.org/)
- [Kotlin Koans](https://kotlinlang.org/docs/koans.html)
- [Stack Overflow](https://stackoverflow.com/questions/tagged/kotlin)

## 🔧 Troubleshooting

### Common Issues

**"kotlin command not found"**
- Ensure Kotlin is installed and in your PATH
- Follow the setup guide carefully

**"java command not found"**
- Install JDK 11 or later
- Set JAVA_HOME environment variable

**"gradle command not found"**
- Install Gradle or use the Gradle wrapper (./gradlew)

**Build failures**
- Run `gradle clean` then `gradle build`
- Check that all dependencies are available

**IDE issues**
- Ensure Kotlin plugin is installed and enabled
- Refresh/reimport the Gradle project

### Getting Help

1. **Check the documentation** in the `docs/` folder
2. **Look at the examples** for similar patterns
3. **Read error messages** carefully
4. **Search online** with specific error messages
5. **Ask on forums** like Stack Overflow with the `kotlin` tag

## 🎉 Next Steps

After completing this tutorial:

1. **Build a project**: Create your own Kotlin application
2. **Explore frameworks**: Try Ktor, Spring Boot with Kotlin
3. **Mobile development**: Learn Kotlin Multiplatform Mobile
4. **Contribute**: Join the Kotlin community

## 📝 Feedback

This tutorial is designed to be beginner-friendly but comprehensive. If you have suggestions for improvement or find any issues, please:

1. Check the existing examples
2. Try the exercises
3. Experiment with the code
4. Share your learning experience

Happy learning! 🚀

---

**Remember**: Learning a new programming language takes time and practice. Don't rush through the concepts - understanding is more important than speed. Good luck on your Kotlin journey!
