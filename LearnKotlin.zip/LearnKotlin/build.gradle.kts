plugins {
    kotlin("jvm") version "1.9.21"
    application
}

group = "com.example"
version = "1.0.0"

repositories {
    mavenCentral()
}

dependencies {
    // Kotlin standard library
    implementation(kotlin("stdlib"))
    
    // Coroutines for asynchronous programming
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.7.3")
    
    // JSON processing (optional)
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.6.2")
    
    // Testing dependencies
    testImplementation(kotlin("test"))
    testImplementation("org.jetbrains.kotlinx:kotlinx-coroutines-test:1.7.3")
}

// Configure the application plugin
application {
    mainClass.set("app.MainKt")
}

// Java version compatibility
java {
    sourceCompatibility = JavaVersion.VERSION_11
    targetCompatibility = JavaVersion.VERSION_11
}

// Kotlin compiler options
tasks.withType<org.jetbrains.kotlin.gradle.tasks.KotlinCompile> {
    kotlinOptions {
        jvmTarget = "11"
        freeCompilerArgs = listOf("-Xjsr305=strict")
    }
}

// Configure test task
tasks.test {
    useJUnitPlatform()
}

// Create a task to run all examples
tasks.register("runAllExamples") {
    group = "application"
    description = "Run all Kotlin examples"
    
    doLast {
        println("=== Running Kotlin Examples ===")
        println("Use 'gradle run' to run the main application")
        println("Or run specific examples using the launcher scripts")
    }
}

// Configure JAR task
tasks.jar {
    manifest {
        attributes(
            "Main-Class" to "app.MainKt"
        )
    }
    
    // Include dependencies in the JAR
    from(configurations.runtimeClasspath.get().map { if (it.isDirectory) it else zipTree(it) }) {
        exclude("META-INF/*.RSA", "META-INF/*.SF", "META-INF/*.DSA")
    }
    
    duplicatesStrategy = DuplicatesStrategy.EXCLUDE
}
