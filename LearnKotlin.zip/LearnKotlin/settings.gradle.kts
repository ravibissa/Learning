rootProject.name = "LearnKotlin"

// Enable Gradle version catalogs
enableFeaturePreview("VERSION_CATALOGS")
