# Complete Kotlin Tutorial for Java Developers

Welcome to the comprehensive Kotlin tutorial! This guide is specifically designed for developers with Java experience, showing you how Kotlin concepts relate to what you already know.

## 📑 Table of Contents

1. [Introduction to Kotlin](#introduction-to-kotlin)
2. [Basic Syntax](#basic-syntax)
3. [Variables and Data Types](#variables-and-data-types)
4. [Functions](#functions)
5. [Control Flow](#control-flow)
6. [Collections](#collections)
7. [Object-Oriented Programming](#object-oriented-programming)
8. [Null Safety](#null-safety)
9. [Extension Functions](#extension-functions)
10. [Lambda Expressions and Higher-Order Functions](#lambda-expressions-and-higher-order-functions)
11. [Coroutines](#coroutines)
12. [Advanced Features](#advanced-features)

---

## 1. Introduction to Kotlin

### What is Kotlin?

Kotlin is a modern, statically-typed programming language that runs on the Java Virtual Machine (JVM). It's 100% interoperable with Java, meaning you can use Java libraries in Kotlin and vice versa.

### Why Kotlin for Java Developers?

- **Concise**: Reduces boilerplate code significantly
- **Safe**: Null safety built into the type system
- **Interoperable**: Seamless integration with existing Java code
- **Modern**: Includes modern language features like coroutines, extension functions, and data classes

### Hello World Comparison

**Java:**
```java
public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello, World!");
    }
}
```

**Kotlin:**
```kotlin
fun main() {
    println("Hello, World!")
}
```

Key differences:
- No class required for simple programs
- `fun` keyword for functions
- No semicolons required
- `println` instead of `System.out.println`

---

## 2. Basic Syntax

### Entry Point

**Java:**
```java
public static void main(String[] args) { }
```

**Kotlin:**
```kotlin
fun main() { }
// or with arguments
fun main(args: Array<String>) { }
```

### Packages and Imports

**Java:**
```java
package com.example.myapp;
import java.util.List;
import java.util.ArrayList;
```

**Kotlin:**
```kotlin
package com.example.myapp
import java.util.*  // Wildcard import
import kotlin.collections.ArrayList as KArrayList  // Aliasing
```

### Comments

Both languages use the same comment syntax:

```kotlin
// Single line comment

/*
 * Multi-line comment
 */

/**
 * Documentation comment (KDoc in Kotlin)
 */
```

---

## 3. Variables and Data Types

### Variable Declaration

**Java:**
```java
// Mutable variables
int age = 25;
String name = "John";

// Immutable (effectively final)
final int MAX_SIZE = 100;
```

**Kotlin:**
```kotlin
// Mutable variables
var age: Int = 25
var name: String = "John"

// Immutable (read-only)
val maxSize: Int = 100

// Type inference
var age = 25  // Int inferred
var name = "John"  // String inferred
val maxSize = 100  // Int inferred
```

### Basic Data Types

| Java | Kotlin | Size |
|------|--------|------|
| `byte` | `Byte` | 8 bits |
| `short` | `Short` | 16 bits |
| `int` | `Int` | 32 bits |
| `long` | `Long` | 64 bits |
| `float` | `Float` | 32 bits |
| `double` | `Double` | 64 bits |
| `boolean` | `Boolean` | - |
| `char` | `Char` | 16 bits |

**Java:**
```java
int number = 42;
long bigNumber = 42L;
float decimal = 3.14f;
double preciseDecimal = 3.14159;
boolean isTrue = true;
char letter = 'A';
```

**Kotlin:**
```kotlin
val number: Int = 42
val bigNumber: Long = 42L
val decimal: Float = 3.14f
val preciseDecimal: Double = 3.14159
val isTrue: Boolean = true
val letter: Char = 'A'

// Type inference
val number = 42  // Int
val bigNumber = 42L  // Long
val decimal = 3.14f  // Float
val preciseDecimal = 3.14159  // Double
```

### String Handling

**Java:**
```java
String firstName = "John";
String lastName = "Doe";
String fullName = firstName + " " + lastName;

// String formatting
String message = String.format("Hello, %s! You are %d years old.", name, age);
```

**Kotlin:**
```kotlin
val firstName = "John"
val lastName = "Doe"
val fullName = "$firstName $lastName"  // String interpolation

// String templates
val message = "Hello, $name! You are $age years old."

// Expression in string template
val mathResult = "2 + 3 = ${2 + 3}"

// Multi-line strings
val multiLine = """
    This is a
    multi-line
    string
""".trimIndent()
```

### Type Conversion

**Java:**
```java
int intValue = 42;
long longValue = intValue;  // Implicit widening
int backToInt = (int) longValue;  // Explicit casting
```

**Kotlin:**
```kotlin
val intValue: Int = 42
val longValue: Long = intValue.toLong()  // Explicit conversion
val backToInt: Int = longValue.toInt()

// All numeric types have conversion functions
val byteValue = intValue.toByte()
val floatValue = intValue.toFloat()
val doubleValue = intValue.toDouble()
```

---

## 4. Functions

### Basic Function Declaration

**Java:**
```java
public static int add(int a, int b) {
    return a + b;
}

public static void printMessage(String message) {
    System.out.println(message);
}
```

**Kotlin:**
```kotlin
fun add(a: Int, b: Int): Int {
    return a + b
}

// Single expression function
fun add(a: Int, b: Int): Int = a + b

// Unit return type (equivalent to void)
fun printMessage(message: String): Unit {
    println(message)
}

// Unit can be omitted
fun printMessage(message: String) {
    println(message)
}
```

### Default Parameters

**Java:**
```java
// Method overloading for default behavior
public static void greet(String name) {
    greet(name, "Hello");
}

public static void greet(String name, String greeting) {
    System.out.println(greeting + ", " + name + "!");
}
```

**Kotlin:**
```kotlin
fun greet(name: String, greeting: String = "Hello") {
    println("$greeting, $name!")
}

// Usage
greet("John")  // Uses default greeting
greet("John", "Hi")  // Custom greeting
```

### Named Arguments

**Kotlin:**
```kotlin
fun createUser(name: String, age: Int, isActive: Boolean = true, email: String) {
    // Function body
}

// Named arguments for clarity
createUser(
    name = "John",
    age = 25,
    email = "john@example.com"
    // isActive uses default value
)
```

### Variable Arguments (Varargs)

**Java:**
```java
public static void printNumbers(int... numbers) {
    for (int number : numbers) {
        System.out.println(number);
    }
}
```

**Kotlin:**
```kotlin
fun printNumbers(vararg numbers: Int) {
    for (number in numbers) {
        println(number)
    }
}

// Usage
printNumbers(1, 2, 3, 4, 5)

// Spread operator
val array = intArrayOf(1, 2, 3)
printNumbers(*array)  // Spread array elements
```

### Local Functions

Kotlin allows functions inside functions:

```kotlin
fun processData(data: List<String>): List<String> {
    fun validate(item: String): Boolean {
        return item.isNotEmpty() && item.length > 2
    }
    
    return data.filter { validate(it) }
}
```

---

## 5. Control Flow

### If Expressions

**Java:**
```java
// if statement
int max;
if (a > b) {
    max = a;
} else {
    max = b;
}

// Ternary operator
int max = (a > b) ? a : b;
```

**Kotlin:**
```kotlin
// if expression
val max = if (a > b) a else b

// Multi-line if expression
val max = if (a > b) {
    println("a is greater")
    a
} else {
    println("b is greater or equal")
    b
}
```

### When Expression (Switch Alternative)

**Java:**
```java
switch (day) {
    case 1:
    case 2:
    case 3:
    case 4:
    case 5:
        System.out.println("Weekday");
        break;
    case 6:
    case 7:
        System.out.println("Weekend");
        break;
    default:
        System.out.println("Invalid day");
}
```

**Kotlin:**
```kotlin
when (day) {
    1, 2, 3, 4, 5 -> println("Weekday")
    6, 7 -> println("Weekend")
    else -> println("Invalid day")
}

// when as expression
val dayType = when (day) {
    in 1..5 -> "Weekday"
    in 6..7 -> "Weekend"
    else -> "Invalid"
}

// when with conditions
when {
    age < 18 -> println("Minor")
    age < 65 -> println("Adult")
    else -> println("Senior")
}

// when with type checking
when (obj) {
    is String -> println("String of length ${obj.length}")
    is Int -> println("Integer: $obj")
    else -> println("Unknown type")
}
```

### Loops

**For Loops:**

**Java:**
```java
// Traditional for loop
for (int i = 0; i < 10; i++) {
    System.out.println(i);
}

// Enhanced for loop
List<String> list = Arrays.asList("a", "b", "c");
for (String item : list) {
    System.out.println(item);
}
```

**Kotlin:**
```kotlin
// Range-based for loop
for (i in 0..9) {
    println(i)
}

// Step and downTo
for (i in 10 downTo 1 step 2) {
    println(i)  // 10, 8, 6, 4, 2
}

// Iterating over collections
val list = listOf("a", "b", "c")
for (item in list) {
    println(item)
}

// With index
for ((index, item) in list.withIndex()) {
    println("$index: $item")
}
```

**While Loops:**

Both languages have similar while loops:

```kotlin
var i = 0
while (i < 10) {
    println(i)
    i++
}

do {
    println(i)
    i--
} while (i > 0)
```

### Break and Continue

**Java:**
```java
outer: for (int i = 0; i < 10; i++) {
    for (int j = 0; j < 10; j++) {
        if (j == 5) continue;
        if (i == 5) break outer;
        System.out.println("$i, $j");
    }
}
```

**Kotlin:**
```kotlin
outer@ for (i in 0..9) {
    for (j in 0..9) {
        if (j == 5) continue
        if (i == 5) break@outer
        println("$i, $j")
    }
}
```

---

## 6. Collections

### Arrays

**Java:**
```java
// Array declaration and initialization
int[] numbers = new int[5];
int[] initialized = {1, 2, 3, 4, 5};
String[] names = {"John", "Jane", "Bob"};

// Access elements
int first = numbers[0];
numbers[0] = 10;
```

**Kotlin:**
```kotlin
// Array creation
val numbers = Array(5) { 0 }  // Array of 5 zeros
val initialized = arrayOf(1, 2, 3, 4, 5)
val names = arrayOf("John", "Jane", "Bob")

// Primitive arrays (for performance)
val intArray = intArrayOf(1, 2, 3, 4, 5)
val doubleArray = doubleArrayOf(1.0, 2.0, 3.0)

// Access elements
val first = numbers[0]
numbers[0] = 10
```

### Lists

**Java:**
```java
// Mutable list
List<String> mutableList = new ArrayList<>();
mutableList.add("apple");
mutableList.add("banana");

// Immutable list (Java 9+)
List<String> immutableList = List.of("apple", "banana", "cherry");
```

**Kotlin:**
```kotlin
// Immutable list (read-only)
val fruits = listOf("apple", "banana", "cherry")

// Mutable list
val mutableFruits = mutableListOf("apple", "banana")
mutableFruits.add("cherry")
mutableFruits.remove("banana")

// Creating from array
val fruitsFromArray = arrayOf("apple", "banana").toList()
```

### Sets

**Java:**
```java
Set<String> set = new HashSet<>();
set.add("apple");
set.add("banana");
set.add("apple");  // Duplicate, won't be added
```

**Kotlin:**
```kotlin
// Immutable set
val fruits = setOf("apple", "banana", "apple")  // Only 2 elements

// Mutable set
val mutableFruits = mutableSetOf("apple", "banana")
mutableFruits.add("cherry")
```

### Maps

**Java:**
```java
Map<String, Integer> ages = new HashMap<>();
ages.put("John", 25);
ages.put("Jane", 30);

Integer johnAge = ages.get("John");
```

**Kotlin:**
```kotlin
// Immutable map
val ages = mapOf("John" to 25, "Jane" to 30)

// Mutable map
val mutableAges = mutableMapOf("John" to 25, "Jane" to 30)
mutableAges["Bob"] = 35
mutableAges.put("Alice", 28)

// Access elements
val johnAge = ages["John"]  // Returns Int? (nullable)
val johnAgeOrDefault = ages.getOrDefault("John", 0)
```

### Collection Operations

Kotlin provides rich collection operations:

```kotlin
val numbers = listOf(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)

// Filter
val evenNumbers = numbers.filter { it % 2 == 0 }

// Map
val squared = numbers.map { it * it }

// Reduce
val sum = numbers.reduce { acc, element -> acc + element }

// Fold
val sumWithInitial = numbers.fold(0) { acc, element -> acc + element }

// Find
val firstEven = numbers.find { it % 2 == 0 }

// Any/All/None
val hasEven = numbers.any { it % 2 == 0 }
val allPositive = numbers.all { it > 0 }
val noneNegative = numbers.none { it < 0 }

// GroupBy
val grouped = numbers.groupBy { it % 2 == 0 }  // Groups by even/odd

// Sort
val sorted = numbers.sortedBy { it }
val sortedDesc = numbers.sortedByDescending { it }
```

---

## 7. Object-Oriented Programming

### Classes

**Java:**
```java
public class Person {
    private String name;
    private int age;
    
    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }
    
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public int getAge() { return age; }
    public void setAge(int age) { this.age = age; }
    
    public void introduce() {
        System.out.println("Hi, I'm " + name + " and I'm " + age + " years old.");
    }
}
```

**Kotlin:**
```kotlin
class Person(private var name: String, private var age: Int) {
    
    fun introduce() {
        println("Hi, I'm $name and I'm $age years old.")
    }
    
    // Custom getter and setter
    var displayName: String
        get() = name.uppercase()
        set(value) {
            name = value.lowercase()
        }
}

// Even simpler with automatic getters/setters
class SimplePerson(var name: String, var age: Int) {
    fun introduce() = println("Hi, I'm $name and I'm $age years old.")
}
```

### Data Classes

**Java:**
```java
public class User {
    private final String name;
    private final int age;
    
    public User(String name, int age) {
        this.name = name;
        this.age = age;
    }
    
    // Getters, equals(), hashCode(), toString() methods...
    
    @Override
    public boolean equals(Object obj) {
        // Implementation...
    }
    
    @Override
    public int hashCode() {
        // Implementation...
    }
    
    @Override
    public String toString() {
        return "User{name='" + name + "', age=" + age + "}";
    }
}
```

**Kotlin:**
```kotlin
data class User(val name: String, val age: Int)

// Automatically provides:
// - toString()
// - equals() and hashCode()
// - componentN() functions for destructuring
// - copy() function

// Usage
val user1 = User("John", 25)
val user2 = User("John", 25)

println(user1)  // User(name=John, age=25)
println(user1 == user2)  // true

// Destructuring
val (name, age) = user1

// Copy with modifications
val olderUser = user1.copy(age = 26)
```

### Inheritance

**Java:**
```java
public class Animal {
    protected String name;
    
    public Animal(String name) {
        this.name = name;
    }
    
    public void makeSound() {
        System.out.println("Some generic animal sound");
    }
}

public class Dog extends Animal {
    public Dog(String name) {
        super(name);
    }
    
    @Override
    public void makeSound() {
        System.out.println("Woof!");
    }
}
```

**Kotlin:**
```kotlin
open class Animal(protected val name: String) {
    open fun makeSound() {
        println("Some generic animal sound")
    }
}

class Dog(name: String) : Animal(name) {
    override fun makeSound() {
        println("Woof!")
    }
}

// Abstract classes
abstract class Shape {
    abstract fun area(): Double
}

class Circle(private val radius: Double) : Shape() {
    override fun area(): Double = Math.PI * radius * radius
}
```

### Interfaces

**Java:**
```java
public interface Drawable {
    void draw();
    
    default void prepare() {
        System.out.println("Preparing to draw...");
    }
}

public class Circle implements Drawable {
    @Override
    public void draw() {
        System.out.println("Drawing a circle");
    }
}
```

**Kotlin:**
```kotlin
interface Drawable {
    fun draw()
    
    fun prepare() {
        println("Preparing to draw...")
    }
}

class Circle : Drawable {
    override fun draw() {
        println("Drawing a circle")
    }
}

// Interface with properties
interface Named {
    val name: String
    val displayName: String
        get() = name.uppercase()
}
```

### Object Declarations and Expressions

**Singleton (Object Declaration):**
```kotlin
object DatabaseManager {
    fun connect() {
        println("Connecting to database...")
    }
}

// Usage
DatabaseManager.connect()
```

**Anonymous Objects (Object Expression):**
```kotlin
val clickListener = object : View.OnClickListener {
    override fun onClick(view: View) {
        println("Button clicked!")
    }
}
```

### Companion Objects

**Java:**
```java
public class MathUtils {
    public static final double PI = 3.14159;
    
    public static int add(int a, int b) {
        return a + b;
    }
}
```

**Kotlin:**
```kotlin
class MathUtils {
    companion object {
        const val PI = 3.14159
        
        fun add(a: Int, b: Int): Int = a + b
    }
}

// Usage
val sum = MathUtils.add(5, 3)
println(MathUtils.PI)
```

---

## 8. Null Safety

One of Kotlin's most important features is built-in null safety.

### Nullable Types

**Java:**
```java
String name = null;  // Can cause NullPointerException
String upper = name.toUpperCase();  // Runtime crash!
```

**Kotlin:**
```kotlin
var name: String = "John"
// name = null  // Compilation error!

var nullableName: String? = "John"
nullableName = null  // OK

// Safe call operator
val upper = nullableName?.uppercase()  // Returns null if nullableName is null

// Elvis operator (null coalescing)
val length = nullableName?.length ?: 0

// Not-null assertion (use with caution!)
val definitelyNotNull = nullableName!!.uppercase()  // Throws exception if null
```

### Safe Calls and Let

```kotlin
val nullableString: String? = getNullableString()

// Traditional approach
if (nullableString != null) {
    println(nullableString.length)
}

// Kotlin approach with let
nullableString?.let { str ->
    println(str.length)
    // str is non-null here
}

// Chaining safe calls
person?.address?.street?.name?.uppercase()
```

### Platform Types

When interacting with Java code, Kotlin uses "platform types":

```kotlin
// Java method returns String (could be null)
val javaString = JavaClass.getString()  // Type is String! (platform type)

// You should explicitly handle nullability
val safeString: String? = JavaClass.getString()
```

---

## 9. Extension Functions

Extension functions allow you to add new functions to existing classes without modifying them.

### Basic Extension Functions

```kotlin
// Extend String class
fun String.removeSpaces(): String {
    return this.replace(" ", "")
}

// Usage
val text = "Hello World"
val noSpaces = text.removeSpaces()  // "HelloWorld"

// Extension with parameters
fun String.truncate(maxLength: Int): String {
    return if (this.length <= maxLength) this else this.substring(0, maxLength) + "..."
}

val longText = "This is a very long text"
val truncated = longText.truncate(10)  // "This is a..."
```

### Extension Properties

```kotlin
val String.firstChar: Char?
    get() = if (this.isEmpty()) null else this[0]

val String.lastChar: Char?
    get() = if (this.isEmpty()) null else this[this.length - 1]

// Usage
val text = "Hello"
println(text.firstChar)  // 'H'
println(text.lastChar)   // 'o'
```

### Extensions on Collections

```kotlin
fun <T> List<T>.secondOrNull(): T? {
    return if (this.size >= 2) this[1] else null
}

fun List<Int>.average(): Double {
    return if (this.isEmpty()) 0.0 else this.sum().toDouble() / this.size
}

// Usage
val numbers = listOf(1, 2, 3, 4, 5)
val second = numbers.secondOrNull()  // 2
val avg = numbers.average()  // 3.0
```

---

## 10. Lambda Expressions and Higher-Order Functions

### Lambda Syntax

**Java:**
```java
// Java 8 lambda
List<String> names = Arrays.asList("Alice", "Bob", "Charlie");
names.stream()
     .filter(name -> name.length() > 3)
     .forEach(System.out::println);
```

**Kotlin:**
```kotlin
val names = listOf("Alice", "Bob", "Charlie")

// Lambda with explicit parameter
names.filter { name -> name.length > 3 }
     .forEach { println(it) }

// Using 'it' for single parameter
names.filter { it.length > 3 }
     .forEach { println(it) }
```

### Function Types

```kotlin
// Function type declaration
val operation: (Int, Int) -> Int = { a, b -> a + b }

// Higher-order function
fun calculate(a: Int, b: Int, operation: (Int, Int) -> Int): Int {
    return operation(a, b)
}

// Usage
val sum = calculate(5, 3) { x, y -> x + y }
val product = calculate(5, 3) { x, y -> x * y }
```

### Common Higher-Order Functions

```kotlin
val numbers = listOf(1, 2, 3, 4, 5)

// map - transforms elements
val doubled = numbers.map { it * 2 }  // [2, 4, 6, 8, 10]

// filter - selects elements
val evens = numbers.filter { it % 2 == 0 }  // [2, 4]

// reduce - combines elements
val sum = numbers.reduce { acc, element -> acc + element }  // 15

// fold - like reduce but with initial value
val sumPlusTen = numbers.fold(10) { acc, element -> acc + element }  // 25

// forEach - performs action on each element
numbers.forEach { println(it) }

// takeWhile - takes elements while condition is true
val taken = numbers.takeWhile { it < 4 }  // [1, 2, 3]

// dropWhile - drops elements while condition is true
val dropped = numbers.dropWhile { it < 4 }  // [4, 5]
```

### Function Literals with Receiver

```kotlin
// Extension function syntax in lambda
fun String.transform(operation: String.() -> String): String {
    return this.operation()
}

// Usage
val result = "hello".transform {
    this.uppercase().reversed()
}  // "OLLEH"

// Common pattern in DSLs
class StringBuilder {
    fun append(text: String) { /* implementation */ }
}

fun buildString(builderAction: StringBuilder.() -> Unit): String {
    val builder = StringBuilder()
    builder.builderAction()
    return builder.toString()
}

// Usage
val html = buildString {
    append("<html>")
    append("<body>Hello</body>")
    append("</html>")
}
```

---

## 11. Coroutines

Coroutines are Kotlin's approach to asynchronous programming, replacing callbacks and complex threading.

### Basic Coroutines

```kotlin
import kotlinx.coroutines.*

// Basic coroutine
fun main() {
    runBlocking {  // Blocks until all coroutines complete
        launch {   // Starts a new coroutine
            delay(1000)  // Non-blocking delay
            println("World!")
        }
        println("Hello, ")
    }
}
```

### Suspend Functions

```kotlin
suspend fun fetchData(): String {
    delay(1000)  // Simulates network call
    return "Data from server"
}

suspend fun processData(data: String): String {
    delay(500)   // Simulates processing time
    return "Processed: $data"
}

fun main() {
    runBlocking {
        val data = fetchData()
        val processed = processData(data)
        println(processed)
    }
}
```

### Async and Await

```kotlin
import kotlinx.coroutines.*

suspend fun fetchUser(userId: Int): User {
    delay(1000)  // Simulates API call
    return User("User$userId", 25)
}

suspend fun fetchPosts(userId: Int): List<Post> {
    delay(800)   // Simulates API call
    return listOf(Post("Post 1"), Post("Post 2"))
}

fun main() {
    runBlocking {
        // Sequential execution
        val user = fetchUser(1)
        val posts = fetchPosts(1)
        
        // Concurrent execution
        val userDeferred = async { fetchUser(1) }
        val postsDeferred = async { fetchPosts(1) }
        
        val userResult = userDeferred.await()
        val postsResult = postsDeferred.await()
    }
}
```

### Coroutine Scope and Context

```kotlin
class UserRepository {
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    
    fun loadUser(id: Int, callback: (User?) -> Unit) {
        scope.launch {
            try {
                val user = fetchUser(id)
                withContext(Dispatchers.Main) {
                    callback(user)
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    callback(null)
                }
            }
        }
    }
}
```

---

## 12. Advanced Features

### Sealed Classes

Sealed classes represent restricted class hierarchies:

```kotlin
sealed class Result<out T>
data class Success<T>(val data: T) : Result<T>()
data class Error(val exception: Throwable) : Result<Nothing>()
object Loading : Result<Nothing>()

fun handleResult(result: Result<String>) {
    when (result) {
        is Success -> println("Data: ${result.data}")
        is Error -> println("Error: ${result.exception.message}")
        Loading -> println("Loading...")
        // No else clause needed - compiler knows all cases
    }
}
```

### Inline Functions

Inline functions reduce overhead of higher-order functions:

```kotlin
inline fun <T> measure(block: () -> T): T {
    val start = System.currentTimeMillis()
    val result = block()
    val time = System.currentTimeMillis() - start
    println("Execution took $time ms")
    return result
}

// Usage - block is inlined at call site
val result = measure {
    Thread.sleep(1000)
    "Done"
}
```

### Reified Type Parameters

```kotlin
inline fun <reified T> parseJson(json: String): T {
    return Gson().fromJson(json, T::class.java)
}

// Usage - type information is preserved
val user: User = parseJson<User>(jsonString)
```

### Delegation

**Property Delegation:**
```kotlin
class User {
    var name: String by Delegates.observable("initial") { property, oldValue, newValue ->
        println("$oldValue -> $newValue")
    }
}

// Lazy initialization
val heavyObject: ExpensiveClass by lazy {
    println("Creating expensive object...")
    ExpensiveClass()
}
```

**Class Delegation:**
```kotlin
interface Repository {
    fun save(data: String)
    fun load(): String
}

class DatabaseRepository : Repository {
    override fun save(data: String) = println("Saving to database: $data")
    override fun load(): String = "Data from database"
}

class CachedRepository(
    private val repository: Repository
) : Repository by repository {
    
    private var cache: String? = null
    
    override fun load(): String {
        return cache ?: repository.load().also { cache = it }
    }
}
```

### Type Aliases

```kotlin
typealias UserMap = Map<String, User>
typealias ClickListener = (View) -> Unit

fun processUsers(users: UserMap) {
    // users is actually Map<String, User>
}

fun setClickListener(listener: ClickListener) {
    // listener is actually (View) -> Unit
}
```

### Destructuring Declarations

```kotlin
// Data classes
data class Person(val name: String, val age: Int)
val person = Person("John", 25)
val (name, age) = person

// Maps
val map = mapOf("key1" to "value1", "key2" to "value2")
for ((key, value) in map) {
    println("$key = $value")
}

// Lists with indices
val list = listOf("a", "b", "c")
for ((index, value) in list.withIndex()) {
    println("$index: $value")
}
```

### Operator Overloading

```kotlin
data class Point(val x: Int, val y: Int) {
    operator fun plus(other: Point): Point {
        return Point(x + other.x, y + other.y)
    }
    
    operator fun times(scalar: Int): Point {
        return Point(x * scalar, y * scalar)
    }
}

// Usage
val p1 = Point(1, 2)
val p2 = Point(3, 4)
val sum = p1 + p2  // Point(4, 6)
val scaled = p1 * 3  // Point(3, 6)
```

---

## Summary: Key Differences from Java

1. **Null Safety**: Built into the type system
2. **Conciseness**: Less boilerplate code
3. **Immutability**: `val` vs `var`, immutable collections by default
4. **Functions**: First-class citizens, can be passed around
5. **Extension Functions**: Add functionality to existing classes
6. **Smart Casts**: Automatic type casting after null checks
7. **Data Classes**: Automatic generation of common methods
8. **Coroutines**: Built-in asynchronous programming support
9. **String Templates**: Embedded expressions in strings
10. **Default Parameters**: No need for method overloading

## Next Steps

1. Practice with the examples in this tutorial
2. Build the sample application provided in this repository
3. Start converting small Java classes to Kotlin
4. Explore Kotlin-specific libraries and frameworks
5. Join the Kotlin community and contribute to open source projects

Happy coding with Kotlin! 🎉
