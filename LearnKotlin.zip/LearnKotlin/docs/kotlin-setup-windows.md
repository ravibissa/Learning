# Kotlin Setup Guide for Windows

This guide will walk you through setting up Kotlin on your Windows machine step by step.

## 📋 Prerequisites

- Windows 10 or later
- Basic familiarity with command line
- Internet connection for downloads

## 🔧 Step 1: Install Java Development Kit (JDK)

Kotlin runs on the Java Virtual Machine (JVM), so you need Java installed first.

### Option A: Install Oracle JDK (Recommended)

1. **Download JDK**:
   - Visit [Oracle JDK Downloads](https://www.oracle.com/java/technologies/downloads/)
   - Download JDK 11 or later (JDK 17 LTS recommended)
   - Choose "Windows x64 Installer"

2. **Install JDK**:
   - Run the downloaded `.exe` file
   - Follow the installation wizard
   - Note the installation path (usually `C:\Program Files\Java\jdk-17`)

3. **Set JAVA_HOME Environment Variable**:
   - Open "Environment Variables" (Win + R → `sysdm.cpl` → Advanced → Environment Variables)
   - Click "New" under System Variables
   - Variable name: `JAVA_HOME`
   - Variable value: `C:\Program Files\Java\jdk-17` (your JDK path)
   - Click OK

4. **Update PATH**:
   - Find "Path" in System Variables and click "Edit"
   - Click "New" and add: `%JAVA_HOME%\bin`
   - Click OK

### Option B: Install OpenJDK

1. **Download from Adoptium**:
   - Visit [Adoptium.net](https://adoptium.net/)
   - Download Eclipse Temurin JDK 17
   - Choose Windows x64 `.msi` installer

2. **Install and configure** (same steps as Oracle JDK above)

### Verify Java Installation

Open Command Prompt (Win + R → `cmd`) and run:

```cmd
java -version
javac -version
```

You should see Java version information.

## 🚀 Step 2: Install Kotlin

### Method 1: Using SDKMAN (Recommended)

SDKMAN is a tool for managing multiple software development kits.

1. **Install SDKMAN**:
   - Download and install [Git for Windows](https://git-scm.com/download/win) if not already installed
   - Open Git Bash (not Command Prompt)
   - Run: `curl -s "https://get.sdkman.io" | bash`
   - Close and reopen Git Bash
   - Run: `source "$HOME/.sdkman/bin/sdkman-init.sh"`

2. **Install Kotlin**:
   ```bash
   sdk install kotlin
   ```

3. **Verify Installation**:
   ```bash
   kotlin -version
   ```

### Method 2: Manual Installation

1. **Download Kotlin Compiler**:
   - Visit [Kotlin Releases](https://github.com/JetBrains/kotlin/releases)
   - Download `kotlin-compiler-X.X.X.zip` (latest version)

2. **Extract and Setup**:
   - Extract to `C:\kotlin` (or your preferred location)
   - Add `C:\kotlin\bin` to your PATH environment variable

3. **Verify Installation**:
   ```cmd
   kotlin -version
   kotlinc -version
   ```

### Method 3: Using Chocolatey

If you have Chocolatey package manager:

```cmd
choco install kotlin
```

## 🛠️ Step 3: Install an IDE

### Option A: IntelliJ IDEA (Highly Recommended)

IntelliJ IDEA has the best Kotlin support since JetBrains created both.

1. **Download IntelliJ IDEA**:
   - Visit [JetBrains IntelliJ IDEA](https://www.jetbrains.com/idea/)
   - Download Community Edition (free) or Ultimate Edition

2. **Install and Configure**:
   - Run the installer
   - During setup, make sure "Kotlin" plugin is enabled
   - Create a desktop shortcut

3. **Verify Kotlin Plugin**:
   - Open IntelliJ IDEA
   - Go to File → Settings → Plugins
   - Ensure "Kotlin" plugin is installed and enabled

### Option B: Visual Studio Code

1. **Install VS Code**:
   - Download from [code.visualstudio.com](https://code.visualstudio.com/)
   - Install with default settings

2. **Install Kotlin Extension**:
   - Open VS Code
   - Go to Extensions (Ctrl + Shift + X)
   - Search for "Kotlin Language" by fwcd
   - Install the extension

### Option C: Eclipse

1. **Install Eclipse IDE**:
   - Download from [eclipse.org](https://www.eclipse.org/downloads/)
   - Choose "Eclipse IDE for Java Developers"

2. **Install Kotlin Plugin**:
   - In Eclipse, go to Help → Eclipse Marketplace
   - Search for "Kotlin" and install the Kotlin Plugin

## 🔧 Step 4: Install Build Tools

### Gradle (Recommended)

1. **Using SDKMAN** (if you installed it):
   ```bash
   sdk install gradle
   ```

2. **Manual Installation**:
   - Download from [gradle.org](https://gradle.org/releases/)
   - Extract to `C:\gradle`
   - Add `C:\gradle\bin` to PATH

3. **Verify**:
   ```cmd
   gradle -version
   ```

### Maven (Alternative)

1. **Download Maven**:
   - Visit [maven.apache.org](https://maven.apache.org/download.cgi)
   - Download binary zip archive

2. **Install**:
   - Extract to `C:\maven`
   - Add `C:\maven\bin` to PATH
   - Set `MAVEN_HOME` environment variable

## ✅ Step 5: Verify Complete Setup

Create a test file to verify everything works:

1. **Create test directory**:
   ```cmd
   mkdir C:\kotlin-test
   cd C:\kotlin-test
   ```

2. **Create Hello.kt**:
   ```kotlin
   fun main() {
       println("Hello, Kotlin on Windows!")
       println("Java version: ${System.getProperty("java.version")}")
   }
   ```

3. **Compile and run**:
   ```cmd
   kotlinc Hello.kt -include-runtime -d Hello.jar
   java -jar Hello.jar
   ```

You should see:
```
Hello, Kotlin on Windows!
Java version: 17.0.x
```

## 🎯 Step 6: Create Your First Kotlin Project

### Using IntelliJ IDEA

1. **Create New Project**:
   - Open IntelliJ IDEA
   - File → New → Project
   - Select "Kotlin" → "Kotlin/JVM"
   - Choose project SDK (your installed JDK)
   - Set project name and location

2. **Create Main File**:
   - Right-click `src` → New → Kotlin Class/File
   - Choose "File" and name it "Main"
   - Add your Kotlin code

### Using Command Line with Gradle

1. **Initialize Gradle Project**:
   ```cmd
   mkdir MyKotlinApp
   cd MyKotlinApp
   gradle init --type kotlin-application
   ```

2. **Run the Application**:
   ```cmd
   gradle run
   ```

## 🔍 Troubleshooting

### Common Issues and Solutions

**Issue**: `'kotlin' is not recognized as an internal or external command`
- **Solution**: Ensure Kotlin's bin directory is in your PATH environment variable

**Issue**: `Java version not compatible`
- **Solution**: Update to JDK 11 or later

**Issue**: `JAVA_HOME not set`
- **Solution**: Set JAVA_HOME environment variable to your JDK installation path

**Issue**: Permission denied when installing
- **Solution**: Run Command Prompt as Administrator

**Issue**: Gradle build fails
- **Solution**: Ensure GRADLE_HOME is set and Gradle is in PATH

### Getting Help

- **Kotlin Documentation**: [kotlinlang.org](https://kotlinlang.org/docs/)
- **Kotlin Slack**: [kotlinlang.slack.com](https://kotlinlang.slack.com/)
- **Stack Overflow**: Tag your questions with `kotlin`

## 🎉 Next Steps

Now that you have Kotlin set up on Windows:

1. Read the [Kotlin Tutorial](kotlin-tutorial.md)
2. Practice with the sample applications in this repository
3. Join the Kotlin community and start building!

## 📚 Additional Tools (Optional)

### Kotlin Multiplatform Mobile

For mobile development:
- Install Android Studio
- Enable Kotlin Multiplatform Mobile plugin

### Kotlin/Native

For native development:
- Kotlin/Native is included with the Kotlin compiler
- No additional setup required

---

**Congratulations!** You now have a complete Kotlin development environment on Windows. Happy coding! 🚀
