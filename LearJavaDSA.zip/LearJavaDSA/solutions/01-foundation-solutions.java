/**
 * Foundation Exercise Solutions
 * 
 * This class contains complete solutions to all foundation exercises
 * with detailed explanations and complexity analysis.
 * 
 * @author DSA Tutorial
 * @version 1.0
 */
public class FoundationSolutions {
    
    /**
     * Exercise 1: Array Reversal
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     * 
     * Approach: Use two pointers from both ends, swap elements and move towards center
     */
    public static void reverseArray(int[] arr) {
        int left = 0;
        int right = arr.length - 1;
        
        while (left < right) {
            // Swap elements at left and right positions
            int temp = arr[left];
            arr[left] = arr[right];
            arr[right] = temp;
            
            // Move pointers towards center
            left++;
            right--;
        }
    }
    
    /**
     * Exercise 2: Find Second Largest
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     * 
     * Approach: Keep track of largest and second largest as we iterate
     */
    public static int findSecondLargest(int[] arr) {
        if (arr.length < 2) {
            return -1; // Need at least 2 elements
        }
        
        int largest = Integer.MIN_VALUE;
        int secondLargest = Integer.MIN_VALUE;
        
        for (int num : arr) {
            if (num > largest) {
                // New largest found, update both
                secondLargest = largest;
                largest = num;
            } else if (num > secondLargest && num != largest) {
                // New second largest found (but not equal to largest)
                secondLargest = num;
            }
        }
        
        return secondLargest == Integer.MIN_VALUE ? -1 : secondLargest;
    }
    
    /**
     * Exercise 3: Remove Duplicates from Sorted Array
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     * 
     * Approach: Use two pointers - one for reading, one for writing
     */
    public static int removeDuplicates(int[] arr) {
        if (arr.length == 0) {
            return 0;
        }
        
        int writeIndex = 1; // Index where next unique element should be written
        
        for (int readIndex = 1; readIndex < arr.length; readIndex++) {
            // If current element is different from previous, it's unique
            if (arr[readIndex] != arr[readIndex - 1]) {
                arr[writeIndex] = arr[readIndex];
                writeIndex++;
            }
        }
        
        return writeIndex; // New length of array
    }
    
    /**
     * Exercise 4: Two Sum
     * Time Complexity: O(n²) - can be optimized to O(n) with HashMap
     * Space Complexity: O(1) - can be optimized to O(n) with HashMap
     * 
     * Approach: Use nested loops to check all pairs
     */
    public static int[] twoSum(int[] nums, int target) {
        for (int i = 0; i < nums.length; i++) {
            for (int j = i + 1; j < nums.length; j++) {
                if (nums[i] + nums[j] == target) {
                    return new int[]{i, j};
                }
            }
        }
        return new int[]{-1, -1}; // No solution found
    }
    
    /**
     * Exercise 4: Two Sum (Optimized with HashMap)
     * Time Complexity: O(n)
     * Space Complexity: O(n)
     * 
     * Approach: Use HashMap to store complements
     */
    public static int[] twoSumOptimized(int[] nums, int target) {
        java.util.Map<Integer, Integer> map = new java.util.HashMap<>();
        
        for (int i = 0; i < nums.length; i++) {
            int complement = target - nums[i];
            if (map.containsKey(complement)) {
                return new int[]{map.get(complement), i};
            }
            map.put(nums[i], i);
        }
        
        return new int[]{-1, -1}; // No solution found
    }
    
    /**
     * Exercise 5: Generate Fibonacci Sequence
     * Time Complexity: O(n)
     * Space Complexity: O(n) for the result array
     * 
     * Approach: Iterative approach, build array step by step
     */
    public static int[] generateFibonacci(int n) {
        if (n <= 0) {
            return new int[0];
        }
        if (n == 1) {
            return new int[]{0};
        }
        
        int[] fib = new int[n];
        fib[0] = 0;
        fib[1] = 1;
        
        for (int i = 2; i < n; i++) {
            fib[i] = fib[i - 1] + fib[i - 2];
        }
        
        return fib;
    }
    
    /**
     * Exercise 6: Check Palindrome
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     * 
     * Approach: Use two pointers, skip non-alphanumeric characters
     */
    public static boolean isPalindrome(String s) {
        if (s == null || s.length() == 0) {
            return true;
        }
        
        int left = 0;
        int right = s.length() - 1;
        
        while (left < right) {
            // Skip non-alphanumeric characters from left
            while (left < right && !Character.isLetterOrDigit(s.charAt(left))) {
                left++;
            }
            
            // Skip non-alphanumeric characters from right
            while (left < right && !Character.isLetterOrDigit(s.charAt(right))) {
                right--;
            }
            
            // Compare characters (case-insensitive)
            if (Character.toLowerCase(s.charAt(left)) != 
                Character.toLowerCase(s.charAt(right))) {
                return false;
            }
            
            left++;
            right--;
        }
        
        return true;
    }
    
    /**
     * Exercise 7: Find Peak Element
     * Time Complexity: O(n) - can be optimized to O(log n) with binary search
     * Space Complexity: O(1)
     * 
     * Approach: Linear search for first peak
     */
    public static int findPeakElement(int[] nums) {
        if (nums.length == 1) {
            return 0;
        }
        
        // Check first element
        if (nums[0] >= nums[1]) {
            return 0;
        }
        
        // Check middle elements
        for (int i = 1; i < nums.length - 1; i++) {
            if (nums[i] >= nums[i - 1] && nums[i] >= nums[i + 1]) {
                return i;
            }
        }
        
        // Check last element
        if (nums[nums.length - 1] >= nums[nums.length - 2]) {
            return nums.length - 1;
        }
        
        return -1; // Should never reach here
    }
    
    /**
     * Exercise 8: Rotate Array
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     * 
     * Approach: Use array reversal technique
     */
    public static void rotateArray(int[] nums, int k) {
        if (nums.length == 0 || k == 0) {
            return;
        }
        
        int n = nums.length;
        k = k % n; // Handle k > array length
        
        // Step 1: Reverse entire array
        reverseArray(nums);
        
        // Step 2: Reverse first k elements
        reverseArray(nums, 0, k - 1);
        
        // Step 3: Reverse remaining elements
        reverseArray(nums, k, n - 1);
    }
    
    /**
     * Helper method to reverse array from start to end index
     */
    private static void reverseArray(int[] arr, int start, int end) {
        while (start < end) {
            int temp = arr[start];
            arr[start] = arr[end];
            arr[end] = temp;
            start++;
            end--;
        }
    }
    
    // ========== BONUS CHALLENGES ==========
    
    /**
     * Bonus Challenge 1: Maximum Subarray Sum (Kadane's Algorithm)
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     * 
     * Approach: Keep track of maximum sum ending at current position
     */
    public static int maxSubarraySum(int[] nums) {
        if (nums.length == 0) {
            return 0;
        }
        
        int maxSoFar = nums[0];
        int maxEndingHere = nums[0];
        
        for (int i = 1; i < nums.length; i++) {
            // Either extend existing subarray or start new one
            maxEndingHere = Math.max(nums[i], maxEndingHere + nums[i]);
            maxSoFar = Math.max(maxSoFar, maxEndingHere);
        }
        
        return maxSoFar;
    }
    
    /**
     * Bonus Challenge 2: Product of Array Except Self
     * Time Complexity: O(n)
     * Space Complexity: O(1) excluding output array
     * 
     * Approach: Two passes - left products then right products
     */
    public static int[] productExceptSelf(int[] nums) {
        int n = nums.length;
        int[] result = new int[n];
        
        // First pass: calculate left products
        result[0] = 1;
        for (int i = 1; i < n; i++) {
            result[i] = result[i - 1] * nums[i - 1];
        }
        
        // Second pass: multiply by right products
        int rightProduct = 1;
        for (int i = n - 1; i >= 0; i--) {
            result[i] *= rightProduct;
            rightProduct *= nums[i];
        }
        
        return result;
    }
    
    /**
     * Bonus Challenge 3: Container With Most Water
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     * 
     * Approach: Two pointers from both ends, move pointer with smaller height
     */
    public static int maxArea(int[] height) {
        int left = 0;
        int right = height.length - 1;
        int maxWater = 0;
        
        while (left < right) {
            // Calculate current area
            int currentArea = Math.min(height[left], height[right]) * (right - left);
            maxWater = Math.max(maxWater, currentArea);
            
            // Move pointer with smaller height
            if (height[left] < height[right]) {
                left++;
            } else {
                right--;
            }
        }
        
        return maxWater;
    }
    
    // ========== TESTING METHODS ==========
    
    public static void main(String[] args) {
        System.out.println("=== Foundation Exercise Solutions ===\n");
        
        // Test Exercise 1: Array Reversal
        System.out.println("Exercise 1: Array Reversal");
        int[] arr1 = {1, 2, 3, 4, 5};
        System.out.println("Before: " + java.util.Arrays.toString(arr1));
        reverseArray(arr1);
        System.out.println("After: " + java.util.Arrays.toString(arr1));
        System.out.println();
        
        // Test Exercise 2: Find Second Largest
        System.out.println("Exercise 2: Find Second Largest");
        int[] arr2 = {3, 7, 2, 9, 1};
        System.out.println("Array: " + java.util.Arrays.toString(arr2));
        System.out.println("Second largest: " + findSecondLargest(arr2));
        System.out.println();
        
        // Test Exercise 3: Remove Duplicates
        System.out.println("Exercise 3: Remove Duplicates");
        int[] arr3 = {1, 1, 2, 2, 3, 4, 4, 5};
        System.out.println("Before: " + java.util.Arrays.toString(arr3));
        int newLength = removeDuplicates(arr3);
        System.out.println("New length: " + newLength);
        System.out.println("After: " + java.util.Arrays.toString(arr3));
        System.out.println();
        
        // Test Exercise 4: Two Sum
        System.out.println("Exercise 4: Two Sum");
        int[] arr4 = {2, 7, 11, 15};
        int[] result4 = twoSum(arr4, 9);
        System.out.println("Array: " + java.util.Arrays.toString(arr4));
        System.out.println("Target: 9, Indices: " + java.util.Arrays.toString(result4));
        System.out.println();
        
        // Test Exercise 5: Fibonacci
        System.out.println("Exercise 5: Fibonacci");
        int[] fib = generateFibonacci(7);
        System.out.println("First 7 Fibonacci numbers: " + java.util.Arrays.toString(fib));
        System.out.println();
        
        // Test Exercise 6: Palindrome
        System.out.println("Exercise 6: Palindrome");
        String test1 = "racecar";
        String test2 = "A man, a plan, a canal: Panama";
        System.out.println("'" + test1 + "' is palindrome: " + isPalindrome(test1));
        System.out.println("'" + test2 + "' is palindrome: " + isPalindrome(test2));
        System.out.println();
        
        // Test Exercise 7: Peak Element
        System.out.println("Exercise 7: Peak Element");
        int[] arr7 = {1, 2, 3, 1};
        System.out.println("Array: " + java.util.Arrays.toString(arr7));
        System.out.println("Peak at index: " + findPeakElement(arr7));
        System.out.println();
        
        // Test Exercise 8: Rotate Array
        System.out.println("Exercise 8: Rotate Array");
        int[] arr8 = {1, 2, 3, 4, 5, 6, 7};
        System.out.println("Before rotation: " + java.util.Arrays.toString(arr8));
        rotateArray(arr8, 3);
        System.out.println("After rotating by 3: " + java.util.Arrays.toString(arr8));
        System.out.println();
        
        // Test Bonus Challenges
        System.out.println("=== Bonus Challenges ===");
        
        // Maximum Subarray Sum
        int[] bonus1 = {-2, 1, -3, 4, -1, 2, 1, -5, 4};
        System.out.println("Max subarray sum: " + maxSubarraySum(bonus1));
        
        // Product Except Self
        int[] bonus2 = {1, 2, 3, 4};
        System.out.println("Product except self: " + java.util.Arrays.toString(productExceptSelf(bonus2)));
        
        // Container With Most Water
        int[] bonus3 = {1, 8, 6, 2, 5, 4, 8, 3, 7};
        System.out.println("Max water area: " + maxArea(bonus3));
        
        System.out.println("\n=== Complexity Summary ===");
        System.out.println("Most solutions are O(n) time and O(1) space");
        System.out.println("This provides a solid foundation for more complex algorithms!");
    }
}
