/**
 * Control Structures Example - Foundation for DSA
 * 
 * This class demonstrates control structures (if-else, loops) that are
 * essential for implementing algorithms and data structures.
 * 
 * @author DSA Tutorial
 * @version 1.0
 */
public class ControlStructures {
    
    public static void main(String[] args) {
        System.out.println("=== Control Structures for DSA ===\n");
        
        // If-else statements
        demonstrateIfElse();
        
        // For loops
        demonstrateForLoops();
        
        // While loops
        demonstrateWhileLoops();
        
        // Nested loops (important for DSA)
        demonstrateNestedLoops();
    }
    
    /**
     * Demonstrates if-else statements with different conditions
     */
    public static void demonstrateIfElse() {
        System.out.println("=== If-Else Statements ===");
        
        int age = 18;
        
        // Simple if statement
        if (age >= 18) {
            System.out.println("You are an adult!");
        }
        
        // If-else statement
        if (age >= 18) {
            System.out.println("You can vote!");
        } else {
            System.out.println("You cannot vote yet.");
        }
        
        // Multiple conditions (else-if chain)
        if (age < 13) {
            System.out.println("Category: Child");
        } else if (age < 20) {
            System.out.println("Category: Teenager");
        } else if (age < 65) {
            System.out.println("Category: Adult");
        } else {
            System.out.println("Category: Senior");
        }
        
        // Logical operators
        int score = 85;
        if (score >= 80 && score < 90) {
            System.out.println("Grade: B (Good job!)");
        }
        
        if (score < 60 || score > 100) {
            System.out.println("Invalid score!");
        }
        
        System.out.println();
    }
    
    /**
     * Demonstrates different types of for loops
     */
    public static void demonstrateForLoops() {
        System.out.println("=== For Loops ===");
        
        // Basic for loop - counting from 1 to 5
        System.out.println("Counting from 1 to 5:");
        for (int i = 1; i <= 5; i++) {
            System.out.println("  Count: " + i);
        }
        
        // For loop with step - even numbers
        System.out.println("Even numbers from 2 to 10:");
        for (int i = 2; i <= 10; i += 2) {
            System.out.println("  Even: " + i);
        }
        
        // Reverse counting
        System.out.println("Countdown from 5 to 1:");
        for (int i = 5; i >= 1; i--) {
            System.out.println("  Countdown: " + i);
        }
        
        // For loop with multiple variables
        System.out.println("Multiple variables in for loop:");
        for (int i = 0, j = 10; i < 5; i++, j--) {
            System.out.println("  i=" + i + ", j=" + j);
        }
        
        System.out.println();
    }
    
    /**
     * Demonstrates while and do-while loops
     */
    public static void demonstrateWhileLoops() {
        System.out.println("=== While Loops ===");
        
        // While loop - continues while condition is true
        int count = 1;
        System.out.println("While loop example:");
        while (count <= 5) {
            System.out.println("  Count: " + count);
            count++; // Don't forget to increment!
        }
        
        // Do-while loop - executes at least once
        int number = 10;
        System.out.println("Do-while loop example:");
        do {
            System.out.println("  Number: " + number);
            number--;
        } while (number > 0);
        
        // While loop with break and continue
        System.out.println("While loop with break and continue:");
        int i = 1;
        while (i <= 10) {
            if (i == 3) {
                i++;
                continue; // Skip iteration
            }
            if (i == 8) {
                break; // Exit loop
            }
            System.out.println("  i: " + i);
            i++;
        }
        
        System.out.println();
    }
    
    /**
     * Demonstrates nested loops - very important for DSA
     */
    public static void demonstrateNestedLoops() {
        System.out.println("=== Nested Loops (Important for DSA) ===");
        
        // Nested for loops - O(n²) complexity
        System.out.println("Multiplication table (3x3):");
        for (int i = 1; i <= 3; i++) {
            for (int j = 1; j <= 3; j++) {
                System.out.print("  " + (i * j) + " ");
            }
            System.out.println(); // New line after each row
        }
        
        // Pattern printing - common in interviews
        System.out.println("Star pattern:");
        for (int i = 1; i <= 4; i++) {
            for (int j = 1; j <= i; j++) {
                System.out.print("* ");
            }
            System.out.println();
        }
        
        // Array traversal with nested loops
        int[][] matrix = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
        System.out.println("2D Array traversal:");
        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix[i].length; j++) {
                System.out.print(matrix[i][j] + " ");
            }
            System.out.println();
        }
        
        System.out.println();
    }
}
