/**
 * Advanced Array Operations
 * 
 * This class demonstrates advanced array manipulation techniques
 * commonly used in data structures and algorithms.
 * 
 * @author DSA Tutorial
 * @version 1.0
 */
import java.util.*;

public class AdvancedArrayOperations {
    
    /**
     * Move all zeros to the end while maintaining relative order
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     * 
     * Approach: Use two passes - first move non-zeros, then fill with zeros
     */
    public static void moveZerosToEnd(int[] nums) {
        int writeIndex = 0;
        
        // First pass: move all non-zero elements to front
        for (int i = 0; i < nums.length; i++) {
            if (nums[i] != 0) {
                nums[writeIndex++] = nums[i];
            }
        }
        
        // Second pass: fill remaining positions with zeros
        while (writeIndex < nums.length) {
            nums[writeIndex++] = 0;
        }
    }
    
    /**
     * Remove all instances of a value in-place
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     * 
     * Approach: Use write pointer to track position for next valid element
     */
    public static int removeElement(int[] nums, int val) {
        int writeIndex = 0;
        
        for (int i = 0; i < nums.length; i++) {
            if (nums[i] != val) {
                nums[writeIndex++] = nums[i];
            }
        }
        
        return writeIndex; // New length
    }
    
    /**
     * Partition array around a pivot (Dutch National Flag problem)
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     * 
     * Approach: Use three pointers to maintain three regions
     */
    public static void partitionAroundPivot(int[] nums, int pivot) {
        int low = 0, mid = 0, high = nums.length - 1;
        
        while (mid <= high) {
            if (nums[mid] < pivot) {
                swap(nums, low++, mid++);
            } else if (nums[mid] > pivot) {
                swap(nums, mid, high--);
            } else {
                mid++;
            }
        }
    }
    
    /**
     * Helper method to swap elements in array
     */
    private static void swap(int[] arr, int i, int j) {
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }
    
    /**
     * Find the majority element (appears more than n/2 times)
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     * 
     * Approach: Boyer-Moore Voting Algorithm
     */
    public static int majorityElement(int[] nums) {
        int candidate = nums[0];
        int count = 1;
        
        // Phase 1: Find candidate
        for (int i = 1; i < nums.length; i++) {
            if (count == 0) {
                candidate = nums[i];
                count = 1;
            } else if (nums[i] == candidate) {
                count++;
            } else {
                count--;
            }
        }
        
        // Phase 2: Verify candidate (optional if guaranteed to exist)
        count = 0;
        for (int num : nums) {
            if (num == candidate) {
                count++;
            }
        }
        
        return count > nums.length / 2 ? candidate : -1;
    }
    
    /**
     * Find all elements that appear more than n/3 times
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     * 
     * Approach: Extended Boyer-Moore Voting Algorithm
     */
    public static List<Integer> majorityElementII(int[] nums) {
        List<Integer> result = new ArrayList<>();
        if (nums.length == 0) return result;
        
        int candidate1 = 0, candidate2 = 0;
        int count1 = 0, count2 = 0;
        
        // Phase 1: Find candidates
        for (int num : nums) {
            if (num == candidate1) {
                count1++;
            } else if (num == candidate2) {
                count2++;
            } else if (count1 == 0) {
                candidate1 = num;
                count1 = 1;
            } else if (count2 == 0) {
                candidate2 = num;
                count2 = 1;
            } else {
                count1--;
                count2--;
            }
        }
        
        // Phase 2: Verify candidates
        count1 = count2 = 0;
        for (int num : nums) {
            if (num == candidate1) count1++;
            else if (num == candidate2) count2++;
        }
        
        if (count1 > nums.length / 3) result.add(candidate1);
        if (count2 > nums.length / 3) result.add(candidate2);
        
        return result;
    }
    
    /**
     * Find the missing number in array containing n distinct numbers from 0 to n
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     * 
     * Approach: Use XOR properties
     */
    public static int missingNumber(int[] nums) {
        int n = nums.length;
        int expectedXOR = 0;
        int actualXOR = 0;
        
        // XOR of numbers from 0 to n
        for (int i = 0; i <= n; i++) {
            expectedXOR ^= i;
        }
        
        // XOR of all numbers in array
        for (int num : nums) {
            actualXOR ^= num;
        }
        
        return expectedXOR ^ actualXOR;
    }
    
    /**
     * Find all numbers disappeared in an array (1 to n range)
     * Time Complexity: O(n)
     * Space Complexity: O(1) excluding output
     * 
     * Approach: Use array indices as hash map
     */
    public static List<Integer> findDisappearedNumbers(int[] nums) {
        List<Integer> result = new ArrayList<>();
        
        // Mark numbers as negative using their indices
        for (int i = 0; i < nums.length; i++) {
            int index = Math.abs(nums[i]) - 1;
            if (nums[index] > 0) {
                nums[index] = -nums[index];
            }
        }
        
        // Find positive numbers (indices of missing numbers)
        for (int i = 0; i < nums.length; i++) {
            if (nums[i] > 0) {
                result.add(i + 1);
            }
        }
        
        return result;
    }
    
    /**
     * Rotate array to the right by k steps
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     * 
     * Approach: Use array reversal technique
     */
    public static void rotateArray(int[] nums, int k) {
        if (nums.length == 0 || k == 0) return;
        
        int n = nums.length;
        k = k % n; // Handle k > array length
        
        // Step 1: Reverse entire array
        reverse(nums, 0, n - 1);
        
        // Step 2: Reverse first k elements
        reverse(nums, 0, k - 1);
        
        // Step 3: Reverse remaining elements
        reverse(nums, k, n - 1);
    }
    
    /**
     * Helper method to reverse array from start to end
     */
    private static void reverse(int[] nums, int start, int end) {
        while (start < end) {
            swap(nums, start++, end--);
        }
    }
    
    /**
     * Find the next permutation of array
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     * 
     * Approach: Find pivot, swap with next greater element, reverse suffix
     */
    public static void nextPermutation(int[] nums) {
        int i = nums.length - 2;
        
        // Step 1: Find the largest index i such that nums[i] < nums[i + 1]
        while (i >= 0 && nums[i] >= nums[i + 1]) {
            i--;
        }
        
        if (i >= 0) {
            // Step 2: Find the largest index j such that nums[i] < nums[j]
            int j = nums.length - 1;
            while (nums[j] <= nums[i]) {
                j--;
            }
            
            // Step 3: Swap nums[i] and nums[j]
            swap(nums, i, j);
        }
        
        // Step 4: Reverse the suffix starting at nums[i + 1]
        reverse(nums, i + 1, nums.length - 1);
    }
    
    public static void main(String[] args) {
        System.out.println("=== Advanced Array Operations ===\n");
        
        // Test moveZerosToEnd
        System.out.println("1. Move Zeros to End:");
        int[] arr1 = {0, 1, 0, 3, 12};
        System.out.println("Before: " + Arrays.toString(arr1));
        moveZerosToEnd(arr1);
        System.out.println("After: " + Arrays.toString(arr1));
        System.out.println();
        
        // Test removeElement
        System.out.println("2. Remove Element:");
        int[] arr2 = {3, 2, 2, 3};
        System.out.println("Before: " + Arrays.toString(arr2));
        int newLength = removeElement(arr2, 3);
        System.out.println("After removing 3: " + Arrays.toString(arr2));
        System.out.println("New length: " + newLength);
        System.out.println();
        
        // Test partitionAroundPivot
        System.out.println("3. Partition Around Pivot:");
        int[] arr3 = {2, 0, 2, 1, 1, 0};
        System.out.println("Before: " + Arrays.toString(arr3));
        partitionAroundPivot(arr3, 1);
        System.out.println("After partitioning around 1: " + Arrays.toString(arr3));
        System.out.println();
        
        // Test majorityElement
        System.out.println("4. Majority Element:");
        int[] arr4 = {3, 2, 3};
        System.out.println("Array: " + Arrays.toString(arr4));
        System.out.println("Majority element: " + majorityElement(arr4));
        System.out.println();
        
        // Test missingNumber
        System.out.println("5. Missing Number:");
        int[] arr5 = {3, 0, 1};
        System.out.println("Array: " + Arrays.toString(arr5));
        System.out.println("Missing number: " + missingNumber(arr5));
        System.out.println();
        
        // Test rotateArray
        System.out.println("6. Rotate Array:");
        int[] arr6 = {1, 2, 3, 4, 5, 6, 7};
        System.out.println("Before: " + Arrays.toString(arr6));
        rotateArray(arr6, 3);
        System.out.println("After rotating by 3: " + Arrays.toString(arr6));
        System.out.println();
        
        // Test nextPermutation
        System.out.println("7. Next Permutation:");
        int[] arr7 = {1, 2, 3};
        System.out.println("Before: " + Arrays.toString(arr7));
        nextPermutation(arr7);
        System.out.println("Next permutation: " + Arrays.toString(arr7));
        System.out.println();
        
        System.out.println("=== Key Takeaways ===");
        System.out.println("• Most operations can be done in O(n) time and O(1) space");
        System.out.println("• Two-pointer technique is very powerful");
        System.out.println("• Array indices can be used as hash maps");
        System.out.println("• Reversal technique is useful for rotation problems");
    }
}
