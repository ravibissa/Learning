/**
 * Sliding Window Algorithm Examples
 * 
 * This class demonstrates the sliding window technique for solving
 * problems involving subarrays and substrings efficiently.
 * 
 * @author DSA Tutorial
 * @version 1.0
 */
import java.util.*;

public class SlidingWindowAlgorithm {
    
    /**
     * Find maximum sum of subarray of size k (Fixed Window)
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     * 
     * Pattern: Fixed size sliding window
     */
    public static int maxSumSubarray(int[] nums, int k) {
        if (nums.length < k) return -1;
        
        // Calculate sum of first window
        int windowSum = 0;
        for (int i = 0; i < k; i++) {
            windowSum += nums[i];
        }
        
        int maxSum = windowSum;
        
        // Slide the window
        for (int i = k; i < nums.length; i++) {
            windowSum = windowSum - nums[i - k] + nums[i];
            maxSum = Math.max(maxSum, windowSum);
        }
        
        return maxSum;
    }
    
    /**
     * Find length of longest substring without repeating characters (Variable Window)
     * Time Complexity: O(n)
     * Space Complexity: O(min(m,n)) where m is charset size
     * 
     * Pattern: Variable size sliding window with HashSet
     */
    public static int lengthOfLongestSubstring(String s) {
        Set<Character> window = new HashSet<>();
        int left = 0, maxLength = 0;
        
        for (int right = 0; right < s.length(); right++) {
            // If character is already in window, shrink from left
            while (window.contains(s.charAt(right))) {
                window.remove(s.charAt(left++));
            }
            
            // Add current character to window
            window.add(s.charAt(right));
            maxLength = Math.max(maxLength, right - left + 1);
        }
        
        return maxLength;
    }
    
    /**
     * Find minimum window substring containing all characters of pattern
     * Time Complexity: O(n)
     * Space Complexity: O(n)
     * 
     * Pattern: Variable size sliding window with HashMap
     */
    public static String minWindow(String s, String t) {
        if (s.length() < t.length()) return "";
        
        Map<Character, Integer> targetCount = new HashMap<>();
        for (char c : t.toCharArray()) {
            targetCount.put(c, targetCount.getOrDefault(c, 0) + 1);
        }
        
        int left = 0, right = 0;
        int minStart = 0, minLength = Integer.MAX_VALUE;
        int required = targetCount.size();
        int formed = 0;
        
        Map<Character, Integer> windowCount = new HashMap<>();
        
        while (right < s.length()) {
            char c = s.charAt(right);
            windowCount.put(c, windowCount.getOrDefault(c, 0) + 1);
            
            if (targetCount.containsKey(c) && 
                windowCount.get(c).intValue() == targetCount.get(c).intValue()) {
                formed++;
            }
            
            while (left <= right && formed == required) {
                if (right - left + 1 < minLength) {
                    minLength = right - left + 1;
                    minStart = left;
                }
                
                char leftChar = s.charAt(left);
                windowCount.put(leftChar, windowCount.get(leftChar) - 1);
                if (targetCount.containsKey(leftChar) && 
                    windowCount.get(leftChar) < targetCount.get(leftChar)) {
                    formed--;
                }
                left++;
            }
            right++;
        }
        
        return minLength == Integer.MAX_VALUE ? "" : s.substring(minStart, minStart + minLength);
    }
    
    /**
     * Find all anagrams of pattern in string
     * Time Complexity: O(n)
     * Space Complexity: O(n)
     * 
     * Pattern: Fixed size sliding window with HashMap
     */
    public static List<Integer> findAnagrams(String s, String p) {
        List<Integer> result = new ArrayList<>();
        if (s.length() < p.length()) return result;
        
        Map<Character, Integer> patternCount = new HashMap<>();
        for (char c : p.toCharArray()) {
            patternCount.put(c, patternCount.getOrDefault(c, 0) + 1);
        }
        
        Map<Character, Integer> windowCount = new HashMap<>();
        int windowSize = p.length();
        
        // Initialize first window
        for (int i = 0; i < windowSize; i++) {
            char c = s.charAt(i);
            windowCount.put(c, windowCount.getOrDefault(c, 0) + 1);
        }
        
        if (windowCount.equals(patternCount)) {
            result.add(0);
        }
        
        // Slide the window
        for (int i = windowSize; i < s.length(); i++) {
            // Remove leftmost character
            char leftChar = s.charAt(i - windowSize);
            windowCount.put(leftChar, windowCount.get(leftChar) - 1);
            if (windowCount.get(leftChar) == 0) {
                windowCount.remove(leftChar);
            }
            
            // Add new character
            char rightChar = s.charAt(i);
            windowCount.put(rightChar, windowCount.getOrDefault(rightChar, 0) + 1);
            
            // Check if current window is an anagram
            if (windowCount.equals(patternCount)) {
                result.add(i - windowSize + 1);
            }
        }
        
        return result;
    }
    
    /**
     * Find maximum number of vowels in substring of length k
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     * 
     * Pattern: Fixed size sliding window
     */
    public static int maxVowels(String s, int k) {
        Set<Character> vowels = new HashSet<>(Arrays.asList('a', 'e', 'i', 'o', 'u'));
        
        // Count vowels in first window
        int vowelCount = 0;
        for (int i = 0; i < k; i++) {
            if (vowels.contains(s.charAt(i))) {
                vowelCount++;
            }
        }
        
        int maxVowels = vowelCount;
        
        // Slide the window
        for (int i = k; i < s.length(); i++) {
            // Remove leftmost character
            if (vowels.contains(s.charAt(i - k))) {
                vowelCount--;
            }
            
            // Add new character
            if (vowels.contains(s.charAt(i))) {
                vowelCount++;
            }
            
            maxVowels = Math.max(maxVowels, vowelCount);
        }
        
        return maxVowels;
    }
    
    /**
     * Find longest substring with at most k distinct characters
     * Time Complexity: O(n)
     * Space Complexity: O(k)
     * 
     * Pattern: Variable size sliding window with HashMap
     */
    public static int lengthOfLongestSubstringKDistinct(String s, int k) {
        if (k == 0) return 0;
        
        Map<Character, Integer> charCount = new HashMap<>();
        int left = 0, maxLength = 0;
        
        for (int right = 0; right < s.length(); right++) {
            char c = s.charAt(right);
            charCount.put(c, charCount.getOrDefault(c, 0) + 1);
            
            // Shrink window if more than k distinct characters
            while (charCount.size() > k) {
                char leftChar = s.charAt(left);
                charCount.put(leftChar, charCount.get(leftChar) - 1);
                if (charCount.get(leftChar) == 0) {
                    charCount.remove(leftChar);
                }
                left++;
            }
            
            maxLength = Math.max(maxLength, right - left + 1);
        }
        
        return maxLength;
    }
    
    /**
     * Find subarray with sum equal to target (contains negative numbers)
     * Time Complexity: O(n)
     * Space Complexity: O(n)
     * 
     * Pattern: Prefix sum with HashMap
     */
    public static int subarraySum(int[] nums, int k) {
        Map<Integer, Integer> prefixSumCount = new HashMap<>();
        prefixSumCount.put(0, 1); // Empty subarray has sum 0
        
        int count = 0, prefixSum = 0;
        
        for (int num : nums) {
            prefixSum += num;
            
            // If (prefixSum - k) exists, then there's a subarray with sum k
            if (prefixSumCount.containsKey(prefixSum - k)) {
                count += prefixSumCount.get(prefixSum - k);
            }
            
            prefixSumCount.put(prefixSum, prefixSumCount.getOrDefault(prefixSum, 0) + 1);
        }
        
        return count;
    }
    
    /**
     * Find longest subarray with sum at most k (non-negative numbers)
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     * 
     * Pattern: Variable size sliding window
     */
    public static int maxSubarraySumAtMostK(int[] nums, int k) {
        int left = 0, maxLength = 0, currentSum = 0;
        
        for (int right = 0; right < nums.length; right++) {
            currentSum += nums[right];
            
            // Shrink window if sum exceeds k
            while (currentSum > k) {
                currentSum -= nums[left++];
            }
            
            maxLength = Math.max(maxLength, right - left + 1);
        }
        
        return maxLength;
    }
    
    /**
     * Find minimum size subarray with sum at least target
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     * 
     * Pattern: Variable size sliding window
     */
    public static int minSubArrayLen(int target, int[] nums) {
        int left = 0, minLength = Integer.MAX_VALUE, currentSum = 0;
        
        for (int right = 0; right < nums.length; right++) {
            currentSum += nums[right];
            
            // Shrink window while sum is at least target
            while (currentSum >= target) {
                minLength = Math.min(minLength, right - left + 1);
                currentSum -= nums[left++];
            }
        }
        
        return minLength == Integer.MAX_VALUE ? 0 : minLength;
    }
    
    public static void main(String[] args) {
        System.out.println("=== Sliding Window Algorithm Examples ===\n");
        
        // Test maxSumSubarray
        System.out.println("1. Maximum Sum Subarray of Size K:");
        int[] arr1 = {1, 4, 2, 10, 23, 3, 1, 0, 20};
        int k1 = 4;
        System.out.println("Array: " + Arrays.toString(arr1) + ", K: " + k1);
        System.out.println("Max sum: " + maxSumSubarray(arr1, k1));
        System.out.println();
        
        // Test lengthOfLongestSubstring
        System.out.println("2. Longest Substring Without Repeating Characters:");
        String s1 = "abcabcbb";
        System.out.println("String: '" + s1 + "'");
        System.out.println("Length: " + lengthOfLongestSubstring(s1));
        System.out.println();
        
        // Test minWindow
        System.out.println("3. Minimum Window Substring:");
        String s2 = "ADOBECODEBANC";
        String t2 = "ABC";
        System.out.println("String: '" + s2 + "', Pattern: '" + t2 + "'");
        System.out.println("Min window: '" + minWindow(s2, t2) + "'");
        System.out.println();
        
        // Test findAnagrams
        System.out.println("4. Find All Anagrams:");
        String s3 = "cbaebabacd";
        String p3 = "abc";
        System.out.println("String: '" + s3 + "', Pattern: '" + p3 + "'");
        System.out.println("Anagram indices: " + findAnagrams(s3, p3));
        System.out.println();
        
        // Test maxVowels
        System.out.println("5. Maximum Number of Vowels in Substring:");
        String s4 = "abciiidef";
        int k4 = 3;
        System.out.println("String: '" + s4 + "', K: " + k4);
        System.out.println("Max vowels: " + maxVowels(s4, k4));
        System.out.println();
        
        // Test lengthOfLongestSubstringKDistinct
        System.out.println("6. Longest Substring with K Distinct Characters:");
        String s5 = "eceba";
        int k5 = 2;
        System.out.println("String: '" + s5 + "', K: " + k5);
        System.out.println("Length: " + lengthOfLongestSubstringKDistinct(s5, k5));
        System.out.println();
        
        // Test subarraySum
        System.out.println("7. Subarray Sum Equals K:");
        int[] arr2 = {1, 1, 1};
        int k6 = 2;
        System.out.println("Array: " + Arrays.toString(arr2) + ", K: " + k6);
        System.out.println("Count: " + subarraySum(arr2, k6));
        System.out.println();
        
        // Test minSubArrayLen
        System.out.println("8. Minimum Size Subarray Sum:");
        int[] arr3 = {2, 3, 1, 2, 4, 3};
        int target = 7;
        System.out.println("Array: " + Arrays.toString(arr3) + ", Target: " + target);
        System.out.println("Min length: " + minSubArrayLen(target, arr3));
        System.out.println();
        
        System.out.println("=== Sliding Window Patterns Summary ===");
        System.out.println("1. Fixed Window: Max sum, Vowel count, Anagrams");
        System.out.println("2. Variable Window: Longest substring, Min window");
        System.out.println("3. Two Pointers: Container water, 3Sum");
        System.out.println("4. Prefix Sum: Subarray sum equals K");
        System.out.println("5. Hash Map: Character frequency, Pattern matching");
    }
}
