/**
 * Arrays and Memory Example - Foundation for DSA
 * 
 * This class demonstrates array operations and memory concepts
 * that are crucial for understanding data structures.
 * 
 * @author DSA Tutorial
 * @version 1.0
 */
public class ArraysExample {
    
    public static void main(String[] args) {
        System.out.println("=== Arrays and Memory for DSA ===\n");
        
        // Basic array operations
        demonstrateBasicArrays();
        
        // Array traversal methods
        demonstrateArrayTraversal();
        
        // Memory concepts
        demonstrateMemoryConcepts();
        
        // Common array algorithms
        demonstrateArrayAlgorithms();
    }
    
    /**
     * Demonstrates basic array creation and manipulation
     */
    public static void demonstrateBasicArrays() {
        System.out.println("=== Basic Array Operations ===");
        
        // Creating arrays
        int[] numbers = new int[5];        // Array of 5 integers (all initialized to 0)
        String[] names = {"Alice", "Bob", "Charlie"}; // Array with initial values
        
        // Accessing and modifying array elements (0-based indexing)
        numbers[0] = 10;
        numbers[1] = 20;
        numbers[2] = 30;
        numbers[3] = 40;
        numbers[4] = 50;
        
        // Displaying array elements
        System.out.println("Numbers array:");
        for (int i = 0; i < numbers.length; i++) {
            System.out.println("  Index " + i + ": " + numbers[i]);
        }
        
        System.out.println("Names array:");
        for (int i = 0; i < names.length; i++) {
            System.out.println("  Index " + i + ": " + names[i]);
        }
        
        // Array length property
        System.out.println("Numbers array length: " + numbers.length);
        System.out.println("Names array length: " + names.length);
        
        System.out.println();
    }
    
    /**
     * Demonstrates different ways to traverse arrays
     */
    public static void demonstrateArrayTraversal() {
        System.out.println("=== Array Traversal Methods ===");
        
        int[] numbers = {1, 2, 3, 4, 5};
        
        // Method 1: Traditional for loop with index
        System.out.println("Traditional for loop:");
        for (int i = 0; i < numbers.length; i++) {
            System.out.print(numbers[i] + " ");
        }
        System.out.println();
        
        // Method 2: Enhanced for loop (for-each loop)
        System.out.println("Enhanced for loop (for-each):");
        for (int num : numbers) {
            System.out.print(num + " ");
        }
        System.out.println();
        
        // Method 3: While loop
        System.out.println("While loop:");
        int index = 0;
        while (index < numbers.length) {
            System.out.print(numbers[index] + " ");
            index++;
        }
        System.out.println();
        
        // Method 4: Reverse traversal
        System.out.println("Reverse traversal:");
        for (int i = numbers.length - 1; i >= 0; i--) {
            System.out.print(numbers[i] + " ");
        }
        System.out.println();
        
        System.out.println();
    }
    
    /**
     * Demonstrates memory concepts important for DSA
     */
    public static void demonstrateMemoryConcepts() {
        System.out.println("=== Memory Concepts ===");
        
        // Stack vs Heap
        int primitive = 42;           // Stored on stack
        int[] array = new int[1000];  // Array object on heap, reference on stack
        
        System.out.println("Primitive variable (stack): " + primitive);
        System.out.println("Array reference (stack): " + array);
        System.out.println("Array length (heap): " + array.length);
        
        // Array copying - important for DSA
        int[] original = {1, 2, 3, 4, 5};
        System.out.println("Original array: " + java.util.Arrays.toString(original));
        
        // Method 1: Manual copying
        int[] copy1 = new int[original.length];
        for (int i = 0; i < original.length; i++) {
            copy1[i] = original[i];
        }
        System.out.println("Manual copy: " + java.util.Arrays.toString(copy1));
        
        // Method 2: Using System.arraycopy (more efficient)
        int[] copy2 = new int[original.length];
        System.arraycopy(original, 0, copy2, 0, original.length);
        System.out.println("System.arraycopy: " + java.util.Arrays.toString(copy2));
        
        // Method 3: Using Arrays.copyOf (Java 6+)
        int[] copy3 = java.util.Arrays.copyOf(original, original.length);
        System.out.println("Arrays.copyOf: " + java.util.Arrays.toString(copy3));
        
        // Demonstrating reference vs value
        int[] arr1 = {1, 2, 3};
        int[] arr2 = arr1; // arr2 points to same array as arr1
        arr2[0] = 999;     // This changes arr1[0] too!
        
        System.out.println("arr1: " + java.util.Arrays.toString(arr1));
        System.out.println("arr2: " + java.util.Arrays.toString(arr2));
        System.out.println("arr1 == arr2: " + (arr1 == arr2)); // Same reference
        
        System.out.println();
    }
    
    /**
     * Demonstrates common array algorithms used in DSA
     */
    public static void demonstrateArrayAlgorithms() {
        System.out.println("=== Common Array Algorithms ===");
        
        int[] numbers = {3, 7, 2, 9, 1, 5};
        System.out.println("Array: " + java.util.Arrays.toString(numbers));
        
        // Find sum
        int sum = 0;
        for (int num : numbers) {
            sum += num;
        }
        System.out.println("Sum: " + sum);
        
        // Find average
        double average = (double) sum / numbers.length;
        System.out.println("Average: " + average);
        
        // Find maximum
        int max = numbers[0];
        for (int i = 1; i < numbers.length; i++) {
            if (numbers[i] > max) {
                max = numbers[i];
            }
        }
        System.out.println("Maximum: " + max);
        
        // Find minimum
        int min = numbers[0];
        for (int i = 1; i < numbers.length; i++) {
            if (numbers[i] < min) {
                min = numbers[i];
            }
        }
        System.out.println("Minimum: " + min);
        
        // Linear search
        int target = 9;
        int index = -1;
        for (int i = 0; i < numbers.length; i++) {
            if (numbers[i] == target) {
                index = i;
                break;
            }
        }
        if (index != -1) {
            System.out.println("Found " + target + " at index " + index);
        } else {
            System.out.println(target + " not found");
        }
        
        // Count occurrences
        int countTarget = 2;
        int count = 0;
        for (int num : numbers) {
            if (num == countTarget) {
                count++;
            }
        }
        System.out.println(countTarget + " appears " + count + " times");
        
        System.out.println();
    }
}
