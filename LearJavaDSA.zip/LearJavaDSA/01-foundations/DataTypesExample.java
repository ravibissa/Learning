/**
 * Data Types Example - Foundation for DSA
 * 
 * This class demonstrates Java primitive data types and their usage
 * in data structures and algorithms.
 * 
 * @author DSA Tutorial
 * @version 1.0
 */
public class DataTypesExample {
    
    public static void main(String[] args) {
        System.out.println("=== Java Data Types for DSA ===\n");
        
        // Integer types - Choose based on range needed
        byte smallNumber = 127;        // 8-bit: -128 to 127
        short mediumNumber = 32000;    // 16-bit: -32,768 to 32,767
        int number = 1000000;          // 32-bit: -2^31 to 2^31-1 (most common)
        long bigNumber = 1000000000L;  // 64-bit: -2^63 to 2^63-1
        
        // Floating point types
        float decimal = 3.14f;         // 32-bit floating point
        double preciseDecimal = 3.14159265359; // 64-bit floating point (most common)
        
        // Character and boolean
        char letter = 'A';             // 16-bit Unicode character
        boolean isTrue = true;         // true or false
        
        // Display all values
        System.out.println("Integer Types:");
        System.out.println("  byte: " + smallNumber + " (8-bit)");
        System.out.println("  short: " + mediumNumber + " (16-bit)");
        System.out.println("  int: " + number + " (32-bit) - Most common for DSA");
        System.out.println("  long: " + bigNumber + " (64-bit)");
        
        System.out.println("\nFloating Point Types:");
        System.out.println("  float: " + decimal + " (32-bit)");
        System.out.println("  double: " + preciseDecimal + " (64-bit) - Most common");
        
        System.out.println("\nOther Types:");
        System.out.println("  char: " + letter + " (16-bit Unicode)");
        System.out.println("  boolean: " + isTrue + " (true/false)");
        
        // Demonstrate type casting
        System.out.println("\n=== Type Casting ===");
        int intValue = 100;
        double doubleValue = intValue; // Implicit casting (int to double)
        int backToInt = (int) doubleValue; // Explicit casting (double to int)
        
        System.out.println("int: " + intValue);
        System.out.println("int to double: " + doubleValue);
        System.out.println("double back to int: " + backToInt);
        
        // Memory considerations for DSA
        System.out.println("\n=== Memory Considerations ===");
        System.out.println("For large datasets, choose appropriate data types:");
        System.out.println("- Use 'int' for most DSA problems (32-bit)");
        System.out.println("- Use 'long' for very large numbers");
        System.out.println("- Use 'double' for decimal calculations");
        System.out.println("- Use 'boolean' for flags and conditions");
    }
}
