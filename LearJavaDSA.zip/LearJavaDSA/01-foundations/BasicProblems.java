/**
 * Basic Problem Solving Examples - Foundation for DSA
 * 
 * This class contains fundamental problems that build the foundation
 * for more complex data structures and algorithms.
 * 
 * @author DSA Tutorial
 * @version 1.0
 */
public class BasicProblems {
    
    /**
     * Problem 1: Find the sum of all elements in an array
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     * 
     * @param arr array of integers
     * @return sum of all elements
     */
    public static int sumArray(int[] arr) {
        int sum = 0;
        for (int num : arr) {
            sum += num;
        }
        return sum;
    }
    
    /**
     * Problem 2: Find the maximum element in an array
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     * 
     * @param arr array of integers
     * @return maximum element, or -1 if array is empty
     */
    public static int findMax(int[] arr) {
        if (arr.length == 0) {
            return -1; // Handle edge case
        }
        
        int max = arr[0]; // Assume first element is maximum
        for (int i = 1; i < arr.length; i++) {
            if (arr[i] > max) {
                max = arr[i];
            }
        }
        return max;
    }
    
    /**
     * Problem 3: Find the minimum element in an array
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     * 
     * @param arr array of integers
     * @return minimum element, or -1 if array is empty
     */
    public static int findMin(int[] arr) {
        if (arr.length == 0) {
            return -1; // Handle edge case
        }
        
        int min = arr[0]; // Assume first element is minimum
        for (int i = 1; i < arr.length; i++) {
            if (arr[i] < min) {
                min = arr[i];
            }
        }
        return min;
    }
    
    /**
     * Problem 4: Linear search - find index of target element
     * Time Complexity: O(n) worst case, O(1) best case
     * Space Complexity: O(1)
     * 
     * @param arr array to search in
     * @param target element to find
     * @return index of target, or -1 if not found
     */
    public static int linearSearch(int[] arr, int target) {
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == target) {
                return i; // Return index where found
            }
        }
        return -1; // Not found
    }
    
    /**
     * Problem 5: Count occurrences of a target element
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     * 
     * @param arr array to search in
     * @param target element to count
     * @return number of occurrences
     */
    public static int countOccurrences(int[] arr, int target) {
        int count = 0;
        for (int num : arr) {
            if (num == target) {
                count++;
            }
        }
        return count;
    }
    
    /**
     * Problem 6: Check if array contains duplicate elements
     * Time Complexity: O(n²) - can be optimized with HashSet to O(n)
     * Space Complexity: O(1) - can be optimized with HashSet to O(n)
     * 
     * @param arr array to check
     * @return true if duplicates exist, false otherwise
     */
    public static boolean hasDuplicates(int[] arr) {
        for (int i = 0; i < arr.length; i++) {
            for (int j = i + 1; j < arr.length; j++) {
                if (arr[i] == arr[j]) {
                    return true;
                }
            }
        }
        return false;
    }
    
    /**
     * Problem 7: Find the second largest element
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     * 
     * @param arr array of integers
     * @return second largest element, or -1 if not found
     */
    public static int findSecondLargest(int[] arr) {
        if (arr.length < 2) {
            return -1; // Need at least 2 elements
        }
        
        int largest = Integer.MIN_VALUE;
        int secondLargest = Integer.MIN_VALUE;
        
        for (int num : arr) {
            if (num > largest) {
                secondLargest = largest;
                largest = num;
            } else if (num > secondLargest && num != largest) {
                secondLargest = num;
            }
        }
        
        return secondLargest == Integer.MIN_VALUE ? -1 : secondLargest;
    }
    
    /**
     * Problem 8: Reverse an array in-place
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     * 
     * @param arr array to reverse
     */
    public static void reverseArray(int[] arr) {
        int left = 0;
        int right = arr.length - 1;
        
        while (left < right) {
            // Swap elements
            int temp = arr[left];
            arr[left] = arr[right];
            arr[right] = temp;
            
            // Move pointers
            left++;
            right--;
        }
    }
    
    /**
     * Problem 9: Check if array is sorted in ascending order
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     * 
     * @param arr array to check
     * @return true if sorted, false otherwise
     */
    public static boolean isSorted(int[] arr) {
        for (int i = 1; i < arr.length; i++) {
            if (arr[i] < arr[i - 1]) {
                return false;
            }
        }
        return true;
    }
    
    /**
     * Problem 10: Find the missing number in array 1 to n
     * Assumes array contains numbers from 1 to n with one missing
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     * 
     * @param arr array with one missing number
     * @param n expected maximum number
     * @return missing number
     */
    public static int findMissingNumber(int[] arr, int n) {
        int expectedSum = n * (n + 1) / 2; // Sum of 1 to n
        int actualSum = 0;
        
        for (int num : arr) {
            actualSum += num;
        }
        
        return expectedSum - actualSum;
    }
    
    public static void main(String[] args) {
        System.out.println("=== Basic Problem Solving for DSA ===\n");
        
        // Test data
        int[] numbers = {3, 7, 2, 9, 1, 5, 7};
        int[] sortedNumbers = {1, 2, 3, 4, 5};
        int[] missingNumberArray = {1, 2, 4, 5}; // Missing 3
        
        System.out.println("Test array: " + java.util.Arrays.toString(numbers));
        System.out.println("Sorted array: " + java.util.Arrays.toString(sortedNumbers));
        System.out.println("Missing number array: " + java.util.Arrays.toString(missingNumberArray));
        System.out.println();
        
        // Test all methods
        System.out.println("1. Sum of array: " + sumArray(numbers));
        System.out.println("2. Maximum element: " + findMax(numbers));
        System.out.println("3. Minimum element: " + findMin(numbers));
        System.out.println("4. Linear search for 9: " + linearSearch(numbers, 9));
        System.out.println("5. Count occurrences of 7: " + countOccurrences(numbers, 7));
        System.out.println("6. Has duplicates: " + hasDuplicates(numbers));
        System.out.println("7. Second largest: " + findSecondLargest(numbers));
        
        // Test array reversal
        int[] copyForReverse = numbers.clone();
        System.out.println("8. Before reverse: " + java.util.Arrays.toString(copyForReverse));
        reverseArray(copyForReverse);
        System.out.println("   After reverse: " + java.util.Arrays.toString(copyForReverse));
        
        System.out.println("9. Is sorted: " + isSorted(sortedNumbers));
        System.out.println("10. Missing number: " + findMissingNumber(missingNumberArray, 5));
        
        System.out.println("\n=== Complexity Analysis ===");
        System.out.println("Most of these algorithms have O(n) time complexity");
        System.out.println("They use O(1) extra space (except for array copying)");
        System.out.println("These are the building blocks for more complex algorithms!");
    }
}
