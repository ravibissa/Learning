/**
 * Methods and Functions Example - Foundation for DSA
 * 
 * This class demonstrates how to create and use methods, which are
 * essential for organizing code and implementing algorithms.
 * 
 * @author DSA Tutorial
 * @version 1.0
 */
public class MethodsExample {
    
    /**
     * Method that takes no parameters and returns nothing
     * Good for displaying information or performing actions
     */
    public static void sayHello() {
        System.out.println("Hello, World!");
    }
    
    /**
     * Method that takes parameters and returns a value
     * This is the most common type of method in DSA
     * 
     * @param a first number
     * @param b second number
     * @return sum of a and b
     */
    public static int add(int a, int b) {
        return a + b;
    }
    
    /**
     * Method that finds the maximum value in an array
     * Demonstrates array processing - very common in DSA
     * 
     * @param numbers array of integers
     * @return maximum value in the array, or -1 if array is empty
     */
    public static int findMax(int[] numbers) {
        // Handle edge case - empty array
        if (numbers.length == 0) {
            return -1; // Error case
        }
        
        int max = numbers[0]; // Assume first element is maximum
        for (int i = 1; i < numbers.length; i++) {
            if (numbers[i] > max) {
                max = numbers[i];
            }
        }
        return max;
    }
    
    /**
     * Method with multiple return statements
     * Demonstrates early returns - good for readability
     * 
     * @param score student's score
     * @return letter grade
     */
    public static String getGrade(int score) {
        if (score >= 90) return "A";
        if (score >= 80) return "B";
        if (score >= 70) return "C";
        if (score >= 60) return "D";
        return "F";
    }
    
    /**
     * Method that demonstrates method overloading
     * Same method name, different parameters
     */
    public static int multiply(int a, int b) {
        return a * b;
    }
    
    public static double multiply(double a, double b) {
        return a * b;
    }
    
    public static int multiply(int a, int b, int c) {
        return a * b * c;
    }
    
    /**
     * Method that demonstrates recursion (calling itself)
     * Important concept for DSA - many algorithms use recursion
     * 
     * @param n number to calculate factorial for
     * @return factorial of n
     */
    public static int factorial(int n) {
        // Base case - stops the recursion
        if (n <= 1) {
            return 1;
        }
        // Recursive case - calls itself with smaller input
        return n * factorial(n - 1);
    }
    
    /**
     * Method that demonstrates array manipulation
     * Common pattern in DSA problems
     * 
     * @param arr array to reverse
     * @return new array with elements in reverse order
     */
    public static int[] reverseArray(int[] arr) {
        int[] reversed = new int[arr.length];
        for (int i = 0; i < arr.length; i++) {
            reversed[i] = arr[arr.length - 1 - i];
        }
        return reversed;
    }
    
    /**
     * Method that demonstrates string manipulation
     * 
     * @param str string to check
     * @return true if string is palindrome, false otherwise
     */
    public static boolean isPalindrome(String str) {
        int left = 0;
        int right = str.length() - 1;
        
        while (left < right) {
            if (str.charAt(left) != str.charAt(right)) {
                return false;
            }
            left++;
            right--;
        }
        return true;
    }
    
    public static void main(String[] args) {
        System.out.println("=== Methods and Functions for DSA ===\n");
        
        // Test basic methods
        sayHello();
        
        int sum = add(5, 3);
        System.out.println("5 + 3 = " + sum);
        
        // Test array methods
        int[] numbers = {3, 7, 2, 9, 1};
        int maxNumber = findMax(numbers);
        System.out.println("Maximum number in " + java.util.Arrays.toString(numbers) + 
                          " is: " + maxNumber);
        
        // Test grade method
        String grade = getGrade(85);
        System.out.println("Grade for score 85: " + grade);
        
        // Test method overloading
        System.out.println("Multiply integers: " + multiply(3, 4));
        System.out.println("Multiply doubles: " + multiply(3.5, 4.2));
        System.out.println("Multiply three integers: " + multiply(2, 3, 4));
        
        // Test recursion
        int fact = factorial(5);
        System.out.println("Factorial of 5: " + fact);
        
        // Test array reversal
        int[] original = {1, 2, 3, 4, 5};
        int[] reversed = reverseArray(original);
        System.out.println("Original: " + java.util.Arrays.toString(original));
        System.out.println("Reversed: " + java.util.Arrays.toString(reversed));
        
        // Test palindrome check
        String testString = "racecar";
        boolean isPal = isPalindrome(testString);
        System.out.println("Is '" + testString + "' a palindrome? " + isPal);
        
        System.out.println("\n=== Method Design Tips for DSA ===");
        System.out.println("1. Always handle edge cases (empty arrays, null values)");
        System.out.println("2. Use meaningful parameter and return type names");
        System.out.println("3. Document your methods with comments");
        System.out.println("4. Keep methods focused on a single task");
        System.out.println("5. Consider time and space complexity");
    }
}
