# Arrays and Strings
## Advanced Array Operations and String Manipulation

Now that you've mastered the basics, let's dive deeper into arrays and strings - the building blocks of most data structures and algorithms.

## 🎯 Learning Objectives
By the end of this section, you will:
- Master advanced array manipulation techniques
- Understand string processing algorithms
- Learn two-pointer and sliding window techniques
- Implement common string algorithms
- Be ready for linked lists and other data structures

## 📚 Table of Contents
1. [Advanced Array Operations](#advanced-array-operations)
2. [String Fundamentals](#string-fundamentals)
3. [Two-Pointer Technique](#two-pointer-technique)
4. [Sliding Window Algorithm](#sliding-window-algorithm)
5. [String Algorithms](#string-algorithms)
6. [Exercises](#exercises)

---

## Advanced Array Operations

### Array Manipulation Patterns

#### Pattern 1: In-Place Operations
Many problems require modifying arrays without extra space:

```java
public class InPlaceOperations {
    
    /**
     * Move all zeros to the end while maintaining relative order
     * Time: O(n), Space: O(1)
     */
    public static void moveZerosToEnd(int[] nums) {
        int writeIndex = 0;
        
        // First pass: move all non-zero elements to front
        for (int i = 0; i < nums.length; i++) {
            if (nums[i] != 0) {
                nums[writeIndex++] = nums[i];
            }
        }
        
        // Second pass: fill remaining positions with zeros
        while (writeIndex < nums.length) {
            nums[writeIndex++] = 0;
        }
    }
    
    /**
     * Remove all instances of a value in-place
     * Time: O(n), Space: O(1)
     */
    public static int removeElement(int[] nums, int val) {
        int writeIndex = 0;
        
        for (int i = 0; i < nums.length; i++) {
            if (nums[i] != val) {
                nums[writeIndex++] = nums[i];
            }
        }
        
        return writeIndex; // New length
    }
}
```

#### Pattern 2: Array Partitioning
Dividing arrays based on conditions:

```java
public class ArrayPartitioning {
    
    /**
     * Partition array around a pivot (Dutch National Flag problem)
     * Time: O(n), Space: O(1)
     */
    public static void partitionAroundPivot(int[] nums, int pivot) {
        int low = 0, mid = 0, high = nums.length - 1;
        
        while (mid <= high) {
            if (nums[mid] < pivot) {
                swap(nums, low++, mid++);
            } else if (nums[mid] > pivot) {
                swap(nums, mid, high--);
            } else {
                mid++;
            }
        }
    }
    
    private static void swap(int[] arr, int i, int j) {
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }
}
```

---

## String Fundamentals

### String vs StringBuilder vs StringBuffer

Understanding when to use each:

```java
public class StringComparison {
    
    public static void demonstrateStringTypes() {
        // String - Immutable, thread-safe
        String str1 = "Hello";
        str1 += " World"; // Creates new String object
        
        // StringBuilder - Mutable, not thread-safe, faster
        StringBuilder sb = new StringBuilder();
        sb.append("Hello").append(" World");
        
        // StringBuffer - Mutable, thread-safe, slower than StringBuilder
        StringBuffer sbf = new StringBuffer();
        sbf.append("Hello").append(" World");
        
        System.out.println("String: " + str1);
        System.out.println("StringBuilder: " + sb.toString());
        System.out.println("StringBuffer: " + sbf.toString());
    }
    
    /**
     * When to use each:
     * - String: When you don't need to modify the string
     * - StringBuilder: When you need to modify strings frequently (single-threaded)
     * - StringBuffer: When you need thread safety
     */
}
```

### Common String Operations

```java
public class StringOperations {
    
    /**
     * Check if two strings are anagrams
     * Time: O(n), Space: O(1) - assuming fixed character set
     */
    public static boolean areAnagrams(String s1, String s2) {
        if (s1.length() != s2.length()) {
            return false;
        }
        
        int[] charCount = new int[26]; // Assuming lowercase letters only
        
        // Count characters in first string
        for (char c : s1.toCharArray()) {
            charCount[c - 'a']++;
        }
        
        // Decrease count for characters in second string
        for (char c : s2.toCharArray()) {
            charCount[c - 'a']--;
            if (charCount[c - 'a'] < 0) {
                return false;
            }
        }
        
        return true;
    }
    
    /**
     * Find the first non-repeating character
     * Time: O(n), Space: O(1)
     */
    public static char firstNonRepeatingChar(String s) {
        int[] charCount = new int[26];
        
        // Count all characters
        for (char c : s.toCharArray()) {
            charCount[c - 'a']++;
        }
        
        // Find first character with count 1
        for (char c : s.toCharArray()) {
            if (charCount[c - 'a'] == 1) {
                return c;
            }
        }
        
        return '\0'; // No non-repeating character found
    }
}
```

---

## Two-Pointer Technique

The two-pointer technique is one of the most powerful patterns in DSA. It's used to solve many array and string problems efficiently.

### Basic Two-Pointer Patterns

#### Pattern 1: Opposite Ends
```java
public class TwoPointerOppositeEnds {
    
    /**
     * Check if string is palindrome
     * Time: O(n), Space: O(1)
     */
    public static boolean isPalindrome(String s) {
        int left = 0, right = s.length() - 1;
        
        while (left < right) {
            if (s.charAt(left) != s.charAt(right)) {
                return false;
            }
            left++;
            right--;
        }
        return true;
    }
    
    /**
     * Two Sum in sorted array
     * Time: O(n), Space: O(1)
     */
    public static int[] twoSumSorted(int[] nums, int target) {
        int left = 0, right = nums.length - 1;
        
        while (left < right) {
            int sum = nums[left] + nums[right];
            if (sum == target) {
                return new int[]{left, right};
            } else if (sum < target) {
                left++;
            } else {
                right--;
            }
        }
        
        return new int[]{-1, -1};
    }
}
```

#### Pattern 2: Same Direction (Fast and Slow)
```java
public class TwoPointerSameDirection {
    
    /**
     * Remove duplicates from sorted array
     * Time: O(n), Space: O(1)
     */
    public static int removeDuplicates(int[] nums) {
        if (nums.length == 0) return 0;
        
        int slow = 0;
        for (int fast = 1; fast < nums.length; fast++) {
            if (nums[fast] != nums[slow]) {
                nums[++slow] = nums[fast];
            }
        }
        return slow + 1;
    }
    
    /**
     * Move all zeros to end
     * Time: O(n), Space: O(1)
     */
    public static void moveZeros(int[] nums) {
        int slow = 0;
        for (int fast = 0; fast < nums.length; fast++) {
            if (nums[fast] != 0) {
                nums[slow++] = nums[fast];
            }
        }
        while (slow < nums.length) {
            nums[slow++] = 0;
        }
    }
}
```

---

## Sliding Window Algorithm

The sliding window technique is used to solve problems involving subarrays or substrings efficiently.

### Fixed Size Window
```java
public class FixedSlidingWindow {
    
    /**
     * Find maximum sum of subarray of size k
     * Time: O(n), Space: O(1)
     */
    public static int maxSumSubarray(int[] nums, int k) {
        if (nums.length < k) return -1;
        
        // Calculate sum of first window
        int windowSum = 0;
        for (int i = 0; i < k; i++) {
            windowSum += nums[i];
        }
        
        int maxSum = windowSum;
        
        // Slide the window
        for (int i = k; i < nums.length; i++) {
            windowSum = windowSum - nums[i - k] + nums[i];
            maxSum = Math.max(maxSum, windowSum);
        }
        
        return maxSum;
    }
}
```

### Variable Size Window
```java
public class VariableSlidingWindow {
    
    /**
     * Find length of longest substring without repeating characters
     * Time: O(n), Space: O(min(m,n)) where m is charset size
     */
    public static int lengthOfLongestSubstring(String s) {
        Set<Character> window = new HashSet<>();
        int left = 0, maxLength = 0;
        
        for (int right = 0; right < s.length(); right++) {
            // If character is already in window, shrink from left
            while (window.contains(s.charAt(right))) {
                window.remove(s.charAt(left++));
            }
            
            // Add current character to window
            window.add(s.charAt(right));
            maxLength = Math.max(maxLength, right - left + 1);
        }
        
        return maxLength;
    }
    
    /**
     * Find minimum window substring containing all characters of pattern
     * Time: O(n), Space: O(n)
     */
    public static String minWindow(String s, String t) {
        if (s.length() < t.length()) return "";
        
        Map<Character, Integer> targetCount = new HashMap<>();
        for (char c : t.toCharArray()) {
            targetCount.put(c, targetCount.getOrDefault(c, 0) + 1);
        }
        
        int left = 0, right = 0;
        int minStart = 0, minLength = Integer.MAX_VALUE;
        int required = targetCount.size();
        int formed = 0;
        
        Map<Character, Integer> windowCount = new HashMap<>();
        
        while (right < s.length()) {
            char c = s.charAt(right);
            windowCount.put(c, windowCount.getOrDefault(c, 0) + 1);
            
            if (targetCount.containsKey(c) && 
                windowCount.get(c).intValue() == targetCount.get(c).intValue()) {
                formed++;
            }
            
            while (left <= right && formed == required) {
                if (right - left + 1 < minLength) {
                    minLength = right - left + 1;
                    minStart = left;
                }
                
                char leftChar = s.charAt(left);
                windowCount.put(leftChar, windowCount.get(leftChar) - 1);
                if (targetCount.containsKey(leftChar) && 
                    windowCount.get(leftChar) < targetCount.get(leftChar)) {
                    formed--;
                }
                left++;
            }
            right++;
        }
        
        return minLength == Integer.MAX_VALUE ? "" : s.substring(minStart, minStart + minLength);
    }
}
```

---

## String Algorithms

### Pattern Matching

#### KMP Algorithm (Knuth-Morris-Pratt)
```java
public class KMPAlgorithm {
    
    /**
     * Find all occurrences of pattern in text using KMP
     * Time: O(n + m), Space: O(m)
     */
    public static List<Integer> kmpSearch(String text, String pattern) {
        List<Integer> result = new ArrayList<>();
        if (pattern.length() == 0) return result;
        
        int[] lps = computeLPS(pattern);
        int i = 0, j = 0; // i for text, j for pattern
        
        while (i < text.length()) {
            if (text.charAt(i) == pattern.charAt(j)) {
                i++;
                j++;
            }
            
            if (j == pattern.length()) {
                result.add(i - j);
                j = lps[j - 1];
            } else if (i < text.length() && text.charAt(i) != pattern.charAt(j)) {
                if (j != 0) {
                    j = lps[j - 1];
                } else {
                    i++;
                }
            }
        }
        
        return result;
    }
    
    /**
     * Compute Longest Proper Prefix which is also Suffix
     */
    private static int[] computeLPS(String pattern) {
        int[] lps = new int[pattern.length()];
        int len = 0, i = 1;
        
        while (i < pattern.length()) {
            if (pattern.charAt(i) == pattern.charAt(len)) {
                lps[i++] = ++len;
            } else {
                if (len != 0) {
                    len = lps[len - 1];
                } else {
                    lps[i++] = 0;
                }
            }
        }
        
        return lps;
    }
}
```

### String Transformation

```java
public class StringTransformation {
    
    /**
     * Group anagrams together
     * Time: O(n * m * log(m)), Space: O(n * m)
     */
    public static List<List<String>> groupAnagrams(String[] strs) {
        Map<String, List<String>> map = new HashMap<>();
        
        for (String str : strs) {
            char[] chars = str.toCharArray();
            Arrays.sort(chars);
            String key = new String(chars);
            
            map.computeIfAbsent(key, k -> new ArrayList<>()).add(str);
        }
        
        return new ArrayList<>(map.values());
    }
    
    /**
     * Find all permutations of a string
     * Time: O(n! * n), Space: O(n! * n)
     */
    public static List<String> permutations(String s) {
        List<String> result = new ArrayList<>();
        permute(s.toCharArray(), 0, result);
        return result;
    }
    
    private static void permute(char[] arr, int start, List<String> result) {
        if (start == arr.length) {
            result.add(new String(arr));
            return;
        }
        
        for (int i = start; i < arr.length; i++) {
            swap(arr, start, i);
            permute(arr, start + 1, result);
            swap(arr, start, i); // backtrack
        }
    }
    
    private static void swap(char[] arr, int i, int j) {
        char temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }
}
```

---

## 🎯 Key Patterns Summary

### Array Patterns:
1. **Two Pointers**: Opposite ends or same direction
2. **Sliding Window**: Fixed or variable size
3. **In-place Operations**: Modify without extra space
4. **Partitioning**: Divide based on conditions

### String Patterns:
1. **Character Frequency**: Use arrays or maps
2. **Pattern Matching**: KMP, Rabin-Karp
3. **String Transformation**: Sorting, hashing
4. **Backtracking**: Permutations, combinations

---

## 🏋️ Exercises

### Exercise 1: Valid Parentheses ⭐
Given a string containing just the characters '(', ')', '{', '}', '[' and ']', determine if the input string is valid.

### Exercise 2: Longest Common Prefix ⭐
Write a function to find the longest common prefix string amongst an array of strings.

### Exercise 3: Container With Most Water ⭐⭐
Given n non-negative integers representing the height of bars, find two lines that together with the x-axis forms a container that holds the most water.

### Exercise 4: 3Sum ⭐⭐
Given an array of integers, find all unique triplets that sum to zero.

### Exercise 5: Longest Substring Without Repeating Characters ⭐⭐
Given a string, find the length of the longest substring without repeating characters.

### Exercise 6: Minimum Window Substring ⭐⭐⭐
Given two strings s and t, return the minimum window substring of s such that every character in t is included in the window.

### Exercise 7: Group Anagrams ⭐⭐
Given an array of strings, group the anagrams together.

### Exercise 8: Valid Anagram ⭐
Given two strings s and t, return true if t is an anagram of s.

---

## 🎓 Interview Tips

1. **Clarify the problem**:
   - Case sensitivity?
   - Empty string handling?
   - Character set (ASCII, Unicode)?

2. **Think about edge cases**:
   - Empty arrays/strings
   - Single element
   - All same elements

3. **Choose the right technique**:
   - Two pointers for sorted arrays
   - Sliding window for subarray problems
   - Hash maps for frequency counting

4. **Optimize step by step**:
   - Start with brute force
   - Identify bottlenecks
   - Apply appropriate patterns

---

## 🚀 What's Next?

You've mastered arrays and strings! Next, we'll explore:
- [Linked Lists](02-basic-ds/01-linked-lists.md) - Dynamic data structures
- [Stacks and Queues](02-basic-ds/02-stacks-queues.md) - LIFO and FIFO structures
- [Hash Tables](02-basic-ds/03-hash-tables.md) - Fast lookups and insertions

Remember: **Pattern recognition is key!** The more problems you solve, the better you'll become at identifying which technique to use.

---

*"The best way to learn algorithms is to implement them yourself." - Donald Knuth*
