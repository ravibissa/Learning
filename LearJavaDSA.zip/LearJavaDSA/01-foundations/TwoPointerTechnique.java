/**
 * Two-Pointer Technique Examples
 * 
 * This class demonstrates the two-pointer technique, one of the most
 * powerful patterns in data structures and algorithms.
 * 
 * @author DSA Tutorial
 * @version 1.0
 */
import java.util.*;

public class TwoPointerTechnique {
    
    /**
     * Check if string is palindrome using two pointers
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     * 
     * Pattern: Opposite ends pointers
     */
    public static boolean isPalindrome(String s) {
        int left = 0, right = s.length() - 1;
        
        while (left < right) {
            if (s.charAt(left) != s.charAt(right)) {
                return false;
            }
            left++;
            right--;
        }
        return true;
    }
    
    /**
     * Two Sum in sorted array
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     * 
     * Pattern: Opposite ends pointers
     */
    public static int[] twoSumSorted(int[] nums, int target) {
        int left = 0, right = nums.length - 1;
        
        while (left < right) {
            int sum = nums[left] + nums[right];
            if (sum == target) {
                return new int[]{left, right};
            } else if (sum < target) {
                left++;
            } else {
                right--;
            }
        }
        
        return new int[]{-1, -1};
    }
    
    /**
     * Remove duplicates from sorted array
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     * 
     * Pattern: Same direction pointers (slow and fast)
     */
    public static int removeDuplicates(int[] nums) {
        if (nums.length == 0) return 0;
        
        int slow = 0;
        for (int fast = 1; fast < nums.length; fast++) {
            if (nums[fast] != nums[slow]) {
                nums[++slow] = nums[fast];
            }
        }
        return slow + 1;
    }
    
    /**
     * Move all zeros to end
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     * 
     * Pattern: Same direction pointers
     */
    public static void moveZeros(int[] nums) {
        int slow = 0;
        for (int fast = 0; fast < nums.length; fast++) {
            if (nums[fast] != 0) {
                nums[slow++] = nums[fast];
            }
        }
        while (slow < nums.length) {
            nums[slow++] = 0;
        }
    }
    
    /**
     * Remove all instances of a value
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     * 
     * Pattern: Same direction pointers
     */
    public static int removeElement(int[] nums, int val) {
        int slow = 0;
        for (int fast = 0; fast < nums.length; fast++) {
            if (nums[fast] != val) {
                nums[slow++] = nums[fast];
            }
        }
        return slow;
    }
    
    /**
     * Container With Most Water
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     * 
     * Pattern: Opposite ends pointers
     */
    public static int maxArea(int[] height) {
        int left = 0, right = height.length - 1;
        int maxWater = 0;
        
        while (left < right) {
            // Calculate current area
            int currentArea = Math.min(height[left], height[right]) * (right - left);
            maxWater = Math.max(maxWater, currentArea);
            
            // Move pointer with smaller height
            if (height[left] < height[right]) {
                left++;
            } else {
                right--;
            }
        }
        
        return maxWater;
    }
    
    /**
     * 3Sum - Find all unique triplets that sum to zero
     * Time Complexity: O(n²)
     * Space Complexity: O(1) excluding output
     * 
     * Pattern: Fixed first element + two pointers for remaining
     */
    public static List<List<Integer>> threeSum(int[] nums) {
        List<List<Integer>> result = new ArrayList<>();
        Arrays.sort(nums);
        
        for (int i = 0; i < nums.length - 2; i++) {
            // Skip duplicates for first element
            if (i > 0 && nums[i] == nums[i - 1]) continue;
            
            int left = i + 1, right = nums.length - 1;
            int target = -nums[i];
            
            while (left < right) {
                int sum = nums[left] + nums[right];
                if (sum == target) {
                    result.add(Arrays.asList(nums[i], nums[left], nums[right]));
                    
                    // Skip duplicates
                    while (left < right && nums[left] == nums[left + 1]) left++;
                    while (left < right && nums[right] == nums[right - 1]) right--;
                    
                    left++;
                    right--;
                } else if (sum < target) {
                    left++;
                } else {
                    right--;
                }
            }
        }
        
        return result;
    }
    
    /**
     * 4Sum - Find all unique quadruplets that sum to target
     * Time Complexity: O(n³)
     * Space Complexity: O(1) excluding output
     * 
     * Pattern: Two nested loops + two pointers
     */
    public static List<List<Integer>> fourSum(int[] nums, int target) {
        List<List<Integer>> result = new ArrayList<>();
        Arrays.sort(nums);
        
        for (int i = 0; i < nums.length - 3; i++) {
            if (i > 0 && nums[i] == nums[i - 1]) continue;
            
            for (int j = i + 1; j < nums.length - 2; j++) {
                if (j > i + 1 && nums[j] == nums[j - 1]) continue;
                
                int left = j + 1, right = nums.length - 1;
                long remainingTarget = (long)target - nums[i] - nums[j];
                
                while (left < right) {
                    long sum = (long)nums[left] + nums[right];
                    if (sum == remainingTarget) {
                        result.add(Arrays.asList(nums[i], nums[j], nums[left], nums[right]));
                        
                        while (left < right && nums[left] == nums[left + 1]) left++;
                        while (left < right && nums[right] == nums[right - 1]) right--;
                        
                        left++;
                        right--;
                    } else if (sum < remainingTarget) {
                        left++;
                    } else {
                        right--;
                    }
                }
            }
        }
        
        return result;
    }
    
    /**
     * Sort Colors (Dutch National Flag Problem)
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     * 
     * Pattern: Three pointers for three regions
     */
    public static void sortColors(int[] nums) {
        int low = 0, mid = 0, high = nums.length - 1;
        
        while (mid <= high) {
            if (nums[mid] == 0) {
                swap(nums, low++, mid++);
            } else if (nums[mid] == 1) {
                mid++;
            } else {
                swap(nums, mid, high--);
            }
        }
    }
    
    /**
     * Helper method to swap elements
     */
    private static void swap(int[] nums, int i, int j) {
        int temp = nums[i];
        nums[i] = nums[j];
        nums[j] = temp;
    }
    
    /**
     * Trapping Rain Water
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     * 
     * Pattern: Two pointers from both ends
     */
    public static int trap(int[] height) {
        if (height.length < 3) return 0;
        
        int left = 0, right = height.length - 1;
        int leftMax = 0, rightMax = 0;
        int water = 0;
        
        while (left < right) {
            if (height[left] < height[right]) {
                if (height[left] >= leftMax) {
                    leftMax = height[left];
                } else {
                    water += leftMax - height[left];
                }
                left++;
            } else {
                if (height[right] >= rightMax) {
                    rightMax = height[right];
                } else {
                    water += rightMax - height[right];
                }
                right--;
            }
        }
        
        return water;
    }
    
    /**
     * Valid Palindrome (ignoring case and non-alphanumeric)
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     * 
     * Pattern: Opposite ends pointers with character validation
     */
    public static boolean isPalindromeIgnoreCase(String s) {
        int left = 0, right = s.length() - 1;
        
        while (left < right) {
            // Skip non-alphanumeric characters
            while (left < right && !Character.isLetterOrDigit(s.charAt(left))) {
                left++;
            }
            while (left < right && !Character.isLetterOrDigit(s.charAt(right))) {
                right--;
            }
            
            // Compare characters (case-insensitive)
            if (Character.toLowerCase(s.charAt(left)) != 
                Character.toLowerCase(s.charAt(right))) {
                return false;
            }
            
            left++;
            right--;
        }
        
        return true;
    }
    
    public static void main(String[] args) {
        System.out.println("=== Two-Pointer Technique Examples ===\n");
        
        // Test palindrome
        System.out.println("1. Palindrome Check:");
        String test1 = "racecar";
        String test2 = "hello";
        System.out.println("'" + test1 + "' is palindrome: " + isPalindrome(test1));
        System.out.println("'" + test2 + "' is palindrome: " + isPalindrome(test2));
        System.out.println();
        
        // Test two sum sorted
        System.out.println("2. Two Sum in Sorted Array:");
        int[] arr1 = {2, 7, 11, 15};
        int[] result1 = twoSumSorted(arr1, 9);
        System.out.println("Array: " + Arrays.toString(arr1) + ", Target: 9");
        System.out.println("Indices: " + Arrays.toString(result1));
        System.out.println();
        
        // Test remove duplicates
        System.out.println("3. Remove Duplicates:");
        int[] arr2 = {1, 1, 2, 2, 3, 4, 4, 5};
        System.out.println("Before: " + Arrays.toString(arr2));
        int newLength = removeDuplicates(arr2);
        System.out.println("After: " + Arrays.toString(arr2));
        System.out.println("New length: " + newLength);
        System.out.println();
        
        // Test container with most water
        System.out.println("4. Container With Most Water:");
        int[] arr3 = {1, 8, 6, 2, 5, 4, 8, 3, 7};
        System.out.println("Heights: " + Arrays.toString(arr3));
        System.out.println("Max water area: " + maxArea(arr3));
        System.out.println();
        
        // Test 3Sum
        System.out.println("5. 3Sum:");
        int[] arr4 = {-1, 0, 1, 2, -1, -4};
        System.out.println("Array: " + Arrays.toString(arr4));
        List<List<Integer>> triplets = threeSum(arr4);
        System.out.println("Triplets that sum to 0: " + triplets);
        System.out.println();
        
        // Test sort colors
        System.out.println("6. Sort Colors:");
        int[] arr5 = {2, 0, 2, 1, 1, 0};
        System.out.println("Before: " + Arrays.toString(arr5));
        sortColors(arr5);
        System.out.println("After: " + Arrays.toString(arr5));
        System.out.println();
        
        // Test trapping rain water
        System.out.println("7. Trapping Rain Water:");
        int[] arr6 = {0, 1, 0, 2, 1, 0, 1, 3, 2, 1, 2, 1};
        System.out.println("Heights: " + Arrays.toString(arr6));
        System.out.println("Trapped water: " + trap(arr6));
        System.out.println();
        
        // Test palindrome with case and punctuation
        System.out.println("8. Valid Palindrome (ignore case/punctuation):");
        String test3 = "A man, a plan, a canal: Panama";
        System.out.println("'" + test3 + "' is palindrome: " + isPalindromeIgnoreCase(test3));
        System.out.println();
        
        System.out.println("=== Two-Pointer Patterns Summary ===");
        System.out.println("1. Opposite Ends: Palindrome, Two Sum, Container Water");
        System.out.println("2. Same Direction: Remove duplicates, Move zeros");
        System.out.println("3. Three Pointers: Sort colors, Dutch flag");
        System.out.println("4. Nested + Two Pointers: 3Sum, 4Sum");
        System.out.println("5. Advanced: Trapping water, Rain water");
    }
}
