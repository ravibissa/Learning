# Java Basics Review
## Foundation for Data Structures & Algorithms

Welcome to your journey into Data Structures and Algorithms! Before we dive into complex data structures, let's make sure you have a solid foundation in Java programming.

## 🎯 Learning Objectives
By the end of this section, you will:
- Understand Java fundamentals essential for DSA
- Master variable types and memory concepts
- Learn control structures and loops
- Practice problem-solving with basic algorithms
- Be ready for advanced data structures

## 📚 Table of Contents
1. [Variables and Data Types](#variables-and-data-types)
2. [Control Structures](#control-structures)
3. [Methods and Functions](#methods-and-functions)
4. [Arrays and Memory](#arrays-and-memory)
5. [Basic Problem Solving](#basic-problem-solving)
6. [Exercises](#exercises)

---

## Variables and Data Types

### Primitive Data Types
Think of variables as labeled boxes that store different types of information.

```java
public class DataTypesExample {
    public static void main(String[] args) {
        // Integer types
        byte smallNumber = 127;        // 8-bit: -128 to 127
        short mediumNumber = 32000;    // 16-bit: -32,768 to 32,767
        int number = 1000000;          // 32-bit: -2^31 to 2^31-1
        long bigNumber = 1000000000L;  // 64-bit: -2^63 to 2^63-1
        
        // Floating point types
        float decimal = 3.14f;         // 32-bit floating point
        double preciseDecimal = 3.14159265359; // 64-bit floating point
        
        // Character and boolean
        char letter = 'A';             // 16-bit Unicode character
        boolean isTrue = true;         // true or false
        
        System.out.println("Integer: " + number);
        System.out.println("Decimal: " + decimal);
        System.out.println("Character: " + letter);
        System.out.println("Boolean: " + isTrue);
    }
}
```

### Why This Matters for DSA
- **Memory efficiency**: Choosing the right data type saves memory
- **Performance**: Smaller data types can be processed faster
- **Precision**: Understanding floating-point limitations

---

## Control Structures

### If-Else Statements
Making decisions in your code is like choosing different paths in a maze.

```java
public class ControlStructures {
    public static void main(String[] args) {
        int age = 18;
        
        // Simple if statement
        if (age >= 18) {
            System.out.println("You are an adult!");
        }
        
        // If-else statement
        if (age >= 18) {
            System.out.println("You can vote!");
        } else {
            System.out.println("You cannot vote yet.");
        }
        
        // Multiple conditions
        if (age < 13) {
            System.out.println("Child");
        } else if (age < 20) {
            System.out.println("Teenager");
        } else if (age < 65) {
            System.out.println("Adult");
        } else {
            System.out.println("Senior");
        }
    }
}
```

### Loops - The Power of Repetition
Loops are like having a robot that repeats tasks for you.

#### For Loop
```java
public class ForLoopExample {
    public static void main(String[] args) {
        // Basic for loop
        System.out.println("Counting from 1 to 5:");
        for (int i = 1; i <= 5; i++) {
            System.out.println("Count: " + i);
        }
        
        // For loop with step
        System.out.println("Even numbers from 2 to 10:");
        for (int i = 2; i <= 10; i += 2) {
            System.out.println("Even: " + i);
        }
        
        // Reverse counting
        System.out.println("Countdown from 5 to 1:");
        for (int i = 5; i >= 1; i--) {
            System.out.println("Countdown: " + i);
        }
    }
}
```

#### While Loop
```java
public class WhileLoopExample {
    public static void main(String[] args) {
        int count = 1;
        
        // While loop - continues while condition is true
        System.out.println("While loop example:");
        while (count <= 5) {
            System.out.println("Count: " + count);
            count++; // Don't forget to increment!
        }
        
        // Do-while loop - executes at least once
        int number = 10;
        do {
            System.out.println("Number: " + number);
            number--;
        } while (number > 0);
    }
}
```

---

## Methods and Functions

Methods are like recipes - they take ingredients (parameters) and produce a result.

```java
public class MethodsExample {
    
    // Method that takes no parameters and returns nothing
    public static void sayHello() {
        System.out.println("Hello, World!");
    }
    
    // Method that takes parameters and returns a value
    public static int add(int a, int b) {
        return a + b;
    }
    
    // Method that takes an array and returns the maximum value
    public static int findMax(int[] numbers) {
        if (numbers.length == 0) {
            return -1; // Error case
        }
        
        int max = numbers[0];
        for (int i = 1; i < numbers.length; i++) {
            if (numbers[i] > max) {
                max = numbers[i];
            }
        }
        return max;
    }
    
    // Method with multiple return statements
    public static String getGrade(int score) {
        if (score >= 90) return "A";
        if (score >= 80) return "B";
        if (score >= 70) return "C";
        if (score >= 60) return "D";
        return "F";
    }
    
    public static void main(String[] args) {
        sayHello();
        
        int sum = add(5, 3);
        System.out.println("5 + 3 = " + sum);
        
        int[] numbers = {3, 7, 2, 9, 1};
        int maxNumber = findMax(numbers);
        System.out.println("Maximum number: " + maxNumber);
        
        String grade = getGrade(85);
        System.out.println("Grade for 85: " + grade);
    }
}
```

---

## Arrays and Memory

### Understanding Arrays
An array is like a row of lockers - each has a number and can store one item.

```java
public class ArraysExample {
    public static void main(String[] args) {
        // Creating arrays
        int[] numbers = new int[5];        // Array of 5 integers
        String[] names = {"Alice", "Bob", "Charlie"}; // Array with initial values
        
        // Accessing array elements (0-based indexing)
        numbers[0] = 10;
        numbers[1] = 20;
        numbers[2] = 30;
        numbers[3] = 40;
        numbers[4] = 50;
        
        // Printing array elements
        System.out.println("Numbers array:");
        for (int i = 0; i < numbers.length; i++) {
            System.out.println("Index " + i + ": " + numbers[i]);
        }
        
        // Enhanced for loop (for-each loop)
        System.out.println("Names array:");
        for (String name : names) {
            System.out.println("Name: " + name);
        }
        
        // Array length
        System.out.println("Numbers array length: " + numbers.length);
        System.out.println("Names array length: " + names.length);
    }
}
```

### Memory Concepts
Understanding how Java manages memory is crucial for DSA:

```java
public class MemoryExample {
    public static void main(String[] args) {
        // Stack vs Heap
        int primitive = 42;           // Stored on stack
        int[] array = new int[1000];  // Array object on heap, reference on stack
        
        // Array copying
        int[] original = {1, 2, 3, 4, 5};
        int[] copy = new int[original.length];
        
        // Manual copying
        for (int i = 0; i < original.length; i++) {
            copy[i] = original[i];
        }
        
        // Using System.arraycopy (more efficient)
        int[] copy2 = new int[original.length];
        System.arraycopy(original, 0, copy2, 0, original.length);
        
        System.out.println("Original: " + java.util.Arrays.toString(original));
        System.out.println("Copy: " + java.util.Arrays.toString(copy));
    }
}
```

---

## Basic Problem Solving

Let's solve some fundamental problems that build the foundation for DSA:

### Problem 1: Find the Sum of Array Elements
```java
public class ArraySum {
    public static int sumArray(int[] arr) {
        int sum = 0;
        for (int num : arr) {
            sum += num;
        }
        return sum;
    }
    
    public static void main(String[] args) {
        int[] numbers = {1, 2, 3, 4, 5};
        int result = sumArray(numbers);
        System.out.println("Sum: " + result); // Output: 15
    }
}
```

### Problem 2: Find Maximum and Minimum
```java
public class FindMinMax {
    public static int findMax(int[] arr) {
        if (arr.length == 0) return -1;
        
        int max = arr[0];
        for (int i = 1; i < arr.length; i++) {
            if (arr[i] > max) {
                max = arr[i];
            }
        }
        return max;
    }
    
    public static int findMin(int[] arr) {
        if (arr.length == 0) return -1;
        
        int min = arr[0];
        for (int i = 1; i < arr.length; i++) {
            if (arr[i] < min) {
                min = arr[i];
            }
        }
        return min;
    }
    
    public static void main(String[] args) {
        int[] numbers = {3, 7, 2, 9, 1, 5};
        System.out.println("Maximum: " + findMax(numbers)); // 9
        System.out.println("Minimum: " + findMin(numbers)); // 1
    }
}
```

### Problem 3: Linear Search
```java
public class LinearSearch {
    public static int linearSearch(int[] arr, int target) {
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == target) {
                return i; // Return index where found
            }
        }
        return -1; // Not found
    }
    
    public static void main(String[] args) {
        int[] numbers = {3, 7, 2, 9, 1, 5};
        int target = 9;
        int index = linearSearch(numbers, target);
        
        if (index != -1) {
            System.out.println("Found " + target + " at index " + index);
        } else {
            System.out.println(target + " not found in array");
        }
    }
}
```

### Problem 4: Count Occurrences
```java
public class CountOccurrences {
    public static int countOccurrences(int[] arr, int target) {
        int count = 0;
        for (int num : arr) {
            if (num == target) {
                count++;
            }
        }
        return count;
    }
    
    public static void main(String[] args) {
        int[] numbers = {1, 2, 3, 2, 4, 2, 5};
        int target = 2;
        int count = countOccurrences(numbers, target);
        System.out.println(target + " appears " + count + " times");
    }
}
```

---

## 🎯 Key Concepts for DSA

### Time Complexity (Big O Notation)
Understanding how algorithms perform as input size grows:

- **O(1)**: Constant time - accessing an array element
- **O(n)**: Linear time - searching through an array
- **O(n²)**: Quadratic time - nested loops

### Space Complexity
How much memory an algorithm uses:

- **O(1)**: Constant space - using a few variables
- **O(n)**: Linear space - creating an array of size n

### Best Practices
1. **Always check array bounds** - prevent IndexOutOfBoundsException
2. **Handle edge cases** - empty arrays, null values
3. **Use meaningful variable names** - makes code readable
4. **Comment your code** - explain complex logic
5. **Test with different inputs** - verify correctness

---

## 🏋️ Exercises

### Exercise 1: Array Reversal
Write a method to reverse an array in-place (without using extra space).

**Hint**: Swap elements from both ends moving towards the center.

### Exercise 2: Find Second Largest
Write a method to find the second largest element in an array.

**Hint**: Keep track of both largest and second largest as you iterate.

### Exercise 3: Remove Duplicates
Write a method to remove duplicates from a sorted array and return the new length.

**Hint**: Use two pointers - one for reading, one for writing.

### Exercise 4: Two Sum
Given an array of integers and a target sum, find two numbers that add up to the target.

**Hint**: Use nested loops or a hash map for efficiency.

### Exercise 5: Fibonacci Sequence
Write a method to generate the first n Fibonacci numbers.

**Hint**: Each number is the sum of the two preceding ones.

---

## 🎓 Interview Tips

1. **Always ask clarifying questions**:
   - "Can the array be empty?"
   - "Are there any constraints on the input size?"
   - "Should I handle negative numbers?"

2. **Think out loud**:
   - Explain your approach before coding
   - Discuss time and space complexity
   - Mention alternative solutions

3. **Start with brute force**:
   - Get a working solution first
   - Then optimize if time permits

4. **Test your code**:
   - Walk through examples
   - Check edge cases
   - Verify with different inputs

---

## 🚀 What's Next?

You've mastered the Java fundamentals! In the next section, we'll dive deeper into:
- [Arrays and Strings](02-arrays-strings.md) - More complex array operations
- String manipulation and pattern matching
- Two-pointer techniques
- Sliding window algorithms

Remember: **Practice makes perfect!** Solve the exercises before moving on.

---

*"The expert in anything was once a beginner." - Helen Hayes*
