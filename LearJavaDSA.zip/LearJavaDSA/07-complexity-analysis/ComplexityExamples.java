import java.util.*;

/**
 * Time and Space Complexity Analysis Examples
 * This file contains practical examples demonstrating different complexity classes
 * with detailed analysis and comparisons.
 * 
 * Author: Java DSA Tutorial
 * Purpose: Help students understand algorithm efficiency analysis
 */

public class ComplexityExamples {
    
    // ==============================================
    // CONSTANT TIME - O(1) EXAMPLES
    // ==============================================
    
    /**
     * Array Access - O(1) Time, O(1) Space
     * Direct access to array element by index
     */
    public static int getArrayElement(int[] arr, int index) {
        return arr[index];  // Direct access - always same time regardless of array size
    }
    
    /**
     * Mathematical Operations - O(1) Time, O(1) Space
     * Basic arithmetic operations take constant time
     */
    public static int addNumbers(int a, int b) {
        return a + b;  // Single operation - constant time
    }
    
    /**
     * Hash Map Operations - O(1) Average Time, O(1) Space
     * Hash table operations are typically constant time
     */
    public static String getValue(Map<String, String> map, String key) {
        return map.get(key);  // Average O(1), worst case O(n) if poor hash function
    }
    
    // ==============================================
    // LOGARITHMIC TIME - O(log n) EXAMPLES
    // ==============================================
    
    /**
     * Binary Search - O(log n) Time, O(1) Space (Iterative)
     * Each step eliminates half of remaining elements
     */
    public static int binarySearchIterative(int[] arr, int target) {
        int left = 0, right = arr.length - 1;
        
        while (left <= right) {  // At most log₂(n) iterations
            int mid = left + (right - left) / 2;  // Avoid overflow
            
            if (arr[mid] == target) {
                return mid;  // Found target
            } else if (arr[mid] < target) {
                left = mid + 1;  // Search right half
            } else {
                right = mid - 1;  // Search left half
            }
        }
        return -1;  // Not found
    }
    
    /**
     * Binary Search - O(log n) Time, O(log n) Space (Recursive)
     * Space complexity increases due to call stack
     */
    public static int binarySearchRecursive(int[] arr, int target, int left, int right) {
        if (left > right) return -1;  // Base case: not found
        
        int mid = left + (right - left) / 2;
        
        if (arr[mid] == target) {
            return mid;  // Found target
        } else if (arr[mid] < target) {
            return binarySearchRecursive(arr, target, mid + 1, right);  // Search right
        } else {
            return binarySearchRecursive(arr, target, left, mid - 1);   // Search left
        }
        // Call stack depth = O(log n) space
    }
    
    /**
     * Finding Height of Binary Tree - O(log n) Average, O(n) Worst
     * For balanced tree: O(log n), for skewed tree: O(n)
     */
    static class TreeNode {
        int val;
        TreeNode left, right;
        TreeNode(int val) { this.val = val; }
    }
    
    public static int treeHeight(TreeNode root) {
        if (root == null) return 0;  // Base case
        
        int leftHeight = treeHeight(root.left);   // Recursive call
        int rightHeight = treeHeight(root.right); // Recursive call
        
        return 1 + Math.max(leftHeight, rightHeight);
        // Time: O(n) - visit all nodes
        // Space: O(log n) average (balanced), O(n) worst (skewed)
    }
    
    // ==============================================
    // LINEAR TIME - O(n) EXAMPLES
    // ==============================================
    
    /**
     * Linear Search - O(n) Time, O(1) Space
     * May need to check every element in worst case
     */
    public static int linearSearch(int[] arr, int target) {
        for (int i = 0; i < arr.length; i++) {  // Up to n iterations
            if (arr[i] == target) {
                return i;  // Found target
            }
        }
        return -1;  // Not found after checking all elements
    }
    
    /**
     * Array Sum - O(n) Time, O(1) Space
     * Must visit every element exactly once
     */
    public static long arraySum(int[] arr) {
        long sum = 0;  // O(1) space
        for (int num : arr) {  // n iterations
            sum += num;  // O(1) operation
        }
        return sum;
        // Total: O(n) time, O(1) space
    }
    
    /**
     * Find Maximum Element - O(n) Time, O(1) Space
     * Must check every element to ensure we found maximum
     */
    public static int findMax(int[] arr) {
        if (arr.length == 0) throw new IllegalArgumentException("Empty array");
        
        int max = arr[0];  // O(1) space
        for (int i = 1; i < arr.length; i++) {  // n-1 iterations
            if (arr[i] > max) {  // O(1) comparison
                max = arr[i];
            }
        }
        return max;
    }
    
    /**
     * Array Reversal - O(n) Time, O(1) Space
     * In-place reversal using two pointers
     */
    public static void reverseArray(int[] arr) {
        int left = 0, right = arr.length - 1;
        
        while (left < right) {  // n/2 iterations
            // Swap elements
            int temp = arr[left];   // O(1) operations
            arr[left] = arr[right];
            arr[right] = temp;
            
            left++;   // Move pointers
            right--;
        }
        // Time: O(n), Space: O(1)
    }
    
    /**
     * Create Copy of Array - O(n) Time, O(n) Space
     * Need to allocate new array and copy all elements
     */
    public static int[] copyArray(int[] arr) {
        int[] copy = new int[arr.length];  // O(n) space allocation
        
        for (int i = 0; i < arr.length; i++) {  // n iterations
            copy[i] = arr[i];  // O(1) copy operation
        }
        
        return copy;
        // Time: O(n), Space: O(n)
    }
    
    // ==============================================
    // LINEARITHMIC TIME - O(n log n) EXAMPLES
    // ==============================================
    
    /**
     * Merge Sort - O(n log n) Time, O(n) Space
     * Divide and conquer approach with optimal comparison-based sorting
     */
    public static void mergeSort(int[] arr, int left, int right) {
        if (left < right) {
            int mid = left + (right - left) / 2;
            
            mergeSort(arr, left, mid);        // T(n/2)
            mergeSort(arr, mid + 1, right);   // T(n/2)
            merge(arr, left, mid, right);     // O(n)
        }
        // Recurrence: T(n) = 2T(n/2) + O(n) = O(n log n)
    }
    
    private static void merge(int[] arr, int left, int mid, int right) {
        int[] temp = new int[right - left + 1];  // O(n) space
        int i = left, j = mid + 1, k = 0;
        
        // Merge two sorted halves
        while (i <= mid && j <= right) {  // O(n) total iterations
            if (arr[i] <= arr[j]) {
                temp[k++] = arr[i++];
            } else {
                temp[k++] = arr[j++];
            }
        }
        
        // Copy remaining elements
        while (i <= mid) temp[k++] = arr[i++];
        while (j <= right) temp[k++] = arr[j++];
        
        // Copy back to original array
        for (i = left; i <= right; i++) {
            arr[i] = temp[i - left];
        }
    }
    
    /**
     * Heap Sort - O(n log n) Time, O(1) Space
     * In-place sorting using heap data structure
     */
    public static void heapSort(int[] arr) {
        int n = arr.length;
        
        // Build max heap - O(n) time
        for (int i = n / 2 - 1; i >= 0; i--) {
            heapify(arr, n, i);
        }
        
        // Extract elements one by one - O(n log n) time
        for (int i = n - 1; i > 0; i--) {
            // Move current root to end
            swap(arr, 0, i);        // O(1)
            heapify(arr, i, 0);     // O(log n)
        }
        // Total: O(n) + O(n log n) = O(n log n)
    }
    
    private static void heapify(int[] arr, int n, int i) {
        int largest = i;
        int left = 2 * i + 1;
        int right = 2 * i + 2;
        
        if (left < n && arr[left] > arr[largest]) largest = left;
        if (right < n && arr[right] > arr[largest]) largest = right;
        
        if (largest != i) {
            swap(arr, i, largest);
            heapify(arr, n, largest);  // Recursive call - O(log n) depth
        }
    }
    
    // ==============================================
    // QUADRATIC TIME - O(n²) EXAMPLES
    // ==============================================
    
    /**
     * Bubble Sort - O(n²) Time, O(1) Space
     * Nested loops with comparisons and swaps
     */
    public static void bubbleSort(int[] arr) {
        int n = arr.length;
        
        for (int i = 0; i < n - 1; i++) {        // n-1 iterations
            boolean swapped = false;
            
            for (int j = 0; j < n - i - 1; j++) { // (n-i-1) iterations
                if (arr[j] > arr[j + 1]) {        // O(1) comparison
                    swap(arr, j, j + 1);          // O(1) swap
                    swapped = true;
                }
            }
            
            if (!swapped) break;  // Optimization: early termination
        }
        // Worst case: n*(n-1)/2 comparisons = O(n²)
        // Best case (sorted): O(n) with early termination
    }
    
    /**
     * Selection Sort - O(n²) Time, O(1) Space
     * Find minimum element and place it at beginning
     */
    public static void selectionSort(int[] arr) {
        int n = arr.length;
        
        for (int i = 0; i < n - 1; i++) {        // n-1 iterations
            int minIndex = i;
            
            for (int j = i + 1; j < n; j++) {    // (n-i-1) iterations
                if (arr[j] < arr[minIndex]) {     // O(1) comparison
                    minIndex = j;
                }
            }
            
            swap(arr, i, minIndex);              // O(1) swap
        }
        // Total comparisons: (n-1) + (n-2) + ... + 1 = n(n-1)/2 = O(n²)
        // Always O(n²) regardless of input
    }
    
    /**
     * All Pairs Sum - O(n²) Time, O(1) Space
     * Check all possible pairs of elements
     */
    public static void printAllPairs(int[] arr) {
        int n = arr.length;
        
        for (int i = 0; i < n; i++) {            // n iterations
            for (int j = i + 1; j < n; j++) {    // varies from (n-1) to 1
                System.out.println("Pair: " + arr[i] + ", " + arr[j]);  // O(1)
            }
        }
        // Total pairs: (n-1) + (n-2) + ... + 1 = n(n-1)/2 = O(n²)
    }
    
    /**
     * Matrix Multiplication - O(n³) Time, O(1) Space
     * Three nested loops for matrix multiplication
     */
    public static int[][] matrixMultiply(int[][] A, int[][] B) {
        int n = A.length;
        int[][] C = new int[n][n];  // O(n²) space
        
        for (int i = 0; i < n; i++) {        // n iterations
            for (int j = 0; j < n; j++) {    // n iterations
                for (int k = 0; k < n; k++) { // n iterations
                    C[i][j] += A[i][k] * B[k][j];  // O(1) operation
                }
            }
        }
        
        return C;
        // Total operations: n³ = O(n³)
        // Space: O(n²) for result matrix
    }
    
    // ==============================================
    // EXPONENTIAL TIME - O(2ⁿ) EXAMPLES
    // ==============================================
    
    /**
     * Naive Fibonacci - O(2ⁿ) Time, O(n) Space
     * Recursive solution with overlapping subproblems
     */
    public static long fibonacciNaive(int n) {
        if (n <= 1) return n;  // Base cases
        
        return fibonacciNaive(n - 1) + fibonacciNaive(n - 2);
        // Each call makes 2 recursive calls
        // Creates binary tree of depth n with ~2ⁿ nodes
        // Time: O(2ⁿ), Space: O(n) for call stack
    }
    
    /**
     * Generate All Subsets - O(2ⁿ) Time, O(2ⁿ) Space
     * Each element can be included or excluded
     */
    public static List<List<Integer>> generateSubsets(int[] nums) {
        List<List<Integer>> result = new ArrayList<>();
        generateSubsetsHelper(nums, 0, new ArrayList<>(), result);
        return result;
        // 2ⁿ possible subsets, each takes O(n) to create
        // Time: O(n * 2ⁿ), Space: O(2ⁿ) to store all subsets
    }
    
    private static void generateSubsetsHelper(int[] nums, int index, 
                                             List<Integer> current, 
                                             List<List<Integer>> result) {
        if (index == nums.length) {
            result.add(new ArrayList<>(current));  // O(n) to copy
            return;
        }
        
        // Exclude current element
        generateSubsetsHelper(nums, index + 1, current, result);
        
        // Include current element
        current.add(nums[index]);
        generateSubsetsHelper(nums, index + 1, current, result);
        current.remove(current.size() - 1);  // Backtrack
    }
    
    // ==============================================
    // OPTIMIZATION EXAMPLES
    // ==============================================
    
    /**
     * Fibonacci with Memoization - O(n) Time, O(n) Space
     * Trade space for time to avoid recomputation
     */
    private static Map<Integer, Long> fibMemo = new HashMap<>();
    
    public static long fibonacciMemo(int n) {
        if (n <= 1) return n;
        
        if (fibMemo.containsKey(n)) {
            return fibMemo.get(n);  // O(1) lookup
        }
        
        long result = fibonacciMemo(n - 1) + fibonacciMemo(n - 2);
        fibMemo.put(n, result);  // O(1) storage
        return result;
        // Each subproblem solved exactly once
        // Time: O(n), Space: O(n)
    }
    
    /**
     * Fibonacci Iterative - O(n) Time, O(1) Space
     * Bottom-up approach using only necessary space
     */
    public static long fibonacciIterative(int n) {
        if (n <= 1) return n;
        
        long prev1 = 0, prev2 = 1;  // O(1) space
        
        for (int i = 2; i <= n; i++) {  // n-1 iterations
            long current = prev1 + prev2;  // O(1) operation
            prev1 = prev2;
            prev2 = current;
        }
        
        return prev2;
        // Time: O(n), Space: O(1)
    }
    
    /**
     * Two Sum Problem - Multiple Approaches
     * Demonstrates different time-space trade-offs
     */
    
    // Approach 1: Brute Force - O(n²) Time, O(1) Space
    public static int[] twoSumBruteForce(int[] nums, int target) {
        for (int i = 0; i < nums.length; i++) {        // n iterations
            for (int j = i + 1; j < nums.length; j++) { // n iterations
                if (nums[i] + nums[j] == target) {       // O(1)
                    return new int[]{i, j};
                }
            }
        }
        return new int[]{};
        // Time: O(n²), Space: O(1)
    }
    
    // Approach 2: Hash Table - O(n) Time, O(n) Space
    public static int[] twoSumHashMap(int[] nums, int target) {
        Map<Integer, Integer> map = new HashMap<>();  // O(n) space worst case
        
        for (int i = 0; i < nums.length; i++) {      // n iterations
            int complement = target - nums[i];
            
            if (map.containsKey(complement)) {        // O(1) average
                return new int[]{map.get(complement), i};
            }
            
            map.put(nums[i], i);                     // O(1) average
        }
        
        return new int[]{};
        // Time: O(n), Space: O(n)
    }
    
    // Approach 3: Two Pointers (sorted array) - O(n) Time, O(1) Space
    public static int[] twoSumTwoPointers(int[] nums, int target) {
        // Assuming array is sorted or we sort it first
        // If we need to sort: O(n log n) time
        
        int left = 0, right = nums.length - 1;
        
        while (left < right) {                       // At most n iterations
            int sum = nums[left] + nums[right];
            
            if (sum == target) {                     // Found target
                return new int[]{left, right};
            } else if (sum < target) {               // Need larger sum
                left++;
            } else {                                 // Need smaller sum
                right--;
            }
        }
        
        return new int[]{};
        // Time: O(n) if sorted, O(n log n) if need to sort
        // Space: O(1)
    }
    
    // ==============================================
    // COMPLEXITY COMPARISON DEMONSTRATIONS
    // ==============================================
    
    /**
     * Performance Testing Framework
     * Compare different algorithms with various input sizes
     */
    public static void performanceComparison() {
        System.out.println("Algorithm Performance Comparison");
        System.out.println("=================================");
        
        int[] testSizes = {100, 1000, 5000, 10000};
        
        for (int size : testSizes) {
            System.out.println("\nInput Size: " + size);
            
            // Generate test data
            int[] arr = generateRandomArray(size);
            int[] sortedArr = arr.clone();
            Arrays.sort(sortedArr);
            
            // Test linear search vs binary search
            int target = arr[size / 2];
            
            long startTime, endTime;
            
            // Linear Search
            startTime = System.nanoTime();
            linearSearch(arr, target);
            endTime = System.nanoTime();
            System.out.println("Linear Search: " + (endTime - startTime) + " ns");
            
            // Binary Search
            startTime = System.nanoTime();
            binarySearchIterative(sortedArr, target);
            endTime = System.nanoTime();
            System.out.println("Binary Search: " + (endTime - startTime) + " ns");
            
            // Sorting comparison (small arrays only)
            if (size <= 5000) {
                int[] bubbleArr = arr.clone();
                int[] mergeArr = arr.clone();
                
                // Bubble Sort
                startTime = System.nanoTime();
                bubbleSort(bubbleArr);
                endTime = System.nanoTime();
                System.out.println("Bubble Sort: " + (endTime - startTime) + " ns");
                
                // Merge Sort
                startTime = System.nanoTime();
                mergeSort(mergeArr, 0, mergeArr.length - 1);
                endTime = System.nanoTime();
                System.out.println("Merge Sort: " + (endTime - startTime) + " ns");
            }
        }
    }
    
    private static int[] generateRandomArray(int size) {
        int[] arr = new int[size];
        Random random = new Random();
        for (int i = 0; i < size; i++) {
            arr[i] = random.nextInt(1000);
        }
        return arr;
    }
    
    // ==============================================
    // UTILITY METHODS
    // ==============================================
    
    private static void swap(int[] arr, int i, int j) {
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }
    
    private static void printArray(int[] arr, String label) {
        System.out.print(label + ": ");
        for (int num : arr) {
            System.out.print(num + " ");
        }
        System.out.println();
    }
    
    // ==============================================
    // MAIN METHOD - DEMONSTRATIONS
    // ==============================================
    
    public static void main(String[] args) {
        System.out.println("Time and Space Complexity Examples");
        System.out.println("===================================");
        
        // Demo 1: Constant Time Operations
        System.out.println("\n1. Constant Time O(1) Examples:");
        int[] testArr = {1, 2, 3, 4, 5};
        System.out.println("Array element at index 2: " + getArrayElement(testArr, 2));
        System.out.println("Sum of 5 + 3: " + addNumbers(5, 3));
        
        // Demo 2: Logarithmic Time Operations
        System.out.println("\n2. Logarithmic Time O(log n) Examples:");
        int[] sortedArray = {1, 3, 5, 7, 9, 11, 13, 15, 17, 19};
        int target = 11;
        int index = binarySearchIterative(sortedArray, target);
        System.out.println("Binary search for " + target + " found at index: " + index);
        
        // Demo 3: Linear Time Operations
        System.out.println("\n3. Linear Time O(n) Examples:");
        int[] unsortedArray = {5, 2, 8, 1, 9, 3};
        System.out.println("Maximum element: " + findMax(unsortedArray));
        System.out.println("Array sum: " + arraySum(unsortedArray));
        
        // Demo 4: Quadratic Time Operations
        System.out.println("\n4. Quadratic Time O(n²) Examples:");
        int[] bubbleArray = unsortedArray.clone();
        printArray(bubbleArray, "Before bubble sort");
        bubbleSort(bubbleArray);
        printArray(bubbleArray, "After bubble sort");
        
        // Demo 5: Different Sorting Algorithms Comparison
        System.out.println("\n5. Sorting Algorithms Comparison:");
        int[] arr1 = {64, 34, 25, 12, 22, 11, 90};
        int[] arr2 = arr1.clone();
        
        System.out.println("Original array: " + Arrays.toString(arr1));
        
        // Selection Sort
        selectionSort(arr1);
        System.out.println("Selection Sort: " + Arrays.toString(arr1));
        
        // Merge Sort
        mergeSort(arr2, 0, arr2.length - 1);
        System.out.println("Merge Sort: " + Arrays.toString(arr2));
        
        // Demo 6: Fibonacci Comparison
        System.out.println("\n6. Fibonacci Algorithms Comparison:");
        int n = 10;
        
        long start = System.nanoTime();
        long result1 = fibonacciIterative(n);
        long end = System.nanoTime();
        System.out.println("Fibonacci(" + n + ") iterative: " + result1 + 
                          " (Time: " + (end - start) + " ns)");
        
        start = System.nanoTime();
        long result2 = fibonacciMemo(n);
        end = System.nanoTime();
        System.out.println("Fibonacci(" + n + ") memoized: " + result2 + 
                          " (Time: " + (end - start) + " ns)");
        
        // Note: Don't test naive fibonacci with large n - it's too slow!
        if (n <= 20) {
            fibMemo.clear(); // Clear memoization for fair comparison
            start = System.nanoTime();
            long result3 = fibonacciNaive(n);
            end = System.nanoTime();
            System.out.println("Fibonacci(" + n + ") naive: " + result3 + 
                              " (Time: " + (end - start) + " ns)");
        }
        
        // Demo 7: Two Sum Approaches
        System.out.println("\n7. Two Sum Problem Approaches:");
        int[] nums = {2, 7, 11, 15};
        int sum = 9;
        
        int[] result = twoSumHashMap(nums, sum);
        System.out.println("Two Sum (HashMap): indices " + 
                          Arrays.toString(result) + " sum to " + sum);
        
        // Demo 8: Space-Time Trade-offs
        System.out.println("\n8. Space-Time Trade-offs:");
        System.out.println("Problem: Find if array has duplicates");
        
        int[] duplicateTest = {1, 2, 3, 4, 5, 3, 6};
        
        // Time-optimized approach (using extra space)
        Set<Integer> seen = new HashSet<>();
        boolean hasDuplicates = false;
        for (int num : duplicateTest) {
            if (seen.contains(num)) {
                hasDuplicates = true;
                break;
            }
            seen.add(num);
        }
        System.out.println("Using HashSet (O(n) time, O(n) space): " + hasDuplicates);
        
        // Space-optimized approach (using more time)
        hasDuplicates = false;
        for (int i = 0; i < duplicateTest.length && !hasDuplicates; i++) {
            for (int j = i + 1; j < duplicateTest.length; j++) {
                if (duplicateTest[i] == duplicateTest[j]) {
                    hasDuplicates = true;
                    break;
                }
            }
        }
        System.out.println("Using nested loops (O(n²) time, O(1) space): " + hasDuplicates);
        
        System.out.println("\nComplexity analysis demonstration completed!");
        
        // Uncomment to run performance comparison
        // performanceComparison();
    }
}

/**
 * COMPLEXITY SUMMARY TABLE
 * ========================
 * 
 * Algorithm                    | Time Complexity | Space Complexity | Notes
 * ----------------------------|-----------------|------------------|--------
 * Array Access                | O(1)            | O(1)             | Direct indexing
 * Binary Search (Iterative)   | O(log n)        | O(1)             | Divide and conquer
 * Binary Search (Recursive)   | O(log n)        | O(log n)         | Call stack space
 * Linear Search               | O(n)            | O(1)             | May check all elements
 * Array Sum                   | O(n)            | O(1)             | Visit each element once
 * Bubble Sort                 | O(n²)           | O(1)             | Nested loops
 * Selection Sort              | O(n²)           | O(1)             | Always quadratic
 * Merge Sort                  | O(n log n)      | O(n)             | Optimal comparison sort
 * Heap Sort                   | O(n log n)      | O(1)             | In-place sorting
 * Fibonacci (Naive)           | O(2ⁿ)           | O(n)             | Exponential explosion
 * Fibonacci (Memoized)        | O(n)            | O(n)             | Trade space for time
 * Fibonacci (Iterative)       | O(n)            | O(1)             | Optimal approach
 * Two Sum (Brute Force)       | O(n²)           | O(1)             | Check all pairs
 * Two Sum (HashMap)           | O(n)            | O(n)             | Trade space for time
 * 
 * KEY INSIGHTS:
 * 1. Often can trade space for time (memoization, hash tables)
 * 2. Recursive solutions may use more space due to call stack
 * 3. In-place algorithms save space but may be more complex
 * 4. Asymptotic analysis helps choose best algorithm for large inputs
 * 5. Constants matter for small inputs, but Big O dominates for large inputs
 */
