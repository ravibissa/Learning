# Time and Space Complexity - Complete Guide

## Table of Contents
1. [Introduction to Algorithm Analysis](#introduction-to-algorithm-analysis)
2. [Big O Notation](#big-o-notation)
3. [Time Complexity Analysis](#time-complexity-analysis)
4. [Space Complexity Analysis](#space-complexity-analysis)
5. [Common Complexity Classes](#common-complexity-classes)
6. [Analyzing Data Structures](#analyzing-data-structures)
7. [Analyzing Algorithms](#analyzing-algorithms)
8. [Optimization Techniques](#optimization-techniques)
9. [Practice Problems](#practice-problems)
10. [Interview Questions](#interview-questions)

## Introduction to Algorithm Analysis

### Why Analyze Algorithms?
Algorithm analysis helps us understand:
- **Performance**: How fast does the algorithm run?
- **Scalability**: How does performance change with input size?
- **Resource Usage**: How much memory does it need?
- **Efficiency**: Can we do better?

**Real-world example:** 
- A search algorithm that works fine for 100 items might be too slow for 1 million items
- An algorithm using 1GB memory for small data might crash with larger datasets

### What We Measure
1. **Time Complexity**: How execution time grows with input size
2. **Space Complexity**: How memory usage grows with input size
3. **Best/Average/Worst Case**: Different scenarios for the same algorithm

### Mathematical Foundation
We use **asymptotic notation** to describe algorithm efficiency:
- **Upper Bound (Big O)**: Worst-case scenario
- **Lower Bound (Big Omega Ω)**: Best-case scenario  
- **Tight Bound (Big Theta Θ)**: Average-case scenario

## Big O Notation

### What is Big O?
Big O notation describes the **worst-case** time or space complexity of an algorithm as the input size approaches infinity.

**Think of it like:** Speed limits on roads
- O(1): Express lane - constant speed regardless of traffic
- O(log n): Highway with smart routing - efficiency improves with size
- O(n): City street - time proportional to distance
- O(n²): Traffic jam - time increases quadratically

### Formal Definition
f(n) = O(g(n)) if there exist positive constants c and n₀ such that:
f(n) ≤ c × g(n) for all n ≥ n₀

**Simple explanation:** f(n) grows no faster than g(n) for large values of n.

### Big O Rules

#### 1. Drop Constants
- O(2n) → O(n)
- O(5) → O(1)
- O(n/2) → O(n)

**Why?** Constants don't affect the growth rate for large inputs.

#### 2. Drop Lower-Order Terms
- O(n² + n) → O(n²)
- O(n³ + n² + n + 1) → O(n³)
- O(log n + 1) → O(log n)

**Why?** Higher-order terms dominate for large inputs.

#### 3. Different Variables
- O(a + b) for sequential operations
- O(a × b) for nested operations

```java
// O(a + b) - sequential
for (int i = 0; i < a; i++) { /* work */ }
for (int j = 0; j < b; j++) { /* work */ }

// O(a × b) - nested
for (int i = 0; i < a; i++) {
    for (int j = 0; j < b; j++) { /* work */ }
}
```

## Time Complexity Analysis

### Common Time Complexities (Best to Worst)

#### 1. O(1) - Constant Time
**Definition:** Execution time doesn't change with input size.

**Examples:**
- Array access by index: `arr[5]`
- HashMap get/put operations
- Mathematical calculations
- Variable assignment

```java
// O(1) examples
public int getFirst(int[] arr) {
    return arr[0];  // Always one operation
}

public int add(int a, int b) {
    return a + b;   // Always one operation
}
```

**Real-world analogy:** Light switch - takes same time regardless of room size.

#### 2. O(log n) - Logarithmic Time
**Definition:** Time increases logarithmically with input size.

**Examples:**
- Binary search in sorted array
- Balanced tree operations (BST, Heap)
- Divide and conquer algorithms

```java
// O(log n) - Binary Search
public int binarySearch(int[] arr, int target) {
    int left = 0, right = arr.length - 1;
    
    while (left <= right) {
        int mid = left + (right - left) / 2;
        if (arr[mid] == target) return mid;
        else if (arr[mid] < target) left = mid + 1;
        else right = mid - 1;
    }
    return -1;
}
```

**Why log n?** Each step eliminates half the remaining possibilities.

**Real-world analogy:** Phone book search - open to middle, eliminate half, repeat.

#### 3. O(n) - Linear Time
**Definition:** Time increases linearly with input size.

**Examples:**
- Linear search
- Array traversal
- Linked list operations
- Simple loops

```java
// O(n) examples
public int findMax(int[] arr) {
    int max = arr[0];
    for (int i = 1; i < arr.length; i++) {  // n iterations
        if (arr[i] > max) max = arr[i];
    }
    return max;
}

public boolean contains(int[] arr, int target) {
    for (int num : arr) {  // potentially check all n elements
        if (num == target) return true;
    }
    return false;
}
```

**Real-world analogy:** Reading a book - time proportional to number of pages.

#### 4. O(n log n) - Linearithmic Time
**Definition:** Combination of linear and logarithmic growth.

**Examples:**
- Efficient sorting algorithms (Merge Sort, Heap Sort)
- Many divide-and-conquer algorithms

```java
// O(n log n) - Merge Sort
public void mergeSort(int[] arr, int left, int right) {
    if (left < right) {
        int mid = left + (right - left) / 2;
        
        mergeSort(arr, left, mid);      // T(n/2)
        mergeSort(arr, mid + 1, right); // T(n/2)
        merge(arr, left, mid, right);   // O(n)
    }
    // Total: T(n) = 2T(n/2) + O(n) = O(n log n)
}
```

**Why n log n?** Divide problem log n times, each level does O(n) work.

**Real-world analogy:** Organizing library - divide books into groups, sort each group.

#### 5. O(n²) - Quadratic Time
**Definition:** Time increases quadratically with input size.

**Examples:**
- Nested loops over input
- Bubble Sort, Selection Sort
- Brute force algorithms

```java
// O(n²) examples
public void bubbleSort(int[] arr) {
    int n = arr.length;
    for (int i = 0; i < n - 1; i++) {        // n iterations
        for (int j = 0; j < n - i - 1; j++) { // n iterations
            if (arr[j] > arr[j + 1]) {
                // swap
                int temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
}

public int[] allPairs(int[] arr) {
    for (int i = 0; i < arr.length; i++) {     // n iterations
        for (int j = 0; j < arr.length; j++) { // n iterations
            System.out.println(arr[i] + ", " + arr[j]);
        }
    }
}
```

**Real-world analogy:** Handshaking at party - everyone shakes hands with everyone else.

#### 6. O(2ⁿ) - Exponential Time
**Definition:** Time doubles with each additional input element.

**Examples:**
- Recursive Fibonacci (naive implementation)
- Brute force password cracking
- Subset generation

```java
// O(2^n) - Naive Fibonacci
public int fibonacci(int n) {
    if (n <= 1) return n;
    return fibonacci(n - 1) + fibonacci(n - 2);  // Two recursive calls
}

// Each call makes 2 more calls, creating 2^n total calls
```

**Real-world analogy:** Chain letter - each person sends to 2 people, exponential growth.

#### 7. O(n!) - Factorial Time
**Definition:** Time grows factorially with input size.

**Examples:**
- Traveling Salesman Problem (brute force)
- Generating all permutations

```java
// O(n!) - All Permutations
public void permute(String str, int l, int r) {
    if (l == r) {
        System.out.println(str);
    } else {
        for (int i = l; i <= r; i++) {  // n choices, then n-1, then n-2...
            str = swap(str, l, i);
            permute(str, l + 1, r);      // Recursive call
            str = swap(str, l, i);       // Backtrack
        }
    }
}
```

**Real-world analogy:** Arranging books on shelf - n! different arrangements possible.

### Complexity Comparison

| Input Size (n) | O(1) | O(log n) | O(n) | O(n log n) | O(n²) | O(2ⁿ) | O(n!) |
|----------------|------|----------|------|------------|-------|-------|-------|
| 1              | 1    | 0        | 1    | 0          | 1     | 2     | 1     |
| 10             | 1    | 3        | 10   | 33         | 100   | 1,024 | 3.6M  |
| 100            | 1    | 7        | 100  | 664        | 10K   | 10³⁰  | 10¹⁵⁷ |
| 1,000          | 1    | 10       | 1K   | 9.9K       | 1M    | ∞     | ∞     |
| 10,000         | 1    | 13       | 10K  | 132K       | 100M  | ∞     | ∞     |

### Time Complexity Analysis Steps

#### Step 1: Identify Basic Operations
Look for the most frequent operation in your algorithm:
- Comparisons in sorting
- Array accesses in searching
- Arithmetic operations in calculations

#### Step 2: Count Operations
- **Sequential statements:** Add complexities
- **Conditional statements:** Take the worse case
- **Loops:** Multiply by number of iterations
- **Recursive calls:** Use recurrence relations

#### Step 3: Express in Big O
- Drop constants and lower-order terms
- Consider worst-case scenario

### Examples of Time Complexity Analysis

#### Example 1: Simple Loop
```java
public void example1(int n) {
    for (int i = 0; i < n; i++) {     // n iterations
        System.out.println(i);        // O(1) operation
    }
}
// Time Complexity: O(n)
```

#### Example 2: Nested Loops
```java
public void example2(int n) {
    for (int i = 0; i < n; i++) {     // n iterations
        for (int j = 0; j < n; j++) { // n iterations for each i
            System.out.println(i + j); // O(1) operation
        }
    }
}
// Time Complexity: O(n × n) = O(n²)
```

#### Example 3: Logarithmic Loop
```java
public void example3(int n) {
    for (int i = 1; i < n; i *= 2) { // log₂(n) iterations
        System.out.println(i);        // O(1) operation
    }
}
// Time Complexity: O(log n)
```

#### Example 4: Dependent Nested Loops
```java
public void example4(int n) {
    for (int i = 0; i < n; i++) {       // n iterations
        for (int j = i; j < n; j++) {   // (n-i) iterations
            System.out.println(i + j);   // O(1) operation
        }
    }
}
// Total iterations: n + (n-1) + (n-2) + ... + 1 = n(n+1)/2
// Time Complexity: O(n²)
```

#### Example 5: Multiple Loops
```java
public void example5(int n) {
    for (int i = 0; i < n; i++) {     // O(n)
        System.out.println(i);
    }
    
    for (int i = 0; i < n; i++) {     // O(n)
        for (int j = 0; j < n; j++) { // O(n)
            System.out.println(i + j);
        }
    }
}
// Time Complexity: O(n) + O(n²) = O(n²)
```

## Space Complexity Analysis

### What is Space Complexity?
Space complexity measures the amount of memory an algorithm uses relative to input size.

### Types of Space Usage

#### 1. Input Space
Space required to store the input data.
- Usually not counted in space complexity analysis
- Sometimes called "auxiliary space" when excluded

#### 2. Auxiliary Space
Extra space used by the algorithm (excluding input).
- Local variables
- Recursive call stack
- Data structures created during execution

#### 3. Output Space
Space required to store the output.
- Sometimes counted, sometimes not
- Depends on the context and problem requirements

### Common Space Complexities

#### O(1) - Constant Space
**Definition:** Memory usage doesn't change with input size.

```java
// O(1) space examples
public int findMax(int[] arr) {
    int max = arr[0];        // O(1) extra space
    for (int i = 1; i < arr.length; i++) {
        if (arr[i] > max) {
            max = arr[i];
        }
    }
    return max;
}

public void swap(int[] arr, int i, int j) {
    int temp = arr[i];       // O(1) extra space
    arr[i] = arr[j];
    arr[j] = temp;
}
```

#### O(n) - Linear Space
**Definition:** Memory usage grows linearly with input size.

```java
// O(n) space examples
public int[] createCopy(int[] arr) {
    int[] copy = new int[arr.length];  // O(n) space
    for (int i = 0; i < arr.length; i++) {
        copy[i] = arr[i];
    }
    return copy;
}

public int fibonacci(int n) {
    if (n <= 1) return n;
    return fibonacci(n - 1) + fibonacci(n - 2);
    // Recursive call stack depth = O(n) space
}
```

#### O(log n) - Logarithmic Space
**Definition:** Memory usage grows logarithmically with input size.

```java
// O(log n) space - Binary Search (recursive)
public int binarySearch(int[] arr, int target, int left, int right) {
    if (left > right) return -1;
    
    int mid = left + (right - left) / 2;
    if (arr[mid] == target) return mid;
    else if (arr[mid] < target) 
        return binarySearch(arr, target, mid + 1, right);
    else 
        return binarySearch(arr, target, left, mid - 1);
}
// Call stack depth = O(log n)
```

### Space-Time Trade-offs

Often, you can trade space for time or vice versa:

#### Example: Fibonacci Sequence

**Time-Optimized (High Space):**
```java
// O(n) time, O(n) space - Memoization
Map<Integer, Long> memo = new HashMap<>();

public long fibonacci(int n) {
    if (n <= 1) return n;
    if (memo.containsKey(n)) return memo.get(n);
    
    long result = fibonacci(n - 1) + fibonacci(n - 2);
    memo.put(n, result);
    return result;
}
```

**Space-Optimized (Lower Space):**
```java
// O(n) time, O(1) space - Iterative
public long fibonacci(int n) {
    if (n <= 1) return n;
    
    long prev1 = 0, prev2 = 1;
    for (int i = 2; i <= n; i++) {
        long current = prev1 + prev2;
        prev1 = prev2;
        prev2 = current;
    }
    return prev2;
}
```

## Common Complexity Classes

### Polynomial Time (P)
Algorithms that run in polynomial time: O(nᵏ) for some constant k.
- **Tractable**: Can be solved efficiently for reasonable input sizes
- **Examples**: Sorting (O(n log n)), Matrix multiplication (O(n³))

### Exponential Time
Algorithms that run in exponential time: O(k^n) for some constant k > 1.
- **Intractable**: Become impractical for large inputs very quickly
- **Examples**: Traveling Salesman (brute force), Subset Sum (brute force)

### NP (Non-deterministic Polynomial)
Problems for which a solution can be verified in polynomial time.
- **Examples**: Traveling Salesman, Knapsack, Graph Coloring
- **Important**: P ⊆ NP, but whether P = NP is unknown

### NP-Complete
The hardest problems in NP - if any NP-complete problem can be solved in polynomial time, then P = NP.

### NP-Hard
Problems at least as hard as NP-complete problems.

## Analyzing Data Structures

### Array Operations

| Operation | Time Complexity | Space Complexity |
|-----------|----------------|------------------|
| Access    | O(1)           | O(1)             |
| Search    | O(n)           | O(1)             |
| Insertion | O(n)           | O(1)             |
| Deletion  | O(n)           | O(1)             |

### Linked List Operations

| Operation | Time Complexity | Space Complexity |
|-----------|----------------|------------------|
| Access    | O(n)           | O(1)             |
| Search    | O(n)           | O(1)             |
| Insertion | O(1)*          | O(1)             |
| Deletion  | O(1)*          | O(1)             |

*If you have reference to the node

### Stack/Queue Operations

| Operation | Time Complexity | Space Complexity |
|-----------|----------------|------------------|
| Push/Enqueue | O(1)        | O(1)             |
| Pop/Dequeue  | O(1)        | O(1)             |
| Peek/Front   | O(1)        | O(1)             |

### Binary Search Tree (Balanced)

| Operation | Average | Worst Case | Space |
|-----------|---------|------------|-------|
| Search    | O(log n)| O(n)       | O(1)  |
| Insert    | O(log n)| O(n)       | O(1)  |
| Delete    | O(log n)| O(n)       | O(1)  |

### Hash Table

| Operation | Average | Worst Case | Space |
|-----------|---------|------------|-------|
| Search    | O(1)    | O(n)       | O(n)  |
| Insert    | O(1)    | O(n)       | O(n)  |
| Delete    | O(1)    | O(n)       | O(n)  |

### Heap (Binary)

| Operation | Time Complexity | Space Complexity |
|-----------|----------------|------------------|
| Find Max/Min | O(1)        | O(1)             |
| Insert    | O(log n)       | O(1)             |
| Delete Max/Min | O(log n)   | O(1)             |
| Build Heap| O(n)           | O(1)             |

## Analyzing Algorithms

### Sorting Algorithms

| Algorithm     | Best    | Average | Worst   | Space   | Stable |
|---------------|---------|---------|---------|---------|--------|
| Bubble Sort   | O(n)    | O(n²)   | O(n²)   | O(1)    | Yes    |
| Selection Sort| O(n²)   | O(n²)   | O(n²)   | O(1)    | No     |
| Insertion Sort| O(n)    | O(n²)   | O(n²)   | O(1)    | Yes    |
| Merge Sort    | O(n log n)| O(n log n)| O(n log n)| O(n)| Yes  |
| Quick Sort    | O(n log n)| O(n log n)| O(n²)  | O(log n)| No   |
| Heap Sort     | O(n log n)| O(n log n)| O(n log n)| O(1)| No   |

### Searching Algorithms

| Algorithm | Time Complexity | Space Complexity | Requirements |
|-----------|----------------|------------------|--------------|
| Linear Search | O(n)      | O(1)             | None         |
| Binary Search | O(log n)  | O(1)             | Sorted array |
| Hash Table    | O(1) avg  | O(n)             | Hash function|

### Graph Algorithms

| Algorithm | Time Complexity | Space Complexity |
|-----------|----------------|------------------|
| DFS       | O(V + E)       | O(V)             |
| BFS       | O(V + E)       | O(V)             |
| Dijkstra  | O((V + E) log V)| O(V)            |
| Bellman-Ford | O(VE)       | O(V)             |
| Floyd-Warshall | O(V³)     | O(V²)            |

## Optimization Techniques

### 1. Memoization
**Trade space for time** by caching computed results.

```java
// Without memoization: O(2^n) time
public int fibonacci(int n) {
    if (n <= 1) return n;
    return fibonacci(n - 1) + fibonacci(n - 2);
}

// With memoization: O(n) time, O(n) space
Map<Integer, Integer> memo = new HashMap<>();
public int fibonacciMemo(int n) {
    if (n <= 1) return n;
    if (memo.containsKey(n)) return memo.get(n);
    
    int result = fibonacciMemo(n - 1) + fibonacciMemo(n - 2);
    memo.put(n, result);
    return result;
}
```

### 2. Two Pointers Technique
**Reduce time complexity** by using two pointers instead of nested loops.

```java
// Brute force: O(n²)
public boolean hasPairSum(int[] arr, int target) {
    for (int i = 0; i < arr.length; i++) {
        for (int j = i + 1; j < arr.length; j++) {
            if (arr[i] + arr[j] == target) return true;
        }
    }
    return false;
}

// Two pointers (sorted array): O(n)
public boolean hasPairSumOptimized(int[] arr, int target) {
    int left = 0, right = arr.length - 1;
    while (left < right) {
        int sum = arr[left] + arr[right];
        if (sum == target) return true;
        else if (sum < target) left++;
        else right--;
    }
    return false;
}
```

### 3. Sliding Window
**Optimize problems** involving subarrays or substrings.

```java
// Brute force: O(n²)
public int maxSubarraySum(int[] arr, int k) {
    int maxSum = Integer.MIN_VALUE;
    for (int i = 0; i <= arr.length - k; i++) {
        int currentSum = 0;
        for (int j = i; j < i + k; j++) {
            currentSum += arr[j];
        }
        maxSum = Math.max(maxSum, currentSum);
    }
    return maxSum;
}

// Sliding window: O(n)
public int maxSubarraySumOptimized(int[] arr, int k) {
    int windowSum = 0;
    for (int i = 0; i < k; i++) {
        windowSum += arr[i];
    }
    
    int maxSum = windowSum;
    for (int i = k; i < arr.length; i++) {
        windowSum = windowSum - arr[i - k] + arr[i];
        maxSum = Math.max(maxSum, windowSum);
    }
    return maxSum;
}
```

### 4. Early Termination
**Stop computation** when answer is found.

```java
// Search with early termination
public boolean contains(int[] arr, int target) {
    for (int num : arr) {
        if (num == target) return true; // Early termination
    }
    return false;
}
```

### 5. Space-Time Trade-offs
**Use extra space** to reduce time complexity.

```java
// Time-optimized: O(n) time, O(n) space
public boolean hasDuplicates(int[] arr) {
    Set<Integer> seen = new HashSet<>();
    for (int num : arr) {
        if (seen.contains(num)) return true;
        seen.add(num);
    }
    return false;
}

// Space-optimized: O(n²) time, O(1) space
public boolean hasDuplicatesSpaceOptimized(int[] arr) {
    for (int i = 0; i < arr.length; i++) {
        for (int j = i + 1; j < arr.length; j++) {
            if (arr[i] == arr[j]) return true;
        }
    }
    return false;
}
```

## Practice Problems

### Easy Level

#### 1. Array Sum
```java
// Problem: Find sum of all elements in array
// Analyze time and space complexity

public int arraySum(int[] arr) {
    int sum = 0;                    // O(1) space
    for (int i = 0; i < arr.length; i++) {  // O(n) time
        sum += arr[i];              // O(1) operation
    }
    return sum;
}
// Time: O(n), Space: O(1)
```

#### 2. Find Maximum
```java
// Problem: Find maximum element in array
// Analyze time and space complexity

public int findMax(int[] arr) {
    int max = arr[0];               // O(1) space
    for (int i = 1; i < arr.length; i++) {  // O(n) time
        if (arr[i] > max) {         // O(1) operation
            max = arr[i];
        }
    }
    return max;
}
// Time: O(n), Space: O(1)
```

### Medium Level

#### 3. Two Sum
```java
// Problem: Find two numbers that add up to target
// Compare different approaches

// Approach 1: Brute Force
public int[] twoSum1(int[] nums, int target) {
    for (int i = 0; i < nums.length; i++) {         // O(n)
        for (int j = i + 1; j < nums.length; j++) { // O(n)
            if (nums[i] + nums[j] == target) {       // O(1)
                return new int[]{i, j};
            }
        }
    }
    return new int[]{};
}
// Time: O(n²), Space: O(1)

// Approach 2: Hash Table
public int[] twoSum2(int[] nums, int target) {
    Map<Integer, Integer> map = new HashMap<>();     // O(n) space
    for (int i = 0; i < nums.length; i++) {        // O(n) time
        int complement = target - nums[i];
        if (map.containsKey(complement)) {          // O(1) average
            return new int[]{map.get(complement), i};
        }
        map.put(nums[i], i);                       // O(1) average
    }
    return new int[]{};
}
// Time: O(n), Space: O(n)
```

#### 4. Merge Sorted Arrays
```java
// Problem: Merge two sorted arrays
// Analyze different approaches

// Approach 1: Create new array
public int[] merge1(int[] nums1, int[] nums2) {
    int[] result = new int[nums1.length + nums2.length]; // O(m+n) space
    int i = 0, j = 0, k = 0;
    
    while (i < nums1.length && j < nums2.length) {      // O(m+n) time
        if (nums1[i] <= nums2[j]) {
            result[k++] = nums1[i++];
        } else {
            result[k++] = nums2[j++];
        }
    }
    
    while (i < nums1.length) result[k++] = nums1[i++];
    while (j < nums2.length) result[k++] = nums2[j++];
    
    return result;
}
// Time: O(m + n), Space: O(m + n)
```

### Hard Level

#### 5. Longest Palindromic Substring
```java
// Problem: Find longest palindromic substring
// Compare different approaches

// Approach 1: Brute Force
public String longestPalindrome1(String s) {
    String longest = "";
    for (int i = 0; i < s.length(); i++) {          // O(n)
        for (int j = i; j < s.length(); j++) {      // O(n)
            String substr = s.substring(i, j + 1);   // O(n)
            if (isPalindrome(substr) && substr.length() > longest.length()) { // O(n)
                longest = substr;
            }
        }
    }
    return longest;
}

private boolean isPalindrome(String s) {            // O(n)
    int left = 0, right = s.length() - 1;
    while (left < right) {
        if (s.charAt(left++) != s.charAt(right--)) return false;
    }
    return true;
}
// Time: O(n³), Space: O(1)

// Approach 2: Expand Around Centers
public String longestPalindrome2(String s) {
    String longest = "";
    for (int i = 0; i < s.length(); i++) {          // O(n)
        // Odd length palindromes
        String odd = expandAroundCenter(s, i, i);    // O(n)
        // Even length palindromes  
        String even = expandAroundCenter(s, i, i + 1); // O(n)
        
        String current = odd.length() > even.length() ? odd : even;
        if (current.length() > longest.length()) {
            longest = current;
        }
    }
    return longest;
}

private String expandAroundCenter(String s, int left, int right) {
    while (left >= 0 && right < s.length() && s.charAt(left) == s.charAt(right)) {
        left--;
        right++;
    }
    return s.substring(left + 1, right);
}
// Time: O(n²), Space: O(1)
```

## Interview Questions

### Question Types

#### 1. Direct Complexity Questions
- "What is the time complexity of this algorithm?"
- "How much space does this solution use?"
- "What's the worst-case scenario?"

#### 2. Optimization Questions
- "Can you optimize this solution?"
- "Is there a way to reduce space complexity?"
- "What trade-offs would you consider?"

#### 3. Comparison Questions
- "Compare these two approaches"
- "When would you use approach A vs approach B?"
- "What are the pros and cons?"

### Sample Interview Problems

#### Problem 1: Array Rotation
**Question:** Rotate array to the right by k steps. Analyze complexity.

```java
// Approach 1: Extra Array
public void rotate1(int[] nums, int k) {
    int n = nums.length;
    int[] result = new int[n];               // O(n) space
    for (int i = 0; i < n; i++) {           // O(n) time
        result[(i + k) % n] = nums[i];       // O(1) operation
    }
    System.arraycopy(result, 0, nums, 0, n); // O(n) time
}
// Time: O(n), Space: O(n)

// Approach 2: Reverse Method
public void rotate2(int[] nums, int k) {
    k %= nums.length;
    reverse(nums, 0, nums.length - 1);      // O(n) time, O(1) space
    reverse(nums, 0, k - 1);                // O(k) time, O(1) space
    reverse(nums, k, nums.length - 1);      // O(n-k) time, O(1) space
}

private void reverse(int[] nums, int start, int end) {
    while (start < end) {
        int temp = nums[start];
        nums[start] = nums[end];
        nums[end] = temp;
        start++;
        end--;
    }
}
// Time: O(n), Space: O(1)
```

**Analysis:**
- Both solutions have O(n) time complexity
- Approach 1 uses O(n) extra space
- Approach 2 uses O(1) extra space
- Approach 2 is more space-efficient

#### Problem 2: Find Duplicates
**Question:** Find all duplicates in array where 1 ≤ a[i] ≤ n.

```java
// Approach 1: Hash Set
public List<Integer> findDuplicates1(int[] nums) {
    Set<Integer> seen = new HashSet<>();        // O(n) space
    List<Integer> duplicates = new ArrayList<>();
    
    for (int num : nums) {                      // O(n) time
        if (seen.contains(num)) {               // O(1) average
            duplicates.add(num);
        } else {
            seen.add(num);                      // O(1) average
        }
    }
    return duplicates;
}
// Time: O(n), Space: O(n)

// Approach 2: Index Marking (using array constraints)
public List<Integer> findDuplicates2(int[] nums) {
    List<Integer> duplicates = new ArrayList<>();
    
    for (int i = 0; i < nums.length; i++) {    // O(n) time
        int index = Math.abs(nums[i]) - 1;
        if (nums[index] < 0) {
            duplicates.add(Math.abs(nums[i]));
        } else {
            nums[index] = -nums[index];
        }
    }
    return duplicates;
}
// Time: O(n), Space: O(1)
```

### Tips for Complexity Analysis in Interviews

#### 1. Think Out Loud
- Explain your thought process
- Identify the dominant operations
- Consider different input scenarios

#### 2. Start with Brute Force
- Always have a working solution first
- Then optimize step by step
- Explain the trade-offs

#### 3. Consider All Cases
- Best case, average case, worst case
- Different input sizes and patterns
- Edge cases and constraints

#### 4. Use Examples
- Walk through small examples
- Count operations step by step
- Visualize the algorithm if helpful

#### 5. Be Precise
- Use proper Big O notation
- Distinguish between time and space
- Consider auxiliary vs input space

### Common Mistakes to Avoid

#### 1. Confusing Time and Space
```java
// This is O(n) time, O(1) space, not O(n) space
public int sum(int[] arr) {
    int total = 0;  // O(1) space
    for (int num : arr) {  // O(n) time
        total += num;
    }
    return total;
}
```

#### 2. Not Considering Recursion Stack
```java
// This is O(n) space due to call stack, not O(1)
public int factorial(int n) {
    if (n <= 1) return 1;
    return n * factorial(n - 1);  // O(n) recursive calls
}
```

#### 3. Ignoring Hidden Complexity
```java
// substring() creates new string - O(n) time and space
// This is O(n³) overall, not O(n²)
for (int i = 0; i < s.length(); i++) {      // O(n)
    for (int j = i; j < s.length(); j++) {  // O(n)
        String substr = s.substring(i, j);   // O(n) hidden complexity!
        // process substr
    }
}
```

## Summary and Key Takeaways

### Essential Concepts
1. **Big O Notation**: Describes upper bound of algorithm efficiency
2. **Time Complexity**: How execution time scales with input size
3. **Space Complexity**: How memory usage scales with input size
4. **Trade-offs**: Often can trade space for time or vice versa

### Complexity Hierarchy (Best to Worst)
1. O(1) - Constant
2. O(log n) - Logarithmic  
3. O(n) - Linear
4. O(n log n) - Linearithmic
5. O(n²) - Quadratic
6. O(2ⁿ) - Exponential
7. O(n!) - Factorial

### Analysis Strategy
1. **Identify** the basic operations
2. **Count** how many times they execute
3. **Express** in terms of input size
4. **Simplify** using Big O rules

### Optimization Techniques
1. **Memoization**: Cache results to avoid recomputation
2. **Two Pointers**: Reduce nested loops to single loop
3. **Sliding Window**: Optimize subarray/substring problems
4. **Early Termination**: Stop when answer is found
5. **Space-Time Trade-offs**: Use extra space to save time

### Interview Success Tips
1. **Start simple**: Brute force first, then optimize
2. **Think aloud**: Explain your reasoning
3. **Consider trade-offs**: Discuss space vs time
4. **Use examples**: Walk through small cases
5. **Be precise**: Use correct notation and terminology

Remember: Understanding complexity analysis is crucial for writing efficient code and succeeding in technical interviews. Practice analyzing various algorithms and data structures to build intuition! 🚀
