# Trees and Binary Trees
## Hierarchical Data Structures

Trees are fundamental hierarchical data structures that model relationships between elements. They're essential for many algorithms and are the foundation for advanced data structures like heaps, tries, and balanced trees.

## 🎯 Learning Objectives
By the end of this section, you will:
- Understand tree terminology and properties
- Implement binary tree operations
- Master tree traversal algorithms
- Solve common tree problems
- Be ready for binary search trees and heaps

## 📚 Table of Contents
1. [Tree Fundamentals](#tree-fundamentals)
2. [Binary Tree Implementation](#binary-tree-implementation)
3. [Tree Traversal Algorithms](#tree-traversal-algorithms)
4. [Common Tree Problems](#common-tree-problems)
5. [Tree Properties and Validation](#tree-properties-and-validation)
6. [Exercises](#exercises)

---

## Tree Fundamentals

### What is a Tree?

A tree is a hierarchical data structure consisting of nodes connected by edges, where:
- **Root**: The topmost node (no parent)
- **Parent**: A node that has child nodes
- **Child**: A node that has a parent
- **Leaf**: A node with no children
- **Height**: Length of longest path from root to leaf
- **Depth**: Length of path from root to a specific node

### Tree Properties:
- **Connected**: Every node is reachable from root
- **Acyclic**: No cycles in the tree
- **Unique path**: Exactly one path between any two nodes

### Binary Tree:
A tree where each node has at most 2 children (left and right).

---

## Binary Tree Implementation

### Node Definition
```java
class TreeNode {
    int val;
    TreeNode left;
    TreeNode right;
    
    TreeNode() {}
    
    TreeNode(int val) {
        this.val = val;
    }
    
    TreeNode(int val, TreeNode left, TreeNode right) {
        this.val = val;
        this.left = left;
        this.right = right;
    }
}
```

### Basic Operations
```java
public class BinaryTree {
    private TreeNode root;
    
    public BinaryTree() {
        root = null;
    }
    
    /**
     * Insert a value into the tree
     * Time: O(n) - for unbalanced tree
     * Space: O(n) - for unbalanced tree
     */
    public void insert(int val) {
        root = insertRecursive(root, val);
    }
    
    private TreeNode insertRecursive(TreeNode node, int val) {
        if (node == null) {
            return new TreeNode(val);
        }
        
        // Simple insertion strategy (not balanced)
        if (val < node.val) {
            node.left = insertRecursive(node.left, val);
        } else {
            node.right = insertRecursive(node.right, val);
        }
        
        return node;
    }
    
    /**
     * Search for a value in the tree
     * Time: O(n) - for unbalanced tree
     * Space: O(n) - for unbalanced tree
     */
    public boolean search(int val) {
        return searchRecursive(root, val);
    }
    
    private boolean searchRecursive(TreeNode node, int val) {
        if (node == null) {
            return false;
        }
        
        if (node.val == val) {
            return true;
        }
        
        return searchRecursive(node.left, val) || 
               searchRecursive(node.right, val);
    }
}
```

---

## Tree Traversal Algorithms

### 1. Depth-First Search (DFS)

#### Preorder Traversal (Root → Left → Right)
```java
public class TreeTraversal {
    
    /**
     * Preorder traversal: Root, Left, Right
     * Time: O(n), Space: O(h) where h is height
     */
    public static void preorderTraversal(TreeNode root) {
        if (root == null) return;
        
        System.out.print(root.val + " "); // Visit root
        preorderTraversal(root.left);     // Traverse left
        preorderTraversal(root.right);    // Traverse right
    }
    
    /**
     * Preorder traversal iterative
     * Time: O(n), Space: O(h)
     */
    public static List<Integer> preorderIterative(TreeNode root) {
        List<Integer> result = new ArrayList<>();
        if (root == null) return result;
        
        Stack<TreeNode> stack = new Stack<>();
        stack.push(root);
        
        while (!stack.isEmpty()) {
            TreeNode node = stack.pop();
            result.add(node.val);
            
            // Push right first, then left (so left is processed first)
            if (node.right != null) stack.push(node.right);
            if (node.left != null) stack.push(node.left);
        }
        
        return result;
    }
}
```

#### Inorder Traversal (Left → Root → Right)
```java
public class TreeTraversal {
    
    /**
     * Inorder traversal: Left, Root, Right
     * Time: O(n), Space: O(h)
     */
    public static void inorderTraversal(TreeNode root) {
        if (root == null) return;
        
        inorderTraversal(root.left);      // Traverse left
        System.out.print(root.val + " "); // Visit root
        inorderTraversal(root.right);     // Traverse right
    }
    
    /**
     * Inorder traversal iterative
     * Time: O(n), Space: O(h)
     */
    public static List<Integer> inorderIterative(TreeNode root) {
        List<Integer> result = new ArrayList<>();
        Stack<TreeNode> stack = new Stack<>();
        TreeNode current = root;
        
        while (current != null || !stack.isEmpty()) {
            // Go to leftmost node
            while (current != null) {
                stack.push(current);
                current = current.left;
            }
            
            // Process node
            current = stack.pop();
            result.add(current.val);
            
            // Move to right subtree
            current = current.right;
        }
        
        return result;
    }
}
```

#### Postorder Traversal (Left → Right → Root)
```java
public class TreeTraversal {
    
    /**
     * Postorder traversal: Left, Right, Root
     * Time: O(n), Space: O(h)
     */
    public static void postorderTraversal(TreeNode root) {
        if (root == null) return;
        
        postorderTraversal(root.left);    // Traverse left
        postorderTraversal(root.right);   // Traverse right
        System.out.print(root.val + " "); // Visit root
    }
    
    /**
     * Postorder traversal iterative
     * Time: O(n), Space: O(h)
     */
    public static List<Integer> postorderIterative(TreeNode root) {
        List<Integer> result = new ArrayList<>();
        if (root == null) return result;
        
        Stack<TreeNode> stack = new Stack<>();
        TreeNode lastVisited = null;
        TreeNode current = root;
        
        while (current != null || !stack.isEmpty()) {
            if (current != null) {
                stack.push(current);
                current = current.left;
            } else {
                TreeNode peekNode = stack.peek();
                
                // If right child exists and hasn't been processed
                if (peekNode.right != null && lastVisited != peekNode.right) {
                    current = peekNode.right;
                } else {
                    result.add(peekNode.val);
                    lastVisited = stack.pop();
                }
            }
        }
        
        return result;
    }
}
```

### 2. Breadth-First Search (BFS)

#### Level Order Traversal
```java
public class TreeTraversal {
    
    /**
     * Level order traversal (BFS)
     * Time: O(n), Space: O(w) where w is maximum width
     */
    public static void levelOrderTraversal(TreeNode root) {
        if (root == null) return;
        
        Queue<TreeNode> queue = new LinkedList<>();
        queue.offer(root);
        
        while (!queue.isEmpty()) {
            TreeNode node = queue.poll();
            System.out.print(node.val + " ");
            
            if (node.left != null) queue.offer(node.left);
            if (node.right != null) queue.offer(node.right);
        }
    }
    
    /**
     * Level order traversal with level separation
     * Time: O(n), Space: O(w)
     */
    public static List<List<Integer>> levelOrder(TreeNode root) {
        List<List<Integer>> result = new ArrayList<>();
        if (root == null) return result;
        
        Queue<TreeNode> queue = new LinkedList<>();
        queue.offer(root);
        
        while (!queue.isEmpty()) {
            int levelSize = queue.size();
            List<Integer> currentLevel = new ArrayList<>();
            
            for (int i = 0; i < levelSize; i++) {
                TreeNode node = queue.poll();
                currentLevel.add(node.val);
                
                if (node.left != null) queue.offer(node.left);
                if (node.right != null) queue.offer(node.right);
            }
            
            result.add(currentLevel);
        }
        
        return result;
    }
}
```

---

## Common Tree Problems

### 1. Maximum Depth of Binary Tree
```java
public class TreeProblems {
    
    /**
     * Find maximum depth of binary tree
     * Time: O(n), Space: O(h)
     */
    public static int maxDepth(TreeNode root) {
        if (root == null) {
            return 0;
        }
        
        int leftDepth = maxDepth(root.left);
        int rightDepth = maxDepth(root.right);
        
        return Math.max(leftDepth, rightDepth) + 1;
    }
    
    /**
     * Find maximum depth iteratively
     * Time: O(n), Space: O(w)
     */
    public static int maxDepthIterative(TreeNode root) {
        if (root == null) return 0;
        
        Queue<TreeNode> queue = new LinkedList<>();
        queue.offer(root);
        int depth = 0;
        
        while (!queue.isEmpty()) {
            int levelSize = queue.size();
            depth++;
            
            for (int i = 0; i < levelSize; i++) {
                TreeNode node = queue.poll();
                if (node.left != null) queue.offer(node.left);
                if (node.right != null) queue.offer(node.right);
            }
        }
        
        return depth;
    }
}
```

### 2. Path Sum
```java
public class TreeProblems {
    
    /**
     * Check if there's a path with given sum
     * Time: O(n), Space: O(h)
     */
    public static boolean hasPathSum(TreeNode root, int targetSum) {
        if (root == null) {
            return false;
        }
        
        // If it's a leaf node and sum equals target
        if (root.left == null && root.right == null) {
            return root.val == targetSum;
        }
        
        int remainingSum = targetSum - root.val;
        return hasPathSum(root.left, remainingSum) || 
               hasPathSum(root.right, remainingSum);
    }
    
    /**
     * Find all paths with given sum
     * Time: O(n²), Space: O(h)
     */
    public static List<List<Integer>> pathSum(TreeNode root, int targetSum) {
        List<List<Integer>> result = new ArrayList<>();
        List<Integer> currentPath = new ArrayList<>();
        pathSumHelper(root, targetSum, currentPath, result);
        return result;
    }
    
    private static void pathSumHelper(TreeNode node, int targetSum, 
                                    List<Integer> currentPath, 
                                    List<List<Integer>> result) {
        if (node == null) return;
        
        currentPath.add(node.val);
        
        if (node.left == null && node.right == null && node.val == targetSum) {
            result.add(new ArrayList<>(currentPath));
        } else {
            pathSumHelper(node.left, targetSum - node.val, currentPath, result);
            pathSumHelper(node.right, targetSum - node.val, currentPath, result);
        }
        
        currentPath.remove(currentPath.size() - 1); // Backtrack
    }
}
```

### 3. Symmetric Tree
```java
public class TreeProblems {
    
    /**
     * Check if tree is symmetric
     * Time: O(n), Space: O(h)
     */
    public static boolean isSymmetric(TreeNode root) {
        if (root == null) return true;
        return isSymmetricHelper(root.left, root.right);
    }
    
    private static boolean isSymmetricHelper(TreeNode left, TreeNode right) {
        if (left == null && right == null) return true;
        if (left == null || right == null) return false;
        
        return left.val == right.val &&
               isSymmetricHelper(left.left, right.right) &&
               isSymmetricHelper(left.right, right.left);
    }
}
```

### 4. Lowest Common Ancestor
```java
public class TreeProblems {
    
    /**
     * Find lowest common ancestor of two nodes
     * Time: O(n), Space: O(h)
     */
    public static TreeNode lowestCommonAncestor(TreeNode root, TreeNode p, TreeNode q) {
        if (root == null || root == p || root == q) {
            return root;
        }
        
        TreeNode left = lowestCommonAncestor(root.left, p, q);
        TreeNode right = lowestCommonAncestor(root.right, p, q);
        
        if (left != null && right != null) {
            return root; // Found LCA
        }
        
        return left != null ? left : right;
    }
}
```

---

## Tree Properties and Validation

### 1. Validate Binary Search Tree
```java
public class TreeValidation {
    
    /**
     * Check if tree is a valid BST
     * Time: O(n), Space: O(h)
     */
    public static boolean isValidBST(TreeNode root) {
        return isValidBSTHelper(root, Long.MIN_VALUE, Long.MAX_VALUE);
    }
    
    private static boolean isValidBSTHelper(TreeNode node, long min, long max) {
        if (node == null) return true;
        
        if (node.val <= min || node.val >= max) {
            return false;
        }
        
        return isValidBSTHelper(node.left, min, node.val) &&
               isValidBSTHelper(node.right, node.val, max);
    }
}
```

### 2. Balanced Binary Tree
```java
public class TreeValidation {
    
    /**
     * Check if tree is balanced
     * Time: O(n), Space: O(h)
     */
    public static boolean isBalanced(TreeNode root) {
        return getHeight(root) != -1;
    }
    
    private static int getHeight(TreeNode node) {
        if (node == null) return 0;
        
        int leftHeight = getHeight(node.left);
        if (leftHeight == -1) return -1;
        
        int rightHeight = getHeight(node.right);
        if (rightHeight == -1) return -1;
        
        if (Math.abs(leftHeight - rightHeight) > 1) {
            return -1;
        }
        
        return Math.max(leftHeight, rightHeight) + 1;
    }
}
```

### 3. Complete Binary Tree
```java
public class TreeValidation {
    
    /**
     * Check if tree is complete
     * Time: O(n), Space: O(w)
     */
    public static boolean isComplete(TreeNode root) {
        if (root == null) return true;
        
        Queue<TreeNode> queue = new LinkedList<>();
        queue.offer(root);
        boolean foundNull = false;
        
        while (!queue.isEmpty()) {
            TreeNode node = queue.poll();
            
            if (node == null) {
                foundNull = true;
            } else {
                if (foundNull) return false; // Found non-null after null
                queue.offer(node.left);
                queue.offer(node.right);
            }
        }
        
        return true;
    }
}
```

---

## 🎯 Key Patterns for Tree Problems

### 1. Recursive Approach
- **Base case**: Handle null nodes
- **Recursive case**: Process current node and recurse on children
- **Combine results**: Merge results from left and right subtrees

### 2. Iterative Approach
- **Stack**: For DFS traversals
- **Queue**: For BFS traversals
- **State tracking**: Keep track of visited nodes

### 3. Tree Properties
- **Height calculation**: Max depth from root to leaf
- **Path problems**: Track path from root to target
- **Validation**: Check tree properties (BST, balanced, complete)

### 4. Common Techniques
- **Dummy nodes**: Simplify edge cases
- **Backtracking**: For path problems
- **Two pointers**: For symmetric tree problems

---

## 🏋️ Exercises

### Exercise 1: Maximum Depth of Binary Tree ⭐
Given the root of a binary tree, return its maximum depth.

### Exercise 2: Same Tree ⭐
Given the roots of two binary trees p and q, check if they are the same.

### Exercise 3: Symmetric Tree ⭐⭐
Given the root of a binary tree, check whether it is a mirror of itself.

### Exercise 4: Path Sum ⭐⭐
Given the root of a binary tree and an integer targetSum, return true if the tree has a root-to-leaf path such that adding up all the values along the path equals targetSum.

### Exercise 5: Binary Tree Level Order Traversal ⭐⭐
Given the root of a binary tree, return the level order traversal of its nodes' values.

### Exercise 6: Validate Binary Search Tree ⭐⭐
Given the root of a binary tree, determine if it is a valid binary search tree.

### Exercise 7: Lowest Common Ancestor ⭐⭐
Given a binary tree, find the lowest common ancestor of two given nodes.

### Exercise 8: Binary Tree Maximum Path Sum ⭐⭐⭐
Given the root of a binary tree, return the maximum path sum of any non-empty path.

---

## 🎓 Interview Tips

1. **Always handle null cases**:
   - Check if root is null
   - Check if left/right children are null

2. **Choose the right traversal**:
   - Preorder: When you need to process root first
   - Inorder: For BST problems (gives sorted order)
   - Postorder: When you need children processed first
   - Level order: For level-wise problems

3. **Use recursion effectively**:
   - Define base case clearly
   - Make recursive calls on subtrees
   - Combine results appropriately

4. **Consider space complexity**:
   - Recursive: O(h) where h is height
   - Iterative: O(w) where w is maximum width

5. **Draw examples**:
   - Visualize the tree structure
   - Trace through your algorithm

---

## 🚀 What's Next?

You've mastered binary trees! Next, we'll explore:
- [Binary Search Trees](02-binary-search-trees.md) - Ordered binary trees
- [Heaps and Priority Queues](03-heaps.md) - Complete binary trees
- [Graphs](04-graphs.md) - General tree structures

Remember: **Tree problems often have elegant recursive solutions!** Master the patterns and you'll be ready for any tree problem.

---

*"In computer science, trees grow upside down." - Anonymous*
