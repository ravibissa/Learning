/**
 * Tree Traversal Algorithms
 * 
 * This class demonstrates all major tree traversal algorithms
 * including recursive and iterative implementations.
 * 
 * @author DSA Tutorial
 * @version 1.0
 */
import java.util.*;

// TreeNode class for binary tree
class TreeNode {
    int val;
    TreeNode left;
    TreeNode right;
    
    TreeNode() {}
    
    TreeNode(int val) {
        this.val = val;
    }
    
    TreeNode(int val, TreeNode left, TreeNode right) {
        this.val = val;
        this.left = left;
        this.right = right;
    }
}

public class TreeTraversal {
    
    /**
     * Preorder Traversal: Root -> Left -> Right
     * Time Complexity: O(n)
     * Space Complexity: O(h) where h is height
     */
    public static void preorderTraversal(TreeNode root) {
        if (root == null) return;
        
        System.out.print(root.val + " "); // Visit root
        preorderTraversal(root.left);     // Traverse left
        preorderTraversal(root.right);    // Traverse right
    }
    
    /**
     * Preorder traversal iterative using stack
     * Time Complexity: O(n)
     * Space Complexity: O(h)
     */
    public static List<Integer> preorderIterative(TreeNode root) {
        List<Integer> result = new ArrayList<>();
        if (root == null) return result;
        
        Stack<TreeNode> stack = new Stack<>();
        stack.push(root);
        
        while (!stack.isEmpty()) {
            TreeNode node = stack.pop();
            result.add(node.val);
            
            // Push right first, then left (so left is processed first)
            if (node.right != null) stack.push(node.right);
            if (node.left != null) stack.push(node.left);
        }
        
        return result;
    }
    
    /**
     * Inorder Traversal: Left -> Root -> Right
     * Time Complexity: O(n)
     * Space Complexity: O(h)
     */
    public static void inorderTraversal(TreeNode root) {
        if (root == null) return;
        
        inorderTraversal(root.left);      // Traverse left
        System.out.print(root.val + " "); // Visit root
        inorderTraversal(root.right);     // Traverse right
    }
    
    /**
     * Inorder traversal iterative using stack
     * Time Complexity: O(n)
     * Space Complexity: O(h)
     */
    public static List<Integer> inorderIterative(TreeNode root) {
        List<Integer> result = new ArrayList<>();
        Stack<TreeNode> stack = new Stack<>();
        TreeNode current = root;
        
        while (current != null || !stack.isEmpty()) {
            // Go to leftmost node
            while (current != null) {
                stack.push(current);
                current = current.left;
            }
            
            // Process node
            current = stack.pop();
            result.add(current.val);
            
            // Move to right subtree
            current = current.right;
        }
        
        return result;
    }
    
    /**
     * Postorder Traversal: Left -> Right -> Root
     * Time Complexity: O(n)
     * Space Complexity: O(h)
     */
    public static void postorderTraversal(TreeNode root) {
        if (root == null) return;
        
        postorderTraversal(root.left);    // Traverse left
        postorderTraversal(root.right);   // Traverse right
        System.out.print(root.val + " "); // Visit root
    }
    
    /**
     * Postorder traversal iterative using stack
     * Time Complexity: O(n)
     * Space Complexity: O(h)
     */
    public static List<Integer> postorderIterative(TreeNode root) {
        List<Integer> result = new ArrayList<>();
        if (root == null) return result;
        
        Stack<TreeNode> stack = new Stack<>();
        TreeNode lastVisited = null;
        TreeNode current = root;
        
        while (current != null || !stack.isEmpty()) {
            if (current != null) {
                stack.push(current);
                current = current.left;
            } else {
                TreeNode peekNode = stack.peek();
                
                // If right child exists and hasn't been processed
                if (peekNode.right != null && lastVisited != peekNode.right) {
                    current = peekNode.right;
                } else {
                    result.add(peekNode.val);
                    lastVisited = stack.pop();
                }
            }
        }
        
        return result;
    }
    
    /**
     * Level Order Traversal (BFS)
     * Time Complexity: O(n)
     * Space Complexity: O(w) where w is maximum width
     */
    public static void levelOrderTraversal(TreeNode root) {
        if (root == null) return;
        
        Queue<TreeNode> queue = new LinkedList<>();
        queue.offer(root);
        
        while (!queue.isEmpty()) {
            TreeNode node = queue.poll();
            System.out.print(node.val + " ");
            
            if (node.left != null) queue.offer(node.left);
            if (node.right != null) queue.offer(node.right);
        }
    }
    
    /**
     * Level order traversal with level separation
     * Time Complexity: O(n)
     * Space Complexity: O(w)
     */
    public static List<List<Integer>> levelOrder(TreeNode root) {
        List<List<Integer>> result = new ArrayList<>();
        if (root == null) return result;
        
        Queue<TreeNode> queue = new LinkedList<>();
        queue.offer(root);
        
        while (!queue.isEmpty()) {
            int levelSize = queue.size();
            List<Integer> currentLevel = new ArrayList<>();
            
            for (int i = 0; i < levelSize; i++) {
                TreeNode node = queue.poll();
                currentLevel.add(node.val);
                
                if (node.left != null) queue.offer(node.left);
                if (node.right != null) queue.offer(node.right);
            }
            
            result.add(currentLevel);
        }
        
        return result;
    }
    
    /**
     * Zigzag Level Order Traversal
     * Time Complexity: O(n)
     * Space Complexity: O(w)
     */
    public static List<List<Integer>> zigzagLevelOrder(TreeNode root) {
        List<List<Integer>> result = new ArrayList<>();
        if (root == null) return result;
        
        Queue<TreeNode> queue = new LinkedList<>();
        queue.offer(root);
        boolean leftToRight = true;
        
        while (!queue.isEmpty()) {
            int levelSize = queue.size();
            List<Integer> currentLevel = new ArrayList<>();
            
            for (int i = 0; i < levelSize; i++) {
                TreeNode node = queue.poll();
                
                if (leftToRight) {
                    currentLevel.add(node.val);
                } else {
                    currentLevel.add(0, node.val); // Add at beginning for reverse
                }
                
                if (node.left != null) queue.offer(node.left);
                if (node.right != null) queue.offer(node.right);
            }
            
            result.add(currentLevel);
            leftToRight = !leftToRight;
        }
        
        return result;
    }
    
    /**
     * Vertical Order Traversal
     * Time Complexity: O(n log n)
     * Space Complexity: O(n)
     */
    public static List<List<Integer>> verticalOrder(TreeNode root) {
        List<List<Integer>> result = new ArrayList<>();
        if (root == null) return result;
        
        Map<Integer, List<Integer>> columnMap = new TreeMap<>();
        Queue<Pair> queue = new LinkedList<>();
        queue.offer(new Pair(root, 0));
        
        while (!queue.isEmpty()) {
            Pair pair = queue.poll();
            TreeNode node = pair.node;
            int column = pair.column;
            
            columnMap.computeIfAbsent(column, k -> new ArrayList<>()).add(node.val);
            
            if (node.left != null) queue.offer(new Pair(node.left, column - 1));
            if (node.right != null) queue.offer(new Pair(node.right, column + 1));
        }
        
        result.addAll(columnMap.values());
        return result;
    }
    
    /**
     * Helper class for vertical order traversal
     */
    static class Pair {
        TreeNode node;
        int column;
        
        Pair(TreeNode node, int column) {
            this.node = node;
            this.column = column;
        }
    }
    
    /**
     * Boundary Traversal (Left boundary, leaves, right boundary)
     * Time Complexity: O(n)
     * Space Complexity: O(h)
     */
    public static List<Integer> boundaryTraversal(TreeNode root) {
        List<Integer> result = new ArrayList<>();
        if (root == null) return result;
        
        result.add(root.val);
        
        // Left boundary (excluding root and leaves)
        leftBoundary(root.left, result);
        
        // Leaves
        leaves(root, result);
        
        // Right boundary (excluding root and leaves)
        rightBoundary(root.right, result);
        
        return result;
    }
    
    private static void leftBoundary(TreeNode node, List<Integer> result) {
        if (node == null || (node.left == null && node.right == null)) return;
        
        result.add(node.val);
        if (node.left != null) {
            leftBoundary(node.left, result);
        } else {
            leftBoundary(node.right, result);
        }
    }
    
    private static void rightBoundary(TreeNode node, List<Integer> result) {
        if (node == null || (node.left == null && node.right == null)) return;
        
        if (node.right != null) {
            rightBoundary(node.right, result);
        } else {
            rightBoundary(node.left, result);
        }
        result.add(node.val);
    }
    
    private static void leaves(TreeNode node, List<Integer> result) {
        if (node == null) return;
        
        if (node.left == null && node.right == null) {
            result.add(node.val);
            return;
        }
        
        leaves(node.left, result);
        leaves(node.right, result);
    }
    
    /**
     * Morris Traversal (Inorder without extra space)
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     */
    public static List<Integer> morrisInorder(TreeNode root) {
        List<Integer> result = new ArrayList<>();
        TreeNode current = root;
        
        while (current != null) {
            if (current.left == null) {
                result.add(current.val);
                current = current.right;
            } else {
                // Find inorder predecessor
                TreeNode predecessor = current.left;
                while (predecessor.right != null && predecessor.right != current) {
                    predecessor = predecessor.right;
                }
                
                if (predecessor.right == null) {
                    predecessor.right = current;
                    current = current.left;
                } else {
                    predecessor.right = null;
                    result.add(current.val);
                    current = current.right;
                }
            }
        }
        
        return result;
    }
    
    /**
     * Helper method to create a sample tree
     */
    public static TreeNode createSampleTree() {
        TreeNode root = new TreeNode(1);
        root.left = new TreeNode(2);
        root.right = new TreeNode(3);
        root.left.left = new TreeNode(4);
        root.left.right = new TreeNode(5);
        root.right.left = new TreeNode(6);
        root.right.right = new TreeNode(7);
        return root;
    }
    
    /**
     * Helper method to print list
     */
    public static void printList(List<Integer> list) {
        for (int val : list) {
            System.out.print(val + " ");
        }
        System.out.println();
    }
    
    /**
     * Helper method to print list of lists
     */
    public static void printListOfLists(List<List<Integer>> listOfLists) {
        for (List<Integer> list : listOfLists) {
            printList(list);
        }
    }
    
    public static void main(String[] args) {
        System.out.println("=== Tree Traversal Algorithms Demo ===\n");
        
        TreeNode root = createSampleTree();
        System.out.println("Sample tree structure:");
        System.out.println("        1");
        System.out.println("       / \\");
        System.out.println("      2   3");
        System.out.println("     / \\ / \\");
        System.out.println("    4  5 6  7");
        System.out.println();
        
        // Test recursive traversals
        System.out.println("1. Recursive Traversals:");
        System.out.print("Preorder: ");
        preorderTraversal(root);
        System.out.println();
        
        System.out.print("Inorder: ");
        inorderTraversal(root);
        System.out.println();
        
        System.out.print("Postorder: ");
        postorderTraversal(root);
        System.out.println();
        System.out.println();
        
        // Test iterative traversals
        System.out.println("2. Iterative Traversals:");
        System.out.print("Preorder: ");
        printList(preorderIterative(root));
        
        System.out.print("Inorder: ");
        printList(inorderIterative(root));
        
        System.out.print("Postorder: ");
        printList(postorderIterative(root));
        System.out.println();
        
        // Test level order traversals
        System.out.println("3. Level Order Traversals:");
        System.out.print("Level Order: ");
        levelOrderTraversal(root);
        System.out.println();
        
        System.out.println("Level Order (with levels):");
        printListOfLists(levelOrder(root));
        
        System.out.println("Zigzag Level Order:");
        printListOfLists(zigzagLevelOrder(root));
        System.out.println();
        
        // Test special traversals
        System.out.println("4. Special Traversals:");
        System.out.println("Vertical Order:");
        printListOfLists(verticalOrder(root));
        
        System.out.print("Boundary Traversal: ");
        printList(boundaryTraversal(root));
        
        System.out.print("Morris Inorder: ");
        printList(morrisInorder(root));
        System.out.println();
        
        System.out.println("=== Traversal Summary ===");
        System.out.println("• Preorder: Root -> Left -> Right");
        System.out.println("• Inorder: Left -> Root -> Right");
        System.out.println("• Postorder: Left -> Right -> Root");
        System.out.println("• Level Order: Breadth-first traversal");
        System.out.println("• All traversals: O(n) time complexity");
        System.out.println("• Recursive: O(h) space, Iterative: O(h) or O(w) space");
    }
}
