/**
 * Common Tree Problems and Solutions
 * 
 * This class contains implementations of common tree problems
 * that are frequently asked in interviews and coding competitions.
 * 
 * @author DSA Tutorial
 * @version 1.0
 */
import java.util.*;

// TreeNode class for binary tree
class TreeNode {
    int val;
    TreeNode left;
    TreeNode right;
    
    TreeNode() {}
    
    TreeNode(int val) {
        this.val = val;
    }
    
    TreeNode(int val, TreeNode left, TreeNode right) {
        this.val = val;
        this.left = left;
        this.right = right;
    }
}

public class TreeProblems {
    
    /**
     * Maximum Depth of Binary Tree
     * Time Complexity: O(n)
     * Space Complexity: O(h) where h is height
     */
    public static int maxDepth(TreeNode root) {
        if (root == null) {
            return 0;
        }
        
        int leftDepth = maxDepth(root.left);
        int rightDepth = maxDepth(root.right);
        
        return Math.max(leftDepth, rightDepth) + 1;
    }
    
    /**
     * Maximum Depth iterative using BFS
     * Time Complexity: O(n)
     * Space Complexity: O(w) where w is maximum width
     */
    public static int maxDepthIterative(TreeNode root) {
        if (root == null) return 0;
        
        Queue<TreeNode> queue = new LinkedList<>();
        queue.offer(root);
        int depth = 0;
        
        while (!queue.isEmpty()) {
            int levelSize = queue.size();
            depth++;
            
            for (int i = 0; i < levelSize; i++) {
                TreeNode node = queue.poll();
                if (node.left != null) queue.offer(node.left);
                if (node.right != null) queue.offer(node.right);
            }
        }
        
        return depth;
    }
    
    /**
     * Same Tree - Check if two trees are identical
     * Time Complexity: O(n)
     * Space Complexity: O(h)
     */
    public static boolean isSameTree(TreeNode p, TreeNode q) {
        if (p == null && q == null) return true;
        if (p == null || q == null) return false;
        
        return p.val == q.val && 
               isSameTree(p.left, q.left) && 
               isSameTree(p.right, q.right);
    }
    
    /**
     * Symmetric Tree - Check if tree is mirror of itself
     * Time Complexity: O(n)
     * Space Complexity: O(h)
     */
    public static boolean isSymmetric(TreeNode root) {
        if (root == null) return true;
        return isSymmetricHelper(root.left, root.right);
    }
    
    private static boolean isSymmetricHelper(TreeNode left, TreeNode right) {
        if (left == null && right == null) return true;
        if (left == null || right == null) return false;
        
        return left.val == right.val &&
               isSymmetricHelper(left.left, right.right) &&
               isSymmetricHelper(left.right, right.left);
    }
    
    /**
     * Path Sum - Check if there's a path with given sum
     * Time Complexity: O(n)
     * Space Complexity: O(h)
     */
    public static boolean hasPathSum(TreeNode root, int targetSum) {
        if (root == null) {
            return false;
        }
        
        // If it's a leaf node and sum equals target
        if (root.left == null && root.right == null) {
            return root.val == targetSum;
        }
        
        int remainingSum = targetSum - root.val;
        return hasPathSum(root.left, remainingSum) || 
               hasPathSum(root.right, remainingSum);
    }
    
    /**
     * Path Sum II - Find all paths with given sum
     * Time Complexity: O(n²)
     * Space Complexity: O(h)
     */
    public static List<List<Integer>> pathSum(TreeNode root, int targetSum) {
        List<List<Integer>> result = new ArrayList<>();
        List<Integer> currentPath = new ArrayList<>();
        pathSumHelper(root, targetSum, currentPath, result);
        return result;
    }
    
    private static void pathSumHelper(TreeNode node, int targetSum, 
                                    List<Integer> currentPath, 
                                    List<List<Integer>> result) {
        if (node == null) return;
        
        currentPath.add(node.val);
        
        if (node.left == null && node.right == null && node.val == targetSum) {
            result.add(new ArrayList<>(currentPath));
        } else {
            pathSumHelper(node.left, targetSum - node.val, currentPath, result);
            pathSumHelper(node.right, targetSum - node.val, currentPath, result);
        }
        
        currentPath.remove(currentPath.size() - 1); // Backtrack
    }
    
    /**
     * Binary Tree Level Order Traversal
     * Time Complexity: O(n)
     * Space Complexity: O(w)
     */
    public static List<List<Integer>> levelOrder(TreeNode root) {
        List<List<Integer>> result = new ArrayList<>();
        if (root == null) return result;
        
        Queue<TreeNode> queue = new LinkedList<>();
        queue.offer(root);
        
        while (!queue.isEmpty()) {
            int levelSize = queue.size();
            List<Integer> currentLevel = new ArrayList<>();
            
            for (int i = 0; i < levelSize; i++) {
                TreeNode node = queue.poll();
                currentLevel.add(node.val);
                
                if (node.left != null) queue.offer(node.left);
                if (node.right != null) queue.offer(node.right);
            }
            
            result.add(currentLevel);
        }
        
        return result;
    }
    
    /**
     * Validate Binary Search Tree
     * Time Complexity: O(n)
     * Space Complexity: O(h)
     */
    public static boolean isValidBST(TreeNode root) {
        return isValidBSTHelper(root, Long.MIN_VALUE, Long.MAX_VALUE);
    }
    
    private static boolean isValidBSTHelper(TreeNode node, long min, long max) {
        if (node == null) return true;
        
        if (node.val <= min || node.val >= max) {
            return false;
        }
        
        return isValidBSTHelper(node.left, min, node.val) &&
               isValidBSTHelper(node.right, node.val, max);
    }
    
    /**
     * Lowest Common Ancestor
     * Time Complexity: O(n)
     * Space Complexity: O(h)
     */
    public static TreeNode lowestCommonAncestor(TreeNode root, TreeNode p, TreeNode q) {
        if (root == null || root == p || root == q) {
            return root;
        }
        
        TreeNode left = lowestCommonAncestor(root.left, p, q);
        TreeNode right = lowestCommonAncestor(root.right, p, q);
        
        if (left != null && right != null) {
            return root; // Found LCA
        }
        
        return left != null ? left : right;
    }
    
    /**
     * Binary Tree Maximum Path Sum
     * Time Complexity: O(n)
     * Space Complexity: O(h)
     */
    public static int maxPathSum(TreeNode root) {
        int[] maxSum = {Integer.MIN_VALUE};
        maxPathSumHelper(root, maxSum);
        return maxSum[0];
    }
    
    private static int maxPathSumHelper(TreeNode node, int[] maxSum) {
        if (node == null) return 0;
        
        int leftSum = Math.max(0, maxPathSumHelper(node.left, maxSum));
        int rightSum = Math.max(0, maxPathSumHelper(node.right, maxSum));
        
        int currentMax = node.val + leftSum + rightSum;
        maxSum[0] = Math.max(maxSum[0], currentMax);
        
        return node.val + Math.max(leftSum, rightSum);
    }
    
    /**
     * Invert Binary Tree
     * Time Complexity: O(n)
     * Space Complexity: O(h)
     */
    public static TreeNode invertTree(TreeNode root) {
        if (root == null) return null;
        
        TreeNode left = invertTree(root.left);
        TreeNode right = invertTree(root.right);
        
        root.left = right;
        root.right = left;
        
        return root;
    }
    
    /**
     * Binary Tree Right Side View
     * Time Complexity: O(n)
     * Space Complexity: O(w)
     */
    public static List<Integer> rightSideView(TreeNode root) {
        List<Integer> result = new ArrayList<>();
        if (root == null) return result;
        
        Queue<TreeNode> queue = new LinkedList<>();
        queue.offer(root);
        
        while (!queue.isEmpty()) {
            int levelSize = queue.size();
            
            for (int i = 0; i < levelSize; i++) {
                TreeNode node = queue.poll();
                
                if (i == levelSize - 1) { // Last node in level
                    result.add(node.val);
                }
                
                if (node.left != null) queue.offer(node.left);
                if (node.right != null) queue.offer(node.right);
            }
        }
        
        return result;
    }
    
    /**
     * Count Complete Tree Nodes
     * Time Complexity: O(log²n)
     * Space Complexity: O(log n)
     */
    public static int countNodes(TreeNode root) {
        if (root == null) return 0;
        
        int leftHeight = getLeftHeight(root);
        int rightHeight = getRightHeight(root);
        
        if (leftHeight == rightHeight) {
            // Complete tree
            return (1 << leftHeight) - 1;
        } else {
            return 1 + countNodes(root.left) + countNodes(root.right);
        }
    }
    
    private static int getLeftHeight(TreeNode node) {
        int height = 0;
        while (node != null) {
            height++;
            node = node.left;
        }
        return height;
    }
    
    private static int getRightHeight(TreeNode node) {
        int height = 0;
        while (node != null) {
            height++;
            node = node.right;
        }
        return height;
    }
    
    /**
     * Serialize and Deserialize Binary Tree
     * Time Complexity: O(n)
     * Space Complexity: O(n)
     */
    public static String serialize(TreeNode root) {
        StringBuilder sb = new StringBuilder();
        serializeHelper(root, sb);
        return sb.toString();
    }
    
    private static void serializeHelper(TreeNode node, StringBuilder sb) {
        if (node == null) {
            sb.append("null,");
        } else {
            sb.append(node.val).append(",");
            serializeHelper(node.left, sb);
            serializeHelper(node.right, sb);
        }
    }
    
    public static TreeNode deserialize(String data) {
        String[] values = data.split(",");
        Queue<String> queue = new LinkedList<>(Arrays.asList(values));
        return deserializeHelper(queue);
    }
    
    private static TreeNode deserializeHelper(Queue<String> queue) {
        String value = queue.poll();
        if (value.equals("null")) {
            return null;
        }
        
        TreeNode node = new TreeNode(Integer.parseInt(value));
        node.left = deserializeHelper(queue);
        node.right = deserializeHelper(queue);
        
        return node;
    }
    
    /**
     * Helper method to create a sample tree
     */
    public static TreeNode createSampleTree() {
        TreeNode root = new TreeNode(1);
        root.left = new TreeNode(2);
        root.right = new TreeNode(3);
        root.left.left = new TreeNode(4);
        root.left.right = new TreeNode(5);
        root.right.left = new TreeNode(6);
        root.right.right = new TreeNode(7);
        return root;
    }
    
    /**
     * Helper method to print list
     */
    public static void printList(List<Integer> list) {
        System.out.println(list);
    }
    
    /**
     * Helper method to print list of lists
     */
    public static void printListOfLists(List<List<Integer>> listOfLists) {
        for (List<Integer> list : listOfLists) {
            System.out.println(list);
        }
    }
    
    public static void main(String[] args) {
        System.out.println("=== Tree Problems Demo ===\n");
        
        TreeNode root = createSampleTree();
        System.out.println("Sample tree structure:");
        System.out.println("        1");
        System.out.println("       / \\");
        System.out.println("      2   3");
        System.out.println("     / \\ / \\");
        System.out.println("    4  5 6  7");
        System.out.println();
        
        // Test maximum depth
        System.out.println("1. Maximum Depth:");
        System.out.println("Recursive: " + maxDepth(root));
        System.out.println("Iterative: " + maxDepthIterative(root));
        System.out.println();
        
        // Test same tree
        System.out.println("2. Same Tree:");
        TreeNode root2 = createSampleTree();
        System.out.println("Are trees same: " + isSameTree(root, root2));
        root2.left.val = 99;
        System.out.println("After modification: " + isSameTree(root, root2));
        System.out.println();
        
        // Test symmetric tree
        System.out.println("3. Symmetric Tree:");
        TreeNode symmetricRoot = new TreeNode(1);
        symmetricRoot.left = new TreeNode(2);
        symmetricRoot.right = new TreeNode(2);
        symmetricRoot.left.left = new TreeNode(3);
        symmetricRoot.right.right = new TreeNode(3);
        System.out.println("Is symmetric: " + isSymmetric(symmetricRoot));
        System.out.println("Original tree is symmetric: " + isSymmetric(root));
        System.out.println();
        
        // Test path sum
        System.out.println("4. Path Sum:");
        System.out.println("Has path sum 7: " + hasPathSum(root, 7));
        System.out.println("Has path sum 10: " + hasPathSum(root, 10));
        System.out.println("All paths with sum 7:");
        printListOfLists(pathSum(root, 7));
        System.out.println();
        
        // Test level order
        System.out.println("5. Level Order Traversal:");
        printListOfLists(levelOrder(root));
        System.out.println();
        
        // Test BST validation
        System.out.println("6. BST Validation:");
        TreeNode bstRoot = new TreeNode(5);
        bstRoot.left = new TreeNode(3);
        bstRoot.right = new TreeNode(7);
        bstRoot.left.left = new TreeNode(2);
        bstRoot.left.right = new TreeNode(4);
        System.out.println("Is valid BST: " + isValidBST(bstRoot));
        System.out.println("Original tree is BST: " + isValidBST(root));
        System.out.println();
        
        // Test right side view
        System.out.println("7. Right Side View:");
        printList(rightSideView(root));
        System.out.println();
        
        // Test invert tree
        System.out.println("8. Invert Tree:");
        TreeNode inverted = invertTree(createSampleTree());
        System.out.println("Inverted tree level order:");
        printListOfLists(levelOrder(inverted));
        System.out.println();
        
        // Test serialize/deserialize
        System.out.println("9. Serialize/Deserialize:");
        String serialized = serialize(root);
        System.out.println("Serialized: " + serialized);
        TreeNode deserialized = deserialize(serialized);
        System.out.println("Deserialized tree level order:");
        printListOfLists(levelOrder(deserialized));
        
        System.out.println("\n=== Key Problem Patterns ===");
        System.out.println("• Recursive approach for most tree problems");
        System.out.println("• BFS for level-order problems");
        System.out.println("• DFS for path and depth problems");
        System.out.println("• Backtracking for path problems");
        System.out.println("• Two-pointer technique for symmetric problems");
    }
}
