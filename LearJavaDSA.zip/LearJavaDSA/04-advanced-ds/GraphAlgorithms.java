import java.util.*;

/**
 * Comprehensive Graph Algorithms Implementation
 * This file contains implementations of major graph algorithms
 * including traversal, shortest path, MST, and advanced algorithms.
 * 
 * Author: Java DSA Tutorial
 * Complexity Analysis: Provided for each algorithm
 */

public class GraphAlgorithms {
    
    // Graph representation using adjacency list
    static class Graph {
        private int vertices;
        private ArrayList<ArrayList<Integer>> adjList;
        private ArrayList<ArrayList<Edge>> weightedAdjList;
        
        // Constructor for unweighted graph
        public Graph(int vertices) {
            this.vertices = vertices;
            this.adjList = new ArrayList<>();
            for (int i = 0; i < vertices; i++) {
                adjList.add(new ArrayList<>());
            }
        }
        
        // Constructor for weighted graph
        public Graph(int vertices, boolean weighted) {
            this.vertices = vertices;
            if (weighted) {
                this.weightedAdjList = new ArrayList<>();
                for (int i = 0; i < vertices; i++) {
                    weightedAdjList.add(new ArrayList<>());
                }
            } else {
                this.adjList = new ArrayList<>();
                for (int i = 0; i < vertices; i++) {
                    adjList.add(new ArrayList<>());
                }
            }
        }
        
        // Add edge to unweighted graph
        public void addEdge(int src, int dest) {
            adjList.get(src).add(dest);
            adjList.get(dest).add(src); // For undirected graph
        }
        
        // Add directed edge to unweighted graph
        public void addDirectedEdge(int src, int dest) {
            adjList.get(src).add(dest);
        }
        
        // Add edge to weighted graph
        public void addWeightedEdge(int src, int dest, int weight) {
            weightedAdjList.get(src).add(new Edge(dest, weight));
            weightedAdjList.get(dest).add(new Edge(src, weight)); // For undirected
        }
        
        // Add directed weighted edge
        public void addDirectedWeightedEdge(int src, int dest, int weight) {
            weightedAdjList.get(src).add(new Edge(dest, weight));
        }
        
        public int getVertices() { return vertices; }
        public ArrayList<ArrayList<Integer>> getAdjList() { return adjList; }
        public ArrayList<ArrayList<Edge>> getWeightedAdjList() { return weightedAdjList; }
    }
    
    // Edge class for weighted graphs
    static class Edge implements Comparable<Edge> {
        int dest, weight;
        
        public Edge(int dest, int weight) {
            this.dest = dest;
            this.weight = weight;
        }
        
        @Override
        public int compareTo(Edge other) {
            return Integer.compare(this.weight, other.weight);
        }
    }
    
    // Union-Find data structure for Kruskal's algorithm
    static class UnionFind {
        private int[] parent, rank;
        
        public UnionFind(int n) {
            parent = new int[n];
            rank = new int[n];
            for (int i = 0; i < n; i++) {
                parent[i] = i;
                rank[i] = 0;
            }
        }
        
        public int find(int x) {
            if (parent[x] != x) {
                parent[x] = find(parent[x]); // Path compression
            }
            return parent[x];
        }
        
        public boolean union(int x, int y) {
            int rootX = find(x);
            int rootY = find(y);
            
            if (rootX == rootY) return false; // Already in same set
            
            // Union by rank
            if (rank[rootX] < rank[rootY]) {
                parent[rootX] = rootY;
            } else if (rank[rootX] > rank[rootY]) {
                parent[rootY] = rootX;
            } else {
                parent[rootY] = rootX;
                rank[rootX]++;
            }
            return true;
        }
    }
    
    // ==============================================
    // GRAPH TRAVERSAL ALGORITHMS
    // ==============================================
    
    /**
     * Depth-First Search (DFS) - Recursive Implementation
     * Time Complexity: O(V + E)
     * Space Complexity: O(V)
     * 
     * @param graph The graph to traverse
     * @param start Starting vertex
     * @return List of vertices in DFS order
     */
    public static List<Integer> dfsRecursive(Graph graph, int start) {
        List<Integer> result = new ArrayList<>();
        boolean[] visited = new boolean[graph.getVertices()];
        dfsHelper(graph, start, visited, result);
        return result;
    }
    
    private static void dfsHelper(Graph graph, int vertex, boolean[] visited, List<Integer> result) {
        visited[vertex] = true;
        result.add(vertex);
        
        for (int neighbor : graph.getAdjList().get(vertex)) {
            if (!visited[neighbor]) {
                dfsHelper(graph, neighbor, visited, result);
            }
        }
    }
    
    /**
     * Depth-First Search (DFS) - Iterative Implementation
     * Time Complexity: O(V + E)
     * Space Complexity: O(V)
     */
    public static List<Integer> dfsIterative(Graph graph, int start) {
        List<Integer> result = new ArrayList<>();
        boolean[] visited = new boolean[graph.getVertices()];
        Stack<Integer> stack = new Stack<>();
        
        stack.push(start);
        
        while (!stack.isEmpty()) {
            int vertex = stack.pop();
            
            if (!visited[vertex]) {
                visited[vertex] = true;
                result.add(vertex);
                
                // Add neighbors in reverse order to maintain left-to-right traversal
                ArrayList<Integer> neighbors = graph.getAdjList().get(vertex);
                for (int i = neighbors.size() - 1; i >= 0; i--) {
                    if (!visited[neighbors.get(i)]) {
                        stack.push(neighbors.get(i));
                    }
                }
            }
        }
        
        return result;
    }
    
    /**
     * Breadth-First Search (BFS)
     * Time Complexity: O(V + E)
     * Space Complexity: O(V)
     * 
     * @param graph The graph to traverse
     * @param start Starting vertex
     * @return List of vertices in BFS order
     */
    public static List<Integer> bfs(Graph graph, int start) {
        List<Integer> result = new ArrayList<>();
        boolean[] visited = new boolean[graph.getVertices()];
        Queue<Integer> queue = new LinkedList<>();
        
        visited[start] = true;
        queue.offer(start);
        
        while (!queue.isEmpty()) {
            int vertex = queue.poll();
            result.add(vertex);
            
            for (int neighbor : graph.getAdjList().get(vertex)) {
                if (!visited[neighbor]) {
                    visited[neighbor] = true;
                    queue.offer(neighbor);
                }
            }
        }
        
        return result;
    }
    
    // ==============================================
    // SHORTEST PATH ALGORITHMS
    // ==============================================
    
    /**
     * Dijkstra's Algorithm for Single-Source Shortest Path
     * Time Complexity: O((V + E) log V)
     * Space Complexity: O(V)
     * 
     * @param graph Weighted graph
     * @param source Source vertex
     * @return Array of shortest distances from source
     */
    public static int[] dijkstra(Graph graph, int source) {
        int V = graph.getVertices();
        int[] dist = new int[V];
        boolean[] visited = new boolean[V];
        
        // Initialize distances
        Arrays.fill(dist, Integer.MAX_VALUE);
        dist[source] = 0;
        
        // Priority queue to store vertices and their distances
        PriorityQueue<Edge> pq = new PriorityQueue<>();
        pq.offer(new Edge(source, 0));
        
        while (!pq.isEmpty()) {
            Edge current = pq.poll();
            int u = current.dest;
            
            if (visited[u]) continue;
            visited[u] = true;
            
            // Relax all adjacent vertices
            for (Edge edge : graph.getWeightedAdjList().get(u)) {
                int v = edge.dest;
                int weight = edge.weight;
                
                if (!visited[v] && dist[u] + weight < dist[v]) {
                    dist[v] = dist[u] + weight;
                    pq.offer(new Edge(v, dist[v]));
                }
            }
        }
        
        return dist;
    }
    
    /**
     * Bellman-Ford Algorithm for Single-Source Shortest Path
     * Handles negative weights and detects negative cycles
     * Time Complexity: O(VE)
     * Space Complexity: O(V)
     * 
     * @param edges List of all edges in the graph
     * @param V Number of vertices
     * @param source Source vertex
     * @return Array of shortest distances, or null if negative cycle exists
     */
    public static int[] bellmanFord(List<int[]> edges, int V, int source) {
        int[] dist = new int[V];
        Arrays.fill(dist, Integer.MAX_VALUE);
        dist[source] = 0;
        
        // Relax all edges V-1 times
        for (int i = 0; i < V - 1; i++) {
            for (int[] edge : edges) {
                int u = edge[0], v = edge[1], weight = edge[2];
                if (dist[u] != Integer.MAX_VALUE && dist[u] + weight < dist[v]) {
                    dist[v] = dist[u] + weight;
                }
            }
        }
        
        // Check for negative cycles
        for (int[] edge : edges) {
            int u = edge[0], v = edge[1], weight = edge[2];
            if (dist[u] != Integer.MAX_VALUE && dist[u] + weight < dist[v]) {
                return null; // Negative cycle detected
            }
        }
        
        return dist;
    }
    
    /**
     * Floyd-Warshall Algorithm for All-Pairs Shortest Path
     * Time Complexity: O(V³)
     * Space Complexity: O(V²)
     * 
     * @param graph Adjacency matrix representation
     * @return 2D array of shortest distances between all pairs
     */
    public static int[][] floydWarshall(int[][] graph) {
        int V = graph.length;
        int[][] dist = new int[V][V];
        
        // Initialize distance matrix
        for (int i = 0; i < V; i++) {
            for (int j = 0; j < V; j++) {
                dist[i][j] = graph[i][j];
            }
        }
        
        // Try all intermediate vertices
        for (int k = 0; k < V; k++) {
            for (int i = 0; i < V; i++) {
                for (int j = 0; j < V; j++) {
                    if (dist[i][k] != Integer.MAX_VALUE && 
                        dist[k][j] != Integer.MAX_VALUE && 
                        dist[i][k] + dist[k][j] < dist[i][j]) {
                        dist[i][j] = dist[i][k] + dist[k][j];
                    }
                }
            }
        }
        
        return dist;
    }
    
    // ==============================================
    // MINIMUM SPANNING TREE ALGORITHMS
    // ==============================================
    
    /**
     * Kruskal's Algorithm for Minimum Spanning Tree
     * Time Complexity: O(E log E)
     * Space Complexity: O(V)
     * 
     * @param edges List of all edges [src, dest, weight]
     * @param V Number of vertices
     * @return List of edges in MST
     */
    public static List<int[]> kruskalMST(List<int[]> edges, int V) {
        List<int[]> mst = new ArrayList<>();
        UnionFind uf = new UnionFind(V);
        
        // Sort edges by weight
        edges.sort((a, b) -> Integer.compare(a[2], b[2]));
        
        for (int[] edge : edges) {
            int u = edge[0], v = edge[1];
            
            // If vertices are in different components, add edge to MST
            if (uf.union(u, v)) {
                mst.add(edge);
                if (mst.size() == V - 1) break; // MST complete
            }
        }
        
        return mst;
    }
    
    /**
     * Prim's Algorithm for Minimum Spanning Tree
     * Time Complexity: O(E log V)
     * Space Complexity: O(V)
     * 
     * @param graph Weighted graph
     * @return Total weight of MST and list of edges
     */
    public static Pair<Integer, List<int[]>> primMST(Graph graph) {
        int V = graph.getVertices();
        boolean[] inMST = new boolean[V];
        int[] parent = new int[V];
        int[] key = new int[V];
        List<int[]> mstEdges = new ArrayList<>();
        
        Arrays.fill(key, Integer.MAX_VALUE);
        key[0] = 0;
        parent[0] = -1;
        
        PriorityQueue<Edge> pq = new PriorityQueue<>();
        pq.offer(new Edge(0, 0));
        
        int totalWeight = 0;
        
        while (!pq.isEmpty()) {
            Edge current = pq.poll();
            int u = current.dest;
            
            if (inMST[u]) continue;
            inMST[u] = true;
            totalWeight += current.weight;
            
            if (parent[u] != -1) {
                mstEdges.add(new int[]{parent[u], u, current.weight});
            }
            
            for (Edge edge : graph.getWeightedAdjList().get(u)) {
                int v = edge.dest;
                int weight = edge.weight;
                
                if (!inMST[v] && weight < key[v]) {
                    key[v] = weight;
                    parent[v] = u;
                    pq.offer(new Edge(v, weight));
                }
            }
        }
        
        return new Pair<>(totalWeight, mstEdges);
    }
    
    // ==============================================
    // TOPOLOGICAL SORTING
    // ==============================================
    
    /**
     * Topological Sort using Kahn's Algorithm (BFS approach)
     * Time Complexity: O(V + E)
     * Space Complexity: O(V)
     * 
     * @param graph Directed acyclic graph
     * @return Topologically sorted vertices, or null if cycle exists
     */
    public static List<Integer> topologicalSort(Graph graph) {
        int V = graph.getVertices();
        int[] inDegree = new int[V];
        
        // Calculate in-degrees
        for (int i = 0; i < V; i++) {
            for (int neighbor : graph.getAdjList().get(i)) {
                inDegree[neighbor]++;
            }
        }
        
        Queue<Integer> queue = new LinkedList<>();
        for (int i = 0; i < V; i++) {
            if (inDegree[i] == 0) {
                queue.offer(i);
            }
        }
        
        List<Integer> result = new ArrayList<>();
        
        while (!queue.isEmpty()) {
            int vertex = queue.poll();
            result.add(vertex);
            
            for (int neighbor : graph.getAdjList().get(vertex)) {
                inDegree[neighbor]--;
                if (inDegree[neighbor] == 0) {
                    queue.offer(neighbor);
                }
            }
        }
        
        // Check if all vertices are included (no cycle)
        return result.size() == V ? result : null;
    }
    
    /**
     * Topological Sort using DFS
     * Time Complexity: O(V + E)
     * Space Complexity: O(V)
     */
    public static List<Integer> topologicalSortDFS(Graph graph) {
        int V = graph.getVertices();
        boolean[] visited = new boolean[V];
        Stack<Integer> stack = new Stack<>();
        
        for (int i = 0; i < V; i++) {
            if (!visited[i]) {
                topologicalDFSHelper(graph, i, visited, stack);
            }
        }
        
        List<Integer> result = new ArrayList<>();
        while (!stack.isEmpty()) {
            result.add(stack.pop());
        }
        
        return result;
    }
    
    private static void topologicalDFSHelper(Graph graph, int vertex, boolean[] visited, Stack<Integer> stack) {
        visited[vertex] = true;
        
        for (int neighbor : graph.getAdjList().get(vertex)) {
            if (!visited[neighbor]) {
                topologicalDFSHelper(graph, neighbor, visited, stack);
            }
        }
        
        stack.push(vertex);
    }
    
    // ==============================================
    // CYCLE DETECTION
    // ==============================================
    
    /**
     * Detect cycle in undirected graph using DFS
     * Time Complexity: O(V + E)
     * Space Complexity: O(V)
     */
    public static boolean hasCycleUndirected(Graph graph) {
        int V = graph.getVertices();
        boolean[] visited = new boolean[V];
        
        for (int i = 0; i < V; i++) {
            if (!visited[i]) {
                if (hasCycleUndirectedDFS(graph, i, visited, -1)) {
                    return true;
                }
            }
        }
        return false;
    }
    
    private static boolean hasCycleUndirectedDFS(Graph graph, int vertex, boolean[] visited, int parent) {
        visited[vertex] = true;
        
        for (int neighbor : graph.getAdjList().get(vertex)) {
            if (!visited[neighbor]) {
                if (hasCycleUndirectedDFS(graph, neighbor, visited, vertex)) {
                    return true;
                }
            } else if (neighbor != parent) {
                return true; // Back edge found
            }
        }
        
        return false;
    }
    
    /**
     * Detect cycle in directed graph using DFS (Three-color approach)
     * Time Complexity: O(V + E)
     * Space Complexity: O(V)
     */
    public static boolean hasCycleDirected(Graph graph) {
        int V = graph.getVertices();
        int[] color = new int[V]; // 0: white, 1: gray, 2: black
        
        for (int i = 0; i < V; i++) {
            if (color[i] == 0) {
                if (hasCycleDirectedDFS(graph, i, color)) {
                    return true;
                }
            }
        }
        return false;
    }
    
    private static boolean hasCycleDirectedDFS(Graph graph, int vertex, int[] color) {
        color[vertex] = 1; // Mark as gray (in recursion stack)
        
        for (int neighbor : graph.getAdjList().get(vertex)) {
            if (color[neighbor] == 1) {
                return true; // Back edge to gray vertex
            }
            if (color[neighbor] == 0 && hasCycleDirectedDFS(graph, neighbor, color)) {
                return true;
            }
        }
        
        color[vertex] = 2; // Mark as black (completely processed)
        return false;
    }
    
    // ==============================================
    // CONNECTED COMPONENTS
    // ==============================================
    
    /**
     * Count connected components in undirected graph
     * Time Complexity: O(V + E)
     * Space Complexity: O(V)
     */
    public static int countConnectedComponents(Graph graph) {
        int V = graph.getVertices();
        boolean[] visited = new boolean[V];
        int components = 0;
        
        for (int i = 0; i < V; i++) {
            if (!visited[i]) {
                dfsComponent(graph, i, visited);
                components++;
            }
        }
        
        return components;
    }
    
    private static void dfsComponent(Graph graph, int vertex, boolean[] visited) {
        visited[vertex] = true;
        for (int neighbor : graph.getAdjList().get(vertex)) {
            if (!visited[neighbor]) {
                dfsComponent(graph, neighbor, visited);
            }
        }
    }
    
    /**
     * Check if graph is bipartite using BFS
     * Time Complexity: O(V + E)
     * Space Complexity: O(V)
     */
    public static boolean isBipartite(Graph graph) {
        int V = graph.getVertices();
        int[] color = new int[V];
        Arrays.fill(color, -1);
        
        for (int i = 0; i < V; i++) {
            if (color[i] == -1) {
                if (!bfsBipartite(graph, i, color)) {
                    return false;
                }
            }
        }
        
        return true;
    }
    
    private static boolean bfsBipartite(Graph graph, int start, int[] color) {
        Queue<Integer> queue = new LinkedList<>();
        color[start] = 0;
        queue.offer(start);
        
        while (!queue.isEmpty()) {
            int vertex = queue.poll();
            
            for (int neighbor : graph.getAdjList().get(vertex)) {
                if (color[neighbor] == -1) {
                    color[neighbor] = 1 - color[vertex];
                    queue.offer(neighbor);
                } else if (color[neighbor] == color[vertex]) {
                    return false; // Same color adjacent vertices
                }
            }
        }
        
        return true;
    }
    
    // ==============================================
    // UTILITY CLASSES
    // ==============================================
    
    static class Pair<T, U> {
        public T first;
        public U second;
        
        public Pair(T first, U second) {
            this.first = first;
            this.second = second;
        }
    }
    
    // ==============================================
    // DEMONSTRATION AND TESTING
    // ==============================================
    
    public static void main(String[] args) {
        System.out.println("Graph Algorithms Demo");
        System.out.println("====================");
        
        // Demo 1: Graph Traversal
        System.out.println("\n1. Graph Traversal Demo:");
        Graph graph1 = new Graph(6);
        graph1.addEdge(0, 1);
        graph1.addEdge(0, 2);
        graph1.addEdge(1, 3);
        graph1.addEdge(2, 4);
        graph1.addEdge(3, 5);
        graph1.addEdge(4, 5);
        
        System.out.println("DFS from vertex 0: " + dfsRecursive(graph1, 0));
        System.out.println("BFS from vertex 0: " + bfs(graph1, 0));
        
        // Demo 2: Shortest Path
        System.out.println("\n2. Shortest Path Demo:");
        Graph weightedGraph = new Graph(5, true);
        weightedGraph.addWeightedEdge(0, 1, 4);
        weightedGraph.addWeightedEdge(0, 2, 1);
        weightedGraph.addWeightedEdge(1, 3, 1);
        weightedGraph.addWeightedEdge(2, 1, 2);
        weightedGraph.addWeightedEdge(2, 3, 5);
        weightedGraph.addWeightedEdge(3, 4, 3);
        
        int[] distances = dijkstra(weightedGraph, 0);
        System.out.println("Shortest distances from vertex 0: " + Arrays.toString(distances));
        
        // Demo 3: MST
        System.out.println("\n3. Minimum Spanning Tree Demo:");
        List<int[]> edges = Arrays.asList(
            new int[]{0, 1, 4},
            new int[]{0, 2, 1},
            new int[]{1, 2, 2},
            new int[]{1, 3, 5},
            new int[]{2, 3, 3}
        );
        
        List<int[]> mst = kruskalMST(edges, 4);
        System.out.println("MST edges (Kruskal's):");
        for (int[] edge : mst) {
            System.out.println("  " + edge[0] + " - " + edge[1] + " (weight: " + edge[2] + ")");
        }
        
        // Demo 4: Topological Sort
        System.out.println("\n4. Topological Sort Demo:");
        Graph dag = new Graph(6);
        dag.addDirectedEdge(5, 2);
        dag.addDirectedEdge(5, 0);
        dag.addDirectedEdge(4, 0);
        dag.addDirectedEdge(4, 1);
        dag.addDirectedEdge(2, 3);
        dag.addDirectedEdge(3, 1);
        
        List<Integer> topoOrder = topologicalSort(dag);
        System.out.println("Topological order: " + topoOrder);
        
        // Demo 5: Cycle Detection
        System.out.println("\n5. Cycle Detection Demo:");
        System.out.println("Undirected graph has cycle: " + hasCycleUndirected(graph1));
        System.out.println("Directed acyclic graph has cycle: " + hasCycleDirected(dag));
        
        // Demo 6: Connected Components
        System.out.println("\n6. Connected Components Demo:");
        System.out.println("Number of connected components: " + countConnectedComponents(graph1));
        System.out.println("Is graph bipartite: " + isBipartite(graph1));
        
        System.out.println("\nDemo completed successfully!");
    }
}

/**
 * COMPLEXITY ANALYSIS SUMMARY:
 * ============================
 * 
 * TRAVERSAL ALGORITHMS:
 * - DFS: Time O(V + E), Space O(V)
 * - BFS: Time O(V + E), Space O(V)
 * 
 * SHORTEST PATH ALGORITHMS:
 * - Dijkstra: Time O((V + E) log V), Space O(V)
 * - Bellman-Ford: Time O(VE), Space O(V)
 * - Floyd-Warshall: Time O(V³), Space O(V²)
 * 
 * MINIMUM SPANNING TREE:
 * - Kruskal: Time O(E log E), Space O(V)
 * - Prim: Time O(E log V), Space O(V)
 * 
 * OTHER ALGORITHMS:
 * - Topological Sort: Time O(V + E), Space O(V)
 * - Cycle Detection: Time O(V + E), Space O(V)
 * - Connected Components: Time O(V + E), Space O(V)
 * - Bipartite Check: Time O(V + E), Space O(V)
 * 
 * KEY INSIGHTS:
 * - Most graph algorithms have linear time complexity O(V + E)
 * - Shortest path algorithms vary based on constraints
 * - MST algorithms depend on edge processing strategy
 * - Space complexity is typically O(V) for auxiliary structures
 */
