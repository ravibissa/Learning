/**
 * Binary Tree Implementation
 * 
 * This class demonstrates a complete implementation of a binary tree
 * with all basic operations and traversal methods.
 * 
 * @author DSA Tutorial
 * @version 1.0
 */
import java.util.*;

// TreeNode class for binary tree
class TreeNode {
    int val;
    TreeNode left;
    TreeNode right;
    
    TreeNode() {}
    
    TreeNode(int val) {
        this.val = val;
    }
    
    TreeNode(int val, TreeNode left, TreeNode right) {
        this.val = val;
        this.left = left;
        this.right = right;
    }
}

public class BinaryTree {
    private TreeNode root;
    
    public BinaryTree() {
        root = null;
    }
    
    /**
     * Insert a value into the tree (simple insertion, not balanced)
     * Time Complexity: O(n) - for unbalanced tree
     * Space Complexity: O(n) - for unbalanced tree
     */
    public void insert(int val) {
        root = insertRecursive(root, val);
    }
    
    private TreeNode insertRecursive(TreeNode node, int val) {
        if (node == null) {
            return new TreeNode(val);
        }
        
        // Simple insertion strategy (not balanced)
        if (val < node.val) {
            node.left = insertRecursive(node.left, val);
        } else {
            node.right = insertRecursive(node.right, val);
        }
        
        return node;
    }
    
    /**
     * Search for a value in the tree
     * Time Complexity: O(n) - for unbalanced tree
     * Space Complexity: O(n) - for unbalanced tree
     */
    public boolean search(int val) {
        return searchRecursive(root, val);
    }
    
    private boolean searchRecursive(TreeNode node, int val) {
        if (node == null) {
            return false;
        }
        
        if (node.val == val) {
            return true;
        }
        
        return searchRecursive(node.left, val) || 
               searchRecursive(node.right, val);
    }
    
    /**
     * Delete a value from the tree
     * Time Complexity: O(n)
     * Space Complexity: O(n)
     */
    public void delete(int val) {
        root = deleteRecursive(root, val);
    }
    
    private TreeNode deleteRecursive(TreeNode node, int val) {
        if (node == null) {
            return null;
        }
        
        if (val < node.val) {
            node.left = deleteRecursive(node.left, val);
        } else if (val > node.val) {
            node.right = deleteRecursive(node.right, val);
        } else {
            // Node to be deleted found
            
            // Case 1: Node with no children (leaf node)
            if (node.left == null && node.right == null) {
                return null;
            }
            
            // Case 2: Node with one child
            if (node.left == null) {
                return node.right;
            }
            if (node.right == null) {
                return node.left;
            }
            
            // Case 3: Node with two children
            // Find inorder successor (smallest in right subtree)
            TreeNode successor = findMin(node.right);
            node.val = successor.val;
            node.right = deleteRecursive(node.right, successor.val);
        }
        
        return node;
    }
    
    /**
     * Find minimum value node
     */
    private TreeNode findMin(TreeNode node) {
        while (node.left != null) {
            node = node.left;
        }
        return node;
    }
    
    /**
     * Get height of the tree
     * Time Complexity: O(n)
     * Space Complexity: O(h) where h is height
     */
    public int getHeight() {
        return getHeightRecursive(root);
    }
    
    private int getHeightRecursive(TreeNode node) {
        if (node == null) {
            return 0;
        }
        
        int leftHeight = getHeightRecursive(node.left);
        int rightHeight = getHeightRecursive(node.right);
        
        return Math.max(leftHeight, rightHeight) + 1;
    }
    
    /**
     * Count total number of nodes
     * Time Complexity: O(n)
     * Space Complexity: O(h)
     */
    public int countNodes() {
        return countNodesRecursive(root);
    }
    
    private int countNodesRecursive(TreeNode node) {
        if (node == null) {
            return 0;
        }
        
        return 1 + countNodesRecursive(node.left) + countNodesRecursive(node.right);
    }
    
    /**
     * Count number of leaf nodes
     * Time Complexity: O(n)
     * Space Complexity: O(h)
     */
    public int countLeaves() {
        return countLeavesRecursive(root);
    }
    
    private int countLeavesRecursive(TreeNode node) {
        if (node == null) {
            return 0;
        }
        
        if (node.left == null && node.right == null) {
            return 1;
        }
        
        return countLeavesRecursive(node.left) + countLeavesRecursive(node.right);
    }
    
    /**
     * Check if tree is empty
     * Time Complexity: O(1)
     * Space Complexity: O(1)
     */
    public boolean isEmpty() {
        return root == null;
    }
    
    /**
     * Clear the entire tree
     * Time Complexity: O(1)
     * Space Complexity: O(1)
     */
    public void clear() {
        root = null;
    }
    
    /**
     * Get root node
     * Time Complexity: O(1)
     * Space Complexity: O(1)
     */
    public TreeNode getRoot() {
        return root;
    }
    
    /**
     * Set root node
     * Time Complexity: O(1)
     * Space Complexity: O(1)
     */
    public void setRoot(TreeNode root) {
        this.root = root;
    }
    
    /**
     * Check if tree is balanced
     * Time Complexity: O(n)
     * Space Complexity: O(h)
     */
    public boolean isBalanced() {
        return isBalancedRecursive(root) != -1;
    }
    
    private int isBalancedRecursive(TreeNode node) {
        if (node == null) {
            return 0;
        }
        
        int leftHeight = isBalancedRecursive(node.left);
        if (leftHeight == -1) return -1;
        
        int rightHeight = isBalancedRecursive(node.right);
        if (rightHeight == -1) return -1;
        
        if (Math.abs(leftHeight - rightHeight) > 1) {
            return -1;
        }
        
        return Math.max(leftHeight, rightHeight) + 1;
    }
    
    /**
     * Check if tree is complete
     * Time Complexity: O(n)
     * Space Complexity: O(w) where w is maximum width
     */
    public boolean isComplete() {
        if (root == null) return true;
        
        Queue<TreeNode> queue = new LinkedList<>();
        queue.offer(root);
        boolean foundNull = false;
        
        while (!queue.isEmpty()) {
            TreeNode node = queue.poll();
            
            if (node == null) {
                foundNull = true;
            } else {
                if (foundNull) return false; // Found non-null after null
                queue.offer(node.left);
                queue.offer(node.right);
            }
        }
        
        return true;
    }
    
    /**
     * Check if tree is full (every node has 0 or 2 children)
     * Time Complexity: O(n)
     * Space Complexity: O(h)
     */
    public boolean isFull() {
        return isFullRecursive(root);
    }
    
    private boolean isFullRecursive(TreeNode node) {
        if (node == null) return true;
        
        // If node has no children, it's full
        if (node.left == null && node.right == null) return true;
        
        // If node has both children, check subtrees
        if (node.left != null && node.right != null) {
            return isFullRecursive(node.left) && isFullRecursive(node.right);
        }
        
        // If node has only one child, it's not full
        return false;
    }
    
    /**
     * Check if tree is perfect (all levels are completely filled)
     * Time Complexity: O(n)
     * Space Complexity: O(h)
     */
    public boolean isPerfect() {
        int height = getHeight();
        return isPerfectRecursive(root, height, 0);
    }
    
    private boolean isPerfectRecursive(TreeNode node, int height, int level) {
        if (node == null) return true;
        
        // If it's a leaf node, check if it's at the last level
        if (node.left == null && node.right == null) {
            return level == height - 1;
        }
        
        // If it's not a leaf node, check if it has both children
        if (node.left == null || node.right == null) {
            return false;
        }
        
        return isPerfectRecursive(node.left, height, level + 1) &&
               isPerfectRecursive(node.right, height, level + 1);
    }
    
    public static void main(String[] args) {
        System.out.println("=== Binary Tree Demo ===\n");
        
        BinaryTree tree = new BinaryTree();
        
        // Test insertion
        System.out.println("1. Insertion Operations:");
        tree.insert(5);
        tree.insert(3);
        tree.insert(7);
        tree.insert(2);
        tree.insert(4);
        tree.insert(6);
        tree.insert(8);
        System.out.println("Tree created with values: 5, 3, 7, 2, 4, 6, 8");
        System.out.println();
        
        // Test search
        System.out.println("2. Search Operations:");
        System.out.println("Search for 4: " + tree.search(4));
        System.out.println("Search for 9: " + tree.search(9));
        System.out.println();
        
        // Test tree properties
        System.out.println("3. Tree Properties:");
        System.out.println("Height: " + tree.getHeight());
        System.out.println("Total nodes: " + tree.countNodes());
        System.out.println("Leaf nodes: " + tree.countLeaves());
        System.out.println("Is balanced: " + tree.isBalanced());
        System.out.println("Is complete: " + tree.isComplete());
        System.out.println("Is full: " + tree.isFull());
        System.out.println("Is perfect: " + tree.isPerfect());
        System.out.println();
        
        // Test deletion
        System.out.println("4. Deletion Operations:");
        System.out.println("Before deletion - Total nodes: " + tree.countNodes());
        tree.delete(4);
        System.out.println("After deleting 4 - Total nodes: " + tree.countNodes());
        System.out.println("Search for 4 after deletion: " + tree.search(4));
        System.out.println();
        
        // Test clear
        System.out.println("5. Clear Tree:");
        System.out.println("Before clear - Is empty: " + tree.isEmpty());
        tree.clear();
        System.out.println("After clear - Is empty: " + tree.isEmpty());
        System.out.println("After clear - Height: " + tree.getHeight());
        
        System.out.println("\n=== Key Takeaways ===");
        System.out.println("• Insertion: O(n) for unbalanced tree");
        System.out.println("• Search: O(n) for unbalanced tree");
        System.out.println("• Deletion: O(n) for unbalanced tree");
        System.out.println("• Height calculation: O(n)");
        System.out.println("• Tree properties can be checked efficiently");
        System.out.println("• Binary trees are fundamental for many algorithms");
    }
}
