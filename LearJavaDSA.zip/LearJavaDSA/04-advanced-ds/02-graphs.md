# Graphs - Complete Tutorial

## Table of Contents
1. [Introduction to Graphs](#introduction-to-graphs)
2. [Graph Representation](#graph-representation)
3. [Graph Traversal Algorithms](#graph-traversal-algorithms)
4. [Shortest Path Algorithms](#shortest-path-algorithms)
5. [Minimum Spanning Tree](#minimum-spanning-tree)
6. [Topological Sorting](#topological-sorting)
7. [Common Graph Problems](#common-graph-problems)
8. [Advanced Graph Algorithms](#advanced-graph-algorithms)
9. [Practice Problems](#practice-problems)

## Introduction to Graphs

### What is a Graph?
A graph is a collection of vertices (nodes) connected by edges. It's one of the most versatile data structures in computer science.

**Think of it like this:** Imagine a social network where people are vertices and friendships are edges connecting them. This is exactly how graphs work!

### Real-World Examples
- **Social Networks**: People as vertices, friendships as edges
- **Road Networks**: Cities as vertices, roads as edges
- **Web Pages**: Pages as vertices, links as edges
- **Computer Networks**: Computers as vertices, connections as edges
- **Family Trees**: People as vertices, relationships as edges
- **Flight Routes**: Airports as vertices, flights as edges

### Graph Terminology

#### Basic Terms
- **Vertex (Node)**: A point in the graph (like a person in social network)
- **Edge**: A connection between two vertices (like a friendship)
- **Path**: A sequence of vertices connected by edges (route from A to B)
- **Cycle**: A path that starts and ends at the same vertex (round trip)
- **Degree**: Number of edges connected to a vertex (number of friends)

#### Graph Types
1. **Directed Graph (Digraph)**: Edges have direction (one-way street)
   - Example: Twitter follows (A follows B doesn't mean B follows A)
2. **Undirected Graph**: Edges have no direction (two-way street)
   - Example: Facebook friendship (mutual connection)
3. **Weighted Graph**: Edges have weights/costs (distance, time, cost)
   - Example: Road network with distances
4. **Unweighted Graph**: All edges have equal weight
   - Example: Simple friendship network

### Graph Properties
- **Dense Graph**: Many edges (highly connected social network)
- **Sparse Graph**: Few edges compared to maximum possible
- **Complete Graph**: Every vertex connected to every other vertex
- **Connected Graph**: Path exists between any two vertices
- **Disconnected Graph**: Some vertices are isolated
- **Bipartite Graph**: Vertices can be divided into two groups with no internal connections

## Graph Representation

### 1. Adjacency Matrix
A 2D array where `matrix[i][j]` represents the edge between vertices i and j.

```
For graph: A-B, A-C, B-C
    A  B  C
A   0  1  1
B   1  0  1  
C   1  1  0
```

**Advantages:**
- O(1) edge lookup - Very fast to check if edge exists
- Easy to implement
- Good for dense graphs
- Simple to understand

**Disadvantages:**
- O(V²) space complexity - Uses lots of memory
- Inefficient for sparse graphs
- Adding/removing vertices is expensive

**When to use:** Dense graphs, frequent edge lookups, small graphs

### 2. Adjacency List
An array of lists where each list contains neighbors of a vertex.

```
For graph: A-B, A-C, B-C
A: [B, C]
B: [A, C]
C: [A, B]
```

**Advantages:**
- O(V + E) space complexity - Memory efficient
- Efficient for sparse graphs
- Easy to iterate over neighbors
- Fast to add/remove edges

**Disadvantages:**
- O(degree) edge lookup - Slower than matrix
- More complex to implement
- Cache performance can be poor

**When to use:** Sparse graphs, graph traversal, most real-world graphs

### 3. Edge List
A list of all edges in the graph.

```
For graph: A-B, A-C, B-C
Edges: [(A,B), (A,C), (B,C)]
```

**Advantages:**
- Simple representation
- Memory efficient for sparse graphs
- Good for some algorithms (Kruskal's MST)

**Disadvantages:**
- O(E) edge lookup - Very slow
- Difficult to find neighbors
- Less efficient for most operations

**When to use:** Simple algorithms, when you need to process all edges

## Graph Traversal Algorithms

### Depth-First Search (DFS)
**Think of it like:** Exploring a maze by going as deep as possible before backtracking.

**How it works:**
1. Start at a vertex
2. Go as deep as possible along each branch
3. Backtrack when you reach a dead end
4. Continue until all vertices visited

**Applications:**
- Finding connected components
- Detecting cycles
- Topological sorting
- Maze solving
- Finding strongly connected components

**Time Complexity:** O(V + E)
**Space Complexity:** O(V) for recursion stack

**Algorithm Steps:**
1. Mark current vertex as visited
2. For each unvisited neighbor:
   - Recursively call DFS on neighbor
3. Backtrack when no unvisited neighbors

### Breadth-First Search (BFS)
**Think of it like:** Exploring level by level, like ripples in a pond.

**How it works:**
1. Start at a vertex
2. Visit all neighbors at current level
3. Move to next level
4. Continue until all vertices visited

**Applications:**
- Shortest path in unweighted graphs
- Level-order traversal
- Finding minimum spanning tree
- Social network analysis (degrees of separation)
- Web crawling

**Time Complexity:** O(V + E)
**Space Complexity:** O(V) for queue

**Algorithm Steps:**
1. Add starting vertex to queue
2. While queue is not empty:
   - Remove vertex from queue
   - Visit all unvisited neighbors
   - Add neighbors to queue

### DFS vs BFS Comparison

| Feature | DFS | BFS |
|---------|-----|-----|
| Data Structure | Stack (recursion) | Queue |
| Memory Usage | O(depth) | O(width) |
| Path Found | Any path | Shortest path |
| Implementation | Recursive/Iterative | Iterative |
| Use Case | Deep exploration | Level exploration |

## Shortest Path Algorithms

### 1. Dijkstra's Algorithm
**The Problem:** Find shortest path from source to all other vertices in weighted graph.

**Think of it like:** Finding the fastest route using GPS navigation.

**Key Points:**
- Works only with non-negative weights
- Uses priority queue (min-heap)
- Greedy approach - always picks shortest known distance
- Guarantees optimal solution

**Algorithm Steps:**
1. Initialize distances: source = 0, others = infinity
2. Add all vertices to priority queue
3. While queue not empty:
   - Extract vertex with minimum distance
   - For each neighbor, try to relax edge
   - Update distance if shorter path found

**Time Complexity:** O((V + E) log V) with binary heap
**Space Complexity:** O(V)

**Real-world applications:**
- GPS navigation systems
- Network routing protocols
- Social network analysis
- Game pathfinding

### 2. Bellman-Ford Algorithm
**The Problem:** Find shortest path when negative weights exist.

**Key Points:**
- Can detect negative cycles
- Works with negative edge weights
- Relaxes all edges V-1 times
- Slower than Dijkstra but more versatile

**Algorithm Steps:**
1. Initialize distances: source = 0, others = infinity
2. Repeat V-1 times:
   - For each edge (u,v): relax if dist[u] + weight < dist[v]
3. Check for negative cycles by trying one more relaxation

**Time Complexity:** O(VE)
**Space Complexity:** O(V)

**When to use:** When graph has negative weights, detecting negative cycles

### 3. Floyd-Warshall Algorithm
**The Problem:** Find shortest path between ALL pairs of vertices.

**Key Points:**
- Dynamic programming approach
- Works with negative weights (but no negative cycles)
- Finds all-pairs shortest path
- Uses intermediate vertices to build optimal paths

**Algorithm Steps:**
1. Initialize distance matrix with direct edge weights
2. For each intermediate vertex k:
   - For each pair (i,j): check if path through k is shorter
   - Update distance[i][j] if shorter path found

**Time Complexity:** O(V³)
**Space Complexity:** O(V²)

**When to use:** When you need shortest paths between all vertex pairs

## Minimum Spanning Tree

### What is MST?
A **Minimum Spanning Tree** connects all vertices with minimum total edge weight, forming a tree (no cycles).

**Real-world examples:**
- Connecting cities with minimum cost roads
- Designing efficient communication networks
- Clustering analysis
- Circuit design

**Properties of MST:**
- Has exactly V-1 edges (where V is number of vertices)
- No cycles
- Connects all vertices
- Minimum total weight among all possible spanning trees

### Kruskal's Algorithm
**Strategy:** Sort edges by weight and add them if they don't create cycles.

**Algorithm Steps:**
1. Sort all edges by weight (ascending)
2. Initialize each vertex as separate component
3. For each edge in sorted order:
   - If endpoints are in different components: add edge
   - Union the components
4. Stop when we have V-1 edges

**Data Structure:** Union-Find (Disjoint Set Union)
**Time Complexity:** O(E log E) - dominated by sorting
**Space Complexity:** O(V) for Union-Find

**When to use:** Sparse graphs, when edges are already sorted

### Prim's Algorithm
**Strategy:** Start with any vertex and grow tree by adding minimum weight edge.

**Algorithm Steps:**
1. Start with arbitrary vertex
2. Maintain set of vertices in MST
3. Repeat until all vertices included:
   - Find minimum weight edge from MST to non-MST vertex
   - Add this edge and vertex to MST

**Data Structure:** Priority Queue
**Time Complexity:** O(E log V) with binary heap
**Space Complexity:** O(V)

**When to use:** Dense graphs, when you want to start from specific vertex

### Kruskal's vs Prim's

| Feature | Kruskal's | Prim's |
|---------|-----------|--------|
| Strategy | Edge-based | Vertex-based |
| Data Structure | Union-Find | Priority Queue |
| Best for | Sparse graphs | Dense graphs |
| Edge selection | Global minimum | Local minimum |
| Parallelizable | Yes | No |

## Topological Sorting

### What is Topological Sort?
An ordering of vertices in a directed acyclic graph (DAG) where for every directed edge (u, v), vertex u comes before vertex v in the ordering.

**Think of it like:** Arranging tasks based on their dependencies.

### Real-world Applications
- **Course scheduling:** Prerequisites must come before advanced courses
- **Build systems:** Compile dependencies before main program
- **Task scheduling:** Complete dependencies before dependent tasks
- **Package management:** Install dependencies before packages
- **Makefile execution:** Build targets in correct order

### Algorithm (Kahn's Algorithm)
1. Calculate in-degrees of all vertices (number of incoming edges)
2. Add all vertices with in-degree 0 to queue
3. While queue is not empty:
   - Remove vertex from queue and add to result
   - For each neighbor: decrease in-degree by 1
   - If neighbor's in-degree becomes 0: add to queue
4. If result contains all vertices: valid topological sort

**Time Complexity:** O(V + E)
**Space Complexity:** O(V)

### Detection of Cycles
- If topological sort includes all vertices: No cycle
- If some vertices remain: Cycle exists
- Cycle detection is crucial for dependency management

## Common Graph Problems

### 1. Cycle Detection

#### Undirected Graph
**Method:** DFS with parent tracking
- During DFS, if we visit a vertex that's already visited and it's not the parent: cycle found
- Keep track of parent to avoid false detection

#### Directed Graph  
**Method:** DFS with recursion stack (three-color approach)
- **White (0):** Unvisited
- **Gray (1):** In recursion stack (being processed)
- **Black (2):** Completely processed
- If we reach a gray vertex: back edge found = cycle

### 2. Connected Components

#### Undirected Graph
**Method:** DFS/BFS from each unvisited vertex
- Each DFS/BFS call finds one connected component
- Count the number of DFS/BFS calls needed

#### Strongly Connected Components (Directed)
**Methods:**
- **Kosaraju's Algorithm:** Two DFS passes
- **Tarjan's Algorithm:** Single DFS with low-link values

### 3. Bipartite Graph
**Definition:** Graph whose vertices can be divided into two disjoint sets such that no two vertices within the same set are adjacent.

**Method:** BFS/DFS with 2-coloring
- Try to color graph with two colors
- If successful: bipartite
- If conflict occurs: not bipartite

**Applications:**
- Matching problems
- Scheduling problems
- Network flow

### 4. Graph Coloring
**Problem:** Assign colors to vertices such that no two adjacent vertices have the same color.

**Objective:** Minimize number of colors needed

**Applications:**
- Register allocation in compilers
- Scheduling problems
- Map coloring
- Frequency assignment

## Advanced Graph Algorithms

### 1. Strongly Connected Components (SCC)

#### Kosaraju's Algorithm
1. Perform DFS on original graph, store finish times
2. Create transpose graph (reverse all edges)
3. Perform DFS on transpose in decreasing order of finish times
4. Each DFS tree in step 3 is one SCC

#### Tarjan's Algorithm
- Single DFS pass
- Uses low-link values and stack
- More efficient in practice

### 2. Articulation Points and Bridges

#### Articulation Points (Cut Vertices)
**Definition:** Vertices whose removal increases the number of connected components.

**Applications:**
- Network reliability
- Social network analysis
- Transportation networks

#### Bridges (Cut Edges)
**Definition:** Edges whose removal increases the number of connected components.

**Tarjan's Algorithm:** Uses DFS with discovery times and low values

### 3. Network Flow

#### Maximum Flow Problem
**Given:** Flow network with source and sink
**Goal:** Find maximum flow from source to sink

#### Ford-Fulkerson Algorithm
- Find augmenting paths in residual graph
- Update flow until no more augmenting paths exist

#### Applications:
- Traffic flow optimization
- Network capacity planning
- Bipartite matching
- Supply chain optimization

### 4. Graph Matching

#### Maximum Matching
**Definition:** Largest set of edges with no shared vertices.

#### Bipartite Matching
- Can be solved using network flow
- Hungarian algorithm for weighted bipartite matching

#### Applications:
- Job assignment
- Marriage problem
- Resource allocation

## Practice Problems

### Easy Level (Getting Started)
1. **Number of Islands** 
   - **Concept:** Connected components using DFS/BFS
   - **Difficulty:** ⭐⭐
   - **Key Skills:** Grid traversal, DFS implementation

2. **Course Schedule**
   - **Concept:** Cycle detection in directed graph
   - **Difficulty:** ⭐⭐
   - **Key Skills:** Topological sort, DFS cycle detection

3. **Clone Graph**
   - **Concept:** Graph traversal and copying
   - **Difficulty:** ⭐⭐
   - **Key Skills:** DFS/BFS, HashMap for mapping

4. **Valid Path**
   - **Concept:** Graph connectivity
   - **Difficulty:** ⭐
   - **Key Skills:** Basic DFS/BFS

5. **Find Center of Star Graph**
   - **Concept:** Graph properties
   - **Difficulty:** ⭐
   - **Key Skills:** Understanding graph structure

### Medium Level (Building Skills)
1. **Course Schedule II**
   - **Concept:** Topological sorting with ordering
   - **Difficulty:** ⭐⭐⭐
   - **Key Skills:** Kahn's algorithm, dependency resolution

2. **Redundant Connection**
   - **Concept:** Union-Find for cycle detection
   - **Difficulty:** ⭐⭐⭐
   - **Key Skills:** Union-Find data structure

3. **Network Delay Time**
   - **Concept:** Single-source shortest path
   - **Difficulty:** ⭐⭐⭐
   - **Key Skills:** Dijkstra's algorithm

4. **Word Ladder**
   - **Concept:** BFS shortest path in implicit graph
   - **Difficulty:** ⭐⭐⭐
   - **Key Skills:** BFS, string manipulation, graph modeling

5. **Critical Connections**
   - **Concept:** Finding bridges in network
   - **Difficulty:** ⭐⭐⭐⭐
   - **Key Skills:** Tarjan's algorithm, DFS tree

### Hard Level (Advanced Concepts)
1. **Alien Dictionary**
   - **Concept:** Topological sort with constraints
   - **Difficulty:** ⭐⭐⭐⭐⭐
   - **Key Skills:** Graph construction from constraints

2. **Minimum Cost to Connect All Points**
   - **Concept:** Minimum spanning tree
   - **Difficulty:** ⭐⭐⭐⭐
   - **Key Skills:** Kruskal's or Prim's algorithm

3. **Cheapest Flights Within K Stops**
   - **Concept:** Shortest path with constraints
   - **Difficulty:** ⭐⭐⭐⭐
   - **Key Skills:** Modified Dijkstra/Bellman-Ford

4. **Graph Valid Tree**
   - **Concept:** Tree properties in graphs
   - **Difficulty:** ⭐⭐⭐
   - **Key Skills:** Cycle detection, connectivity

5. **Reconstruct Itinerary**
   - **Concept:** Eulerian path/circuit
   - **Difficulty:** ⭐⭐⭐⭐
   - **Key Skills:** Hierholzer's algorithm, DFS

## Interview Tips

### Common Graph Interview Questions

#### 1. "How would you represent a graph?"
**Expected Answer:**
- Discuss both adjacency matrix and adjacency list
- Compare time and space complexity
- Consider the specific use case:
  - Dense graphs: Matrix might be better
  - Sparse graphs: List is usually better
  - Frequent edge lookups: Matrix
  - Memory-constrained: List

#### 2. "When would you use DFS vs BFS?"
**DFS when:**
- Deep exploration needed
- Memory is limited (recursion uses O(depth))
- Finding any path is sufficient
- Topological sorting
- Cycle detection

**BFS when:**
- Shortest path needed (unweighted)
- Level-order traversal
- Finding minimum steps/hops
- Social network analysis (degrees of separation)

#### 3. "How do you detect cycles in a graph?"
**Undirected Graph:**
- DFS with parent tracking
- If we visit a node that's already visited and it's not the parent: cycle

**Directed Graph:**
- DFS with three colors (white, gray, black)
- Back edge detection
- Union-Find can also work

#### 4. "Explain Dijkstra's algorithm"
**Key Points:**
- Greedy algorithm for shortest path
- Uses priority queue (min-heap)
- Only works with non-negative weights
- Relaxation process
- Time complexity: O((V + E) log V)

### Problem-Solving Strategy

#### Step 1: Identify the Problem Type
- **Traversal:** DFS/BFS
- **Shortest Path:** Dijkstra, BFS (unweighted), Bellman-Ford
- **Connectivity:** Union-Find, DFS/BFS
- **Cycle Detection:** DFS-based approaches
- **Topological Sort:** Kahn's algorithm, DFS
- **MST:** Kruskal's, Prim's

#### Step 2: Choose Graph Representation
- **Sparse graph:** Adjacency list
- **Dense graph:** Adjacency matrix
- **Edge processing:** Edge list
- **Memory constraint:** Consider space complexity

#### Step 3: Consider Edge Cases
- Empty graph
- Single vertex
- Disconnected components
- Self-loops
- Negative weights (if applicable)
- Large input sizes

#### Step 4: Optimize
- Can you use bidirectional search?
- Can you stop early?
- Can you use heuristics?
- Memory vs time trade-offs

### Common Patterns in Graph Problems

#### Pattern 1: "Count Connected Components"
```java
int components = 0;
boolean[] visited = new boolean[n];
for (int i = 0; i < n; i++) {
    if (!visited[i]) {
        dfs(i, visited, graph);
        components++;
    }
}
```

#### Pattern 2: "Shortest Path in Unweighted Graph"
```java
Queue<Integer> queue = new LinkedList<>();
int[] distance = new int[n];
Arrays.fill(distance, -1);
queue.offer(start);
distance[start] = 0;

while (!queue.isEmpty()) {
    int curr = queue.poll();
    for (int neighbor : graph.get(curr)) {
        if (distance[neighbor] == -1) {
            distance[neighbor] = distance[curr] + 1;
            queue.offer(neighbor);
        }
    }
}
```

#### Pattern 3: "Cycle Detection in Directed Graph"
```java
enum Color { WHITE, GRAY, BLACK }
Color[] colors = new Color[n];

boolean hasCycle(int node) {
    colors[node] = Color.GRAY;
    for (int neighbor : graph.get(node)) {
        if (colors[neighbor] == Color.GRAY) return true;
        if (colors[neighbor] == Color.WHITE && hasCycle(neighbor)) return true;
    }
    colors[node] = Color.BLACK;
    return false;
}
```

## Next Steps

### Immediate Practice (Week 1-2)
1. Implement basic graph representations
2. Master DFS and BFS traversals
3. Solve 5-10 easy graph problems
4. Practice drawing graphs for better visualization

### Intermediate Development (Week 3-4)
1. Learn and implement shortest path algorithms
2. Practice topological sorting problems
3. Understand Union-Find data structure
4. Solve medium-level graph problems

### Advanced Mastery (Week 5-8)
1. Study advanced algorithms (Tarjan's, Kosaraju's)
2. Learn about network flow and matching
3. Practice hard graph problems
4. Study graph optimization techniques

### Interview Preparation
1. Practice explaining algorithms verbally
2. Focus on time and space complexity analysis
3. Learn to identify graph problems in disguise
4. Practice coding under time pressure

### Resources for Further Learning
- **Books:** "Introduction to Algorithms" (CLRS), "Algorithm Design Manual"
- **Online Platforms:** LeetCode, HackerRank, Codeforces
- **Visualization Tools:** VisuAlgo, Graph Online
- **Practice:** Solve at least 50+ graph problems

## Summary

Graphs are fundamental to computer science and appear in many real-world applications. Key takeaways:

1. **Understand the basics:** Representation, terminology, and properties
2. **Master traversal:** DFS and BFS are building blocks for everything else
3. **Learn patterns:** Many graph problems follow similar patterns
4. **Practice regularly:** Graph problems require practice to recognize patterns
5. **Think systematically:** Always consider representation, algorithm choice, and edge cases

Remember: Graphs might seem complex initially, but with consistent practice and understanding of core concepts, you'll be able to tackle any graph problem confidently!

**Success Formula:** Theory + Implementation + Practice = Graph Algorithm Mastery 🚀
