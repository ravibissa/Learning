/**
 * Singly Linked List Implementation
 * 
 * This class demonstrates a complete implementation of a singly linked list
 * with all basic operations and common algorithms.
 * 
 * @author DSA Tutorial
 * @version 1.0
 */

// Node class for singly linked list
class ListNode {
    int val;
    ListNode next;
    
    ListNode() {}
    
    ListNode(int val) {
        this.val = val;
    }
    
    ListNode(int val, ListNode next) {
        this.val = val;
        this.next = next;
    }
}

public class SinglyLinkedList {
    private ListNode head;
    private int size;
    
    public SinglyLinkedList() {
        head = null;
        size = 0;
    }
    
    /**
     * Insert at the beginning
     * Time Complexity: O(1)
     * Space Complexity: O(1)
     */
    public void insertAtBeginning(int val) {
        ListNode newNode = new ListNode(val);
        newNode.next = head;
        head = newNode;
        size++;
    }
    
    /**
     * Insert at the end
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     */
    public void insertAtEnd(int val) {
        ListNode newNode = new ListNode(val);
        
        if (head == null) {
            head = newNode;
        } else {
            ListNode current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
        size++;
    }
    
    /**
     * Insert at specific position
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     */
    public void insertAtPosition(int val, int position) {
        if (position < 0 || position > size) {
            System.out.println("Invalid position");
            return;
        }
        
        if (position == 0) {
            insertAtBeginning(val);
            return;
        }
        
        ListNode newNode = new ListNode(val);
        ListNode current = head;
        
        for (int i = 0; i < position - 1; i++) {
            current = current.next;
        }
        
        newNode.next = current.next;
        current.next = newNode;
        size++;
    }
    
    /**
     * Delete from beginning
     * Time Complexity: O(1)
     * Space Complexity: O(1)
     */
    public void deleteFromBeginning() {
        if (head == null) {
            System.out.println("List is empty");
            return;
        }
        
        head = head.next;
        size--;
    }
    
    /**
     * Delete from end
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     */
    public void deleteFromEnd() {
        if (head == null) {
            System.out.println("List is empty");
            return;
        }
        
        if (head.next == null) {
            head = null;
        } else {
            ListNode current = head;
            while (current.next.next != null) {
                current = current.next;
            }
            current.next = null;
        }
        size--;
    }
    
    /**
     * Delete by value
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     */
    public boolean deleteByValue(int val) {
        if (head == null) {
            return false;
        }
        
        if (head.val == val) {
            head = head.next;
            size--;
            return true;
        }
        
        ListNode current = head;
        while (current.next != null) {
            if (current.next.val == val) {
                current.next = current.next.next;
                size--;
                return true;
            }
            current = current.next;
        }
        
        return false;
    }
    
    /**
     * Delete at specific position
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     */
    public void deleteAtPosition(int position) {
        if (position < 0 || position >= size) {
            System.out.println("Invalid position");
            return;
        }
        
        if (position == 0) {
            deleteFromBeginning();
            return;
        }
        
        ListNode current = head;
        for (int i = 0; i < position - 1; i++) {
            current = current.next;
        }
        
        current.next = current.next.next;
        size--;
    }
    
    /**
     * Search for a value
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     */
    public boolean search(int val) {
        ListNode current = head;
        while (current != null) {
            if (current.val == val) {
                return true;
            }
            current = current.next;
        }
        return false;
    }
    
    /**
     * Get value at specific position
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     */
    public int get(int position) {
        if (position < 0 || position >= size) {
            throw new IndexOutOfBoundsException("Invalid position");
        }
        
        ListNode current = head;
        for (int i = 0; i < position; i++) {
            current = current.next;
        }
        return current.val;
    }
    
    /**
     * Update value at specific position
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     */
    public void set(int position, int val) {
        if (position < 0 || position >= size) {
            throw new IndexOutOfBoundsException("Invalid position");
        }
        
        ListNode current = head;
        for (int i = 0; i < position; i++) {
            current = current.next;
        }
        current.val = val;
    }
    
    /**
     * Get length of the list
     * Time Complexity: O(1) - we maintain size
     * Space Complexity: O(1)
     */
    public int getLength() {
        return size;
    }
    
    /**
     * Check if list is empty
     * Time Complexity: O(1)
     * Space Complexity: O(1)
     */
    public boolean isEmpty() {
        return head == null;
    }
    
    /**
     * Print all elements in the list
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     */
    public void printList() {
        ListNode current = head;
        System.out.print("List: ");
        while (current != null) {
            System.out.print(current.val + " -> ");
            current = current.next;
        }
        System.out.println("null");
    }
    
    /**
     * Convert list to array
     * Time Complexity: O(n)
     * Space Complexity: O(n)
     */
    public int[] toArray() {
        int[] array = new int[size];
        ListNode current = head;
        int index = 0;
        
        while (current != null) {
            array[index++] = current.val;
            current = current.next;
        }
        
        return array;
    }
    
    /**
     * Clear the entire list
     * Time Complexity: O(1)
     * Space Complexity: O(1)
     */
    public void clear() {
        head = null;
        size = 0;
    }
    
    /**
     * Reverse the linked list iteratively
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     */
    public void reverse() {
        ListNode prev = null;
        ListNode current = head;
        
        while (current != null) {
            ListNode next = current.next;
            current.next = prev;
            prev = current;
            current = next;
        }
        
        head = prev;
    }
    
    /**
     * Reverse the linked list recursively
     * Time Complexity: O(n)
     * Space Complexity: O(n) - due to recursion stack
     */
    public void reverseRecursive() {
        head = reverseRecursiveHelper(head);
    }
    
    private ListNode reverseRecursiveHelper(ListNode node) {
        if (node == null || node.next == null) {
            return node;
        }
        
        ListNode newHead = reverseRecursiveHelper(node.next);
        node.next.next = node;
        node.next = null;
        
        return newHead;
    }
    
    /**
     * Find middle node using slow and fast pointers
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     */
    public ListNode findMiddle() {
        if (head == null) return null;
        
        ListNode slow = head;
        ListNode fast = head;
        
        while (fast != null && fast.next != null) {
            slow = slow.next;
            fast = fast.next.next;
        }
        
        return slow;
    }
    
    /**
     * Detect cycle using Floyd's cycle detection algorithm
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     */
    public boolean hasCycle() {
        if (head == null || head.next == null) {
            return false;
        }
        
        ListNode slow = head;
        ListNode fast = head;
        
        while (fast != null && fast.next != null) {
            slow = slow.next;
            fast = fast.next.next;
            
            if (slow == fast) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Remove duplicates from sorted list
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     */
    public void removeDuplicates() {
        if (head == null || head.next == null) {
            return;
        }
        
        ListNode current = head;
        while (current.next != null) {
            if (current.val == current.next.val) {
                current.next = current.next.next;
                size--;
            } else {
                current = current.next;
            }
        }
    }
    
    public static void main(String[] args) {
        System.out.println("=== Singly Linked List Demo ===\n");
        
        SinglyLinkedList list = new SinglyLinkedList();
        
        // Test insertion operations
        System.out.println("1. Insertion Operations:");
        list.insertAtEnd(1);
        list.insertAtEnd(2);
        list.insertAtEnd(3);
        list.insertAtBeginning(0);
        list.insertAtPosition(1, 2); // Insert 1 at position 2
        list.printList();
        System.out.println("Length: " + list.getLength());
        System.out.println();
        
        // Test search and get operations
        System.out.println("2. Search and Get Operations:");
        System.out.println("Search for 3: " + list.search(3));
        System.out.println("Get element at position 2: " + list.get(2));
        System.out.println();
        
        // Test update operation
        System.out.println("3. Update Operation:");
        list.set(2, 99);
        System.out.println("After updating position 2 to 99:");
        list.printList();
        System.out.println();
        
        // Test deletion operations
        System.out.println("4. Deletion Operations:");
        list.deleteFromBeginning();
        System.out.println("After deleting from beginning:");
        list.printList();
        
        list.deleteFromEnd();
        System.out.println("After deleting from end:");
        list.printList();
        
        list.deleteByValue(99);
        System.out.println("After deleting value 99:");
        list.printList();
        System.out.println();
        
        // Test reverse operations
        System.out.println("5. Reverse Operations:");
        list.insertAtEnd(4);
        list.insertAtEnd(5);
        System.out.println("Before reverse:");
        list.printList();
        
        list.reverse();
        System.out.println("After iterative reverse:");
        list.printList();
        
        list.reverseRecursive();
        System.out.println("After recursive reverse:");
        list.printList();
        System.out.println();
        
        // Test middle finding
        System.out.println("6. Find Middle:");
        ListNode middle = list.findMiddle();
        System.out.println("Middle node value: " + (middle != null ? middle.val : "null"));
        System.out.println();
        
        // Test cycle detection
        System.out.println("7. Cycle Detection:");
        System.out.println("Has cycle: " + list.hasCycle());
        System.out.println();
        
        // Test array conversion
        System.out.println("8. Array Conversion:");
        int[] array = list.toArray();
        System.out.println("Array: " + java.util.Arrays.toString(array));
        System.out.println();
        
        // Test clear
        System.out.println("9. Clear List:");
        list.clear();
        System.out.println("Is empty: " + list.isEmpty());
        System.out.println("Length: " + list.getLength());
        
        System.out.println("\n=== Key Takeaways ===");
        System.out.println("• Insertion at beginning: O(1)");
        System.out.println("• Insertion at end: O(n)");
        System.out.println("• Deletion at beginning: O(1)");
        System.out.println("• Deletion at end: O(n)");
        System.out.println("• Search: O(n)");
        System.out.println("• Access by index: O(n)");
        System.out.println("• Reverse: O(n)");
        System.out.println("• Find middle: O(n)");
    }
}
