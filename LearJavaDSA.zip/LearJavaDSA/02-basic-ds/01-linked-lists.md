# Linked Lists
## Dynamic Data Structures for Flexible Storage

Linked lists are fundamental data structures that provide dynamic memory allocation and efficient insertion/deletion operations. They're the building blocks for many advanced data structures.

## 🎯 Learning Objectives
By the end of this section, you will:
- Understand linked list concepts and operations
- Implement singly, doubly, and circular linked lists
- Master common linked list algorithms
- Solve linked list problems efficiently
- Be ready for stacks, queues, and trees

## 📚 Table of Contents
1. [Linked List Fundamentals](#linked-list-fundamentals)
2. [Singly Linked List](#singly-linked-list)
3. [Doubly Linked List](#doubly-linked-list)
4. [Circular Linked List](#circular-linked-list)
5. [Common Algorithms](#common-algorithms)
6. [Exercises](#exercises)

---

## Linked List Fundamentals

### What is a Linked List?

A linked list is a linear data structure where elements are stored in nodes, and each node contains:
- **Data**: The actual value
- **Next**: Reference to the next node
- **Previous**: Reference to the previous node (in doubly linked lists)

### Advantages vs Arrays:
- **Dynamic size**: Can grow/shrink during runtime
- **Efficient insertion/deletion**: O(1) at known positions
- **Memory efficiency**: No wasted space
- **No shifting**: Insertions don't require shifting elements

### Disadvantages:
- **No random access**: Must traverse to reach elements
- **Extra memory**: Each node stores a reference
- **Cache performance**: Nodes may not be contiguous in memory

---

## Singly Linked List

### Node Definition
```java
class ListNode {
    int val;
    ListNode next;
    
    ListNode() {}
    
    ListNode(int val) {
        this.val = val;
    }
    
    ListNode(int val, ListNode next) {
        this.val = val;
        this.next = next;
    }
}
```

### Basic Operations

#### 1. Traversal
```java
public class SinglyLinkedList {
    private ListNode head;
    
    /**
     * Print all elements in the list
     * Time: O(n), Space: O(1)
     */
    public void printList() {
        ListNode current = head;
        while (current != null) {
            System.out.print(current.val + " -> ");
            current = current.next;
        }
        System.out.println("null");
    }
    
    /**
     * Get length of the list
     * Time: O(n), Space: O(1)
     */
    public int getLength() {
        int length = 0;
        ListNode current = head;
        while (current != null) {
            length++;
            current = current.next;
        }
        return length;
    }
}
```

#### 2. Insertion Operations
```java
public class SinglyLinkedList {
    
    /**
     * Insert at the beginning
     * Time: O(1), Space: O(1)
     */
    public void insertAtBeginning(int val) {
        ListNode newNode = new ListNode(val);
        newNode.next = head;
        head = newNode;
    }
    
    /**
     * Insert at the end
     * Time: O(n), Space: O(1)
     */
    public void insertAtEnd(int val) {
        ListNode newNode = new ListNode(val);
        
        if (head == null) {
            head = newNode;
            return;
        }
        
        ListNode current = head;
        while (current.next != null) {
            current = current.next;
        }
        current.next = newNode;
    }
    
    /**
     * Insert at specific position
     * Time: O(n), Space: O(1)
     */
    public void insertAtPosition(int val, int position) {
        if (position < 0) return;
        
        if (position == 0) {
            insertAtBeginning(val);
            return;
        }
        
        ListNode newNode = new ListNode(val);
        ListNode current = head;
        
        for (int i = 0; i < position - 1 && current != null; i++) {
            current = current.next;
        }
        
        if (current != null) {
            newNode.next = current.next;
            current.next = newNode;
        }
    }
}
```

#### 3. Deletion Operations
```java
public class SinglyLinkedList {
    
    /**
     * Delete from beginning
     * Time: O(1), Space: O(1)
     */
    public void deleteFromBeginning() {
        if (head != null) {
            head = head.next;
        }
    }
    
    /**
     * Delete from end
     * Time: O(n), Space: O(1)
     */
    public void deleteFromEnd() {
        if (head == null || head.next == null) {
            head = null;
            return;
        }
        
        ListNode current = head;
        while (current.next.next != null) {
            current = current.next;
        }
        current.next = null;
    }
    
    /**
     * Delete by value
     * Time: O(n), Space: O(1)
     */
    public void deleteByValue(int val) {
        if (head == null) return;
        
        if (head.val == val) {
            head = head.next;
            return;
        }
        
        ListNode current = head;
        while (current.next != null) {
            if (current.next.val == val) {
                current.next = current.next.next;
                return;
            }
            current = current.next;
        }
    }
}
```

---

## Doubly Linked List

### Node Definition
```java
class DoublyListNode {
    int val;
    DoublyListNode next;
    DoublyListNode prev;
    
    DoublyListNode() {}
    
    DoublyListNode(int val) {
        this.val = val;
    }
    
    DoublyListNode(int val, DoublyListNode next, DoublyListNode prev) {
        this.val = val;
        this.next = next;
        this.prev = prev;
    }
}
```

### Advantages of Doubly Linked List:
- **Bidirectional traversal**: Can move forward and backward
- **Efficient deletion**: Can delete a node in O(1) if you have reference to it
- **Better for certain algorithms**: Like LRU cache implementation

### Basic Operations
```java
public class DoublyLinkedList {
    private DoublyListNode head;
    private DoublyListNode tail;
    
    /**
     * Insert at beginning
     * Time: O(1), Space: O(1)
     */
    public void insertAtBeginning(int val) {
        DoublyListNode newNode = new DoublyListNode(val);
        
        if (head == null) {
            head = tail = newNode;
        } else {
            newNode.next = head;
            head.prev = newNode;
            head = newNode;
        }
    }
    
    /**
     * Insert at end
     * Time: O(1), Space: O(1)
     */
    public void insertAtEnd(int val) {
        DoublyListNode newNode = new DoublyListNode(val);
        
        if (tail == null) {
            head = tail = newNode;
        } else {
            tail.next = newNode;
            newNode.prev = tail;
            tail = newNode;
        }
    }
    
    /**
     * Delete node (given reference to node)
     * Time: O(1), Space: O(1)
     */
    public void deleteNode(DoublyListNode node) {
        if (node == null) return;
        
        if (node.prev != null) {
            node.prev.next = node.next;
        } else {
            head = node.next;
        }
        
        if (node.next != null) {
            node.next.prev = node.prev;
        } else {
            tail = node.prev;
        }
    }
}
```

---

## Circular Linked List

### Characteristics:
- **Last node points to first**: Creates a circular structure
- **No null references**: Every node has a next node
- **Traversal**: Must be careful to avoid infinite loops

### Implementation
```java
public class CircularLinkedList {
    private ListNode head;
    
    /**
     * Insert at beginning
     * Time: O(1), Space: O(1)
     */
    public void insertAtBeginning(int val) {
        ListNode newNode = new ListNode(val);
        
        if (head == null) {
            head = newNode;
            head.next = head; // Point to itself
        } else {
            ListNode current = head;
            while (current.next != head) {
                current = current.next;
            }
            newNode.next = head;
            current.next = newNode;
            head = newNode;
        }
    }
    
    /**
     * Print circular list (with limit to avoid infinite loop)
     * Time: O(n), Space: O(1)
     */
    public void printList() {
        if (head == null) return;
        
        ListNode current = head;
        do {
            System.out.print(current.val + " -> ");
            current = current.next;
        } while (current != head);
        System.out.println("(back to " + head.val + ")");
    }
}
```

---

## Common Algorithms

### 1. Reverse Linked List
```java
public class LinkedListAlgorithms {
    
    /**
     * Reverse linked list iteratively
     * Time: O(n), Space: O(1)
     */
    public static ListNode reverseList(ListNode head) {
        ListNode prev = null;
        ListNode current = head;
        
        while (current != null) {
            ListNode next = current.next;
            current.next = prev;
            prev = current;
            current = next;
        }
        
        return prev;
    }
    
    /**
     * Reverse linked list recursively
     * Time: O(n), Space: O(n) - due to recursion stack
     */
    public static ListNode reverseListRecursive(ListNode head) {
        if (head == null || head.next == null) {
            return head;
        }
        
        ListNode newHead = reverseListRecursive(head.next);
        head.next.next = head;
        head.next = null;
        
        return newHead;
    }
}
```

### 2. Detect Cycle (Floyd's Algorithm)
```java
public class LinkedListAlgorithms {
    
    /**
     * Detect cycle using Floyd's cycle detection algorithm
     * Time: O(n), Space: O(1)
     */
    public static boolean hasCycle(ListNode head) {
        if (head == null || head.next == null) {
            return false;
        }
        
        ListNode slow = head;
        ListNode fast = head;
        
        while (fast != null && fast.next != null) {
            slow = slow.next;
            fast = fast.next.next;
            
            if (slow == fast) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Find the start of cycle
     * Time: O(n), Space: O(1)
     */
    public static ListNode detectCycle(ListNode head) {
        if (head == null || head.next == null) {
            return null;
        }
        
        ListNode slow = head;
        ListNode fast = head;
        
        // First phase: detect if cycle exists
        while (fast != null && fast.next != null) {
            slow = slow.next;
            fast = fast.next.next;
            
            if (slow == fast) {
                break;
            }
        }
        
        if (fast == null || fast.next == null) {
            return null; // No cycle
        }
        
        // Second phase: find start of cycle
        slow = head;
        while (slow != fast) {
            slow = slow.next;
            fast = fast.next;
        }
        
        return slow;
    }
}
```

### 3. Merge Two Sorted Lists
```java
public class LinkedListAlgorithms {
    
    /**
     * Merge two sorted linked lists
     * Time: O(n + m), Space: O(1)
     */
    public static ListNode mergeTwoLists(ListNode l1, ListNode l2) {
        ListNode dummy = new ListNode(0);
        ListNode current = dummy;
        
        while (l1 != null && l2 != null) {
            if (l1.val <= l2.val) {
                current.next = l1;
                l1 = l1.next;
            } else {
                current.next = l2;
                l2 = l2.next;
            }
            current = current.next;
        }
        
        // Attach remaining nodes
        current.next = (l1 != null) ? l1 : l2;
        
        return dummy.next;
    }
}
```

### 4. Find Middle Node
```java
public class LinkedListAlgorithms {
    
    /**
     * Find middle node using slow and fast pointers
     * Time: O(n), Space: O(1)
     */
    public static ListNode findMiddle(ListNode head) {
        if (head == null) return null;
        
        ListNode slow = head;
        ListNode fast = head;
        
        while (fast != null && fast.next != null) {
            slow = slow.next;
            fast = fast.next.next;
        }
        
        return slow;
    }
}
```

### 5. Remove Nth Node From End
```java
public class LinkedListAlgorithms {
    
    /**
     * Remove nth node from end
     * Time: O(n), Space: O(1)
     */
    public static ListNode removeNthFromEnd(ListNode head, int n) {
        ListNode dummy = new ListNode(0);
        dummy.next = head;
        
        ListNode first = dummy;
        ListNode second = dummy;
        
        // Move first pointer n+1 steps ahead
        for (int i = 0; i <= n; i++) {
            first = first.next;
        }
        
        // Move both pointers until first reaches end
        while (first != null) {
            first = first.next;
            second = second.next;
        }
        
        // Remove the nth node
        second.next = second.next.next;
        
        return dummy.next;
    }
}
```

### 6. Palindrome Check
```java
public class LinkedListAlgorithms {
    
    /**
     * Check if linked list is palindrome
     * Time: O(n), Space: O(1)
     */
    public static boolean isPalindrome(ListNode head) {
        if (head == null || head.next == null) {
            return true;
        }
        
        // Find middle
        ListNode slow = head;
        ListNode fast = head;
        
        while (fast != null && fast.next != null) {
            slow = slow.next;
            fast = fast.next.next;
        }
        
        // Reverse second half
        ListNode secondHalf = reverseList(slow);
        
        // Compare first half with reversed second half
        ListNode firstHalf = head;
        while (secondHalf != null) {
            if (firstHalf.val != secondHalf.val) {
                return false;
            }
            firstHalf = firstHalf.next;
            secondHalf = secondHalf.next;
        }
        
        return true;
    }
}
```

---

## 🎯 Key Patterns for Linked Lists

### 1. Two Pointers
- **Slow and Fast**: Find middle, detect cycle
- **First and Second**: Remove nth from end

### 2. Dummy Node
- **Simplify edge cases**: Avoid null pointer exceptions
- **Maintain reference**: Keep track of head

### 3. Reversal
- **Iterative**: Use three pointers
- **Recursive**: Use call stack

### 4. Merging
- **Two sorted lists**: Use dummy node and compare
- **Divide and conquer**: Merge sort approach

---

## 🏋️ Exercises

### Exercise 1: Reverse Linked List ⭐
Reverse a singly linked list.

### Exercise 2: Merge Two Sorted Lists ⭐
Merge two sorted linked lists and return it as a sorted list.

### Exercise 3: Detect Cycle ⭐⭐
Given head, determine if the linked list has a cycle in it.

### Exercise 4: Find Middle Node ⭐
Given the head of a singly linked list, return the middle node.

### Exercise 5: Remove Nth Node From End ⭐⭐
Given the head of a linked list, remove the nth node from the end of the list.

### Exercise 6: Palindrome Linked List ⭐⭐
Given the head of a singly linked list, return true if it is a palindrome.

### Exercise 7: Intersection of Two Linked Lists ⭐⭐
Given the heads of two singly linked-lists, return the node at which the two lists intersect.

### Exercise 8: Copy List with Random Pointer ⭐⭐⭐
A linked list of length n is given such that each node contains an additional random pointer.

---

## 🎓 Interview Tips

1. **Always handle edge cases**:
   - Empty list (head == null)
   - Single node list
   - Two node list

2. **Use dummy nodes**:
   - Simplify insertion/deletion at head
   - Avoid null pointer exceptions

3. **Two pointer technique**:
   - Slow and fast pointers for middle/cycle detection
   - First and second pointers for nth from end

4. **Draw diagrams**:
   - Visualize the problem
   - Track pointer movements

5. **Test with examples**:
   - Walk through your solution
   - Verify edge cases

---

## 🚀 What's Next?

You've mastered linked lists! Next, we'll explore:
- [Stacks and Queues](02-stacks-queues.md) - LIFO and FIFO structures
- [Hash Tables](03-hash-tables.md) - Fast lookups and insertions
- [Trees](04-advanced-ds/01-trees.md) - Hierarchical data structures

Remember: **Linked lists are the foundation for many advanced data structures!** Master these patterns and you'll be ready for any linked list problem.

---

*"The best way to understand linked lists is to implement them yourself." - Computer Science Wisdom*
