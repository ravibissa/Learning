/**
 * Common Linked List Algorithms
 * 
 * This class contains implementations of common linked list algorithms
 * that are frequently asked in interviews and used in real applications.
 * 
 * @author DSA Tutorial
 * @version 1.0
 */
import java.util.*;

// Node class for linked list
class ListNode {
    int val;
    ListNode next;
    
    ListNode() {}
    
    ListNode(int val) {
        this.val = val;
    }
    
    ListNode(int val, ListNode next) {
        this.val = val;
        this.next = next;
    }
}

public class LinkedListAlgorithms {
    
    /**
     * Reverse linked list iteratively
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     */
    public static ListNode reverseList(ListNode head) {
        ListNode prev = null;
        ListNode current = head;
        
        while (current != null) {
            ListNode next = current.next;
            current.next = prev;
            prev = current;
            current = next;
        }
        
        return prev;
    }
    
    /**
     * Reverse linked list recursively
     * Time Complexity: O(n)
     * Space Complexity: O(n) - due to recursion stack
     */
    public static ListNode reverseListRecursive(ListNode head) {
        if (head == null || head.next == null) {
            return head;
        }
        
        ListNode newHead = reverseListRecursive(head.next);
        head.next.next = head;
        head.next = null;
        
        return newHead;
    }
    
    /**
     * Detect cycle using Floyd's cycle detection algorithm
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     */
    public static boolean hasCycle(ListNode head) {
        if (head == null || head.next == null) {
            return false;
        }
        
        ListNode slow = head;
        ListNode fast = head;
        
        while (fast != null && fast.next != null) {
            slow = slow.next;
            fast = fast.next.next;
            
            if (slow == fast) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Find the start of cycle
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     */
    public static ListNode detectCycle(ListNode head) {
        if (head == null || head.next == null) {
            return null;
        }
        
        ListNode slow = head;
        ListNode fast = head;
        
        // First phase: detect if cycle exists
        while (fast != null && fast.next != null) {
            slow = slow.next;
            fast = fast.next.next;
            
            if (slow == fast) {
                break;
            }
        }
        
        if (fast == null || fast.next == null) {
            return null; // No cycle
        }
        
        // Second phase: find start of cycle
        slow = head;
        while (slow != fast) {
            slow = slow.next;
            fast = fast.next;
        }
        
        return slow;
    }
    
    /**
     * Merge two sorted linked lists
     * Time Complexity: O(n + m)
     * Space Complexity: O(1)
     */
    public static ListNode mergeTwoLists(ListNode l1, ListNode l2) {
        ListNode dummy = new ListNode(0);
        ListNode current = dummy;
        
        while (l1 != null && l2 != null) {
            if (l1.val <= l2.val) {
                current.next = l1;
                l1 = l1.next;
            } else {
                current.next = l2;
                l2 = l2.next;
            }
            current = current.next;
        }
        
        // Attach remaining nodes
        current.next = (l1 != null) ? l1 : l2;
        
        return dummy.next;
    }
    
    /**
     * Find middle node using slow and fast pointers
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     */
    public static ListNode findMiddle(ListNode head) {
        if (head == null) return null;
        
        ListNode slow = head;
        ListNode fast = head;
        
        while (fast != null && fast.next != null) {
            slow = slow.next;
            fast = fast.next.next;
        }
        
        return slow;
    }
    
    /**
     * Remove nth node from end
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     */
    public static ListNode removeNthFromEnd(ListNode head, int n) {
        ListNode dummy = new ListNode(0);
        dummy.next = head;
        
        ListNode first = dummy;
        ListNode second = dummy;
        
        // Move first pointer n+1 steps ahead
        for (int i = 0; i <= n; i++) {
            first = first.next;
        }
        
        // Move both pointers until first reaches end
        while (first != null) {
            first = first.next;
            second = second.next;
        }
        
        // Remove the nth node
        second.next = second.next.next;
        
        return dummy.next;
    }
    
    /**
     * Check if linked list is palindrome
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     */
    public static boolean isPalindrome(ListNode head) {
        if (head == null || head.next == null) {
            return true;
        }
        
        // Find middle
        ListNode slow = head;
        ListNode fast = head;
        
        while (fast != null && fast.next != null) {
            slow = slow.next;
            fast = fast.next.next;
        }
        
        // Reverse second half
        ListNode secondHalf = reverseList(slow);
        
        // Compare first half with reversed second half
        ListNode firstHalf = head;
        while (secondHalf != null) {
            if (firstHalf.val != secondHalf.val) {
                return false;
            }
            firstHalf = firstHalf.next;
            secondHalf = secondHalf.next;
        }
        
        return true;
    }
    
    /**
     * Intersection of two linked lists
     * Time Complexity: O(n + m)
     * Space Complexity: O(1)
     */
    public static ListNode getIntersectionNode(ListNode headA, ListNode headB) {
        if (headA == null || headB == null) {
            return null;
        }
        
        ListNode a = headA;
        ListNode b = headB;
        
        // When one pointer reaches end, move it to other list's head
        // This handles different lengths
        while (a != b) {
            a = (a == null) ? headB : a.next;
            b = (b == null) ? headA : b.next;
        }
        
        return a;
    }
    
    /**
     * Add two numbers represented as linked lists
     * Time Complexity: O(max(n, m))
     * Space Complexity: O(max(n, m))
     */
    public static ListNode addTwoNumbers(ListNode l1, ListNode l2) {
        ListNode dummy = new ListNode(0);
        ListNode current = dummy;
        int carry = 0;
        
        while (l1 != null || l2 != null || carry != 0) {
            int sum = carry;
            
            if (l1 != null) {
                sum += l1.val;
                l1 = l1.next;
            }
            
            if (l2 != null) {
                sum += l2.val;
                l2 = l2.next;
            }
            
            carry = sum / 10;
            current.next = new ListNode(sum % 10);
            current = current.next;
        }
        
        return dummy.next;
    }
    
    /**
     * Copy list with random pointer
     * Time Complexity: O(n)
     * Space Complexity: O(n)
     */
    static class RandomListNode {
        int val;
        RandomListNode next;
        RandomListNode random;
        
        RandomListNode(int val) {
            this.val = val;
        }
    }
    
    public static RandomListNode copyRandomList(RandomListNode head) {
        if (head == null) return null;
        
        Map<RandomListNode, RandomListNode> map = new HashMap<>();
        RandomListNode current = head;
        
        // First pass: create new nodes
        while (current != null) {
            map.put(current, new RandomListNode(current.val));
            current = current.next;
        }
        
        // Second pass: set next and random pointers
        current = head;
        while (current != null) {
            RandomListNode newNode = map.get(current);
            newNode.next = map.get(current.next);
            newNode.random = map.get(current.random);
            current = current.next;
        }
        
        return map.get(head);
    }
    
    /**
     * Rotate list to the right by k places
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     */
    public static ListNode rotateRight(ListNode head, int k) {
        if (head == null || head.next == null || k == 0) {
            return head;
        }
        
        // Find length and make list circular
        ListNode current = head;
        int length = 1;
        
        while (current.next != null) {
            current = current.next;
            length++;
        }
        
        current.next = head; // Make circular
        
        // Find new head position
        k = k % length;
        int stepsToNewHead = length - k;
        
        for (int i = 0; i < stepsToNewHead; i++) {
            current = current.next;
        }
        
        ListNode newHead = current.next;
        current.next = null; // Break the circle
        
        return newHead;
    }
    
    /**
     * Remove duplicates from sorted list
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     */
    public static ListNode deleteDuplicates(ListNode head) {
        if (head == null || head.next == null) {
            return head;
        }
        
        ListNode current = head;
        while (current.next != null) {
            if (current.val == current.next.val) {
                current.next = current.next.next;
            } else {
                current = current.next;
            }
        }
        
        return head;
    }
    
    /**
     * Remove all elements with given value
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     */
    public static ListNode removeElements(ListNode head, int val) {
        ListNode dummy = new ListNode(0);
        dummy.next = head;
        ListNode current = dummy;
        
        while (current.next != null) {
            if (current.next.val == val) {
                current.next = current.next.next;
            } else {
                current = current.next;
            }
        }
        
        return dummy.next;
    }
    
    /**
     * Helper method to create a linked list from array
     */
    public static ListNode createList(int[] values) {
        if (values.length == 0) return null;
        
        ListNode head = new ListNode(values[0]);
        ListNode current = head;
        
        for (int i = 1; i < values.length; i++) {
            current.next = new ListNode(values[i]);
            current = current.next;
        }
        
        return head;
    }
    
    /**
     * Helper method to print linked list
     */
    public static void printList(ListNode head) {
        ListNode current = head;
        while (current != null) {
            System.out.print(current.val + " -> ");
            current = current.next;
        }
        System.out.println("null");
    }
    
    public static void main(String[] args) {
        System.out.println("=== Linked List Algorithms Demo ===\n");
        
        // Test reverse list
        System.out.println("1. Reverse Linked List:");
        ListNode list1 = createList(new int[]{1, 2, 3, 4, 5});
        System.out.print("Original: ");
        printList(list1);
        ListNode reversed = reverseList(list1);
        System.out.print("Reversed: ");
        printList(reversed);
        System.out.println();
        
        // Test merge two lists
        System.out.println("2. Merge Two Sorted Lists:");
        ListNode list2 = createList(new int[]{1, 3, 5});
        ListNode list3 = createList(new int[]{2, 4, 6});
        System.out.print("List 1: ");
        printList(list2);
        System.out.print("List 2: ");
        printList(list3);
        ListNode merged = mergeTwoLists(list2, list3);
        System.out.print("Merged: ");
        printList(merged);
        System.out.println();
        
        // Test find middle
        System.out.println("3. Find Middle Node:");
        ListNode list4 = createList(new int[]{1, 2, 3, 4, 5});
        System.out.print("List: ");
        printList(list4);
        ListNode middle = findMiddle(list4);
        System.out.println("Middle node: " + (middle != null ? middle.val : "null"));
        System.out.println();
        
        // Test remove nth from end
        System.out.println("4. Remove Nth Node From End:");
        ListNode list5 = createList(new int[]{1, 2, 3, 4, 5});
        System.out.print("Original: ");
        printList(list5);
        ListNode removed = removeNthFromEnd(list5, 2);
        System.out.print("After removing 2nd from end: ");
        printList(removed);
        System.out.println();
        
        // Test palindrome check
        System.out.println("5. Palindrome Check:");
        ListNode list6 = createList(new int[]{1, 2, 3, 2, 1});
        System.out.print("List: ");
        printList(list6);
        System.out.println("Is palindrome: " + isPalindrome(list6));
        
        ListNode list7 = createList(new int[]{1, 2, 3, 4, 5});
        System.out.print("List: ");
        printList(list7);
        System.out.println("Is palindrome: " + isPalindrome(list7));
        System.out.println();
        
        // Test add two numbers
        System.out.println("6. Add Two Numbers:");
        ListNode num1 = createList(new int[]{2, 4, 3});
        ListNode num2 = createList(new int[]{5, 6, 4});
        System.out.print("Number 1: ");
        printList(num1);
        System.out.print("Number 2: ");
        printList(num2);
        ListNode sum = addTwoNumbers(num1, num2);
        System.out.print("Sum: ");
        printList(sum);
        System.out.println();
        
        // Test remove duplicates
        System.out.println("7. Remove Duplicates:");
        ListNode list8 = createList(new int[]{1, 1, 2, 3, 3, 4});
        System.out.print("Original: ");
        printList(list8);
        ListNode noDuplicates = deleteDuplicates(list8);
        System.out.print("After removing duplicates: ");
        printList(noDuplicates);
        System.out.println();
        
        // Test rotate right
        System.out.println("8. Rotate Right:");
        ListNode list9 = createList(new int[]{1, 2, 3, 4, 5});
        System.out.print("Original: ");
        printList(list9);
        ListNode rotated = rotateRight(list9, 2);
        System.out.print("After rotating right by 2: ");
        printList(rotated);
        System.out.println();
        
        System.out.println("=== Key Algorithm Patterns ===");
        System.out.println("1. Two Pointers: Slow/Fast for middle, cycle detection");
        System.out.println("2. Dummy Node: Simplify edge cases in insertion/deletion");
        System.out.println("3. Reversal: Three-pointer technique");
        System.out.println("4. Merging: Compare and attach nodes");
        System.out.println("5. Hash Map: For random pointer problems");
        System.out.println("6. Mathematical: For number addition problems");
    }
}
