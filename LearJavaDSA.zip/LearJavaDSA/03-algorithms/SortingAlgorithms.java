/**
 * Complete Sorting Algorithms Implementation
 * 
 * This class contains implementations of all major sorting algorithms
 * with detailed explanations and complexity analysis.
 * 
 * @author DSA Tutorial
 * @version 1.0
 */
import java.util.*;

public class SortingAlgorithms {
    
    /**
     * Bubble Sort - Compare adjacent elements and swap if needed
     * Time Complexity: O(n²) worst/average, O(n) best
     * Space Complexity: O(1)
     * Stable: Yes, In-place: Yes
     */
    public static void bubbleSort(int[] arr) {
        int n = arr.length;
        
        for (int i = 0; i < n - 1; i++) {
            boolean swapped = false;
            
            for (int j = 0; j < n - i - 1; j++) {
                if (arr[j] > arr[j + 1]) {
                    swap(arr, j, j + 1);
                    swapped = true;
                }
            }
            
            // If no swapping occurred, array is sorted
            if (!swapped) break;
        }
    }
    
    /**
     * Selection Sort - Find minimum and place at beginning
     * Time Complexity: O(n²) all cases
     * Space Complexity: O(1)
     * Stable: No, In-place: Yes
     */
    public static void selectionSort(int[] arr) {
        int n = arr.length;
        
        for (int i = 0; i < n - 1; i++) {
            int minIndex = i;
            
            // Find minimum element in remaining array
            for (int j = i + 1; j < n; j++) {
                if (arr[j] < arr[minIndex]) {
                    minIndex = j;
                }
            }
            
            // Swap with first element
            swap(arr, i, minIndex);
        }
    }
    
    /**
     * Insertion Sort - Insert element in correct position
     * Time Complexity: O(n²) worst/average, O(n) best
     * Space Complexity: O(1)
     * Stable: Yes, In-place: Yes
     */
    public static void insertionSort(int[] arr) {
        int n = arr.length;
        
        for (int i = 1; i < n; i++) {
            int key = arr[i];
            int j = i - 1;
            
            // Move elements greater than key one position ahead
            while (j >= 0 && arr[j] > key) {
                arr[j + 1] = arr[j];
                j--;
            }
            
            arr[j + 1] = key;
        }
    }
    
    /**
     * Merge Sort - Divide and conquer approach
     * Time Complexity: O(n log n) all cases
     * Space Complexity: O(n)
     * Stable: Yes, In-place: No
     */
    public static void mergeSort(int[] arr) {
        if (arr.length <= 1) return;
        
        int[] temp = new int[arr.length];
        mergeSortHelper(arr, temp, 0, arr.length - 1);
    }
    
    private static void mergeSortHelper(int[] arr, int[] temp, int left, int right) {
        if (left < right) {
            int mid = left + (right - left) / 2;
            
            // Sort left half
            mergeSortHelper(arr, temp, left, mid);
            
            // Sort right half
            mergeSortHelper(arr, temp, mid + 1, right);
            
            // Merge sorted halves
            merge(arr, temp, left, mid, right);
        }
    }
    
    private static void merge(int[] arr, int[] temp, int left, int mid, int right) {
        // Copy data to temp arrays
        for (int i = left; i <= right; i++) {
            temp[i] = arr[i];
        }
        
        int i = left;    // Initial index of left subarray
        int j = mid + 1; // Initial index of right subarray
        int k = left;    // Initial index of merged subarray
        
        // Merge temp arrays back into arr
        while (i <= mid && j <= right) {
            if (temp[i] <= temp[j]) {
                arr[k] = temp[i];
                i++;
            } else {
                arr[k] = temp[j];
                j++;
            }
            k++;
        }
        
        // Copy remaining elements of left subarray
        while (i <= mid) {
            arr[k] = temp[i];
            i++;
            k++;
        }
        
        // Copy remaining elements of right subarray
        while (j <= right) {
            arr[k] = temp[j];
            j++;
            k++;
        }
    }
    
    /**
     * Quick Sort - Divide and conquer with pivot
     * Time Complexity: O(n log n) average, O(n²) worst
     * Space Complexity: O(log n) average, O(n) worst
     * Stable: No, In-place: Yes
     */
    public static void quickSort(int[] arr) {
        if (arr.length <= 1) return;
        quickSortHelper(arr, 0, arr.length - 1);
    }
    
    private static void quickSortHelper(int[] arr, int low, int high) {
        if (low < high) {
            // Partition array and get pivot index
            int pivotIndex = partition(arr, low, high);
            
            // Recursively sort elements before and after partition
            quickSortHelper(arr, low, pivotIndex - 1);
            quickSortHelper(arr, pivotIndex + 1, high);
        }
    }
    
    private static int partition(int[] arr, int low, int high) {
        // Choose rightmost element as pivot
        int pivot = arr[high];
        int i = low - 1; // Index of smaller element
        
        for (int j = low; j < high; j++) {
            // If current element is smaller than or equal to pivot
            if (arr[j] <= pivot) {
                i++;
                swap(arr, i, j);
            }
        }
        
        // Place pivot in correct position
        swap(arr, i + 1, high);
        return i + 1;
    }
    
    /**
     * Heap Sort - Use heap data structure
     * Time Complexity: O(n log n) all cases
     * Space Complexity: O(1)
     * Stable: No, In-place: Yes
     */
    public static void heapSort(int[] arr) {
        int n = arr.length;
        
        // Build max heap
        for (int i = n / 2 - 1; i >= 0; i--) {
            heapify(arr, n, i);
        }
        
        // Extract elements from heap one by one
        for (int i = n - 1; i > 0; i--) {
            // Move current root to end
            swap(arr, 0, i);
            
            // Call heapify on reduced heap
            heapify(arr, i, 0);
        }
    }
    
    private static void heapify(int[] arr, int n, int i) {
        int largest = i;    // Initialize largest as root
        int left = 2 * i + 1;  // Left child
        int right = 2 * i + 2; // Right child
        
        // If left child is larger than root
        if (left < n && arr[left] > arr[largest]) {
            largest = left;
        }
        
        // If right child is larger than largest so far
        if (right < n && arr[right] > arr[largest]) {
            largest = right;
        }
        
        // If largest is not root
        if (largest != i) {
            swap(arr, i, largest);
            
            // Recursively heapify affected sub-tree
            heapify(arr, n, largest);
        }
    }
    
    /**
     * Counting Sort - Count occurrences of each element
     * Time Complexity: O(n + k) where k is range
     * Space Complexity: O(k)
     * Stable: Yes, In-place: No
     */
    public static void countingSort(int[] arr) {
        if (arr.length == 0) return;
        
        // Find range of input array
        int max = Arrays.stream(arr).max().getAsInt();
        int min = Arrays.stream(arr).min().getAsInt();
        int range = max - min + 1;
        
        // Create count array
        int[] count = new int[range];
        int[] output = new int[arr.length];
        
        // Store count of each element
        for (int value : arr) {
            count[value - min]++;
        }
        
        // Modify count array to store actual position
        for (int i = 1; i < range; i++) {
            count[i] += count[i - 1];
        }
        
        // Build output array
        for (int i = arr.length - 1; i >= 0; i--) {
            output[count[arr[i] - min] - 1] = arr[i];
            count[arr[i] - min]--;
        }
        
        // Copy output array to original array
        System.arraycopy(output, 0, arr, 0, arr.length);
    }
    
    /**
     * Radix Sort - Sort by individual digits
     * Time Complexity: O(d × (n + k)) where d is digits, k is base
     * Space Complexity: O(n + k)
     * Stable: Yes, In-place: No
     */
    public static void radixSort(int[] arr) {
        if (arr.length == 0) return;
        
        // Find maximum number to know number of digits
        int max = Arrays.stream(arr).max().getAsInt();
        
        // Do counting sort for every digit
        for (int exp = 1; max / exp > 0; exp *= 10) {
            countingSortByDigit(arr, exp);
        }
    }
    
    private static void countingSortByDigit(int[] arr, int exp) {
        int n = arr.length;
        int[] output = new int[n];
        int[] count = new int[10];
        
        // Store count of occurrences
        for (int value : arr) {
            count[(value / exp) % 10]++;
        }
        
        // Change count to actual position
        for (int i = 1; i < 10; i++) {
            count[i] += count[i - 1];
        }
        
        // Build output array
        for (int i = n - 1; i >= 0; i--) {
            output[count[(arr[i] / exp) % 10] - 1] = arr[i];
            count[(arr[i] / exp) % 10]--;
        }
        
        // Copy output array to original array
        System.arraycopy(output, 0, arr, 0, n);
    }
    
    /**
     * Bucket Sort - Distribute elements into buckets
     * Time Complexity: O(n + k) average, O(n²) worst
     * Space Complexity: O(n + k)
     * Stable: Yes, In-place: No
     */
    public static void bucketSort(double[] arr) {
        if (arr.length == 0) return;
        
        int n = arr.length;
        List<Double>[] buckets = new List[n];
        
        // Create empty buckets
        for (int i = 0; i < n; i++) {
            buckets[i] = new ArrayList<>();
        }
        
        // Put array elements in different buckets
        for (double value : arr) {
            int bucketIndex = (int) (n * value);
            buckets[bucketIndex].add(value);
        }
        
        // Sort individual buckets
        for (List<Double> bucket : buckets) {
            Collections.sort(bucket);
        }
        
        // Concatenate all buckets into arr
        int index = 0;
        for (List<Double> bucket : buckets) {
            for (double value : bucket) {
                arr[index++] = value;
            }
        }
    }
    
    /**
     * Shell Sort - Improved insertion sort with gaps
     * Time Complexity: O(n²) worst, O(n log n) best
     * Space Complexity: O(1)
     * Stable: No, In-place: Yes
     */
    public static void shellSort(int[] arr) {
        int n = arr.length;
        
        // Start with big gap, then reduce gap
        for (int gap = n / 2; gap > 0; gap /= 2) {
            // Do insertion sort for this gap size
            for (int i = gap; i < n; i++) {
                int temp = arr[i];
                int j;
                
                for (j = i; j >= gap && arr[j - gap] > temp; j -= gap) {
                    arr[j] = arr[j - gap];
                }
                
                arr[j] = temp;
            }
        }
    }
    
    /**
     * Comb Sort - Improved bubble sort with gap
     * Time Complexity: O(n²) worst, O(n log n) average
     * Space Complexity: O(1)
     * Stable: No, In-place: Yes
     */
    public static void combSort(int[] arr) {
        int n = arr.length;
        int gap = n;
        boolean swapped = true;
        
        while (gap != 1 || swapped) {
            // Find next gap
            gap = getNextGap(gap);
            swapped = false;
            
            // Compare all elements with current gap
            for (int i = 0; i < n - gap; i++) {
                if (arr[i] > arr[i + gap]) {
                    swap(arr, i, i + gap);
                    swapped = true;
                }
            }
        }
    }
    
    private static int getNextGap(int gap) {
        gap = (gap * 10) / 13;
        if (gap < 1) {
            return 1;
        }
        return gap;
    }
    
    /**
     * Helper method to swap elements
     */
    private static void swap(int[] arr, int i, int j) {
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }
    
    /**
     * Helper method to print array
     */
    public static void printArray(int[] arr) {
        System.out.println(Arrays.toString(arr));
    }
    
    /**
     * Helper method to print array with label
     */
    public static void printArray(String label, int[] arr) {
        System.out.println(label + ": " + Arrays.toString(arr));
    }
    
    /**
     * Helper method to create a copy of array
     */
    public static int[] copyArray(int[] arr) {
        return Arrays.copyOf(arr, arr.length);
    }
    
    /**
     * Helper method to check if array is sorted
     */
    public static boolean isSorted(int[] arr) {
        for (int i = 1; i < arr.length; i++) {
            if (arr[i] < arr[i - 1]) {
                return false;
            }
        }
        return true;
    }
    
    public static void main(String[] args) {
        System.out.println("=== Sorting Algorithms Demo ===\n");
        
        // Test data
        int[] originalArray = {64, 34, 25, 12, 22, 11, 90, 5, 77, 30};
        System.out.println("Original array: " + Arrays.toString(originalArray));
        System.out.println();
        
        // Test Bubble Sort
        System.out.println("1. Bubble Sort:");
        int[] arr1 = copyArray(originalArray);
        printArray("Before", arr1);
        bubbleSort(arr1);
        printArray("After", arr1);
        System.out.println("Is sorted: " + isSorted(arr1));
        System.out.println();
        
        // Test Selection Sort
        System.out.println("2. Selection Sort:");
        int[] arr2 = copyArray(originalArray);
        printArray("Before", arr2);
        selectionSort(arr2);
        printArray("After", arr2);
        System.out.println("Is sorted: " + isSorted(arr2));
        System.out.println();
        
        // Test Insertion Sort
        System.out.println("3. Insertion Sort:");
        int[] arr3 = copyArray(originalArray);
        printArray("Before", arr3);
        insertionSort(arr3);
        printArray("After", arr3);
        System.out.println("Is sorted: " + isSorted(arr3));
        System.out.println();
        
        // Test Merge Sort
        System.out.println("4. Merge Sort:");
        int[] arr4 = copyArray(originalArray);
        printArray("Before", arr4);
        mergeSort(arr4);
        printArray("After", arr4);
        System.out.println("Is sorted: " + isSorted(arr4));
        System.out.println();
        
        // Test Quick Sort
        System.out.println("5. Quick Sort:");
        int[] arr5 = copyArray(originalArray);
        printArray("Before", arr5);
        quickSort(arr5);
        printArray("After", arr5);
        System.out.println("Is sorted: " + isSorted(arr5));
        System.out.println();
        
        // Test Heap Sort
        System.out.println("6. Heap Sort:");
        int[] arr6 = copyArray(originalArray);
        printArray("Before", arr6);
        heapSort(arr6);
        printArray("After", arr6);
        System.out.println("Is sorted: " + isSorted(arr6));
        System.out.println();
        
        // Test Counting Sort
        System.out.println("7. Counting Sort:");
        int[] arr7 = copyArray(originalArray);
        printArray("Before", arr7);
        countingSort(arr7);
        printArray("After", arr7);
        System.out.println("Is sorted: " + isSorted(arr7));
        System.out.println();
        
        // Test Radix Sort
        System.out.println("8. Radix Sort:");
        int[] arr8 = copyArray(originalArray);
        printArray("Before", arr8);
        radixSort(arr8);
        printArray("After", arr8);
        System.out.println("Is sorted: " + isSorted(arr8));
        System.out.println();
        
        // Test Shell Sort
        System.out.println("9. Shell Sort:");
        int[] arr9 = copyArray(originalArray);
        printArray("Before", arr9);
        shellSort(arr9);
        printArray("After", arr9);
        System.out.println("Is sorted: " + isSorted(arr9));
        System.out.println();
        
        // Test Comb Sort
        System.out.println("10. Comb Sort:");
        int[] arr10 = copyArray(originalArray);
        printArray("Before", arr10);
        combSort(arr10);
        printArray("After", arr10);
        System.out.println("Is sorted: " + isSorted(arr10));
        System.out.println();
        
        // Test Bucket Sort with doubles
        System.out.println("11. Bucket Sort (for doubles):");
        double[] doubleArray = {0.897, 0.565, 0.656, 0.1234, 0.665, 0.3434};
        System.out.println("Before: " + Arrays.toString(doubleArray));
        bucketSort(doubleArray);
        System.out.println("After: " + Arrays.toString(doubleArray));
        System.out.println();
        
        System.out.println("=== Sorting Algorithm Summary ===");
        System.out.println("• Bubble Sort: O(n²) - Simple but inefficient");
        System.out.println("• Selection Sort: O(n²) - Always O(n²)");
        System.out.println("• Insertion Sort: O(n²) - Good for small arrays");
        System.out.println("• Merge Sort: O(n log n) - Stable, guaranteed performance");
        System.out.println("• Quick Sort: O(n log n) average - Fast in practice");
        System.out.println("• Heap Sort: O(n log n) - In-place, not stable");
        System.out.println("• Counting Sort: O(n + k) - Good for small range");
        System.out.println("• Radix Sort: O(d × n) - Good for integers");
        System.out.println("• Bucket Sort: O(n + k) - Good for uniform distribution");
        System.out.println("• Shell Sort: O(n²) - Improved insertion sort");
        System.out.println("• Comb Sort: O(n²) - Improved bubble sort");
    }
}
