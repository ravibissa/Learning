# Searching Algorithms
## Finding Elements Efficiently

Searching is a fundamental operation in computer science. Understanding different searching algorithms helps you choose the most efficient approach for your specific data structure and use case.

## 🎯 Learning Objectives
By the end of this section, you will:
- Understand different searching algorithms and their applications
- Implement searching algorithms from scratch
- Analyze time and space complexity
- Choose the right searching algorithm for different scenarios
- Be ready for searching-related interview questions

## 📚 Table of Contents
1. [Searching Fundamentals](#searching-fundamentals)
2. [Linear Search](#linear-search)
3. [Binary Search](#binary-search)
4. [Advanced Searching](#advanced-searching)
5. [String Searching](#string-searching)
6. [Searching Applications](#searching-applications)
7. [Exercises](#exercises)

---

## Searching Fundamentals

### What is Searching?
Searching is the process of finding a specific element or value in a data structure.

### Types of Searching:

#### 1. Sequential Search
- Search through elements one by one
- Works on any data structure
- Examples: Linear Search

#### 2. Interval Search
- Search in sorted data by repeatedly dividing search space
- More efficient than sequential search
- Examples: Binary Search, Ternary Search

#### 3. Hash-based Search
- Use hash functions to locate elements
- Average O(1) time complexity
- Examples: Hash Table lookup

### Search Space:
- **Sorted Array**: Can use binary search
- **Unsorted Array**: Must use linear search
- **Tree**: Can use tree traversal
- **Graph**: Can use BFS/DFS

---

## Linear Search

### Basic Linear Search
**Time Complexity**: O(n)  
**Space Complexity**: O(1)  
**Works on**: Any data structure

```java
public class LinearSearch {
    
    /**
     * Linear Search - Search element by element
     * Time: O(n), Space: O(1)
     */
    public static int linearSearch(int[] arr, int target) {
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == target) {
                return i; // Return index where found
            }
        }
        return -1; // Not found
    }
    
    /**
     * Linear Search with enhanced for loop
     * Time: O(n), Space: O(1)
     */
    public static int linearSearchEnhanced(int[] arr, int target) {
        int index = 0;
        for (int element : arr) {
            if (element == target) {
                return index;
            }
            index++;
        }
        return -1;
    }
    
    /**
     * Find all occurrences of target
     * Time: O(n), Space: O(k) where k is number of occurrences
     */
    public static List<Integer> findAllOccurrences(int[] arr, int target) {
        List<Integer> indices = new ArrayList<>();
        
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == target) {
                indices.add(i);
            }
        }
        
        return indices;
    }
    
    /**
     * Find last occurrence of target
     * Time: O(n), Space: O(1)
     */
    public static int findLastOccurrence(int[] arr, int target) {
        int lastIndex = -1;
        
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == target) {
                lastIndex = i;
            }
        }
        
        return lastIndex;
    }
}
```

### Optimized Linear Search
```java
public class OptimizedLinearSearch {
    
    /**
     * Move to Front - Move found element to beginning
     * Time: O(n) worst, O(1) best for repeated searches
     * Space: O(1)
     */
    public static int moveToFrontSearch(int[] arr, int target) {
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == target) {
                // Move to front
                int temp = arr[0];
                arr[0] = arr[i];
                arr[i] = temp;
                return i;
            }
        }
        return -1;
    }
    
    /**
     * Transposition - Move found element one position left
     * Time: O(n) worst, O(1) best for repeated searches
     * Space: O(1)
     */
    public static int transpositionSearch(int[] arr, int target) {
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == target) {
                if (i > 0) {
                    // Swap with previous element
                    int temp = arr[i - 1];
                    arr[i - 1] = arr[i];
                    arr[i] = temp;
                    return i - 1;
                }
                return i;
            }
        }
        return -1;
    }
}
```

---

## Binary Search

### Basic Binary Search
**Time Complexity**: O(log n)  
**Space Complexity**: O(1) iterative, O(log n) recursive  
**Works on**: Sorted arrays only

```java
public class BinarySearch {
    
    /**
     * Binary Search - Iterative implementation
     * Time: O(log n), Space: O(1)
     */
    public static int binarySearch(int[] arr, int target) {
        int left = 0;
        int right = arr.length - 1;
        
        while (left <= right) {
            int mid = left + (right - left) / 2; // Avoid overflow
            
            if (arr[mid] == target) {
                return mid;
            } else if (arr[mid] < target) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        
        return -1; // Not found
    }
    
    /**
     * Binary Search - Recursive implementation
     * Time: O(log n), Space: O(log n)
     */
    public static int binarySearchRecursive(int[] arr, int target) {
        return binarySearchHelper(arr, target, 0, arr.length - 1);
    }
    
    private static int binarySearchHelper(int[] arr, int target, int left, int right) {
        if (left > right) {
            return -1;
        }
        
        int mid = left + (right - left) / 2;
        
        if (arr[mid] == target) {
            return mid;
        } else if (arr[mid] < target) {
            return binarySearchHelper(arr, target, mid + 1, right);
        } else {
            return binarySearchHelper(arr, target, left, mid - 1);
        }
    }
}
```

### Binary Search Variations

#### 1. Find First Occurrence
```java
public class BinarySearchVariations {
    
    /**
     * Find first occurrence of target
     * Time: O(log n), Space: O(1)
     */
    public static int findFirstOccurrence(int[] arr, int target) {
        int left = 0;
        int right = arr.length - 1;
        int result = -1;
        
        while (left <= right) {
            int mid = left + (right - left) / 2;
            
            if (arr[mid] == target) {
                result = mid;
                right = mid - 1; // Continue searching left
            } else if (arr[mid] < target) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        
        return result;
    }
    
    /**
     * Find last occurrence of target
     * Time: O(log n), Space: O(1)
     */
    public static int findLastOccurrence(int[] arr, int target) {
        int left = 0;
        int right = arr.length - 1;
        int result = -1;
        
        while (left <= right) {
            int mid = left + (right - left) / 2;
            
            if (arr[mid] == target) {
                result = mid;
                left = mid + 1; // Continue searching right
            } else if (arr[mid] < target) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        
        return result;
    }
}
```

#### 2. Find Insert Position
```java
public class BinarySearchVariations {
    
    /**
     * Find insert position for target (leftmost position)
     * Time: O(log n), Space: O(1)
     */
    public static int findInsertPosition(int[] arr, int target) {
        int left = 0;
        int right = arr.length;
        
        while (left < right) {
            int mid = left + (right - left) / 2;
            
            if (arr[mid] < target) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }
        
        return left;
    }
    
    /**
     * Find insert position for target (rightmost position)
     * Time: O(log n), Space: O(1)
     */
    public static int findInsertPositionRight(int[] arr, int target) {
        int left = 0;
        int right = arr.length;
        
        while (left < right) {
            int mid = left + (right - left) / 2;
            
            if (arr[mid] <= target) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }
        
        return left;
    }
}
```

#### 3. Search in Rotated Array
```java
public class BinarySearchVariations {
    
    /**
     * Search in rotated sorted array
     * Time: O(log n), Space: O(1)
     */
    public static int searchRotatedArray(int[] arr, int target) {
        int left = 0;
        int right = arr.length - 1;
        
        while (left <= right) {
            int mid = left + (right - left) / 2;
            
            if (arr[mid] == target) {
                return mid;
            }
            
            // Check which half is sorted
            if (arr[left] <= arr[mid]) {
                // Left half is sorted
                if (target >= arr[left] && target < arr[mid]) {
                    right = mid - 1;
                } else {
                    left = mid + 1;
                }
            } else {
                // Right half is sorted
                if (target > arr[mid] && target <= arr[right]) {
                    left = mid + 1;
                } else {
                    right = mid - 1;
                }
            }
        }
        
        return -1;
    }
}
```

#### 4. Find Peak Element
```java
public class BinarySearchVariations {
    
    /**
     * Find peak element in array
     * Time: O(log n), Space: O(1)
     */
    public static int findPeakElement(int[] arr) {
        int left = 0;
        int right = arr.length - 1;
        
        while (left < right) {
            int mid = left + (right - left) / 2;
            
            if (arr[mid] > arr[mid + 1]) {
                right = mid;
            } else {
                left = mid + 1;
            }
        }
        
        return left;
    }
}
```

---

## Advanced Searching

### 1. Ternary Search
**Time Complexity**: O(log₃ n)  
**Space Complexity**: O(1)  
**Works on**: Unimodal functions

```java
public class TernarySearch {
    
    /**
     * Ternary Search - Divide search space into three parts
     * Time: O(log₃ n), Space: O(1)
     */
    public static int ternarySearch(int[] arr, int target) {
        int left = 0;
        int right = arr.length - 1;
        
        while (left <= right) {
            int mid1 = left + (right - left) / 3;
            int mid2 = right - (right - left) / 3;
            
            if (arr[mid1] == target) {
                return mid1;
            }
            if (arr[mid2] == target) {
                return mid2;
            }
            
            if (target < arr[mid1]) {
                right = mid1 - 1;
            } else if (target > arr[mid2]) {
                left = mid2 + 1;
            } else {
                left = mid1 + 1;
                right = mid2 - 1;
            }
        }
        
        return -1;
    }
}
```

### 2. Jump Search
**Time Complexity**: O(√n)  
**Space Complexity**: O(1)  
**Works on**: Sorted arrays

```java
public class JumpSearch {
    
    /**
     * Jump Search - Jump by fixed steps, then linear search
     * Time: O(√n), Space: O(1)
     */
    public static int jumpSearch(int[] arr, int target) {
        int n = arr.length;
        int step = (int) Math.sqrt(n);
        int prev = 0;
        
        // Find the block where target might be
        while (arr[Math.min(step, n) - 1] < target) {
            prev = step;
            step += (int) Math.sqrt(n);
            if (prev >= n) {
                return -1;
            }
        }
        
        // Linear search in the block
        while (arr[prev] < target) {
            prev++;
            if (prev == Math.min(step, n)) {
                return -1;
            }
        }
        
        if (arr[prev] == target) {
            return prev;
        }
        
        return -1;
    }
}
```

### 3. Interpolation Search
**Time Complexity**: O(log log n) average, O(n) worst  
**Space Complexity**: O(1)  
**Works on**: Uniformly distributed sorted arrays

```java
public class InterpolationSearch {
    
    /**
     * Interpolation Search - Estimate position based on value
     * Time: O(log log n) average, O(n) worst, Space: O(1)
     */
    public static int interpolationSearch(int[] arr, int target) {
        int left = 0;
        int right = arr.length - 1;
        
        while (left <= right && target >= arr[left] && target <= arr[right]) {
            if (left == right) {
                if (arr[left] == target) {
                    return left;
                }
                return -1;
            }
            
            // Calculate position using interpolation formula
            int pos = left + ((target - arr[left]) * (right - left)) / (arr[right] - arr[left]);
            
            if (arr[pos] == target) {
                return pos;
            } else if (arr[pos] < target) {
                left = pos + 1;
            } else {
                right = pos - 1;
            }
        }
        
        return -1;
    }
}
```

---

## String Searching

### 1. Naive String Search
**Time Complexity**: O(m × n)  
**Space Complexity**: O(1)

```java
public class StringSearch {
    
    /**
     * Naive String Search - Check every position
     * Time: O(m × n), Space: O(1)
     */
    public static int naiveSearch(String text, String pattern) {
        int n = text.length();
        int m = pattern.length();
        
        for (int i = 0; i <= n - m; i++) {
            int j;
            for (j = 0; j < m; j++) {
                if (text.charAt(i + j) != pattern.charAt(j)) {
                    break;
                }
            }
            if (j == m) {
                return i; // Pattern found at index i
            }
        }
        
        return -1; // Pattern not found
    }
    
    /**
     * Find all occurrences of pattern in text
     * Time: O(m × n), Space: O(k) where k is number of matches
     */
    public static List<Integer> findAllOccurrences(String text, String pattern) {
        List<Integer> indices = new ArrayList<>();
        int n = text.length();
        int m = pattern.length();
        
        for (int i = 0; i <= n - m; i++) {
            int j;
            for (j = 0; j < m; j++) {
                if (text.charAt(i + j) != pattern.charAt(j)) {
                    break;
                }
            }
            if (j == m) {
                indices.add(i);
            }
        }
        
        return indices;
    }
}
```

### 2. KMP Algorithm
**Time Complexity**: O(m + n)  
**Space Complexity**: O(m)

```java
public class StringSearch {
    
    /**
     * KMP Algorithm - Knuth-Morris-Pratt
     * Time: O(m + n), Space: O(m)
     */
    public static int kmpSearch(String text, String pattern) {
        int n = text.length();
        int m = pattern.length();
        
        if (m == 0) return 0;
        
        int[] lps = computeLPS(pattern);
        int i = 0; // Index for text
        int j = 0; // Index for pattern
        
        while (i < n) {
            if (text.charAt(i) == pattern.charAt(j)) {
                i++;
                j++;
            }
            
            if (j == m) {
                return i - j; // Pattern found
            } else if (i < n && text.charAt(i) != pattern.charAt(j)) {
                if (j != 0) {
                    j = lps[j - 1];
                } else {
                    i++;
                }
            }
        }
        
        return -1;
    }
    
    /**
     * Compute Longest Proper Prefix which is also Suffix
     */
    private static int[] computeLPS(String pattern) {
        int m = pattern.length();
        int[] lps = new int[m];
        int len = 0;
        int i = 1;
        
        while (i < m) {
            if (pattern.charAt(i) == pattern.charAt(len)) {
                len++;
                lps[i] = len;
                i++;
            } else {
                if (len != 0) {
                    len = lps[len - 1];
                } else {
                    lps[i] = 0;
                    i++;
                }
            }
        }
        
        return lps;
    }
}
```

---

## Searching Applications

### 1. Find Kth Largest Element
```java
public class SearchingApplications {
    
    /**
     * Find Kth largest element using quick select
     * Time: O(n) average, O(n²) worst, Space: O(1)
     */
    public static int findKthLargest(int[] nums, int k) {
        return quickSelect(nums, 0, nums.length - 1, nums.length - k);
    }
    
    private static int quickSelect(int[] arr, int left, int right, int k) {
        if (left == right) return arr[left];
        
        int pivotIndex = partition(arr, left, right);
        
        if (k == pivotIndex) {
            return arr[k];
        } else if (k < pivotIndex) {
            return quickSelect(arr, left, pivotIndex - 1, k);
        } else {
            return quickSelect(arr, pivotIndex + 1, right, k);
        }
    }
    
    private static int partition(int[] arr, int left, int right) {
        int pivot = arr[right];
        int i = left - 1;
        
        for (int j = left; j < right; j++) {
            if (arr[j] <= pivot) {
                i++;
                swap(arr, i, j);
            }
        }
        
        swap(arr, i + 1, right);
        return i + 1;
    }
    
    private static void swap(int[] arr, int i, int j) {
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }
}
```

### 2. Search in 2D Matrix
```java
public class SearchingApplications {
    
    /**
     * Search in 2D matrix (sorted row-wise and column-wise)
     * Time: O(m + n), Space: O(1)
     */
    public static boolean searchMatrix(int[][] matrix, int target) {
        if (matrix.length == 0 || matrix[0].length == 0) return false;
        
        int row = 0;
        int col = matrix[0].length - 1;
        
        while (row < matrix.length && col >= 0) {
            if (matrix[row][col] == target) {
                return true;
            } else if (matrix[row][col] > target) {
                col--;
            } else {
                row++;
            }
        }
        
        return false;
    }
}
```

### 3. Find Missing Number
```java
public class SearchingApplications {
    
    /**
     * Find missing number in array containing n distinct numbers from 0 to n
     * Time: O(n), Space: O(1)
     */
    public static int findMissingNumber(int[] nums) {
        int n = nums.length;
        int expectedSum = n * (n + 1) / 2;
        int actualSum = 0;
        
        for (int num : nums) {
            actualSum += num;
        }
        
        return expectedSum - actualSum;
    }
    
    /**
     * Find missing number using XOR
     * Time: O(n), Space: O(1)
     */
    public static int findMissingNumberXOR(int[] nums) {
        int n = nums.length;
        int expectedXOR = 0;
        int actualXOR = 0;
        
        for (int i = 0; i <= n; i++) {
            expectedXOR ^= i;
        }
        
        for (int num : nums) {
            actualXOR ^= num;
        }
        
        return expectedXOR ^ actualXOR;
    }
}
```

---

## 🎯 Algorithm Comparison

| Algorithm | Time Complexity | Space Complexity | Best Use Case |
|-----------|----------------|------------------|---------------|
| Linear Search | O(n) | O(1) | Unsorted arrays |
| Binary Search | O(log n) | O(1) | Sorted arrays |
| Ternary Search | O(log₃ n) | O(1) | Unimodal functions |
| Jump Search | O(√n) | O(1) | Sorted arrays |
| Interpolation Search | O(log log n) | O(1) | Uniformly distributed |
| KMP | O(m + n) | O(m) | String searching |

---

## 🏋️ Exercises

### Exercise 1: Implement Binary Search ⭐
Implement binary search with both iterative and recursive approaches.

### Exercise 2: Search Insert Position ⭐⭐
Given a sorted array and a target value, return the index where target should be inserted.

### Exercise 3: Find First and Last Position ⭐⭐
Given a sorted array with duplicates, find the first and last position of target.

### Exercise 4: Search in Rotated Sorted Array ⭐⭐
Search for a target in a rotated sorted array.

### Exercise 5: Find Peak Element ⭐⭐
Find a peak element in an array (greater than its neighbors).

### Exercise 6: Kth Largest Element ⭐⭐
Find the kth largest element in an unsorted array.

### Exercise 7: Search in 2D Matrix ⭐⭐
Search for a target in a 2D matrix sorted row-wise and column-wise.

### Exercise 8: Find Missing Number ⭐
Find the missing number in an array containing n distinct numbers from 0 to n.

---

## 🎓 Interview Tips

1. **Choose the right algorithm**:
   - Sorted array → Binary search
   - Unsorted array → Linear search
   - String searching → KMP algorithm

2. **Handle edge cases**:
   - Empty arrays
   - Single element arrays
   - Target not found
   - Duplicate elements

3. **Optimize for repeated searches**:
   - Move to front
   - Transposition
   - Self-organizing data structures

4. **Understand the trade-offs**:
   - Time vs space complexity
   - Preprocessing vs search time
   - Static vs dynamic data

---

## 🚀 What's Next?

You've mastered searching algorithms! Next, we'll explore:
- [Dynamic Programming](05-advanced-algorithms/01-dynamic-programming.md) - Optimizing recursive solutions
- [Graph Algorithms](05-advanced-algorithms/02-graph-algorithms.md) - Traversing and analyzing graphs
- [Greedy Algorithms](05-advanced-algorithms/03-greedy.md) - Making locally optimal choices

Remember: **Searching is often a building block for more complex algorithms!** Master these patterns and you'll be ready for any searching problem.

---

*"The best search algorithm is the one that fits your data structure and use case." - Computer Science Wisdom*
