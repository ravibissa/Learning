/**
 * Complete Searching Algorithms Implementation
 * 
 * This class contains implementations of all major searching algorithms
 * with detailed explanations and complexity analysis.
 * 
 * @author DSA Tutorial
 * @version 1.0
 */
import java.util.*;

public class SearchingAlgorithms {
    
    /**
     * Linear Search - Search element by element
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     * Works on: Any data structure
     */
    public static int linearSearch(int[] arr, int target) {
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == target) {
                return i; // Return index where found
            }
        }
        return -1; // Not found
    }
    
    /**
     * Linear Search with enhanced for loop
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     */
    public static int linearSearchEnhanced(int[] arr, int target) {
        int index = 0;
        for (int element : arr) {
            if (element == target) {
                return index;
            }
            index++;
        }
        return -1;
    }
    
    /**
     * Find all occurrences of target
     * Time Complexity: O(n)
     * Space Complexity: O(k) where k is number of occurrences
     */
    public static List<Integer> findAllOccurrences(int[] arr, int target) {
        List<Integer> indices = new ArrayList<>();
        
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == target) {
                indices.add(i);
            }
        }
        
        return indices;
    }
    
    /**
     * Find last occurrence of target
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     */
    public static int findLastOccurrence(int[] arr, int target) {
        int lastIndex = -1;
        
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == target) {
                lastIndex = i;
            }
        }
        
        return lastIndex;
    }
    
    /**
     * Move to Front - Move found element to beginning
     * Time Complexity: O(n) worst, O(1) best for repeated searches
     * Space Complexity: O(1)
     */
    public static int moveToFrontSearch(int[] arr, int target) {
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == target) {
                // Move to front
                int temp = arr[0];
                arr[0] = arr[i];
                arr[i] = temp;
                return i;
            }
        }
        return -1;
    }
    
    /**
     * Transposition - Move found element one position left
     * Time Complexity: O(n) worst, O(1) best for repeated searches
     * Space Complexity: O(1)
     */
    public static int transpositionSearch(int[] arr, int target) {
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == target) {
                if (i > 0) {
                    // Swap with previous element
                    int temp = arr[i - 1];
                    arr[i - 1] = arr[i];
                    arr[i] = temp;
                    return i - 1;
                }
                return i;
            }
        }
        return -1;
    }
    
    /**
     * Binary Search - Iterative implementation
     * Time Complexity: O(log n)
     * Space Complexity: O(1)
     * Works on: Sorted arrays only
     */
    public static int binarySearch(int[] arr, int target) {
        int left = 0;
        int right = arr.length - 1;
        
        while (left <= right) {
            int mid = left + (right - left) / 2; // Avoid overflow
            
            if (arr[mid] == target) {
                return mid;
            } else if (arr[mid] < target) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        
        return -1; // Not found
    }
    
    /**
     * Binary Search - Recursive implementation
     * Time Complexity: O(log n)
     * Space Complexity: O(log n)
     */
    public static int binarySearchRecursive(int[] arr, int target) {
        return binarySearchHelper(arr, target, 0, arr.length - 1);
    }
    
    private static int binarySearchHelper(int[] arr, int target, int left, int right) {
        if (left > right) {
            return -1;
        }
        
        int mid = left + (right - left) / 2;
        
        if (arr[mid] == target) {
            return mid;
        } else if (arr[mid] < target) {
            return binarySearchHelper(arr, target, mid + 1, right);
        } else {
            return binarySearchHelper(arr, target, left, mid - 1);
        }
    }
    
    /**
     * Find first occurrence of target
     * Time Complexity: O(log n)
     * Space Complexity: O(1)
     */
    public static int findFirstOccurrence(int[] arr, int target) {
        int left = 0;
        int right = arr.length - 1;
        int result = -1;
        
        while (left <= right) {
            int mid = left + (right - left) / 2;
            
            if (arr[mid] == target) {
                result = mid;
                right = mid - 1; // Continue searching left
            } else if (arr[mid] < target) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        
        return result;
    }
    
    /**
     * Find last occurrence of target
     * Time Complexity: O(log n)
     * Space Complexity: O(1)
     */
    public static int findLastOccurrence(int[] arr, int target) {
        int left = 0;
        int right = arr.length - 1;
        int result = -1;
        
        while (left <= right) {
            int mid = left + (right - left) / 2;
            
            if (arr[mid] == target) {
                result = mid;
                left = mid + 1; // Continue searching right
            } else if (arr[mid] < target) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        
        return result;
    }
    
    /**
     * Find insert position for target (leftmost position)
     * Time Complexity: O(log n)
     * Space Complexity: O(1)
     */
    public static int findInsertPosition(int[] arr, int target) {
        int left = 0;
        int right = arr.length;
        
        while (left < right) {
            int mid = left + (right - left) / 2;
            
            if (arr[mid] < target) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }
        
        return left;
    }
    
    /**
     * Find insert position for target (rightmost position)
     * Time Complexity: O(log n)
     * Space Complexity: O(1)
     */
    public static int findInsertPositionRight(int[] arr, int target) {
        int left = 0;
        int right = arr.length;
        
        while (left < right) {
            int mid = left + (right - left) / 2;
            
            if (arr[mid] <= target) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }
        
        return left;
    }
    
    /**
     * Search in rotated sorted array
     * Time Complexity: O(log n)
     * Space Complexity: O(1)
     */
    public static int searchRotatedArray(int[] arr, int target) {
        int left = 0;
        int right = arr.length - 1;
        
        while (left <= right) {
            int mid = left + (right - left) / 2;
            
            if (arr[mid] == target) {
                return mid;
            }
            
            // Check which half is sorted
            if (arr[left] <= arr[mid]) {
                // Left half is sorted
                if (target >= arr[left] && target < arr[mid]) {
                    right = mid - 1;
                } else {
                    left = mid + 1;
                }
            } else {
                // Right half is sorted
                if (target > arr[mid] && target <= arr[right]) {
                    left = mid + 1;
                } else {
                    right = mid - 1;
                }
            }
        }
        
        return -1;
    }
    
    /**
     * Find peak element in array
     * Time Complexity: O(log n)
     * Space Complexity: O(1)
     */
    public static int findPeakElement(int[] arr) {
        int left = 0;
        int right = arr.length - 1;
        
        while (left < right) {
            int mid = left + (right - left) / 2;
            
            if (arr[mid] > arr[mid + 1]) {
                right = mid;
            } else {
                left = mid + 1;
            }
        }
        
        return left;
    }
    
    /**
     * Ternary Search - Divide search space into three parts
     * Time Complexity: O(log₃ n)
     * Space Complexity: O(1)
     * Works on: Unimodal functions
     */
    public static int ternarySearch(int[] arr, int target) {
        int left = 0;
        int right = arr.length - 1;
        
        while (left <= right) {
            int mid1 = left + (right - left) / 3;
            int mid2 = right - (right - left) / 3;
            
            if (arr[mid1] == target) {
                return mid1;
            }
            if (arr[mid2] == target) {
                return mid2;
            }
            
            if (target < arr[mid1]) {
                right = mid1 - 1;
            } else if (target > arr[mid2]) {
                left = mid2 + 1;
            } else {
                left = mid1 + 1;
                right = mid2 - 1;
            }
        }
        
        return -1;
    }
    
    /**
     * Jump Search - Jump by fixed steps, then linear search
     * Time Complexity: O(√n)
     * Space Complexity: O(1)
     * Works on: Sorted arrays
     */
    public static int jumpSearch(int[] arr, int target) {
        int n = arr.length;
        int step = (int) Math.sqrt(n);
        int prev = 0;
        
        // Find the block where target might be
        while (arr[Math.min(step, n) - 1] < target) {
            prev = step;
            step += (int) Math.sqrt(n);
            if (prev >= n) {
                return -1;
            }
        }
        
        // Linear search in the block
        while (arr[prev] < target) {
            prev++;
            if (prev == Math.min(step, n)) {
                return -1;
            }
        }
        
        if (arr[prev] == target) {
            return prev;
        }
        
        return -1;
    }
    
    /**
     * Interpolation Search - Estimate position based on value
     * Time Complexity: O(log log n) average, O(n) worst
     * Space Complexity: O(1)
     * Works on: Uniformly distributed sorted arrays
     */
    public static int interpolationSearch(int[] arr, int target) {
        int left = 0;
        int right = arr.length - 1;
        
        while (left <= right && target >= arr[left] && target <= arr[right]) {
            if (left == right) {
                if (arr[left] == target) {
                    return left;
                }
                return -1;
            }
            
            // Calculate position using interpolation formula
            int pos = left + ((target - arr[left]) * (right - left)) / (arr[right] - arr[left]);
            
            if (arr[pos] == target) {
                return pos;
            } else if (arr[pos] < target) {
                left = pos + 1;
            } else {
                right = pos - 1;
            }
        }
        
        return -1;
    }
    
    /**
     * Naive String Search - Check every position
     * Time Complexity: O(m × n)
     * Space Complexity: O(1)
     */
    public static int naiveSearch(String text, String pattern) {
        int n = text.length();
        int m = pattern.length();
        
        for (int i = 0; i <= n - m; i++) {
            int j;
            for (j = 0; j < m; j++) {
                if (text.charAt(i + j) != pattern.charAt(j)) {
                    break;
                }
            }
            if (j == m) {
                return i; // Pattern found at index i
            }
        }
        
        return -1; // Pattern not found
    }
    
    /**
     * Find all occurrences of pattern in text
     * Time Complexity: O(m × n)
     * Space Complexity: O(k) where k is number of matches
     */
    public static List<Integer> findAllOccurrences(String text, String pattern) {
        List<Integer> indices = new ArrayList<>();
        int n = text.length();
        int m = pattern.length();
        
        for (int i = 0; i <= n - m; i++) {
            int j;
            for (j = 0; j < m; j++) {
                if (text.charAt(i + j) != pattern.charAt(j)) {
                    break;
                }
            }
            if (j == m) {
                indices.add(i);
            }
        }
        
        return indices;
    }
    
    /**
     * KMP Algorithm - Knuth-Morris-Pratt
     * Time Complexity: O(m + n)
     * Space Complexity: O(m)
     */
    public static int kmpSearch(String text, String pattern) {
        int n = text.length();
        int m = pattern.length();
        
        if (m == 0) return 0;
        
        int[] lps = computeLPS(pattern);
        int i = 0; // Index for text
        int j = 0; // Index for pattern
        
        while (i < n) {
            if (text.charAt(i) == pattern.charAt(j)) {
                i++;
                j++;
            }
            
            if (j == m) {
                return i - j; // Pattern found
            } else if (i < n && text.charAt(i) != pattern.charAt(j)) {
                if (j != 0) {
                    j = lps[j - 1];
                } else {
                    i++;
                }
            }
        }
        
        return -1;
    }
    
    /**
     * Compute Longest Proper Prefix which is also Suffix
     */
    private static int[] computeLPS(String pattern) {
        int m = pattern.length();
        int[] lps = new int[m];
        int len = 0;
        int i = 1;
        
        while (i < m) {
            if (pattern.charAt(i) == pattern.charAt(len)) {
                len++;
                lps[i] = len;
                i++;
            } else {
                if (len != 0) {
                    len = lps[len - 1];
                } else {
                    lps[i] = 0;
                    i++;
                }
            }
        }
        
        return lps;
    }
    
    /**
     * Find Kth largest element using quick select
     * Time Complexity: O(n) average, O(n²) worst
     * Space Complexity: O(1)
     */
    public static int findKthLargest(int[] nums, int k) {
        return quickSelect(nums, 0, nums.length - 1, nums.length - k);
    }
    
    private static int quickSelect(int[] arr, int left, int right, int k) {
        if (left == right) return arr[left];
        
        int pivotIndex = partition(arr, left, right);
        
        if (k == pivotIndex) {
            return arr[k];
        } else if (k < pivotIndex) {
            return quickSelect(arr, left, pivotIndex - 1, k);
        } else {
            return quickSelect(arr, pivotIndex + 1, right, k);
        }
    }
    
    private static int partition(int[] arr, int left, int right) {
        int pivot = arr[right];
        int i = left - 1;
        
        for (int j = left; j < right; j++) {
            if (arr[j] <= pivot) {
                i++;
                swap(arr, i, j);
            }
        }
        
        swap(arr, i + 1, right);
        return i + 1;
    }
    
    /**
     * Search in 2D matrix (sorted row-wise and column-wise)
     * Time Complexity: O(m + n)
     * Space Complexity: O(1)
     */
    public static boolean searchMatrix(int[][] matrix, int target) {
        if (matrix.length == 0 || matrix[0].length == 0) return false;
        
        int row = 0;
        int col = matrix[0].length - 1;
        
        while (row < matrix.length && col >= 0) {
            if (matrix[row][col] == target) {
                return true;
            } else if (matrix[row][col] > target) {
                col--;
            } else {
                row++;
            }
        }
        
        return false;
    }
    
    /**
     * Find missing number in array containing n distinct numbers from 0 to n
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     */
    public static int findMissingNumber(int[] nums) {
        int n = nums.length;
        int expectedSum = n * (n + 1) / 2;
        int actualSum = 0;
        
        for (int num : nums) {
            actualSum += num;
        }
        
        return expectedSum - actualSum;
    }
    
    /**
     * Find missing number using XOR
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     */
    public static int findMissingNumberXOR(int[] nums) {
        int n = nums.length;
        int expectedXOR = 0;
        int actualXOR = 0;
        
        for (int i = 0; i <= n; i++) {
            expectedXOR ^= i;
        }
        
        for (int num : nums) {
            actualXOR ^= num;
        }
        
        return expectedXOR ^ actualXOR;
    }
    
    /**
     * Helper method to swap elements
     */
    private static void swap(int[] arr, int i, int j) {
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }
    
    /**
     * Helper method to print array
     */
    public static void printArray(int[] arr) {
        System.out.println(Arrays.toString(arr));
    }
    
    /**
     * Helper method to print array with label
     */
    public static void printArray(String label, int[] arr) {
        System.out.println(label + ": " + Arrays.toString(arr));
    }
    
    /**
     * Helper method to create a copy of array
     */
    public static int[] copyArray(int[] arr) {
        return Arrays.copyOf(arr, arr.length);
    }
    
    public static void main(String[] args) {
        System.out.println("=== Searching Algorithms Demo ===\n");
        
        // Test data
        int[] unsortedArray = {64, 34, 25, 12, 22, 11, 90, 5, 77, 30};
        int[] sortedArray = {5, 11, 12, 22, 25, 30, 34, 64, 77, 90};
        int[] duplicateArray = {1, 2, 2, 2, 3, 4, 4, 5, 6, 7};
        
        System.out.println("Test arrays:");
        printArray("Unsorted", unsortedArray);
        printArray("Sorted", sortedArray);
        printArray("With duplicates", duplicateArray);
        System.out.println();
        
        // Test Linear Search
        System.out.println("1. Linear Search:");
        int target1 = 25;
        int result1 = linearSearch(unsortedArray, target1);
        System.out.println("Search for " + target1 + " in unsorted array: " + result1);
        
        List<Integer> occurrences = findAllOccurrences(duplicateArray, 2);
        System.out.println("All occurrences of 2 in duplicate array: " + occurrences);
        System.out.println();
        
        // Test Binary Search
        System.out.println("2. Binary Search:");
        int target2 = 30;
        int result2 = binarySearch(sortedArray, target2);
        System.out.println("Search for " + target2 + " in sorted array: " + result2);
        
        int result3 = binarySearchRecursive(sortedArray, target2);
        System.out.println("Recursive search for " + target2 + ": " + result3);
        System.out.println();
        
        // Test Binary Search Variations
        System.out.println("3. Binary Search Variations:");
        int firstOcc = findFirstOccurrence(duplicateArray, 2);
        int lastOcc = findLastOccurrence(duplicateArray, 2);
        System.out.println("First occurrence of 2: " + firstOcc);
        System.out.println("Last occurrence of 2: " + lastOcc);
        
        int insertPos = findInsertPosition(sortedArray, 28);
        System.out.println("Insert position for 28: " + insertPos);
        System.out.println();
        
        // Test Advanced Searching
        System.out.println("4. Advanced Searching:");
        int[] rotatedArray = {4, 5, 6, 7, 0, 1, 2};
        printArray("Rotated array", rotatedArray);
        int rotatedResult = searchRotatedArray(rotatedArray, 0);
        System.out.println("Search for 0 in rotated array: " + rotatedResult);
        
        int[] peakArray = {1, 2, 3, 1};
        printArray("Peak array", peakArray);
        int peakIndex = findPeakElement(peakArray);
        System.out.println("Peak element index: " + peakIndex);
        System.out.println();
        
        // Test Other Search Algorithms
        System.out.println("5. Other Search Algorithms:");
        int ternaryResult = ternarySearch(sortedArray, 30);
        System.out.println("Ternary search for 30: " + ternaryResult);
        
        int jumpResult = jumpSearch(sortedArray, 30);
        System.out.println("Jump search for 30: " + jumpResult);
        
        int interpResult = interpolationSearch(sortedArray, 30);
        System.out.println("Interpolation search for 30: " + interpResult);
        System.out.println();
        
        // Test String Searching
        System.out.println("6. String Searching:");
        String text = "ABABDABACDABABCABAB";
        String pattern = "ABABCABAB";
        int naiveResult = naiveSearch(text, pattern);
        System.out.println("Naive search for '" + pattern + "' in '" + text + "': " + naiveResult);
        
        int kmpResult = kmpSearch(text, pattern);
        System.out.println("KMP search for '" + pattern + "' in '" + text + "': " + kmpResult);
        System.out.println();
        
        // Test Applications
        System.out.println("7. Searching Applications:");
        int[] kthArray = {3, 2, 1, 5, 6, 4};
        printArray("Kth largest array", kthArray);
        int kthLargest = findKthLargest(kthArray, 2);
        System.out.println("2nd largest element: " + kthLargest);
        
        int[][] matrix = {{1, 4, 7, 11}, {2, 5, 8, 12}, {3, 6, 9, 16}};
        boolean matrixResult = searchMatrix(matrix, 5);
        System.out.println("Search for 5 in 2D matrix: " + matrixResult);
        
        int[] missingArray = {3, 0, 1};
        printArray("Missing number array", missingArray);
        int missing = findMissingNumber(missingArray);
        System.out.println("Missing number: " + missing);
        
        int missingXOR = findMissingNumberXOR(missingArray);
        System.out.println("Missing number (XOR): " + missingXOR);
        System.out.println();
        
        System.out.println("=== Searching Algorithm Summary ===");
        System.out.println("• Linear Search: O(n) - Works on any data structure");
        System.out.println("• Binary Search: O(log n) - Works on sorted arrays");
        System.out.println("• Ternary Search: O(log₃ n) - Works on unimodal functions");
        System.out.println("• Jump Search: O(√n) - Works on sorted arrays");
        System.out.println("• Interpolation Search: O(log log n) - Works on uniformly distributed arrays");
        System.out.println("• KMP: O(m + n) - Efficient string searching");
        System.out.println("• Choose the right algorithm based on your data structure and requirements");
    }
}
