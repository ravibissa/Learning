# Sorting Algorithms
## Organizing Data Efficiently

Sorting is one of the most fundamental operations in computer science. Understanding different sorting algorithms helps you choose the right one for your specific use case and is essential for technical interviews.

## 🎯 Learning Objectives
By the end of this section, you will:
- Understand different sorting algorithms and their trade-offs
- Implement sorting algorithms from scratch
- Analyze time and space complexity
- Choose the right sorting algorithm for different scenarios
- Be ready for sorting-related interview questions

## 📚 Table of Contents
1. [Sorting Fundamentals](#sorting-fundamentals)
2. [Comparison-Based Sorting](#comparison-based-sorting)
3. [Non-Comparison Sorting](#non-comparison-sorting)
4. [Hybrid Sorting](#hybrid-sorting)
5. [Sorting Applications](#sorting-applications)
6. [Exercises](#exercises)

---

## Sorting Fundamentals

### What is Sorting?
Sorting is the process of arranging data in a particular order (ascending or descending) based on some criteria.

### Sorting Categories:

#### 1. Comparison-Based Sorting
- Compare elements to determine their relative order
- Lower bound: Ω(n log n) for comparison-based sorts
- Examples: Bubble Sort, Selection Sort, Insertion Sort, Merge Sort, Quick Sort, Heap Sort

#### 2. Non-Comparison Sorting
- Don't compare elements directly
- Can achieve O(n) time complexity
- Examples: Counting Sort, Radix Sort, Bucket Sort

### Stability:
- **Stable**: Equal elements maintain their relative order
- **Unstable**: Equal elements may change their relative order

### In-Place:
- **In-place**: Uses O(1) extra space
- **Not in-place**: Uses O(n) or more extra space

---

## Comparison-Based Sorting

### 1. Bubble Sort
**Time Complexity**: O(n²) worst/average, O(n) best  
**Space Complexity**: O(1)  
**Stable**: Yes  
**In-place**: Yes

```java
public class BubbleSort {
    
    /**
     * Bubble Sort - Compare adjacent elements and swap if needed
     * Time: O(n²), Space: O(1)
     */
    public static void bubbleSort(int[] arr) {
        int n = arr.length;
        
        for (int i = 0; i < n - 1; i++) {
            boolean swapped = false;
            
            for (int j = 0; j < n - i - 1; j++) {
                if (arr[j] > arr[j + 1]) {
                    swap(arr, j, j + 1);
                    swapped = true;
                }
            }
            
            // If no swapping occurred, array is sorted
            if (!swapped) break;
        }
    }
    
    private static void swap(int[] arr, int i, int j) {
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }
}
```

### 2. Selection Sort
**Time Complexity**: O(n²) all cases  
**Space Complexity**: O(1)  
**Stable**: No  
**In-place**: Yes

```java
public class SelectionSort {
    
    /**
     * Selection Sort - Find minimum and place at beginning
     * Time: O(n²), Space: O(1)
     */
    public static void selectionSort(int[] arr) {
        int n = arr.length;
        
        for (int i = 0; i < n - 1; i++) {
            int minIndex = i;
            
            // Find minimum element in remaining array
            for (int j = i + 1; j < n; j++) {
                if (arr[j] < arr[minIndex]) {
                    minIndex = j;
                }
            }
            
            // Swap with first element
            swap(arr, i, minIndex);
        }
    }
    
    private static void swap(int[] arr, int i, int j) {
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }
}
```

### 3. Insertion Sort
**Time Complexity**: O(n²) worst/average, O(n) best  
**Space Complexity**: O(1)  
**Stable**: Yes  
**In-place**: Yes

```java
public class InsertionSort {
    
    /**
     * Insertion Sort - Insert element in correct position
     * Time: O(n²), Space: O(1)
     */
    public static void insertionSort(int[] arr) {
        int n = arr.length;
        
        for (int i = 1; i < n; i++) {
            int key = arr[i];
            int j = i - 1;
            
            // Move elements greater than key one position ahead
            while (j >= 0 && arr[j] > key) {
                arr[j + 1] = arr[j];
                j--;
            }
            
            arr[j + 1] = key;
        }
    }
}
```

### 4. Merge Sort
**Time Complexity**: O(n log n) all cases  
**Space Complexity**: O(n)  
**Stable**: Yes  
**In-place**: No

```java
public class MergeSort {
    
    /**
     * Merge Sort - Divide and conquer approach
     * Time: O(n log n), Space: O(n)
     */
    public static void mergeSort(int[] arr) {
        if (arr.length <= 1) return;
        
        int[] temp = new int[arr.length];
        mergeSortHelper(arr, temp, 0, arr.length - 1);
    }
    
    private static void mergeSortHelper(int[] arr, int[] temp, int left, int right) {
        if (left < right) {
            int mid = left + (right - left) / 2;
            
            // Sort left half
            mergeSortHelper(arr, temp, left, mid);
            
            // Sort right half
            mergeSortHelper(arr, temp, mid + 1, right);
            
            // Merge sorted halves
            merge(arr, temp, left, mid, right);
        }
    }
    
    private static void merge(int[] arr, int[] temp, int left, int mid, int right) {
        // Copy data to temp arrays
        for (int i = left; i <= right; i++) {
            temp[i] = arr[i];
        }
        
        int i = left;    // Initial index of left subarray
        int j = mid + 1; // Initial index of right subarray
        int k = left;    // Initial index of merged subarray
        
        // Merge temp arrays back into arr
        while (i <= mid && j <= right) {
            if (temp[i] <= temp[j]) {
                arr[k] = temp[i];
                i++;
            } else {
                arr[k] = temp[j];
                j++;
            }
            k++;
        }
        
        // Copy remaining elements of left subarray
        while (i <= mid) {
            arr[k] = temp[i];
            i++;
            k++;
        }
        
        // Copy remaining elements of right subarray
        while (j <= right) {
            arr[k] = temp[j];
            j++;
            k++;
        }
    }
}
```

### 5. Quick Sort
**Time Complexity**: O(n log n) average, O(n²) worst  
**Space Complexity**: O(log n) average, O(n) worst  
**Stable**: No  
**In-place**: Yes

```java
public class QuickSort {
    
    /**
     * Quick Sort - Divide and conquer with pivot
     * Time: O(n log n) average, O(n²) worst, Space: O(log n)
     */
    public static void quickSort(int[] arr) {
        if (arr.length <= 1) return;
        quickSortHelper(arr, 0, arr.length - 1);
    }
    
    private static void quickSortHelper(int[] arr, int low, int high) {
        if (low < high) {
            // Partition array and get pivot index
            int pivotIndex = partition(arr, low, high);
            
            // Recursively sort elements before and after partition
            quickSortHelper(arr, low, pivotIndex - 1);
            quickSortHelper(arr, pivotIndex + 1, high);
        }
    }
    
    private static int partition(int[] arr, int low, int high) {
        // Choose rightmost element as pivot
        int pivot = arr[high];
        int i = low - 1; // Index of smaller element
        
        for (int j = low; j < high; j++) {
            // If current element is smaller than or equal to pivot
            if (arr[j] <= pivot) {
                i++;
                swap(arr, i, j);
            }
        }
        
        // Place pivot in correct position
        swap(arr, i + 1, high);
        return i + 1;
    }
    
    private static void swap(int[] arr, int i, int j) {
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }
}
```

### 6. Heap Sort
**Time Complexity**: O(n log n) all cases  
**Space Complexity**: O(1)  
**Stable**: No  
**In-place**: Yes

```java
public class HeapSort {
    
    /**
     * Heap Sort - Use heap data structure
     * Time: O(n log n), Space: O(1)
     */
    public static void heapSort(int[] arr) {
        int n = arr.length;
        
        // Build max heap
        for (int i = n / 2 - 1; i >= 0; i--) {
            heapify(arr, n, i);
        }
        
        // Extract elements from heap one by one
        for (int i = n - 1; i > 0; i--) {
            // Move current root to end
            swap(arr, 0, i);
            
            // Call heapify on reduced heap
            heapify(arr, i, 0);
        }
    }
    
    private static void heapify(int[] arr, int n, int i) {
        int largest = i;    // Initialize largest as root
        int left = 2 * i + 1;  // Left child
        int right = 2 * i + 2; // Right child
        
        // If left child is larger than root
        if (left < n && arr[left] > arr[largest]) {
            largest = left;
        }
        
        // If right child is larger than largest so far
        if (right < n && arr[right] > arr[largest]) {
            largest = right;
        }
        
        // If largest is not root
        if (largest != i) {
            swap(arr, i, largest);
            
            // Recursively heapify affected sub-tree
            heapify(arr, n, largest);
        }
    }
    
    private static void swap(int[] arr, int i, int j) {
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }
}
```

---

## Non-Comparison Sorting

### 1. Counting Sort
**Time Complexity**: O(n + k) where k is range  
**Space Complexity**: O(k)  
**Stable**: Yes  
**In-place**: No

```java
public class CountingSort {
    
    /**
     * Counting Sort - Count occurrences of each element
     * Time: O(n + k), Space: O(k)
     */
    public static void countingSort(int[] arr) {
        if (arr.length == 0) return;
        
        // Find range of input array
        int max = Arrays.stream(arr).max().getAsInt();
        int min = Arrays.stream(arr).min().getAsInt();
        int range = max - min + 1;
        
        // Create count array
        int[] count = new int[range];
        int[] output = new int[arr.length];
        
        // Store count of each element
        for (int value : arr) {
            count[value - min]++;
        }
        
        // Modify count array to store actual position
        for (int i = 1; i < range; i++) {
            count[i] += count[i - 1];
        }
        
        // Build output array
        for (int i = arr.length - 1; i >= 0; i--) {
            output[count[arr[i] - min] - 1] = arr[i];
            count[arr[i] - min]--;
        }
        
        // Copy output array to original array
        System.arraycopy(output, 0, arr, 0, arr.length);
    }
}
```

### 2. Radix Sort
**Time Complexity**: O(d × (n + k)) where d is digits, k is base  
**Space Complexity**: O(n + k)  
**Stable**: Yes  
**In-place**: No

```java
public class RadixSort {
    
    /**
     * Radix Sort - Sort by individual digits
     * Time: O(d × (n + k)), Space: O(n + k)
     */
    public static void radixSort(int[] arr) {
        if (arr.length == 0) return;
        
        // Find maximum number to know number of digits
        int max = Arrays.stream(arr).max().getAsInt();
        
        // Do counting sort for every digit
        for (int exp = 1; max / exp > 0; exp *= 10) {
            countingSortByDigit(arr, exp);
        }
    }
    
    private static void countingSortByDigit(int[] arr, int exp) {
        int n = arr.length;
        int[] output = new int[n];
        int[] count = new int[10];
        
        // Store count of occurrences
        for (int value : arr) {
            count[(value / exp) % 10]++;
        }
        
        // Change count to actual position
        for (int i = 1; i < 10; i++) {
            count[i] += count[i - 1];
        }
        
        // Build output array
        for (int i = n - 1; i >= 0; i--) {
            output[count[(arr[i] / exp) % 10] - 1] = arr[i];
            count[(arr[i] / exp) % 10]--;
        }
        
        // Copy output array to original array
        System.arraycopy(output, 0, arr, 0, n);
    }
}
```

### 3. Bucket Sort
**Time Complexity**: O(n + k) average, O(n²) worst  
**Space Complexity**: O(n + k)  
**Stable**: Yes  
**In-place**: No

```java
public class BucketSort {
    
    /**
     * Bucket Sort - Distribute elements into buckets
     * Time: O(n + k) average, Space: O(n + k)
     */
    public static void bucketSort(double[] arr) {
        if (arr.length == 0) return;
        
        int n = arr.length;
        List<Double>[] buckets = new List[n];
        
        // Create empty buckets
        for (int i = 0; i < n; i++) {
            buckets[i] = new ArrayList<>();
        }
        
        // Put array elements in different buckets
        for (double value : arr) {
            int bucketIndex = (int) (n * value);
            buckets[bucketIndex].add(value);
        }
        
        // Sort individual buckets
        for (List<Double> bucket : buckets) {
            Collections.sort(bucket);
        }
        
        // Concatenate all buckets into arr
        int index = 0;
        for (List<Double> bucket : buckets) {
            for (double value : bucket) {
                arr[index++] = value;
            }
        }
    }
}
```

---

## Hybrid Sorting

### Tim Sort (Used in Python, Java)
**Time Complexity**: O(n log n) worst, O(n) best  
**Space Complexity**: O(n)  
**Stable**: Yes  
**In-place**: No

Tim Sort combines merge sort and insertion sort:
1. Divide array into small runs
2. Sort runs using insertion sort
3. Merge runs using merge sort

### Introsort (Used in C++)
**Time Complexity**: O(n log n) worst  
**Space Complexity**: O(log n)  
**Stable**: No  
**In-place**: Yes

Introsort combines quick sort, heap sort, and insertion sort:
1. Start with quick sort
2. Switch to heap sort if recursion depth is too high
3. Use insertion sort for small arrays

---

## Sorting Applications

### 1. Finding Kth Largest/Smallest Element
```java
public class SortingApplications {
    
    /**
     * Find Kth largest element using sorting
     * Time: O(n log n), Space: O(1)
     */
    public static int findKthLargest(int[] nums, int k) {
        Arrays.sort(nums);
        return nums[nums.length - k];
    }
    
    /**
     * Find Kth largest element using quick select
     * Time: O(n) average, O(n²) worst, Space: O(1)
     */
    public static int findKthLargestQuickSelect(int[] nums, int k) {
        return quickSelect(nums, 0, nums.length - 1, nums.length - k);
    }
    
    private static int quickSelect(int[] arr, int left, int right, int k) {
        if (left == right) return arr[left];
        
        int pivotIndex = partition(arr, left, right);
        
        if (k == pivotIndex) {
            return arr[k];
        } else if (k < pivotIndex) {
            return quickSelect(arr, left, pivotIndex - 1, k);
        } else {
            return quickSelect(arr, pivotIndex + 1, right, k);
        }
    }
}
```

### 2. Merge Intervals
```java
public class SortingApplications {
    
    /**
     * Merge overlapping intervals
     * Time: O(n log n), Space: O(1)
     */
    public static int[][] merge(int[][] intervals) {
        if (intervals.length <= 1) return intervals;
        
        // Sort intervals by start time
        Arrays.sort(intervals, (a, b) -> Integer.compare(a[0], b[0]));
        
        List<int[]> result = new ArrayList<>();
        int[] current = intervals[0];
        
        for (int i = 1; i < intervals.length; i++) {
            if (current[1] >= intervals[i][0]) {
                // Overlapping intervals, merge them
                current[1] = Math.max(current[1], intervals[i][1]);
            } else {
                // Non-overlapping, add current and move to next
                result.add(current);
                current = intervals[i];
            }
        }
        
        result.add(current);
        return result.toArray(new int[result.size()][]);
    }
}
```

### 3. Meeting Rooms
```java
public class SortingApplications {
    
    /**
     * Check if person can attend all meetings
     * Time: O(n log n), Space: O(1)
     */
    public static boolean canAttendMeetings(int[][] intervals) {
        if (intervals.length <= 1) return true;
        
        // Sort by start time
        Arrays.sort(intervals, (a, b) -> Integer.compare(a[0], b[0]));
        
        for (int i = 1; i < intervals.length; i++) {
            if (intervals[i][0] < intervals[i - 1][1]) {
                return false; // Overlapping meetings
            }
        }
        
        return true;
    }
}
```

---

## 🎯 Algorithm Comparison

| Algorithm | Best Case | Average Case | Worst Case | Space | Stable | In-place |
|-----------|-----------|--------------|------------|-------|--------|----------|
| Bubble Sort | O(n) | O(n²) | O(n²) | O(1) | Yes | Yes |
| Selection Sort | O(n²) | O(n²) | O(n²) | O(1) | No | Yes |
| Insertion Sort | O(n) | O(n²) | O(n²) | O(1) | Yes | Yes |
| Merge Sort | O(n log n) | O(n log n) | O(n log n) | O(n) | Yes | No |
| Quick Sort | O(n log n) | O(n log n) | O(n²) | O(log n) | No | Yes |
| Heap Sort | O(n log n) | O(n log n) | O(n log n) | O(1) | No | Yes |
| Counting Sort | O(n + k) | O(n + k) | O(n + k) | O(k) | Yes | No |
| Radix Sort | O(d × n) | O(d × n) | O(d × n) | O(n + k) | Yes | No |

---

## 🏋️ Exercises

### Exercise 1: Implement Bubble Sort ⭐
Implement bubble sort with optimization for early termination.

### Exercise 2: Implement Quick Sort ⭐⭐
Implement quick sort with different pivot selection strategies.

### Exercise 3: Sort Colors (Dutch National Flag) ⭐⭐
Given an array with only 0s, 1s, and 2s, sort it in-place.

### Exercise 4: Merge Sorted Arrays ⭐⭐
Merge two sorted arrays into one sorted array.

### Exercise 5: Find Minimum in Rotated Sorted Array ⭐⭐
Find the minimum element in a rotated sorted array.

### Exercise 6: Sort Characters by Frequency ⭐⭐
Sort characters in a string by their frequency.

### Exercise 7: Largest Number ⭐⭐⭐
Given a list of non-negative integers, arrange them to form the largest number.

### Exercise 8: Custom Sort String ⭐⭐
Sort string s according to the order defined by string t.

---

## 🎓 Interview Tips

1. **Know the trade-offs**:
   - When to use stable vs unstable sorts
   - When to use in-place vs not in-place
   - Time vs space complexity considerations

2. **Understand the algorithms**:
   - Be able to implement from scratch
   - Know the key steps and optimizations
   - Understand when each algorithm performs best

3. **Practice variations**:
   - Different pivot selection for quick sort
   - Optimized versions of basic sorts
   - Hybrid sorting algorithms

4. **Real-world applications**:
   - When to use built-in sort vs custom implementation
   - How sorting enables other algorithms
   - Performance considerations for large datasets

---

## 🚀 What's Next?

You've mastered sorting algorithms! Next, we'll explore:
- [Searching Algorithms](02-searching.md) - Finding elements efficiently
- [Dynamic Programming](05-advanced-algorithms/01-dynamic-programming.md) - Optimizing recursive solutions
- [Graph Algorithms](05-advanced-algorithms/02-graph-algorithms.md) - Traversing and analyzing graphs

Remember: **Sorting is often a preprocessing step for other algorithms!** Understanding sorting helps you solve many complex problems.

---

*"The best sorting algorithm is the one that fits your specific use case." - Computer Science Wisdom*
