# Dynamic Programming
## Optimizing Recursive Solutions

Dynamic Programming (DP) is a powerful technique for solving complex problems by breaking them down into simpler subproblems and storing the results to avoid redundant calculations. It's essential for technical interviews and real-world optimization problems.

## 🎯 Learning Objectives
By the end of this section, you will:
- Understand the core concepts of dynamic programming
- Identify when to use DP vs other approaches
- Master different DP patterns and techniques
- Implement DP solutions from scratch
- Be ready for DP interview questions

## 📚 Table of Contents
1. [Dynamic Programming Fundamentals](#dynamic-programming-fundamentals)
2. [Top-Down Approach (Memoization)](#top-down-approach-memoization)
3. [Bottom-Up Approach (Tabulation)](#bottom-up-approach-tabulation)
4. [Common DP Patterns](#common-dp-patterns)
5. [Advanced DP Techniques](#advanced-dp-techniques)
6. [Exercises](#exercises)

---

## Dynamic Programming Fundamentals

### What is Dynamic Programming?

Dynamic Programming is an algorithmic technique that solves complex problems by:
1. **Breaking down** the problem into simpler subproblems
2. **Storing** the results of subproblems to avoid redundant calculations
3. **Building up** the solution from smaller subproblems

### Key Characteristics:
- **Optimal Substructure**: Optimal solution contains optimal solutions to subproblems
- **Overlapping Subproblems**: Same subproblems are solved multiple times
- **Memoization**: Store results of expensive function calls

### When to Use DP:
- Problem can be broken into overlapping subproblems
- Brute force solution has exponential time complexity
- You need to find optimal solution (minimum, maximum, count, etc.)

### DP vs Other Approaches:
- **Greedy**: Makes locally optimal choice at each step
- **Divide & Conquer**: Subproblems don't overlap
- **DP**: Subproblems overlap, store results

---

## Top-Down Approach (Memoization)

### Fibonacci Sequence
**Problem**: Calculate nth Fibonacci number efficiently.

#### Naive Recursive Approach:
```java
public class Fibonacci {
    
    /**
     * Naive recursive Fibonacci
     * Time: O(2^n), Space: O(n)
     */
    public static int fibonacciNaive(int n) {
        if (n <= 1) return n;
        return fibonacciNaive(n - 1) + fibonacciNaive(n - 2);
    }
}
```

#### Memoized Approach:
```java
public class Fibonacci {
    
    /**
     * Memoized Fibonacci
     * Time: O(n), Space: O(n)
     */
    public static int fibonacciMemo(int n) {
        int[] memo = new int[n + 1];
        Arrays.fill(memo, -1);
        return fibonacciMemoHelper(n, memo);
    }
    
    private static int fibonacciMemoHelper(int n, int[] memo) {
        if (n <= 1) return n;
        
        if (memo[n] != -1) {
            return memo[n]; // Return cached result
        }
        
        memo[n] = fibonacciMemoHelper(n - 1, memo) + fibonacciMemoHelper(n - 2, memo);
        return memo[n];
    }
}
```

### Climbing Stairs
**Problem**: You can climb 1 or 2 steps at a time. How many ways to reach the top?

```java
public class ClimbingStairs {
    
    /**
     * Climbing stairs with memoization
     * Time: O(n), Space: O(n)
     */
    public static int climbStairs(int n) {
        int[] memo = new int[n + 1];
        Arrays.fill(memo, -1);
        return climbStairsHelper(n, memo);
    }
    
    private static int climbStairsHelper(int n, int[] memo) {
        if (n <= 2) return n;
        
        if (memo[n] != -1) {
            return memo[n];
        }
        
        memo[n] = climbStairsHelper(n - 1, memo) + climbStairsHelper(n - 2, memo);
        return memo[n];
    }
}
```

---

## Bottom-Up Approach (Tabulation)

### Fibonacci with Tabulation
```java
public class Fibonacci {
    
    /**
     * Fibonacci with tabulation
     * Time: O(n), Space: O(n)
     */
    public static int fibonacciTab(int n) {
        if (n <= 1) return n;
        
        int[] dp = new int[n + 1];
        dp[0] = 0;
        dp[1] = 1;
        
        for (int i = 2; i <= n; i++) {
            dp[i] = dp[i - 1] + dp[i - 2];
        }
        
        return dp[n];
    }
    
    /**
     * Fibonacci with space optimization
     * Time: O(n), Space: O(1)
     */
    public static int fibonacciOptimized(int n) {
        if (n <= 1) return n;
        
        int prev2 = 0;
        int prev1 = 1;
        
        for (int i = 2; i <= n; i++) {
            int current = prev1 + prev2;
            prev2 = prev1;
            prev1 = current;
        }
        
        return prev1;
    }
}
```

### Climbing Stairs with Tabulation
```java
public class ClimbingStairs {
    
    /**
     * Climbing stairs with tabulation
     * Time: O(n), Space: O(n)
     */
    public static int climbStairsTab(int n) {
        if (n <= 2) return n;
        
        int[] dp = new int[n + 1];
        dp[1] = 1;
        dp[2] = 2;
        
        for (int i = 3; i <= n; i++) {
            dp[i] = dp[i - 1] + dp[i - 2];
        }
        
        return dp[n];
    }
    
    /**
     * Climbing stairs with space optimization
     * Time: O(n), Space: O(1)
     */
    public static int climbStairsOptimized(int n) {
        if (n <= 2) return n;
        
        int prev2 = 1;
        int prev1 = 2;
        
        for (int i = 3; i <= n; i++) {
            int current = prev1 + prev2;
            prev2 = prev1;
            prev1 = current;
        }
        
        return prev1;
    }
}
```

---

## Common DP Patterns

### 1. 1D DP Problems

#### House Robber
**Problem**: Rob houses to maximize money, but can't rob adjacent houses.

```java
public class HouseRobber {
    
    /**
     * House Robber with memoization
     * Time: O(n), Space: O(n)
     */
    public static int rob(int[] nums) {
        int[] memo = new int[nums.length];
        Arrays.fill(memo, -1);
        return robHelper(nums, 0, memo);
    }
    
    private static int robHelper(int[] nums, int index, int[] memo) {
        if (index >= nums.length) return 0;
        
        if (memo[index] != -1) {
            return memo[index];
        }
        
        // Two choices: rob current house or skip it
        int robCurrent = nums[index] + robHelper(nums, index + 2, memo);
        int skipCurrent = robHelper(nums, index + 1, memo);
        
        memo[index] = Math.max(robCurrent, skipCurrent);
        return memo[index];
    }
    
    /**
     * House Robber with tabulation
     * Time: O(n), Space: O(n)
     */
    public static int robTab(int[] nums) {
        if (nums.length == 0) return 0;
        if (nums.length == 1) return nums[0];
        
        int[] dp = new int[nums.length];
        dp[0] = nums[0];
        dp[1] = Math.max(nums[0], nums[1]);
        
        for (int i = 2; i < nums.length; i++) {
            dp[i] = Math.max(dp[i - 1], dp[i - 2] + nums[i]);
        }
        
        return dp[nums.length - 1];
    }
    
    /**
     * House Robber with space optimization
     * Time: O(n), Space: O(1)
     */
    public static int robOptimized(int[] nums) {
        if (nums.length == 0) return 0;
        if (nums.length == 1) return nums[0];
        
        int prev2 = nums[0];
        int prev1 = Math.max(nums[0], nums[1]);
        
        for (int i = 2; i < nums.length; i++) {
            int current = Math.max(prev1, prev2 + nums[i]);
            prev2 = prev1;
            prev1 = current;
        }
        
        return prev1;
    }
}
```

### 2. 2D DP Problems

#### Unique Paths
**Problem**: Find number of unique paths from top-left to bottom-right in a grid.

```java
public class UniquePaths {
    
    /**
     * Unique Paths with memoization
     * Time: O(m × n), Space: O(m × n)
     */
    public static int uniquePaths(int m, int n) {
        int[][] memo = new int[m][n];
        for (int[] row : memo) {
            Arrays.fill(row, -1);
        }
        return uniquePathsHelper(m - 1, n - 1, memo);
    }
    
    private static int uniquePathsHelper(int row, int col, int[][] memo) {
        if (row == 0 || col == 0) return 1;
        
        if (memo[row][col] != -1) {
            return memo[row][col];
        }
        
        memo[row][col] = uniquePathsHelper(row - 1, col, memo) + 
                        uniquePathsHelper(row, col - 1, memo);
        return memo[row][col];
    }
    
    /**
     * Unique Paths with tabulation
     * Time: O(m × n), Space: O(m × n)
     */
    public static int uniquePathsTab(int m, int n) {
        int[][] dp = new int[m][n];
        
        // Initialize first row and column
        for (int i = 0; i < m; i++) {
            dp[i][0] = 1;
        }
        for (int j = 0; j < n; j++) {
            dp[0][j] = 1;
        }
        
        // Fill the rest of the table
        for (int i = 1; i < m; i++) {
            for (int j = 1; j < n; j++) {
                dp[i][j] = dp[i - 1][j] + dp[i][j - 1];
            }
        }
        
        return dp[m - 1][n - 1];
    }
    
    /**
     * Unique Paths with space optimization
     * Time: O(m × n), Space: O(n)
     */
    public static int uniquePathsOptimized(int m, int n) {
        int[] prev = new int[n];
        Arrays.fill(prev, 1);
        
        for (int i = 1; i < m; i++) {
            int[] current = new int[n];
            current[0] = 1;
            
            for (int j = 1; j < n; j++) {
                current[j] = current[j - 1] + prev[j];
            }
            
            prev = current;
        }
        
        return prev[n - 1];
    }
}
```

### 3. Knapsack Problems

#### 0/1 Knapsack
**Problem**: Given items with weights and values, maximize value without exceeding weight limit.

```java
public class Knapsack {
    
    /**
     * 0/1 Knapsack with memoization
     * Time: O(n × W), Space: O(n × W)
     */
    public static int knapsack(int[] weights, int[] values, int capacity) {
        int n = weights.length;
        int[][] memo = new int[n + 1][capacity + 1];
        for (int[] row : memo) {
            Arrays.fill(row, -1);
        }
        return knapsackHelper(weights, values, n, capacity, memo);
    }
    
    private static int knapsackHelper(int[] weights, int[] values, int n, int capacity, int[][] memo) {
        if (n == 0 || capacity == 0) return 0;
        
        if (memo[n][capacity] != -1) {
            return memo[n][capacity];
        }
        
        if (weights[n - 1] > capacity) {
            // Can't include this item
            memo[n][capacity] = knapsackHelper(weights, values, n - 1, capacity, memo);
        } else {
            // Two choices: include or exclude
            int include = values[n - 1] + knapsackHelper(weights, values, n - 1, capacity - weights[n - 1], memo);
            int exclude = knapsackHelper(weights, values, n - 1, capacity, memo);
            memo[n][capacity] = Math.max(include, exclude);
        }
        
        return memo[n][capacity];
    }
    
    /**
     * 0/1 Knapsack with tabulation
     * Time: O(n × W), Space: O(n × W)
     */
    public static int knapsackTab(int[] weights, int[] values, int capacity) {
        int n = weights.length;
        int[][] dp = new int[n + 1][capacity + 1];
        
        for (int i = 1; i <= n; i++) {
            for (int w = 1; w <= capacity; w++) {
                if (weights[i - 1] > w) {
                    dp[i][w] = dp[i - 1][w];
                } else {
                    dp[i][w] = Math.max(dp[i - 1][w], 
                                       values[i - 1] + dp[i - 1][w - weights[i - 1]]);
                }
            }
        }
        
        return dp[n][capacity];
    }
}
```

### 4. Longest Common Subsequence (LCS)
**Problem**: Find the length of the longest subsequence common to both strings.

```java
public class LongestCommonSubsequence {
    
    /**
     * LCS with memoization
     * Time: O(m × n), Space: O(m × n)
     */
    public static int lcs(String text1, String text2) {
        int m = text1.length();
        int n = text2.length();
        int[][] memo = new int[m + 1][n + 1];
        for (int[] row : memo) {
            Arrays.fill(row, -1);
        }
        return lcsHelper(text1, text2, m, n, memo);
    }
    
    private static int lcsHelper(String text1, String text2, int m, int n, int[][] memo) {
        if (m == 0 || n == 0) return 0;
        
        if (memo[m][n] != -1) {
            return memo[m][n];
        }
        
        if (text1.charAt(m - 1) == text2.charAt(n - 1)) {
            memo[m][n] = 1 + lcsHelper(text1, text2, m - 1, n - 1, memo);
        } else {
            memo[m][n] = Math.max(lcsHelper(text1, text2, m - 1, n, memo),
                                 lcsHelper(text1, text2, m, n - 1, memo));
        }
        
        return memo[m][n];
    }
    
    /**
     * LCS with tabulation
     * Time: O(m × n), Space: O(m × n)
     */
    public static int lcsTab(String text1, String text2) {
        int m = text1.length();
        int n = text2.length();
        int[][] dp = new int[m + 1][n + 1];
        
        for (int i = 1; i <= m; i++) {
            for (int j = 1; j <= n; j++) {
                if (text1.charAt(i - 1) == text2.charAt(j - 1)) {
                    dp[i][j] = 1 + dp[i - 1][j - 1];
                } else {
                    dp[i][j] = Math.max(dp[i - 1][j], dp[i][j - 1]);
                }
            }
        }
        
        return dp[m][n];
    }
}
```

---

## Advanced DP Techniques

### 1. State Machine DP

#### Buy and Sell Stock
**Problem**: Buy and sell stock to maximize profit with transaction restrictions.

```java
public class BuySellStock {
    
    /**
     * Buy and Sell Stock I - One transaction
     * Time: O(n), Space: O(1)
     */
    public static int maxProfit(int[] prices) {
        int minPrice = Integer.MAX_VALUE;
        int maxProfit = 0;
        
        for (int price : prices) {
            minPrice = Math.min(minPrice, price);
            maxProfit = Math.max(maxProfit, price - minPrice);
        }
        
        return maxProfit;
    }
    
    /**
     * Buy and Sell Stock II - Unlimited transactions
     * Time: O(n), Space: O(1)
     */
    public static int maxProfitII(int[] prices) {
        int profit = 0;
        
        for (int i = 1; i < prices.length; i++) {
            if (prices[i] > prices[i - 1]) {
                profit += prices[i] - prices[i - 1];
            }
        }
        
        return profit;
    }
    
    /**
     * Buy and Sell Stock III - At most 2 transactions
     * Time: O(n), Space: O(1)
     */
    public static int maxProfitIII(int[] prices) {
        int buy1 = Integer.MAX_VALUE;
        int sell1 = 0;
        int buy2 = Integer.MAX_VALUE;
        int sell2 = 0;
        
        for (int price : prices) {
            buy1 = Math.min(buy1, price);
            sell1 = Math.max(sell1, price - buy1);
            buy2 = Math.min(buy2, price - sell1);
            sell2 = Math.max(sell2, price - buy2);
        }
        
        return sell2;
    }
}
```

### 2. Interval DP

#### Matrix Chain Multiplication
**Problem**: Find the minimum number of multiplications needed to multiply a chain of matrices.

```java
public class MatrixChainMultiplication {
    
    /**
     * Matrix Chain Multiplication with memoization
     * Time: O(n³), Space: O(n²)
     */
    public static int matrixChainOrder(int[] dimensions) {
        int n = dimensions.length - 1;
        int[][] memo = new int[n + 1][n + 1];
        for (int[] row : memo) {
            Arrays.fill(row, -1);
        }
        return matrixChainHelper(dimensions, 1, n, memo);
    }
    
    private static int matrixChainHelper(int[] dimensions, int i, int j, int[][] memo) {
        if (i == j) return 0;
        
        if (memo[i][j] != -1) {
            return memo[i][j];
        }
        
        int minCost = Integer.MAX_VALUE;
        
        for (int k = i; k < j; k++) {
            int cost = matrixChainHelper(dimensions, i, k, memo) +
                      matrixChainHelper(dimensions, k + 1, j, memo) +
                      dimensions[i - 1] * dimensions[k] * dimensions[j];
            
            minCost = Math.min(minCost, cost);
        }
        
        memo[i][j] = minCost;
        return minCost;
    }
}
```

### 3. Digit DP

#### Count Numbers with Unique Digits
**Problem**: Count numbers with unique digits in a given range.

```java
public class DigitDP {
    
    /**
     * Count numbers with unique digits
     * Time: O(n), Space: O(n)
     */
    public static int countNumbersWithUniqueDigits(int n) {
        if (n == 0) return 1;
        
        int[] dp = new int[n + 1];
        dp[0] = 1;
        dp[1] = 10;
        
        for (int i = 2; i <= n; i++) {
            dp[i] = dp[i - 1] * (10 - i + 1);
        }
        
        int result = 0;
        for (int i = 0; i <= n; i++) {
            result += dp[i];
        }
        
        return result;
    }
}
```

---

## 🎯 DP Problem Patterns

### 1. 1D DP Patterns:
- **Fibonacci**: `dp[i] = dp[i-1] + dp[i-2]`
- **House Robber**: `dp[i] = max(dp[i-1], dp[i-2] + nums[i])`
- **Climbing Stairs**: `dp[i] = dp[i-1] + dp[i-2]`

### 2. 2D DP Patterns:
- **Unique Paths**: `dp[i][j] = dp[i-1][j] + dp[i][j-1]`
- **LCS**: `dp[i][j] = dp[i-1][j-1] + 1` if match, else `max(dp[i-1][j], dp[i][j-1])`
- **Edit Distance**: `dp[i][j] = min(dp[i-1][j], dp[i][j-1], dp[i-1][j-1]) + 1`

### 3. Knapsack Patterns:
- **0/1 Knapsack**: `dp[i][w] = max(dp[i-1][w], dp[i-1][w-wt[i]] + val[i])`
- **Unbounded Knapsack**: `dp[w] = max(dp[w], dp[w-wt[i]] + val[i])`

### 4. State Machine Patterns:
- **Buy/Sell Stock**: Track states (hold, sold, cooldown)
- **House Robber**: Track states (rob, don't rob)

---

## 🏋️ Exercises

### Exercise 1: Fibonacci with DP ⭐
Implement Fibonacci using both memoization and tabulation.

### Exercise 2: Climbing Stairs ⭐
Find number of ways to climb n stairs with 1 or 2 steps.

### Exercise 3: House Robber ⭐⭐
Maximize money robbed without robbing adjacent houses.

### Exercise 4: Unique Paths ⭐⭐
Find number of unique paths in a grid from top-left to bottom-right.

### Exercise 5: 0/1 Knapsack ⭐⭐
Maximize value in knapsack without exceeding weight limit.

### Exercise 6: Longest Common Subsequence ⭐⭐
Find length of longest common subsequence between two strings.

### Exercise 7: Edit Distance ⭐⭐⭐
Find minimum operations to convert one string to another.

### Exercise 8: Buy and Sell Stock ⭐⭐
Maximize profit from buying and selling stocks with various constraints.

---

## 🎓 Interview Tips

1. **Identify DP problems**:
   - Look for optimization problems
   - Check for overlapping subproblems
   - Verify optimal substructure

2. **Choose the right approach**:
   - Top-down for natural recursion
   - Bottom-up for space optimization
   - Consider space-time trade-offs

3. **State definition**:
   - Define what dp[i] represents
   - Choose appropriate dimensions
   - Consider state transitions

4. **Base cases**:
   - Handle edge cases carefully
   - Initialize DP table correctly
   - Set up boundary conditions

5. **Optimization**:
   - Look for space optimization opportunities
   - Consider rolling array technique
   - Analyze time complexity improvements

---

## 🚀 What's Next?

You've mastered dynamic programming! Next, we'll explore:
- [Graph Algorithms](02-graph-algorithms.md) - Traversing and analyzing graphs
- [Greedy Algorithms](03-greedy.md) - Making locally optimal choices
- [Backtracking](04-backtracking.md) - Exploring all possible solutions

Remember: **DP is about recognizing patterns and building solutions incrementally!** Practice identifying the right subproblems and you'll be ready for any DP problem.

---

*"Dynamic Programming is just a fancy way to say 'remembering stuff to save time later'." - Computer Science Wisdom*
