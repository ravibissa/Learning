/**
 * Complete Dynamic Programming Implementation
 * 
 * This class contains implementations of major dynamic programming problems
 * with both memoization and tabulation approaches.
 * 
 * @author DSA Tutorial
 * @version 1.0
 */
import java.util.*;

public class DynamicProgramming {
    
    /**
     * Fibonacci with memoization
     * Time: O(n), Space: O(n)
     */
    public static int fibonacciMemo(int n) {
        int[] memo = new int[n + 1];
        Arrays.fill(memo, -1);
        return fibonacciMemoHelper(n, memo);
    }
    
    private static int fibonacciMemoHelper(int n, int[] memo) {
        if (n <= 1) return n;
        
        if (memo[n] != -1) {
            return memo[n];
        }
        
        memo[n] = fibonacciMemoHelper(n - 1, memo) + fibonacciMemoHelper(n - 2, memo);
        return memo[n];
    }
    
    /**
     * Fibonacci with tabulation
     * Time: O(n), Space: O(n)
     */
    public static int fibonacciTab(int n) {
        if (n <= 1) return n;
        
        int[] dp = new int[n + 1];
        dp[0] = 0;
        dp[1] = 1;
        
        for (int i = 2; i <= n; i++) {
            dp[i] = dp[i - 1] + dp[i - 2];
        }
        
        return dp[n];
    }
    
    /**
     * Fibonacci with space optimization
     * Time: O(n), Space: O(1)
     */
    public static int fibonacciOptimized(int n) {
        if (n <= 1) return n;
        
        int prev2 = 0;
        int prev1 = 1;
        
        for (int i = 2; i <= n; i++) {
            int current = prev1 + prev2;
            prev2 = prev1;
            prev1 = current;
        }
        
        return prev1;
    }
    
    /**
     * Climbing stairs with memoization
     * Time: O(n), Space: O(n)
     */
    public static int climbStairs(int n) {
        int[] memo = new int[n + 1];
        Arrays.fill(memo, -1);
        return climbStairsHelper(n, memo);
    }
    
    private static int climbStairsHelper(int n, int[] memo) {
        if (n <= 2) return n;
        
        if (memo[n] != -1) {
            return memo[n];
        }
        
        memo[n] = climbStairsHelper(n - 1, memo) + climbStairsHelper(n - 2, memo);
        return memo[n];
    }
    
    /**
     * Climbing stairs with tabulation
     * Time: O(n), Space: O(n)
     */
    public static int climbStairsTab(int n) {
        if (n <= 2) return n;
        
        int[] dp = new int[n + 1];
        dp[1] = 1;
        dp[2] = 2;
        
        for (int i = 3; i <= n; i++) {
            dp[i] = dp[i - 1] + dp[i - 2];
        }
        
        return dp[n];
    }
    
    /**
     * Climbing stairs with space optimization
     * Time: O(n), Space: O(1)
     */
    public static int climbStairsOptimized(int n) {
        if (n <= 2) return n;
        
        int prev2 = 1;
        int prev1 = 2;
        
        for (int i = 3; i <= n; i++) {
            int current = prev1 + prev2;
            prev2 = prev1;
            prev1 = current;
        }
        
        return prev1;
    }
    
    /**
     * House Robber with memoization
     * Time: O(n), Space: O(n)
     */
    public static int rob(int[] nums) {
        int[] memo = new int[nums.length];
        Arrays.fill(memo, -1);
        return robHelper(nums, 0, memo);
    }
    
    private static int robHelper(int[] nums, int index, int[] memo) {
        if (index >= nums.length) return 0;
        
        if (memo[index] != -1) {
            return memo[index];
        }
        
        int robCurrent = nums[index] + robHelper(nums, index + 2, memo);
        int skipCurrent = robHelper(nums, index + 1, memo);
        
        memo[index] = Math.max(robCurrent, skipCurrent);
        return memo[index];
    }
    
    /**
     * House Robber with tabulation
     * Time: O(n), Space: O(n)
     */
    public static int robTab(int[] nums) {
        if (nums.length == 0) return 0;
        if (nums.length == 1) return nums[0];
        
        int[] dp = new int[nums.length];
        dp[0] = nums[0];
        dp[1] = Math.max(nums[0], nums[1]);
        
        for (int i = 2; i < nums.length; i++) {
            dp[i] = Math.max(dp[i - 1], dp[i - 2] + nums[i]);
        }
        
        return dp[nums.length - 1];
    }
    
    /**
     * House Robber with space optimization
     * Time: O(n), Space: O(1)
     */
    public static int robOptimized(int[] nums) {
        if (nums.length == 0) return 0;
        if (nums.length == 1) return nums[0];
        
        int prev2 = nums[0];
        int prev1 = Math.max(nums[0], nums[1]);
        
        for (int i = 2; i < nums.length; i++) {
            int current = Math.max(prev1, prev2 + nums[i]);
            prev2 = prev1;
            prev1 = current;
        }
        
        return prev1;
    }
    
    /**
     * Unique Paths with memoization
     * Time: O(m × n), Space: O(m × n)
     */
    public static int uniquePaths(int m, int n) {
        int[][] memo = new int[m][n];
        for (int[] row : memo) {
            Arrays.fill(row, -1);
        }
        return uniquePathsHelper(m - 1, n - 1, memo);
    }
    
    private static int uniquePathsHelper(int row, int col, int[][] memo) {
        if (row == 0 || col == 0) return 1;
        
        if (memo[row][col] != -1) {
            return memo[row][col];
        }
        
        memo[row][col] = uniquePathsHelper(row - 1, col, memo) + 
                        uniquePathsHelper(row, col - 1, memo);
        return memo[row][col];
    }
    
    /**
     * Unique Paths with tabulation
     * Time: O(m × n), Space: O(m × n)
     */
    public static int uniquePathsTab(int m, int n) {
        int[][] dp = new int[m][n];
        
        for (int i = 0; i < m; i++) {
            dp[i][0] = 1;
        }
        for (int j = 0; j < n; j++) {
            dp[0][j] = 1;
        }
        
        for (int i = 1; i < m; i++) {
            for (int j = 1; j < n; j++) {
                dp[i][j] = dp[i - 1][j] + dp[i][j - 1];
            }
        }
        
        return dp[m - 1][n - 1];
    }
    
    /**
     * Unique Paths with space optimization
     * Time: O(m × n), Space: O(n)
     */
    public static int uniquePathsOptimized(int m, int n) {
        int[] prev = new int[n];
        Arrays.fill(prev, 1);
        
        for (int i = 1; i < m; i++) {
            int[] current = new int[n];
            current[0] = 1;
            
            for (int j = 1; j < n; j++) {
                current[j] = current[j - 1] + prev[j];
            }
            
            prev = current;
        }
        
        return prev[n - 1];
    }
    
    /**
     * 0/1 Knapsack with memoization
     * Time: O(n × W), Space: O(n × W)
     */
    public static int knapsack(int[] weights, int[] values, int capacity) {
        int n = weights.length;
        int[][] memo = new int[n + 1][capacity + 1];
        for (int[] row : memo) {
            Arrays.fill(row, -1);
        }
        return knapsackHelper(weights, values, n, capacity, memo);
    }
    
    private static int knapsackHelper(int[] weights, int[] values, int n, int capacity, int[][] memo) {
        if (n == 0 || capacity == 0) return 0;
        
        if (memo[n][capacity] != -1) {
            return memo[n][capacity];
        }
        
        if (weights[n - 1] > capacity) {
            memo[n][capacity] = knapsackHelper(weights, values, n - 1, capacity, memo);
        } else {
            int include = values[n - 1] + knapsackHelper(weights, values, n - 1, capacity - weights[n - 1], memo);
            int exclude = knapsackHelper(weights, values, n - 1, capacity, memo);
            memo[n][capacity] = Math.max(include, exclude);
        }
        
        return memo[n][capacity];
    }
    
    /**
     * 0/1 Knapsack with tabulation
     * Time: O(n × W), Space: O(n × W)
     */
    public static int knapsackTab(int[] weights, int[] values, int capacity) {
        int n = weights.length;
        int[][] dp = new int[n + 1][capacity + 1];
        
        for (int i = 1; i <= n; i++) {
            for (int w = 1; w <= capacity; w++) {
                if (weights[i - 1] > w) {
                    dp[i][w] = dp[i - 1][w];
                } else {
                    dp[i][w] = Math.max(dp[i - 1][w], 
                                       values[i - 1] + dp[i - 1][w - weights[i - 1]]);
                }
            }
        }
        
        return dp[n][capacity];
    }
    
    /**
     * Longest Common Subsequence with memoization
     * Time: O(m × n), Space: O(m × n)
     */
    public static int lcs(String text1, String text2) {
        int m = text1.length();
        int n = text2.length();
        int[][] memo = new int[m + 1][n + 1];
        for (int[] row : memo) {
            Arrays.fill(row, -1);
        }
        return lcsHelper(text1, text2, m, n, memo);
    }
    
    private static int lcsHelper(String text1, String text2, int m, int n, int[][] memo) {
        if (m == 0 || n == 0) return 0;
        
        if (memo[m][n] != -1) {
            return memo[m][n];
        }
        
        if (text1.charAt(m - 1) == text2.charAt(n - 1)) {
            memo[m][n] = 1 + lcsHelper(text1, text2, m - 1, n - 1, memo);
        } else {
            memo[m][n] = Math.max(lcsHelper(text1, text2, m - 1, n, memo),
                                 lcsHelper(text1, text2, m, n - 1, memo));
        }
        
        return memo[m][n];
    }
    
    /**
     * Longest Common Subsequence with tabulation
     * Time: O(m × n), Space: O(m × n)
     */
    public static int lcsTab(String text1, String text2) {
        int m = text1.length();
        int n = text2.length();
        int[][] dp = new int[m + 1][n + 1];
        
        for (int i = 1; i <= m; i++) {
            for (int j = 1; j <= n; j++) {
                if (text1.charAt(i - 1) == text2.charAt(j - 1)) {
                    dp[i][j] = 1 + dp[i - 1][j - 1];
                } else {
                    dp[i][j] = Math.max(dp[i - 1][j], dp[i][j - 1]);
                }
            }
        }
        
        return dp[m][n];
    }
    
    /**
     * Edit Distance with memoization
     * Time: O(m × n), Space: O(m × n)
     */
    public static int editDistance(String word1, String word2) {
        int m = word1.length();
        int n = word2.length();
        int[][] memo = new int[m + 1][n + 1];
        for (int[] row : memo) {
            Arrays.fill(row, -1);
        }
        return editDistanceHelper(word1, word2, m, n, memo);
    }
    
    private static int editDistanceHelper(String word1, String word2, int m, int n, int[][] memo) {
        if (m == 0) return n;
        if (n == 0) return m;
        
        if (memo[m][n] != -1) {
            return memo[m][n];
        }
        
        if (word1.charAt(m - 1) == word2.charAt(n - 1)) {
            memo[m][n] = editDistanceHelper(word1, word2, m - 1, n - 1, memo);
        } else {
            memo[m][n] = 1 + Math.min(
                editDistanceHelper(word1, word2, m - 1, n, memo),     // Delete
                Math.min(
                    editDistanceHelper(word1, word2, m, n - 1, memo), // Insert
                    editDistanceHelper(word1, word2, m - 1, n - 1, memo) // Replace
                )
            );
        }
        
        return memo[m][n];
    }
    
    /**
     * Edit Distance with tabulation
     * Time: O(m × n), Space: O(m × n)
     */
    public static int editDistanceTab(String word1, String word2) {
        int m = word1.length();
        int n = word2.length();
        int[][] dp = new int[m + 1][n + 1];
        
        for (int i = 0; i <= m; i++) {
            dp[i][0] = i;
        }
        for (int j = 0; j <= n; j++) {
            dp[0][j] = j;
        }
        
        for (int i = 1; i <= m; i++) {
            for (int j = 1; j <= n; j++) {
                if (word1.charAt(i - 1) == word2.charAt(j - 1)) {
                    dp[i][j] = dp[i - 1][j - 1];
                } else {
                    dp[i][j] = 1 + Math.min(dp[i - 1][j], Math.min(dp[i][j - 1], dp[i - 1][j - 1]));
                }
            }
        }
        
        return dp[m][n];
    }
    
    /**
     * Buy and Sell Stock I - One transaction
     * Time: O(n), Space: O(1)
     */
    public static int maxProfit(int[] prices) {
        int minPrice = Integer.MAX_VALUE;
        int maxProfit = 0;
        
        for (int price : prices) {
            minPrice = Math.min(minPrice, price);
            maxProfit = Math.max(maxProfit, price - minPrice);
        }
        
        return maxProfit;
    }
    
    /**
     * Buy and Sell Stock II - Unlimited transactions
     * Time: O(n), Space: O(1)
     */
    public static int maxProfitII(int[] prices) {
        int profit = 0;
        
        for (int i = 1; i < prices.length; i++) {
            if (prices[i] > prices[i - 1]) {
                profit += prices[i] - prices[i - 1];
            }
        }
        
        return profit;
    }
    
    /**
     * Buy and Sell Stock III - At most 2 transactions
     * Time: O(n), Space: O(1)
     */
    public static int maxProfitIII(int[] prices) {
        int buy1 = Integer.MAX_VALUE;
        int sell1 = 0;
        int buy2 = Integer.MAX_VALUE;
        int sell2 = 0;
        
        for (int price : prices) {
            buy1 = Math.min(buy1, price);
            sell1 = Math.max(sell1, price - buy1);
            buy2 = Math.min(buy2, price - sell1);
            sell2 = Math.max(sell2, price - buy2);
        }
        
        return sell2;
    }
    
    /**
     * Coin Change - Minimum number of coins
     * Time: O(amount × coins), Space: O(amount)
     */
    public static int coinChange(int[] coins, int amount) {
        int[] dp = new int[amount + 1];
        Arrays.fill(dp, amount + 1);
        dp[0] = 0;
        
        for (int i = 1; i <= amount; i++) {
            for (int coin : coins) {
                if (coin <= i) {
                    dp[i] = Math.min(dp[i], dp[i - coin] + 1);
                }
            }
        }
        
        return dp[amount] > amount ? -1 : dp[amount];
    }
    
    /**
     * Longest Increasing Subsequence
     * Time: O(n²), Space: O(n)
     */
    public static int lengthOfLIS(int[] nums) {
        if (nums.length == 0) return 0;
        
        int[] dp = new int[nums.length];
        Arrays.fill(dp, 1);
        
        for (int i = 1; i < nums.length; i++) {
            for (int j = 0; j < i; j++) {
                if (nums[j] < nums[i]) {
                    dp[i] = Math.max(dp[i], dp[j] + 1);
                }
            }
        }
        
        return Arrays.stream(dp).max().getAsInt();
    }
    
    /**
     * Word Break
     * Time: O(n²), Space: O(n)
     */
    public static boolean wordBreak(String s, List<String> wordDict) {
        Set<String> wordSet = new HashSet<>(wordDict);
        boolean[] dp = new boolean[s.length() + 1];
        dp[0] = true;
        
        for (int i = 1; i <= s.length(); i++) {
            for (int j = 0; j < i; j++) {
                if (dp[j] && wordSet.contains(s.substring(j, i))) {
                    dp[i] = true;
                    break;
                }
            }
        }
        
        return dp[s.length()];
    }
    
    public static void main(String[] args) {
        System.out.println("=== Dynamic Programming Demo ===\n");
        
        // Test Fibonacci
        System.out.println("1. Fibonacci Sequence:");
        int n = 10;
        System.out.println("Fibonacci(" + n + ") with memoization: " + fibonacciMemo(n));
        System.out.println("Fibonacci(" + n + ") with tabulation: " + fibonacciTab(n));
        System.out.println("Fibonacci(" + n + ") optimized: " + fibonacciOptimized(n));
        System.out.println();
        
        // Test Climbing Stairs
        System.out.println("2. Climbing Stairs:");
        int stairs = 5;
        System.out.println("Ways to climb " + stairs + " stairs (memo): " + climbStairs(stairs));
        System.out.println("Ways to climb " + stairs + " stairs (tab): " + climbStairsTab(stairs));
        System.out.println("Ways to climb " + stairs + " stairs (opt): " + climbStairsOptimized(stairs));
        System.out.println();
        
        // Test House Robber
        System.out.println("3. House Robber:");
        int[] houses = {2, 7, 9, 3, 1};
        System.out.println("Houses: " + Arrays.toString(houses));
        System.out.println("Max money (memo): " + rob(houses));
        System.out.println("Max money (tab): " + robTab(houses));
        System.out.println("Max money (opt): " + robOptimized(houses));
        System.out.println();
        
        // Test Unique Paths
        System.out.println("4. Unique Paths:");
        int m = 3, n = 3;
        System.out.println("Unique paths in " + m + "x" + n + " grid (memo): " + uniquePaths(m, n));
        System.out.println("Unique paths in " + m + "x" + n + " grid (tab): " + uniquePathsTab(m, n));
        System.out.println("Unique paths in " + m + "x" + n + " grid (opt): " + uniquePathsOptimized(m, n));
        System.out.println();
        
        // Test Knapsack
        System.out.println("5. 0/1 Knapsack:");
        int[] weights = {1, 3, 4, 5};
        int[] values = {1, 4, 5, 7};
        int capacity = 7;
        System.out.println("Weights: " + Arrays.toString(weights));
        System.out.println("Values: " + Arrays.toString(values));
        System.out.println("Capacity: " + capacity);
        System.out.println("Max value (memo): " + knapsack(weights, values, capacity));
        System.out.println("Max value (tab): " + knapsackTab(weights, values, capacity));
        System.out.println();
        
        // Test LCS
        System.out.println("6. Longest Common Subsequence:");
        String text1 = "ABCDGH";
        String text2 = "AEDFHR";
        System.out.println("Text1: " + text1);
        System.out.println("Text2: " + text2);
        System.out.println("LCS length (memo): " + lcs(text1, text2));
        System.out.println("LCS length (tab): " + lcsTab(text1, text2));
        System.out.println();
        
        // Test Edit Distance
        System.out.println("7. Edit Distance:");
        String word1 = "kitten";
        String word2 = "sitting";
        System.out.println("Word1: " + word1);
        System.out.println("Word2: " + word2);
        System.out.println("Edit distance (memo): " + editDistance(word1, word2));
        System.out.println("Edit distance (tab): " + editDistanceTab(word1, word2));
        System.out.println();
        
        // Test Buy and Sell Stock
        System.out.println("8. Buy and Sell Stock:");
        int[] prices = {7, 1, 5, 3, 6, 4};
        System.out.println("Prices: " + Arrays.toString(prices));
        System.out.println("Max profit (1 transaction): " + maxProfit(prices));
        System.out.println("Max profit (unlimited): " + maxProfitII(prices));
        System.out.println("Max profit (2 transactions): " + maxProfitIII(prices));
        System.out.println();
        
        // Test Coin Change
        System.out.println("9. Coin Change:");
        int[] coins = {1, 3, 4};
        int amount = 6;
        System.out.println("Coins: " + Arrays.toString(coins));
        System.out.println("Amount: " + amount);
        System.out.println("Min coins needed: " + coinChange(coins, amount));
        System.out.println();
        
        // Test LIS
        System.out.println("10. Longest Increasing Subsequence:");
        int[] nums = {10, 9, 2, 5, 3, 7, 101, 18};
        System.out.println("Array: " + Arrays.toString(nums));
        System.out.println("LIS length: " + lengthOfLIS(nums));
        System.out.println();
        
        // Test Word Break
        System.out.println("11. Word Break:");
        String s = "leetcode";
        List<String> wordDict = Arrays.asList("leet", "code");
        System.out.println("String: " + s);
        System.out.println("Word dict: " + wordDict);
        System.out.println("Can be segmented: " + wordBreak(s, wordDict));
        System.out.println();
        
        System.out.println("=== DP Summary ===");
        System.out.println("• Memoization: Top-down approach, natural recursion");
        System.out.println("• Tabulation: Bottom-up approach, iterative");
        System.out.println("• Space optimization: Reduce space complexity");
        System.out.println("• Key patterns: 1D DP, 2D DP, Knapsack, LCS, Edit Distance");
        System.out.println("• Choose approach based on problem requirements");
    }
}
