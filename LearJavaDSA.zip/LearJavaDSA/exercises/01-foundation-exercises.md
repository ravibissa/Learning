# Foundation Exercises
## Practice Problems for Java Basics

These exercises will help you master the fundamentals before moving to advanced data structures and algorithms.

## 🎯 Exercise Guidelines
- **Time yourself**: Aim to solve each problem in 15-30 minutes
- **Think out loud**: Explain your approach before coding
- **Test thoroughly**: Use different test cases
- **Optimize**: Consider time and space complexity

---

## Exercise 1: Array Reversal ⭐
**Difficulty**: Easy  
**Time Limit**: 15 minutes

Write a method to reverse an array **in-place** (without using extra space).

### Requirements:
- Don't create a new array
- Modify the original array
- Handle edge cases (empty array, single element)

### Method Signature:
```java
public static void reverseArray(int[] arr)
```

### Test Cases:
```java
// Test 1: Normal case
int[] arr1 = {1, 2, 3, 4, 5};
reverseArray(arr1);
// Expected: [5, 4, 3, 2, 1]

// Test 2: Empty array
int[] arr2 = {};
reverseArray(arr2);
// Expected: []

// Test 3: Single element
int[] arr3 = {42};
reverseArray(arr3);
// Expected: [42]
```

### Hint:
Use two pointers - one at the beginning, one at the end. Swap elements and move pointers towards the center.

---

## Exercise 2: Find Second Largest ⭐
**Difficulty**: Easy  
**Time Limit**: 20 minutes

Write a method to find the second largest element in an array.

### Requirements:
- Handle arrays with less than 2 elements
- Handle arrays with all same elements
- Return -1 if no second largest exists

### Method Signature:
```java
public static int findSecondLargest(int[] arr)
```

### Test Cases:
```java
// Test 1: Normal case
int[] arr1 = {3, 7, 2, 9, 1};
// Expected: 7

// Test 2: All same elements
int[] arr2 = {5, 5, 5, 5};
// Expected: -1

// Test 3: Less than 2 elements
int[] arr3 = {42};
// Expected: -1
```

### Hint:
Keep track of both largest and second largest as you iterate through the array.

---

## Exercise 3: Remove Duplicates ⭐⭐
**Difficulty**: Medium  
**Time Limit**: 25 minutes

Write a method to remove duplicates from a **sorted** array and return the new length.

### Requirements:
- Don't use extra space (modify array in-place)
- Return the new length of the array
- The array is already sorted

### Method Signature:
```java
public static int removeDuplicates(int[] arr)
```

### Test Cases:
```java
// Test 1: Normal case
int[] arr1 = {1, 1, 2, 2, 3, 4, 4, 5};
int newLength = removeDuplicates(arr1);
// Expected: newLength = 5, arr1 = [1, 2, 3, 4, 5, ?, ?, ?]

// Test 2: No duplicates
int[] arr2 = {1, 2, 3, 4, 5};
int newLength2 = removeDuplicates(arr2);
// Expected: newLength2 = 5, arr2 unchanged

// Test 3: All same elements
int[] arr3 = {7, 7, 7, 7};
int newLength3 = removeDuplicates(arr3);
// Expected: newLength3 = 1, arr3 = [7, ?, ?, ?]
```

### Hint:
Use two pointers - one for reading, one for writing. Only write when you find a new unique element.

---

## Exercise 4: Two Sum ⭐⭐
**Difficulty**: Medium  
**Time Limit**: 30 minutes

Given an array of integers and a target sum, find two numbers that add up to the target.

### Requirements:
- Return indices of the two numbers
- You may not use the same element twice
- Return {-1, -1} if no solution exists
- Assume exactly one solution exists

### Method Signature:
```java
public static int[] twoSum(int[] nums, int target)
```

### Test Cases:
```java
// Test 1: Normal case
int[] nums1 = {2, 7, 11, 15};
int[] result1 = twoSum(nums1, 9);
// Expected: [0, 1] (because nums[0] + nums[1] = 2 + 7 = 9)

// Test 2: Different target
int[] nums2 = {3, 2, 4};
int[] result2 = twoSum(nums2, 6);
// Expected: [1, 2] (because nums[1] + nums[2] = 2 + 4 = 6)

// Test 3: Same numbers
int[] nums3 = {3, 3};
int[] result3 = twoSum(nums3, 6);
// Expected: [0, 1]
```

### Hint:
Use nested loops for O(n²) solution, or HashMap for O(n) solution.

---

## Exercise 5: Fibonacci Sequence ⭐
**Difficulty**: Easy  
**Time Limit**: 20 minutes

Write a method to generate the first n Fibonacci numbers.

### Requirements:
- Return an array of Fibonacci numbers
- Handle edge cases (n = 0, n = 1)
- Use iterative approach (not recursive)

### Method Signature:
```java
public static int[] generateFibonacci(int n)
```

### Test Cases:
```java
// Test 1: Normal case
int[] fib1 = generateFibonacci(7);
// Expected: [0, 1, 1, 2, 3, 5, 8]

// Test 2: Edge case
int[] fib2 = generateFibonacci(1);
// Expected: [0]

// Test 3: Edge case
int[] fib3 = generateFibonacci(0);
// Expected: []
```

### Hint:
Each number is the sum of the two preceding ones. Start with [0, 1] and build up.

---

## Exercise 6: Check Palindrome ⭐
**Difficulty**: Easy  
**Time Limit**: 15 minutes

Write a method to check if a string is a palindrome (reads the same forwards and backwards).

### Requirements:
- Ignore case differences
- Ignore non-alphanumeric characters
- Return true if palindrome, false otherwise

### Method Signature:
```java
public static boolean isPalindrome(String s)
```

### Test Cases:
```java
// Test 1: Simple palindrome
boolean result1 = isPalindrome("racecar");
// Expected: true

// Test 2: With spaces and punctuation
boolean result2 = isPalindrome("A man, a plan, a canal: Panama");
// Expected: true

// Test 3: Not a palindrome
boolean result3 = isPalindrome("hello");
// Expected: false
```

### Hint:
Use two pointers from both ends, skip non-alphanumeric characters, compare characters (case-insensitive).

---

## Exercise 7: Find Peak Element ⭐⭐
**Difficulty**: Medium  
**Time Limit**: 25 minutes

A peak element is an element that is greater than or equal to its neighbors. Find any peak element in an array.

### Requirements:
- Array may contain multiple peaks
- Return the index of any peak
- Handle edge cases (single element, two elements)
- Assume nums[-1] = nums[n] = -∞

### Method Signature:
```java
public static int findPeakElement(int[] nums)
```

### Test Cases:
```java
// Test 1: Normal case
int[] nums1 = {1, 2, 3, 1};
int peak1 = findPeakElement(nums1);
// Expected: 2 (index of element 3)

// Test 2: Multiple peaks
int[] nums2 = {1, 2, 1, 3, 5, 6, 4};
int peak2 = findPeakElement(nums2);
// Expected: 1 or 5 (indices of peaks 2 or 6)

// Test 3: Single element
int[] nums3 = {42};
int peak3 = findPeakElement(nums3);
// Expected: 0
```

### Hint:
You can use linear search O(n) or binary search O(log n). For this exercise, use linear search.

---

## Exercise 8: Rotate Array ⭐⭐
**Difficulty**: Medium  
**Time Limit**: 30 minutes

Given an array, rotate it to the right by k steps.

### Requirements:
- Rotate in-place (don't use extra space)
- Handle k > array length
- Handle edge cases (empty array, k = 0)

### Method Signature:
```java
public static void rotateArray(int[] nums, int k)
```

### Test Cases:
```java
// Test 1: Normal case
int[] nums1 = {1, 2, 3, 4, 5, 6, 7};
rotateArray(nums1, 3);
// Expected: [5, 6, 7, 1, 2, 3, 4]

// Test 2: k > array length
int[] nums2 = {1, 2};
rotateArray(nums2, 3);
// Expected: [2, 1] (because 3 % 2 = 1)

// Test 3: k = 0
int[] nums3 = {1, 2, 3};
rotateArray(nums3, 0);
// Expected: [1, 2, 3] (unchanged)
```

### Hint:
Use array reversal technique: reverse entire array, then reverse first k elements, then reverse remaining elements.

---

## 🎯 Bonus Challenges

### Challenge 1: Maximum Subarray Sum (Kadane's Algorithm) ⭐⭐⭐
Find the contiguous subarray with maximum sum.

### Challenge 2: Product of Array Except Self ⭐⭐⭐
Given an array, return an array where each element is the product of all other elements.

### Challenge 3: Container With Most Water ⭐⭐⭐
Find two lines that together with the x-axis forms a container that holds the most water.

---

## 📊 Progress Tracking

| Exercise | Status | Time Taken | Notes |
|----------|--------|------------|-------|
| Array Reversal | ⬜ | ___ min | |
| Find Second Largest | ⬜ | ___ min | |
| Remove Duplicates | ⬜ | ___ min | |
| Two Sum | ⬜ | ___ min | |
| Fibonacci Sequence | ⬜ | ___ min | |
| Check Palindrome | ⬜ | ___ min | |
| Find Peak Element | ⬜ | ___ min | |
| Rotate Array | ⬜ | ___ min | |

---

## 🎓 Interview Tips

1. **Always start with examples**: Walk through test cases
2. **Think about edge cases**: Empty arrays, single elements, duplicates
3. **Discuss complexity**: Time and space complexity
4. **Optimize if time permits**: Start with brute force, then optimize
5. **Test your solution**: Walk through your code with examples

---

## 🚀 Next Steps

Once you've completed these exercises:
1. Review the solutions in the `solutions/` directory
2. Understand the time and space complexity of each solution
3. Try to solve them again without looking at solutions
4. Move on to [Arrays and Strings](02-arrays-strings.md)

Remember: **Practice makes perfect!** The more you solve, the better you'll get at recognizing patterns and applying the right techniques.

---

*"The only way to learn programming is by programming." - Brian Kernighan*
