# Graph Algorithms and Complexity Analysis - Exercises

## Table of Contents
1. [Graph Theory Fundamentals](#graph-theory-fundamentals)
2. [Graph Representation Exercises](#graph-representation-exercises)
3. [Graph Traversal Problems](#graph-traversal-problems)
4. [Shortest Path Problems](#shortest-path-problems)
5. [Minimum Spanning Tree Problems](#minimum-spanning-tree-problems)
6. [Advanced Graph Problems](#advanced-graph-problems)
7. [Complexity Analysis Exercises](#complexity-analysis-exercises)
8. [Mixed Challenge Problems](#mixed-challenge-problems)

---

## Graph Theory Fundamentals

### Exercise 1: Graph Properties
**Difficulty:** ⭐
**Concepts:** Graph terminology, properties

Given the following graph descriptions, answer the questions:

```
Graph A: Vertices {0, 1, 2, 3}, Edges {(0,1), (1,2), (2,3), (3,0), (1,3)}
Graph B: Vertices {A, B, C, D}, Edges {(A,B), (B,C), (C,D)}
Graph C: Vertices {1, 2, 3, 4}, Edges {(1,2), (2,3), (3,1), (2,4)}
```

**Questions:**
1. Which graphs are connected?
2. Which graphs contain cycles?
3. What is the degree of each vertex in Graph A?
4. Is Graph B a tree? Why or why not?
5. How many connected components does Graph C have?

### Exercise 2: Graph Classification
**Difficulty:** ⭐⭐
**Concepts:** Graph types, directed vs undirected

For each scenario, determine the best graph type and justify your answer:

1. **Social Network Followers:** Users can follow others, but following is not mutual
2. **Road Network:** Roads connect cities, and you can travel in both directions
3. **Course Prerequisites:** Some courses require others as prerequisites
4. **Friendship Network:** Friendships are mutual relationships
5. **Web Page Links:** Pages link to other pages, but links are one-way

**Answer format:** Graph type (directed/undirected, weighted/unweighted) + justification

---

## Graph Representation Exercises

### Exercise 3: Adjacency Matrix vs Adjacency List
**Difficulty:** ⭐⭐
**Concepts:** Graph representation trade-offs

Given a graph with V vertices and E edges:

**Part A:** Complete the comparison table

| Aspect | Adjacency Matrix | Adjacency List |
|--------|------------------|----------------|
| Space Complexity | ? | ? |
| Check if edge exists | ? | ? |
| Add vertex | ? | ? |
| Add edge | ? | ? |
| Remove vertex | ? | ? |
| Find all neighbors | ? | ? |

**Part B:** For each scenario, choose the better representation and explain why:

1. **Dense graph** with V = 1000, E = 400,000
2. **Sparse graph** with V = 10,000, E = 15,000
3. **Frequent edge existence queries** in a social network
4. **Dynamic graph** where vertices are frequently added/removed
5. **Memory-constrained environment** with a sparse graph

### Exercise 4: Implementation Challenge
**Difficulty:** ⭐⭐⭐
**Concepts:** Graph representation implementation

Implement both adjacency matrix and adjacency list representations for an undirected graph:

```java
class GraphMatrix {
    private boolean[][] matrix;
    private int vertices;
    
    public GraphMatrix(int vertices) {
        // TODO: Initialize
    }
    
    public void addEdge(int src, int dest) {
        // TODO: Add edge
    }
    
    public boolean hasEdge(int src, int dest) {
        // TODO: Check if edge exists
    }
    
    public List<Integer> getNeighbors(int vertex) {
        // TODO: Return all neighbors
    }
}

class GraphList {
    private List<List<Integer>> adjList;
    private int vertices;
    
    public GraphList(int vertices) {
        // TODO: Initialize
    }
    
    public void addEdge(int src, int dest) {
        // TODO: Add edge
    }
    
    public boolean hasEdge(int src, int dest) {
        // TODO: Check if edge exists
    }
    
    public List<Integer> getNeighbors(int vertex) {
        // TODO: Return all neighbors
    }
}
```

**Requirements:**
- Handle edge cases (invalid vertices, self-loops)
- Provide time complexity analysis for each method
- Test with example graphs

---

## Graph Traversal Problems

### Exercise 5: DFS vs BFS Applications
**Difficulty:** ⭐⭐
**Concepts:** Algorithm selection, traversal applications

For each problem, choose DFS or BFS and explain your reasoning:

1. **Find if path exists** between two vertices
2. **Find shortest path** in unweighted graph
3. **Detect cycles** in undirected graph
4. **Count connected components**
5. **Find all vertices at distance K** from source
6. **Check if graph is bipartite**
7. **Topological sorting** of DAG
8. **Find strongly connected components**

### Exercise 6: Island Counting
**Difficulty:** ⭐⭐
**Concepts:** Connected components, grid traversal

Given a 2D grid of '1's (land) and '0's (water), count the number of islands. An island is surrounded by water and formed by connecting adjacent lands horizontally or vertically.

```java
public int numIslands(char[][] grid) {
    // TODO: Implement using DFS or BFS
}
```

**Test Cases:**
```
Input:
[
  ['1','1','1','1','0'],
  ['1','1','0','1','0'],
  ['1','1','0','0','0'],
  ['0','0','0','0','0']
]
Output: 1

Input:
[
  ['1','1','0','0','0'],
  ['1','1','0','0','0'],
  ['0','0','1','0','0'],
  ['0','0','0','1','1']
]
Output: 3
```

**Analysis Required:**
- Time complexity
- Space complexity
- Comparison of DFS vs BFS approaches

### Exercise 7: Course Schedule
**Difficulty:** ⭐⭐⭐
**Concepts:** Topological sorting, cycle detection

There are `numCourses` courses labeled from 0 to `numCourses - 1`. Some courses have prerequisites. Can you finish all courses?

```java
public boolean canFinish(int numCourses, int[][] prerequisites) {
    // TODO: Implement using topological sorting
}

public int[] findOrder(int numCourses, int[][] prerequisites) {
    // TODO: Return valid course order or empty array if impossible
}
```

**Test Cases:**
```
Input: numCourses = 2, prerequisites = [[1,0]]
Output: true (take course 0, then course 1)

Input: numCourses = 2, prerequisites = [[1,0],[0,1]]
Output: false (circular dependency)

Input: numCourses = 4, prerequisites = [[1,0],[2,0],[3,1],[3,2]]
findOrder Output: [0,2,1,3] or [0,1,2,3]
```

---

## Shortest Path Problems

### Exercise 8: Shortest Path Algorithm Selection
**Difficulty:** ⭐⭐
**Concepts:** Algorithm applicability, constraints

For each scenario, choose the appropriate shortest path algorithm and justify:

1. **Unweighted graph**, single source to all destinations
2. **Weighted graph with non-negative weights**, single source
3. **Weighted graph with negative weights**, single source
4. **All-pairs shortest path** in dense graph
5. **Single-pair shortest path** in large sparse graph
6. **Shortest path in grid** with obstacles
7. **Graph with negative cycles**, detect them
8. **Real-time GPS navigation** system

### Exercise 9: Network Delay Time
**Difficulty:** ⭐⭐⭐
**Concepts:** Dijkstra's algorithm application

You have a network of `n` nodes labeled 1 to `n`. Given a list of travel times as directed edges `times[i] = (ui, vi, wi)`, find the minimum time for a signal to reach all nodes from node `k`.

```java
public int networkDelayTime(int[][] times, int n, int k) {
    // TODO: Implement using Dijkstra's algorithm
}
```

**Test Cases:**
```
Input: times = [[2,1,1],[2,3,1],[3,4,1]], n = 4, k = 2
Output: 2

Input: times = [[1,2,1]], n = 2, k = 1
Output: 1

Input: times = [[1,2,1]], n = 2, k = 2
Output: -1 (cannot reach all nodes)
```

### Exercise 10: Cheapest Flights Within K Stops
**Difficulty:** ⭐⭐⭐⭐
**Concepts:** Modified shortest path, constraints

Find the cheapest price from `src` to `dst` with at most `k` stops.

```java
public int findCheapestPrice(int n, int[][] flights, int src, int dst, int k) {
    // TODO: Implement using modified Bellman-Ford or Dijkstra
}
```

**Test Cases:**
```
Input: n = 3, flights = [[0,1,100],[1,2,100],[0,2,500]], src = 0, dst = 2, k = 1
Output: 200

Input: n = 3, flights = [[0,1,100],[1,2,100],[0,2,500]], src = 0, dst = 2, k = 0
Output: 500
```

---

## Minimum Spanning Tree Problems

### Exercise 11: MST Algorithm Comparison
**Difficulty:** ⭐⭐
**Concepts:** Kruskal's vs Prim's algorithm

**Part A:** Complete the comparison table

| Aspect | Kruskal's | Prim's |
|--------|-----------|--------|
| Time Complexity | ? | ? |
| Space Complexity | ? | ? |
| Data Structure Used | ? | ? |
| Edge Selection Strategy | ? | ? |
| Better for Dense Graphs | ? | ? |
| Better for Sparse Graphs | ? | ? |
| Parallelizable | ? | ? |

**Part B:** Choose the better algorithm for each scenario:
1. **Dense graph** with V = 1000, E = 500,000
2. **Sparse graph** with V = 10,000, E = 20,000
3. **Distributed computing** environment
4. **Memory-constrained** system
5. **Real-time** edge additions

### Exercise 12: Connecting Cities
**Difficulty:** ⭐⭐⭐
**Concepts:** MST application, cost optimization

You are given `n` cities and the cost of connecting each pair of cities. Find the minimum cost to connect all cities.

```java
public int minimumCost(int n, int[][] connections) {
    // connections[i] = [city1, city2, cost]
    // TODO: Implement using MST algorithm
}
```

**Test Cases:**
```
Input: n = 3, connections = [[1,2,5],[1,3,6],[2,3,1]]
Output: 6 (connect 2-3 and 1-2 or 1-3)

Input: n = 4, connections = [[1,2,3],[3,4,4]]
Output: -1 (cannot connect all cities)
```

---

## Advanced Graph Problems

### Exercise 13: Strongly Connected Components
**Difficulty:** ⭐⭐⭐⭐
**Concepts:** SCC, Kosaraju's algorithm

Find all strongly connected components in a directed graph.

```java
public List<List<Integer>> findSCC(int n, int[][] edges) {
    // TODO: Implement using Kosaraju's or Tarjan's algorithm
}
```

### Exercise 14: Critical Connections
**Difficulty:** ⭐⭐⭐⭐
**Concepts:** Bridges, Tarjan's algorithm

Find all critical connections (bridges) in a network. A critical connection is one whose removal increases the number of connected components.

```java
public List<List<Integer>> criticalConnections(int n, List<List<Integer>> connections) {
    // TODO: Implement using Tarjan's bridge-finding algorithm
}
```

### Exercise 15: Word Ladder
**Difficulty:** ⭐⭐⭐
**Concepts:** BFS in implicit graph, string manipulation

Find the shortest transformation sequence from `beginWord` to `endWord` such that:
1. Only one letter can be changed at a time
2. Each transformed word must exist in the word list

```java
public int ladderLength(String beginWord, String endWord, List<String> wordList) {
    // TODO: Implement using BFS on implicit graph
}
```

**Test Case:**
```
Input: beginWord = "hit", endWord = "cog", wordList = ["hot","dot","dog","lot","log","cog"]
Output: 5 ("hit" -> "hot" -> "dot" -> "dog" -> "cog")
```

---

## Complexity Analysis Exercises

### Exercise 16: Algorithm Complexity Analysis
**Difficulty:** ⭐⭐
**Concepts:** Time and space complexity calculation

Analyze the time and space complexity of the following code snippets:

**Snippet A:**
```java
public void mystery1(int n) {
    for (int i = 0; i < n; i++) {
        for (int j = i; j < n; j++) {
            System.out.println(i + " " + j);
        }
    }
}
```

**Snippet B:**
```java
public int mystery2(int[] arr) {
    Arrays.sort(arr);  // Assume O(n log n)
    for (int i = 0; i < arr.length; i++) {
        if (binarySearch(arr, arr[i] * 2) != -1) {
            return arr[i];
        }
    }
    return -1;
}
```

**Snippet C:**
```java
public List<String> mystery3(String s, int k) {
    List<String> result = new ArrayList<>();
    for (int i = 0; i <= s.length() - k; i++) {
        result.add(s.substring(i, i + k));
    }
    return result;
}
```

### Exercise 17: Recursive Complexity Analysis
**Difficulty:** ⭐⭐⭐
**Concepts:** Recurrence relations, Master theorem

Analyze the time complexity using recurrence relations:

**Problem A:**
```java
public int fibonacci(int n) {
    if (n <= 1) return n;
    return fibonacci(n-1) + fibonacci(n-2);
}
```

**Problem B:**
```java
public void mergeSort(int[] arr, int left, int right) {
    if (left < right) {
        int mid = (left + right) / 2;
        mergeSort(arr, left, mid);
        mergeSort(arr, mid + 1, right);
        merge(arr, left, mid, right);  // O(n)
    }
}
```

**Problem C:**
```java
public int power(int base, int exp) {
    if (exp == 0) return 1;
    if (exp % 2 == 0) {
        int half = power(base, exp / 2);
        return half * half;
    } else {
        return base * power(base, exp - 1);
    }
}
```

### Exercise 18: Space Complexity Deep Dive
**Difficulty:** ⭐⭐⭐
**Concepts:** Auxiliary space, call stack analysis

Analyze the space complexity, distinguishing between input space and auxiliary space:

**Algorithm A: In-place quicksort**
```java
public void quickSort(int[] arr, int low, int high) {
    if (low < high) {
        int pi = partition(arr, low, high);  // O(1) space
        quickSort(arr, low, pi - 1);
        quickSort(arr, pi + 1, high);
    }
}
```

**Algorithm B: Level-order traversal**
```java
public List<List<Integer>> levelOrder(TreeNode root) {
    List<List<Integer>> result = new ArrayList<>();
    Queue<TreeNode> queue = new LinkedList<>();
    if (root != null) queue.offer(root);
    
    while (!queue.isEmpty()) {
        int size = queue.size();
        List<Integer> level = new ArrayList<>();
        for (int i = 0; i < size; i++) {
            TreeNode node = queue.poll();
            level.add(node.val);
            if (node.left != null) queue.offer(node.left);
            if (node.right != null) queue.offer(node.right);
        }
        result.add(level);
    }
    return result;
}
```

### Exercise 19: Optimization Challenge
**Difficulty:** ⭐⭐⭐⭐
**Concepts:** Algorithm optimization, trade-offs

For each problem, provide multiple solutions with different time-space trade-offs:

**Problem: Find if array has duplicates**

Provide solutions for:
1. **Minimal space usage** (O(1) space)
2. **Optimal time complexity** (O(n) time)
3. **Balanced approach** (reasonable time and space)

```java
// Approach 1: Space-optimized
public boolean hasDuplicates1(int[] nums) {
    // TODO: O(1) space solution
}

// Approach 2: Time-optimized
public boolean hasDuplicates2(int[] nums) {
    // TODO: O(n) time solution
}

// Approach 3: Balanced
public boolean hasDuplicates3(int[] nums) {
    // TODO: Balanced approach
}
```

---

## Mixed Challenge Problems

### Exercise 20: Graph Construction and Analysis
**Difficulty:** ⭐⭐⭐⭐
**Concepts:** Graph modeling, multiple algorithms

**Problem:** Social Network Analysis

You're building a social media platform. Users can follow each other (directed relationship) and also be friends (undirected relationship). Implement the following functionality:

```java
class SocialNetwork {
    // TODO: Choose appropriate data structures
    
    public void addUser(int userId) {
        // TODO: Add a new user
    }
    
    public void addFollowing(int follower, int followee) {
        // TODO: User follower starts following followee
    }
    
    public void addFriendship(int user1, int user2) {
        // TODO: Create mutual friendship
    }
    
    public List<Integer> suggestFollowers(int userId, int maxSuggestions) {
        // TODO: Suggest users to follow based on mutual friends
        // Time complexity requirement: O(V + E) per suggestion
    }
    
    public int shortestConnectionPath(int user1, int user2) {
        // TODO: Find shortest path through friendships
    }
    
    public List<List<Integer>> findCommunities() {
        // TODO: Find strongly connected components in follow graph
    }
    
    public boolean isInfluencer(int userId, int threshold) {
        // TODO: Check if user has more than threshold followers
        // and follows less than threshold/10 people
    }
}
```

**Requirements:**
- Analyze time and space complexity for each method
- Handle edge cases (non-existent users, cycles, etc.)
- Optimize for common operations
- Provide test cases

### Exercise 21: Algorithm Design Challenge
**Difficulty:** ⭐⭐⭐⭐⭐
**Concepts:** Algorithm design, complexity optimization

**Problem:** Efficient Route Planning

Design a system for a delivery company that needs to:

1. **Find optimal routes** between warehouses and customers
2. **Handle real-time traffic updates** (edge weight changes)
3. **Minimize total delivery time** for multiple packages
4. **Support different vehicle types** with varying capacities

```java
class DeliveryRouter {
    // TODO: Design the system architecture
    
    public void addLocation(int id, String address) {
        // TODO: Add delivery location
    }
    
    public void addRoute(int from, int to, int distance, int time) {
        // TODO: Add route with distance and time weights
    }
    
    public void updateTraffic(int from, int to, double trafficMultiplier) {
        // TODO: Update route time based on traffic
    }
    
    public List<Integer> findOptimalRoute(int start, List<Integer> destinations) {
        // TODO: Find optimal route visiting all destinations
        // This is a variant of TSP - use approximation algorithm
    }
    
    public Map<Integer, List<Integer>> assignDeliveries(
            List<Integer> vehicles, 
            List<Delivery> deliveries) {
        // TODO: Assign deliveries to vehicles optimally
    }
    
    public int estimateDeliveryTime(int start, int destination) {
        // TODO: Estimate delivery time considering current traffic
    }
}
```

**Constraints:**
- System should handle 100,000+ locations
- Real-time updates should be processed in < 100ms
- Route calculations should complete in < 1 second
- Memory usage should be reasonable for mobile devices

**Analysis Required:**
- Choose appropriate algorithms for each component
- Analyze time and space complexity
- Discuss trade-offs and optimizations
- Consider system scalability

---

## Solutions Guidelines

### Evaluation Criteria

**Basic Problems (⭐-⭐⭐):**
- Correct implementation
- Basic complexity analysis
- Handling of edge cases

**Intermediate Problems (⭐⭐⭐):**
- Optimal algorithm choice
- Detailed complexity analysis
- Multiple solution approaches
- Code efficiency

**Advanced Problems (⭐⭐⭐⭐-⭐⭐⭐⭐⭐):**
- System design considerations
- Advanced optimization techniques
- Scalability analysis
- Real-world applicability

### Common Mistakes to Avoid

1. **Complexity Analysis:**
   - Confusing time and space complexity
   - Ignoring recursive call stack space
   - Missing hidden complexity in library functions

2. **Graph Algorithms:**
   - Not handling disconnected graphs
   - Forgetting to mark vertices as visited
   - Incorrect edge case handling

3. **Implementation:**
   - Index out of bounds errors
   - Not checking for null/empty inputs
   - Memory leaks in dynamic structures

### Study Tips

1. **Practice Pattern Recognition:**
   - Learn to identify graph problem types
   - Recognize when to use specific algorithms
   - Understand complexity patterns

2. **Master the Fundamentals:**
   - Graph representations
   - Basic traversal algorithms
   - Common optimization techniques

3. **Build Intuition:**
   - Visualize algorithms with small examples
   - Understand why certain approaches work
   - Practice complexity analysis regularly

Remember: The key to mastering graph algorithms and complexity analysis is consistent practice and understanding the underlying principles, not just memorizing implementations! 🚀
