# Module 3: Storage & Databases (S3, RDS, DynamoDB)
**Duration**: 10 hours | **Level**: Intermediate | **Certification**: SAA-C03 Domain 3 (High-Performance Architectures)

## 🎯 Learning Objectives

By the end of this module, you will be able to:
- Integrate Spring Boot applications with S3 for object storage
- Configure and connect to Amazon RDS for relational data
- Implement DynamoDB for NoSQL data patterns
- Design data access patterns and caching strategies
- Implement backup, disaster recovery, and data lifecycle policies
- Optimize database performance and costs

---

## 📚 Module Contents

### 📖 Theory & Concepts
- **S3 Deep Dive**: Storage classes, lifecycle policies, security
- **RDS Fundamentals**: Engine types, Multi-AZ, Read Replicas
- **DynamoDB Design**: Partition keys, GSI/LSI, best practices
- **Data Patterns**: CQRS, Event Sourcing, Polyglot Persistence
- **Performance Optimization**: Caching, connection pooling, indexing

### 💻 Code Examples
- **Spring Data JPA with RDS**: Entity mapping, repositories, transactions
- **DynamoDB SDK Integration**: CRUD operations, queries, batch processing
- **S3 File Management**: Upload, download, multipart, pre-signed URLs
- **Caching with ElastiCache**: Redis integration, cache-aside pattern
- **Database Migration Tools**: Flyway, Liquibase integration

### 🎯 Hands-on Labs
- **Lab 1**: S3 Integration - File upload/download service
- **Lab 2**: RDS Setup - PostgreSQL with Spring Data JPA
- **Lab 3**: DynamoDB Implementation - User profile service
- **Lab 4**: Multi-Database Architecture - Polyglot persistence
- **Lab 5**: Performance Optimization - Caching and indexing

---

## 🏗️ Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                    Data Storage Architecture                    │
│                                                                 │
│  ┌─────────────────┐    ┌─────────────────────────────────┐   │
│  │  Spring Boot    │    │         Amazon S3               │   │
│  │  Application    │───▶│  • Static content               │   │
│  │                 │    │  • File uploads                 │   │
│  │  ┌─────────────┐│    │  • Backup storage              │   │
│  │  │   Service   ││    └─────────────────────────────────┘   │
│  │  │   Layer     ││                                          │
│  │  └─────────────┘│    ┌─────────────────────────────────┐   │
│  │         │       │    │         Amazon RDS              │   │
│  │         ▼       │    │  • Transactional data          │   │
│  │  ┌─────────────┐│───▶│  • PostgreSQL/MySQL            │   │
│  │  │    Data     ││    │  • Multi-AZ deployment         │   │
│  │  │   Access    ││    └─────────────────────────────────┘   │
│  │  │   Layer     ││                                          │
│  │  └─────────────┘│    ┌─────────────────────────────────┐   │
│  │         │       │    │       Amazon DynamoDB           │   │
│  │         ▼       │───▶│  • User sessions                │   │
│  │  ┌─────────────┐│    │  • Product catalog              │   │
│  │  │   Cache     ││    │  • High-speed NoSQL             │   │
│  │  │   Layer     ││    └─────────────────────────────────┘   │
│  │  └─────────────┘│                                          │
│  │         │       │    ┌─────────────────────────────────┐   │
│  │         ▼       │───▶│       Amazon ElastiCache        │   │
│  │  ┌─────────────┐│    │  • Redis caching               │   │
│  │  │ Application ││    │  • Session storage             │   │
│  │  │  Business   ││    │  • Performance optimization    │   │
│  │  │   Logic     ││    └─────────────────────────────────┘   │
│  │  └─────────────┘│                                          │
│  └─────────────────┘                                          │
└─────────────────────────────────────────────────────────────────┘
```

---

## 🎯 Key Learning Topics

### S3 Object Storage (2.5 hours)
- **Storage Classes**: Standard, IA, Glacier, Deep Archive
- **Security**: Bucket policies, ACLs, encryption
- **Performance**: Multipart upload, Transfer Acceleration
- **Integration**: Spring Boot file upload/download service

### Amazon RDS (3 hours)
- **Database Engines**: PostgreSQL, MySQL, Oracle, SQL Server
- **High Availability**: Multi-AZ, Read Replicas, automated backups
- **Security**: VPC, encryption, IAM database authentication
- **Performance**: Parameter groups, Performance Insights

### DynamoDB (3 hours)
- **Data Modeling**: Partition keys, sort keys, denormalization
- **Indexes**: Global Secondary Index (GSI), Local Secondary Index (LSI)
- **Operations**: Queries, scans, batch operations, transactions
- **Performance**: Auto scaling, DAX caching

### Advanced Patterns (1.5 hours)
- **Polyglot Persistence**: Using multiple databases appropriately
- **Caching Strategies**: Cache-aside, write-through, write-behind
- **Data Lifecycle**: Archiving, retention policies, compliance

---

## 💻 Spring Boot Integration Examples

### S3 File Service
```java
@Service
public class S3FileService {
    
    @Autowired
    private S3Client s3Client;
    
    public String uploadFile(MultipartFile file) {
        String key = generateUniqueKey(file.getOriginalFilename());
        
        PutObjectRequest request = PutObjectRequest.builder()
            .bucket(bucketName)
            .key(key)
            .contentType(file.getContentType())
            .build();
            
        s3Client.putObject(request, 
            RequestBody.fromInputStream(file.getInputStream(), file.getSize()));
            
        return generatePublicUrl(key);
    }
}
```

### RDS with Spring Data JPA
```java
@Entity
@Table(name = "users")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(nullable = false, unique = true)
    private String email;
    
    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL)
    private List<Order> orders;
}

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    @Query("SELECT u FROM User u LEFT JOIN FETCH u.orders WHERE u.email = :email")
    Optional<User> findByEmailWithOrders(@Param("email") String email);
}
```

### DynamoDB Integration
```java
@DynamoDbBean
public class UserProfile {
    private String userId;
    private String email;
    private Map<String, String> preferences;
    
    @DynamoDbPartitionKey
    public String getUserId() { return userId; }
    
    @DynamoDbAttribute("email")
    public String getEmail() { return email; }
}

@Repository
public class UserProfileRepository {
    
    @Autowired
    private DynamoDbEnhancedClient dynamoDbClient;
    
    public void saveUserProfile(UserProfile profile) {
        DynamoDbTable<UserProfile> table = dynamoDbClient.table("UserProfiles", 
            TableSchema.fromBean(UserProfile.class));
        table.putItem(profile);
    }
}
```

---

## 🎓 Certification Mapping

### SAA-C03 Domain 3: Design High-Performing Architectures (24%)

This module covers:
- **3.1** Choose performant storage and databases
  - ✅ S3 storage classes and performance optimization
  - ✅ RDS instance types and storage options
  - ✅ DynamoDB design patterns and performance

- **3.2** Design solutions for elasticity and scalability
  - ✅ RDS Read Replicas for read scaling
  - ✅ DynamoDB auto scaling and on-demand billing
  - ✅ S3 Transfer Acceleration and multipart upload

- **3.3** Design solutions for high-performing networking
  - ✅ VPC endpoints for S3 and DynamoDB
  - ✅ ElastiCache for application acceleration
  - ✅ Database connection pooling and optimization

---

## 🏆 Real-World Projects

### E-commerce Platform Data Layer
- **Product Catalog**: DynamoDB for fast product searches
- **Order Management**: RDS for transactional integrity
- **Media Storage**: S3 for product images and videos
- **Caching**: ElastiCache for frequently accessed data

### Content Management System
- **User Data**: RDS for relational user information
- **Content Storage**: S3 for documents and media files
- **Metadata**: DynamoDB for content indexing and search
- **Performance**: Multi-layer caching strategy

---

## 📚 Prerequisites

### Required Knowledge
- Completed Module 1 (AWS Basics) and Module 2 (Compute)
- SQL fundamentals and database concepts
- Basic understanding of NoSQL databases
- Java collections and data structures

### Development Environment
- Spring Boot 3.x with Spring Data JPA
- PostgreSQL or MySQL client tools
- AWS CLI configured for DynamoDB operations
- IDE with database integration (IntelliJ IDEA recommended)

---

## 🔄 Next Module

After completing this module, proceed to:
**[Module 4: Serverless (Lambda, API Gateway, EventBridge)](../module-04-serverless/README.md)**

You'll learn how to build event-driven, serverless architectures that complement your data storage strategies.

---

**Ready to master AWS data services?** 🚀 Start with understanding the different storage patterns and choose the right tool for each data type in your applications.

**Begin with**: S3 Integration Lab - Build a robust file management service for your Spring Boot application.
