# Module 7: Monitoring & Security
**Duration**: 8 hours | **Level**: Advanced | **Certification**: SAA-C03 Domain 1 & 4

## 🎯 Learning Objectives

By the end of this module, you will be able to:
- Implement comprehensive application monitoring with CloudWatch and X-Ray
- Design security monitoring and incident response strategies
- Configure automated alerting and notification systems
- Implement cost monitoring and optimization alerts
- Set up distributed tracing for microservices architectures
- Apply security best practices and compliance monitoring

---

## 📚 Module Contents

### 📖 Theory & Concepts
- **Observability Pillars**: Metrics, logs, traces, and events
- **CloudWatch Deep Dive**: Custom metrics, dashboards, alarms
- **AWS X-Ray**: Distributed tracing, service maps, performance analysis
- **Security Monitoring**: CloudTrail, Config, GuardDuty, Security Hub
- **Cost Monitoring**: Cost Explorer, Budgets, Trusted Advisor

### 💻 Code Examples
- **Custom Metrics**: Spring Boot Actuator with CloudWatch integration
- **Distributed Tracing**: X-Ray SDK implementation
- **Log Aggregation**: Centralized logging with CloudWatch Logs
- **Security Events**: Real-time security monitoring and alerting
- **Cost Optimization**: Automated cost tracking and budgeting

### 🎯 Hands-on Labs
- **Lab 1**: CloudWatch Integration - Metrics and dashboards
- **Lab 2**: X-Ray Tracing - End-to-end request tracking
- **Lab 3**: Security Monitoring - CloudTrail and Config setup
- **Lab 4**: Alerting and Response - Automated incident management
- **Lab 5**: Cost Optimization - Monitoring and automated cleanup

---

## 🏗️ Monitoring Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                        Comprehensive Monitoring Architecture                    │
│                                                                                 │
│  ┌─────────────────────────────────────────────────────────────────────────┐   │
│  │                           Application Layer                             │   │
│  │                                                                         │   │
│  │  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────────────┐ │   │
│  │  │  Spring Boot    │  │   Microservice  │  │    Lambda Functions     │ │   │
│  │  │  Application    │  │   Architecture  │  │                         │ │   │
│  │  │                 │  │                 │  │                         │ │   │
│  │  │  ┌─────────────┐│  │  ┌─────────────┐│  │  ┌─────────────────────┐│ │   │
│  │  │  │   Metrics   ││  │  │   Traces    ││  │  │       Logs          ││ │   │
│  │  │  │   • Custom  ││  │  │   • X-Ray   ││  │  │  • Structured       ││ │   │
│  │  │  │   • Business││  │  │   • Service ││  │  │  • Centralized      ││ │   │
│  │  │  │   • System  ││  │  │   • Maps    ││  │  │  • Searchable       ││ │   │
│  │  │  └─────────────┘│  │  └─────────────┘│  │  └─────────────────────┘│ │   │
│  │  └─────────────────┘  └─────────────────┘  └─────────────────────────┘ │   │
│  └─────────────────────────────────────────────────────────────────────────┘   │
│                                           │                                     │
│                                           ▼                                     │
│  ┌─────────────────────────────────────────────────────────────────────────┐   │
│  │                         Data Collection Layer                          │   │
│  │                                                                         │   │
│  │  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────────────┐ │   │
│  │  │   CloudWatch    │  │     AWS X-Ray   │  │    CloudWatch Logs      │ │   │
│  │  │   Metrics       │  │                 │  │                         │ │   │
│  │  │                 │  │  ┌─────────────┐│  │  ┌─────────────────────┐│ │   │
│  │  │  ┌─────────────┐│  │  │   Service   ││  │  │   Log Groups        ││ │   │
│  │  │  │   Custom    ││  │  │   Map       ││  │  │  • Application      ││ │   │
│  │  │  │   Metrics   ││  │  └─────────────┘│  │  │  • Infrastructure   ││ │   │
│  │  │  └─────────────┘│  │                 │  │  │  • Security         ││ │   │
│  │  │                 │  │  ┌─────────────┐│  │  └─────────────────────┘│ │   │
│  │  │  ┌─────────────┐│  │  │   Traces    ││  │                         │ │   │
│  │  │  │   System    ││  │  │   Analytics ││  │  ┌─────────────────────┐│ │   │
│  │  │  │   Metrics   ││  │  └─────────────┘│  │  │   Log Insights      ││ │   │
│  │  │  └─────────────┘│  └─────────────────┘  │  │  • Queries          ││ │   │
│  │  └─────────────────┘                       │  │  • Analytics        ││ │   │
│  │                                             │  └─────────────────────┘│ │   │
│  │                                             └─────────────────────────┘ │   │
│  └─────────────────────────────────────────────────────────────────────────┘   │
│                                           │                                     │
│                                           ▼                                     │
│  ┌─────────────────────────────────────────────────────────────────────────┐   │
│  │                        Analysis & Alerting Layer                       │   │
│  │                                                                         │   │
│  │  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────────────┐ │   │
│  │  │   CloudWatch    │  │   CloudWatch    │  │      Security           │ │   │
│  │  │   Dashboards    │  │   Alarms        │  │      Monitoring         │ │   │
│  │  │                 │  │                 │  │                         │ │   │
│  │  │  ┌─────────────┐│  │  ┌─────────────┐│  │  ┌─────────────────────┐│ │   │
│  │  │  │ Executive   ││  │  │ Threshold   ││  │  │   CloudTrail        ││ │   │
│  │  │  │ Summary     ││  │  │ Based       ││  │  │  • API calls        ││ │   │
│  │  │  └─────────────┘│  │  └─────────────┘│  │  └─────────────────────┘│ │   │
│  │  │                 │  │                 │  │                         │ │   │
│  │  │  ┌─────────────┐│  │  ┌─────────────┐│  │  ┌─────────────────────┐│ │   │
│  │  │  │ Technical   ││  │  │ Anomaly     ││  │  │   GuardDuty         ││ │   │
│  │  │  │ Details     ││  │  │ Detection   ││  │  │  • Threat detection ││ │   │
│  │  │  └─────────────┘│  │  └─────────────┘│  │  └─────────────────────┘│ │   │
│  │  │                 │  │                 │  │                         │ │   │
│  │  │  ┌─────────────┐│  │  ┌─────────────┐│  │  ┌─────────────────────┐│ │   │
│  │  │  │ Cost        ││  │  │ Composite   ││  │  │   Config            ││ │   │
│  │  │  │ Analysis    ││  │  │ Alarms      ││  │  │  • Compliance       ││ │   │
│  │  │  └─────────────┘│  │  └─────────────┘│  │  └─────────────────────┘│ │   │
│  │  └─────────────────┘  └─────────────────┘  └─────────────────────────┘ │   │
│  └─────────────────────────────────────────────────────────────────────────┘   │
│                                           │                                     │
│                                           ▼                                     │
│  ┌─────────────────────────────────────────────────────────────────────────┐   │
│  │                      Response & Action Layer                           │   │
│  │                                                                         │   │
│  │  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────────────┐ │   │
│  │  │      SNS        │  │   Lambda        │  │    Systems Manager      │ │   │
│  │  │ Notifications   │  │ Auto-Response   │  │   Automation            │ │   │
│  │  │                 │  │                 │  │                         │ │   │
│  │  │  ┌─────────────┐│  │  ┌─────────────┐│  │  ┌─────────────────────┐│ │   │
│  │  │  │   Email     ││  │  │  Incident   ││  │  │  Auto Scaling       ││ │   │
│  │  │  │   Alerts    ││  │  │  Response   ││  │  │  • Scale up/down    ││ │   │
│  │  │  └─────────────┘│  │  └─────────────┘│  │  └─────────────────────┘│ │   │
│  │  │                 │  │                 │  │                         │ │   │
│  │  │  ┌─────────────┐│  │  ┌─────────────┐│  │  ┌─────────────────────┐│ │   │
│  │  │  │   Slack     ││  │  │  Resource   ││  │  │  Remediation        ││ │   │
│  │  │  │   Teams     ││  │  │  Cleanup    ││  │  │  • Auto-healing     ││ │   │
│  │  │  └─────────────┘│  │  └─────────────┘│  │  └─────────────────────┘│ │   │
│  │  │                 │  │                 │  │                         │ │   │
│  │  │  ┌─────────────┐│  │  ┌─────────────┐│  │  ┌─────────────────────┐│ │   │
│  │  │  │   PagerDuty ││  │  │   Security  ││  │  │   Cost              ││ │   │
│  │  │  │   OnCall    ││  │  │   Response  ││  │  │   Optimization      ││ │   │
│  │  │  └─────────────┘│  │  └─────────────┘│  │  └─────────────────────┘│ │   │
│  │  └─────────────────┘  └─────────────────┘  └─────────────────────────┘ │   │
│  └─────────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────────┘
```

---

## 🎯 Key Learning Topics

### CloudWatch Monitoring (2 hours)
- **Custom Metrics**: Business and technical metrics
- **Dashboards**: Executive and operational views
- **Alarms**: Threshold-based and anomaly detection
- **Log Insights**: Advanced log analysis and queries

### Distributed Tracing (2 hours)
- **AWS X-Ray**: Service maps, trace analysis, performance optimization
- **Spring Cloud Sleuth**: Distributed tracing integration
- **Trace Correlation**: Request flow across microservices
- **Performance Bottleneck Identification**

### Security Monitoring (2 hours)
- **CloudTrail**: API call logging and analysis
- **GuardDuty**: Threat detection and response
- **Config**: Compliance monitoring and remediation
- **Security Hub**: Centralized security findings

### Cost Monitoring (2 hours)
- **Cost Explorer**: Usage analysis and forecasting
- **Budgets**: Automated cost alerts and controls
- **Trusted Advisor**: Cost optimization recommendations
- **Resource Tagging**: Cost allocation and tracking

---

## 💻 Implementation Examples

### Spring Boot with CloudWatch Custom Metrics
```java
// Custom metrics configuration
@Configuration
@EnableConfigurationProperties(CloudWatchProperties.class)
public class CloudWatchConfig {
    
    @Bean
    public CloudWatchAsyncClient cloudWatchAsyncClient() {
        return CloudWatchAsyncClient.builder()
            .region(Region.US_EAST_1)
            .build();
    }
    
    @Bean
    public CloudWatchMeterRegistry cloudWatchMeterRegistry(
            CloudWatchAsyncClient cloudWatchAsyncClient,
            CloudWatchProperties properties) {
        
        CloudWatchConfig config = new CloudWatchConfig() {
            @Override
            public String get(String key) {
                return null; // Use defaults
            }
            
            @Override
            public String namespace() {
                return properties.getNamespace();
            }
            
            @Override
            public Duration step() {
                return Duration.ofMinutes(1);
            }
        };
        
        return new CloudWatchMeterRegistry(config, Clock.SYSTEM, cloudWatchAsyncClient);
    }
}

// Business metrics service
@Service
public class BusinessMetricsService {
    
    private final MeterRegistry meterRegistry;
    private final Counter orderCounter;
    private final Timer orderProcessingTimer;
    private final Gauge activeUsersGauge;
    
    public BusinessMetricsService(MeterRegistry meterRegistry) {
        this.meterRegistry = meterRegistry;
        this.orderCounter = Counter.builder("orders.created")
            .description("Number of orders created")
            .tag("application", "spring-boot-demo")
            .register(meterRegistry);
            
        this.orderProcessingTimer = Timer.builder("orders.processing.time")
            .description("Order processing time")
            .tag("application", "spring-boot-demo")
            .register(meterRegistry);
            
        this.activeUsersGauge = Gauge.builder("users.active")
            .description("Number of active users")
            .tag("application", "spring-boot-demo")
            .register(meterRegistry, this, BusinessMetricsService::getActiveUserCount);
    }
    
    public void recordOrderCreated(String orderType, BigDecimal amount) {
        orderCounter.increment(
            Tags.of(
                "type", orderType,
                "amount_range", categorizeAmount(amount)
            )
        );
    }
    
    public void recordOrderProcessingTime(Duration processingTime, String status) {
        orderProcessingTimer.record(processingTime, Tags.of("status", status));
    }
    
    public void recordCustomBusinessMetric(String metricName, double value, Tags tags) {
        meterRegistry.gauge(metricName, tags, value);
    }
    
    private double getActiveUserCount() {
        // Implementation to get active user count
        return userService.getActiveUserCount();
    }
    
    private String categorizeAmount(BigDecimal amount) {
        if (amount.compareTo(BigDecimal.valueOf(100)) < 0) return "small";
        if (amount.compareTo(BigDecimal.valueOf(1000)) < 0) return "medium";
        return "large";
    }
}

// Custom health indicators
@Component
public class CustomHealthIndicators {
    
    @Autowired
    private MeterRegistry meterRegistry;
    
    @Component
    public class DatabaseHealthIndicator implements HealthIndicator {
        
        @Override
        public Health health() {
            Timer.Sample sample = Timer.start(meterRegistry);
            
            try {
                boolean isHealthy = checkDatabaseConnection();
                
                if (isHealthy) {
                    sample.stop(Timer.builder("health.check.duration")
                        .tag("component", "database")
                        .tag("status", "success")
                        .register(meterRegistry));
                    return Health.up()
                        .withDetail("database", "Connected")
                        .build();
                } else {
                    sample.stop(Timer.builder("health.check.duration")
                        .tag("component", "database")
                        .tag("status", "failure")
                        .register(meterRegistry));
                    return Health.down()
                        .withDetail("database", "Connection failed")
                        .build();
                }
            } catch (Exception e) {
                sample.stop(Timer.builder("health.check.duration")
                    .tag("component", "database")
                    .tag("status", "error")
                    .register(meterRegistry));
                return Health.down(e)
                    .withDetail("database", "Health check failed")
                    .build();
            }
        }
    }
}
```

### X-Ray Distributed Tracing
```java
// X-Ray configuration
@Configuration
@EnableXRay
public class XRayConfig {
    
    @Bean
    public XRayInterceptor xrayInterceptor() {
        return new XRayInterceptor();
    }
    
    @Bean
    public Filter TracingFilter() {
        return new AWSXRayServletFilter("spring-boot-demo");
    }
}

// Service with X-Ray tracing
@Service
@XRayEnabled
public class OrderService {
    
    @Autowired
    private PaymentService paymentService;
    
    @Autowired
    private InventoryService inventoryService;
    
    @Autowired
    private NotificationService notificationService;
    
    @Trace(metaData = true)
    public OrderResult processOrder(OrderRequest request) {
        
        // Add custom annotations for better tracing
        AWSXRay.getCurrentSegment().putAnnotation("orderId", request.getOrderId());
        AWSXRay.getCurrentSegment().putAnnotation("userId", request.getUserId());
        AWSXRay.getCurrentSegment().putAnnotation("orderValue", request.getTotalAmount());
        
        // Add metadata for detailed analysis
        AWSXRay.getCurrentSegment().putMetadata("order", "details", request);
        
        try {
            // Each service call will be automatically traced
            validateOrder(request);
            
            PaymentResult payment = paymentService.processPayment(request);
            InventoryResult inventory = inventoryService.reserveItems(request);
            
            if (payment.isSuccessful() && inventory.isSuccessful()) {
                notificationService.sendOrderConfirmation(request);
                
                AWSXRay.getCurrentSegment().putAnnotation("orderStatus", "success");
                return OrderResult.success(request.getOrderId());
            } else {
                // Compensating actions
                if (payment.isSuccessful()) {
                    paymentService.refundPayment(payment.getTransactionId());
                }
                if (inventory.isSuccessful()) {
                    inventoryService.releaseItems(request);
                }
                
                AWSXRay.getCurrentSegment().putAnnotation("orderStatus", "failed");
                return OrderResult.failure(request.getOrderId(), "Payment or inventory failed");
            }
            
        } catch (Exception e) {
            AWSXRay.getCurrentSegment().addException(e);
            AWSXRay.getCurrentSegment().putAnnotation("orderStatus", "error");
            throw e;
        }
    }
    
    @Trace
    private void validateOrder(OrderRequest request) {
        // Custom subsegment for validation
        Subsegment subsegment = AWSXRay.beginSubsegment("order-validation");
        try {
            // Validation logic
            subsegment.putAnnotation("validationSteps", 3);
            subsegment.putMetadata("validation", "rules", getValidationRules());
            
            if (!isValidOrder(request)) {
                throw new ValidationException("Invalid order");
            }
        } finally {
            AWSXRay.endSubsegment();
        }
    }
}

// External service call tracing
@Service
public class ExternalApiService {
    
    private final RestTemplate restTemplate;
    
    public ExternalApiService() {
        this.restTemplate = new RestTemplate();
        // Add X-Ray interceptor for HTTP calls
        this.restTemplate.setInterceptors(
            Collections.singletonList(new TracingInterceptor())
        );
    }
    
    @Trace
    public ApiResponse callExternalApi(String endpoint, Object request) {
        
        Subsegment subsegment = AWSXRay.beginSubsegment("external-api-call");
        try {
            subsegment.putAnnotation("endpoint", endpoint);
            subsegment.putAnnotation("method", "POST");
            
            ApiResponse response = restTemplate.postForObject(
                endpoint, 
                request, 
                ApiResponse.class
            );
            
            subsegment.putAnnotation("responseStatus", response.getStatus());
            return response;
            
        } catch (Exception e) {
            subsegment.addException(e);
            throw e;
        } finally {
            AWSXRay.endSubsegment();
        }
    }
}
```

### Security Monitoring Integration
```java
// Security event logging
@Service
public class SecurityEventService {
    
    private static final Logger securityLogger = LoggerFactory.getLogger("SECURITY");
    
    @Autowired
    private CloudWatchLogsClient cloudWatchLogsClient;
    
    public void logSecurityEvent(SecurityEvent event) {
        
        // Structured logging for CloudWatch Logs Insights
        String logMessage = createStructuredLogMessage(event);
        securityLogger.warn(logMessage);
        
        // Send to dedicated security log group
        sendToSecurityLogGroup(event);
        
        // If critical, send immediate alert
        if (event.getSeverity() == SecuritySeverity.CRITICAL) {
            sendImmediateAlert(event);
        }
    }
    
    private String createStructuredLogMessage(SecurityEvent event) {
        return String.format(
            "SECURITY_EVENT: {\"timestamp\":\"%s\", \"eventType\":\"%s\", " +
            "\"severity\":\"%s\", \"userId\":\"%s\", \"ipAddress\":\"%s\", " +
            "\"userAgent\":\"%s\", \"details\":%s}",
            event.getTimestamp(),
            event.getEventType(),
            event.getSeverity(),
            event.getUserId(),
            event.getIpAddress(),
            event.getUserAgent(),
            event.getDetailsAsJson()
        );
    }
    
    private void sendToSecurityLogGroup(SecurityEvent event) {
        try {
            PutLogEventsRequest request = PutLogEventsRequest.builder()
                .logGroupName("/aws/lambda/security-events")
                .logStreamName(generateLogStreamName())
                .logEvents(InputLogEvent.builder()
                    .timestamp(event.getTimestamp().toEpochMilli())
                    .message(createStructuredLogMessage(event))
                    .build())
                .build();
                
            cloudWatchLogsClient.putLogEvents(request);
        } catch (Exception e) {
            logger.error("Failed to send security event to CloudWatch", e);
        }
    }
}

// Security monitoring aspect
@Aspect
@Component
public class SecurityMonitoringAspect {
    
    @Autowired
    private SecurityEventService securityEventService;
    
    @Around("@annotation(Secured)")
    public Object monitorSecuredMethod(ProceedingJoinPoint joinPoint) throws Throwable {
        
        String methodName = joinPoint.getSignature().getName();
        String className = joinPoint.getTarget().getClass().getSimpleName();
        
        try {
            Object result = joinPoint.proceed();
            
            // Log successful access
            securityEventService.logSecurityEvent(
                SecurityEvent.builder()
                    .eventType("METHOD_ACCESS")
                    .severity(SecuritySeverity.INFO)
                    .details(Map.of(
                        "method", methodName,
                        "class", className,
                        "status", "success"
                    ))
                    .build()
            );
            
            return result;
            
        } catch (AccessDeniedException e) {
            // Log access denied
            securityEventService.logSecurityEvent(
                SecurityEvent.builder()
                    .eventType("ACCESS_DENIED")
                    .severity(SecuritySeverity.WARNING)
                    .details(Map.of(
                        "method", methodName,
                        "class", className,
                        "reason", e.getMessage()
                    ))
                    .build()
            );
            throw e;
        }
    }
}
```

### Cost Monitoring and Optimization
```java
// Cost monitoring service
@Service
public class CostMonitoringService {
    
    @Autowired
    private CostExplorerClient costExplorerClient;
    
    @Autowired
    private BudgetsClient budgetsClient;
    
    @Scheduled(cron = "0 0 9 * * MON") // Every Monday at 9 AM
    public void generateWeeklyCostReport() {
        
        LocalDate endDate = LocalDate.now();
        LocalDate startDate = endDate.minusDays(7);
        
        GetCostAndUsageRequest request = GetCostAndUsageRequest.builder()
            .timePeriod(DateInterval.builder()
                .start(startDate.toString())
                .end(endDate.toString())
                .build())
            .granularity(Granularity.DAILY)
            .metrics("BlendedCost", "UsageQuantity")
            .groupBy(
                GroupDefinition.builder()
                    .type(GroupDefinitionType.DIMENSION)
                    .key("SERVICE")
                    .build(),
                GroupDefinition.builder()
                    .type(GroupDefinitionType.TAG)
                    .key("Environment")
                    .build()
            )
            .build();
            
        GetCostAndUsageResponse response = costExplorerClient.getCostAndUsage(request);
        
        // Process and send report
        CostReport report = processCostData(response);
        sendCostReport(report);
        
        // Check for anomalies
        checkForCostAnomalies(report);
    }
    
    public void checkBudgetAlerts() {
        DescribeBudgetsRequest request = DescribeBudgetsRequest.builder()
            .accountId(getAccountId())
            .build();
            
        DescribeBudgetsResponse response = budgetsClient.describeBudgets(request);
        
        for (Budget budget : response.budgets()) {
            if (isBudgetExceeded(budget)) {
                sendBudgetAlert(budget);
            }
        }
    }
    
    @EventListener
    public void handleCostAlert(CostAlertEvent event) {
        if (event.getThresholdExceeded() > 0.8) { // 80% of budget
            // Trigger automated cost optimization
            triggerCostOptimization(event);
        }
    }
    
    private void triggerCostOptimization(CostAlertEvent event) {
        // Automated responses to cost alerts
        
        // 1. Scale down non-production environments
        if (event.getEnvironment().equals("dev") || 
            event.getEnvironment().equals("staging")) {
            scaleDownEnvironment(event.getEnvironment());
        }
        
        // 2. Stop unused EC2 instances
        stopUnusedInstances(event.getEnvironment());
        
        // 3. Cleanup old snapshots and AMIs
        cleanupOldSnapshots(event.getEnvironment());
        
        // 4. Review and optimize storage classes
        optimizeStorageClasses(event.getEnvironment());
    }
}
```

---

## 🎓 Certification Mapping

### SAA-C03 Domain 1: Design Secure Architectures (30%)
- **1.1** Design secure access to AWS resources
  - ✅ CloudTrail for API monitoring
  - ✅ GuardDuty for threat detection
  - ✅ Config for compliance monitoring

### SAA-C03 Domain 4: Design Cost-Optimized Architectures (20%)
- **4.1** Design cost-optimized storage solutions
  - ✅ Cost monitoring and alerting
  - ✅ Automated cost optimization
  - ✅ Resource usage analysis

---

## 📊 Monitoring Dashboards

### Executive Dashboard
```json
{
  "widgets": [
    {
      "type": "metric",
      "properties": {
        "metrics": [
          ["AWS/ApplicationELB", "RequestCount", "LoadBalancer", "app-lb"],
          ["AWS/ApplicationELB", "TargetResponseTime", "LoadBalancer", "app-lb"],
          ["AWS/ECS", "CPUUtilization", "ServiceName", "spring-boot-service"],
          ["AWS/ECS", "MemoryUtilization", "ServiceName", "spring-boot-service"]
        ],
        "view": "timeSeries",
        "stacked": false,
        "region": "us-east-1",
        "title": "Application Performance",
        "period": 300
      }
    },
    {
      "type": "metric",
      "properties": {
        "metrics": [
          ["SpringBootApp", "orders.created", "application", "spring-boot-demo"],
          ["SpringBootApp", "orders.processing.time", "application", "spring-boot-demo"]
        ],
        "view": "timeSeries",
        "stacked": false,
        "region": "us-east-1",
        "title": "Business Metrics",
        "period": 300
      }
    }
  ]
}
```

### Operational Dashboard
```json
{
  "widgets": [
    {
      "type": "log",
      "properties": {
        "query": "SOURCE '/aws/ecs/spring-boot-app'\n| fields @timestamp, @message\n| filter @message like /ERROR/\n| sort @timestamp desc\n| limit 20",
        "region": "us-east-1",
        "title": "Recent Errors",
        "view": "table"
      }
    },
    {
      "type": "metric",
      "properties": {
        "metrics": [
          ["AWS/X-Ray", "TracesReceived"],
          ["AWS/X-Ray", "ErrorRate", "ServiceName", "spring-boot-demo"],
          ["AWS/X-Ray", "ResponseTime", "ServiceName", "spring-boot-demo"]
        ],
        "view": "timeSeries",
        "stacked": false,
        "region": "us-east-1",
        "title": "Distributed Tracing Metrics",
        "period": 300
      }
    }
  ]
}
```

---

## 🚨 Alerting Strategy

### Alert Hierarchy
```yaml
# Critical Alerts (Immediate Response)
critical_alerts:
  - name: "Application Down"
    metric: "AWS/ApplicationELB/HealthyHostCount"
    threshold: 0
    evaluation_periods: 2
    response_time: "<5 minutes"
    
  - name: "High Error Rate"
    metric: "AWS/ApplicationELB/HTTPCode_Target_5XX_Count"
    threshold: ">10% of requests"
    evaluation_periods: 2
    response_time: "<5 minutes"

# Warning Alerts (Monitor Closely)
warning_alerts:
  - name: "High Response Time"
    metric: "AWS/ApplicationELB/TargetResponseTime"
    threshold: ">2 seconds"
    evaluation_periods: 3
    response_time: "<15 minutes"
    
  - name: "High CPU Usage"
    metric: "AWS/ECS/CPUUtilization"
    threshold: ">80%"
    evaluation_periods: 3
    response_time: "<15 minutes"

# Info Alerts (Trend Monitoring)
info_alerts:
  - name: "Cost Budget Alert"
    metric: "AWS/Billing/EstimatedCharges"
    threshold: "80% of budget"
    evaluation_periods: 1
    response_time: "<1 hour"
```

---

## 📚 Prerequisites

### Required Knowledge
- Completed Modules 1-6 (Foundation through CI/CD)
- Understanding of monitoring and observability concepts
- Basic knowledge of security principles
- Familiarity with cost optimization strategies

### Development Environment
- AWS CLI with CloudWatch and X-Ray permissions
- Spring Boot application with Actuator enabled
- Access to CloudWatch console and dashboards

---

## 🔄 Next Module

After completing this module, proceed to:
**[Module 8: Capstone Project](../module-08-capstone/README.md)**

You'll apply everything learned in the previous modules to build a complete Employee & Organization Management System with full monitoring, security, and cost optimization.

---

## 🎯 Monitoring Best Practices

### The Four Golden Signals
1. **Latency**: Time to service requests
2. **Traffic**: Demand on your system
3. **Errors**: Rate of failed requests
4. **Saturation**: Resource utilization

### Alert Fatigue Prevention
- **Actionable Alerts Only**: Every alert should require human action
- **Context-Rich Notifications**: Include runbooks and next steps
- **Alert Correlation**: Group related alerts to reduce noise
- **Escalation Paths**: Clear ownership and escalation procedures

---

**Ready to achieve full observability?** 👁️ Build comprehensive monitoring that provides insights into your application's health, security, and costs!

**Begin with**: CloudWatch Integration Lab - Set up custom metrics and dashboards for your Spring Boot application.
