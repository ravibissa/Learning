# SAA-C03 Domain 1: Design Secure Architectures (30%)

## 🎯 Domain Overview

Domain 1 represents **30% of the SAA-C03 exam** and focuses on designing secure architectures in AWS. This domain tests your ability to implement security controls, manage access, and protect data across AWS services.

---

## 📚 Domain Breakdown

### 1.1 Design secure access to AWS resources (8-10%)

#### Key Topics:
- **Access controls and management across multiple accounts**
- **AWS federated access and identity providers** 
- **Cross-account access**
- **Appropriate use of resource-based policies vs identity-based policies**
- **When to use AWS managed policies vs customer managed policies**

#### Critical Concepts:

**IAM Policy Types**
```json
// Identity-based policy (attached to user/group/role)
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": "s3:GetObject",
      "Resource": "arn:aws:s3:::my-bucket/*"
    }
  ]
}

// Resource-based policy (attached to S3 bucket)
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": "arn:aws:iam::123456789012:role/MyRole",
      "Action": "s3:GetObject",
      "Resource": "arn:aws:s3:::my-bucket/*"
    }
  ]
}
```

**Cross-Account Access Pattern**
```java
// Java example: Assuming cross-account role
AWSSecurityTokenService stsClient = AWSSecurityTokenServiceClientBuilder.defaultClient();

AssumeRoleRequest assumeRoleRequest = new AssumeRoleRequest()
    .withRoleArn("arn:aws:iam::ACCOUNT-B:role/CrossAccountRole")
    .withRoleSessionName("MySession")
    .withExternalId("unique-external-id"); // Security feature

AssumeRoleResult result = stsClient.assumeRole(assumeRoleRequest);
```

#### Exam Tips:
- **Resource-based policies** allow cross-account access without role assumption
- **External ID** is required for secure cross-account role assumption
- **AWS managed policies** are maintained by AWS, customer managed policies by you
- **Policy evaluation**: Explicit deny always overrides allow

---

### 1.2 Design secure application tiers (6-8%)

#### Key Topics:
- **Application Load Balancer (ALB) security features**
- **Network Load Balancer (NLB) and security groups**
- **Security groups vs NACLs**
- **WAF integration with CloudFront and ALB**
- **API Gateway security features**

#### Critical Concepts:

**Security Groups vs NACLs**
| Feature | Security Groups | Network ACLs |
|---------|----------------|--------------|
| Level | Instance | Subnet |
| Rules | Allow only | Allow/Deny |
| State | Stateful | Stateless |
| Rule evaluation | All rules | Rules in order |

**ALB Security Features**
```java
// Spring Boot with ALB health check
@RestController
public class HealthController {
    
    @GetMapping("/health")
    public ResponseEntity<Map<String, String>> health() {
        // ALB health check endpoint
        return ResponseEntity.ok(Map.of(
            "status", "UP",
            "timestamp", Instant.now().toString()
        ));
    }
    
    @GetMapping("/ready")
    public ResponseEntity<Map<String, String>> ready() {
        // Kubernetes-style readiness probe
        return ResponseEntity.ok(Map.of("status", "READY"));
    }
}
```

**WAF Integration Example**
```json
// WAF rule to block SQL injection
{
  "Name": "SQLInjectionRule",
  "Statement": {
    "SqliMatchStatement": {
      "FieldToMatch": {
        "AllQueryArguments": {}
      },
      "TextTransformations": [
        {
          "Priority": 1,
          "Type": "URL_DECODE"
        }
      ]
    }
  },
  "Action": {
    "Block": {}
  }
}
```

#### Exam Tips:
- **ALB** supports SSL termination, WAF integration, and host-based routing
- **Security groups** are stateful (return traffic automatically allowed)
- **NACLs** are stateless (must explicitly allow return traffic)
- **WAF** protects against OWASP Top 10 vulnerabilities

---

### 1.3 Select appropriate data security controls (6-8%)

#### Key Topics:
- **Data classification and protection**
- **Encryption in transit and at rest**
- **Key management with AWS KMS**
- **Access patterns and permissions**
- **Data loss prevention**

#### Critical Concepts:

**S3 Encryption Options**
```java
// S3 encryption with Spring Boot
@Service
public class SecureS3Service {
    
    public void uploadEncryptedFile(String bucket, String key, String content) {
        PutObjectRequest request = PutObjectRequest.builder()
            .bucket(bucket)
            .key(key)
            .serverSideEncryption(ServerSideEncryption.AES256) // S3-managed
            // OR
            .ssekmsKeyId("arn:aws:kms:region:account:key/key-id") // KMS-managed
            .build();
            
        s3Client.putObject(request, RequestBody.fromString(content));
    }
}
```

**RDS Encryption**
```yaml
# CloudFormation template for encrypted RDS
Resources:
  DatabaseInstance:
    Type: AWS::RDS::DBInstance
    Properties:
      DBInstanceClass: db.t3.micro
      Engine: mysql
      StorageEncrypted: true
      KmsKeyId: !Ref DatabaseKMSKey
      BackupRetentionPeriod: 7
      DeletionProtection: true
```

**KMS Key Policy Example**
```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "AllowDeveloperAccess",
      "Effect": "Allow",
      "Principal": {
        "AWS": "arn:aws:iam::123456789012:role/DeveloperRole"
      },
      "Action": [
        "kms:Encrypt",
        "kms:Decrypt",
        "kms:ReEncrypt*",
        "kms:GenerateDataKey*",
        "kms:DescribeKey"
      ],
      "Resource": "*",
      "Condition": {
        "StringEquals": {
          "kms:ViaService": [
            "s3.us-east-1.amazonaws.com",
            "rds.us-east-1.amazonaws.com"
          ]
        }
      }
    }
  ]
}
```

#### Exam Tips:
- **S3** supports SSE-S3, SSE-KMS, and SSE-C encryption
- **RDS** encryption must be enabled at creation time
- **KMS** provides centralized key management with audit trails
- **CloudTrail** logs all KMS key usage for compliance

---

### 1.4 Design secure network architectures (8-10%)

#### Key Topics:
- **VPC design with public/private subnets**
- **Network segmentation and isolation**
- **VPC endpoints for private connectivity**
- **Transit Gateway for complex networking**
- **Direct Connect and VPN**

#### Critical Concepts:

**VPC Architecture Pattern**
```
┌─────────────────────────────────────────────────────────────┐
│                        VPC (10.0.0.0/16)                   │
│                                                             │
│  ┌──────────────────────┐    ┌──────────────────────────┐  │
│  │    Public Subnet     │    │    Private Subnet        │  │
│  │   (10.0.1.0/24)     │    │   (10.0.2.0/24)         │  │
│  │                      │    │                          │  │
│  │  ┌─────────────────┐ │    │  ┌─────────────────────┐ │  │
│  │  │   ALB/NLB       │ │    │  │   Spring Boot App   │ │  │
│  │  │                 │ │    │  │   (EC2/ECS)         │ │  │
│  │  └─────────────────┘ │    │  └─────────────────────┘ │  │
│  │                      │    │                          │  │
│  │  ┌─────────────────┐ │    │  ┌─────────────────────┐ │  │
│  │  │   NAT Gateway   │ │    │  │   RDS Database      │ │  │
│  │  └─────────────────┘ │    │  └─────────────────────┘ │  │
│  └──────────────────────┘    └──────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
```

**VPC Endpoints for Private Access**
```java
// Spring Boot accessing S3 via VPC endpoint
@Configuration
public class VpcEndpointConfig {
    
    @Bean
    public S3Client s3ClientWithVpcEndpoint() {
        return S3Client.builder()
            .region(Region.US_EAST_1)
            .endpointOverride(URI.create("https://vpce-12345-abcde.s3.us-east-1.vpce.amazonaws.com"))
            .build();
    }
}
```

#### Exam Tips:
- **Public subnets** have routes to Internet Gateway
- **Private subnets** use NAT Gateway for outbound internet access
- **VPC endpoints** provide private connectivity to AWS services
- **Transit Gateway** simplifies complex multi-VPC connectivity

---

## 🎯 Common Exam Scenarios

### Scenario 1: Multi-Account Strategy
**Question**: "Company wants to separate dev, staging, and production environments with secure cross-account access."

**Answer**: 
- Create separate AWS accounts for each environment
- Use cross-account IAM roles for access
- Implement AWS Organizations for centralized management
- Use external ID for additional security

### Scenario 2: Database Security
**Question**: "Application needs to access RDS database securely without exposing credentials."

**Answer**:
- Use IAM database authentication
- Store database credentials in AWS Secrets Manager
- Use VPC security groups to control network access
- Enable encryption at rest and in transit

### Scenario 3: Data Protection
**Question**: "S3 bucket contains sensitive customer data that must be encrypted and access-controlled."

**Answer**:
- Enable S3 bucket encryption with KMS
- Use bucket policies to restrict access
- Enable S3 access logging
- Implement S3 Object Lock for compliance

### Scenario 4: Network Security
**Question**: "Web application needs to be publicly accessible but backend services should be private."

**Answer**:
- Use public subnets for load balancers
- Place application servers in private subnets
- Use security groups for fine-grained access control
- Implement VPC endpoints for AWS service access

---

## 🎓 Study Strategy

### Week 1: Foundation
- [ ] IAM concepts and policy structure
- [ ] Hands-on: Create users, groups, roles, and policies
- [ ] Practice: Cross-account access setup

### Week 2: Application Security
- [ ] Security groups vs NACLs
- [ ] ALB/NLB security features
- [ ] WAF and CloudFront integration

### Week 3: Data Protection
- [ ] S3 encryption options
- [ ] KMS key management
- [ ] RDS security features

### Week 4: Network Architecture
- [ ] VPC design patterns
- [ ] VPC endpoints and private connectivity
- [ ] Transit Gateway use cases

---

## 📝 Key Formulas and Rules

### IAM Policy Evaluation
```
1. Explicit DENY = DENY (always wins)
2. Explicit ALLOW = ALLOW
3. No explicit policy = DENY (default)
```

### S3 Access Control
```
Bucket Policy + IAM Policy + ACL = Final Permission
(Most restrictive wins)
```

### Security Group Rules
```
Inbound: Must explicitly allow
Outbound: All traffic allowed by default (can be restricted)
```

---

## 🔗 Additional Resources

### AWS Documentation
- [IAM Best Practices](https://docs.aws.amazon.com/IAM/latest/UserGuide/best-practices.html)
- [S3 Security Best Practices](https://docs.aws.amazon.com/AmazonS3/latest/userguide/security-best-practices.html)
- [VPC Security Best Practices](https://docs.aws.amazon.com/vpc/latest/userguide/vpc-security-best-practices.html)

### Practice Labs
- [IAM Policy Simulator](https://policysim.aws.amazon.com/)
- [AWS Security Workshops](https://workshops.aws/categories/Security)
- [AWS Well-Architected Security Pillar](https://docs.aws.amazon.com/wellarchitected/latest/security-pillar/)

### Java Integration Examples
```java
// Complete Spring Boot security configuration
@Configuration
@EnableWebSecurity
public class SecurityConfig {
    
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        return http
            .csrf(csrf -> csrf.disable())
            .sessionManagement(session -> 
                session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/health", "/actuator/**").permitAll()
                .anyRequest().authenticated())
            .oauth2ResourceServer(oauth2 -> oauth2
                .jwt(jwt -> jwt.decoder(jwtDecoder())))
            .build();
    }
}
```

---

## ✅ Self-Assessment Questions

1. **What's the difference between identity-based and resource-based policies?**
2. **When would you use cross-account IAM roles vs. resource-based policies?**
3. **How do you implement least privilege access for a Spring Boot application?**
4. **What are the different S3 encryption options and when to use each?**
5. **How do security groups differ from NACLs in terms of functionality?**

---

**Next Domain**: [Domain 2: Design Resilient Architectures](./saa-c03-domain2.md)

---

**Remember**: Domain 1 is worth 30% of your exam score. Focus on hands-on practice with IAM, security groups, and encryption to build confidence for exam day! 🎯
