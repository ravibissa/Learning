# Module 1: AWS Basics & Setup
**Duration**: 5 hours | **Level**: Beginner | **Certification**: SAA-C03 Domain 1 (Secure Architectures)

## 🎯 Learning Objectives

By the end of this module, you will be able to:
- Understand fundamental AWS cloud concepts and the shared responsibility model
- Set up and configure AWS CLI with proper security practices
- Create and manage IAM users, groups, roles, and policies
- Implement AWS security best practices for authentication and authorization
- Navigate the AWS Management Console effectively
- Apply basic cost optimization strategies

---

## 📚 Module Contents

### 📖 [Theory & Concepts](./theory/)
- [What is Cloud Computing?](./theory/01-cloud-computing.md)
- [AWS Global Infrastructure](./theory/02-aws-infrastructure.md)
- [AWS Shared Responsibility Model](./theory/03-shared-responsibility.md)
- [Identity and Access Management (IAM)](./theory/04-iam-concepts.md)
- [AWS CLI & SDK Overview](./theory/05-cli-sdk.md)

### 💻 [Code Examples](./code-examples/)
- [Java 21 + Spring Boot AWS SDK Integration](./code-examples/aws-sdk-demo/)
- [IAM Policy Examples](./code-examples/iam-policies/)
- [AWS CLI Common Commands](./code-examples/cli-scripts/)

### 🎯 [Hands-on Lab](./hands-on-lab/)
- [Lab 1: AWS Account Setup & Billing Alerts](./hands-on-lab/lab-01-account-setup.md)
- [Lab 2: IAM Users, Groups, and Policies](./hands-on-lab/lab-02-iam-setup.md)
- [Lab 3: AWS CLI Configuration](./hands-on-lab/lab-03-cli-setup.md)
- [Lab 4: Spring Boot + AWS SDK Integration](./hands-on-lab/lab-04-spring-aws.md)

### 📝 [Certification Notes](./certification-notes/)
- [SAA-C03 Domain 1 Key Points](./certification-notes/saa-c03-domain1.md)
- [Common Exam Questions & Patterns](./certification-notes/exam-tips.md)

---

## ⏱️ Time Breakdown

| Section | Duration | Activity Type |
|---------|----------|---------------|
| Theory & Concepts | 2 hours | Reading & Video |
| Code Examples Review | 1 hour | Code Analysis |
| Hands-on Labs | 1.5 hours | Practical |
| Certification Review | 30 minutes | Exam Prep |

---

## 🏗️ Architecture Overview

```
┌─────────────────────────────────────────────────────────────┐
│                     AWS Cloud Account                       │
│                                                             │
│  ┌─────────────────┐    ┌──────────────────────────────┐   │
│  │   IAM Service   │    │        AWS CLI/SDK           │   │
│  │                 │    │                              │   │
│  │  ┌─────────────┐│    │  ┌─────────────────────────┐ │   │
│  │  │    Users    ││    │  │   Local Development    │ │   │
│  │  │             ││    │  │     Environment        │ │   │
│  │  │  ┌─────────┐││    │  │                         │ │   │
│  │  │  │ Groups  │││    │  │  ┌─────────────────────┐│ │   │
│  │  │  │         │││    │  │  │  Spring Boot App   ││ │   │
│  │  │  │ ┌─────┐ │││    │  │  │  + AWS SDK v2      ││ │   │
│  │  │  │ │Roles│ │││    │  │  │  + Java 21         ││ │   │
│  │  │  │ └─────┘ │││    │  │  └─────────────────────┘│ │   │
│  │  │  └─────────┘││    │  └─────────────────────────┘ │   │
│  │  └─────────────┘│    └──────────────────────────────┘   │
│  └─────────────────┘                                       │
│                                                             │
│  ┌─────────────────────────────────────────────────────┐   │
│  │              Security Best Practices                │   │
│  │  • MFA Enabled  • Least Privilege  • Regular Audits│   │
│  └─────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
```

---

## 🚀 Prerequisites Check

Before starting this module, ensure you have:

### Software Requirements
- [ ] **Java 21** installed (Amazon Corretto recommended)
- [ ] **Maven 3.9+** installed
- [ ] **Git** installed
- [ ] **IDE** (IntelliJ IDEA or VS Code)
- [ ] **Web browser** (Chrome/Firefox/Safari)

### Verification Commands
```bash
# Verify Java 21
java --version

# Verify Maven
mvn --version

# Verify Git
git --version
```

### AWS Account Requirements
- [ ] AWS Free Tier account created
- [ ] Valid credit card on file (for verification)
- [ ] Understanding of potential charges

---

## 🎯 Learning Path

### Step 1: Foundation (1.5 hours)
1. Read theory documents 1-3
2. Watch AWS introductory videos
3. Understand shared responsibility model

### Step 2: IAM Deep Dive (1.5 hours)
1. Study IAM concepts (theory document 4)
2. Complete Lab 2 (IAM setup)
3. Review policy examples

### Step 3: Development Setup (1.5 hours)
1. Complete Lab 3 (AWS CLI setup)
2. Complete Lab 4 (Spring Boot integration)
3. Test code examples

### Step 4: Certification Prep (30 minutes)
1. Review certification notes
2. Take practice quiz
3. Identify knowledge gaps

---

## ✅ Knowledge Check

After completing this module, you should be able to answer:

### Basic Questions
1. What is the difference between IaaS, PaaS, and SaaS?
2. List 5 AWS regions and their use cases
3. Explain the AWS shared responsibility model
4. What are the 4 main IAM components?

### Intermediate Questions
1. How do you implement least privilege access in IAM?
2. What's the difference between IAM users and roles?
3. How do you configure AWS CLI with multiple profiles?
4. When should you use IAM policies vs. resource-based policies?

### Advanced Questions
1. Design an IAM strategy for a multi-environment Spring Boot application
2. How would you implement cross-account access for your application?
3. What are the security implications of different AWS credential providers?

---

## 📋 Lab Deliverables

By the end of this module, you should have:

1. **AWS Account Setup**
   - Free tier account with billing alerts
   - Root account secured with MFA
   - Basic cost monitoring configured

2. **IAM Configuration**
   - At least 2 IAM users (admin, developer)
   - 2 groups with appropriate policies
   - 1 role for EC2 service access

3. **Development Environment**
   - AWS CLI configured with profiles
   - Spring Boot application with AWS SDK integration
   - Basic S3 list operation working

4. **Security Implementation**
   - All accounts have MFA enabled
   - Least privilege policies implemented
   - Access keys properly secured

---

## 🎓 Certification Mapping

### SAA-C03 Domain 1: Design Secure Architectures (30%)

This module covers:
- **1.1** Design secure access to AWS resources
  - ✅ Access controls and management across multiple accounts
  - ✅ Cross-account access management
  - ✅ Federated access management
  - ✅ Privileges escalation and limitation
  - ✅ Resource-based policies

- **1.2** Design secure application tiers
  - ✅ Security in app tiers (API Gateway, load balancer, compute)
  - ✅ Data in transit and at rest security

- **1.3** Select appropriate data security controls
  - ✅ Access patterns and permissions
  - ✅ Data classification and labeling

---

## 📚 Additional Resources

### AWS Documentation
- [IAM User Guide](https://docs.aws.amazon.com/IAM/latest/UserGuide/)
- [AWS CLI User Guide](https://docs.aws.amazon.com/cli/latest/userguide/)
- [AWS SDK for Java Developer Guide](https://docs.aws.amazon.com/sdk-for-java/latest/developer-guide/)

### Best Practices
- [IAM Best Practices](https://docs.aws.amazon.com/IAM/latest/UserGuide/best-practices.html)
- [AWS Security Best Practices](https://aws.amazon.com/architecture/security-identity-compliance/)

### Practice
- [AWS Hands-on Tutorials](https://aws.amazon.com/getting-started/hands-on/)
- [IAM Policy Simulator](https://policysim.aws.amazon.com/)

---

## 🔄 Next Module

After completing this module, proceed to:
**[Module 2: Compute (EC2, ASG, ELB)](../module-02-compute/README.md)**

You'll learn how to deploy your Spring Boot application on AWS compute services with high availability and scalability.

---

## 📞 Support

If you encounter issues:
1. Check the troubleshooting guides in each lab
2. Review AWS documentation links
3. Use AWS Support (Basic tier included with Free Tier)
4. Join AWS community forums

**Happy Learning! 🚀**
