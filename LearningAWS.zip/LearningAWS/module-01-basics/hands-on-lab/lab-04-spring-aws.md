# Lab 4: Spring Boot + AWS SDK Integration

**Duration**: 45 minutes | **Difficulty**: Intermediate

## 🎯 Objectives

By the end of this lab, you will:
- Create a Spring Boot 3 application with Java 21
- Integrate AWS SDK v2 for Java
- Implement S3 operations with proper error handling
- Configure AWS credentials securely
- Test the application locally and prepare for cloud deployment

---

## 📋 Prerequisites

Before starting this lab, ensure:
- [ ] Java 21 is installed
- [ ] Maven 3.9+ is installed
- [ ] AWS CLI is configured (from Lab 3)
- [ ] IAM user with S3 permissions (from Lab 2)
- [ ] IDE setup (IntelliJ IDEA or VS Code)

---

## 🛠️ Lab Steps

### Step 1: Create Spring Boot Project Structure

```bash
# Create project directory
mkdir spring-aws-demo
cd spring-aws-demo

# Create Maven project structure
mkdir -p src/main/java/com/example/awsdemo
mkdir -p src/main/resources
mkdir -p src/test/java/com/example/awsdemo
```

### Step 2: Create Maven Configuration

Create `pom.xml`:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 
         http://maven.apache.org/xsd/maven-4.0.0.xsd">
    
    <modelVersion>4.0.0</modelVersion>
    <parent>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-parent</artifactId>
        <version>3.2.0</version>
        <relativePath/>
    </parent>
    
    <groupId>com.example</groupId>
    <artifactId>spring-aws-demo</artifactId>
    <version>1.0.0</version>
    <packaging>jar</packaging>
    
    <name>Spring Boot AWS Demo</name>
    <description>Demo project for Spring Boot with AWS SDK v2</description>
    
    <properties>
        <java.version>21</java.version>
        <maven.compiler.source>21</maven.compiler.source>
        <maven.compiler.target>21</maven.compiler.target>
        <aws.java.sdk.version>2.21.29</aws.java.sdk.version>
        <spring-cloud-aws.version>3.0.3</spring-cloud-aws.version>
    </properties>
    
    <dependencies>
        <!-- Spring Boot Starters -->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-web</artifactId>
        </dependency>
        
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-actuator</artifactId>
        </dependency>
        
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-validation</artifactId>
        </dependency>
        
        <!-- AWS SDK v2 -->
        <dependency>
            <groupId>software.amazon.awssdk</groupId>
            <artifactId>bom</artifactId>
            <version>${aws.java.sdk.version}</version>
            <type>pom</type>
            <scope>import</scope>
        </dependency>
        
        <dependency>
            <groupId>software.amazon.awssdk</groupId>
            <artifactId>s3</artifactId>
        </dependency>
        
        <dependency>
            <groupId>software.amazon.awssdk</groupId>
            <artifactId>sts</artifactId>
        </dependency>
        
        <!-- Spring Cloud AWS -->
        <dependency>
            <groupId>io.awspring.cloud</groupId>
            <artifactId>spring-cloud-aws-starter</artifactId>
            <version>${spring-cloud-aws.version}</version>
        </dependency>
        
        <!-- Development Tools -->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-devtools</artifactId>
            <scope>runtime</scope>
            <optional>true</optional>
        </dependency>
        
        <!-- Testing -->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-test</artifactId>
            <scope>test</scope>
        </dependency>
        
        <dependency>
            <groupId>org.testcontainers</groupId>
            <artifactId>junit-jupiter</artifactId>
            <scope>test</scope>
        </dependency>
        
        <dependency>
            <groupId>org.testcontainers</groupId>
            <artifactId>localstack</artifactId>
            <scope>test</scope>
        </dependency>
    </dependencies>
    
    <build>
        <plugins>
            <plugin>
                <groupId>org.springframework.boot</groupId>
                <artifactId>spring-boot-maven-plugin</artifactId>
            </plugin>
        </plugins>
    </build>
</project>
```

### Step 3: Create Main Application Class

Create `src/main/java/com/example/awsdemo/SpringAwsDemoApplication.java`:

```java
package com.example.awsdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Spring Boot application demonstrating AWS SDK v2 integration.
 * 
 * This application showcases:
 * - AWS S3 operations with proper error handling
 * - Secure credential management
 * - Production-ready configuration
 * - Health checks and monitoring
 */
@SpringBootApplication
public class SpringAwsDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringAwsDemoApplication.class, args);
    }
}
```

### Step 4: Create AWS Configuration

Create `src/main/java/com/example/awsdemo/config/AwsConfig.java`:

```java
package com.example.awsdemo.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import software.amazon.awssdk.auth.credentials.DefaultCredentialsProvider;
import software.amazon.awssdk.auth.credentials.ProfileCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.sts.StsClient;

/**
 * AWS Configuration for Spring Boot application.
 * 
 * This configuration provides:
 * - Different credential providers for different environments
 * - Proper region configuration
 * - Client configuration with best practices
 */
@Configuration
public class AwsConfig {

    @Value("${aws.region:us-east-1}")
    private String awsRegion;

    @Value("${aws.profile:default}")
    private String awsProfile;

    /**
     * S3 Client for local development using AWS profiles.
     */
    @Bean
    @Profile("!prod")
    public S3Client s3ClientDev() {
        return S3Client.builder()
                .region(Region.of(awsRegion))
                .credentialsProvider(ProfileCredentialsProvider.create(awsProfile))
                .build();
    }

    /**
     * S3 Client for production using default credential chain.
     * This will use IAM roles when running on EC2/ECS/Lambda.
     */
    @Bean
    @Profile("prod")
    public S3Client s3ClientProd() {
        return S3Client.builder()
                .region(Region.of(awsRegion))
                .credentialsProvider(DefaultCredentialsProvider.create())
                .build();
    }

    /**
     * STS Client for credential validation and role assumption.
     */
    @Bean
    public StsClient stsClient() {
        return StsClient.builder()
                .region(Region.of(awsRegion))
                .credentialsProvider(DefaultCredentialsProvider.create())
                .build();
    }
}
```

### Step 5: Create S3 Service

Create `src/main/java/com/example/awsdemo/service/S3Service.java`:

```java
package com.example.awsdemo.service;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import software.amazon.awssdk.core.ResponseInputStream;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.DeleteObjectRequest;
import software.amazon.awssdk.services.s3.model.GetObjectRequest;
import software.amazon.awssdk.services.s3.model.GetObjectResponse;
import software.amazon.awssdk.services.s3.model.HeadBucketRequest;
import software.amazon.awssdk.services.s3.model.ListObjectsV2Request;
import software.amazon.awssdk.services.s3.model.ListObjectsV2Response;
import software.amazon.awssdk.services.s3.model.NoSuchBucketException;
import software.amazon.awssdk.services.s3.model.NoSuchKeyException;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;
import software.amazon.awssdk.services.s3.model.S3Exception;
import software.amazon.awssdk.services.s3.model.S3Object;

/**
 * Service for S3 operations with comprehensive error handling.
 * 
 * This service demonstrates:
 * - CRUD operations on S3 objects
 * - Proper exception handling
 * - Logging for debugging and monitoring
 * - Input validation
 */
@Service
public class S3Service {

    private static final Logger logger = LoggerFactory.getLogger(S3Service.class);

    private final S3Client s3Client;
    
    @Value("${aws.s3.default-bucket:spring-aws-demo-bucket}")
    private String defaultBucket;

    public S3Service(S3Client s3Client) {
        this.s3Client = s3Client;
    }

    /**
     * Check if bucket exists and is accessible.
     */
    public boolean doesBucketExist(String bucketName) {
        try {
            s3Client.headBucket(HeadBucketRequest.builder().bucket(bucketName).build());
            logger.info("Bucket {} exists and is accessible", bucketName);
            return true;
        } catch (NoSuchBucketException e) {
            logger.warn("Bucket {} does not exist", bucketName);
            return false;
        } catch (S3Exception e) {
            logger.error("Error checking bucket {}: {}", bucketName, e.getMessage());
            throw new RuntimeException("Failed to check bucket existence", e);
        }
    }

    /**
     * Upload content to S3 bucket.
     */
    public void uploadFile(String bucketName, String key, String content) {
        validateInputs(bucketName, key);
        
        try {
            PutObjectRequest putObjectRequest = PutObjectRequest.builder()
                    .bucket(bucketName)
                    .key(key)
                    .contentType("text/plain")
                    .build();

            s3Client.putObject(putObjectRequest, 
                              RequestBody.fromInputStream(
                                  new ByteArrayInputStream(content.getBytes()), 
                                  content.length()));
            
            logger.info("Successfully uploaded file {} to bucket {}", key, bucketName);
        } catch (S3Exception e) {
            logger.error("Failed to upload file {} to bucket {}: {}", key, bucketName, e.getMessage());
            throw new RuntimeException("Failed to upload file to S3", e);
        }
    }

    /**
     * Download content from S3 bucket.
     */
    public String downloadFile(String bucketName, String key) {
        validateInputs(bucketName, key);
        
        try {
            GetObjectRequest getObjectRequest = GetObjectRequest.builder()
                    .bucket(bucketName)
                    .key(key)
                    .build();

            ResponseInputStream<GetObjectResponse> s3Object = s3Client.getObject(getObjectRequest);
            String content = new String(s3Object.readAllBytes());
            
            logger.info("Successfully downloaded file {} from bucket {}", key, bucketName);
            return content;
        } catch (NoSuchKeyException e) {
            logger.warn("File {} not found in bucket {}", key, bucketName);
            throw new RuntimeException("File not found in S3", e);
        } catch (S3Exception e) {
            logger.error("Failed to download file {} from bucket {}: {}", key, bucketName, e.getMessage());
            throw new RuntimeException("Failed to download file from S3", e);
        } catch (Exception e) {
            logger.error("Unexpected error downloading file {} from bucket {}: {}", key, bucketName, e.getMessage());
            throw new RuntimeException("Unexpected error downloading file", e);
        }
    }

    /**
     * List objects in bucket with optional prefix.
     */
    public List<String> listObjects(String bucketName, String prefix) {
        validateBucketName(bucketName);
        
        try {
            ListObjectsV2Request.Builder requestBuilder = ListObjectsV2Request.builder()
                    .bucket(bucketName)
                    .maxKeys(100);
            
            if (prefix != null && !prefix.trim().isEmpty()) {
                requestBuilder.prefix(prefix);
            }

            ListObjectsV2Response response = s3Client.listObjectsV2(requestBuilder.build());
            
            List<String> objectKeys = response.contents().stream()
                    .map(S3Object::key)
                    .collect(Collectors.toList());
            
            logger.info("Found {} objects in bucket {} with prefix '{}'", 
                       objectKeys.size(), bucketName, prefix);
            return objectKeys;
        } catch (S3Exception e) {
            logger.error("Failed to list objects in bucket {} with prefix '{}': {}", 
                        bucketName, prefix, e.getMessage());
            throw new RuntimeException("Failed to list objects in S3", e);
        }
    }

    /**
     * Delete object from S3 bucket.
     */
    public void deleteFile(String bucketName, String key) {
        validateInputs(bucketName, key);
        
        try {
            DeleteObjectRequest deleteObjectRequest = DeleteObjectRequest.builder()
                    .bucket(bucketName)
                    .key(key)
                    .build();

            s3Client.deleteObject(deleteObjectRequest);
            logger.info("Successfully deleted file {} from bucket {}", key, bucketName);
        } catch (S3Exception e) {
            logger.error("Failed to delete file {} from bucket {}: {}", key, bucketName, e.getMessage());
            throw new RuntimeException("Failed to delete file from S3", e);
        }
    }

    /**
     * Get default bucket name for the application.
     */
    public String getDefaultBucket() {
        return defaultBucket;
    }

    // Validation helpers
    private void validateInputs(String bucketName, String key) {
        validateBucketName(bucketName);
        if (key == null || key.trim().isEmpty()) {
            throw new IllegalArgumentException("Object key cannot be null or empty");
        }
    }

    private void validateBucketName(String bucketName) {
        if (bucketName == null || bucketName.trim().isEmpty()) {
            throw new IllegalArgumentException("Bucket name cannot be null or empty");
        }
    }
}
```

### Step 6: Create REST Controller

Create `src/main/java/com/example/awsdemo/controller/S3Controller.java`:

```java
package com.example.awsdemo.controller;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.awsdemo.service.S3Service;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;

/**
 * REST Controller for S3 operations.
 * 
 * Provides endpoints for:
 * - File upload and download
 * - Listing bucket contents
 * - File deletion
 * - Health checks
 */
@RestController
@RequestMapping("/api/s3")
public class S3Controller {

    private static final Logger logger = LoggerFactory.getLogger(S3Controller.class);

    private final S3Service s3Service;

    public S3Controller(S3Service s3Service) {
        this.s3Service = s3Service;
    }

    /**
     * Health check endpoint to verify S3 connectivity.
     */
    @GetMapping("/health")
    public ResponseEntity<Map<String, Object>> health() {
        try {
            String defaultBucket = s3Service.getDefaultBucket();
            boolean bucketExists = s3Service.doesBucketExist(defaultBucket);
            
            return ResponseEntity.ok(Map.of(
                "status", "UP",
                "service", "S3",
                "defaultBucket", defaultBucket,
                "bucketAccessible", bucketExists
            ));
        } catch (Exception e) {
            logger.error("S3 health check failed", e);
            return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE)
                    .body(Map.of(
                        "status", "DOWN",
                        "service", "S3",
                        "error", e.getMessage()
                    ));
        }
    }

    /**
     * Upload file content to S3.
     */
    @PostMapping("/files")
    public ResponseEntity<Map<String, String>> uploadFile(
            @Valid @RequestBody FileUploadRequest request) {
        try {
            String bucketName = request.bucketName() != null ? 
                              request.bucketName() : s3Service.getDefaultBucket();
            
            s3Service.uploadFile(bucketName, request.key(), request.content());
            
            return ResponseEntity.ok(Map.of(
                "message", "File uploaded successfully",
                "bucket", bucketName,
                "key", request.key()
            ));
        } catch (Exception e) {
            logger.error("Failed to upload file", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "Failed to upload file: " + e.getMessage()));
        }
    }

    /**
     * Download file content from S3.
     */
    @GetMapping("/files/{key}")
    public ResponseEntity<Map<String, String>> downloadFile(
            @PathVariable String key,
            @RequestParam(required = false) String bucket) {
        try {
            String bucketName = bucket != null ? bucket : s3Service.getDefaultBucket();
            String content = s3Service.downloadFile(bucketName, key);
            
            return ResponseEntity.ok(Map.of(
                "content", content,
                "bucket", bucketName,
                "key", key
            ));
        } catch (Exception e) {
            logger.error("Failed to download file", e);
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("error", "Failed to download file: " + e.getMessage()));
        }
    }

    /**
     * List objects in bucket.
     */
    @GetMapping("/files")
    public ResponseEntity<Map<String, Object>> listFiles(
            @RequestParam(required = false) String bucket,
            @RequestParam(required = false) String prefix) {
        try {
            String bucketName = bucket != null ? bucket : s3Service.getDefaultBucket();
            List<String> objects = s3Service.listObjects(bucketName, prefix);
            
            return ResponseEntity.ok(Map.of(
                "objects", objects,
                "bucket", bucketName,
                "prefix", prefix != null ? prefix : "",
                "count", objects.size()
            ));
        } catch (Exception e) {
            logger.error("Failed to list files", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "Failed to list files: " + e.getMessage()));
        }
    }

    /**
     * Delete file from S3.
     */
    @DeleteMapping("/files/{key}")
    public ResponseEntity<Map<String, String>> deleteFile(
            @PathVariable String key,
            @RequestParam(required = false) String bucket) {
        try {
            String bucketName = bucket != null ? bucket : s3Service.getDefaultBucket();
            s3Service.deleteFile(bucketName, key);
            
            return ResponseEntity.ok(Map.of(
                "message", "File deleted successfully",
                "bucket", bucketName,
                "key", key
            ));
        } catch (Exception e) {
            logger.error("Failed to delete file", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "Failed to delete file: " + e.getMessage()));
        }
    }

    /**
     * Request record for file upload.
     */
    public record FileUploadRequest(
            @NotBlank(message = "Key is required") String key,
            @NotBlank(message = "Content is required") String content,
            String bucketName
    ) {}
}
```

### Step 7: Create Application Configuration

Create `src/main/resources/application.yml`:

```yaml
# Default configuration
spring:
  application:
    name: spring-aws-demo
  profiles:
    active: dev

# AWS Configuration
aws:
  region: us-east-1
  profile: default
  s3:
    default-bucket: ${AWS_S3_BUCKET:spring-aws-demo-bucket-${random.uuid}}

# Server Configuration
server:
  port: 8080
  servlet:
    context-path: /

# Actuator Configuration
management:
  endpoints:
    web:
      exposure:
        include: health,info,metrics
  endpoint:
    health:
      show-details: always

# Logging Configuration
logging:
  level:
    com.example.awsdemo: DEBUG
    software.amazon.awssdk: WARN
    org.springframework.web: INFO
  pattern:
    console: "%d{yyyy-MM-dd HH:mm:ss} - %msg%n"
    file: "%d{yyyy-MM-dd HH:mm:ss} [%thread] %-5level %logger{36} - %msg%n"

---
# Development Profile
spring:
  config:
    activate:
      on-profile: dev

logging:
  level:
    com.example.awsdemo: DEBUG

---
# Production Profile
spring:
  config:
    activate:
      on-profile: prod

logging:
  level:
    com.example.awsdemo: INFO
    software.amazon.awssdk: WARN
```

### Step 8: Create Test Configuration

Create `src/test/java/com/example/awsdemo/SpringAwsDemoApplicationTests.java`:

```java
package com.example.awsdemo;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import com.example.awsdemo.service.S3Service;

@SpringBootTest
@ActiveProfiles("test")
class SpringAwsDemoApplicationTests {

    @Autowired
    private S3Service s3Service;

    @Test
    void contextLoads() {
        assertNotNull(s3Service);
    }
}
```

### Step 9: Build and Test the Application

```bash
# Build the application
mvn clean compile

# Run tests (will use mock AWS services)
mvn test

# Start the application
mvn spring-boot:run

# In another terminal, test the health endpoint
curl http://localhost:8080/api/s3/health
```

### Step 10: Test S3 Operations

First, create an S3 bucket for testing:

```bash
# Create test bucket (replace with unique name)
aws s3 mb s3://your-unique-bucket-name-$(date +%s)

# Set the bucket name in application.yml or environment variable
export AWS_S3_BUCKET=your-unique-bucket-name
```

Test the API endpoints:

```bash
# 1. Check health
curl http://localhost:8080/api/s3/health

# 2. Upload a file
curl -X POST http://localhost:8080/api/s3/files \
  -H "Content-Type: application/json" \
  -d '{
    "key": "test-file.txt",
    "content": "Hello from Spring Boot and AWS!"
  }'

# 3. List files
curl http://localhost:8080/api/s3/files

# 4. Download the file
curl http://localhost:8080/api/s3/files/test-file.txt

# 5. Delete the file
curl -X DELETE http://localhost:8080/api/s3/files/test-file.txt
```

---

## ✅ Verification Checklist

After completing this lab, verify:

- [ ] **Application starts successfully** without errors
- [ ] **Health endpoint returns UP status** with S3 connectivity
- [ ] **File upload works** and returns success message
- [ ] **File download returns correct content**
- [ ] **File listing shows uploaded files**
- [ ] **File deletion removes files successfully**
- [ ] **Error handling works** for invalid operations
- [ ] **Logs show appropriate debug information**

---

## 🎯 Key Learning Points

### 1. AWS SDK v2 Integration
- Modern reactive programming model
- Better performance and memory usage
- Native support for Java 21 features

### 2. Credential Management
- Different providers for different environments
- Security best practices (no hardcoded keys)
- Automatic credential chain resolution

### 3. Error Handling
- Specific AWS exception handling
- User-friendly error messages
- Proper logging for debugging

### 4. Spring Boot Best Practices
- Configuration externalization
- Profile-based configuration
- Health checks and monitoring

---

## 🚀 Next Steps

### Prepare for Cloud Deployment
1. **Create IAM Role** for EC2 instances
2. **Test with different AWS profiles**
3. **Implement additional S3 features** (multipart upload, versioning)
4. **Add integration tests** with LocalStack

### Advanced Features to Explore
1. **S3 Event Notifications** with SQS/SNS
2. **Pre-signed URLs** for secure file access
3. **S3 Transfer Manager** for large files
4. **Cross-region replication**

---

## 🔧 Troubleshooting

### Common Issues

**Issue**: `NoCredentialsException`
```
Solution: 
1. Check AWS CLI configuration: aws configure list
2. Verify IAM user has S3 permissions
3. Check profile name in application.yml
```

**Issue**: `NoSuchBucketException`
```
Solution:
1. Create bucket: aws s3 mb s3://your-bucket-name
2. Check bucket name in configuration
3. Verify bucket region matches AWS configuration
```

**Issue**: `AccessDeniedException`
```
Solution:
1. Check IAM policy includes required S3 permissions
2. Verify bucket policy allows access
3. Check if MFA is required
```

---

## 📝 Certification Notes

### SAA-C03 Relevance
- **Domain 1**: Secure access to AWS resources (IAM roles, policies)
- **Domain 3**: High-performing architectures (S3 optimization)
- **Best Practices**: Credential management, error handling, monitoring

### Key Exam Points
- **IAM Roles vs. Users**: Applications should use roles, not users
- **AWS SDK Best Practices**: Use default credential provider chain
- **S3 Security**: Bucket policies, ACLs, encryption
- **Error Handling**: Graceful degradation and retry logic

---

**Congratulations!** 🎉 You've successfully integrated AWS SDK v2 with Spring Boot 3 and Java 21. This foundation will be used throughout the remaining modules for building cloud-native applications.

**Next**: Move to [Module 2: Compute (EC2, ASG, ELB)](../../module-02-compute/README.md) to deploy this application to AWS infrastructure.
