# What is Cloud Computing?

## 🎯 Learning Objectives
- Understand the fundamental concepts of cloud computing
- Differentiate between cloud service models (IaaS, PaaS, SaaS)
- Compare cloud deployment models (Public, Private, Hybrid, Multi-cloud)
- Identify business benefits of cloud adoption

---

## 📖 Introduction to Cloud Computing

Cloud computing is the **on-demand delivery of IT resources** over the Internet with **pay-as-you-go pricing**. Instead of buying, owning, and maintaining physical data centers and servers, you can access technology services, such as computing power, storage, and databases, on an as-needed basis from a cloud provider like Amazon Web Services (AWS).

### Key Characteristics

1. **On-Demand Self-Service**
   - Users can provision computing capabilities automatically without requiring human interaction with service providers

2. **Broad Network Access**
   - Capabilities are available over the network and accessed through standard mechanisms

3. **Resource Pooling**
   - Provider's computing resources are pooled to serve multiple consumers using a multi-tenant model

4. **Rapid Elasticity**
   - Capabilities can be elastically provisioned and released to scale rapidly with demand

5. **Measured Service**
   - Cloud systems automatically control and optimize resource use by leveraging metering capabilities

---

## 🏗️ Cloud Service Models

### Infrastructure as a Service (IaaS)
**Definition**: Provides virtualized computing resources over the internet.

**What you manage**: Operating systems, middleware, runtime, data, applications
**What cloud provider manages**: Virtualization, servers, storage, networking

**AWS Examples**:
- Amazon EC2 (Elastic Compute Cloud)
- Amazon VPC (Virtual Private Cloud)
- Amazon EBS (Elastic Block Store)

**Use Cases**:
- Lift-and-shift migrations
- Development and testing environments
- Big data analytics
- High-performance computing

**Java Developer Perspective**:
```java
// Example: Running Spring Boot on EC2
// You manage: JVM, Spring Boot app, OS patches
// AWS manages: Physical hardware, hypervisor, networking
@SpringBootApplication
public class MyApplication {
    public static void main(String[] args) {
        SpringApplication.run(MyApplication.class, args);
    }
}
```

### Platform as a Service (PaaS)
**Definition**: Provides a platform allowing customers to develop, run, and manage applications.

**What you manage**: Data, applications
**What cloud provider manages**: Runtime, middleware, operating systems, virtualization, servers, storage, networking

**AWS Examples**:
- AWS Elastic Beanstalk
- AWS Lambda
- Amazon RDS (Relational Database Service)

**Use Cases**:
- Rapid application development
- API development and management
- Microservices architecture
- IoT applications

**Java Developer Perspective**:
```java
// Example: Spring Boot on Elastic Beanstalk
// You manage: Application code and configuration
// AWS manages: Java runtime, application server, OS, scaling
@RestController
public class HealthController {
    @GetMapping("/health")
    public ResponseEntity<String> health() {
        return ResponseEntity.ok("Application is healthy");
    }
}
```

### Software as a Service (SaaS)
**Definition**: Provides software applications over the internet, on a subscription basis.

**What you manage**: User access and data
**What cloud provider manages**: Applications, data, runtime, middleware, operating systems, virtualization, servers, storage, networking

**AWS Examples**:
- Amazon WorkSpaces
- Amazon Chime
- AWS Organizations

**Use Cases**:
- Email and collaboration
- Customer relationship management
- Enterprise resource planning
- Human resources management

---

## 🌐 Cloud Deployment Models

### Public Cloud
- **Definition**: Cloud services offered over the public internet and available to anyone who wants to purchase them
- **Ownership**: Third-party cloud service provider
- **Examples**: AWS, Microsoft Azure, Google Cloud Platform
- **Benefits**: Lower costs, no maintenance, near-unlimited scalability
- **Considerations**: Less control, potential security concerns for sensitive data

### Private Cloud
- **Definition**: Cloud computing resources used exclusively by a single business or organization
- **Ownership**: Can be owned by the organization or a third party
- **Location**: On-premises or off-premises
- **Benefits**: More control, enhanced security, customization
- **Considerations**: Higher costs, maintenance responsibility

### Hybrid Cloud
- **Definition**: Combines public and private clouds, allowing data and applications to be shared between them
- **Use Cases**: 
  - Keep sensitive data in private cloud
  - Use public cloud for less sensitive operations
  - Burst to public cloud during peak demand
- **Benefits**: Flexibility, cost optimization, compliance

### Multi-Cloud
- **Definition**: Uses multiple cloud computing services from different providers
- **Benefits**: Avoid vendor lock-in, optimize costs, leverage best-of-breed services
- **Challenges**: Increased complexity, integration challenges

---

## 🎯 Business Benefits of Cloud Computing

### 1. Cost Benefits
- **Capital Expenditure to Operating Expenditure**: No upfront hardware costs
- **Pay-as-you-go**: Only pay for what you use
- **Economies of Scale**: Benefit from cloud provider's purchasing power

### 2. Speed and Agility
- **Rapid Provisioning**: Resources available in minutes
- **Global Deployment**: Deploy applications worldwide quickly
- **Innovation**: Focus on business logic rather than infrastructure

### 3. Scalability and Elasticity
- **Auto Scaling**: Automatically scale resources based on demand
- **Global Scale**: Access to worldwide infrastructure
- **Performance**: High-performance computing capabilities

### 4. Reliability and Disaster Recovery
- **High Availability**: Built-in redundancy and failover
- **Backup and Recovery**: Automated backup solutions
- **Data Durability**: Multiple copies of data across regions

### 5. Security
- **Professional Security**: Dedicated security teams
- **Compliance**: Meet various compliance requirements
- **Encryption**: Data encryption in transit and at rest

---

## 🏢 Cloud Adoption Strategies

### 1. Rehost ("Lift and Shift")
- Move applications to cloud without changes
- Quick migration with immediate cost benefits
- Example: Moving Spring Boot app from on-premises to EC2

### 2. Replatform ("Lift, Tinker, and Shift")
- Make minor optimizations during migration
- Example: Moving database to Amazon RDS

### 3. Refactor/Re-architect
- Redesign applications to be cloud-native
- Example: Breaking monolith into microservices using Lambda

### 4. Repurchase
- Replace existing application with cloud-based solution
- Example: Moving from on-premises email to Amazon WorkMail

### 5. Retain
- Keep applications in existing environment
- Usually for applications that can't be migrated

### 6. Retire
- Decommission applications that are no longer needed

---

## 🔍 Real-World Example: E-commerce Platform

### Traditional On-Premises Setup
```
Problem: Online retailer with seasonal traffic spikes
- Peak season: 10x normal traffic
- Must provision for peak capacity year-round
- High upfront costs for hardware
- Long procurement cycles
```

### Cloud Solution
```
Solution: AWS-based architecture
- Auto Scaling Groups for web servers
- Amazon RDS for database
- CloudFront for content delivery
- S3 for static content storage

Benefits:
- Scale automatically during peak seasons
- Pay only for resources used
- Deploy new features faster
- Global reach with CDN
```

### Java Implementation Snippet
```java
@Service
public class OrderService {
    
    @Autowired
    private AmazonS3 s3Client;
    
    @Autowired
    private AmazonDynamoDB dynamoClient;
    
    public Order processOrder(Order order) {
        // Store order in DynamoDB
        dynamoClient.putItem(order.toAttributeValueMap());
        
        // Generate receipt and store in S3
        String receipt = generateReceipt(order);
        s3Client.putObject("receipts-bucket", 
                          order.getId() + ".pdf", 
                          receipt);
        
        return order;
    }
}
```

---

## 📝 Key Takeaways

1. **Cloud computing is about agility and efficiency** - Focus on business value, not infrastructure management

2. **Choose the right service model** - IaaS for control, PaaS for rapid development, SaaS for standardized solutions

3. **Start with public cloud** - Most cost-effective for new projects and startups

4. **Plan your migration strategy** - Consider business impact and technical complexity

5. **Security is a shared responsibility** - Understand what you're responsible for vs. the cloud provider

---

## 🎯 Certification Notes (SAA-C03)

### Key Exam Points:
- **Service Models**: Understand what you manage vs. what AWS manages in each model
- **Deployment Models**: Know when to use public, private, or hybrid cloud
- **Benefits**: Cost optimization, scalability, reliability, security
- **Migration Strategies**: 6 R's of migration

### Common Exam Scenarios:
1. "Company wants to move applications to cloud but maintain full control" → Private Cloud or IaaS
2. "Startup needs to deploy applications quickly without managing infrastructure" → PaaS (Elastic Beanstalk)
3. "Enterprise needs to keep sensitive data on-premises but use cloud for development" → Hybrid Cloud

---

## 🔗 Additional Resources

- [AWS Cloud Computing Concepts](https://aws.amazon.com/what-is-cloud-computing/)
- [Cloud Adoption Framework](https://aws.amazon.com/cloud-adoption-framework/)
- [AWS Well-Architected Framework](https://aws.amazon.com/architecture/well-architected/)

---

**Next**: [AWS Global Infrastructure](./02-aws-infrastructure.md)
