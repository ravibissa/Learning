# Identity and Access Management (IAM)

## 🎯 Learning Objectives
- Understand IAM fundamentals and core components
- Learn how to implement least privilege access
- Master IAM policies and permission evaluation
- Apply IAM best practices for Java applications
- Design secure authentication and authorization patterns

---

## 📖 What is IAM?

AWS Identity and Access Management (IAM) is a web service that helps you **securely control access to AWS resources**. You use IAM to control who is authenticated (signed in) and authorized (has permissions) to use resources.

### Core Benefits
- **Fine-grained access control** to AWS resources
- **Shared access** to your AWS account
- **Granular permissions** for different users and applications
- **Identity federation** with corporate directories
- **Multi-factor authentication (MFA)** for enhanced security
- **No additional charges** - IAM is provided at no additional cost

---

## 🏗️ IAM Core Components

### 1. Users
**Definition**: An IAM user is an entity that represents a person or service that interacts with AWS.

**Characteristics**:
- Has a unique name within the AWS account
- Can have long-term credentials (password and/or access keys)
- Can be assigned directly to policies or groups
- Has a unique Amazon Resource Name (ARN)

**Best Practices**:
- Create individual users for each person
- Don't share user credentials
- Use strong passwords and enable MFA
- Rotate access keys regularly

**Example ARN**: `arn:aws:iam::123456789012:user/john-developer`

### 2. Groups
**Definition**: An IAM group is a collection of IAM users. Groups let you specify permissions for multiple users.

**Characteristics**:
- Groups cannot be nested (groups cannot contain other groups)
- Users can belong to multiple groups
- No default group for new users
- Groups can have multiple policies attached

**Common Group Examples**:
```
Developers Group:
├── EC2 Read/Write
├── S3 Development Bucket Access
└── CloudWatch Logs Read

DevOps Group:
├── EC2 Full Access
├── CloudFormation Full Access
├── IAM Limited Access
└── CloudWatch Full Access

Administrators Group:
└── AdministratorAccess (Full AWS Access)
```

### 3. Roles
**Definition**: An IAM role is an IAM identity that has specific permissions. Unlike users, roles are not associated with a specific person.

**Key Concepts**:
- **Assumable**: Roles can be assumed by users, applications, or services
- **Temporary credentials**: When you assume a role, you get temporary security credentials
- **Cross-account access**: Roles can be assumed across AWS accounts
- **Service roles**: AWS services can assume roles to access other services

**Common Role Types**:

#### Service Roles
```java
// Example: EC2 instance role for S3 access
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "Service": "ec2.amazonaws.com"
      },
      "Action": "sts:AssumeRole"
    }
  ]
}
```

#### Cross-Account Roles
```java
// Example: Allow another AWS account to assume role
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "AWS": "arn:aws:iam::ACCOUNT-B:root"
      },
      "Action": "sts:AssumeRole",
      "Condition": {
        "StringEquals": {
          "sts:ExternalId": "unique-external-id"
        }
      }
    }
  ]
}
```

### 4. Policies
**Definition**: Policies are documents that define permissions. They are written in JSON and specify what actions are allowed or denied.

**Policy Types**:

#### Managed Policies
- **AWS Managed**: Created and maintained by AWS
- **Customer Managed**: Created and maintained by you
- **Can be attached to multiple users, groups, or roles**

#### Inline Policies
- **Directly embedded** in a single user, group, or role
- **One-to-one relationship** between policy and identity
- **Deleted when the identity is deleted**

#### Resource-Based Policies
- **Attached to resources** (S3 buckets, SQS queues, etc.)
- **Specify who can access the resource and what actions they can perform**

---

## 📋 IAM Policy Structure

### Policy Document Format
```json
{
  "Version": "2012-10-17",
  "Id": "PolicyId",
  "Statement": [
    {
      "Sid": "StatementId",
      "Effect": "Allow",
      "Principal": "arn:aws:iam::123456789012:user/username",
      "Action": "s3:GetObject",
      "Resource": "arn:aws:s3:::my-bucket/*",
      "Condition": {
        "StringEquals": {
          "s3:x-amz-server-side-encryption": "AES256"
        }
      }
    }
  ]
}
```

### Policy Elements Explained

#### Version
- **Required**: Specifies the policy language version
- **Current version**: "2012-10-17"
- **Legacy version**: "2008-10-17" (avoid using)

#### Statement
- **Required**: Main policy element containing permission details
- **Can be a single statement or array of statements**

#### Sid (Statement ID)
- **Optional**: Unique identifier for the statement
- **Best practice**: Use descriptive names

#### Effect
- **Required**: Either "Allow" or "Deny"
- **Explicit deny always overrides allow**

#### Principal
- **Used in resource-based policies**: Specifies who the statement applies to
- **Not used in identity-based policies**

#### Action
- **Required**: Specifies the action(s) that the statement applies to
- **Format**: service:action (e.g., s3:GetObject)
- **Wildcards supported**: s3:*, *

#### Resource
- **Specifies the resource(s)** that the statement applies to
- **Uses ARN format**
- **Wildcards supported**

#### Condition
- **Optional**: Specifies circumstances under which the policy grants permission
- **Uses condition operators and context keys**

---

## 🔐 Permission Evaluation Logic

### Policy Evaluation Flow
```
1. By default, all requests are DENIED
2. Explicit ALLOW in identity-based policy → ALLOWED
3. Explicit DENY in any policy → DENIED (overrides allow)
4. If no explicit allow → DENIED

Evaluation Order:
1. Identity-based policies (user, group, role)
2. Resource-based policies
3. Permissions boundaries
4. Organizations SCPs (Service Control Policies)
5. Session policies
```

### Java Code Example: Understanding Permissions
```java
@Service
public class S3Service {
    
    private final AmazonS3 s3Client;
    
    public S3Service(AmazonS3 s3Client) {
        this.s3Client = s3Client;
    }
    
    public String downloadFile(String bucketName, String key) {
        try {
            // This operation requires:
            // 1. s3:GetObject permission on the object
            // 2. s3:ListBucket permission if using object existence check
            S3Object s3Object = s3Client.getObject(bucketName, key);
            return s3Object.getObjectContent().toString();
        } catch (AmazonS3Exception e) {
            if (e.getStatusCode() == 403) {
                log.error("Access denied. Check IAM permissions for s3:GetObject");
            }
            throw e;
        }
    }
    
    public void uploadFile(String bucketName, String key, String content) {
        try {
            // This operation requires:
            // 1. s3:PutObject permission on the object
            // 2. Potentially s3:PutObjectAcl if setting ACLs
            s3Client.putObject(bucketName, key, content);
        } catch (AmazonS3Exception e) {
            if (e.getStatusCode() == 403) {
                log.error("Access denied. Check IAM permissions for s3:PutObject");
            }
            throw e;
        }
    }
}
```

---

## 🛡️ Security Best Practices

### 1. Principle of Least Privilege
Grant only the permissions required to perform a task.

**Example**: Developer accessing S3 bucket for application data
```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "AllowAppBucketAccess",
      "Effect": "Allow",
      "Action": [
        "s3:GetObject",
        "s3:PutObject",
        "s3:DeleteObject"
      ],
      "Resource": "arn:aws:s3:::my-app-data/*"
    },
    {
      "Sid": "AllowListingAppBucket",
      "Effect": "Allow",
      "Action": "s3:ListBucket",
      "Resource": "arn:aws:s3:::my-app-data",
      "Condition": {
        "StringLike": {
          "s3:prefix": "user-uploads/*"
        }
      }
    }
  ]
}
```

### 2. Use Roles for Applications
Never embed access keys in application code.

**Spring Boot Configuration Example**:
```java
@Configuration
public class AwsConfig {
    
    @Bean
    public AmazonS3 amazonS3() {
        // Use DefaultAWSCredentialsProviderChain
        // This automatically looks for credentials in order:
        // 1. Environment variables
        // 2. Java system properties
        // 3. Credential profiles file
        // 4. EC2 Instance Metadata (IAM roles)
        return AmazonS3ClientBuilder
            .standard()
            .withCredentials(DefaultAWSCredentialsProviderChain.getInstance())
            .withRegion(Regions.US_EAST_1)
            .build();
    }
}

// Application properties for local development
# application-dev.yml
cloud:
  aws:
    credentials:
      profile-name: dev-profile
    region:
      static: us-east-1
```

### 3. Enable Multi-Factor Authentication (MFA)
Require MFA for sensitive operations.

**Policy Example**: Require MFA for S3 deletion
```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "AllowS3ReadWithoutMFA",
      "Effect": "Allow",
      "Action": [
        "s3:GetObject",
        "s3:ListBucket"
      ],
      "Resource": [
        "arn:aws:s3:::my-bucket",
        "arn:aws:s3:::my-bucket/*"
      ]
    },
    {
      "Sid": "DenyDeleteWithoutMFA",
      "Effect": "Deny",
      "Action": "s3:DeleteObject",
      "Resource": "arn:aws:s3:::my-bucket/*",
      "Condition": {
        "BoolIfExists": {
          "aws:MultiFactorAuthPresent": "false"
        }
      }
    }
  ]
}
```

### 4. Regular Access Reviews
Implement regular access reviews and cleanup.

**Java Tool Example**: IAM Access Analyzer
```java
@Service
public class IamAuditService {
    
    private final AmazonIdentityManagement iamClient;
    
    public List<UnusedCredentials> findUnusedCredentials() {
        List<UnusedCredentials> unused = new ArrayList<>();
        
        // Get all users
        ListUsersResult users = iamClient.listUsers();
        
        for (User user : users.getUsers()) {
            // Check last activity
            GetUserResult userDetail = iamClient.getUser(
                new GetUserRequest().withUserName(user.getUserName())
            );
            
            Date lastActivity = userDetail.getUser().getPasswordLastUsed();
            if (lastActivity != null && 
                lastActivity.before(Date.from(Instant.now().minus(90, ChronoUnit.DAYS)))) {
                unused.add(new UnusedCredentials(user.getUserName(), lastActivity));
            }
        }
        
        return unused;
    }
}
```

---

## 🎯 Common IAM Patterns for Java Applications

### 1. Application Role Pattern
**Use Case**: EC2 instance running Spring Boot application needs AWS access

```java
// 1. Create IAM role for EC2
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "Service": "ec2.amazonaws.com"
      },
      "Action": "sts:AssumeRole"
    }
  ]
}

// 2. Attach policy to role
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "s3:GetObject",
        "s3:PutObject"
      ],
      "Resource": "arn:aws:s3:::my-app-bucket/*"
    }
  ]
}

// 3. Spring Boot automatically uses instance metadata
@Service
public class FileService {
    @Autowired
    private AmazonS3 s3Client; // Automatically uses IAM role
    
    public void uploadFile(String content) {
        s3Client.putObject("my-app-bucket", "file.txt", content);
    }
}
```

### 2. Cross-Account Access Pattern
**Use Case**: Production application in Account A needs to access resources in Account B

```java
@Service
public class CrossAccountService {
    
    public void accessCrossAccountResource() {
        // Assume role in another account
        AWSSecurityTokenService stsClient = AWSSecurityTokenServiceClientBuilder
            .defaultClient();
            
        AssumeRoleRequest assumeRoleRequest = new AssumeRoleRequest()
            .withRoleArn("arn:aws:iam::ACCOUNT-B:role/CrossAccountRole")
            .withRoleSessionName("SpringBootSession")
            .withDurationSeconds(3600);
            
        AssumeRoleResult assumeRoleResult = stsClient.assumeRole(assumeRoleRequest);
        Credentials credentials = assumeRoleResult.getCredentials();
        
        // Create temporary credentials
        BasicSessionCredentials sessionCredentials = new BasicSessionCredentials(
            credentials.getAccessKeyId(),
            credentials.getSecretAccessKey(),
            credentials.getSessionToken()
        );
        
        // Use temporary credentials
        AmazonS3 s3Client = AmazonS3ClientBuilder.standard()
            .withCredentials(new AWSStaticCredentialsProvider(sessionCredentials))
            .withRegion(Regions.US_EAST_1)
            .build();
            
        // Access resources in Account B
        s3Client.listObjects("account-b-bucket");
    }
}
```

### 3. Federated Access Pattern
**Use Case**: Corporate users access AWS through Active Directory

```java
@Configuration
public class FederatedAuthConfig {
    
    @Bean
    public AWSCredentialsProvider federatedCredentialsProvider() {
        return new STSAssumeRoleWithWebIdentitySessionCredentialsProvider.Builder(
            "arn:aws:iam::123456789012:role/FederatedRole",
            "session-name",
            "web-identity-token"
        ).build();
    }
}
```

---

## 📊 IAM Limits and Considerations

### Default Limits
| Resource | Default Limit | Adjustable |
|----------|---------------|------------|
| Users per account | 5,000 | Yes |
| Groups per account | 300 | Yes |
| Roles per account | 1,000 | Yes |
| Managed policies per account | 1,500 | Yes |
| Policy size | 6,144 characters | No |
| Policies per user/group/role | 10 | Yes |

### Performance Considerations
- **Policy evaluation time**: More complex policies take longer to evaluate
- **Policy size**: Smaller policies evaluate faster
- **Condition complexity**: Simple conditions are faster than complex ones

---

## 🎓 Certification Notes (SAA-C03)

### Key Exam Topics
1. **IAM Users vs. Roles**: When to use each
2. **Policy Types**: Managed vs. inline vs. resource-based
3. **Permission Evaluation**: Understand explicit deny overrides allow
4. **Cross-Account Access**: How to set up securely
5. **MFA Implementation**: When and how to require MFA
6. **Least Privilege**: How to implement and examples

### Common Exam Scenarios
1. **"Application needs temporary AWS access"** → Use IAM Roles
2. **"Block all actions except with MFA"** → Use condition with aws:MultiFactorAuthPresent
3. **"Grant minimum required permissions"** → Apply least privilege principle
4. **"Share access across AWS accounts"** → Use cross-account IAM roles

### Exam Tips
- **Always choose roles over users** for applications and services
- **Resource-based policies** are attached to resources, not identities
- **Explicit deny always wins** over explicit allow
- **MFA conditions** can be used to enforce additional security

---

## 🔗 Additional Resources

- [IAM User Guide](https://docs.aws.amazon.com/IAM/latest/UserGuide/)
- [IAM Best Practices](https://docs.aws.amazon.com/IAM/latest/UserGuide/best-practices.html)
- [IAM Policy Simulator](https://policysim.aws.amazon.com/)
- [AWS Security Blog](https://aws.amazon.com/blogs/security/)

---

**Next**: [AWS CLI & SDK Overview](./05-cli-sdk.md)
