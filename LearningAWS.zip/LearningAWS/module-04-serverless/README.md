# Module 4: Serverless (Lambda, API Gateway, EventBridge)
**Duration**: 10 hours | **Level**: Intermediate to Advanced | **Certification**: SAA-C03 Domain 2 & 3

## 🎯 Learning Objectives

By the end of this module, you will be able to:
- Build serverless applications using AWS Lambda with Java 21
- Design API-first architectures with API Gateway
- Implement event-driven patterns using EventBridge and SQS
- Create serverless data processing pipelines
- Apply cost optimization strategies for serverless workloads
- Monitor and debug serverless applications effectively

---

## 📚 Module Contents

### 📖 Theory & Concepts
- **Serverless Fundamentals**: FaaS, event-driven architecture, serverless patterns
- **AWS Lambda Deep Dive**: Runtime, execution model, cold starts, performance
- **API Gateway**: REST vs HTTP APIs, authentication, throttling, caching
- **Event-Driven Architecture**: EventBridge, SQS, SNS, Step Functions
- **Serverless Security**: IAM roles, VPC, secrets management

### 💻 Code Examples
- **Java 21 Lambda Functions**: Native compilation, virtual threads, performance optimization
- **Spring Cloud Function**: Portable function development with Spring Boot
- **API Gateway Integration**: Request/response transformation, validation
- **Event Processing**: EventBridge rules, SQS message processing
- **Serverless Patterns**: CQRS, Event Sourcing, Saga pattern

### 🎯 Hands-on Labs
- **Lab 1**: Java Lambda Functions - Order processing service
- **Lab 2**: API Gateway Setup - Serverless REST API
- **Lab 3**: Event-Driven Architecture - Order fulfillment system
- **Lab 4**: Serverless Data Pipeline - Real-time analytics
- **Lab 5**: Production Deployment - CI/CD and monitoring

---

## 🏗️ Serverless Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                          Serverless Event-Driven Architecture                  │
│                                                                                 │
│  ┌─────────────────┐    ┌─────────────────────────────────────────────────┐   │
│  │   Client Apps   │    │                API Gateway                      │   │
│  │  • Web Apps     │───▶│  • Authentication                               │   │
│  │  • Mobile Apps  │    │  • Rate limiting                                │   │
│  │  • IoT Devices  │    │  • Request validation                           │   │
│  └─────────────────┘    └─────────────────────────────────────────────────┘   │
│                                           │                                     │
│                                           ▼                                     │
│  ┌─────────────────────────────────────────────────────────────────────────┐   │
│  │                        AWS Lambda Functions                             │   │
│  │                                                                         │   │
│  │  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────────────┐ │   │
│  │  │  Order Service  │  │ Payment Service │  │  Notification Service  │ │   │
│  │  │  • Java 21      │  │  • Java 21      │  │  • Java 21             │ │   │
│  │  │  • Spring Cloud │  │  • Native Image │  │  • Event processing    │ │   │
│  │  │  • Function     │  │  • Fast startup │  │  • SQS integration     │ │   │
│  │  └─────────────────┘  └─────────────────┘  └─────────────────────────┘ │   │
│  └─────────────────────────────────────────────────────────────────────────┘   │
│                                           │                                     │
│                                           ▼                                     │
│  ┌─────────────────────────────────────────────────────────────────────────┐   │
│  │                        Event Processing Layer                          │   │
│  │                                                                         │   │
│  │  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────────────┐ │   │
│  │  │   EventBridge   │  │       SQS       │  │      Step Functions     │ │   │
│  │  │  • Event routing│  │  • Message queue│  │  • Workflow orchestr.  │ │   │
│  │  │  • Schema registry│ │  • DLQ handling │  │  • Error handling      │ │   │
│  │  │  • Event replay │  │  • Batch processing│ │  • State management   │ │   │
│  │  └─────────────────┘  └─────────────────┘  └─────────────────────────┘ │   │
│  └─────────────────────────────────────────────────────────────────────────┘   │
│                                           │                                     │
│                                           ▼                                     │
│  ┌─────────────────────────────────────────────────────────────────────────┐   │
│  │                          Data Layer                                     │   │
│  │                                                                         │   │
│  │  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────────────┐ │   │
│  │  │    DynamoDB     │  │       S3        │  │      ElastiCache       │ │   │
│  │  │  • Event store  │  │  • Object storage│ │  • Caching layer       │ │   │
│  │  │  • High speed   │  │  • Static content│ │  • Session storage     │ │   │
│  │  │  • Auto scaling │  │  • Data lake    │  │  • Performance boost   │ │   │
│  │  └─────────────────┘  └─────────────────┘  └─────────────────────────┘ │   │
│  └─────────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────────┘
```

---

## 🎯 Key Learning Topics

### AWS Lambda with Java 21 (3 hours)
- **Runtime Environment**: Java 21 features in Lambda
- **Performance Optimization**: Cold start reduction, memory tuning
- **Spring Cloud Function**: Framework-agnostic function development
- **Native Compilation**: GraalVM for ultra-fast startup

### API Gateway (2 hours)
- **API Types**: REST API vs HTTP API vs WebSocket API
- **Security**: JWT authentication, API keys, usage plans
- **Performance**: Caching, throttling, request validation
- **Integration**: Lambda proxy, direct service integration

### Event-Driven Patterns (3 hours)
- **EventBridge**: Custom events, rules, targets
- **SQS Integration**: Message processing, DLQ handling
- **Event Sourcing**: Immutable event logs with DynamoDB
- **CQRS Pattern**: Command Query Responsibility Segregation

### Serverless Data Processing (2 hours)
- **Real-time Processing**: Kinesis integration, stream processing
- **Batch Processing**: S3 triggers, scheduled functions
- **Analytics Pipeline**: Lambda → Kinesis → S3 → Athena

---

## 💻 Java 21 Lambda Examples

### Order Processing Function
```java
// Spring Cloud Function approach
@Component
public class OrderProcessor implements Function<OrderEvent, OrderResult> {
    
    @Autowired
    private OrderService orderService;
    
    @Override
    public OrderResult apply(OrderEvent orderEvent) {
        log.info("Processing order: {}", orderEvent.getOrderId());
        
        try {
            // Validate order
            orderService.validateOrder(orderEvent);
            
            // Process payment
            PaymentResult payment = orderService.processPayment(orderEvent);
            
            // Update inventory
            InventoryResult inventory = orderService.updateInventory(orderEvent);
            
            // Send confirmation
            orderService.sendConfirmation(orderEvent, payment);
            
            return OrderResult.success(orderEvent.getOrderId());
            
        } catch (Exception e) {
            log.error("Order processing failed", e);
            return OrderResult.failure(orderEvent.getOrderId(), e.getMessage());
        }
    }
}

// Lambda handler
public class OrderProcessorHandler implements RequestHandler<APIGatewayProxyRequestEvent, APIGatewayProxyResponseEvent> {
    
    private final OrderProcessor orderProcessor;
    
    public OrderProcessorHandler() {
        // Initialize Spring context
        ApplicationContext context = SpringApplication.run(Application.class);
        this.orderProcessor = context.getBean(OrderProcessor.class);
    }
    
    @Override
    public APIGatewayProxyResponseEvent handleRequest(
            APIGatewayProxyRequestEvent input, 
            Context context) {
        
        try {
            OrderEvent event = parseOrderEvent(input.getBody());
            OrderResult result = orderProcessor.apply(event);
            
            return APIGatewayProxyResponseEvent.builder()
                .withStatusCode(200)
                .withBody(objectMapper.writeValueAsString(result))
                .withHeaders(Map.of("Content-Type", "application/json"))
                .build();
                
        } catch (Exception e) {
            return APIGatewayProxyResponseEvent.builder()
                .withStatusCode(500)
                .withBody("{\"error\":\"" + e.getMessage() + "\"}")
                .build();
        }
    }
}
```

### Event-Driven Architecture
```java
// EventBridge event publisher
@Service
public class EventPublisher {
    
    @Autowired
    private EventBridgeClient eventBridgeClient;
    
    public void publishOrderEvent(OrderEvent event) {
        PutEventsRequest request = PutEventsRequest.builder()
            .entries(PutEventsRequestEntry.builder()
                .source("ecommerce.orders")
                .detailType("Order Status Change")
                .detail(objectMapper.writeValueAsString(event))
                .eventBusName("order-events")
                .build())
            .build();
            
        eventBridgeClient.putEvents(request);
    }
}

// SQS message processor
@Component
public class PaymentProcessor implements Function<SQSEvent, Void> {
    
    @Override
    public Void apply(SQSEvent sqsEvent) {
        for (SQSMessage message : sqsEvent.getRecords()) {
            try {
                PaymentEvent event = parsePaymentEvent(message.getBody());
                processPayment(event);
                
                // Message is automatically deleted on successful processing
                
            } catch (Exception e) {
                log.error("Payment processing failed", e);
                // Message will be retried or sent to DLQ
                throw new RuntimeException("Payment processing failed", e);
            }
        }
        return null;
    }
}
```

---

## 🎓 Certification Mapping

### SAA-C03 Domain 2: Design Resilient Architectures (26%)
- **2.3** Design decoupling mechanisms
  - ✅ SQS for asynchronous processing
  - ✅ SNS for pub/sub messaging
  - ✅ EventBridge for event routing
  - ✅ API Gateway for service decoupling

### SAA-C03 Domain 3: Design High-Performing Architectures (24%)
- **3.1** Choose performant storage and databases
  - ✅ DynamoDB for serverless applications
  - ✅ Lambda performance optimization
  - ✅ API Gateway caching strategies

---

## 🏆 Real-World Use Cases

### E-commerce Order Processing
```
API Gateway → Lambda → EventBridge → Multiple Processors
• Order validation
• Payment processing
• Inventory management
• Shipping notification
```

### IoT Data Processing
```
IoT Devices → API Gateway → Lambda → Kinesis → S3
• Real-time sensor data ingestion
• Data transformation and validation
• Stream processing and analytics
• Data lake storage
```

### Serverless Web Backend
```
Frontend → CloudFront → API Gateway → Lambda → DynamoDB
• User authentication
• CRUD operations
• File upload processing
• Real-time notifications
```

---

## 📊 Performance Optimization

### Cold Start Reduction
```java
// Provisioned concurrency configuration
{
  "FunctionName": "order-processor",
  "ProvisionedConcurrencyConfig": {
    "ProvisionedConcurrency": 5
  }
}

// Java optimization techniques
public class OptimizedLambdaHandler {
    
    // Initialize expensive resources outside handler
    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();
    private static final AmazonDynamoDB DYNAMO_CLIENT = 
        AmazonDynamoDBClientBuilder.defaultClient();
    
    public APIGatewayProxyResponseEvent handleRequest(
            APIGatewayProxyRequestEvent input, Context context) {
        // Handler logic here
    }
}
```

### Cost Optimization Strategies
- **Right-sizing Memory**: Balance performance vs cost
- **Execution Time Optimization**: Reduce billable duration
- **Provisioned Concurrency**: For predictable workloads
- **Tiered Pricing**: Leverage free tier and volume discounts

---

## 🔍 Monitoring and Debugging

### CloudWatch Integration
```java
// Custom metrics in Lambda
@Component
public class MetricsService {
    
    @Autowired
    private CloudWatchClient cloudWatchClient;
    
    public void recordCustomMetric(String metricName, double value) {
        PutMetricDataRequest request = PutMetricDataRequest.builder()
            .namespace("MyApp/Orders")
            .metricData(MetricDatum.builder()
                .metricName(metricName)
                .value(value)
                .unit(StandardUnit.COUNT)
                .timestamp(Instant.now())
                .build())
            .build();
            
        cloudWatchClient.putMetricData(request);
    }
}
```

### Distributed Tracing with X-Ray
```java
// X-Ray tracing annotations
@XRayEnabled
@Service
public class OrderService {
    
    @Trace(metaData = true)
    public OrderResult processOrder(OrderEvent event) {
        
        // Add custom annotations
        AWSXRay.getCurrentSegment().putAnnotation("orderId", event.getOrderId());
        AWSXRay.getCurrentSegment().putMetadata("orderDetails", event);
        
        return doProcessOrder(event);
    }
}
```

---

## 📚 Prerequisites

### Required Knowledge
- Completed Modules 1-3 (Basics, Compute, Storage)
- Event-driven programming concepts
- REST API design principles
- Basic understanding of messaging patterns

### Development Environment
- AWS SAM CLI or Serverless Framework
- Java 21 with GraalVM (optional for native compilation)
- Docker for local testing
- Postman or similar API testing tool

---

## 🔄 Next Module

After completing this module, proceed to:
**[Module 5: Containers (ECS, EKS, Docker)](../module-05-containers/README.md)**

You'll learn how to containerize your applications and run them on AWS container services, building on the microservices patterns established in this module.

---

## 🎯 Key Benefits of Serverless

### Developer Productivity
- **No server management**: Focus on business logic
- **Automatic scaling**: Handle any load without configuration
- **Pay-per-use**: Cost-effective for variable workloads
- **Fast deployment**: Deploy functions in seconds

### Operational Excellence
- **Built-in monitoring**: CloudWatch integration out of the box
- **High availability**: Multi-AZ by default
- **Security**: IAM integration, VPC support
- **Compliance**: SOC, HIPAA, PCI compliance ready

---

**Ready to go serverless?** ⚡ Start building event-driven, scalable applications that automatically handle any load while optimizing costs!

**Begin with**: Java 21 Lambda Functions - Create your first serverless order processing service.
