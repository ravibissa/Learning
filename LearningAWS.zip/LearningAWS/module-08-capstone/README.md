# Module 8: Capstone Project - Employee & Organization Management System
**Duration**: 20 hours | **Level**: Expert | **Certification**: All SAA-C03 Domains + SAP-C02 Foundation

## 🎯 Project Overview

Build a comprehensive **Employee & Organization Management System** that demonstrates mastery of all AWS services and architectural patterns learned throughout the course. This capstone project integrates every module's concepts into a production-ready, enterprise-grade application.

---

## 📋 Project Requirements

### Functional Requirements
- **Employee Management**: CRUD operations, profile management, org chart visualization
- **Organization Structure**: Departments, teams, hierarchical relationships
- **Authentication & Authorization**: Role-based access control (RBAC)
- **File Management**: Document storage, profile pictures, org charts
- **Reporting & Analytics**: Employee metrics, org insights, cost analysis
- **Notifications**: Email alerts, real-time updates, workflow notifications

### Non-Functional Requirements
- **Scalability**: Support 10,000+ employees with auto-scaling
- **Availability**: 99.9% uptime with multi-AZ deployment
- **Security**: End-to-end encryption, audit trails, compliance
- **Performance**: <200ms API response times, <3s page loads
- **Cost-Optimized**: Automated cost monitoring and optimization
- **Monitoring**: Comprehensive observability with alerting

---

## 🏗️ Complete System Architecture

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                     Employee & Organization Management System                   │
│                                Multi-Tier, Cloud-Native Architecture          │
│                                                                                 │
│  ┌─────────────────────────────────────────────────────────────────────────┐   │
│  │                              Frontend Layer                             │   │
│  │                                                                         │   │
│  │  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────────────┐ │   │
│  │  │     React       │  │   CloudFront    │  │        S3 Static        │ │   │
│  │  │   TypeScript    │  │     CDN         │  │      Website Hosting    │ │   │
│  │  │   SPA Frontend  │  │  • SSL/TLS      │  │  • Static Assets        │ │   │
│  │  │                 │  │  • Caching      │  │  • React Build          │ │   │
│  │  │  ┌─────────────┐│  │  • GZIP         │  │  • Error Pages          │ │   │
│  │  │  │   Admin     ││  │  • Security     │  │  • Version Control      │ │   │
│  │  │  │   Portal    ││  │    Headers      │  │                         │ │   │
│  │  │  └─────────────┘│  └─────────────────┘  └─────────────────────────┘ │   │
│  │  │                 │                                                   │   │
│  │  │  ┌─────────────┐│  ┌─────────────────┐  ┌─────────────────────────┐ │   │
│  │  │  │  Employee   ││  │   API Gateway   │  │       Cognito           │ │   │
│  │  │  │  Self-      ││  │  • Rate Limiting│  │     User Pool           │ │   │
│  │  │  │  Service    ││  │  • Authentication │ │  • OAuth 2.0/OIDC      │ │   │
│  │  │  └─────────────┘│  │  • Request      │  │  • MFA Support          │ │   │
│  │  │                 │  │    Validation   │  │  • Social Login         │ │   │
│  │  │  ┌─────────────┐│  │  • CORS         │  │  • Custom Attributes    │ │   │
│  │  │  │   Manager   ││  └─────────────────┘  └─────────────────────────┘ │   │
│  │  │  │  Dashboard  ││                                                   │   │
│  │  │  └─────────────┘│                                                   │   │
│  │  └─────────────────┘                                                   │   │
│  └─────────────────────────────────────────────────────────────────────────┘   │
│                                           │                                     │
│                                           ▼                                     │
│  ┌─────────────────────────────────────────────────────────────────────────┐   │
│  │                           API & Service Layer                          │   │
│  │                                                                         │   │
│  │  ┌─────────────────────────────────────────────────────────────────┐   │   │
│  │  │                      Microservices (ECS/EKS)                   │   │   │
│  │  │                                                                 │   │   │
│  │  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────────┐ │   │   │
│  │  │  │  Employee   │  │Organization │  │    Authentication       │ │   │   │
│  │  │  │  Service    │  │   Service   │  │      Service            │ │   │   │
│  │  │  │             │  │             │  │                         │ │   │   │
│  │  │  │ • CRUD Ops  │  │ • Dept Mgmt │  │ • JWT Validation        │ │   │   │
│  │  │  │ • Profiles  │  │ • Team Mgmt │  │ • RBAC                  │ │   │   │
│  │  │  │ • Search    │  │ • Hierarchy │  │ • Session Management    │ │   │   │
│  │  │  └─────────────┘  └─────────────┘  └─────────────────────────┘ │   │   │
│  │  │                                                                 │   │   │
│  │  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────────┐ │   │   │
│  │  │  │    File     │  │ Notification│  │      Reporting          │ │   │   │
│  │  │  │   Service   │  │   Service   │  │      Service            │ │   │   │
│  │  │  │             │  │             │  │                         │ │   │   │
│  │  │  │ • S3 Upload │  │ • Email     │  │ • Analytics             │ │   │   │
│  │  │  │ • Processing│  │ • SMS       │  │ • Dashboards            │ │   │   │
│  │  │  │ • Metadata  │  │ • Push      │  │ • Export                │ │   │   │
│  │  │  └─────────────┘  └─────────────┘  └─────────────────────────┘ │   │   │
│  │  └─────────────────────────────────────────────────────────────────┘   │   │
│  │                                    │                                    │   │
│  │                                    ▼                                    │   │
│  │  ┌─────────────────────────────────────────────────────────────────┐   │   │
│  │  │                    Serverless Functions                        │   │   │
│  │  │                                                                 │   │   │
│  │  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────────┐ │   │   │
│  │  │  │   Image     │  │    Data     │  │      Workflow           │ │   │   │
│  │  │  │ Processing  │  │  Processing │  │    Orchestration        │ │   │   │
│  │  │  │             │  │             │  │                         │ │   │   │
│  │  │  │ • Resize    │  │ • ETL Jobs  │  │ • Step Functions        │ │   │   │
│  │  │  │ • OCR       │  │ • Analytics │  │ • Approval Workflows    │ │   │   │
│  │  │  │ • Metadata  │  │ • Reports   │  │ • Event Processing      │ │   │   │
│  │  │  └─────────────┘  └─────────────┘  └─────────────────────────┘ │   │   │
│  │  └─────────────────────────────────────────────────────────────────┘   │   │
│  └─────────────────────────────────────────────────────────────────────────┘   │
│                                           │                                     │
│                                           ▼                                     │
│  ┌─────────────────────────────────────────────────────────────────────────┐   │
│  │                            Data Layer                                  │   │
│  │                                                                         │   │
│  │  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────────────┐ │   │
│  │  │    Amazon       │  │    Amazon       │  │         Amazon          │ │   │
│  │  │     RDS         │  │   DynamoDB      │  │           S3            │ │   │
│  │  │                 │  │                 │  │                         │ │   │
│  │  │ • Employee Data │  │ • User Sessions │  │ • Document Storage      │ │   │
│  │  │ • Org Structure │  │ • Activity Logs │  │ • Profile Pictures      │ │   │
│  │  │ • Relationships │  │ • Real-time     │  │ • Backup Archives       │ │   │
│  │  │ • Audit Trail   │  │   Events        │  │ • Static Assets         │ │   │
│  │  │ • Multi-AZ      │  │ • Auto Scaling  │  │ • Data Lake             │ │   │
│  │  │ • Read Replicas │  │ • Global Tables │  │ • Lifecycle Policies    │ │   │
│  │  └─────────────────┘  └─────────────────┘  └─────────────────────────┘ │   │
│  │                                                                         │   │
│  │  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────────────┐ │   │
│  │  │  ElastiCache    │  │   OpenSearch    │  │      QuickSight         │ │   │
│  │  │     Redis       │  │                 │  │                         │ │   │
│  │  │                 │  │ • Search Index  │  │ • BI Dashboards         │ │   │
│  │  │ • Session Store │  │ • Full-text     │  │ • Executive Reports     │ │   │
│  │  │ • Cache Layer   │  │   Search        │  │ • Data Visualization    │ │   │
│  │  │ • Rate Limiting │  │ • Analytics     │  │ • Self-Service          │ │   │
│  │  └─────────────────┘  └─────────────────┘  └─────────────────────────┘ │   │
│  └─────────────────────────────────────────────────────────────────────────┘   │
│                                           │                                     │
│                                           ▼                                     │
│  ┌─────────────────────────────────────────────────────────────────────────┐   │
│  │                       Infrastructure & Operations                       │   │
│  │                                                                         │   │
│  │  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────────────┐ │   │
│  │  │    Monitoring   │  │      Security   │  │      CI/CD Pipeline     │ │   │
│  │  │   & Alerting    │  │    & Compliance │  │                         │ │   │
│  │  │                 │  │                 │  │                         │ │   │
│  │  │ • CloudWatch    │  │ • WAF           │  │ • GitHub Actions        │ │   │
│  │  │ • X-Ray Tracing │  │ • GuardDuty     │  │ • CodePipeline          │ │   │
│  │  │ • Custom Metrics│  │ • Config        │  │ • Blue-Green Deploy     │ │   │
│  │  │ • Log Analytics │  │ • CloudTrail    │  │ • Automated Testing     │ │   │
│  │  │ • Dashboards    │  │ • KMS           │  │ • Infrastructure as     │ │   │
│  │  │ • Auto-Response │  │ • Secrets Mgr   │  │   Code (Terraform)      │ │   │
│  │  └─────────────────┘  └─────────────────┘  └─────────────────────────┘ │   │
│  └─────────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────────┘
```

---

## 🎯 Module Integration & Learning Objectives

### Module 1: AWS Basics & IAM
**Applied**: Complete IAM strategy with cross-service access
- Service-specific IAM roles for each microservice
- Cross-account access for CI/CD pipelines
- Fine-grained permissions following least privilege
- MFA enforcement for admin operations

### Module 2: Compute Services
**Applied**: Multi-tier compute architecture
- Application Load Balancer with path-based routing
- ECS Fargate for microservices deployment
- Auto Scaling Groups with custom metrics
- Blue-green deployment strategy

### Module 3: Storage & Databases
**Applied**: Polyglot persistence architecture
- RDS PostgreSQL for relational employee data
- DynamoDB for session management and real-time events
- S3 for document storage and static website hosting
- ElastiCache Redis for application caching

### Module 4: Serverless
**Applied**: Event-driven processing
- Lambda functions for image processing and ETL
- API Gateway for public API endpoints
- EventBridge for cross-service communication
- Step Functions for workflow orchestration

### Module 5: Containers
**Applied**: Microservices containerization
- Docker optimization for Spring Boot services
- ECS service mesh with App Mesh
- Kubernetes deployment patterns (EKS alternative)
- Container image security scanning

### Module 6: Infrastructure as Code
**Applied**: Complete automation
- Terraform modules for all infrastructure
- CI/CD pipelines with automated testing
- Environment-specific configurations
- GitOps workflow implementation

### Module 7: Monitoring & Security
**Applied**: Production-ready observability
- CloudWatch custom metrics and dashboards
- X-Ray distributed tracing across all services
- Security monitoring with GuardDuty and Config
- Automated incident response

---

## 📝 Project Phases

### Phase 1: Foundation Setup (4 hours)
#### Infrastructure as Code
```hcl
# main.tf - Root module
module "networking" {
  source = "./modules/networking"
  
  application_name = var.application_name
  environment     = var.environment
  
  vpc_cidr             = "10.0.0.0/16"
  availability_zones   = ["us-east-1a", "us-east-1b", "us-east-1c"]
  public_subnet_cidrs  = ["10.0.1.0/24", "10.0.2.0/24", "10.0.3.0/24"]
  private_subnet_cidrs = ["10.0.4.0/24", "10.0.5.0/24", "10.0.6.0/24"]
  database_subnet_cidrs = ["10.0.7.0/24", "10.0.8.0/24", "10.0.9.0/24"]
}

module "security" {
  source = "./modules/security"
  
  vpc_id = module.networking.vpc_id
  
  # Security groups for each tier
  alb_security_group_rules    = local.alb_sg_rules
  app_security_group_rules    = local.app_sg_rules
  db_security_group_rules     = local.db_sg_rules
  cache_security_group_rules  = local.cache_sg_rules
}

module "database" {
  source = "./modules/database"
  
  vpc_id               = module.networking.vpc_id
  database_subnet_ids  = module.networking.database_subnet_ids
  security_group_ids   = [module.security.database_security_group_id]
  
  # RDS Configuration
  engine_version    = "15.4"
  instance_class    = var.environment == "prod" ? "db.r5.xlarge" : "db.t3.medium"
  allocated_storage = var.environment == "prod" ? 500 : 100
  multi_az         = var.environment == "prod"
  backup_retention = var.environment == "prod" ? 30 : 7
  
  # DynamoDB Tables
  dynamodb_tables = {
    user_sessions = {
      hash_key = "session_id"
      attributes = [
        {
          name = "session_id"
          type = "S"
        },
        {
          name = "user_id"
          type = "S"
        }
      ]
      global_secondary_indexes = [
        {
          name     = "user-id-index"
          hash_key = "user_id"
        }
      ]
    }
    
    activity_logs = {
      hash_key  = "user_id"
      range_key = "timestamp"
      attributes = [
        {
          name = "user_id"
          type = "S"
        },
        {
          name = "timestamp"
          type = "N"
        }
      ]
    }
    
    notifications = {
      hash_key = "notification_id"
      attributes = [
        {
          name = "notification_id"
          type = "S"
        },
        {
          name = "user_id"
          type = "S"
        },
        {
          name = "created_at"
          type = "N"
        }
      ]
      global_secondary_indexes = [
        {
          name     = "user-created-index"
          hash_key = "user_id"
          range_key = "created_at"
        }
      ]
    }
  }
}

module "storage" {
  source = "./modules/storage"
  
  # S3 Buckets
  buckets = {
    documents = {
      versioning = true
      lifecycle_rules = [
        {
          id     = "archive_old_documents"
          status = "Enabled"
          transitions = [
            {
              days          = 30
              storage_class = "STANDARD_IA"
            },
            {
              days          = 90
              storage_class = "GLACIER"
            },
            {
              days          = 365
              storage_class = "DEEP_ARCHIVE"
            }
          ]
        }
      ]
    }
    
    profile_pictures = {
      versioning = false
      lifecycle_rules = [
        {
          id     = "cleanup_incomplete_uploads"
          status = "Enabled"
          abort_incomplete_multipart_upload_days = 7
        }
      ]
    }
    
    backups = {
      versioning = true
      lifecycle_rules = [
        {
          id     = "backup_retention"
          status = "Enabled"
          expiration = {
            days = 2555  # 7 years
          }
        }
      ]
    }
  }
}
```

#### CI/CD Pipeline Setup
```yaml
# .github/workflows/deploy.yml
name: Deploy Employee Management System

on:
  push:
    branches: [main, develop]
  pull_request:
    branches: [main]

env:
  AWS_REGION: us-east-1
  ECR_REPOSITORY: employee-management
  ECS_CLUSTER: employee-management-cluster

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Set up Java 21
        uses: actions/setup-java@v3
        with:
          java-version: '21'
          distribution: 'corretto'
          
      - name: Cache Maven dependencies
        uses: actions/cache@v3
        with:
          path: ~/.m2
          key: ${{ runner.os }}-m2-${{ hashFiles('**/pom.xml') }}
          
      - name: Run tests
        run: |
          mvn clean test
          mvn verify
          
      - name: Security scan
        run: |
          mvn org.owasp:dependency-check-maven:check
          
      - name: SonarQube analysis
        env:
          GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}
          SONAR_TOKEN: ${{ secrets.SONAR_TOKEN }}
        run: |
          mvn sonar:sonar \
            -Dsonar.projectKey=employee-management \
            -Dsonar.host.url=https://sonarcloud.io \
            -Dsonar.organization=your-org

  build-and-deploy:
    needs: test
    runs-on: ubuntu-latest
    if: github.ref == 'refs/heads/main' || github.ref == 'refs/heads/develop'
    
    steps:
      - uses: actions/checkout@v3
      
      - name: Configure AWS credentials
        uses: aws-actions/configure-aws-credentials@v2
        with:
          aws-access-key-id: ${{ secrets.AWS_ACCESS_KEY_ID }}
          aws-secret-access-key: ${{ secrets.AWS_SECRET_ACCESS_KEY }}
          aws-region: ${{ env.AWS_REGION }}
          
      - name: Set environment
        run: |
          if [[ "${{ github.ref }}" == "refs/heads/main" ]]; then
            echo "ENVIRONMENT=prod" >> $GITHUB_ENV
          else
            echo "ENVIRONMENT=dev" >> $GITHUB_ENV
          fi
          
      - name: Build and package
        run: |
          mvn clean package -DskipTests
          
      - name: Build Docker images
        run: |
          # Build all microservices
          docker build -t employee-service:${{ github.sha }} ./employee-service
          docker build -t organization-service:${{ github.sha }} ./organization-service
          docker build -t notification-service:${{ github.sha }} ./notification-service
          docker build -t file-service:${{ github.sha }} ./file-service
          docker build -t reporting-service:${{ github.sha }} ./reporting-service
          
      - name: Push to ECR
        run: |
          aws ecr get-login-password --region $AWS_REGION | docker login --username AWS --password-stdin $AWS_ACCOUNT_ID.dkr.ecr.$AWS_REGION.amazonaws.com
          
          # Tag and push all services
          for service in employee organization notification file reporting; do
            docker tag ${service}-service:${{ github.sha }} $AWS_ACCOUNT_ID.dkr.ecr.$AWS_REGION.amazonaws.com/${service}-service:${{ github.sha }}
            docker tag ${service}-service:${{ github.sha }} $AWS_ACCOUNT_ID.dkr.ecr.$AWS_REGION.amazonaws.com/${service}-service:latest
            docker push $AWS_ACCOUNT_ID.dkr.ecr.$AWS_REGION.amazonaws.com/${service}-service:${{ github.sha }}
            docker push $AWS_ACCOUNT_ID.dkr.ecr.$AWS_REGION.amazonaws.com/${service}-service:latest
          done
          
      - name: Deploy infrastructure
        run: |
          cd terraform
          terraform init
          terraform workspace select $ENVIRONMENT || terraform workspace new $ENVIRONMENT
          terraform plan -var="environment=$ENVIRONMENT" -var="image_tag=${{ github.sha }}"
          terraform apply -auto-approve -var="environment=$ENVIRONMENT" -var="image_tag=${{ github.sha }}"
          
      - name: Deploy services
        run: |
          # Update ECS services
          for service in employee organization notification file reporting; do
            aws ecs update-service \
              --cluster $ECS_CLUSTER-$ENVIRONMENT \
              --service ${service}-service-$ENVIRONMENT \
              --force-new-deployment
          done
          
      - name: Run integration tests
        run: |
          # Wait for deployment to complete
          sleep 300
          
          # Run integration tests against deployed environment
          mvn test -Dtest=IntegrationTest \
            -Dapi.base.url=https://api-$ENVIRONMENT.employee-mgmt.com
            
      - name: Notify deployment
        if: always()
        uses: 8398a7/action-slack@v3
        with:
          status: ${{ job.status }}
          channel: '#deployments'
          webhook_url: ${{ secrets.SLACK_WEBHOOK }}
```

### Phase 2: Core Services Development (8 hours)

#### Employee Service Implementation
```java
// Employee Service - Core business logic
@RestController
@RequestMapping("/api/v1/employees")
@Validated
public class EmployeeController {
    
    @Autowired
    private EmployeeService employeeService;
    
    @Autowired
    private SecurityService securityService;
    
    @GetMapping
    @PreAuthorize("hasRole('ROLE_USER')")
    public ResponseEntity<Page<EmployeeDTO>> getEmployees(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size,
            @RequestParam(required = false) String search,
            @RequestParam(required = false) String department,
            @RequestParam(required = false) String location,
            Authentication authentication) {
        
        Pageable pageable = PageRequest.of(page, size);
        EmployeeFilter filter = EmployeeFilter.builder()
            .search(search)
            .department(department)
            .location(location)
            .build();
            
        // Apply data access controls based on user role
        String currentUserId = securityService.getCurrentUserId(authentication);
        filter = securityService.applyDataAccessFilter(filter, currentUserId);
        
        Page<EmployeeDTO> employees = employeeService.getEmployees(filter, pageable);
        return ResponseEntity.ok(employees);
    }
    
    @GetMapping("/{id}")
    @PreAuthorize("hasRole('ROLE_USER')")
    public ResponseEntity<EmployeeDTO> getEmployee(
            @PathVariable String id,
            Authentication authentication) {
        
        // Check if user can access this employee's data
        if (!securityService.canAccessEmployee(id, authentication)) {
            throw new AccessDeniedException("Cannot access employee data");
        }
        
        EmployeeDTO employee = employeeService.getEmployee(id);
        return ResponseEntity.ok(employee);
    }
    
    @PostMapping
    @PreAuthorize("hasRole('ROLE_HR') or hasRole('ROLE_ADMIN')")
    public ResponseEntity<EmployeeDTO> createEmployee(
            @Valid @RequestBody CreateEmployeeRequest request,
            Authentication authentication) {
        
        String createdBy = securityService.getCurrentUserId(authentication);
        EmployeeDTO employee = employeeService.createEmployee(request, createdBy);
        
        // Publish employee created event
        eventPublisher.publishEmployeeCreatedEvent(employee);
        
        return ResponseEntity.status(HttpStatus.CREATED).body(employee);
    }
    
    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ROLE_HR') or hasRole('ROLE_ADMIN') or #id == authentication.name")
    public ResponseEntity<EmployeeDTO> updateEmployee(
            @PathVariable String id,
            @Valid @RequestBody UpdateEmployeeRequest request,
            Authentication authentication) {
        
        String updatedBy = securityService.getCurrentUserId(authentication);
        
        // Check field-level permissions
        securityService.validateFieldUpdates(request, authentication);
        
        EmployeeDTO employee = employeeService.updateEmployee(id, request, updatedBy);
        
        // Publish employee updated event
        eventPublisher.publishEmployeeUpdatedEvent(employee);
        
        return ResponseEntity.ok(employee);
    }
    
    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<Void> deleteEmployee(
            @PathVariable String id,
            Authentication authentication) {
        
        String deletedBy = securityService.getCurrentUserId(authentication);
        employeeService.deleteEmployee(id, deletedBy);
        
        // Publish employee deleted event
        eventPublisher.publishEmployeeDeletedEvent(id);
        
        return ResponseEntity.noContent().build();
    }
    
    @GetMapping("/{id}/org-chart")
    @PreAuthorize("hasRole('ROLE_USER')")
    public ResponseEntity<OrgChartDTO> getOrgChart(
            @PathVariable String id,
            @RequestParam(defaultValue = "2") int levels) {
        
        OrgChartDTO orgChart = employeeService.getOrgChart(id, levels);
        return ResponseEntity.ok(orgChart);
    }
    
    @PostMapping("/{id}/profile-picture")
    @PreAuthorize("#id == authentication.name or hasRole('ROLE_HR')")
    public ResponseEntity<FileUploadResponse> uploadProfilePicture(
            @PathVariable String id,
            @RequestParam("file") MultipartFile file,
            Authentication authentication) {
        
        // Validate file type and size
        fileValidationService.validateImageFile(file);
        
        String uploadedBy = securityService.getCurrentUserId(authentication);
        FileUploadResponse response = fileService.uploadProfilePicture(id, file, uploadedBy);
        
        return ResponseEntity.ok(response);
    }
}

// Employee Service Implementation
@Service
@Transactional
public class EmployeeServiceImpl implements EmployeeService {
    
    @Autowired
    private EmployeeRepository employeeRepository;
    
    @Autowired
    private OrganizationServiceClient organizationServiceClient;
    
    @Autowired
    private AuditService auditService;
    
    @Autowired
    private CacheManager cacheManager;
    
    @Override
    @Cacheable(value = "employees", key = "#filter.hashCode() + '_' + #pageable.pageNumber")
    public Page<EmployeeDTO> getEmployees(EmployeeFilter filter, Pageable pageable) {
        
        Specification<Employee> spec = EmployeeSpecifications.withFilter(filter);
        Page<Employee> employees = employeeRepository.findAll(spec, pageable);
        
        return employees.map(this::convertToDTO);
    }
    
    @Override
    @Cacheable(value = "employee", key = "#id")
    public EmployeeDTO getEmployee(String id) {
        Employee employee = employeeRepository.findById(id)
            .orElseThrow(() -> new EmployeeNotFoundException("Employee not found: " + id));
            
        return convertToDTO(employee);
    }
    
    @Override
    @CacheEvict(value = {"employees", "orgChart"}, allEntries = true)
    public EmployeeDTO createEmployee(CreateEmployeeRequest request, String createdBy) {
        
        // Validate unique constraints
        validateUniqueEmail(request.getEmail());
        validateUniqueEmployeeId(request.getEmployeeId());
        
        Employee employee = Employee.builder()
            .id(UUID.randomUUID().toString())
            .employeeId(request.getEmployeeId())
            .firstName(request.getFirstName())
            .lastName(request.getLastName())
            .email(request.getEmail())
            .phone(request.getPhone())
            .department(request.getDepartment())
            .position(request.getPosition())
            .managerId(request.getManagerId())
            .startDate(request.getStartDate())
            .status(EmployeeStatus.ACTIVE)
            .createdBy(createdBy)
            .createdAt(Instant.now())
            .build();
            
        employee = employeeRepository.save(employee);
        
        // Log audit event
        auditService.logEmployeeCreated(employee.getId(), createdBy);
        
        return convertToDTO(employee);
    }
    
    @Override
    @CacheEvict(value = {"employee", "employees", "orgChart"}, key = "#id", allEntries = true)
    public EmployeeDTO updateEmployee(String id, UpdateEmployeeRequest request, String updatedBy) {
        
        Employee employee = employeeRepository.findById(id)
            .orElseThrow(() -> new EmployeeNotFoundException("Employee not found: " + id));
            
        // Track changes for audit
        Map<String, Object> changes = trackChanges(employee, request);
        
        // Update fields
        if (request.getFirstName() != null) {
            employee.setFirstName(request.getFirstName());
        }
        if (request.getLastName() != null) {
            employee.setLastName(request.getLastName());
        }
        if (request.getEmail() != null && !request.getEmail().equals(employee.getEmail())) {
            validateUniqueEmail(request.getEmail());
            employee.setEmail(request.getEmail());
        }
        if (request.getPhone() != null) {
            employee.setPhone(request.getPhone());
        }
        if (request.getDepartment() != null) {
            employee.setDepartment(request.getDepartment());
        }
        if (request.getPosition() != null) {
            employee.setPosition(request.getPosition());
        }
        if (request.getManagerId() != null) {
            validateManagerHierarchy(id, request.getManagerId());
            employee.setManagerId(request.getManagerId());
        }
        if (request.getStatus() != null) {
            employee.setStatus(request.getStatus());
        }
        
        employee.setUpdatedBy(updatedBy);
        employee.setUpdatedAt(Instant.now());
        
        employee = employeeRepository.save(employee);
        
        // Log audit event
        auditService.logEmployeeUpdated(employee.getId(), updatedBy, changes);
        
        return convertToDTO(employee);
    }
    
    @Override
    @Cacheable(value = "orgChart", key = "#employeeId + '_' + #levels")
    public OrgChartDTO getOrgChart(String employeeId, int levels) {
        
        Employee employee = employeeRepository.findById(employeeId)
            .orElseThrow(() -> new EmployeeNotFoundException("Employee not found: " + employeeId));
            
        // Build organization chart
        OrgChartNode root = buildOrgChartNode(employee);
        
        // Add direct reports recursively
        addDirectReports(root, levels - 1);
        
        return OrgChartDTO.builder()
            .root(root)
            .generatedAt(Instant.now())
            .levels(levels)
            .build();
    }
    
    private void addDirectReports(OrgChartNode node, int remainingLevels) {
        if (remainingLevels <= 0) {
            return;
        }
        
        List<Employee> directReports = employeeRepository.findByManagerId(node.getEmployeeId());
        
        for (Employee report : directReports) {
            OrgChartNode childNode = buildOrgChartNode(report);
            node.addDirectReport(childNode);
            
            // Recursively add their reports
            addDirectReports(childNode, remainingLevels - 1);
        }
    }
    
    private EmployeeDTO convertToDTO(Employee employee) {
        return EmployeeDTO.builder()
            .id(employee.getId())
            .employeeId(employee.getEmployeeId())
            .firstName(employee.getFirstName())
            .lastName(employee.getLastName())
            .fullName(employee.getFirstName() + " " + employee.getLastName())
            .email(employee.getEmail())
            .phone(employee.getPhone())
            .department(employee.getDepartment())
            .position(employee.getPosition())
            .managerId(employee.getManagerId())
            .managerName(getManagerName(employee.getManagerId()))
            .startDate(employee.getStartDate())
            .status(employee.getStatus())
            .profilePictureUrl(getProfilePictureUrl(employee.getId()))
            .createdAt(employee.getCreatedAt())
            .updatedAt(employee.getUpdatedAt())
            .build();
    }
}
```

#### Organization Service Implementation
```java
// Organization Service for department and team management
@RestController
@RequestMapping("/api/v1/organization")
@Validated
public class OrganizationController {
    
    @Autowired
    private OrganizationService organizationService;
    
    @GetMapping("/departments")
    @PreAuthorize("hasRole('ROLE_USER')")
    public ResponseEntity<List<DepartmentDTO>> getDepartments() {
        List<DepartmentDTO> departments = organizationService.getAllDepartments();
        return ResponseEntity.ok(departments);
    }
    
    @PostMapping("/departments")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<DepartmentDTO> createDepartment(
            @Valid @RequestBody CreateDepartmentRequest request,
            Authentication authentication) {
        
        String createdBy = securityService.getCurrentUserId(authentication);
        DepartmentDTO department = organizationService.createDepartment(request, createdBy);
        
        return ResponseEntity.status(HttpStatus.CREATED).body(department);
    }
    
    @GetMapping("/departments/{id}/hierarchy")
    @PreAuthorize("hasRole('ROLE_USER')")
    public ResponseEntity<DepartmentHierarchyDTO> getDepartmentHierarchy(
            @PathVariable String id) {
        
        DepartmentHierarchyDTO hierarchy = organizationService.getDepartmentHierarchy(id);
        return ResponseEntity.ok(hierarchy);
    }
    
    @GetMapping("/teams")
    @PreAuthorize("hasRole('ROLE_USER')")
    public ResponseEntity<List<TeamDTO>> getTeams(
            @RequestParam(required = false) String department) {
        
        List<TeamDTO> teams = organizationService.getTeams(department);
        return ResponseEntity.ok(teams);
    }
    
    @PostMapping("/teams")
    @PreAuthorize("hasRole('ROLE_MANAGER') or hasRole('ROLE_ADMIN')")
    public ResponseEntity<TeamDTO> createTeam(
            @Valid @RequestBody CreateTeamRequest request,
            Authentication authentication) {
        
        String createdBy = securityService.getCurrentUserId(authentication);
        TeamDTO team = organizationService.createTeam(request, createdBy);
        
        return ResponseEntity.status(HttpStatus.CREATED).body(team);
    }
    
    @PostMapping("/teams/{teamId}/members")
    @PreAuthorize("hasRole('ROLE_MANAGER') or hasRole('ROLE_ADMIN')")
    public ResponseEntity<Void> addTeamMember(
            @PathVariable String teamId,
            @Valid @RequestBody AddTeamMemberRequest request,
            Authentication authentication) {
        
        String addedBy = securityService.getCurrentUserId(authentication);
        organizationService.addTeamMember(teamId, request.getEmployeeId(), addedBy);
        
        return ResponseEntity.ok().build();
    }
    
    @DeleteMapping("/teams/{teamId}/members/{employeeId}")
    @PreAuthorize("hasRole('ROLE_MANAGER') or hasRole('ROLE_ADMIN')")
    public ResponseEntity<Void> removeTeamMember(
            @PathVariable String teamId,
            @PathVariable String employeeId,
            Authentication authentication) {
        
        String removedBy = securityService.getCurrentUserId(authentication);
        organizationService.removeTeamMember(teamId, employeeId, removedBy);
        
        return ResponseEntity.ok().build();
    }
}
```

### Phase 3: Advanced Features (4 hours)

#### File Service with S3 Integration
```java
// File Service for document and image management
@Service
public class FileServiceImpl implements FileService {
    
    @Autowired
    private S3Client s3Client;
    
    @Autowired
    private DynamoDbEnhancedClient dynamoDbClient;
    
    @Value("${aws.s3.documents-bucket}")
    private String documentsBucket;
    
    @Value("${aws.s3.profile-pictures-bucket}")
    private String profilePicturesBucket;
    
    @Override
    public FileUploadResponse uploadDocument(String employeeId, MultipartFile file, String uploadedBy) {
        
        // Validate file
        validateDocumentFile(file);
        
        // Generate unique key
        String fileKey = generateDocumentKey(employeeId, file.getOriginalFilename());
        
        try {
            // Upload to S3
            PutObjectRequest request = PutObjectRequest.builder()
                .bucket(documentsBucket)
                .key(fileKey)
                .contentType(file.getContentType())
                .metadata(Map.of(
                    "original-filename", file.getOriginalFilename(),
                    "uploaded-by", uploadedBy,
                    "employee-id", employeeId
                ))
                .build();
                
            s3Client.putObject(request, RequestBody.fromInputStream(
                file.getInputStream(), file.getSize()));
            
            // Save metadata to DynamoDB
            FileMetadata metadata = FileMetadata.builder()
                .fileId(UUID.randomUUID().toString())
                .fileName(file.getOriginalFilename())
                .fileKey(fileKey)
                .fileSize(file.getSize())
                .contentType(file.getContentType())
                .employeeId(employeeId)
                .uploadedBy(uploadedBy)
                .uploadedAt(Instant.now())
                .bucket(documentsBucket)
                .build();
                
            DynamoDbTable<FileMetadata> table = dynamoDbClient.table(
                "file_metadata", TableSchema.fromBean(FileMetadata.class));
            table.putItem(metadata);
            
            // Generate presigned URL for access
            String presignedUrl = generatePresignedUrl(documentsBucket, fileKey, Duration.ofHours(1));
            
            return FileUploadResponse.builder()
                .fileId(metadata.getFileId())
                .fileName(metadata.getFileName())
                .fileUrl(presignedUrl)
                .uploadedAt(metadata.getUploadedAt())
                .build();
                
        } catch (Exception e) {
            logger.error("Failed to upload document", e);
            throw new FileUploadException("Failed to upload document", e);
        }
    }
    
    @Override
    public FileUploadResponse uploadProfilePicture(String employeeId, MultipartFile file, String uploadedBy) {
        
        // Validate image file
        validateImageFile(file);
        
        String fileKey = generateProfilePictureKey(employeeId);
        
        try {
            // Resize image before upload
            byte[] resizedImage = imageProcessingService.resizeImage(
                file.getBytes(), 300, 300);
            
            // Upload original and resized versions
            uploadImageVariant(profilePicturesBucket, fileKey + "_original", file.getBytes(), file.getContentType());
            uploadImageVariant(profilePicturesBucket, fileKey + "_medium", resizedImage, "image/jpeg");
            
            // Generate thumbnail
            byte[] thumbnail = imageProcessingService.resizeImage(
                file.getBytes(), 100, 100);
            uploadImageVariant(profilePicturesBucket, fileKey + "_thumbnail", thumbnail, "image/jpeg");
            
            // Update employee record with profile picture URL
            updateEmployeeProfilePicture(employeeId, fileKey);
            
            return FileUploadResponse.builder()
                .fileId(fileKey)
                .fileName(file.getOriginalFilename())
                .fileUrl(generatePresignedUrl(profilePicturesBucket, fileKey + "_medium", Duration.ofDays(7)))
                .uploadedAt(Instant.now())
                .build();
                
        } catch (Exception e) {
            logger.error("Failed to upload profile picture", e);
            throw new FileUploadException("Failed to upload profile picture", e);
        }
    }
    
    @Override
    public List<FileMetadata> getEmployeeDocuments(String employeeId) {
        
        DynamoDbTable<FileMetadata> table = dynamoDbClient.table(
            "file_metadata", TableSchema.fromBean(FileMetadata.class));
            
        DynamoDbIndex<FileMetadata> index = table.index("employee-id-index");
        
        QueryConditional queryConditional = QueryConditional
            .keyEqualTo(Key.builder().partitionValue(employeeId).build());
            
        return index.query(queryConditional)
            .items()
            .stream()
            .collect(Collectors.toList());
    }
    
    @Override
    public String generatePresignedDownloadUrl(String fileId, Duration validity) {
        
        FileMetadata metadata = getFileMetadata(fileId);
        return generatePresignedUrl(metadata.getBucket(), metadata.getFileKey(), validity);
    }
    
    private String generatePresignedUrl(String bucket, String key, Duration validity) {
        
        GetObjectRequest getObjectRequest = GetObjectRequest.builder()
            .bucket(bucket)
            .key(key)
            .build();
            
        GetObjectPresignRequest presignRequest = GetObjectPresignRequest.builder()
            .signatureDuration(validity)
            .getObjectRequest(getObjectRequest)
            .build();
            
        S3Presigner presigner = S3Presigner.create();
        PresignedGetObjectRequest presignedRequest = presigner.presignGetObject(presignRequest);
        
        return presignedRequest.url().toString();
    }
}
```

#### Lambda Functions for Background Processing
```java
// Lambda function for image processing
public class ImageProcessingFunction implements RequestHandler<S3Event, String> {
    
    private final S3Client s3Client = S3Client.create();
    private final DynamoDbEnhancedClient dynamoDbClient = DynamoDbEnhancedClient.create();
    
    @Override
    public String handleRequest(S3Event event, Context context) {
        
        for (S3EventNotificationRecord record : event.getRecords()) {
            String bucket = record.getS3().getBucket().getName();
            String key = record.getS3().getObject().getKey();
            
            try {
                // Download image from S3
                GetObjectRequest getRequest = GetObjectRequest.builder()
                    .bucket(bucket)
                    .key(key)
                    .build();
                    
                ResponseInputStream<GetObjectResponse> s3Object = s3Client.getObject(getRequest);
                byte[] imageBytes = s3Object.readAllBytes();
                
                // Process image (resize, optimize, extract metadata)
                ImageProcessingResult result = processImage(imageBytes, key);
                
                // Upload processed variants
                uploadProcessedVariants(bucket, key, result);
                
                // Update metadata in DynamoDB
                updateImageMetadata(key, result);
                
                context.getLogger().log("Successfully processed image: " + key);
                
            } catch (Exception e) {
                context.getLogger().log("Error processing image " + key + ": " + e.getMessage());
                
                // Send to DLQ for manual review
                sendToDeadLetterQueue(record, e.getMessage());
            }
        }
        
        return "SUCCESS";
    }
    
    private ImageProcessingResult processImage(byte[] imageBytes, String key) throws IOException {
        
        BufferedImage originalImage = ImageIO.read(new ByteArrayInputStream(imageBytes));
        
        // Extract metadata
        ImageMetadata metadata = ImageMetadata.builder()
            .width(originalImage.getWidth())
            .height(originalImage.getHeight())
            .format(getImageFormat(key))
            .size(imageBytes.length)
            .build();
        
        // Create different sizes
        Map<String, byte[]> variants = new HashMap<>();
        
        // Thumbnail (100x100)
        BufferedImage thumbnail = resizeImage(originalImage, 100, 100);
        variants.put("thumbnail", imageToBytes(thumbnail, "jpg"));
        
        // Medium (300x300)
        BufferedImage medium = resizeImage(originalImage, 300, 300);
        variants.put("medium", imageToBytes(medium, "jpg"));
        
        // Optimized original (maintain aspect ratio, max 1200px)
        if (originalImage.getWidth() > 1200 || originalImage.getHeight() > 1200) {
            BufferedImage optimized = resizeImageProportional(originalImage, 1200);
            variants.put("optimized", imageToBytes(optimized, "jpg"));
        }
        
        return ImageProcessingResult.builder()
            .metadata(metadata)
            .variants(variants)
            .build();
    }
    
    private BufferedImage resizeImage(BufferedImage original, int targetWidth, int targetHeight) {
        
        Image scaled = original.getScaledInstance(targetWidth, targetHeight, Image.SCALE_SMOOTH);
        BufferedImage resized = new BufferedImage(targetWidth, targetHeight, BufferedImage.TYPE_INT_RGB);
        
        Graphics2D g2d = resized.createGraphics();
        g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g2d.drawImage(scaled, 0, 0, null);
        g2d.dispose();
        
        return resized;
    }
}

// Lambda function for data processing and ETL
public class DataProcessingFunction implements RequestHandler<ScheduledEvent, String> {
    
    @Override
    public String handleRequest(ScheduledEvent event, Context context) {
        
        try {
            // Generate daily employee analytics
            generateDailyAnalytics();
            
            // Update organization metrics
            updateOrganizationMetrics();
            
            // Cleanup old data
            cleanupOldData();
            
            // Generate reports
            generateScheduledReports();
            
            context.getLogger().log("Daily data processing completed successfully");
            return "SUCCESS";
            
        } catch (Exception e) {
            context.getLogger().log("Error in data processing: " + e.getMessage());
            
            // Send alert to operations team
            sendOperationsAlert(e);
            
            throw new RuntimeException("Data processing failed", e);
        }
    }
    
    private void generateDailyAnalytics() {
        
        // Query employee data from RDS
        List<Employee> employees = employeeRepository.findAllActive();
        
        // Calculate metrics
        EmployeeAnalytics analytics = EmployeeAnalytics.builder()
            .date(LocalDate.now())
            .totalEmployees(employees.size())
            .departmentBreakdown(calculateDepartmentBreakdown(employees))
            .locationBreakdown(calculateLocationBreakdown(employees))
            .tenureAnalysis(calculateTenureAnalysis(employees))
            .newHires(countNewHires(employees))
            .terminations(countTerminations())
            .build();
        
        // Store in DynamoDB for fast access
        analyticsRepository.save(analytics);
        
        // Store in S3 for data lake
        storeInDataLake(analytics);
    }
}
```

### Phase 4: Frontend Integration (4 hours)

#### React Frontend with TypeScript
```typescript
// Employee List Component
import React, { useState, useEffect, useCallback } from 'react';
import { 
  Table, 
  Input, 
  Button, 
  Select, 
  Pagination, 
  Avatar, 
  Tag, 
  Space,
  Modal,
  message 
} from 'antd';
import { 
  SearchOutlined, 
  PlusOutlined, 
  EditOutlined, 
  DeleteOutlined 
} from '@ant-design/icons';
import { useQuery, useMutation, useQueryClient } from 'react-query';
import { employeeService } from '../services/employeeService';
import { Employee, EmployeeFilter } from '../types/employee';

const { Option } = Select;

interface EmployeeListProps {
  onEdit?: (employee: Employee) => void;
  onView?: (employee: Employee) => void;
}

const EmployeeList: React.FC<EmployeeListProps> = ({ onEdit, onView }) => {
  const [filter, setFilter] = useState<EmployeeFilter>({
    page: 0,
    size: 20,
    search: '',
    department: undefined,
    location: undefined
  });
  
  const queryClient = useQueryClient();
  
  // Fetch employees with react-query for caching and background updates
  const { 
    data: employeesData, 
    isLoading, 
    error,
    refetch 
  } = useQuery(
    ['employees', filter],
    () => employeeService.getEmployees(filter),
    {
      keepPreviousData: true,
      staleTime: 5 * 60 * 1000, // 5 minutes
      cacheTime: 10 * 60 * 1000, // 10 minutes
    }
  );
  
  // Delete employee mutation
  const deleteEmployeeMutation = useMutation(
    employeeService.deleteEmployee,
    {
      onSuccess: () => {
        message.success('Employee deleted successfully');
        queryClient.invalidateQueries(['employees']);
      },
      onError: (error: any) => {
        message.error(`Failed to delete employee: ${error.message}`);
      }
    }
  );
  
  // Fetch departments for filter
  const { data: departments } = useQuery(
    'departments',
    () => organizationService.getDepartments(),
    {
      staleTime: 30 * 60 * 1000, // 30 minutes
    }
  );
  
  const handleSearch = useCallback((value: string) => {
    setFilter(prev => ({ ...prev, search: value, page: 0 }));
  }, []);
  
  const handleDepartmentFilter = useCallback((department: string) => {
    setFilter(prev => ({ ...prev, department, page: 0 }));
  }, []);
  
  const handlePageChange = useCallback((page: number, pageSize: number) => {
    setFilter(prev => ({ ...prev, page: page - 1, size: pageSize }));
  }, []);
  
  const handleDelete = useCallback((employee: Employee) => {
    Modal.confirm({
      title: `Delete ${employee.fullName}?`,
      content: 'This action cannot be undone.',
      okText: 'Delete',
      okType: 'danger',
      cancelText: 'Cancel',
      onOk: () => deleteEmployeeMutation.mutate(employee.id),
    });
  }, [deleteEmployeeMutation]);
  
  const columns = [
    {
      title: 'Employee',
      key: 'employee',
      render: (record: Employee) => (
        <Space>
          <Avatar 
            src={record.profilePictureUrl} 
            size={40}
          >
            {record.firstName[0]}{record.lastName[0]}
          </Avatar>
          <div>
            <div style={{ fontWeight: 500 }}>{record.fullName}</div>
            <div style={{ color: '#666', fontSize: '12px' }}>
              {record.employeeId}
            </div>
          </div>
        </Space>
      ),
    },
    {
      title: 'Email',
      dataIndex: 'email',
      key: 'email',
    },
    {
      title: 'Department',
      dataIndex: 'department',
      key: 'department',
      render: (department: string) => (
        <Tag color="blue">{department}</Tag>
      ),
    },
    {
      title: 'Position',
      dataIndex: 'position',
      key: 'position',
    },
    {
      title: 'Manager',
      dataIndex: 'managerName',
      key: 'managerName',
      render: (name: string) => name || '-',
    },
    {
      title: 'Status',
      dataIndex: 'status',
      key: 'status',
      render: (status: string) => (
        <Tag color={status === 'ACTIVE' ? 'green' : 'red'}>
          {status}
        </Tag>
      ),
    },
    {
      title: 'Actions',
      key: 'actions',
      render: (record: Employee) => (
        <Space>
          <Button 
            icon={<EditOutlined />} 
            size="small"
            onClick={() => onEdit?.(record)}
          >
            Edit
          </Button>
          <Button 
            icon={<DeleteOutlined />} 
            size="small" 
            danger
            onClick={() => handleDelete(record)}
            loading={deleteEmployeeMutation.isLoading}
          >
            Delete
          </Button>
        </Space>
      ),
    },
  ];
  
  if (error) {
    return (
      <div style={{ padding: '20px', textAlign: 'center' }}>
        <p>Error loading employees: {(error as Error).message}</p>
        <Button onClick={() => refetch()}>Retry</Button>
      </div>
    );
  }
  
  return (
    <div style={{ padding: '20px' }}>
      {/* Filters */}
      <div style={{ marginBottom: '20px', display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
        <Input
          placeholder="Search employees..."
          prefix={<SearchOutlined />}
          style={{ width: '300px' }}
          onChange={(e) => handleSearch(e.target.value)}
          allowClear
        />
        
        <Select
          placeholder="Filter by department"
          style={{ width: '200px' }}
          onChange={handleDepartmentFilter}
          allowClear
        >
          {departments?.map(dept => (
            <Option key={dept.id} value={dept.name}>
              {dept.name}
            </Option>
          ))}
        </Select>
        
        <Button 
          type="primary" 
          icon={<PlusOutlined />}
          onClick={() => {/* Navigate to create employee */}}
        >
          Add Employee
        </Button>
      </div>
      
      {/* Employee Table */}
      <Table
        columns={columns}
        dataSource={employeesData?.content || []}
        loading={isLoading}
        pagination={false}
        rowKey="id"
        size="middle"
      />
      
      {/* Pagination */}
      <div style={{ marginTop: '20px', textAlign: 'right' }}>
        <Pagination
          current={(filter.page || 0) + 1}
          pageSize={filter.size || 20}
          total={employeesData?.totalElements || 0}
          showSizeChanger
          showQuickJumper
          showTotal={(total, range) => 
            `${range[0]}-${range[1]} of ${total} employees`
          }
          onChange={handlePageChange}
        />
      </div>
    </div>
  );
};

export default EmployeeList;
```

```typescript
// Employee Service with API client
import axios, { AxiosResponse } from 'axios';
import { Employee, EmployeeFilter, CreateEmployeeRequest, UpdateEmployeeRequest } from '../types/employee';
import { Page } from '../types/common';

const API_BASE_URL = process.env.REACT_APP_API_BASE_URL || 'https://api.employee-mgmt.com';

// Create axios instance with interceptors
const apiClient = axios.create({
  baseURL: API_BASE_URL,
  timeout: 30000,
});

// Request interceptor to add auth token
apiClient.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('access_token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Response interceptor for error handling
apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      // Redirect to login
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

export const employeeService = {
  
  async getEmployees(filter: EmployeeFilter): Promise<Page<Employee>> {
    const params = new URLSearchParams();
    
    if (filter.page !== undefined) params.append('page', filter.page.toString());
    if (filter.size !== undefined) params.append('size', filter.size.toString());
    if (filter.search) params.append('search', filter.search);
    if (filter.department) params.append('department', filter.department);
    if (filter.location) params.append('location', filter.location);
    
    const response: AxiosResponse<Page<Employee>> = await apiClient.get(
      `/api/v1/employees?${params.toString()}`
    );
    
    return response.data;
  },
  
  async getEmployee(id: string): Promise<Employee> {
    const response: AxiosResponse<Employee> = await apiClient.get(
      `/api/v1/employees/${id}`
    );
    
    return response.data;
  },
  
  async createEmployee(request: CreateEmployeeRequest): Promise<Employee> {
    const response: AxiosResponse<Employee> = await apiClient.post(
      '/api/v1/employees',
      request
    );
    
    return response.data;
  },
  
  async updateEmployee(id: string, request: UpdateEmployeeRequest): Promise<Employee> {
    const response: AxiosResponse<Employee> = await apiClient.put(
      `/api/v1/employees/${id}`,
      request
    );
    
    return response.data;
  },
  
  async deleteEmployee(id: string): Promise<void> {
    await apiClient.delete(`/api/v1/employees/${id}`);
  },
  
  async uploadProfilePicture(id: string, file: File): Promise<{ fileUrl: string }> {
    const formData = new FormData();
    formData.append('file', file);
    
    const response = await apiClient.post(
      `/api/v1/employees/${id}/profile-picture`,
      formData,
      {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      }
    );
    
    return response.data;
  },
  
  async getOrgChart(id: string, levels: number = 2): Promise<OrgChart> {
    const response: AxiosResponse<OrgChart> = await apiClient.get(
      `/api/v1/employees/${id}/org-chart?levels=${levels}`
    );
    
    return response.data;
  },
};
```

---

## 🎓 Certification Exam Alignment

### SAA-C03 Coverage (All Domains)
- **Domain 1 (30%)**: IAM, security groups, encryption, compliance monitoring
- **Domain 2 (26%)**: Auto scaling, load balancing, multi-AZ, decoupling
- **Domain 3 (24%)**: Performance optimization, caching, database design
- **Domain 4 (20%)**: Cost monitoring, resource optimization, lifecycle policies

### SAP-C02 Foundation Topics
- **Complex Architectures**: Multi-tier, microservices, event-driven
- **Enterprise Integration**: Identity federation, hybrid connectivity
- **Cost Management**: Advanced cost optimization and governance
- **Migration Strategies**: Replatforming, modernization patterns

---

## 📊 Success Metrics

### Technical Metrics
- **Performance**: API response times < 200ms (95th percentile)
- **Availability**: 99.9% uptime with automated health checks
- **Scalability**: Support for 10,000+ concurrent users
- **Security**: Zero critical vulnerabilities, SOC 2 compliance ready

### Business Metrics
- **User Experience**: Page load times < 3 seconds
- **Feature Adoption**: >80% feature utilization rate
- **Cost Efficiency**: <$500/month for dev environment
- **Development Velocity**: <2 week feature delivery cycle

---

## 📚 Final Assessment Criteria

### Architecture (25%)
- Proper service decomposition and boundaries
- Appropriate AWS service selection
- Scalability and performance design
- Security and compliance implementation

### Implementation (25%)
- Code quality and best practices
- Error handling and resilience
- Testing coverage and quality
- Documentation completeness

### Operations (25%)
- Monitoring and alerting setup
- CI/CD pipeline implementation
- Infrastructure as Code usage
- Incident response procedures

### Innovation (25%)
- Creative problem solving
- Advanced AWS feature usage
- Performance optimizations
- Cost optimization strategies

---

## 🎉 Congratulations!

Upon completing this capstone project, you will have:

✅ **Built a production-ready, enterprise-grade application**  
✅ **Demonstrated mastery of all AWS core services**  
✅ **Implemented modern DevOps and cloud-native practices**  
✅ **Prepared for both SAA-C03 and SAP-C02 certification exams**  
✅ **Created a portfolio project showcasing your skills**  

This capstone project represents the culmination of your AWS learning journey and serves as a comprehensive demonstration of your ability to architect, implement, and operate complex cloud-native applications on AWS.

**You're now ready to tackle real-world AWS challenges with confidence!** 🚀☁️
