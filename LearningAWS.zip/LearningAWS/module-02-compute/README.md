# Module 2: Compute Services (EC2, ASG, ELB)
**Duration**: 8 hours | **Level**: Beginner to Intermediate | **Certification**: SAA-C03 Domain 2 (Resilient Architectures)

## 🎯 Learning Objectives

By the end of this module, you will be able to:
- Understand AWS compute services and their use cases
- Deploy Spring Boot applications on EC2 instances
- Configure Auto Scaling Groups for high availability
- Implement Load Balancers for traffic distribution
- Design resilient and scalable compute architectures
- Apply EC2 best practices for cost optimization and security

---

## 📚 Module Contents

### 📖 [Theory & Concepts](./theory/)
- [EC2 Fundamentals](./theory/01-ec2-fundamentals.md)
- [Instance Types & Sizing](./theory/02-instance-types.md)
- [Auto Scaling Groups](./theory/03-auto-scaling.md)
- [Elastic Load Balancing](./theory/04-load-balancing.md)
- [High Availability Patterns](./theory/05-ha-patterns.md)

### 💻 [Code Examples](./code-examples/)
- [Spring Boot Deployment Scripts](./code-examples/deployment/)
- [User Data Scripts](./code-examples/user-data/)
- [Health Check Implementations](./code-examples/health-checks/)
- [Auto Scaling Policies](./code-examples/scaling-policies/)

### 🎯 [Hands-on Labs](./hands-on-lab/)
- [Lab 1: Launch EC2 Instance](./hands-on-lab/lab-01-ec2-launch.md)
- [Lab 2: Deploy Spring Boot App](./hands-on-lab/lab-02-spring-deployment.md)
- [Lab 3: Configure Auto Scaling](./hands-on-lab/lab-03-auto-scaling.md)
- [Lab 4: Setup Load Balancer](./hands-on-lab/lab-04-load-balancer.md)
- [Lab 5: End-to-End Architecture](./hands-on-lab/lab-05-complete-setup.md)

### 📝 [Certification Notes](./certification-notes/)
- [SAA-C03 Domain 2 Key Points](./certification-notes/saa-c03-domain2.md)
- [EC2 Exam Tips](./certification-notes/ec2-exam-tips.md)
- [Common Scenarios](./certification-notes/common-scenarios.md)

---

## ⏱️ Time Breakdown

| Section | Duration | Activity Type |
|---------|----------|---------------|
| Theory & Concepts | 2.5 hours | Reading & Diagrams |
| Code Examples Review | 1 hour | Code Analysis |
| Hands-on Labs | 4 hours | Practical Implementation |
| Certification Review | 30 minutes | Exam Prep |

---

## 🏗️ Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                                AWS Region                                        │
│                                                                                 │
│  ┌─────────────────────────────────────────────────────────────────────────┐   │
│  │                            Availability Zone A                          │   │
│  │                                                                         │   │
│  │  ┌─────────────────┐    ┌─────────────────────────────────────────┐   │   │
│  │  │  Public Subnet  │    │           Private Subnet                │   │   │
│  │  │                 │    │                                         │   │   │
│  │  │  ┌─────────────┐│    │  ┌─────────────┐  ┌─────────────────┐ │   │   │
│  │  │  │     ALB     ││    │  │   EC2 Web   │  │   Auto Scaling  │ │   │   │
│  │  │  │             ││    │  │   Server 1  │  │     Group       │ │   │   │
│  │  │  └─────────────┘│    │  └─────────────┘  └─────────────────┘ │   │   │
│  │  └─────────────────┘    └─────────────────────────────────────────┘   │   │
│  └─────────────────────────────────────────────────────────────────────────┘   │
│                                                                                 │
│  ┌─────────────────────────────────────────────────────────────────────────┐   │
│  │                            Availability Zone B                          │   │
│  │                                                                         │   │
│  │  ┌─────────────────┐    ┌─────────────────────────────────────────┐   │   │
│  │  │  Public Subnet  │    │           Private Subnet                │   │   │
│  │  │                 │    │                                         │   │   │
│  │  │  ┌─────────────┐│    │  ┌─────────────┐  ┌─────────────────┐ │   │   │
│  │  │  │   Target    ││    │  │   EC2 Web   │  │   CloudWatch    │ │   │   │
│  │  │  │   Groups    ││    │  │   Server 2  │  │   Monitoring    │ │   │   │
│  │  │  └─────────────┘│    │  └─────────────┘  └─────────────────┘ │   │   │
│  │  └─────────────────┘    └─────────────────────────────────────────┘   │   │
│  └─────────────────────────────────────────────────────────────────────────┘   │
│                                                                                 │
│  ┌─────────────────────────────────────────────────────────────────────────┐   │
│  │                            Internet Gateway                             │   │
│  └─────────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────────┘
```

---

## 🚀 Prerequisites Check

Before starting this module, ensure you have completed:

### From Module 1
- [ ] **AWS CLI configured** with proper credentials
- [ ] **IAM user with EC2 permissions** created
- [ ] **Basic Spring Boot application** from Lab 4
- [ ] **S3 bucket** for deployment artifacts

### Additional Requirements
- [ ] **SSH key pair** for EC2 access
- [ ] **VPC and subnets** (can be default VPC)
- [ ] **Security groups** understanding
- [ ] **Basic Linux commands** knowledge

### Verification Commands
```bash
# Verify AWS CLI access
aws sts get-caller-identity

# Check EC2 permissions
aws ec2 describe-regions

# Verify Spring Boot app builds
cd module-01-basics/spring-aws-demo
mvn clean package
```

---

## 🎯 Learning Path

### Phase 1: Foundation (2 hours)
1. **EC2 Fundamentals** - Understand compute concepts
2. **Instance Types** - Choose right instance for workload
3. **Networking Basics** - VPC, subnets, security groups

### Phase 2: Deployment (3 hours)
1. **Launch EC2 Instance** - Manual deployment
2. **Spring Boot Setup** - Configure application
3. **Automation** - User data scripts and AMIs

### Phase 3: Scaling (2 hours)
1. **Auto Scaling Groups** - Horizontal scaling
2. **Load Balancers** - Traffic distribution
3. **Health Checks** - Application monitoring

### Phase 4: Production Ready (1 hour)
1. **Security Best Practices** - Hardening and compliance
2. **Cost Optimization** - Right-sizing and reserved instances
3. **Monitoring Setup** - CloudWatch integration

---

## 🛠️ Key Technologies

### AWS Services
- **Amazon EC2** - Virtual servers in the cloud
- **Auto Scaling** - Automatic capacity management
- **Elastic Load Balancing** - Distribute incoming traffic
- **CloudWatch** - Monitoring and alerting
- **Systems Manager** - Instance management

### Development Stack
- **Java 21** - Latest LTS version with virtual threads
- **Spring Boot 3.x** - Modern framework with native compilation
- **Maven** - Build and dependency management
- **Docker** - Containerization (preparation for later modules)

### Tools & Scripts
- **Bash/PowerShell** - Automation scripts
- **User Data** - Instance initialization
- **CloudFormation** - Infrastructure as Code
- **AWS CLI** - Command-line operations

---

## 📊 Real-World Use Cases

### E-commerce Platform
```
Challenge: Handle Black Friday traffic spikes
Solution: Auto Scaling + Load Balancers
Benefits: 10x traffic handling, 99.9% uptime
```

### SaaS Application
```
Challenge: Multi-tenant application scaling
Solution: Application Load Balancer with host-based routing
Benefits: Efficient resource utilization, tenant isolation
```

### Enterprise Web Application
```
Challenge: High availability across regions
Solution: Multi-AZ deployment with ELB health checks
Benefits: Zero-downtime deployments, disaster recovery
```

---

## 🎓 Certification Mapping

### SAA-C03 Domain 2: Design Resilient Architectures (26%)

This module covers:
- **2.1** Design scalable and loosely coupled architectures
  - ✅ Auto Scaling Groups implementation
  - ✅ Load balancer configuration
  - ✅ Decoupling application components

- **2.2** Design highly available and/or fault-tolerant architectures
  - ✅ Multi-AZ deployments
  - ✅ Health check implementation
  - ✅ Graceful failure handling

- **2.3** Design decoupling mechanisms
  - ✅ Load balancer patterns
  - ✅ Microservices preparation
  - ✅ Asynchronous processing setup

---

## 🏆 Module Outcomes

### Technical Skills
- Deploy and manage EC2 instances effectively
- Configure auto scaling for dynamic workloads
- Implement load balancing strategies
- Monitor application health and performance
- Optimize costs and security

### Certification Preparation
- Understand EC2 instance types and use cases
- Know when to use different load balancer types
- Master auto scaling policies and triggers
- Apply high availability design patterns

### Real-World Application
- Build production-ready Spring Boot deployments
- Implement monitoring and alerting
- Design for scale and resilience
- Follow AWS Well-Architected principles

---

## 📚 Additional Resources

### AWS Documentation
- [EC2 User Guide](https://docs.aws.amazon.com/ec2/)
- [Auto Scaling User Guide](https://docs.aws.amazon.com/autoscaling/)
- [ELB User Guide](https://docs.aws.amazon.com/elasticloadbalancing/)

### Best Practices
- [EC2 Best Practices](https://docs.aws.amazon.com/ec2/latest/userguide/ec2-best-practices.html)
- [Auto Scaling Best Practices](https://docs.aws.amazon.com/autoscaling/ec2/userguide/auto-scaling-benefits.html)

### Spring Boot on AWS
- [Spring Cloud AWS](https://spring.io/projects/spring-cloud-aws)
- [Spring Boot Actuator](https://spring.io/guides/gs/actuator-service/)

---

## 🔄 Next Module

After completing this module, proceed to:
**[Module 3: Storage & Databases (S3, RDS, DynamoDB)](../module-03-storage/README.md)**

You'll learn how to integrate your Spring Boot application with AWS storage and database services for persistent data management.

---

## 📞 Support & Troubleshooting

### Common Issues
1. **Instance launch failures** - Check IAM permissions and VPC configuration
2. **Application startup errors** - Review user data scripts and logs
3. **Load balancer health check failures** - Verify security groups and endpoint configuration
4. **Auto scaling not triggering** - Check CloudWatch metrics and scaling policies

### Getting Help
- Review CloudWatch logs for application errors
- Use AWS Systems Manager Session Manager for instance access
- Check AWS Trusted Advisor for optimization recommendations
- Consult AWS Support documentation

---

**Ready to build resilient, scalable compute architectures?** 🚀

**Start with**: [Theory: EC2 Fundamentals](./theory/01-ec2-fundamentals.md)
