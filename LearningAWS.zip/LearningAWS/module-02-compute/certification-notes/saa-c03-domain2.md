# SAA-C03 Domain 2: Design Resilient Architectures (26%)

## 🎯 Domain Overview

Domain 2 represents **26% of the SAA-C03 exam** and focuses on designing resilient, highly available, and scalable architectures. This domain tests your ability to design systems that can handle failures gracefully and scale to meet demand.

---

## 📚 Domain Breakdown

### 2.1 Design scalable and loosely coupled architectures (6-8%)

#### Key Topics:
- **Auto Scaling Groups and launch configurations**
- **Load balancer types and use cases**
- **Microservices vs monolithic architectures**
- **Event-driven architectures**
- **Caching strategies**

#### Critical Concepts:

**Auto Scaling Group Configuration**
```java
// Spring Boot health check for ASG
@RestController
public class AutoScalingHealthController {
    
    @GetMapping("/health")
    public ResponseEntity<Map<String, String>> health() {
        // ALB health check - must be fast and simple
        return ResponseEntity.ok(Map.of(
            "status", "UP",
            "timestamp", Instant.now().toString()
        ));
    }
    
    @GetMapping("/health/ready")
    public ResponseEntity<Map<String, Object>> readiness() {
        // Detailed readiness check for traffic routing
        Map<String, Object> checks = new HashMap<>();
        
        // Check critical dependencies
        boolean databaseReady = checkDatabaseConnection();
        boolean cacheReady = checkCacheConnection();
        
        checks.put("database", databaseReady ? "UP" : "DOWN");
        checks.put("cache", cacheReady ? "UP" : "DOWN");
        
        boolean overall = databaseReady && cacheReady;
        
        return overall ? 
            ResponseEntity.ok(Map.of("status", "UP", "checks", checks)) :
            ResponseEntity.status(503).body(Map.of("status", "DOWN", "checks", checks));
    }
}
```

**Load Balancer Types**
| Type | Use Case | Layer | Features |
|------|----------|-------|----------|
| **ALB** | HTTP/HTTPS traffic | Layer 7 | Host/path routing, SSL termination, WAF integration |
| **NLB** | TCP/UDP traffic | Layer 4 | Ultra-low latency, static IP, high throughput |
| **GWLB** | Third-party appliances | Layer 3 | Firewalls, intrusion detection |
| **CLB** | Legacy applications | Layer 4/7 | Basic load balancing (deprecated) |

#### Exam Tips:
- **ALB** supports WebSocket, HTTP/2, and gRPC
- **NLB** preserves source IP address
- **Auto Scaling** can scale based on custom CloudWatch metrics
- **Target Groups** enable blue-green deployments

---

### 2.2 Design highly available and/or fault-tolerant architectures (8-10%)

#### Key Topics:
- **Multi-AZ and multi-region deployments**
- **Disaster recovery strategies**
- **RTO and RPO requirements**
- **Database high availability**
- **Backup and restore strategies**

#### Critical Concepts:

**High Availability Patterns**
```
┌─────────────────────────────────────────────────────────────┐
│                    Multi-AZ Architecture                    │
│                                                             │
│  ┌─────────────────────┐    ┌─────────────────────────┐   │
│  │   Availability      │    │   Availability Zone B  │   │
│  │   Zone A            │    │                         │   │
│  │                     │    │                         │   │
│  │  ┌─────────────────┐│    │  ┌─────────────────────┐│   │
│  │  │      ALB        ││    │  │      ALB Target     ││   │
│  │  │   Target Group  ││    │  │      Group         ││   │
│  │  └─────────────────┘│    │  └─────────────────────┘│   │
│  │                     │    │                         │   │
│  │  ┌─────────────────┐│    │  ┌─────────────────────┐│   │
│  │  │   EC2 Instance  ││    │  │   EC2 Instance     ││   │
│  │  │  (Spring Boot)  ││    │  │  (Spring Boot)     ││   │
│  │  └─────────────────┘│    │  └─────────────────────┘│   │
│  │                     │    │                         │   │
│  │  ┌─────────────────┐│    │  ┌─────────────────────┐│   │
│  │  │   RDS Primary   ││    │  │   RDS Standby      ││   │
│  │  │   (Active)      ││    │  │   (Passive)        ││   │
│  │  └─────────────────┘│    │  └─────────────────────┘│   │
│  └─────────────────────┘    └─────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
```

**Disaster Recovery Strategies**
| Strategy | RTO | RPO | Cost | Use Case |
|----------|-----|-----|------|----------|
| **Backup & Restore** | Hours | Hours | Low | Non-critical workloads |
| **Pilot Light** | 10s of minutes | Minutes | Medium | Critical systems with lower usage |
| **Warm Standby** | Minutes | Minutes | High | Business-critical applications |
| **Multi-Site Active/Active** | Seconds | Seconds | Very High | Mission-critical systems |

**Spring Boot Circuit Breaker Pattern**
```java
@Component
public class ResilientServiceClient {
    
    private final CircuitBreaker circuitBreaker;
    
    public ResilientServiceClient() {
        this.circuitBreaker = CircuitBreaker.ofDefaults("externalService");
        circuitBreaker.getEventPublisher()
            .onStateTransition(event -> 
                log.info("Circuit breaker state transition: {}", event));
    }
    
    public String callExternalService() {
        Supplier<String> decoratedSupplier = CircuitBreaker
            .decorateSupplier(circuitBreaker, () -> {
                // Call external service
                return restTemplate.getForObject("/api/data", String.class);
            });
            
        return Try.ofSupplier(decoratedSupplier)
            .recover(throwable -> {
                log.warn("External service call failed, using fallback", throwable);
                return "Fallback data";
            });
    }
}
```

#### Exam Tips:
- **RDS Multi-AZ** provides synchronous replication for high availability
- **Read Replicas** are for read scaling, not high availability
- **EBS snapshots** are stored in S3 and can be copied across regions
- **S3 Cross-Region Replication** enables disaster recovery

---

### 2.3 Design decoupling mechanisms using AWS services (6-8%)

#### Key Topics:
- **SQS for message queuing**
- **SNS for pub/sub messaging**
- **EventBridge for event routing**
- **API Gateway for service decoupling**
- **Step Functions for workflow orchestration**

#### Critical Concepts:

**Decoupling with SQS**
```java
@Service
public class OrderProcessingService {
    
    @Autowired
    private SqsTemplate sqsTemplate;
    
    // Producer: Send order to queue
    public void submitOrder(Order order) {
        log.info("Submitting order {} to processing queue", order.getId());
        
        sqsTemplate.send("order-processing-queue", order);
    }
    
    // Consumer: Process orders from queue
    @SqsListener("order-processing-queue")
    public void processOrder(Order order) {
        try {
            log.info("Processing order {}", order.getId());
            
            // Process the order
            validateOrder(order);
            chargePayment(order);
            reserveInventory(order);
            sendConfirmation(order);
            
            log.info("Order {} processed successfully", order.getId());
            
        } catch (Exception e) {
            log.error("Failed to process order {}", order.getId(), e);
            // Message will be retried or sent to DLQ
            throw e;
        }
    }
}
```

**Event-Driven Architecture with SNS**
```java
@Component
public class OrderEventPublisher {
    
    @Autowired
    private SnsTemplate snsTemplate;
    
    public void publishOrderEvent(OrderEvent event) {
        try {
            snsTemplate.convertAndSend("order-events-topic", event);
            log.info("Published order event: {}", event.getType());
        } catch (Exception e) {
            log.error("Failed to publish order event", e);
            // Handle publishing failure
        }
    }
}

// Multiple subscribers can listen to the same topic
@Component
public class InventoryService {
    
    @SnsListener("order-events-topic")
    public void handleOrderCreated(OrderCreatedEvent event) {
        // Reserve inventory
        reserveItems(event.getOrderItems());
    }
}

@Component
public class EmailService {
    
    @SnsListener("order-events-topic")
    public void handleOrderCreated(OrderCreatedEvent event) {
        // Send confirmation email
        sendOrderConfirmation(event.getCustomerEmail(), event.getOrderId());
    }
}
```

#### Message Patterns Comparison
| Pattern | AWS Service | Use Case | Delivery |
|---------|-------------|----------|----------|
| **Point-to-Point** | SQS | Task queues, job processing | One consumer |
| **Pub/Sub** | SNS | Event notifications | Multiple subscribers |
| **Event Routing** | EventBridge | Complex routing rules | Filtered delivery |
| **Workflow** | Step Functions | Multi-step processes | Orchestrated |

#### Exam Tips:
- **SQS FIFO** guarantees ordering and exactly-once processing
- **SNS** can deliver to multiple endpoints (email, SMS, SQS, Lambda)
- **EventBridge** supports content-based filtering
- **Dead Letter Queues** handle failed message processing

---

### 2.4 Choose appropriate resilient storage (4-6%)

#### Key Topics:
- **S3 storage classes and lifecycle policies**
- **EBS volume types and backup strategies**
- **EFS for shared file systems**
- **Data durability and availability**

#### Critical Concepts:

**S3 Storage Classes**
| Class | Use Case | Durability | Availability | Cost |
|-------|----------|------------|--------------|------|
| **Standard** | Frequently accessed | 99.999999999% | 99.99% | Highest |
| **IA** | Infrequent access | 99.999999999% | 99.9% | Medium |
| **Glacier** | Long-term backup | 99.999999999% | 99.99% | Low |
| **Deep Archive** | Compliance/Archive | 99.999999999% | 99.99% | Lowest |

**EBS Volume Types**
| Type | Use Case | IOPS | Throughput | Cost |
|------|----------|------|------------|------|
| **gp3** | General purpose | 3,000-16,000 | 125-1,000 MB/s | Balanced |
| **io2** | High IOPS | Up to 64,000 | Up to 1,000 MB/s | Highest |
| **st1** | Throughput optimized | 500 | 40-500 MB/s | Medium |
| **sc1** | Cold HDD | 250 | 12-250 MB/s | Lowest |

**Spring Boot with EFS**
```java
@Configuration
public class FileStorageConfig {
    
    @Value("${app.storage.efs.mount-point:/mnt/efs}")
    private String efsMountPoint;
    
    @Bean
    public FileStorageService fileStorageService() {
        // Use EFS for shared file storage across instances
        return new EfsFileStorageService(efsMountPoint);
    }
}

@Service
public class EfsFileStorageService implements FileStorageService {
    
    private final String mountPoint;
    
    public void saveFile(String fileName, byte[] content) {
        Path filePath = Paths.get(mountPoint, fileName);
        
        try {
            Files.createDirectories(filePath.getParent());
            Files.write(filePath, content, StandardOpenOption.CREATE);
            log.info("File saved to EFS: {}", filePath);
        } catch (IOException e) {
            log.error("Failed to save file to EFS", e);
            throw new RuntimeException("File storage failed", e);
        }
    }
}
```

#### Exam Tips:
- **S3** provides 99.999999999% (11 9's) durability
- **EBS snapshots** are incremental and stored in S3
- **EFS** provides shared storage across multiple AZs
- **S3 Lifecycle policies** can automatically transition objects

---

## 🎯 Common Exam Scenarios

### Scenario 1: High Availability Web Application
**Question**: "Web application needs 99.9% uptime with automatic scaling during traffic spikes."

**Answer**:
- Deploy across multiple AZs using Auto Scaling Groups
- Use Application Load Balancer for traffic distribution
- Configure health checks for automatic instance replacement
- Use RDS Multi-AZ for database high availability

### Scenario 2: Microservices Decoupling
**Question**: "Monolithic application needs to be broken into microservices with loose coupling."

**Answer**:
- Use API Gateway for service discovery and routing
- Implement SQS for asynchronous communication
- Use SNS for event-driven architecture
- Store shared data in managed databases (RDS, DynamoDB)

### Scenario 3: Disaster Recovery
**Question**: "Critical application needs RPO < 1 hour and RTO < 30 minutes."

**Answer**:
- Implement warm standby in secondary region
- Use RDS cross-region read replicas
- Automate failover with Route 53 health checks
- Use S3 cross-region replication for data

### Scenario 4: Cost-Optimized Storage
**Question**: "Large amounts of data with varying access patterns needs cost optimization."

**Answer**:
- Use S3 Intelligent Tiering for unknown access patterns
- Implement lifecycle policies for predictable patterns
- Use S3 Storage Lens for optimization insights
- Consider EFS IA for infrequently accessed shared files

---

## 🎓 Study Strategy

### Week 1: Scaling Foundations
- [ ] Auto Scaling Groups configuration and policies
- [ ] Load balancer types and use cases
- [ ] Hands-on: Deploy multi-AZ application with ALB

### Week 2: High Availability
- [ ] Multi-AZ and multi-region patterns
- [ ] RDS high availability options
- [ ] Hands-on: Implement disaster recovery strategy

### Week 3: Decoupling Services
- [ ] SQS, SNS, and EventBridge patterns
- [ ] API Gateway and microservices
- [ ] Hands-on: Build event-driven architecture

### Week 4: Storage Strategies
- [ ] S3 storage classes and lifecycle policies
- [ ] EBS and EFS use cases
- [ ] Hands-on: Implement backup and restore strategy

---

## 📝 Key Formulas and Rules

### High Availability Calculation
```
Availability = (Total Time - Downtime) / Total Time × 100%

99.9% = 8.76 hours downtime per year
99.99% = 52.56 minutes downtime per year
99.999% = 5.26 minutes downtime per year
```

### Auto Scaling Policies
```
Target Tracking: Maintains specific metric value
Step Scaling: Scales based on CloudWatch alarm breach size
Simple Scaling: Scales based on single alarm
```

### Storage Durability
```
S3 Standard: 99.999999999% (11 9's) = 1 object loss per 10 billion objects per year
EBS: 99.999% to 99.5% depending on volume type
```

---

## 🔗 Additional Resources

### AWS Documentation
- [Auto Scaling User Guide](https://docs.aws.amazon.com/autoscaling/)
- [Elastic Load Balancing Guide](https://docs.aws.amazon.com/elasticloadbalancing/)
- [Well-Architected Reliability Pillar](https://docs.aws.amazon.com/wellarchitected/latest/reliability-pillar/)

### Hands-on Practice
- [AWS Resilience Hub](https://aws.amazon.com/resilience-hub/)
- [Disaster Recovery Workshop](https://disaster-recovery.workshop.aws/)
- [Microservices Workshop](https://microservices.workshop.aws/)

### Java Integration
```java
// Complete Spring Boot resilience configuration
@Configuration
@EnableRetry
public class ResilienceConfig {
    
    @Bean
    @Retryable(value = {Exception.class}, maxAttempts = 3)
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }
    
    @Bean
    public CircuitBreaker circuitBreaker() {
        return CircuitBreaker.ofDefaults("default");
    }
    
    @Bean
    public TimeLimiter timeLimiter() {
        return TimeLimiter.of(Duration.ofSeconds(10));
    }
}
```

---

## ✅ Self-Assessment Questions

1. **When would you choose NLB over ALB for your application?**
2. **How do you implement zero-downtime deployments with Auto Scaling?**
3. **What's the difference between RDS Multi-AZ and Read Replicas?**
4. **How do you decouple microservices using AWS messaging services?**
5. **What storage strategy would you use for a data lake with mixed access patterns?**

---

**Next Domain**: [Domain 3: Design High-Performing Architectures](./saa-c03-domain3.md)

---

**Remember**: Domain 2 is worth 26% of your exam score. Focus on hands-on practice with Auto Scaling, Load Balancers, and messaging services to build real-world experience! 🎯
