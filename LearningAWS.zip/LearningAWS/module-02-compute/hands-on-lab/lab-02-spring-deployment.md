# Lab 2: Deploy Spring Boot Application on EC2

**Duration**: 60 minutes | **Difficulty**: Intermediate

## 🎯 Objectives

By the end of this lab, you will:
- Deploy the Spring Boot application from Module 1 to EC2
- Configure the application for production use
- Implement health checks and monitoring
- Set up automated deployment using user data scripts
- Secure the application with proper IAM roles and security groups

---

## 📋 Prerequisites

Before starting this lab, ensure:
- [ ] Completed Module 1 (Spring Boot + AWS SDK integration)
- [ ] EC2 instance launched (from Lab 1)
- [ ] SSH access to the instance configured
- [ ] Spring Boot application JAR file available
- [ ] IAM role for EC2 with S3 access

---

## 🛠️ Lab Steps

### Step 1: Prepare Spring Boot Application for Production

#### Update Application Configuration

Create `src/main/resources/application-prod.yml`:

```yaml
# Production configuration
spring:
  profiles:
    active: prod
  application:
    name: spring-aws-demo

# Server configuration for production
server:
  port: 8080
  servlet:
    context-path: /
  shutdown: graceful
  tomcat:
    threads:
      max: 200
      min-spare: 10
    connection-timeout: 20s
    keep-alive-timeout: 30s

# AWS Configuration for production
aws:
  region: ${AWS_REGION:us-east-1}
  s3:
    default-bucket: ${AWS_S3_BUCKET:spring-aws-demo-prod}

# Actuator configuration for health checks
management:
  endpoints:
    web:
      exposure:
        include: health,info,metrics,env
      base-path: /actuator
  endpoint:
    health:
      show-details: when-authorized
      probes:
        enabled: true
  health:
    diskspace:
      enabled: true
      threshold: 10GB
    db:
      enabled: false
  server:
    port: 8081

# Logging configuration
logging:
  level:
    com.example.awsdemo: INFO
    software.amazon.awssdk: WARN
    org.springframework.web: WARN
  pattern:
    console: "%d{yyyy-MM-dd HH:mm:ss} - %msg%n"
    file: "%d{yyyy-MM-dd HH:mm:ss} [%thread] %-5level %logger{36} - %msg%n"
  file:
    name: /var/log/spring-aws-demo/application.log
    max-size: 100MB
    max-history: 10
```

#### Create Production Health Check Controller

Create `src/main/java/com/example/awsdemo/controller/HealthController.java`:

```java
package com.example.awsdemo.controller;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuator.health.Health;
import org.springframework.boot.actuator.health.HealthIndicator;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.awsdemo.service.S3Service;

/**
 * Health check controller for Load Balancer and monitoring.
 * 
 * Provides multiple endpoints for different health check types:
 * - ALB health checks
 * - Deep health checks with dependencies
 * - Readiness and liveness probes
 */
@RestController
public class HealthController {

    private static final Logger logger = LoggerFactory.getLogger(HealthController.class);

    @Autowired
    private S3Service s3Service;

    /**
     * Simple health check for ALB target group.
     * Fast response without external dependencies.
     */
    @GetMapping("/health")
    public ResponseEntity<Map<String, Object>> health() {
        Map<String, Object> response = new HashMap<>();
        response.put("status", "UP");
        response.put("timestamp", Instant.now().toString());
        response.put("service", "spring-aws-demo");
        response.put("version", "1.0.0");
        
        return ResponseEntity.ok(response);
    }

    /**
     * Kubernetes-style liveness probe.
     * Indicates if the application is running.
     */
    @GetMapping("/health/live")
    public ResponseEntity<Map<String, Object>> liveness() {
        Map<String, Object> response = new HashMap<>();
        response.put("status", "UP");
        response.put("type", "liveness");
        response.put("timestamp", Instant.now().toString());
        
        return ResponseEntity.ok(response);
    }

    /**
     * Kubernetes-style readiness probe.
     * Indicates if the application is ready to serve traffic.
     */
    @GetMapping("/health/ready")
    public ResponseEntity<Map<String, Object>> readiness() {
        Map<String, Object> response = new HashMap<>();
        
        try {
            // Check critical dependencies
            boolean s3Healthy = checkS3Health();
            
            if (s3Healthy) {
                response.put("status", "UP");
                response.put("type", "readiness");
                response.put("timestamp", Instant.now().toString());
                response.put("dependencies", Map.of("s3", "UP"));
                
                return ResponseEntity.ok(response);
            } else {
                response.put("status", "DOWN");
                response.put("type", "readiness");
                response.put("timestamp", Instant.now().toString());
                response.put("dependencies", Map.of("s3", "DOWN"));
                
                return ResponseEntity.status(503).body(response);
            }
        } catch (Exception e) {
            logger.error("Readiness check failed", e);
            
            response.put("status", "DOWN");
            response.put("type", "readiness");
            response.put("timestamp", Instant.now().toString());
            response.put("error", e.getMessage());
            
            return ResponseEntity.status(503).body(response);
        }
    }

    /**
     * Deep health check with external dependencies.
     * Use this for monitoring and alerting.
     */
    @GetMapping("/health/deep")
    public ResponseEntity<Map<String, Object>> deepHealth() {
        Map<String, Object> response = new HashMap<>();
        Map<String, Object> dependencies = new HashMap<>();
        
        try {
            // Check S3 connectivity
            long s3StartTime = System.currentTimeMillis();
            boolean s3Healthy = checkS3Health();
            long s3ResponseTime = System.currentTimeMillis() - s3StartTime;
            
            dependencies.put("s3", Map.of(
                "status", s3Healthy ? "UP" : "DOWN",
                "responseTime", s3ResponseTime + "ms"
            ));

            // Check disk space
            long totalSpace = Runtime.getRuntime().totalMemory();
            long freeSpace = Runtime.getRuntime().freeMemory();
            long usedMemory = totalSpace - freeSpace;
            double memoryUsagePercent = (double) usedMemory / totalSpace * 100;
            
            dependencies.put("memory", Map.of(
                "status", memoryUsagePercent < 90 ? "UP" : "WARNING",
                "usagePercent", String.format("%.2f%%", memoryUsagePercent),
                "totalMB", totalSpace / 1024 / 1024,
                "usedMB", usedMemory / 1024 / 1024
            ));

            boolean overallHealthy = s3Healthy && memoryUsagePercent < 95;
            
            response.put("status", overallHealthy ? "UP" : "DOWN");
            response.put("type", "deep");
            response.put("timestamp", Instant.now().toString());
            response.put("dependencies", dependencies);
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            logger.error("Deep health check failed", e);
            
            response.put("status", "DOWN");
            response.put("type", "deep");
            response.put("timestamp", Instant.now().toString());
            response.put("error", e.getMessage());
            response.put("dependencies", dependencies);
            
            return ResponseEntity.status(503).body(response);
        }
    }

    private boolean checkS3Health() {
        try {
            String defaultBucket = s3Service.getDefaultBucket();
            return s3Service.doesBucketExist(defaultBucket);
        } catch (Exception e) {
            logger.warn("S3 health check failed: {}", e.getMessage());
            return false;
        }
    }
}
```

#### Build Production JAR

Update `pom.xml` to include production profile:

```xml
<profiles>
    <profile>
        <id>prod</id>
        <properties>
            <spring.profiles.active>prod</spring.profiles.active>
        </properties>
        <build>
            <plugins>
                <plugin>
                    <groupId>org.springframework.boot</groupId>
                    <artifactId>spring-boot-maven-plugin</artifactId>
                    <configuration>
                        <profiles>
                            <profile>prod</profile>
                        </profiles>
                    </configuration>
                </plugin>
            </plugins>
        </build>
    </profile>
</profiles>
```

Build the application:

```bash
# Build production JAR
mvn clean package -Pprod

# Verify JAR was created
ls -la target/spring-aws-demo-1.0.0.jar
```

### Step 2: Upload Application to S3

Create deployment bucket and upload artifacts:

```bash
# Create deployment bucket
BUCKET_NAME="spring-aws-deployments-$(date +%s)"
aws s3 mb s3://$BUCKET_NAME

# Upload JAR file
aws s3 cp target/spring-aws-demo-1.0.0.jar s3://$BUCKET_NAME/

# Upload deployment scripts (we'll create these next)
aws s3 cp deployment-scripts/ s3://$BUCKET_NAME/scripts/ --recursive
```

### Step 3: Create Deployment Scripts

#### Create Application Start Script

Create `deployment-scripts/start-application.sh`:

```bash
#!/bin/bash

# Spring Boot Application Startup Script for EC2
# This script downloads and starts the Spring Boot application

set -e  # Exit on any error

# Configuration
APP_NAME="spring-aws-demo"
APP_VERSION="1.0.0"
APP_JAR="${APP_NAME}-${APP_VERSION}.jar"
APP_DIR="/opt/${APP_NAME}"
LOG_DIR="/var/log/${APP_NAME}"
SERVICE_USER="springboot"
S3_BUCKET="${S3_DEPLOYMENT_BUCKET}"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

log() {
    echo -e "${GREEN}[$(date +'%Y-%m-%d %H:%M:%S')] $1${NC}"
}

warn() {
    echo -e "${YELLOW}[$(date +'%Y-%m-%d %H:%M:%S')] WARNING: $1${NC}"
}

error() {
    echo -e "${RED}[$(date +'%Y-%m-%d %H:%M:%S')] ERROR: $1${NC}"
}

# Function to check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Install required packages
install_dependencies() {
    log "Installing required packages..."
    
    # Update package manager
    if command_exists yum; then
        yum update -y
        yum install -y java-21-amazon-corretto-devel wget curl unzip
    elif command_exists apt-get; then
        apt-get update
        apt-get install -y openjdk-21-jdk wget curl unzip
    else
        error "Unsupported package manager"
        exit 1
    fi
    
    # Verify Java installation
    java -version
    log "Java installation completed"
}

# Create application user and directories
setup_application_user() {
    log "Setting up application user and directories..."
    
    # Create service user
    if ! id "$SERVICE_USER" &>/dev/null; then
        useradd -r -s /bin/false -d $APP_DIR $SERVICE_USER
        log "Created user: $SERVICE_USER"
    fi
    
    # Create directories
    mkdir -p $APP_DIR
    mkdir -p $LOG_DIR
    
    # Set permissions
    chown -R $SERVICE_USER:$SERVICE_USER $APP_DIR
    chown -R $SERVICE_USER:$SERVICE_USER $LOG_DIR
    chmod 755 $APP_DIR
    chmod 755 $LOG_DIR
    
    log "Application directories created"
}

# Download application from S3
download_application() {
    log "Downloading application from S3..."
    
    if [ -z "$S3_BUCKET" ]; then
        error "S3_DEPLOYMENT_BUCKET environment variable is not set"
        exit 1
    fi
    
    # Download JAR file
    aws s3 cp s3://$S3_BUCKET/$APP_JAR $APP_DIR/
    
    if [ ! -f "$APP_DIR/$APP_JAR" ]; then
        error "Failed to download $APP_JAR from S3"
        exit 1
    fi
    
    # Set permissions
    chown $SERVICE_USER:$SERVICE_USER $APP_DIR/$APP_JAR
    chmod 644 $APP_DIR/$APP_JAR
    
    log "Application downloaded successfully"
}

# Create systemd service file
create_systemd_service() {
    log "Creating systemd service..."
    
    cat > /etc/systemd/system/${APP_NAME}.service << EOF
[Unit]
Description=Spring Boot AWS Demo Application
After=network.target

[Service]
Type=simple
User=$SERVICE_USER
Group=$SERVICE_USER
WorkingDirectory=$APP_DIR
ExecStart=/usr/bin/java -jar $APP_DIR/$APP_JAR --spring.profiles.active=prod
Restart=on-failure
RestartSec=10
StandardOutput=journal
StandardError=journal
SyslogIdentifier=$APP_NAME

# JVM Options
Environment="JAVA_OPTS=-Xms512m -Xmx1g -XX:+UseG1GC -XX:MaxGCPauseMillis=200"

# Application Environment
Environment="SPRING_PROFILES_ACTIVE=prod"
Environment="SERVER_PORT=8080"
Environment="MANAGEMENT_SERVER_PORT=8081"

# AWS Configuration
Environment="AWS_REGION=us-east-1"

[Install]
WantedBy=multi-user.target
EOF
    
    # Reload systemd and enable service
    systemctl daemon-reload
    systemctl enable ${APP_NAME}.service
    
    log "Systemd service created and enabled"
}

# Configure CloudWatch logging
setup_cloudwatch_logging() {
    log "Setting up CloudWatch logging..."
    
    # Install CloudWatch agent
    wget https://s3.amazonaws.com/amazoncloudwatch-agent/amazon_linux/amd64/latest/amazon-cloudwatch-agent.rpm
    rpm -U ./amazon-cloudwatch-agent.rpm
    
    # Create CloudWatch agent configuration
    cat > /opt/aws/amazon-cloudwatch-agent/etc/amazon-cloudwatch-agent.json << EOF
{
    "logs": {
        "logs_collected": {
            "files": {
                "collect_list": [
                    {
                        "file_path": "$LOG_DIR/application.log",
                        "log_group_name": "/aws/ec2/$APP_NAME",
                        "log_stream_name": "{instance_id}",
                        "timezone": "UTC"
                    },
                    {
                        "file_path": "/var/log/messages",
                        "log_group_name": "/aws/ec2/system",
                        "log_stream_name": "{instance_id}",
                        "timezone": "UTC"
                    }
                ]
            }
        }
    },
    "metrics": {
        "namespace": "EC2/SpringBoot",
        "metrics_collected": {
            "cpu": {
                "measurement": [
                    "cpu_usage_idle",
                    "cpu_usage_iowait",
                    "cpu_usage_system",
                    "cpu_usage_user"
                ],
                "metrics_collection_interval": 60
            },
            "disk": {
                "measurement": [
                    "used_percent"
                ],
                "metrics_collection_interval": 60,
                "resources": [
                    "*"
                ]
            },
            "mem": {
                "measurement": [
                    "mem_used_percent"
                ],
                "metrics_collection_interval": 60
            }
        }
    }
}
EOF
    
    # Start CloudWatch agent
    /opt/aws/amazon-cloudwatch-agent/bin/amazon-cloudwatch-agent-ctl \
        -a fetch-config \
        -m ec2 \
        -c file:/opt/aws/amazon-cloudwatch-agent/etc/amazon-cloudwatch-agent.json \
        -s
    
    log "CloudWatch logging configured"
}

# Start the application
start_application() {
    log "Starting application..."
    
    # Start the service
    systemctl start ${APP_NAME}.service
    
    # Wait for application to start
    log "Waiting for application to start..."
    sleep 30
    
    # Check if service is running
    if systemctl is-active --quiet ${APP_NAME}.service; then
        log "Application started successfully"
        
        # Test health endpoint
        local max_attempts=30
        local attempt=1
        
        while [ $attempt -le $max_attempts ]; do
            if curl -f http://localhost:8080/health >/dev/null 2>&1; then
                log "Health check passed"
                break
            fi
            
            log "Health check attempt $attempt/$max_attempts failed, retrying..."
            sleep 10
            attempt=$((attempt + 1))
        done
        
        if [ $attempt -gt $max_attempts ]; then
            error "Health check failed after $max_attempts attempts"
            journalctl -u ${APP_NAME}.service --no-pager --lines=50
            exit 1
        fi
        
    else
        error "Application failed to start"
        journalctl -u ${APP_NAME}.service --no-pager --lines=50
        exit 1
    fi
}

# Main execution
main() {
    log "Starting Spring Boot application deployment..."
    
    install_dependencies
    setup_application_user
    download_application
    create_systemd_service
    setup_cloudwatch_logging
    start_application
    
    log "Deployment completed successfully!"
    log "Application is running on http://localhost:8080"
    log "Health check available at http://localhost:8080/health"
    log "Actuator endpoints available at http://localhost:8081/actuator"
}

# Run main function
main "$@"
```

#### Create Stop Script

Create `deployment-scripts/stop-application.sh`:

```bash
#!/bin/bash

# Spring Boot Application Stop Script

APP_NAME="spring-aws-demo"

echo "Stopping $APP_NAME..."

# Stop the service
systemctl stop ${APP_NAME}.service

# Check if stopped
if systemctl is-active --quiet ${APP_NAME}.service; then
    echo "Failed to stop $APP_NAME"
    exit 1
else
    echo "$APP_NAME stopped successfully"
fi
```

### Step 4: Create User Data Script

Create EC2 user data script for automated deployment:

```bash
#!/bin/bash

# EC2 User Data Script for Spring Boot Deployment
# This script runs when the instance starts

# Set environment variables
export S3_DEPLOYMENT_BUCKET="your-deployment-bucket-name"  # Replace with your bucket
export AWS_DEFAULT_REGION="us-east-1"

# Log all output
exec > >(tee /var/log/user-data.log|logger -t user-data -s 2>/dev/console) 2>&1

echo "Starting user data script execution..."

# Download and execute deployment script
cd /tmp
aws s3 cp s3://$S3_DEPLOYMENT_BUCKET/scripts/start-application.sh .
chmod +x start-application.sh
./start-application.sh

echo "User data script execution completed"
```

### Step 5: Launch EC2 Instance with Application

Create CloudFormation template for automated deployment:

Create `deployment-scripts/ec2-spring-boot.yaml`:

```yaml
AWSTemplateFormatVersion: '2010-09-09'
Description: 'EC2 instance with Spring Boot application deployment'

Parameters:
  KeyPairName:
    Type: AWS::EC2::KeyPair::KeyName
    Description: Name of an existing EC2 KeyPair for SSH access
    
  InstanceType:
    Type: String
    Default: t3.micro
    AllowedValues: [t3.micro, t3.small, t3.medium]
    Description: EC2 instance type
    
  DeploymentBucket:
    Type: String
    Description: S3 bucket containing deployment artifacts
    
  SubnetId:
    Type: AWS::EC2::Subnet::Id
    Description: Subnet for the EC2 instance
    
  VpcId:
    Type: AWS::EC2::VPC::Id
    Description: VPC for security group

Resources:
  # IAM Role for EC2 instance
  EC2Role:
    Type: AWS::IAM::Role
    Properties:
      AssumeRolePolicyDocument:
        Version: '2012-10-17'
        Statement:
          - Effect: Allow
            Principal:
              Service: ec2.amazonaws.com
            Action: sts:AssumeRole
      ManagedPolicyArns:
        - arn:aws:iam::aws:policy/CloudWatchAgentServerPolicy
      Policies:
        - PolicyName: S3DeploymentAccess
          PolicyDocument:
            Version: '2012-10-17'
            Statement:
              - Effect: Allow
                Action:
                  - s3:GetObject
                  - s3:ListBucket
                Resource:
                  - !Sub 'arn:aws:s3:::${DeploymentBucket}'
                  - !Sub 'arn:aws:s3:::${DeploymentBucket}/*'
        - PolicyName: CloudWatchLogs
          PolicyDocument:
            Version: '2012-10-17'
            Statement:
              - Effect: Allow
                Action:
                  - logs:CreateLogGroup
                  - logs:CreateLogStream
                  - logs:PutLogEvents
                  - logs:DescribeLogStreams
                Resource: '*'

  # Instance Profile
  EC2InstanceProfile:
    Type: AWS::IAM::InstanceProfile
    Properties:
      Roles:
        - !Ref EC2Role

  # Security Group
  SpringBootSecurityGroup:
    Type: AWS::EC2::SecurityGroup
    Properties:
      GroupDescription: Security group for Spring Boot application
      VpcId: !Ref VpcId
      SecurityGroupIngress:
        - IpProtocol: tcp
          FromPort: 22
          ToPort: 22
          CidrIp: 0.0.0.0/0
          Description: SSH access
        - IpProtocol: tcp
          FromPort: 8080
          ToPort: 8080
          CidrIp: 0.0.0.0/0
          Description: Spring Boot application
        - IpProtocol: tcp
          FromPort: 8081
          ToPort: 8081
          CidrIp: 10.0.0.0/8
          Description: Actuator endpoints (internal only)
      SecurityGroupEgress:
        - IpProtocol: -1
          CidrIp: 0.0.0.0/0
          Description: All outbound traffic

  # EC2 Instance
  SpringBootInstance:
    Type: AWS::EC2::Instance
    Properties:
      ImageId: ami-0c02fb55956c7d316  # Amazon Linux 2023
      InstanceType: !Ref InstanceType
      KeyName: !Ref KeyPairName
      SubnetId: !Ref SubnetId
      SecurityGroupIds:
        - !Ref SpringBootSecurityGroup
      IamInstanceProfile: !Ref EC2InstanceProfile
      UserData:
        Fn::Base64: !Sub |
          #!/bin/bash
          yum update -y
          
          # Set environment variables
          export S3_DEPLOYMENT_BUCKET="${DeploymentBucket}"
          export AWS_DEFAULT_REGION="${AWS::Region}"
          
          # Log all output
          exec > >(tee /var/log/user-data.log|logger -t user-data -s 2>/dev/console) 2>&1
          
          echo "Starting user data script execution..."
          
          # Download and execute deployment script
          cd /tmp
          aws s3 cp s3://$S3_DEPLOYMENT_BUCKET/scripts/start-application.sh .
          chmod +x start-application.sh
          ./start-application.sh
          
          echo "User data script execution completed"
      Tags:
        - Key: Name
          Value: SpringBoot-Demo-Instance
        - Key: Application
          Value: spring-aws-demo
        - Key: Environment
          Value: dev

Outputs:
  InstanceId:
    Description: EC2 Instance ID
    Value: !Ref SpringBootInstance
    
  PublicIP:
    Description: Public IP address
    Value: !GetAtt SpringBootInstance.PublicIp
    
  PrivateIP:
    Description: Private IP address
    Value: !GetAtt SpringBootInstance.PrivateIp
    
  ApplicationURL:
    Description: Spring Boot application URL
    Value: !Sub 'http://${SpringBootInstance.PublicIp}:8080'
    
  HealthCheckURL:
    Description: Health check URL
    Value: !Sub 'http://${SpringBootInstance.PublicIp}:8080/health'
```

### Step 6: Deploy Using CloudFormation

```bash
# Upload deployment scripts to S3
aws s3 cp deployment-scripts/ s3://$BUCKET_NAME/scripts/ --recursive

# Deploy CloudFormation stack
aws cloudformation create-stack \
  --stack-name spring-boot-ec2-demo \
  --template-body file://deployment-scripts/ec2-spring-boot.yaml \
  --parameters \
    ParameterKey=KeyPairName,ParameterValue=your-key-pair \
    ParameterKey=DeploymentBucket,ParameterValue=$BUCKET_NAME \
    ParameterKey=SubnetId,ParameterValue=subnet-xxxxxxxx \
    ParameterKey=VpcId,ParameterValue=vpc-xxxxxxxx \
  --capabilities CAPABILITY_IAM

# Wait for stack creation
aws cloudformation wait stack-create-complete \
  --stack-name spring-boot-ec2-demo

# Get outputs
aws cloudformation describe-stacks \
  --stack-name spring-boot-ec2-demo \
  --query 'Stacks[0].Outputs'
```

### Step 7: Test the Deployment

```bash
# Get the public IP from CloudFormation output
PUBLIC_IP=$(aws cloudformation describe-stacks \
  --stack-name spring-boot-ec2-demo \
  --query 'Stacks[0].Outputs[?OutputKey==`PublicIP`].OutputValue' \
  --output text)

# Test health endpoint
curl http://$PUBLIC_IP:8080/health

# Test application endpoints
curl http://$PUBLIC_IP:8080/api/s3/health

# Upload a test file
curl -X POST http://$PUBLIC_IP:8080/api/s3/files \
  -H "Content-Type: application/json" \
  -d '{
    "key": "production-test.txt",
    "content": "Hello from production EC2 deployment!"
  }'

# List files
curl http://$PUBLIC_IP:8080/api/s3/files
```

### Step 8: Monitor and Verify

#### Check Application Status

```bash
# SSH to the instance
ssh -i your-key.pem ec2-user@$PUBLIC_IP

# Check service status
sudo systemctl status spring-aws-demo

# View logs
sudo journalctl -u spring-aws-demo.service -f

# Check application logs
sudo tail -f /var/log/spring-aws-demo/application.log
```

#### Verify CloudWatch Integration

```bash
# Check CloudWatch log groups
aws logs describe-log-groups \
  --log-group-name-prefix "/aws/ec2/spring-aws-demo"

# View recent log events
aws logs describe-log-streams \
  --log-group-name "/aws/ec2/spring-aws-demo" \
  --order-by LastEventTime \
  --descending \
  --max-items 1

# Get CloudWatch metrics
aws cloudwatch get-metric-statistics \
  --namespace "EC2/SpringBoot" \
  --metric-name "cpu_usage_user" \
  --start-time $(date -u -d '1 hour ago' +%Y-%m-%dT%H:%M:%S) \
  --end-time $(date -u +%Y-%m-%dT%H:%M:%S) \
  --period 300 \
  --statistics Average
```

---

## ✅ Verification Checklist

After completing this lab, verify:

- [ ] **Application deployed successfully** and accessible via public IP
- [ ] **Health checks responding** at `/health`, `/health/live`, `/health/ready`
- [ ] **S3 integration working** - can upload and download files
- [ ] **CloudWatch logging configured** - logs visible in CloudWatch
- [ ] **Systemd service running** - application starts automatically
- [ ] **Security groups configured** - only required ports open
- [ ] **IAM role attached** - no hardcoded credentials needed
- [ ] **User data script completed** successfully

---

## 🎯 Key Learning Points

### 1. Production Configuration
- Separate configuration profiles for different environments
- Externalized configuration using environment variables
- Proper logging setup for troubleshooting

### 2. Health Checks
- Multiple health check endpoints for different purposes
- Dependency checks for external services
- Proper HTTP status codes for load balancer integration

### 3. Deployment Automation
- User data scripts for instance initialization
- CloudFormation for repeatable infrastructure
- S3 for artifact storage and distribution

### 4. Security Best Practices
- IAM roles instead of access keys
- Least privilege permissions
- Security groups with minimal required access

### 5. Monitoring and Observability
- CloudWatch integration for logs and metrics
- Structured logging for better analysis
- Health endpoints for automated monitoring

---

## 🚀 Next Steps

### Immediate Improvements
1. **Implement Blue-Green Deployment** using multiple instances
2. **Add Application Load Balancer** for high availability
3. **Configure Auto Scaling** based on metrics
4. **Set up CloudWatch Alarms** for automated monitoring

### Advanced Features
1. **Implement Circuit Breakers** for external service calls
2. **Add Distributed Tracing** with AWS X-Ray
3. **Configure SSL/TLS** termination
4. **Implement Log Aggregation** with centralized logging

---

## 🔧 Troubleshooting

### Common Issues

**Issue**: Application fails to start
```bash
# Check user data logs
sudo cat /var/log/user-data.log

# Check application service logs
sudo journalctl -u spring-aws-demo.service --no-pager

# Check Java installation
java -version
```

**Issue**: Health checks failing
```bash
# Test locally on the instance
curl http://localhost:8080/health

# Check if application is listening
sudo netstat -tlnp | grep 8080

# Check application logs for errors
sudo tail -f /var/log/spring-aws-demo/application.log
```

**Issue**: S3 access denied
```bash
# Check IAM role permissions
aws sts get-caller-identity

# Test S3 access manually
aws s3 ls

# Check bucket permissions
aws s3api get-bucket-policy --bucket your-bucket-name
```

**Issue**: CloudWatch logs not appearing
```bash
# Check CloudWatch agent status
sudo /opt/aws/amazon-cloudwatch-agent/bin/amazon-cloudwatch-agent-ctl \
  -m ec2 -c file:/opt/aws/amazon-cloudwatch-agent/etc/amazon-cloudwatch-agent.json \
  -a query

# Restart CloudWatch agent
sudo systemctl restart amazon-cloudwatch-agent
```

---

## 📝 Certification Notes

### SAA-C03 Relevance
- **Domain 2**: Resilient architectures with health checks and monitoring
- **Domain 1**: Secure access using IAM roles and security groups
- **Best Practices**: Automation, monitoring, and security

### Key Exam Points
- **User Data Scripts**: Automate instance configuration at launch
- **IAM Roles for EC2**: Secure way to provide AWS access to applications
- **Health Checks**: Essential for load balancer and auto scaling integration
- **CloudWatch Integration**: Monitoring and logging best practices

---

**Congratulations!** 🎉 You've successfully deployed a production-ready Spring Boot application on EC2 with proper monitoring, security, and automation.

**Next**: [Lab 3: Configure Auto Scaling](./lab-03-auto-scaling.md) to make your deployment highly available and scalable.
