# Last-Minute Study Guide
**Quick reference for final exam preparation** | **Review Time**: 60-90 minutes

---

## 🎯 Exam Day Strategy

### 24 Hours Before Exam:
- [ ] **Review this guide** (don't learn new concepts)
- [ ] **Get 7-8 hours sleep** 
- [ ] **Prepare exam logistics** (location, login, ID)
- [ ] **Light review only** (avoid cramming)

### 2 Hours Before Exam:
- [ ] **Light meal** (avoid heavy foods)
- [ ] **Review key formulas** (below)
- [ ] **Calm, confident mindset**
- [ ] **Arrive early** or log in 30 minutes before

---

## 📊 Quick Facts & Formulas

### AWS Availability Calculations
- **99.9%** = 8.76 hours downtime/year = 43.8 minutes/month
- **99.95%** = 4.38 hours downtime/year = 21.9 minutes/month  
- **99.99%** = 52.56 minutes downtime/year = 4.38 minutes/month
- **99.999%** = 5.26 minutes downtime/year = 26.3 seconds/month

### RTO vs RPO
- **RTO (Recovery Time Objective)**: How long to recover
- **RPO (Recovery Point Objective)**: How much data loss acceptable
- **Lower RTO/RPO = Higher Cost**

### Auto Scaling Policies
- **Target Tracking**: Maintain specific metric value (e.g., 70% CPU)
- **Step Scaling**: Scale based on alarm breach size
- **Simple Scaling**: Basic scale up/down on alarm
- **Predictive Scaling**: ML-based prediction

### S3 Storage Classes (Cost: Low → High)
1. **Deep Archive**: $1/TB/month, 180-day minimum
2. **Glacier**: $4/TB/month, 90-day minimum
3. **IA**: $12.5/TB/month, 30-day minimum
4. **Standard**: $23/TB/month, no minimum

---

## 🔐 Security Quick Reference

### IAM Essentials
- **Users**: People or services (avoid for applications)
- **Groups**: Collections of users (cannot be nested)
- **Roles**: Assumable identities (preferred for applications)
- **Policies**: JSON documents defining permissions

### Policy Evaluation Order
1. **Explicit DENY** = DENY (always wins)
2. **Explicit ALLOW** = ALLOW  
3. **No policy** = DENY (default)

### Encryption Types
- **At Rest**: Data stored on disk (S3, EBS, RDS)
- **In Transit**: Data moving over network (SSL/TLS)
- **Client-Side**: Encrypt before sending to AWS
- **Server-Side**: AWS encrypts after receiving

### Key Security Services
- **CloudTrail**: API call logging
- **GuardDuty**: Threat detection
- **Config**: Compliance monitoring
- **WAF**: Web application firewall
- **Shield**: DDoS protection

---

## 🏗️ Architecture Patterns

### High Availability Patterns
- **Multi-AZ**: Deploy across multiple Availability Zones
- **Multi-Region**: Deploy across multiple AWS regions
- **Auto Scaling**: Automatically adjust capacity
- **Load Balancing**: Distribute traffic across instances
- **Circuit Breaker**: Prevent cascade failures

### Disaster Recovery Strategies (Cost: Low → High)
1. **Backup & Restore**: Hours RTO, lowest cost
2. **Pilot Light**: 10s of minutes RTO, minimal infrastructure
3. **Warm Standby**: Minutes RTO, scaled-down infrastructure  
4. **Multi-Site**: Seconds RTO, full duplicate infrastructure

### Decoupling Patterns
- **SQS**: Message queuing (point-to-point)
- **SNS**: Pub/sub messaging (one-to-many)
- **EventBridge**: Event routing with rules
- **API Gateway**: API management and throttling

---

## ⚡ Performance Optimization

### Caching Hierarchy (Fastest → Slowest)
1. **Browser Cache**: User's device
2. **CloudFront**: Global edge locations
3. **ElastiCache**: In-memory database cache
4. **Application Cache**: In-memory application cache
5. **Database**: Optimized queries and indexes

### Database Selection Guide
- **RDS**: Relational data, ACID transactions
- **DynamoDB**: NoSQL, single-digit millisecond latency
- **Redshift**: Data warehousing, analytics
- **OpenSearch**: Full-text search, logging analytics
- **Aurora**: High-performance relational, cloud-native

### Auto Scaling Triggers
- **CPU Utilization**: Most common trigger
- **Request Count**: For web applications
- **Queue Depth**: For message processing
- **Custom Metrics**: Business-specific metrics

---

## 💰 Cost Optimization

### EC2 Pricing Models
- **On-Demand**: Pay per hour, no commitment
- **Reserved**: 1-3 year commitment, up to 75% savings
- **Spot**: Bid on spare capacity, up to 90% savings
- **Savings Plans**: Flexible commitment pricing

### Storage Cost Optimization
- **S3 Lifecycle Policies**: Auto-transition to cheaper classes
- **EBS GP3**: More cost-effective than GP2
- **EFS IA**: Infrequent access file storage
- **Data Deduplication**: Reduce storage requirements

### Cost Monitoring Tools
- **AWS Budgets**: Set spending limits and alerts
- **Cost Explorer**: Analyze spending patterns
- **Trusted Advisor**: Cost optimization recommendations
- **Cost Anomaly Detection**: ML-based unusual spending alerts

---

## 🎯 Service Selection Guide

### Compute Services
| Use Case | Service | Why |
|----------|---------|-----|
| Web applications | EC2 + ALB | Full control, proven pattern |
| Microservices | ECS/EKS | Container orchestration |
| Event processing | Lambda | Serverless, event-driven |
| Batch processing | AWS Batch | Managed batch compute |
| HPC workloads | EC2 + placement groups | Optimized networking |

### Storage Services
| Use Case | Service | Why |
|----------|---------|-----|
| Object storage | S3 | Scalable, durable, lifecycle policies |
| Block storage | EBS | High IOPS, consistent performance |
| File storage | EFS | Shared access, POSIX compliance |
| Backup storage | S3 Glacier | Long-term, cost-effective |
| Content delivery | CloudFront | Global edge caching |

### Database Services
| Use Case | Service | Why |
|----------|---------|-----|
| Relational OLTP | RDS/Aurora | ACID compliance, familiar SQL |
| NoSQL applications | DynamoDB | Single-digit ms latency, serverless |
| Data warehousing | Redshift | Columnar storage, analytics |
| Search applications | OpenSearch | Full-text search, log analytics |
| In-memory cache | ElastiCache | Sub-ms latency, Redis/Memcached |

---

## ⚠️ Common Exam Traps

### Security Traps
- **DON'T** use root account for daily activities
- **DON'T** hardcode credentials in applications
- **DON'T** use overly broad permissions (like `*:*`)
- **DO** use IAM roles for EC2 instances
- **DO** enable MFA for privileged accounts

### Architecture Traps
- **Single AZ** deployments = single point of failure
- **Tight coupling** between services = cascade failures
- **No health checks** = traffic to unhealthy instances
- **Synchronous processing** = not scalable
- **No caching** = poor performance

### Cost Traps
- **Over-provisioning** = wasted money
- **Wrong instance types** = poor price/performance
- **No lifecycle policies** = expensive storage
- **Unused resources** = unnecessary charges
- **Wrong pricing model** = missed savings

---

## 🎯 Domain-Specific Keywords

### Domain 1 (Security) - Key Terms
- **Least Privilege**, **Defense in Depth**, **Zero Trust**
- **IAM Roles**, **Policies**, **Condition Keys**
- **Encryption at Rest/Transit**, **KMS**, **Secrets Manager**
- **CloudTrail**, **GuardDuty**, **Config**
- **VPC**, **Security Groups**, **NACLs**

### Domain 2 (Resilient) - Key Terms
- **Multi-AZ**, **Auto Scaling**, **Load Balancing**
- **RTO/RPO**, **Disaster Recovery**, **Backup**
- **Decoupling**, **SQS**, **SNS**, **EventBridge**
- **Circuit Breaker**, **Retry Logic**, **Dead Letter Queue**
- **Health Checks**, **Graceful Degradation**

### Domain 3 (Performance) - Key Terms
- **Caching**, **ElastiCache**, **CloudFront**
- **Auto Scaling**, **Right-sizing**, **Instance Types**
- **Read Replicas**, **Global Tables**, **Partitioning**
- **CDN**, **Edge Locations**, **Global Accelerator**
- **Placement Groups**, **Enhanced Networking**

### Domain 4 (Cost) - Key Terms
- **Reserved Instances**, **Spot Instances**, **Savings Plans**
- **Lifecycle Policies**, **Storage Classes**, **Right-sizing**
- **Budgets**, **Cost Explorer**, **Trusted Advisor**
- **Tagging**, **Cost Allocation**, **Chargeback**
- **Resource Scheduling**, **Automated Optimization**

---

## 📝 Exam Day Checklist

### During the Exam:
- [ ] **Read questions completely** before looking at answers
- [ ] **Identify keywords** that hint at specific services
- [ ] **Eliminate obviously wrong answers** first
- [ ] **Look for requirements** (performance, cost, compliance)
- [ ] **Consider constraints** (time, budget, complexity)
- [ ] **Flag uncertain questions** for review
- [ ] **Manage time**: ~2 minutes per question

### Question Analysis Framework:
1. **What is the requirement?** (performance, security, cost)
2. **What are the constraints?** (time, budget, compliance)
3. **What type of question?** (architecture, troubleshooting, optimization)
4. **Which services are involved?** (compute, storage, network, database)
5. **What's the best practice?** (security, performance, cost, operations)

---

## 🎯 Final Confidence Boosters

### You're Ready If You Can:
- [ ] **Explain when to use** each major AWS service
- [ ] **Design multi-tier applications** with proper security
- [ ] **Choose appropriate database** for different use cases
- [ ] **Implement auto scaling** and load balancing
- [ ] **Optimize costs** using different pricing models
- [ ] **Ensure high availability** across multiple AZs
- [ ] **Secure applications** using IAM and encryption
- [ ] **Monitor and troubleshoot** using CloudWatch

### Remember:
- **AWS favors managed services** over self-managed solutions
- **Security is always a priority** - choose secure options
- **Cost optimization** is important but not at expense of requirements
- **Simpler solutions** are often better than complex ones
- **Well-Architected principles** guide good architecture decisions

---

## 🚀 Go Ace That Exam!

### Final Tips:
- **Trust your preparation** - you've put in the work
- **Stay calm and focused** - don't second-guess yourself
- **Read carefully** - exam questions can have subtle distinctions
- **Use elimination** - remove wrong answers to find the right one
- **Flag and return** - don't get stuck on difficult questions

### Most Important Reminders:
1. **Security First**: Always choose the most secure option that meets requirements
2. **AWS Managed Services**: Prefer managed services over self-managed solutions
3. **Cost vs Performance**: Balance based on specific requirements
4. **Simplicity**: Simpler solutions are often better
5. **Well-Architected**: Apply the 6 pillars in your decision-making

---

**You've got this!** 🎯

Remember: You've studied hard, practiced extensively, and learned from real-world scenarios. Trust your knowledge and approach each question methodically. 

**Good luck on your AWS Certified Solutions Architect exam!** 🚀☁️
