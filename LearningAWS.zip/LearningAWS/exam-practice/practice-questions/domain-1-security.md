# Domain 1: Design Secure Architectures (30%)
**Practice Questions**: 15 Questions | **Time Allocation**: 30 minutes | **Passing Score**: 80%

---

## 📋 Question Format Legend
- 🟢 **Beginner** - Foundation knowledge
- 🟡 **Intermediate** - Applied scenarios  
- 🔴 **Advanced** - Complex multi-service solutions

---

## Question 1 🟢
**Scenario**: A startup company is launching their first web application on AWS. They need to ensure that only authenticated users can access their application's admin panel, and they want to implement the principle of least privilege.

**Which of the following approaches BEST implements secure access control?**

A) Create IAM users for each admin and attach the AdministratorAccess policy  
B) Use AWS Cognito User Pools for authentication and IAM roles with specific permissions for authorization  
C) Create a single IAM user with admin permissions and share the credentials among all administrators  
D) Use API Gateway with AWS Lambda authorizer and store user credentials in RDS  

**Domain**: 1.1 Design secure access to AWS resources  
**Difficulty**: Beginner

---

## Question 2 🟡
**Scenario**: A financial services company needs to ensure that all API calls to their AWS resources are logged and monitored for compliance purposes. They also need to detect any unusual access patterns that might indicate a security breach.

**Which combination of AWS services should they implement? (Choose TWO)**

A) AWS CloudTrail for API call logging  
B) Amazon CloudWatch for resource monitoring  
C) AWS GuardDuty for threat detection  
D) AWS Config for resource configuration tracking  
E) AWS X-Ray for application tracing  

**Domain**: 1.1 Design secure access to AWS resources  
**Difficulty**: Intermediate

---

## Question 3 🔴
**Scenario**: A multinational corporation has multiple AWS accounts for different business units. They need to implement a centralized security strategy where the security team in the master account can monitor and enforce security policies across all accounts, while each business unit maintains operational independence.

**What is the MOST effective approach to achieve this requirement?**

A) Use AWS Organizations with Service Control Policies (SCPs) and AWS Security Hub for centralized monitoring  
B) Create cross-account IAM roles and use AWS Config aggregators for compliance monitoring  
C) Implement AWS Single Sign-On (SSO) with permission sets and use CloudTrail organization trails  
D) Use AWS Control Tower with Account Factory and enable AWS Config in all accounts  

**Domain**: 1.1 Design secure access to AWS resources  
**Difficulty**: Advanced

---

## Question 4 🟡
**Scenario**: An e-commerce company stores customer payment information in an RDS database. They need to ensure that this sensitive data is encrypted both in transit and at rest, and they want to maintain control over the encryption keys.

**Which approach provides the HIGHEST level of security for their requirements?**

A) Use RDS encryption with AWS managed keys and SSL/TLS for data in transit  
B) Use RDS encryption with customer managed KMS keys and SSL/TLS with certificate pinning  
C) Implement application-level encryption with AWS KMS and use VPN for data transmission  
D) Use AWS KMS for encryption at rest and AWS Certificate Manager for SSL certificates  

**Domain**: 1.3 Select appropriate data security controls  
**Difficulty**: Intermediate

---

## Question 5 🟢
**Scenario**: A development team needs to give their Spring Boot application running on EC2 access to an S3 bucket. They want to follow AWS security best practices.

**What is the MOST secure way to provide this access?**

A) Create an IAM user with S3 access and store the access keys in the application configuration file  
B) Create an IAM role with S3 permissions and attach it to the EC2 instance  
C) Use AWS Secrets Manager to store IAM user credentials and retrieve them at runtime  
D) Embed IAM access keys directly in the application code  

**Domain**: 1.1 Design secure access to AWS resources  
**Difficulty**: Beginner

---

## Question 6 🔴
**Scenario**: A healthcare organization needs to implement a secure architecture for their patient management system. They require end-to-end encryption, audit trails for all data access, network isolation, and compliance with HIPAA regulations. The system will have multiple tiers: web servers, application servers, and database servers.

**Which architecture components should be included to meet these requirements? (Choose THREE)**

A) VPC with private subnets for application and database tiers, public subnets for web tier  
B) Application Load Balancer with AWS WAF and SSL termination  
C) Amazon RDS with encryption at rest using customer managed KMS keys  
D) AWS PrivateLink for secure service-to-service communication  
E) Amazon ElastiCache for session storage without encryption  
F) AWS CloudTrail with log file encryption and integrity validation  

**Domain**: 1.2 Design secure application tiers  
**Difficulty**: Advanced

---

## Question 7 🟡
**Scenario**: A company wants to implement network-level security for their VPC. They need to control traffic at both the subnet level and instance level, with different security requirements for different tiers of their application.

**Which combination of security controls should they implement?**

A) Security Groups for instance-level control and Network ACLs for subnet-level control  
B) Only Security Groups since they provide both instance and subnet level control  
C) Only Network ACLs since they provide comprehensive network security  
D) AWS WAF for all network security requirements  

**Domain**: 1.2 Design secure application tiers  
**Difficulty**: Intermediate

---

## Question 8 🟢
**Scenario**: A company needs to rotate their RDS database passwords regularly for security compliance. They want an automated solution that doesn't require application code changes.

**Which AWS service should they use?**

A) AWS Systems Manager Parameter Store  
B) AWS Secrets Manager with automatic rotation  
C) AWS KMS for key rotation  
D) IAM password policies  

**Domain**: 1.3 Select appropriate data security controls  
**Difficulty**: Beginner

---

## Question 9 🔴
**Scenario**: A global enterprise needs to implement a zero-trust network architecture for their AWS workloads. They require microsegmentation, identity-based access control, encrypted communications between all services, and real-time security monitoring. Their architecture includes microservices running on EKS, Lambda functions, and various AWS managed services.

**Which combination of services and features BEST implements this zero-trust architecture? (Choose THREE)**

A) AWS App Mesh with mutual TLS authentication between services  
B) AWS PrivateLink endpoints for all AWS service communications  
C) Amazon EKS with Kubernetes Network Policies and Pod Security Standards  
D) AWS Identity Center (formerly SSO) with fine-grained permission sets  
E) Amazon VPC with only public subnets for simplified management  
F) AWS Security Hub with custom security standards and automated remediation  

**Domain**: 1.2 Design secure application tiers  
**Difficulty**: Advanced

---

## Question 10 🟡
**Scenario**: A SaaS company needs to implement tenant isolation for their multi-tenant application. Each tenant's data must be completely isolated from other tenants, and they need to implement fine-grained access control based on tenant context.

**Which approach provides the BEST tenant isolation?**

A) Use separate databases for each tenant with tenant-specific IAM roles  
B) Use a single database with row-level security based on tenant ID  
C) Use separate AWS accounts for each tenant with cross-account access  
D) Use DynamoDB with tenant-specific partition keys and IAM policies with conditions  

**Domain**: 1.1 Design secure access to AWS resources  
**Difficulty**: Intermediate

---

## Question 11 🟢
**Scenario**: A company wants to ensure that their S3 buckets are not accidentally made public. They need a preventive control that works across their entire AWS organization.

**Which solution provides the MOST effective protection?**

A) Use S3 bucket policies to deny public access  
B) Enable S3 Block Public Access at the organization level  
C) Use IAM policies to restrict S3 public access permissions  
D) Monitor S3 buckets with AWS Config rules  

**Domain**: 1.3 Select appropriate data security controls  
**Difficulty**: Beginner

---

## Question 12 🔴
**Scenario**: A financial institution is migrating their core banking application to AWS. They need to implement defense-in-depth security with multiple layers of protection. The application handles sensitive financial data and must comply with PCI DSS requirements. They need to protect against DDoS attacks, SQL injection, cross-site scripting, and other web application vulnerabilities.

**Which multi-layered security architecture should they implement?**

A) CloudFront → AWS WAF → ALB → EC2 instances in private subnets → RDS with encryption  
B) ALB → EC2 instances in public subnets → RDS in private subnets  
C) CloudFront → ALB → Lambda functions → DynamoDB  
D) Direct EC2 access → Application-level security → Encrypted RDS  

**Domain**: 1.2 Design secure application tiers  
**Difficulty**: Advanced

---

## Question 13 🟡
**Scenario**: A company needs to implement Just-in-Time (JIT) access for their production environment. System administrators should only get elevated privileges when needed, for a limited time, and all access should be logged and approved.

**Which solution BEST implements JIT access?**

A) AWS Systems Manager Session Manager with time-limited access  
B) AWS IAM Access Analyzer with temporary credentials  
C) AWS Control Tower with Account Factory  
D) AWS Identity Center with time-based access and approval workflows  

**Domain**: 1.1 Design secure access to AWS resources  
**Difficulty**: Intermediate

---

## Question 14 🟡
**Scenario**: A company stores highly sensitive intellectual property in S3. They need to ensure that even if AWS is compromised, their data remains protected. They want client-side encryption where they maintain complete control over the encryption keys.

**Which approach BEST meets their requirements?**

A) Use S3 server-side encryption with customer-provided keys (SSE-C)  
B) Use S3 server-side encryption with AWS KMS customer managed keys (SSE-KMS)  
C) Implement client-side encryption with customer managed keys before uploading to S3  
D) Use S3 server-side encryption with AWS managed keys (SSE-S3)  

**Domain**: 1.3 Select appropriate data security controls  
**Difficulty**: Intermediate

---

## Question 15 🔴
**Scenario**: A large enterprise is implementing a cloud-first security strategy across multiple AWS accounts in different regions. They need centralized security monitoring, automated threat response, compliance reporting, and security orchestration. They want to correlate security findings from multiple sources and automatically remediate common security issues.

**Which comprehensive security solution should they implement?**

A) AWS Security Hub as central dashboard + EventBridge for orchestration + Lambda for automated remediation + GuardDuty for threat detection  
B) Amazon Detective for investigation + AWS Config for compliance + CloudTrail for logging  
C) AWS Inspector for vulnerability assessment + AWS Systems Manager for patch management  
D) Third-party SIEM solution + AWS native logging services  

**Domain**: 1.1 Design secure access to AWS resources  
**Difficulty**: Advanced

---

## 📊 Domain 1 Summary

**Question Distribution:**
- **Beginner (🟢)**: 4 questions (27%)
- **Intermediate (🟡)**: 7 questions (47%) 
- **Advanced (🔴)**: 4 questions (26%)

**Sub-Domain Coverage:**
- **1.1 Design secure access to AWS resources**: 8 questions
- **1.2 Design secure application tiers**: 4 questions  
- **1.3 Select appropriate data security controls**: 3 questions

**Key Topics Covered:**
- IAM users, roles, and policies
- Multi-account security strategies
- Network security (VPC, Security Groups, NACLs)
- Data encryption (at rest and in transit)
- Security monitoring and compliance
- Zero-trust architecture
- Defense-in-depth strategies

---

**Next**: Continue with [Domain 2: Design Resilient Architectures](./domain-2-resilient.md)

**Answer Key**: Available in [Answer Keys Section](../answer-keys/domain-1-answers.md)
