# Domain 2: Design Resilient Architectures (26%)
**Practice Questions**: 15 Questions | **Time Allocation**: 30 minutes | **Passing Score**: 80%

---

## Question 1 🟢
**Scenario**: A company wants to ensure their web application can handle traffic spikes during Black Friday sales. The application currently runs on a single EC2 instance.

**What is the MOST cost-effective way to make the application resilient to traffic spikes?**

A) Upgrade to a larger EC2 instance type  
B) Implement an Auto Scaling Group with Application Load Balancer  
C) Add a CloudFront distribution in front of the application  
D) Deploy the application across multiple Availability Zones manually  

**Domain**: 2.2 Design highly available and/or fault-tolerant architectures  
**Difficulty**: Beginner

---

## Question 2 🟡
**Scenario**: An e-commerce company has strict requirements for their database: RTO (Recovery Time Objective) of 5 minutes and RPO (Recovery Point Objective) of 1 minute. Their application is mission-critical and cannot tolerate any data loss.

**Which Amazon RDS configuration BEST meets these requirements?**

A) RDS with automated backups and Multi-AZ deployment  
B) RDS with Multi-AZ deployment and read replicas in different regions  
C) RDS with point-in-time recovery and manual snapshots  
D) RDS Aurora with Aurora Replicas across multiple Availability Zones  

**Domain**: 2.2 Design highly available and/or fault-tolerant architectures  
**Difficulty**: Intermediate

---

## Question 3 🔴
**Scenario**: A global media streaming company needs to design a disaster recovery strategy for their video streaming platform. They have strict requirements: RPO of 15 minutes, RTO of 1 hour, and the ability to serve users from multiple regions. Their architecture includes web servers, application servers, databases, and a content delivery network.

**Which disaster recovery strategy provides the BEST balance of cost and recovery objectives?**

A) Pilot Light: Minimal infrastructure in DR region with automated scaling scripts  
B) Warm Standby: Pre-deployed infrastructure with reduced capacity in DR region  
C) Multi-Site Active-Active: Full deployment in multiple regions with traffic distribution  
D) Backup and Restore: Regular backups to S3 with manual restoration process  

**Domain**: 2.2 Design highly available and/or fault-tolerant architectures  
**Difficulty**: Advanced

---

## Question 4 🟡
**Scenario**: A financial application processes thousands of transactions per minute. The application needs to be decoupled to handle varying loads and ensure no transactions are lost, even if downstream services are temporarily unavailable.

**Which decoupling strategy BEST ensures transaction reliability?**

A) Use Amazon SQS Standard queue with dead letter queue for failed messages  
B) Use Amazon SQS FIFO queue with message deduplication  
C) Use Amazon SNS with multiple subscribers for redundancy  
D) Use Amazon Kinesis Data Streams with multiple shards  

**Domain**: 2.3 Design decoupling mechanisms using AWS services  
**Difficulty**: Intermediate

---

## Question 5 🟢
**Scenario**: A startup's web application experiences occasional spikes in traffic that cause the application to become slow or unresponsive. They want to automatically add more EC2 instances when CPU utilization exceeds 70%.

**Which AWS service should they configure to achieve this?**

A) Amazon CloudWatch with SNS notifications  
B) AWS Auto Scaling with CloudWatch alarms  
C) Elastic Load Balancing with health checks  
D) AWS Systems Manager with automation documents  

**Domain**: 2.1 Design scalable and loosely coupled architectures  
**Difficulty**: Beginner

---

## Question 6 🔴
**Scenario**: A large enterprise is designing a microservices architecture for their order processing system. They need to ensure that if any individual microservice fails, it doesn't bring down the entire system. The system must handle partial failures gracefully and provide eventual consistency across services.

**Which combination of patterns and services BEST implements this resilient microservices architecture? (Choose THREE)**

A) Implement circuit breaker pattern with Spring Cloud Circuit Breaker  
B) Use Amazon SQS for asynchronous communication between services  
C) Implement database-per-service pattern with eventual consistency  
D) Use synchronous HTTP calls for all inter-service communication  
E) Implement distributed transactions with two-phase commit  
F) Use Amazon EventBridge for event-driven communication  

**Domain**: 2.1 Design scalable and loosely coupled architectures  
**Difficulty**: Advanced

---

## Question 7 🟡
**Scenario**: A company needs to ensure their application can handle sudden traffic increases of up to 10x normal load within 2 minutes. The application consists of web servers and a database.

**Which combination of services provides the FASTEST scaling response?**

A) Application Load Balancer + Auto Scaling Groups + RDS with read replicas  
B) CloudFront + Lambda functions + DynamoDB with auto scaling  
C) Application Load Balancer + ECS Fargate + Aurora Serverless  
D) API Gateway + Lambda functions + RDS Proxy  

**Domain**: 2.1 Design scalable and loosely coupled architectures  
**Difficulty**: Intermediate

---

## Question 8 🟢
**Scenario**: A company wants to distribute incoming web traffic across multiple EC2 instances in different Availability Zones. They need to ensure that unhealthy instances are automatically removed from service.

**Which AWS service should they use?**

A) Amazon Route 53 with health checks  
B) Application Load Balancer with health checks  
C) Amazon CloudFront with origin failover  
D) AWS Auto Scaling with health check grace period  

**Domain**: 2.2 Design highly available and/or fault-tolerant architectures  
**Difficulty**: Beginner

---

## Question 9 🔴
**Scenario**: A multinational corporation is designing a global architecture for their customer management system. They need to ensure that customers in each region experience low latency, and if an entire region becomes unavailable, traffic can be automatically routed to the next nearest healthy region. The system must maintain data consistency across regions.

**Which architecture BEST meets these requirements?**

A) Multi-region active-passive with Route 53 health checks and cross-region RDS read replicas  
B) Multi-region active-active with Route 53 geolocation routing and DynamoDB Global Tables  
C) Single region with CloudFront global edge locations and S3 Transfer Acceleration  
D) Multi-region with AWS Global Accelerator and Aurora Global Database  

**Domain**: 2.2 Design highly available and/or fault-tolerant architectures  
**Difficulty**: Advanced

---

## Question 10 🟡
**Scenario**: An IoT company receives millions of sensor data points per hour. They need to process this data in real-time and store it for long-term analysis. The system must handle sudden spikes in data volume without losing any sensor readings.

**Which architecture provides the BEST resilience for this use case?**

A) API Gateway → Lambda → DynamoDB → S3 for archival  
B) Kinesis Data Streams → Kinesis Analytics → S3 → Athena for analysis  
C) SQS → Lambda → RDS → Data Pipeline for ETL  
D) Direct EC2 processing → ElastiCache → Redshift  

**Domain**: 2.3 Design decoupling mechanisms using AWS services  
**Difficulty**: Intermediate

---

## Question 11 🟢
**Scenario**: A company's application occasionally receives a large batch of messages that need to be processed. They want to ensure that these messages are processed reliably, even if their processing service is temporarily unavailable.

**Which AWS service provides the BEST solution for this requirement?**

A) Amazon SNS for message distribution  
B) Amazon SQS for message queuing  
C) Amazon Kinesis for real-time processing  
D) AWS Step Functions for workflow orchestration  

**Domain**: 2.3 Design decoupling mechanisms using AWS services  
**Difficulty**: Beginner

---

## Question 12 🔴
**Scenario**: A video streaming platform needs to design a resilient architecture that can handle millions of concurrent users across the globe. They need to ensure content is delivered with low latency, the system can handle sudden viral content spikes, and the platform remains available even if multiple AWS services in a region fail.

**Which comprehensive resilient architecture should they implement?**

A) Route 53 → CloudFront (Global) → ALB (Multi-Region) → Auto Scaling EC2 → RDS Multi-AZ → S3 (Cross-Region Replication)  
B) CloudFront → API Gateway → Lambda@Edge → DynamoDB Global Tables → S3 with Transfer Acceleration  
C) Global Accelerator → ALB → ECS Fargate → Aurora Global Database → S3 Intelligent Tiering  
D) Route 53 → CloudFront → Origin Groups → Multi-Region ALB → Auto Scaling Groups → Aurora Cross-Region Replicas → S3 Cross-Region Replication  

**Domain**: 2.2 Design highly available and/or fault-tolerant architectures  
**Difficulty**: Advanced

---

## Question 13 🟡
**Scenario**: A payment processing company needs to ensure that their order processing system maintains exactly-once message processing. Duplicate payment processing could result in charging customers multiple times.

**Which combination of AWS services BEST ensures exactly-once processing?**

A) Amazon SQS FIFO queue with message deduplication and idempotent processing  
B) Amazon SNS with message filtering and Lambda function deduplication  
C) Amazon Kinesis with sequence numbers and DynamoDB conditional writes  
D) Amazon EventBridge with replay capability and error handling  

**Domain**: 2.3 Design decoupling mechanisms using AWS services  
**Difficulty**: Intermediate

---

## Question 14 🟡
**Scenario**: A company wants to implement a backup strategy for their critical application data. They need to meet compliance requirements for 7-year data retention, but want to optimize costs by transitioning older backups to cheaper storage classes.

**Which S3 storage strategy BEST meets their requirements?**

A) Store all backups in S3 Standard for immediate access  
B) Use S3 Lifecycle policies to transition data from Standard → IA → Glacier → Deep Archive  
C) Store backups in Glacier immediately for cost optimization  
D) Use S3 Intelligent Tiering for automatic cost optimization  

**Domain**: 2.4 Choose appropriate resilient storage  
**Difficulty**: Intermediate

---

## Question 15 🔴
**Scenario**: A global e-commerce platform is implementing a comprehensive business continuity strategy. They need to ensure their entire infrastructure can be recovered in multiple scenarios: single AZ failure, regional disaster, and complete AWS service outage. They process millions of orders daily and cannot afford more than 30 minutes of downtime.

**Which multi-layered resilience strategy BEST addresses all failure scenarios?**

A) Multi-AZ deployment + Cross-region replication + Multi-cloud backup strategy + Infrastructure as Code for rapid deployment  
B) Auto Scaling Groups + RDS Multi-AZ + S3 Cross-Region Replication  
C) Load balancers + Database clustering + Regular backups  
D) CloudFormation templates + Automated testing + Manual disaster recovery procedures  

**Domain**: 2.2 Design highly available and/or fault-tolerant architectures  
**Difficulty**: Advanced

---

## 📊 Domain 2 Summary

**Question Distribution:**
- **Beginner (🟢)**: 4 questions (27%)
- **Intermediate (🟡)**: 7 questions (47%)
- **Advanced (🔴)**: 4 questions (26%)

**Sub-Domain Coverage:**
- **2.1 Design scalable and loosely coupled architectures**: 4 questions
- **2.2 Design highly available and/or fault-tolerant architectures**: 8 questions
- **2.3 Design decoupling mechanisms**: 5 questions
- **2.4 Choose appropriate resilient storage**: 1 question

**Key Topics Covered:**
- Auto Scaling and Load Balancing
- Multi-AZ and Multi-Region strategies
- Disaster Recovery (RTO/RPO)
- Message queuing and event-driven architectures
- Circuit breaker patterns
- Database resilience strategies
- Global content delivery
- Backup and archival strategies

**Common Services Featured:**
- Auto Scaling Groups
- Application Load Balancer
- Amazon RDS Multi-AZ
- Amazon SQS/SNS
- Amazon Route 53
- AWS Lambda
- Amazon S3
- Amazon CloudFront

---

**Next**: Continue with [Domain 3: Design High-Performing Architectures](./domain-3-performance.md)

**Answer Key**: Available in [Answer Keys Section](../answer-keys/domain-2-answers.md)
