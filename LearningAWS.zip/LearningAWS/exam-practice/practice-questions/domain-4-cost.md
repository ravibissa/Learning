# Domain 4: Design Cost-Optimized Architectures (20%)
**Practice Questions**: 15 Questions | **Time Allocation**: 30 minutes | **Passing Score**: 80%

---

## Question 1 🟢
**Scenario**: A company runs a web application on EC2 instances that experiences predictable traffic patterns - high usage during business hours (8 AM - 6 PM) and minimal usage overnight and weekends.

**Which EC2 pricing model provides the BEST cost optimization for this usage pattern?**

A) On-Demand Instances for consistent pricing  
B) Reserved Instances for predictable savings  
C) Spot Instances for maximum cost savings  
D) Combination of Reserved Instances for baseline and On-Demand for peak hours  

**Domain**: 4.2 Design cost-optimized compute solutions  
**Difficulty**: Beginner

---

## Question 2 🟡
**Scenario**: A startup has variable workloads that can be interrupted without impact to their business. They want to achieve maximum cost savings while maintaining the ability to scale quickly when needed.

**Which combination of EC2 pricing options provides the BEST cost optimization?**

A) 100% Spot Instances with Spot Fleet for diversification  
B) 70% Spot Instances + 30% On-Demand Instances for stability  
C) 50% Reserved Instances + 50% Spot Instances  
D) 100% On-Demand Instances for simplicity  

**Domain**: 4.2 Design cost-optimized compute solutions  
**Difficulty**: Intermediate

---

## Question 3 🔴
**Scenario**: A global enterprise needs to optimize costs across their entire AWS infrastructure spanning multiple accounts, regions, and environments (dev, staging, production). They want centralized cost management, automated cost optimization, and detailed cost attribution by business unit.

**Which comprehensive cost optimization strategy should they implement?**

A) AWS Cost Explorer + AWS Budgets + Reserved Instance recommendations  
B) AWS Organizations with consolidated billing + Cost Categories + AWS Cost Anomaly Detection + Automated RI/SP purchasing  
C) Third-party cost management tools + manual cost optimization  
D) AWS Trusted Advisor + basic monitoring and alerts  

**Domain**: 4.1 Design cost-optimized storage solutions  
**Difficulty**: Advanced

---

## Question 4 🟡
**Scenario**: A company stores application logs, database backups, and archived documents in S3. They have 100TB of data with varying access patterns: logs accessed weekly, backups accessed monthly, and archives accessed rarely (once per year or less).

**Which S3 storage strategy minimizes costs while meeting access requirements?**

A) Store everything in S3 Standard for consistent access  
B) Use S3 Intelligent-Tiering for all data types  
C) Implement custom lifecycle policies: Logs (Standard→IA→Glacier), Backups (IA→Glacier), Archives (Deep Archive)  
D) Store all data in S3 Glacier for maximum cost savings  

**Domain**: 4.1 Design cost-optimized storage solutions  
**Difficulty**: Intermediate

---

## Question 5 🟢
**Scenario**: A development team spins up EC2 instances for testing but often forgets to terminate them after use, leading to unnecessary charges.

**Which approach provides the MOST effective cost control for this scenario?**

A) Train developers to remember to terminate instances  
B) Implement instance scheduling with AWS Systems Manager  
C) Use Spot Instances that automatically terminate  
D) Set up billing alerts when costs exceed thresholds  

**Domain**: 4.2 Design cost-optimized compute solutions  
**Difficulty**: Beginner

---

## Question 6 🔴
**Scenario**: A data analytics company processes large datasets using EMR clusters. Jobs run for 2-8 hours with varying compute requirements. They want to minimize costs while ensuring jobs complete within acceptable timeframes. Some jobs can tolerate interruptions, while others are time-critical.

**Which EMR cost optimization strategy provides the BEST balance of cost and reliability?**

A) Use 100% Spot Instances for all EMR clusters  
B) Use Reserved Instances for predictable baseline capacity  
C) Mix of On-Demand master nodes + Spot core/task nodes with multiple instance types and AZs  
D) Use On-Demand instances for all critical workloads  

**Domain**: 4.2 Design cost-optimized compute solutions  
**Difficulty**: Advanced

---

## Question 7 🟡
**Scenario**: A company transfers 50TB of data monthly from their on-premises data center to AWS for backup purposes. They currently use Direct Connect but want to optimize data transfer costs.

**Which data transfer strategy minimizes costs for this use case?**

A) Continue using Direct Connect for all transfers  
B) Use AWS DataSync over the internet for cost savings  
C) Use AWS Snow family devices for monthly transfers  
D) Compress data and use S3 Transfer Acceleration  

**Domain**: 4.3 Design cost-optimized network architectures  
**Difficulty**: Intermediate

---

## Question 8 🟢
**Scenario**: A company wants to monitor their AWS costs and receive alerts when spending exceeds their monthly budget of $10,000.

**Which AWS service should they use to set up automated cost monitoring?**

A) AWS Cost Explorer for cost analysis  
B) AWS Budgets for budget alerts  
C) CloudWatch billing alarms  
D) AWS Trusted Advisor cost optimization checks  

**Domain**: 4.1 Design cost-optimized storage solutions  
**Difficulty**: Beginner

---

## Question 9 🔴
**Scenario**: A multinational company operates in multiple AWS regions with complex data residency requirements. They need to optimize cross-region data transfer costs while maintaining compliance. Their architecture includes real-time replication, batch data transfers, and user access from multiple regions.

**Which network optimization strategy minimizes data transfer costs while meeting requirements?**

A) Use CloudFront with regional edge caches to minimize origin requests  
B) Implement VPC Peering between regions for all data transfers  
C) Use AWS PrivateLink + S3 Transfer Acceleration + regional data lakes with selective replication  
D) Deploy duplicate infrastructure in each region to eliminate cross-region transfers  

**Domain**: 4.3 Design cost-optimized network architectures  
**Difficulty**: Advanced

---

## Question 10 🟡
**Scenario**: A gaming company has unpredictable traffic spikes during game launches and events. They want to minimize infrastructure costs during low-traffic periods while ensuring they can handle sudden traffic increases.

**Which auto-scaling strategy provides the BEST cost optimization?**

A) Maintain high minimum capacity to handle potential spikes  
B) Use predictive scaling based on historical patterns  
C) Implement aggressive scale-down policies with fast scale-up capabilities  
D) Use scheduled scaling based on known event times  

**Domain**: 4.2 Design cost-optimized compute solutions  
**Difficulty**: Intermediate

---

## Question 11 🟢
**Scenario**: A company runs batch processing jobs that can run anytime within a 24-hour window. The jobs are fault-tolerant and can be restarted if interrupted.

**Which compute option provides the MAXIMUM cost savings for this workload?**

A) On-Demand EC2 instances  
B) Reserved EC2 instances  
C) Spot EC2 instances  
D) AWS Lambda functions  

**Domain**: 4.2 Design cost-optimized compute solutions  
**Difficulty**: Beginner

---

## Question 12 🔴
**Scenario**: A financial services company needs to optimize costs for their data warehouse that processes both real-time analytics and batch reporting. The system handles 10TB of new data daily, with queries ranging from real-time dashboards to complex monthly reports. They need to balance performance requirements with cost optimization.

**Which data warehouse cost optimization strategy provides the BEST value?**

A) Amazon Redshift with Reserved Instances + S3 data lake for long-term storage + Lifecycle policies  
B) Amazon Athena for all queries + S3 with Intelligent Tiering  
C) Amazon Redshift Serverless + S3 for raw data + automated workload management  
D) RDS with read replicas + ElastiCache for caching + S3 for archival  

**Domain**: 4.1 Design cost-optimized storage solutions  
**Difficulty**: Advanced

---

## Question 13 🟡
**Scenario**: A media company stores video files that are frequently accessed for the first month after upload, occasionally accessed for the next 6 months, and rarely accessed afterward. They want to optimize storage costs while maintaining reasonable access times.

**Which S3 storage optimization strategy is MOST cost-effective?**

A) Use S3 Standard for all files to ensure fast access  
B) Implement lifecycle policies: Standard (30 days) → IA (6 months) → Glacier (long-term)  
C) Use S3 Intelligent-Tiering for automatic optimization  
D) Store files in S3 IA immediately since access patterns vary  

**Domain**: 4.1 Design cost-optimized storage solutions  
**Difficulty**: Intermediate

---

## Question 14 🟡
**Scenario**: A SaaS company wants to implement a chargeback model where different business units pay for their actual AWS resource usage. They need detailed cost attribution and reporting.

**Which approach provides the MOST accurate cost allocation?**

A) Use separate AWS accounts for each business unit  
B) Implement comprehensive resource tagging with cost allocation tags  
C) Use AWS Cost Categories to group resources by business unit  
D) Manual cost allocation based on estimated usage  

**Domain**: 4.1 Design cost-optimized storage solutions  
**Difficulty**: Intermediate

---

## Question 15 🔴
**Scenario**: A global e-commerce platform wants to optimize their total cost of ownership (TCO) while maintaining high performance and availability. Their current architecture includes web servers, databases, caching layers, and content delivery. They process millions of transactions daily with strict performance requirements.

**Which comprehensive cost optimization strategy addresses all aspects of their infrastructure?**

A) Right-size instances + Reserved Instance/Savings Plans + S3 lifecycle policies + CloudFront optimization  
B) Migrate everything to serverless architecture for automatic cost optimization  
C) Use only Spot Instances and S3 Glacier for maximum savings  
D) Implement multi-cloud strategy to leverage best pricing from different providers  

**Domain**: 4.2 Design cost-optimized compute solutions  
**Difficulty**: Advanced

---

## 📊 Domain 4 Summary

**Question Distribution:**
- **Beginner (🟢)**: 4 questions (27%)
- **Intermediate (🟡)**: 7 questions (47%)
- **Advanced (🔴)**: 4 questions (26%)

**Sub-Domain Coverage:**
- **4.1 Design cost-optimized storage solutions**: 6 questions
- **4.2 Design cost-optimized compute solutions**: 7 questions
- **4.3 Design cost-optimized network architectures**: 2 questions

**Key Topics Covered:**
- EC2 pricing models (On-Demand, Reserved, Spot)
- S3 storage classes and lifecycle policies
- Auto Scaling for cost optimization
- Data transfer cost optimization
- Cost monitoring and budgeting
- Reserved Instances and Savings Plans
- Resource tagging and cost allocation
- Multi-region cost considerations

**Cost Optimization Strategies:**
- **Compute**: Right-sizing, Reserved Instances, Spot Instances, Auto Scaling
- **Storage**: Lifecycle policies, Intelligent Tiering, appropriate storage classes
- **Network**: Regional architecture, data transfer optimization
- **Monitoring**: Budgets, Cost Explorer, automated alerts
- **Governance**: Tagging strategies, cost allocation, chargeback models

**AWS Cost Management Tools:**
- AWS Cost Explorer
- AWS Budgets
- AWS Cost Anomaly Detection
- AWS Trusted Advisor
- AWS Cost and Usage Reports
- AWS Organizations (consolidated billing)

---

## 💡 Cost Optimization Quick Reference

### EC2 Cost Optimization
- **Predictable workloads**: Reserved Instances (up to 75% savings)
- **Interruptible workloads**: Spot Instances (up to 90% savings)
- **Variable workloads**: Auto Scaling + mix of pricing models
- **Development/Testing**: Scheduled scaling, automatic shutdown

### S3 Cost Optimization
- **Frequently accessed**: S3 Standard
- **Infrequent access**: S3 IA (30 days minimum)
- **Archive**: Glacier (90 days minimum)
- **Long-term archive**: Deep Archive (180 days minimum)
- **Unknown patterns**: S3 Intelligent Tiering

### Network Cost Optimization
- **Regional traffic**: Free within same region
- **Cross-region**: Use CloudFront, minimize transfers
- **Internet traffic**: Outbound charges apply
- **Data transfer**: Consider AWS Direct Connect for large volumes

---

**Next**: Continue with [SAP-C02 Professional Questions](./sap-c02-professional.md)

**Answer Key**: Available in [Answer Keys Section](../answer-keys/domain-4-answers.md)
