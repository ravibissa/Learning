# Domain 3: Design High-Performing Architectures (24%)
**Practice Questions**: 15 Questions | **Time Allocation**: 30 minutes | **Passing Score**: 80%

---

## Question 1 🟢
**Scenario**: A web application experiences slow response times during peak hours. Analysis shows that database queries are the bottleneck. The application frequently reads the same product catalog data.

**Which solution will provide the MOST immediate performance improvement?**

A) Upgrade the RDS instance to a larger size  
B) Implement Amazon ElastiCache for frequently accessed data  
C) Add RDS read replicas in multiple Availability Zones  
D) Migrate the database to Amazon DynamoDB  

**Domain**: 3.1 Choose performant storage and databases  
**Difficulty**: Beginner

---

## Question 2 🟡
**Scenario**: A global news website needs to deliver content quickly to users worldwide. They have static content (images, CSS, JavaScript) and dynamic content (articles, user comments). The backend API is hosted in the us-east-1 region.

**Which architecture provides the BEST global performance?**

A) CloudFront with origin in us-east-1 serving both static and dynamic content  
B) CloudFront for static content with S3 origin, and direct API calls for dynamic content  
C) CloudFront for static content with S3 origin, and CloudFront with ALB origin for dynamic content  
D) Multiple ALB instances deployed in different regions for both static and dynamic content  

**Domain**: 3.3 Design solutions for high-performing networking  
**Difficulty**: Intermediate

---

## Question 3 🔴
**Scenario**: A financial trading platform requires extremely low latency for real-time market data processing. They need to process millions of transactions per second with sub-millisecond response times. The system must handle sudden market volatility spikes without performance degradation.

**Which combination of services and techniques provides the LOWEST latency architecture? (Choose THREE)**

A) Amazon ElastiCache for Redis with cluster mode for in-memory processing  
B) AWS Lambda functions for transaction processing  
C) EC2 instances with enhanced networking and placement groups  
D) Amazon DynamoDB with provisioned throughput  
E) Amazon Kinesis Data Streams with enhanced fan-out  
F) Application Load Balancer with least outstanding requests routing  

**Domain**: 3.1 Choose performant storage and databases  
**Difficulty**: Advanced

---

## Question 4 🟡
**Scenario**: An e-commerce application has a product search feature that's becoming slow as the product catalog grows. Users search by product name, category, price range, and various attributes. The current MySQL database struggles with complex search queries.

**Which solution provides the BEST search performance?**

A) Add database indexes for all searchable fields  
B) Implement Amazon OpenSearch (Elasticsearch) for full-text search  
C) Use Amazon RDS with read replicas for search queries  
D) Cache search results in Amazon ElastiCache  

**Domain**: 3.1 Choose performant storage and databases  
**Difficulty**: Intermediate

---

## Question 5 🟢
**Scenario**: A Spring Boot application running on EC2 instances experiences high CPU utilization during business hours. The application is stateless and can be horizontally scaled.

**What is the MOST cost-effective way to handle the varying load?**

A) Upgrade to larger EC2 instances permanently  
B) Configure Auto Scaling to add instances during high load periods  
C) Use Spot Instances for all application servers  
D) Migrate the entire application to AWS Lambda  

**Domain**: 3.2 Design solutions for elasticity and scalability  
**Difficulty**: Beginner

---

## Question 6 🔴
**Scenario**: A video streaming platform needs to optimize video delivery for millions of concurrent users. They have videos in different resolutions (480p, 720p, 1080p, 4K) and need to serve the appropriate resolution based on user's device and bandwidth. They also need to minimize origin server load and provide instant playback.

**Which comprehensive solution provides optimal video delivery performance?**

A) CloudFront with Lambda@Edge for device detection + S3 for video storage + Adaptive bitrate streaming  
B) CloudFront with multiple origins for different resolutions + ElastiCache for metadata caching  
C) API Gateway with Lambda for resolution selection + S3 with Transfer Acceleration  
D) Multiple CloudFront distributions for each resolution + Direct S3 access for origin  

**Domain**: 3.3 Design solutions for high-performing networking  
**Difficulty**: Advanced

---

## Question 7 🟡
**Scenario**: A social media platform stores user posts, comments, and relationships. They need to support both relational queries (friend relationships) and high-speed reads for user feeds. The application requires strong consistency for financial transactions but can accept eventual consistency for social features.

**Which database architecture BEST handles these mixed requirements?**

A) Single Amazon RDS instance with read replicas  
B) Amazon DynamoDB for social features and Amazon RDS for financial transactions  
C) Amazon Aurora with both relational and document capabilities  
D) Amazon DocumentDB for all data with consistent reads  

**Domain**: 3.1 Choose performant storage and databases  
**Difficulty**: Intermediate

---

## Question 8 🟢
**Scenario**: A company's API response times vary significantly throughout the day. During peak hours, response times increase from 100ms to 2 seconds. The API performs complex calculations that could benefit from caching.

**Which caching strategy provides the BEST performance improvement?**

A) Cache responses at the API Gateway level  
B) Implement application-level caching with Amazon ElastiCache  
C) Use CloudFront for API response caching  
D) Cache database query results only  

**Domain**: 3.1 Choose performant storage and databases  
**Difficulty**: Beginner

---

## Question 9 🔴
**Scenario**: A real-time analytics platform processes IoT sensor data from millions of devices. They need to provide real-time dashboards, detect anomalies within seconds, and store data for long-term analysis. The system must handle data ingestion rates that can spike 100x during events.

**Which architecture provides the BEST performance for this real-time analytics use case?**

A) Kinesis Data Streams → Kinesis Analytics → ElastiCache → CloudWatch Dashboards + S3 for long-term storage  
B) SQS → Lambda → DynamoDB → QuickSight + S3 for archival  
C) API Gateway → Lambda → RDS → CloudWatch + S3 for backups  
D) Direct database writes → Read replicas → Reporting tools  

**Domain**: 3.2 Design solutions for elasticity and scalability  
**Difficulty**: Advanced

---

## Question 10 🟡
**Scenario**: An online gaming platform needs to serve game assets (textures, models, sounds) to players worldwide with minimal latency. Game files range from small icons (KB) to large video files (GB). Players download assets during game loading.

**Which content delivery strategy minimizes game loading times?**

A) CloudFront with S3 origin and custom caching policies based on file type  
B) S3 Transfer Acceleration for all asset downloads  
C) Regional S3 buckets with cross-region replication  
D) ElastiCache distributed across multiple regions  

**Domain**: 3.3 Design solutions for high-performing networking  
**Difficulty**: Intermediate

---

## Question 11 🟢
**Scenario**: A reporting application runs complex analytical queries that take 10-15 minutes to complete. These reports are run monthly and the results don't change once generated.

**Which approach provides the BEST performance for end users?**

A) Optimize database queries with better indexing  
B) Pre-generate reports and store results for quick access  
C) Use a more powerful database instance  
D) Implement real-time query caching  

**Domain**: 3.1 Choose performant storage and databases  
**Difficulty**: Beginner

---

## Question 12 🔴
**Scenario**: A machine learning platform trains models on large datasets and serves predictions via API. Training can take hours and uses significant compute resources, while prediction serving requires low latency and high throughput. The platform needs to handle both batch and real-time inference workloads efficiently.

**Which architecture optimizes performance for both training and inference workloads?**

A) EC2 GPU instances for training + Lambda for inference + S3 for model storage  
B) SageMaker Training Jobs + SageMaker Endpoints with auto-scaling + Model Registry  
C) ECS with GPU tasks for training + API Gateway + Lambda for inference  
D) Spot Fleet for training + EKS for inference serving + EFS for model storage  

**Domain**: 3.2 Design solutions for elasticity and scalability  
**Difficulty**: Advanced

---

## Question 13 🟡
**Scenario**: A document management system stores millions of PDF files ranging from 1KB to 100MB. Users frequently access recently uploaded documents but rarely access files older than 6 months. The system needs to optimize storage costs while maintaining good performance for active files.

**Which S3 storage strategy provides the BEST performance and cost balance?**

A) Store all files in S3 Standard for consistent performance  
B) Use S3 Intelligent-Tiering to automatically optimize storage costs  
C) Implement lifecycle policies: Standard → IA after 30 days → Glacier after 180 days  
D) Store frequently accessed files in S3 Standard, archive others to Glacier immediately  

**Domain**: 3.1 Choose performant storage and databases  
**Difficulty**: Intermediate

---

## Question 14 🟡
**Scenario**: A Spring Boot microservices application has performance issues with service-to-service communication. Some services are in different AZs, and network latency is impacting overall response times. The services need to maintain loose coupling.

**Which solution reduces inter-service communication latency while maintaining decoupling?**

A) Place all services in the same AZ to reduce network latency  
B) Use Amazon SQS for all inter-service communication  
C) Implement service mesh with AWS App Mesh for optimized routing  
D) Use AWS PrivateLink for service-to-service communication  

**Domain**: 3.3 Design solutions for high-performing networking  
**Difficulty**: Intermediate

---

## Question 15 🔴
**Scenario**: A multinational corporation needs to optimize their global application performance. They have users in North America, Europe, and Asia-Pacific regions. The application includes user authentication, real-time chat, file sharing, and collaborative document editing. Different features have different latency requirements and data consistency needs.

**Which comprehensive global performance optimization strategy should they implement?**

A) Multi-region deployment with Route 53 latency-based routing + Regional data replication + CDN for static assets  
B) Single region deployment with CloudFront global distribution + Edge locations for all content  
C) AWS Global Accelerator + Multi-region active-active deployment + DynamoDB Global Tables + CloudFront with Lambda@Edge  
D) Regional API Gateway deployments + Cross-region VPC peering + ElastiCache global datastore  

**Domain**: 3.3 Design solutions for high-performing networking  
**Difficulty**: Advanced

---

## 📊 Domain 3 Summary

**Question Distribution:**
- **Beginner (🟢)**: 4 questions (27%)
- **Intermediate (🟡)**: 7 questions (47%)
- **Advanced (🔴)**: 4 questions (26%)

**Sub-Domain Coverage:**
- **3.1 Choose performant storage and databases**: 8 questions
- **3.2 Design solutions for elasticity and scalability**: 4 questions
- **3.3 Design solutions for high-performing networking**: 3 questions

**Key Topics Covered:**
- Database performance optimization
- Caching strategies (ElastiCache, CloudFront)
- Auto Scaling and elasticity
- Global content delivery
- Storage performance optimization
- Real-time data processing
- Microservices performance
- Multi-region architectures

**Performance Optimization Techniques:**
- In-memory caching with ElastiCache
- Content delivery with CloudFront
- Database read replicas
- Search optimization with OpenSearch
- Auto Scaling for variable loads
- Global traffic routing
- Storage lifecycle optimization
- Network latency reduction

**Common Services Featured:**
- Amazon ElastiCache
- Amazon CloudFront
- Amazon RDS/Aurora
- Amazon DynamoDB
- Amazon S3
- Auto Scaling Groups
- Amazon Route 53
- AWS Global Accelerator

---

**Next**: Continue with [Domain 4: Design Cost-Optimized Architectures](./domain-4-cost.md)

**Answer Key**: Available in [Answer Keys Section](../answer-keys/domain-3-answers.md)
