# Module 5: Containers (ECS, EKS, Docker)
**Duration**: 12 hours | **Level**: Advanced | **Certification**: SAA-C03 Domain 3 (High-Performance Architectures)

## 🎯 Learning Objectives

By the end of this module, you will be able to:
- Containerize Spring Boot applications using Docker and Java 21
- Deploy microservices on Amazon ECS with Fargate
- Orchestrate containers using Amazon EKS (Kubernetes)
- Implement service discovery and load balancing for containerized apps
- Design CI/CD pipelines for container deployments
- Monitor and scale containerized applications effectively

---

## 📚 Module Contents

### 📖 Theory & Concepts
- **Container Fundamentals**: Docker, microservices architecture
- **Amazon ECS**: Task definitions, services, clusters, Fargate vs EC2
- **Amazon EKS**: Kubernetes concepts, nodes, pods, services
- **Service Mesh**: App Mesh, Istio, service discovery patterns
- **Container Security**: Image scanning, IAM roles, network isolation

### 💻 Code Examples
- **Dockerfile Optimization**: Multi-stage builds, Java 21 features
- **ECS Task Definitions**: Spring Boot configuration, health checks
- **Kubernetes Manifests**: Deployments, services, ingress controllers
- **Microservices Communication**: Service discovery, circuit breakers
- **Observability**: Distributed tracing, logging, metrics collection

### 🎯 Hands-on Labs
- **Lab 1**: Docker Containerization - Spring Boot optimization
- **Lab 2**: ECS Deployment - Fargate microservices
- **Lab 3**: EKS Setup - Kubernetes cluster with Spring Boot
- **Lab 4**: Service Mesh - App Mesh integration
- **Lab 5**: Production Pipeline - CI/CD with containers

---

## 🏗️ Container Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                        Containerized Microservices Architecture                │
│                                                                                 │
│  ┌─────────────────────────────────────────────────────────────────────────┐   │
│  │                           Application Load Balancer                     │   │
│  │                        • SSL Termination                               │   │
│  │                        • Path-based routing                            │   │
│  │                        • Health checks                                 │   │
│  └─────────────────────────────────────────────────────────────────────────┘   │
│                                           │                                     │
│                                           ▼                                     │
│  ┌─────────────────────────────────────────────────────────────────────────┐   │
│  │                          Container Orchestration                        │   │
│  │                                                                         │   │
│  │  ┌─────────────────────────┐       ┌─────────────────────────────────┐ │   │
│  │  │       Amazon ECS        │       │           Amazon EKS            │ │   │
│  │  │                         │       │                                 │ │   │
│  │  │  ┌─────────────────────┐│       │  ┌─────────────────────────────┐│ │   │
│  │  │  │  Order Service      ││       │  │      User Service           ││ │   │
│  │  │  │  • Spring Boot      ││       │  │      • Spring Boot          ││ │   │
│  │  │  │  • Java 21          ││       │  │      • Java 21              ││ │   │
│  │  │  │  • Fargate Task     ││       │  │      • Kubernetes Pod       ││ │   │
│  │  │  └─────────────────────┘│       │  └─────────────────────────────┘│ │   │
│  │  │                         │       │                                 │ │   │
│  │  │  ┌─────────────────────┐│       │  ┌─────────────────────────────┐│ │   │
│  │  │  │  Payment Service    ││       │  │    Product Service          ││ │   │
│  │  │  │  • Spring Boot      ││       │  │    • Spring Boot            ││ │   │
│  │  │  │  • Java 21          ││       │  │    • Java 21                ││ │   │
│  │  │  │  • Auto Scaling     ││       │  │    • HPA (Auto Scaling)     ││ │   │
│  │  │  └─────────────────────┘│       │  └─────────────────────────────┘│ │   │
│  │  └─────────────────────────┘       └─────────────────────────────────┘ │   │
│  └─────────────────────────────────────────────────────────────────────────┘   │
│                                           │                                     │
│                                           ▼                                     │
│  ┌─────────────────────────────────────────────────────────────────────────┐   │
│  │                           Service Discovery & Mesh                     │   │
│  │                                                                         │   │
│  │  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────────────┐ │   │
│  │  │   Cloud Map     │  │    App Mesh     │  │    Service Discovery    │ │   │
│  │  │  • DNS based    │  │  • Traffic mgmt │  │  • Load balancing       │ │   │
│  │  │  • Health checks│  │  • Observability│  │  • Circuit breaking     │ │   │
│  │  │  • Integration  │  │  • Security     │  │  • Retry policies       │ │   │
│  │  └─────────────────┘  └─────────────────┘  └─────────────────────────┘ │   │
│  └─────────────────────────────────────────────────────────────────────────┘   │
│                                           │                                     │
│                                           ▼                                     │
│  ┌─────────────────────────────────────────────────────────────────────────┐   │
│  │                              Data Layer                                 │   │
│  │                                                                         │   │
│  │  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────────────┐ │   │
│  │  │      RDS        │  │    DynamoDB     │  │         S3              │ │   │
│  │  │  • PostgreSQL   │  │  • Session data │  │  • Static content       │ │   │
│  │  │  • Multi-AZ     │  │  • Product cat. │  │  • File storage         │ │   │
│  │  │  • Read replicas│  │  • User profiles│  │  • Backup storage       │ │   │
│  │  └─────────────────┘  └─────────────────┘  └─────────────────────────┘ │   │
│  └─────────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────────┘
```

---

## 🎯 Key Learning Topics

### Docker & Containerization (3 hours)
- **Dockerfile Best Practices**: Multi-stage builds, layer optimization
- **Java 21 Containers**: JVM tuning, memory management, startup optimization
- **Security**: Image scanning, non-root users, minimal base images
- **Registry Management**: ECR, image versioning, vulnerability scanning

### Amazon ECS (3 hours)
- **Task Definitions**: CPU/memory allocation, networking, volumes
- **Services**: Auto scaling, load balancing, rolling deployments
- **Fargate vs EC2**: Cost optimization, use case selection
- **Service Discovery**: Cloud Map integration, DNS-based discovery

### Amazon EKS (4 hours)
- **Kubernetes Fundamentals**: Pods, services, deployments, namespaces
- **Cluster Management**: Node groups, auto scaling, networking
- **Application Deployment**: Helm charts, GitOps, progressive delivery
- **Monitoring**: Prometheus, Grafana, CloudWatch Container Insights

### Advanced Patterns (2 hours)
- **Service Mesh**: App Mesh, Istio, traffic management
- **CI/CD Integration**: CodePipeline, GitHub Actions, ArgoCD
- **Multi-environment Strategy**: Dev, staging, production deployments

---

## 💻 Container Implementation Examples

### Optimized Dockerfile for Spring Boot
```dockerfile
# Multi-stage build for optimal image size
FROM amazoncorretto:21-alpine AS builder

# Install Maven
RUN apk add --no-cache maven

# Copy source code
WORKDIR /app
COPY pom.xml .
COPY src ./src

# Build application
RUN mvn clean package -DskipTests

# Runtime stage
FROM amazoncorretto:21-alpine AS runtime

# Add non-root user for security
RUN addgroup -g 1001 -S spring && \
    adduser -u 1001 -S spring -G spring

# Install dumb-init for proper signal handling
RUN apk add --no-cache dumb-init

# Set working directory
WORKDIR /app

# Copy JAR from builder stage
COPY --from=builder /app/target/*.jar app.jar

# Change ownership to spring user
RUN chown spring:spring /app

# Switch to non-root user
USER spring

# Health check
HEALTHCHECK --interval=30s --timeout=10s --retries=3 \
  CMD wget -nv -t1 --spider http://localhost:8080/actuator/health || exit 1

# JVM optimization for containers
ENV JAVA_OPTS="-XX:+UseContainerSupport \
               -XX:+UseG1GC \
               -XX:MaxRAMPercentage=75.0 \
               -XX:+HeapDumpOnOutOfMemoryError \
               -XX:HeapDumpPath=/tmp/heapdump.hprof \
               -Djava.security.egd=file:/dev/./urandom"

# Expose port
EXPOSE 8080

# Use dumb-init for proper signal handling
ENTRYPOINT ["dumb-init", "--"]
CMD ["sh", "-c", "java $JAVA_OPTS -jar app.jar"]
```

### ECS Task Definition
```json
{
  "family": "spring-boot-microservice",
  "networkMode": "awsvpc",
  "requiresCompatibilities": ["FARGATE"],
  "cpu": "512",
  "memory": "1024",
  "executionRoleArn": "arn:aws:iam::account:role/ecsTaskExecutionRole",
  "taskRoleArn": "arn:aws:iam::account:role/ecsTaskRole",
  "containerDefinitions": [
    {
      "name": "order-service",
      "image": "your-account.dkr.ecr.region.amazonaws.com/order-service:latest",
      "essential": true,
      "portMappings": [
        {
          "containerPort": 8080,
          "protocol": "tcp"
        }
      ],
      "healthCheck": {
        "command": [
          "CMD-SHELL",
          "wget -nv -t1 --spider http://localhost:8080/actuator/health || exit 1"
        ],
        "interval": 30,
        "timeout": 10,
        "retries": 3,
        "startPeriod": 60
      },
      "environment": [
        {
          "name": "SPRING_PROFILES_ACTIVE",
          "value": "prod"
        },
        {
          "name": "AWS_REGION",
          "value": "us-east-1"
        }
      ],
      "secrets": [
        {
          "name": "DB_PASSWORD",
          "valueFrom": "arn:aws:secretsmanager:region:account:secret:db-password"
        }
      ],
      "logConfiguration": {
        "logDriver": "awslogs",
        "options": {
          "awslogs-group": "/ecs/spring-boot-microservice",
          "awslogs-region": "us-east-1",
          "awslogs-stream-prefix": "ecs"
        }
      }
    }
  ]
}
```

### Kubernetes Deployment
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: order-service
  namespace: microservices
spec:
  replicas: 3
  strategy:
    type: RollingUpdate
    rollingUpdate:
      maxSurge: 1
      maxUnavailable: 0
  selector:
    matchLabels:
      app: order-service
  template:
    metadata:
      labels:
        app: order-service
        version: v1
    spec:
      serviceAccountName: order-service-sa
      containers:
      - name: order-service
        image: your-account.dkr.ecr.region.amazonaws.com/order-service:latest
        ports:
        - containerPort: 8080
          name: http
        env:
        - name: SPRING_PROFILES_ACTIVE
          value: "prod"
        - name: AWS_REGION
          valueFrom:
            fieldRef:
              fieldPath: metadata.annotations['eks.amazonaws.com/region']
        envFrom:
        - secretRef:
            name: order-service-secrets
        resources:
          requests:
            memory: "512Mi"
            cpu: "250m"
          limits:
            memory: "1Gi"
            cpu: "500m"
        livenessProbe:
          httpGet:
            path: /actuator/health/liveness
            port: 8080
          initialDelaySeconds: 30
          periodSeconds: 30
        readinessProbe:
          httpGet:
            path: /actuator/health/readiness
            port: 8080
          initialDelaySeconds: 10
          periodSeconds: 5
        lifecycle:
          preStop:
            exec:
              command: ["sleep", "15"]
---
apiVersion: v1
kind: Service
metadata:
  name: order-service
  namespace: microservices
spec:
  selector:
    app: order-service
  ports:
  - port: 80
    targetPort: 8080
    name: http
  type: ClusterIP
---
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: order-service-hpa
  namespace: microservices
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: order-service
  minReplicas: 2
  maxReplicas: 10
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70
  - type: Resource
    resource:
      name: memory
      target:
        type: Utilization
        averageUtilization: 80
```

---

## 🎓 Certification Mapping

### SAA-C03 Domain 3: Design High-Performing Architectures (24%)

This module covers:
- **3.1** Choose performant storage and databases
  - ✅ Container-optimized storage solutions
  - ✅ EBS CSI drivers for persistent volumes
  - ✅ EFS for shared storage across containers

- **3.2** Design solutions for elasticity and scalability
  - ✅ ECS auto scaling and Fargate scaling
  - ✅ EKS horizontal pod autoscaling
  - ✅ Application Load Balancer integration

- **3.3** Design solutions for high-performing networking
  - ✅ VPC networking for containers
  - ✅ Service mesh for microservices communication
  - ✅ Container networking optimization

---

## 🏆 Microservices Design Patterns

### Circuit Breaker Pattern
```java
@Component
public class PaymentServiceClient {
    
    private final CircuitBreaker circuitBreaker;
    private final RestTemplate restTemplate;
    
    public PaymentServiceClient() {
        this.circuitBreaker = CircuitBreaker.ofDefaults("payment-service");
        this.restTemplate = new RestTemplate();
    }
    
    public PaymentResult processPayment(PaymentRequest request) {
        Supplier<PaymentResult> paymentCall = CircuitBreaker
            .decorateSupplier(circuitBreaker, () -> {
                return restTemplate.postForObject(
                    "http://payment-service/api/payments", 
                    request, 
                    PaymentResult.class);
            });
            
        return Try.ofSupplier(paymentCall)
            .recover(throwable -> {
                log.warn("Payment service unavailable, using fallback", throwable);
                return PaymentResult.unavailable();
            });
    }
}
```

### Service Discovery Pattern
```java
// ECS with Cloud Map
@Configuration
public class ServiceDiscoveryConfig {
    
    @Bean
    public DiscoveryClient discoveryClient() {
        return new CloudMapDiscoveryClient();
    }
    
    @LoadBalanced
    @Bean
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }
}

// Usage in service
@Service
public class OrderService {
    
    @Autowired
    private RestTemplate restTemplate;
    
    public void processOrder(Order order) {
        // Service discovery automatically resolves service names
        PaymentResult payment = restTemplate.postForObject(
            "http://payment-service/api/payments",
            createPaymentRequest(order),
            PaymentResult.class
        );
    }
}
```

---

## 📊 Container Performance Optimization

### Resource Allocation Best Practices
```yaml
# Right-sizing containers for optimal performance
resources:
  requests:
    memory: "512Mi"  # Guaranteed memory
    cpu: "250m"      # Guaranteed CPU (0.25 cores)
  limits:
    memory: "1Gi"    # Maximum memory
    cpu: "500m"      # Maximum CPU (0.5 cores)

# JVM tuning for containers
env:
- name: JAVA_OPTS
  value: "-XX:+UseContainerSupport 
          -XX:MaxRAMPercentage=75.0 
          -XX:+UseG1GC 
          -XX:MaxGCPauseMillis=200"
```

### Monitoring and Observability
```java
// Spring Boot Actuator for container health
@Component
public class CustomHealthIndicator implements HealthIndicator {
    
    @Override
    public Health health() {
        // Check application-specific health
        boolean databaseHealthy = checkDatabaseConnection();
        boolean externalServiceHealthy = checkExternalServices();
        
        if (databaseHealthy && externalServiceHealthy) {
            return Health.up()
                .withDetail("database", "UP")
                .withDetail("external-services", "UP")
                .build();
        } else {
            return Health.down()
                .withDetail("database", databaseHealthy ? "UP" : "DOWN")
                .withDetail("external-services", externalServiceHealthy ? "UP" : "DOWN")
                .build();
        }
    }
}
```

---

## 🛡️ Container Security Best Practices

### Image Security
```dockerfile
# Use minimal base images
FROM amazoncorretto:21-alpine

# Scan for vulnerabilities
RUN apk add --no-cache dumb-init && \
    apk update && apk upgrade

# Run as non-root user
RUN addgroup -g 1001 -S appuser && \
    adduser -u 1001 -S appuser -G appuser

USER appuser

# Use read-only root filesystem
COPY --chown=appuser:appuser app.jar /app/app.jar
```

### Runtime Security
```yaml
# Kubernetes security context
securityContext:
  runAsNonRoot: true
  runAsUser: 1001
  runAsGroup: 1001
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop:
    - ALL

# Pod security policy
apiVersion: policy/v1beta1
kind: PodSecurityPolicy
metadata:
  name: microservice-psp
spec:
  privileged: false
  allowPrivilegeEscalation: false
  requiredDropCapabilities:
    - ALL
  runAsUser:
    rule: 'MustRunAsNonRoot'
  fsGroup:
    rule: 'RunAsAny'
```

---

## 📚 Prerequisites

### Required Knowledge
- Completed Modules 1-4 (Foundation through Serverless)
- Docker fundamentals and containerization concepts
- Microservices architecture principles
- Basic Kubernetes concepts (pods, services, deployments)

### Development Environment
- Docker Desktop installed and configured
- AWS CLI with ECR permissions
- kubectl for Kubernetes interaction
- Helm for package management (optional)

---

## 🔄 Next Module

After completing this module, proceed to:
**[Module 6: Infrastructure as Code & CI/CD](../module-06-iac-cicd/README.md)**

You'll learn how to automate the deployment and management of your containerized applications using infrastructure as code and continuous deployment pipelines.

---

## 🎯 Container Strategy Decision Matrix

| Factor | ECS Fargate | ECS EC2 | EKS |
|--------|-------------|---------|-----|
| **Management Overhead** | Low | Medium | High |
| **Cost (Small Scale)** | Low | Medium | High |
| **Cost (Large Scale)** | High | Low | Medium |
| **Kubernetes Features** | No | No | Yes |
| **Vendor Lock-in** | High | High | Low |
| **Learning Curve** | Low | Medium | High |
| **Flexibility** | Medium | High | Very High |

---

**Ready to containerize your applications?** 🐳 Start with Docker optimization and then choose the right AWS container service for your specific use case!

**Begin with**: Docker Containerization Lab - Optimize your Spring Boot application for production container deployments.
