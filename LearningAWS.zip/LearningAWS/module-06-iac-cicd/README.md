# Module 6: Infrastructure as Code & CI/CD
**Duration**: 12 hours | **Level**: Advanced | **Certification**: SAA-C03 Domain 4 (Cost-Optimized Architectures)

## 🎯 Learning Objectives

By the end of this module, you will be able to:
- Implement Infrastructure as Code using AWS CloudFormation and Terraform
- Design and build automated CI/CD pipelines with AWS CodePipeline
- Deploy Spring Boot applications using GitOps principles
- Implement blue-green and canary deployment strategies
- Automate testing, security scanning, and compliance checks
- Optimize deployment costs and infrastructure management

---

## 📚 Module Contents

### 📖 Theory & Concepts
- **Infrastructure as Code**: CloudFormation vs Terraform vs CDK
- **CI/CD Pipeline Design**: Build, test, deploy, monitor phases
- **Deployment Strategies**: Rolling, blue-green, canary deployments
- **GitOps Principles**: Git as single source of truth
- **Security in Pipelines**: SAST, DAST, dependency scanning

### 💻 Code Examples
- **CloudFormation Templates**: Complete application stacks
- **Terraform Modules**: Reusable infrastructure components
- **Pipeline Definitions**: CodePipeline, GitHub Actions, Jenkins
- **Deployment Scripts**: Automated application deployment
- **Monitoring Integration**: CloudWatch, X-Ray, custom metrics

### 🎯 Hands-on Labs
- **Lab 1**: CloudFormation Stack - Complete application infrastructure
- **Lab 2**: Terraform Implementation - Multi-environment setup
- **Lab 3**: CI/CD Pipeline - Automated Spring Boot deployment
- **Lab 4**: Advanced Deployments - Blue-green and canary strategies
- **Lab 5**: GitOps Workflow - Complete automation

---

## 🏗️ CI/CD Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                           CI/CD Pipeline Architecture                           │
│                                                                                 │
│  ┌─────────────────────────────────────────────────────────────────────────┐   │
│  │                              Source Control                             │   │
│  │                                                                         │   │
│  │  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────────────┐ │   │
│  │  │   GitHub/       │  │   Infrastructure│  │    Application Code     │ │   │
│  │  │   CodeCommit    │  │   Code (IaC)    │  │    • Spring Boot        │ │   │
│  │  │                 │  │   • CloudFormation│ │    • Java 21            │ │   │
│  │  │  ┌─────────────┐│  │   • Terraform   │  │    • Tests              │ │   │
│  │  │  │  Git Hooks  ││  │   • CDK         │  │    • Dockerfile         │ │   │
│  │  │  └─────────────┘│  └─────────────────┘  └─────────────────────────┘ │   │
│  │  └─────────────────┘                                                   │   │
│  └─────────────────────────────────────────────────────────────────────────┘   │
│                                           │                                     │
│                                           ▼                                     │
│  ┌─────────────────────────────────────────────────────────────────────────┐   │
│  │                          CI/CD Pipeline Engine                         │   │
│  │                                                                         │   │
│  │  ┌─────────────────────────────────────────────────────────────────┐   │   │
│  │  │                      Build Stage                               │   │   │
│  │  │                                                                 │   │   │
│  │  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────────┐ │   │   │
│  │  │  │   Source    │  │    Build    │  │      Test Suite         │ │   │   │
│  │  │  │   Code      │→ │   • Maven   │→ │  • Unit Tests           │ │   │   │
│  │  │  │   Checkout  │  │   • Docker  │  │  • Integration Tests    │ │   │   │
│  │  │  │             │  │   • Package │  │  • Security Scans       │ │   │   │
│  │  │  └─────────────┘  └─────────────┘  └─────────────────────────┘ │   │   │
│  │  └─────────────────────────────────────────────────────────────────┘   │   │
│  │                                    │                                    │   │
│  │                                    ▼                                    │   │
│  │  ┌─────────────────────────────────────────────────────────────────┐   │   │
│  │  │                    Deploy Stage                                │   │   │
│  │  │                                                                 │   │   │
│  │  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────────┐ │   │   │
│  │  │  │   Staging   │  │  Production │  │    Rollback Strategy    │ │   │   │
│  │  │  │   Deploy    │→ │   Deploy    │  │  • Blue-Green           │ │   │   │
│  │  │  │             │  │             │  │  • Canary Release       │ │   │   │
│  │  │  │             │  │             │  │  • Automatic Rollback   │ │   │   │
│  │  │  └─────────────┘  └─────────────┘  └─────────────────────────┘ │   │   │
│  │  └─────────────────────────────────────────────────────────────────┘   │   │
│  └─────────────────────────────────────────────────────────────────────────┘   │
│                                           │                                     │
│                                           ▼                                     │
│  ┌─────────────────────────────────────────────────────────────────────────┐   │
│  │                        Target Environments                             │   │
│  │                                                                         │   │
│  │  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────────────┐ │   │
│  │  │   Development   │  │     Staging     │  │      Production         │ │   │
│  │  │   Environment   │  │   Environment   │  │     Environment         │ │   │
│  │  │                 │  │                 │  │                         │ │   │
│  │  │  • ECS/EKS      │  │  • ECS/EKS      │  │  • ECS/EKS              │ │   │
│  │  │  • RDS          │  │  • RDS          │  │  • RDS Multi-AZ         │ │   │
│  │  │  • Basic        │  │  • Production-  │  │  • Auto Scaling         │ │   │
│  │  │    monitoring   │  │    like config  │  │  • Full monitoring      │ │   │
│  │  └─────────────────┘  └─────────────────┘  └─────────────────────────┘ │   │
│  └─────────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────────┘
```

---

## 🎯 Key Learning Topics

### Infrastructure as Code (3 hours)
- **CloudFormation**: Templates, stacks, nested stacks, StackSets
- **Terraform**: Modules, state management, workspaces
- **AWS CDK**: Programming infrastructure with familiar languages
- **Best Practices**: Version control, testing, modularization

### CI/CD Pipeline Design (3 hours)
- **Pipeline Stages**: Source, build, test, deploy, monitor
- **AWS CodeServices**: CodeCommit, CodeBuild, CodeDeploy, CodePipeline
- **Third-party Integration**: GitHub Actions, Jenkins, GitLab CI
- **Artifact Management**: ECR, S3, versioning strategies

### Deployment Strategies (3 hours)
- **Rolling Deployments**: Zero-downtime updates
- **Blue-Green Deployments**: Instant switchover capability
- **Canary Deployments**: Risk mitigation through gradual rollout
- **Feature Flags**: Runtime configuration and A/B testing

### Advanced Automation (3 hours)
- **GitOps Workflows**: ArgoCD, Flux, configuration drift detection
- **Security Integration**: SAST, DAST, dependency vulnerability scanning
- **Compliance Automation**: Policy as code, automated auditing
- **Cost Optimization**: Resource tagging, automated cleanup

---

## 💻 Implementation Examples

### CloudFormation Template for Spring Boot Application
```yaml
AWSTemplateFormatVersion: '2010-09-09'
Description: 'Complete Spring Boot application infrastructure'

Parameters:
  ApplicationName:
    Type: String
    Default: spring-boot-app
    Description: Name of the application
    
  Environment:
    Type: String
    Default: dev
    AllowedValues: [dev, staging, prod]
    Description: Environment name
    
  ImageUri:
    Type: String
    Description: ECR image URI for the application

Mappings:
  EnvironmentConfig:
    dev:
      InstanceType: t3.small
      MinSize: 1
      MaxSize: 2
      DesiredCapacity: 1
    staging:
      InstanceType: t3.medium
      MinSize: 1
      MaxSize: 3
      DesiredCapacity: 2
    prod:
      InstanceType: t3.large
      MinSize: 2
      MaxSize: 10
      DesiredCapacity: 3

Resources:
  # VPC and Networking
  VPC:
    Type: AWS::EC2::VPC
    Properties:
      CidrBlock: 10.0.0.0/16
      EnableDnsHostnames: true
      EnableDnsSupport: true
      Tags:
        - Key: Name
          Value: !Sub '${ApplicationName}-${Environment}-vpc'

  PublicSubnet1:
    Type: AWS::EC2::Subnet
    Properties:
      VpcId: !Ref VPC
      CidrBlock: 10.0.1.0/24
      AvailabilityZone: !Select [0, !GetAZs '']
      MapPublicIpOnLaunch: true
      Tags:
        - Key: Name
          Value: !Sub '${ApplicationName}-${Environment}-public-subnet-1'

  PublicSubnet2:
    Type: AWS::EC2::Subnet
    Properties:
      VpcId: !Ref VPC
      CidrBlock: 10.0.2.0/24
      AvailabilityZone: !Select [1, !GetAZs '']
      MapPublicIpOnLaunch: true
      Tags:
        - Key: Name
          Value: !Sub '${ApplicationName}-${Environment}-public-subnet-2'

  PrivateSubnet1:
    Type: AWS::EC2::Subnet
    Properties:
      VpcId: !Ref VPC
      CidrBlock: 10.0.3.0/24
      AvailabilityZone: !Select [0, !GetAZs '']
      Tags:
        - Key: Name
          Value: !Sub '${ApplicationName}-${Environment}-private-subnet-1'

  PrivateSubnet2:
    Type: AWS::EC2::Subnet
    Properties:
      VpcId: !Ref VPC
      CidrBlock: 10.0.4.0/24
      AvailabilityZone: !Select [1, !GetAZs '']
      Tags:
        - Key: Name
          Value: !Sub '${ApplicationName}-${Environment}-private-subnet-2'

  # Internet Gateway
  InternetGateway:
    Type: AWS::EC2::InternetGateway
    Properties:
      Tags:
        - Key: Name
          Value: !Sub '${ApplicationName}-${Environment}-igw'

  AttachGateway:
    Type: AWS::EC2::VPCGatewayAttachment
    Properties:
      VpcId: !Ref VPC
      InternetGatewayId: !Ref InternetGateway

  # Application Load Balancer
  ApplicationLoadBalancer:
    Type: AWS::ElasticLoadBalancingV2::LoadBalancer
    Properties:
      Name: !Sub '${ApplicationName}-${Environment}-alb'
      Scheme: internet-facing
      Type: application
      Subnets:
        - !Ref PublicSubnet1
        - !Ref PublicSubnet2
      SecurityGroups:
        - !Ref ALBSecurityGroup
      Tags:
        - Key: Name
          Value: !Sub '${ApplicationName}-${Environment}-alb'

  ALBTargetGroup:
    Type: AWS::ElasticLoadBalancingV2::TargetGroup
    Properties:
      Name: !Sub '${ApplicationName}-${Environment}-tg'
      Port: 8080
      Protocol: HTTP
      VpcId: !Ref VPC
      TargetType: ip
      HealthCheckPath: /actuator/health
      HealthCheckIntervalSeconds: 30
      HealthCheckTimeoutSeconds: 10
      HealthyThresholdCount: 2
      UnhealthyThresholdCount: 5

  ALBListener:
    Type: AWS::ElasticLoadBalancingV2::Listener
    Properties:
      DefaultActions:
        - Type: forward
          TargetGroupArn: !Ref ALBTargetGroup
      LoadBalancerArn: !Ref ApplicationLoadBalancer
      Port: 80
      Protocol: HTTP

  # ECS Cluster
  ECSCluster:
    Type: AWS::ECS::Cluster
    Properties:
      ClusterName: !Sub '${ApplicationName}-${Environment}-cluster'
      CapacityProviders:
        - FARGATE
        - FARGATE_SPOT
      DefaultCapacityProviderStrategy:
        - CapacityProvider: FARGATE
          Weight: 1
        - CapacityProvider: FARGATE_SPOT
          Weight: 4

  # ECS Task Definition
  TaskDefinition:
    Type: AWS::ECS::TaskDefinition
    Properties:
      Family: !Sub '${ApplicationName}-${Environment}'
      NetworkMode: awsvpc
      RequiresCompatibilities:
        - FARGATE
      Cpu: !FindInMap [EnvironmentConfig, !Ref Environment, Cpu]
      Memory: !FindInMap [EnvironmentConfig, !Ref Environment, Memory]
      ExecutionRoleArn: !Ref ECSExecutionRole
      TaskRoleArn: !Ref ECSTaskRole
      ContainerDefinitions:
        - Name: !Sub '${ApplicationName}'
          Image: !Ref ImageUri
          Essential: true
          PortMappings:
            - ContainerPort: 8080
              Protocol: tcp
          HealthCheck:
            Command:
              - CMD-SHELL
              - wget -nv -t1 --spider http://localhost:8080/actuator/health || exit 1
            Interval: 30
            Timeout: 10
            Retries: 3
            StartPeriod: 60
          Environment:
            - Name: SPRING_PROFILES_ACTIVE
              Value: !Ref Environment
            - Name: AWS_REGION
              Value: !Ref AWS::Region
          LogConfiguration:
            LogDriver: awslogs
            Options:
              awslogs-group: !Ref CloudWatchLogGroup
              awslogs-region: !Ref AWS::Region
              awslogs-stream-prefix: ecs

  # ECS Service
  ECSService:
    Type: AWS::ECS::Service
    DependsOn: ALBListener
    Properties:
      ServiceName: !Sub '${ApplicationName}-${Environment}-service'
      Cluster: !Ref ECSCluster
      TaskDefinition: !Ref TaskDefinition
      LaunchType: FARGATE
      DesiredCount: !FindInMap [EnvironmentConfig, !Ref Environment, DesiredCapacity]
      NetworkConfiguration:
        AwsvpcConfiguration:
          SecurityGroups:
            - !Ref ECSSecurityGroup
          Subnets:
            - !Ref PrivateSubnet1
            - !Ref PrivateSubnet2
          AssignPublicIp: DISABLED
      LoadBalancers:
        - ContainerName: !Sub '${ApplicationName}'
          ContainerPort: 8080
          TargetGroupArn: !Ref ALBTargetGroup
      DeploymentConfiguration:
        MaximumPercent: 200
        MinimumHealthyPercent: 50
        DeploymentCircuitBreaker:
          Enable: true
          Rollback: true

Outputs:
  LoadBalancerDNS:
    Description: DNS name of the load balancer
    Value: !GetAtt ApplicationLoadBalancer.DNSName
    Export:
      Name: !Sub '${ApplicationName}-${Environment}-alb-dns'
      
  ClusterName:
    Description: Name of the ECS cluster
    Value: !Ref ECSCluster
    Export:
      Name: !Sub '${ApplicationName}-${Environment}-cluster-name'
```

### CodePipeline Configuration
```yaml
# buildspec.yml for CodeBuild
version: 0.2

phases:
  pre_build:
    commands:
      - echo Logging in to Amazon ECR...
      - aws ecr get-login-password --region $AWS_DEFAULT_REGION | docker login --username AWS --password-stdin $AWS_ACCOUNT_ID.dkr.ecr.$AWS_DEFAULT_REGION.amazonaws.com
      - REPOSITORY_URI=$AWS_ACCOUNT_ID.dkr.ecr.$AWS_DEFAULT_REGION.amazonaws.com/$IMAGE_REPO_NAME
      - COMMIT_HASH=$(echo $CODEBUILD_RESOLVED_SOURCE_VERSION | cut -c 1-7)
      - IMAGE_TAG=${COMMIT_HASH:=latest}
      
  build:
    commands:
      - echo Build started on `date`
      - echo Building the Java application...
      - mvn clean package -DskipTests
      - echo Running tests...
      - mvn test
      - echo Security scan...
      - mvn org.owasp:dependency-check-maven:check
      - echo Building the Docker image...
      - docker build -t $IMAGE_REPO_NAME:$IMAGE_TAG .
      - docker tag $IMAGE_REPO_NAME:$IMAGE_TAG $REPOSITORY_URI:$IMAGE_TAG
      
  post_build:
    commands:
      - echo Build completed on `date`
      - echo Pushing the Docker image...
      - docker push $REPOSITORY_URI:$IMAGE_TAG
      - echo Writing image definitions file...
      - printf '[{"name":"spring-boot-app","imageUri":"%s"}]' $REPOSITORY_URI:$IMAGE_TAG > imagedefinitions.json
      
artifacts:
  files:
    - imagedefinitions.json
    - cloudformation/**/*
    - scripts/**/*

cache:
  paths:
    - '/root/.m2/**/*'
    - '/root/.docker/**/*'
```

### Terraform Module for Application Infrastructure
```hcl
# modules/spring-boot-app/main.tf
terraform {
  required_version = ">= 1.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
}

variable "application_name" {
  description = "Name of the application"
  type        = string
}

variable "environment" {
  description = "Environment name"
  type        = string
  validation {
    condition     = contains(["dev", "staging", "prod"], var.environment)
    error_message = "Environment must be dev, staging, or prod."
  }
}

variable "image_uri" {
  description = "ECR image URI"
  type        = string
}

locals {
  common_tags = {
    Application = var.application_name
    Environment = var.environment
    ManagedBy   = "terraform"
  }
  
  environment_config = {
    dev = {
      instance_type     = "t3.small"
      min_size         = 1
      max_size         = 2
      desired_capacity = 1
      cpu             = 512
      memory          = 1024
    }
    staging = {
      instance_type     = "t3.medium"
      min_size         = 1
      max_size         = 3
      desired_capacity = 2
      cpu             = 1024
      memory          = 2048
    }
    prod = {
      instance_type     = "t3.large"
      min_size         = 2
      max_size         = 10
      desired_capacity = 3
      cpu             = 2048
      memory          = 4096
    }
  }
}

# VPC Module
module "vpc" {
  source = "terraform-aws-modules/vpc/aws"
  
  name = "${var.application_name}-${var.environment}"
  cidr = "10.0.0.0/16"
  
  azs             = data.aws_availability_zones.available.names
  public_subnets  = ["10.0.1.0/24", "10.0.2.0/24"]
  private_subnets = ["10.0.3.0/24", "10.0.4.0/24"]
  
  enable_nat_gateway = true
  enable_vpn_gateway = false
  enable_dns_hostnames = true
  enable_dns_support = true
  
  tags = local.common_tags
}

# Application Load Balancer
resource "aws_lb" "application" {
  name               = "${var.application_name}-${var.environment}-alb"
  internal           = false
  load_balancer_type = "application"
  security_groups    = [aws_security_group.alb.id]
  subnets            = module.vpc.public_subnets
  
  enable_deletion_protection = var.environment == "prod"
  
  tags = local.common_tags
}

resource "aws_lb_target_group" "application" {
  name        = "${var.application_name}-${var.environment}-tg"
  port        = 8080
  protocol    = "HTTP"
  vpc_id      = module.vpc.vpc_id
  target_type = "ip"
  
  health_check {
    enabled             = true
    healthy_threshold   = 2
    interval            = 30
    matcher             = "200"
    path                = "/actuator/health"
    port                = "traffic-port"
    protocol            = "HTTP"
    timeout             = 10
    unhealthy_threshold = 5
  }
  
  tags = local.common_tags
}

resource "aws_lb_listener" "application" {
  load_balancer_arn = aws_lb.application.arn
  port              = "80"
  protocol          = "HTTP"
  
  default_action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.application.arn
  }
}

# ECS Cluster
resource "aws_ecs_cluster" "application" {
  name = "${var.application_name}-${var.environment}-cluster"
  
  capacity_providers = ["FARGATE", "FARGATE_SPOT"]
  
  default_capacity_provider_strategy {
    capacity_provider = "FARGATE"
    weight           = 1
    base             = 1
  }
  
  default_capacity_provider_strategy {
    capacity_provider = "FARGATE_SPOT"
    weight           = 4
  }
  
  setting {
    name  = "containerInsights"
    value = "enabled"
  }
  
  tags = local.common_tags
}

# ECS Task Definition
resource "aws_ecs_task_definition" "application" {
  family                   = "${var.application_name}-${var.environment}"
  network_mode             = "awsvpc"
  requires_compatibilities = ["FARGATE"]
  cpu                      = local.environment_config[var.environment].cpu
  memory                   = local.environment_config[var.environment].memory
  execution_role_arn       = aws_iam_role.ecs_execution.arn
  task_role_arn            = aws_iam_role.ecs_task.arn
  
  container_definitions = jsonencode([
    {
      name  = var.application_name
      image = var.image_uri
      essential = true
      
      portMappings = [
        {
          containerPort = 8080
          protocol      = "tcp"
        }
      ]
      
      healthCheck = {
        command = [
          "CMD-SHELL",
          "wget -nv -t1 --spider http://localhost:8080/actuator/health || exit 1"
        ]
        interval    = 30
        timeout     = 10
        retries     = 3
        startPeriod = 60
      }
      
      environment = [
        {
          name  = "SPRING_PROFILES_ACTIVE"
          value = var.environment
        },
        {
          name  = "AWS_REGION"
          value = data.aws_region.current.name
        }
      ]
      
      logConfiguration = {
        logDriver = "awslogs"
        options = {
          "awslogs-group"         = aws_cloudwatch_log_group.application.name
          "awslogs-region"        = data.aws_region.current.name
          "awslogs-stream-prefix" = "ecs"
        }
      }
    }
  ])
  
  tags = local.common_tags
}

# ECS Service
resource "aws_ecs_service" "application" {
  name            = "${var.application_name}-${var.environment}-service"
  cluster         = aws_ecs_cluster.application.id
  task_definition = aws_ecs_task_definition.application.arn
  launch_type     = "FARGATE"
  desired_count   = local.environment_config[var.environment].desired_capacity
  
  network_configuration {
    security_groups  = [aws_security_group.ecs.id]
    subnets          = module.vpc.private_subnets
    assign_public_ip = false
  }
  
  load_balancer {
    container_name   = var.application_name
    container_port   = 8080
    target_group_arn = aws_lb_target_group.application.arn
  }
  
  deployment_configuration {
    maximum_percent         = 200
    minimum_healthy_percent = 50
    
    deployment_circuit_breaker {
      enable   = true
      rollback = true
    }
  }
  
  depends_on = [aws_lb_listener.application]
  
  tags = local.common_tags
}

# Auto Scaling
resource "aws_appautoscaling_target" "ecs_target" {
  max_capacity       = local.environment_config[var.environment].max_size
  min_capacity       = local.environment_config[var.environment].min_size
  resource_id        = "service/${aws_ecs_cluster.application.name}/${aws_ecs_service.application.name}"
  scalable_dimension = "ecs:service:DesiredCount"
  service_namespace  = "ecs"
}

resource "aws_appautoscaling_policy" "cpu_scaling" {
  name               = "${var.application_name}-${var.environment}-cpu-scaling"
  policy_type        = "TargetTrackingScaling"
  resource_id        = aws_appautoscaling_target.ecs_target.resource_id
  scalable_dimension = aws_appautoscaling_target.ecs_target.scalable_dimension
  service_namespace  = aws_appautoscaling_target.ecs_target.service_namespace
  
  target_tracking_scaling_policy_configuration {
    predefined_metric_specification {
      predefined_metric_type = "ECSServiceAverageCPUUtilization"
    }
    target_value = 70.0
  }
}

# Outputs
output "load_balancer_dns" {
  description = "DNS name of the load balancer"
  value       = aws_lb.application.dns_name
}

output "cluster_name" {
  description = "Name of the ECS cluster"
  value       = aws_ecs_cluster.application.name
}

output "service_name" {
  description = "Name of the ECS service"
  value       = aws_ecs_service.application.name
}
```

---

## 🎓 Certification Mapping

### SAA-C03 Domain 4: Design Cost-Optimized Architectures (20%)

This module covers:
- **4.1** Design cost-optimized storage solutions
  - ✅ Automated lifecycle policies
  - ✅ Resource tagging and cost allocation
  - ✅ Infrastructure optimization through IaC

- **4.2** Design cost-optimized compute solutions
  - ✅ Auto scaling for cost optimization
  - ✅ Spot instances and reserved capacity
  - ✅ Right-sizing through automation

---

## 🏆 Advanced Deployment Patterns

### Blue-Green Deployment with CodeDeploy
```yaml
# appspec.yml for CodeDeploy ECS
version: 0.0
Resources:
  - TargetService:
      Type: AWS::ECS::Service
      Properties:
        TaskDefinition: <TASK_DEFINITION>
        LoadBalancerInfo:
          ContainerName: "spring-boot-app"
          ContainerPort: 8080
        PlatformVersion: "LATEST"

Hooks:
  - BeforeInstall: "scripts/stop_application.sh"
  - ApplicationStart: "scripts/start_application.sh"
  - ApplicationStop: "scripts/stop_application.sh"
  - BeforeAllowTraffic: "scripts/pre_traffic_hook.sh"
  - AfterAllowTraffic: "scripts/post_traffic_hook.sh"
```

### Canary Deployment Strategy
```java
// Feature flag integration for canary releases
@RestController
public class OrderController {
    
    @Autowired
    private FeatureFlagService featureFlagService;
    
    @PostMapping("/orders")
    public ResponseEntity<OrderResponse> createOrder(@RequestBody OrderRequest request) {
        
        if (featureFlagService.isEnabled("new-order-processing", request.getUserId())) {
            // New implementation (canary)
            return processOrderV2(request);
        } else {
            // Stable implementation
            return processOrderV1(request);
        }
    }
}

@Service
public class FeatureFlagService {
    
    public boolean isEnabled(String flagName, String userId) {
        // Check feature flag service (AWS AppConfig, LaunchDarkly, etc.)
        // Implement percentage-based rollout
        return calculateCanaryPercentage(flagName, userId);
    }
}
```

---

## 📊 Cost Optimization Strategies

### Resource Tagging Strategy
```hcl
# Terraform tagging configuration
locals {
  required_tags = {
    Environment    = var.environment
    Application    = var.application_name
    Owner         = var.team_name
    CostCenter    = var.cost_center
    Project       = var.project_name
    ManagedBy     = "terraform"
    CreatedDate   = formatdate("YYYY-MM-DD", timestamp())
  }
}

# Apply tags to all resources
resource "aws_instance" "example" {
  # ... other configuration
  
  tags = merge(
    local.required_tags,
    {
      Name = "${var.application_name}-${var.environment}-instance"
      Type = "compute"
    }
  )
}
```

### Automated Cost Monitoring
```yaml
# CloudWatch alarm for cost monitoring
CostAlarm:
  Type: AWS::CloudWatch::Alarm
  Properties:
    AlarmName: !Sub '${ApplicationName}-${Environment}-cost-alarm'
    AlarmDescription: 'Alert when monthly costs exceed threshold'
    MetricName: EstimatedCharges
    Namespace: AWS/Billing
    Statistic: Maximum
    Period: 86400
    EvaluationPeriods: 1
    Threshold: !Ref CostThreshold
    ComparisonOperator: GreaterThanThreshold
    Dimensions:
      - Name: Currency
        Value: USD
    AlarmActions:
      - !Ref CostAlarmTopic
```

---

## 📚 Prerequisites

### Required Knowledge
- Completed Modules 1-5 (Foundation through Containers)
- Git version control and branching strategies
- CI/CD concepts and pipeline design
- Infrastructure as Code principles

### Development Environment
- AWS CLI with CloudFormation and CodeCommit permissions
- Terraform CLI (latest version)
- Git client configured
- IDE with YAML/JSON support

---

## 🔄 Next Module

After completing this module, proceed to:
**[Module 7: Monitoring & Security](../module-07-monitoring/README.md)**

You'll learn how to implement comprehensive monitoring, logging, and security practices for your automated infrastructure and applications.

---

## 🎯 Pipeline Best Practices

### Security in Pipelines
```yaml
# Security scanning in build pipeline
- name: Security Scan
  run: |
    # SAST (Static Application Security Testing)
    mvn org.owasp:dependency-check-maven:check
    
    # Container image scanning
    docker run --rm -v /var/run/docker.sock:/var/run/docker.sock \
      -v $(pwd):/tmp/ci aquasec/trivy image $IMAGE_URI
    
    # Infrastructure scanning
    terraform plan -out=tfplan
    tfsec tfplan
```

### Quality Gates
```java
// Quality gates in pipeline configuration
pipeline {
    stages {
        stage('Test') {
            steps {
                sh 'mvn test'
            }
            post {
                always {
                    publishTestResults testsPattern: 'target/surefire-reports/*.xml'
                    publishCoverage adapters: [jacocoAdapter('target/site/jacoco/jacoco.xml')], 
                                   sourceFileResolver: sourceFiles('STORE_LAST_BUILD')
                }
            }
        }
        
        stage('Quality Gate') {
            steps {
                script {
                    def qg = waitForQualityGate()
                    if (qg.status != 'OK') {
                        error "Pipeline aborted due to quality gate failure: ${qg.status}"
                    }
                }
            }
        }
    }
}
```

---

**Ready to automate everything?** 🚀 Build robust, secure, and cost-effective CI/CD pipelines that deliver your Spring Boot applications reliably to production!

**Begin with**: CloudFormation Stack Lab - Create your complete application infrastructure as code.
