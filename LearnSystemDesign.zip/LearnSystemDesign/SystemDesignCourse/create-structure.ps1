# System Design Course Structure Creator

$modules = @(
    "01-foundations",
    "02-networking", 
    "03-storage",
    "04-databases",
    "05-caching",
    "06-messaging",
    "07-microservices",
    "08-consistency",
    "09-scalability",
    "10-observability",
    "11-security",
    "12-cloud-aws",
    "13-case-studies",
    "14-interview-mastery"
)

$caseStudies = @(
    "url-shortener",
    "rate-limiter", 
    "chat-system",
    "social-media-timeline",
    "e-commerce-platform",
    "notification-system",
    "video-streaming",
    "search-engine"
)

Write-Host "Creating System Design Course structure..." -ForegroundColor Green

# Create module directories
foreach ($module in $modules) {
    $modulePath = "docs/$module"
    New-Item -ItemType Directory -Path $modulePath -Force | Out-Null
    
    # Create subdirectories for each module
    New-Item -ItemType Directory -Path "$modulePath/diagrams" -Force | Out-Null
    New-Item -ItemType Directory -Path "$modulePath/examples" -Force | Out-Null
    New-Item -ItemType Directory -Path "$modulePath/exercises" -Force | Out-Null
    
    Write-Host "Created: $modulePath" -ForegroundColor Yellow
}

# Create code structure
$codeStructure = @(
    "common/utils",
    "common/config",
    "common/testing",
    "modules",
    "case-studies",
    "capstone-notification-platform"
)

foreach ($dir in $codeStructure) {
    New-Item -ItemType Directory -Path "code/$dir" -Force | Out-Null
    Write-Host "Created: code/$dir" -ForegroundColor Yellow
}

# Create case study directories
foreach ($study in $caseStudies) {
    New-Item -ItemType Directory -Path "code/case-studies/$study" -Force | Out-Null
    New-Item -ItemType Directory -Path "docs/13-case-studies/$study" -Force | Out-Null
    Write-Host "Created case study: $study" -ForegroundColor Cyan
}

# Create infrastructure directories
$infraDirs = @("docker", "kubernetes", "terraform", "monitoring", "scripts")
foreach ($dir in $infraDirs) {
    New-Item -ItemType Directory -Path "infra/$dir" -Force | Out-Null
    Write-Host "Created: infra/$dir" -ForegroundColor Yellow
}

# Create cheatsheets directories
$cheatDirs = @("java21", "spring-boot", "system-design", "aws", "patterns", "interview-prep")
foreach ($dir in $cheatDirs) {
    New-Item -ItemType Directory -Path "cheatsheets/$dir" -Force | Out-Null
    Write-Host "Created: cheatsheets/$dir" -ForegroundColor Yellow
}

Write-Host "`nStructure created successfully!" -ForegroundColor Green
Write-Host "Total modules: $($modules.Count)" -ForegroundColor White
Write-Host "Total case studies: $($caseStudies.Count)" -ForegroundColor White
