# Module 9: Scalability Patterns

## 📈 Building Systems That Scale to Millions

### 📚 Learning Objectives

By the end of this module, you will:
- Design horizontal and vertical scaling strategies
- Implement auto-scaling mechanisms for cloud environments
- Handle traffic spikes and capacity planning
- Design systems for global scale with geographic distribution
- Implement performance optimization patterns
- Plan for scaling databases, caches, and message queues

---

## 🏗️ Scaling Strategies and Patterns

### 1. Horizontal vs Vertical Scaling

```java
// Auto-scaling service implementation
@Service
public class AutoScalingService {
    
    @Autowired
    private MetricsCollector metricsCollector;
    
    @Autowired
    private KubernetesClient k8sClient;
    
    @Autowired
    private CloudProviderClient cloudClient;
    
    @Autowired
    private ScalingMetrics scalingMetrics;
    
    /**
     * Horizontal Pod Autoscaler (HPA) implementation
     */
    @Component
    public static class HorizontalPodAutoscaler {
        
        @Autowired
        private KubernetesClient kubernetesClient;
        
        @Autowired
        private MetricsServerClient metricsClient;
        
        @Scheduled(fixedRate = 30000) // Check every 30 seconds
        public void evaluateScaling() {
            List<Deployment> deployments = getScalableDeployments();
            
            for (Deployment deployment : deployments) {
                try {
                    ScalingDecision decision = evaluateDeploymentScaling(deployment);
                    
                    if (decision.shouldScale()) {
                        executeScaling(deployment, decision);
                    }
                    
                } catch (Exception e) {
                    log.error("Failed to evaluate scaling for deployment: {}", 
                        deployment.getMetadata().getName(), e);
                }
            }
        }
        
        private ScalingDecision evaluateDeploymentScaling(Deployment deployment) {
            String deploymentName = deployment.getMetadata().getName();
            int currentReplicas = deployment.getSpec().getReplicas();
            
            // Get current metrics
            ResourceMetrics metrics = metricsClient.getResourceMetrics(deploymentName);
            
            // CPU-based scaling
            double avgCpuUtilization = metrics.getAverageCpuUtilization();
            double targetCpuUtilization = getTargetCpuUtilization(deployment);
            
            // Memory-based scaling
            double avgMemoryUtilization = metrics.getAverageMemoryUtilization();
            double targetMemoryUtilization = getTargetMemoryUtilization(deployment);
            
            // Custom metrics scaling (e.g., request rate, queue length)
            double requestRate = metrics.getRequestRate();
            double targetRequestsPerReplica = getTargetRequestsPerReplica(deployment);
            
            // Calculate desired replicas based on different metrics
            int cpuDesiredReplicas = calculateReplicasForCpu(
                currentReplicas, avgCpuUtilization, targetCpuUtilization);
            
            int memoryDesiredReplicas = calculateReplicasForMemory(
                currentReplicas, avgMemoryUtilization, targetMemoryUtilization);
            
            int requestDesiredReplicas = calculateReplicasForRequests(
                requestRate, targetRequestsPerReplica);
            
            // Take the maximum to ensure all constraints are met
            int desiredReplicas = Math.max(Math.max(cpuDesiredReplicas, memoryDesiredReplicas), 
                                         requestDesiredReplicas);
            
            // Apply min/max constraints
            ScalingConstraints constraints = getScalingConstraints(deployment);
            desiredReplicas = Math.max(constraints.getMinReplicas(), 
                             Math.min(constraints.getMaxReplicas(), desiredReplicas));
            
            // Apply scaling policies (prevent thrashing)
            if (shouldApplyScalingPolicy(deployment, currentReplicas, desiredReplicas)) {
                return ScalingDecision.builder()
                    .shouldScale(currentReplicas != desiredReplicas)
                    .currentReplicas(currentReplicas)
                    .desiredReplicas(desiredReplicas)
                    .reason(buildScalingReason(metrics, desiredReplicas))
                    .metrics(metrics)
                    .build();
            }
            
            return ScalingDecision.noScaling(currentReplicas, "Scaling policy prevented scaling");
        }
        
        private int calculateReplicasForCpu(int currentReplicas, double currentUtilization, 
                                          double targetUtilization) {
            if (targetUtilization <= 0) return currentReplicas;
            
            // Scale up if utilization is above target, scale down if below
            double utilizationRatio = currentUtilization / targetUtilization;
            return (int) Math.ceil(currentReplicas * utilizationRatio);
        }
        
        private int calculateReplicasForMemory(int currentReplicas, double currentUtilization, 
                                             double targetUtilization) {
            if (targetUtilization <= 0) return currentReplicas;
            
            double utilizationRatio = currentUtilization / targetUtilization;
            return (int) Math.ceil(currentReplicas * utilizationRatio);
        }
        
        private int calculateReplicasForRequests(double requestRate, double targetRequestsPerReplica) {
            if (targetRequestsPerReplica <= 0) return 1;
            
            return (int) Math.ceil(requestRate / targetRequestsPerReplica);
        }
        
        private boolean shouldApplyScalingPolicy(Deployment deployment, int currentReplicas, 
                                               int desiredReplicas) {
            ScalingPolicy policy = getScalingPolicy(deployment);
            
            if (desiredReplicas > currentReplicas) {
                // Scale up policy
                return hasEnoughTimePassedSinceLastScaleUp(deployment, policy.getScaleUpCooldown()) &&
                       (desiredReplicas - currentReplicas) >= policy.getMinScaleUpStep();
            } else if (desiredReplicas < currentReplicas) {
                // Scale down policy
                return hasEnoughTimePassedSinceLastScaleDown(deployment, policy.getScaleDownCooldown()) &&
                       (currentReplicas - desiredReplicas) >= policy.getMinScaleDownStep();
            }
            
            return false;
        }
        
        private void executeScaling(Deployment deployment, ScalingDecision decision) {
            try {
                String deploymentName = deployment.getMetadata().getName();
                String namespace = deployment.getMetadata().getNamespace();
                
                log.info("Scaling deployment {} from {} to {} replicas. Reason: {}", 
                    deploymentName, decision.getCurrentReplicas(), 
                    decision.getDesiredReplicas(), decision.getReason());
                
                // Update deployment replica count
                kubernetesClient.apps().deployments()
                    .inNamespace(namespace)
                    .withName(deploymentName)
                    .scale(decision.getDesiredReplicas());
                
                // Record scaling event
                recordScalingEvent(deployment, decision);
                
                // Update scaling metrics
                scalingMetrics.recordScalingEvent(deploymentName, 
                    decision.getCurrentReplicas(), decision.getDesiredReplicas());
                
            } catch (Exception e) {
                log.error("Failed to execute scaling for deployment: {}", 
                    deployment.getMetadata().getName(), e);
                scalingMetrics.recordScalingFailure(deployment.getMetadata().getName(), e);
            }
        }
    }
    
    /**
     * Vertical Pod Autoscaler (VPA) implementation
     */
    @Component
    public static class VerticalPodAutoscaler {
        
        @Autowired
        private KubernetesClient kubernetesClient;
        
        @Autowired
        private MetricsServerClient metricsClient;
        
        @Scheduled(fixedRate = 300000) // Check every 5 minutes
        public void evaluateVerticalScaling() {
            List<Deployment> deployments = getVpaEnabledDeployments();
            
            for (Deployment deployment : deployments) {
                try {
                    ResourceRecommendation recommendation = generateResourceRecommendation(deployment);
                    
                    if (recommendation.shouldUpdate()) {
                        applyResourceRecommendation(deployment, recommendation);
                    }
                    
                } catch (Exception e) {
                    log.error("Failed to evaluate VPA for deployment: {}", 
                        deployment.getMetadata().getName(), e);
                }
            }
        }
        
        private ResourceRecommendation generateResourceRecommendation(Deployment deployment) {
            String deploymentName = deployment.getMetadata().getName();
            
            // Get historical resource usage
            ResourceUsageHistory history = metricsClient.getResourceUsageHistory(
                deploymentName, Duration.ofDays(7));
            
            // Analyze usage patterns
            ResourceUsageAnalysis analysis = analyzeResourceUsage(history);
            
            // Current resource requests and limits
            Container container = deployment.getSpec().getTemplate().getSpec().getContainers().get(0);
            ResourceRequirements currentResources = container.getResources();
            
            // Calculate recommendations
            ResourceRequirements recommendedRequests = calculateRecommendedRequests(analysis);
            ResourceRequirements recommendedLimits = calculateRecommendedLimits(analysis);
            
            return ResourceRecommendation.builder()
                .deploymentName(deploymentName)
                .currentRequests(currentResources.getRequests())
                .currentLimits(currentResources.getLimits())
                .recommendedRequests(recommendedRequests.getRequests())
                .recommendedLimits(recommendedLimits.getLimits())
                .shouldUpdate(shouldUpdateResources(currentResources, recommendedRequests, recommendedLimits))
                .confidence(analysis.getConfidence())
                .build();
        }
        
        private ResourceUsageAnalysis analyzeResourceUsage(ResourceUsageHistory history) {
            List<ResourceUsagePoint> dataPoints = history.getDataPoints();
            
            // Calculate percentiles
            double cpuP50 = calculatePercentile(dataPoints, ResourceType.CPU, 0.5);
            double cpuP95 = calculatePercentile(dataPoints, ResourceType.CPU, 0.95);
            double cpuP99 = calculatePercentile(dataPoints, ResourceType.CPU, 0.99);
            
            double memoryP50 = calculatePercentile(dataPoints, ResourceType.MEMORY, 0.5);
            double memoryP95 = calculatePercentile(dataPoints, ResourceType.MEMORY, 0.95);
            double memoryP99 = calculatePercentile(dataPoints, ResourceType.MEMORY, 0.99);
            
            // Detect trends
            Trend cpuTrend = detectTrend(dataPoints, ResourceType.CPU);
            Trend memoryTrend = detectTrend(dataPoints, ResourceType.MEMORY);
            
            // Calculate confidence based on data quality
            double confidence = calculateConfidence(dataPoints);
            
            return ResourceUsageAnalysis.builder()
                .cpuP50(cpuP50).cpuP95(cpuP95).cpuP99(cpuP99)
                .memoryP50(memoryP50).memoryP95(memoryP95).memoryP99(memoryP99)
                .cpuTrend(cpuTrend).memoryTrend(memoryTrend)
                .confidence(confidence)
                .dataPoints(dataPoints.size())
                .build();
        }
        
        private ResourceRequirements calculateRecommendedRequests(ResourceUsageAnalysis analysis) {
            // Requests should be based on typical usage (P50-P75)
            double cpuRequest = analysis.getCpuP50() * 1.2; // 20% buffer
            double memoryRequest = analysis.getMemoryP50() * 1.1; // 10% buffer
            
            // Apply growth trend
            if (analysis.getCpuTrend() == Trend.INCREASING) {
                cpuRequest *= 1.3; // 30% additional buffer for growing workloads
            }
            if (analysis.getMemoryTrend() == Trend.INCREASING) {
                memoryRequest *= 1.2; // 20% additional buffer
            }
            
            return ResourceRequirements.builder()
                .requests(Map.of(
                    "cpu", formatCpuResource(cpuRequest),
                    "memory", formatMemoryResource(memoryRequest)
                ))
                .build();
        }
        
        private ResourceRequirements calculateRecommendedLimits(ResourceUsageAnalysis analysis) {
            // Limits should handle peak usage (P95-P99)
            double cpuLimit = analysis.getCpuP95() * 1.5; // Allow burst capacity
            double memoryLimit = analysis.getMemoryP99() * 1.2; // Memory is less burstable
            
            return ResourceRequirements.builder()
                .limits(Map.of(
                    "cpu", formatCpuResource(cpuLimit),
                    "memory", formatMemoryResource(memoryLimit)
                ))
                .build();
        }
    }
    
    /**
     * Cluster Autoscaler for node-level scaling
     */
    @Component
    public static class ClusterAutoscaler {
        
        @Autowired
        private KubernetesClient kubernetesClient;
        
        @Autowired
        private CloudProviderClient cloudClient;
        
        @Scheduled(fixedRate = 60000) // Check every minute
        public void evaluateClusterScaling() {
            try {
                ClusterState clusterState = getCurrentClusterState();
                ScalingDecision decision = evaluateClusterScalingNeed(clusterState);
                
                if (decision.shouldScale()) {
                    executeClusterScaling(decision);
                }
                
            } catch (Exception e) {
                log.error("Failed to evaluate cluster scaling", e);
            }
        }
        
        private ClusterState getCurrentClusterState() {
            List<Node> nodes = kubernetesClient.nodes().list().getItems();
            List<Pod> pods = kubernetesClient.pods().inAnyNamespace().list().getItems();
            
            // Categorize nodes
            List<Node> readyNodes = nodes.stream()
                .filter(this::isNodeReady)
                .toList();
            
            List<Node> unschedulableNodes = nodes.stream()
                .filter(this::isNodeUnschedulable)
                .toList();
            
            // Find unschedulable pods
            List<Pod> unschedulablePods = pods.stream()
                .filter(this::isPodUnschedulable)
                .toList();
            
            // Calculate resource utilization
            ResourceUtilization utilization = calculateClusterUtilization(readyNodes, pods);
            
            return ClusterState.builder()
                .totalNodes(nodes.size())
                .readyNodes(readyNodes.size())
                .unschedulableNodes(unschedulableNodes.size())
                .unschedulablePods(unschedulablePods.size())
                .resourceUtilization(utilization)
                .nodeGroups(getNodeGroups())
                .build();
        }
        
        private ScalingDecision evaluateClusterScalingNeed(ClusterState state) {
            // Scale up conditions
            if (state.getUnschedulablePods() > 0) {
                return ScalingDecision.scaleUp("Unschedulable pods detected", 
                    calculateRequiredNodes(state.getUnschedulablePods()));
            }
            
            if (state.getResourceUtilization().getCpuUtilization() > 80 ||
                state.getResourceUtilization().getMemoryUtilization() > 85) {
                return ScalingDecision.scaleUp("High resource utilization", 1);
            }
            
            // Scale down conditions
            if (state.getResourceUtilization().getCpuUtilization() < 30 &&
                state.getResourceUtilization().getMemoryUtilization() < 40 &&
                state.getReadyNodes() > getMinimumNodes()) {
                
                return ScalingDecision.scaleDown("Low resource utilization", 
                    calculateNodesToRemove(state));
            }
            
            return ScalingDecision.noScaling("Cluster state is optimal");
        }
        
        private void executeClusterScaling(ScalingDecision decision) {
            try {
                if (decision.getScaleDirection() == ScaleDirection.UP) {
                    scaleUpCluster(decision.getNodeCount());
                } else if (decision.getScaleDirection() == ScaleDirection.DOWN) {
                    scaleDownCluster(decision.getNodeCount());
                }
                
                scalingMetrics.recordClusterScaling(decision);
                
            } catch (Exception e) {
                log.error("Failed to execute cluster scaling", e);
                scalingMetrics.recordClusterScalingFailure(e);
            }
        }
        
        private void scaleUpCluster(int nodeCount) {
            log.info("Scaling up cluster by {} nodes", nodeCount);
            
            // Add nodes to the appropriate node group
            NodeGroup targetNodeGroup = selectNodeGroupForScaleUp();
            cloudClient.addNodesToGroup(targetNodeGroup.getName(), nodeCount);
            
            // Wait for nodes to be ready
            waitForNodesReady(nodeCount, Duration.ofMinutes(10));
        }
        
        private void scaleDownCluster(int nodeCount) {
            log.info("Scaling down cluster by {} nodes", nodeCount);
            
            // Select nodes for removal (prefer underutilized nodes)
            List<Node> nodesToRemove = selectNodesForRemoval(nodeCount);
            
            for (Node node : nodesToRemove) {
                // Cordon and drain node
                cordonNode(node);
                drainNode(node);
                
                // Remove from cloud provider
                cloudClient.removeNode(node.getMetadata().getName());
            }
        }
    }
}
```

### 2. Global Distribution and CDN

```java
// Global distribution and CDN implementation
@Service
public class GlobalDistributionService {
    
    @Autowired
    private CloudFrontClient cloudFrontClient;
    
    @Autowired
    private GeolocationService geolocationService;
    
    @Autowired
    private LatencyMonitor latencyMonitor;
    
    /**
     * Geographic load balancing
     */
    @Component
    public static class GeographicLoadBalancer {
        
        @Autowired
        private ServiceDiscoveryClient serviceDiscovery;
        
        @Autowired
        private LatencyMonitor latencyMonitor;
        
        public ServiceEndpoint selectOptimalEndpoint(String clientIp, String serviceName) {
            // Determine client location
            GeoLocation clientLocation = geolocationService.getLocation(clientIp);
            
            // Get all available service endpoints
            List<ServiceEndpoint> endpoints = serviceDiscovery.getServiceEndpoints(serviceName);
            
            // Filter healthy endpoints
            List<ServiceEndpoint> healthyEndpoints = endpoints.stream()
                .filter(this::isEndpointHealthy)
                .toList();
            
            if (healthyEndpoints.isEmpty()) {
                throw new NoHealthyEndpointsException("No healthy endpoints for service: " + serviceName);
            }
            
            // Select optimal endpoint based on multiple criteria
            return selectBestEndpoint(clientLocation, healthyEndpoints);
        }
        
        private ServiceEndpoint selectBestEndpoint(GeoLocation clientLocation, 
                                                  List<ServiceEndpoint> endpoints) {
            
            return endpoints.stream()
                .map(endpoint -> EndpointScore.builder()
                    .endpoint(endpoint)
                    .score(calculateEndpointScore(clientLocation, endpoint))
                    .build())
                .max(Comparator.comparing(EndpointScore::getScore))
                .map(EndpointScore::getEndpoint)
                .orElse(endpoints.get(0)); // Fallback to first endpoint
        }
        
        private double calculateEndpointScore(GeoLocation clientLocation, ServiceEndpoint endpoint) {
            double score = 0.0;
            
            // Geographic distance (40% weight)
            double distance = calculateDistance(clientLocation, endpoint.getLocation());
            double distanceScore = Math.max(0, 1000 - distance) / 1000; // Normalize to 0-1
            score += distanceScore * 0.4;
            
            // Latency (30% weight)
            Duration avgLatency = latencyMonitor.getAverageLatency(endpoint);
            double latencyScore = Math.max(0, 1000 - avgLatency.toMillis()) / 1000;
            score += latencyScore * 0.3;
            
            // Load (20% weight)
            double currentLoad = endpoint.getCurrentLoad();
            double loadScore = Math.max(0, 1.0 - currentLoad);
            score += loadScore * 0.2;
            
            // Availability (10% weight)
            double availability = endpoint.getAvailability();
            score += availability * 0.1;
            
            return score;
        }
        
        private double calculateDistance(GeoLocation location1, GeoLocation location2) {
            // Haversine formula for geographic distance
            double lat1Rad = Math.toRadians(location1.getLatitude());
            double lat2Rad = Math.toRadians(location2.getLatitude());
            double deltaLatRad = Math.toRadians(location2.getLatitude() - location1.getLatitude());
            double deltaLonRad = Math.toRadians(location2.getLongitude() - location1.getLongitude());
            
            double a = Math.sin(deltaLatRad / 2) * Math.sin(deltaLatRad / 2) +
                      Math.cos(lat1Rad) * Math.cos(lat2Rad) *
                      Math.sin(deltaLonRad / 2) * Math.sin(deltaLonRad / 2);
            
            double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
            
            return 6371 * c; // Earth's radius in kilometers
        }
    }
    
    /**
     * CDN management and optimization
     */
    @Component
    public static class CDNManager {
        
        @Autowired
        private CloudFrontClient cloudFrontClient;
        
        @Autowired
        private CacheOptimizer cacheOptimizer;
        
        public void optimizeCDNConfiguration(String distributionId) {
            try {
                // Get current distribution configuration
                Distribution distribution = cloudFrontClient.getDistribution(distributionId);
                
                // Analyze traffic patterns
                TrafficAnalysis analysis = analyzeTrafficPatterns(distributionId);
                
                // Generate optimization recommendations
                CDNOptimizationPlan plan = generateOptimizationPlan(distribution, analysis);
                
                // Apply optimizations
                applyCDNOptimizations(distributionId, plan);
                
            } catch (Exception e) {
                log.error("Failed to optimize CDN configuration for distribution: {}", distributionId, e);
            }
        }
        
        private TrafficAnalysis analyzeTrafficPatterns(String distributionId) {
            // Get CloudFront metrics
            Duration analysisWindow = Duration.ofDays(7);
            CloudFrontMetrics metrics = cloudFrontClient.getMetrics(distributionId, analysisWindow);
            
            // Analyze request patterns
            Map<String, Long> requestsByPath = metrics.getRequestsByPath();
            Map<String, Double> cacheHitRates = metrics.getCacheHitRatesByPath();
            Map<String, Duration> responseTimesByPath = metrics.getResponseTimesByPath();
            Map<String, Long> requestsByGeography = metrics.getRequestsByGeography();
            
            // Identify hot spots and optimization opportunities
            List<String> highTrafficPaths = identifyHighTrafficPaths(requestsByPath);
            List<String> lowCacheHitPaths = identifyLowCacheHitPaths(cacheHitRates);
            List<String> slowResponsePaths = identifySlowResponsePaths(responseTimesByPath);
            
            return TrafficAnalysis.builder()
                .totalRequests(metrics.getTotalRequests())
                .averageCacheHitRate(metrics.getAverageCacheHitRate())
                .averageResponseTime(metrics.getAverageResponseTime())
                .highTrafficPaths(highTrafficPaths)
                .lowCacheHitPaths(lowCacheHitPaths)
                .slowResponsePaths(slowResponsePaths)
                .geographicDistribution(requestsByGeography)
                .build();
        }
        
        private CDNOptimizationPlan generateOptimizationPlan(Distribution distribution, 
                                                            TrafficAnalysis analysis) {
            
            List<CDNOptimization> optimizations = new ArrayList<>();
            
            // Cache optimization
            if (analysis.getAverageCacheHitRate() < 80) {
                optimizations.add(CDNOptimization.builder()
                    .type(OptimizationType.CACHE_BEHAVIOR)
                    .description("Improve cache behaviors for low hit rate paths")
                    .paths(analysis.getLowCacheHitPaths())
                    .expectedImpact("Increase cache hit rate by 15-25%")
                    .build());
            }
            
            // Compression optimization
            if (hasUncompressedContent(distribution)) {
                optimizations.add(CDNOptimization.builder()
                    .type(OptimizationType.COMPRESSION)
                    .description("Enable compression for text-based content")
                    .expectedImpact("Reduce bandwidth by 60-80%")
                    .build());
            }
            
            // Geographic optimization
            if (needsAdditionalEdgeLocations(analysis)) {
                optimizations.add(CDNOptimization.builder()
                    .type(OptimizationType.EDGE_LOCATIONS)
                    .description("Enable additional edge locations")
                    .expectedImpact("Reduce latency by 20-40%")
                    .build());
            }
            
            // Origin optimization
            if (hasSlowOriginResponse(analysis)) {
                optimizations.add(CDNOptimization.builder()
                    .type(OptimizationType.ORIGIN_OPTIMIZATION)
                    .description("Optimize origin connection settings")
                    .expectedImpact("Reduce origin fetch time by 30%")
                    .build());
            }
            
            return CDNOptimizationPlan.builder()
                .distributionId(distribution.getId())
                .optimizations(optimizations)
                .estimatedImpact(calculateEstimatedImpact(optimizations))
                .implementationEffort(calculateImplementationEffort(optimizations))
                .build();
        }
        
        private void applyCDNOptimizations(String distributionId, CDNOptimizationPlan plan) {
            for (CDNOptimization optimization : plan.getOptimizations()) {
                try {
                    switch (optimization.getType()) {
                        case CACHE_BEHAVIOR:
                            optimizeCacheBehaviors(distributionId, optimization);
                            break;
                        case COMPRESSION:
                            enableCompression(distributionId);
                            break;
                        case EDGE_LOCATIONS:
                            enableAdditionalEdgeLocations(distributionId);
                            break;
                        case ORIGIN_OPTIMIZATION:
                            optimizeOriginSettings(distributionId);
                            break;
                    }
                    
                    log.info("Applied CDN optimization: {} for distribution: {}", 
                        optimization.getType(), distributionId);
                    
                } catch (Exception e) {
                    log.error("Failed to apply CDN optimization: {} for distribution: {}", 
                        optimization.getType(), distributionId, e);
                }
            }
        }
    }
    
    /**
     * Traffic shaping and rate limiting
     */
    @Component
    public static class TrafficShaper {
        
        @Autowired
        private RedisTemplate<String, Object> redisTemplate;
        
        @Autowired
        private TrafficMetrics trafficMetrics;
        
        public boolean allowRequest(String clientId, TrafficShapingRule rule) {
            String key = STR."traffic_shaping:\{rule.getName()}:\{clientId}";
            
            try {
                // Implement token bucket algorithm
                TokenBucket bucket = getOrCreateTokenBucket(key, rule);
                
                if (bucket.tryConsume(1)) {
                    trafficMetrics.recordAllowedRequest(rule.getName(), clientId);
                    return true;
                } else {
                    trafficMetrics.recordBlockedRequest(rule.getName(), clientId);
                    return false;
                }
                
            } catch (Exception e) {
                log.error("Failed to apply traffic shaping for client: {}", clientId, e);
                // Fail open - allow request if traffic shaping fails
                return true;
            }
        }
        
        private TokenBucket getOrCreateTokenBucket(String key, TrafficShapingRule rule) {
            // Try to get existing bucket from Redis
            TokenBucketState state = (TokenBucketState) redisTemplate.opsForValue().get(key);
            
            if (state == null) {
                // Create new bucket
                state = TokenBucketState.builder()
                    .tokens(rule.getBucketCapacity())
                    .lastRefillTime(Instant.now())
                    .build();
            }
            
            // Refill tokens based on time elapsed
            TokenBucket bucket = TokenBucket.fromState(state, rule);
            bucket.refill();
            
            // Save updated state back to Redis
            redisTemplate.opsForValue().set(key, bucket.getState(), rule.getTimeWindow());
            
            return bucket;
        }
        
        // Adaptive traffic shaping based on system load
        public void adaptTrafficShaping() {
            SystemLoad currentLoad = systemMonitor.getCurrentLoad();
            
            if (currentLoad.getCpuUtilization() > 85 || currentLoad.getMemoryUtilization() > 90) {
                // System under stress - tighten traffic shaping
                tightenTrafficLimits(0.7); // Reduce limits by 30%
            } else if (currentLoad.getCpuUtilization() < 50 && currentLoad.getMemoryUtilization() < 60) {
                // System has capacity - relax traffic shaping
                relaxTrafficLimits(1.2); // Increase limits by 20%
            }
        }
    }
}
```

### 3. Database Scaling Strategies

```java
// Database scaling implementation
@Service
public class DatabaseScalingService {
    
    /**
     * Read replica management
     */
    @Component
    public static class ReadReplicaManager {
        
        @Autowired
        private RdsClient rdsClient;
        
        @Autowired
        private DatabaseMetrics dbMetrics;
        
        @Scheduled(fixedRate = 300000) // Check every 5 minutes
        public void evaluateReadReplicaScaling() {
            List<DatabaseCluster> clusters = getDatabaseClusters();
            
            for (DatabaseCluster cluster : clusters) {
                try {
                    ReadReplicaDecision decision = evaluateReadReplicaNeeds(cluster);
                    
                    if (decision.shouldScale()) {
                        executeReadReplicaScaling(cluster, decision);
                    }
                    
                } catch (Exception e) {
                    log.error("Failed to evaluate read replica scaling for cluster: {}", 
                        cluster.getClusterIdentifier(), e);
                }
            }
        }
        
        private ReadReplicaDecision evaluateReadReplicaNeeds(DatabaseCluster cluster) {
            String clusterId = cluster.getClusterIdentifier();
            
            // Get read/write ratio
            DatabaseMetrics.ReadWriteRatio ratio = dbMetrics.getReadWriteRatio(clusterId);
            
            // Get connection pool utilization
            double connectionUtilization = dbMetrics.getConnectionUtilization(clusterId);
            
            // Get read latency
            Duration avgReadLatency = dbMetrics.getAverageReadLatency(clusterId);
            
            // Get current replica count
            int currentReplicas = cluster.getReadReplicaCount();
            
            // Calculate optimal replica count
            int optimalReplicas = calculateOptimalReplicaCount(ratio, connectionUtilization, 
                avgReadLatency, currentReplicas);
            
            return ReadReplicaDecision.builder()
                .clusterId(clusterId)
                .currentReplicas(currentReplicas)
                .recommendedReplicas(optimalReplicas)
                .shouldScale(currentReplicas != optimalReplicas)
                .readWriteRatio(ratio)
                .connectionUtilization(connectionUtilization)
                .avgReadLatency(avgReadLatency)
                .build();
        }
        
        private int calculateOptimalReplicaCount(DatabaseMetrics.ReadWriteRatio ratio,
                                               double connectionUtilization,
                                               Duration avgReadLatency,
                                               int currentReplicas) {
            
            // Base calculation on read/write ratio
            double readPercentage = ratio.getReadPercentage();
            int baseReplicas = (int) Math.ceil(readPercentage / 25); // 1 replica per 25% read traffic
            
            // Adjust for connection utilization
            if (connectionUtilization > 80) {
                baseReplicas += 1; // Add replica for high connection usage
            }
            
            // Adjust for latency
            if (avgReadLatency.toMillis() > 100) {
                baseReplicas += 1; // Add replica for high latency
            }
            
            // Apply constraints
            int minReplicas = 1;
            int maxReplicas = 10;
            
            return Math.max(minReplicas, Math.min(maxReplicas, baseReplicas));
        }
        
        private void executeReadReplicaScaling(DatabaseCluster cluster, ReadReplicaDecision decision) {
            String clusterId = cluster.getClusterIdentifier();
            int currentReplicas = decision.getCurrentReplicas();
            int targetReplicas = decision.getRecommendedReplicas();
            
            try {
                if (targetReplicas > currentReplicas) {
                    // Scale up - add replicas
                    int replicasToAdd = targetReplicas - currentReplicas;
                    
                    for (int i = 0; i < replicasToAdd; i++) {
                        createReadReplica(cluster);
                    }
                    
                    log.info("Added {} read replicas to cluster: {}", replicasToAdd, clusterId);
                    
                } else if (targetReplicas < currentReplicas) {
                    // Scale down - remove replicas
                    int replicasToRemove = currentReplicas - targetReplicas;
                    
                    List<String> replicaInstances = getReadReplicaInstances(clusterId);
                    List<String> instancesToRemove = selectReplicasForRemoval(replicaInstances, replicasToRemove);
                    
                    for (String instanceId : instancesToRemove) {
                        removeReadReplica(instanceId);
                    }
                    
                    log.info("Removed {} read replicas from cluster: {}", replicasToRemove, clusterId);
                }
                
                dbMetrics.recordReplicaScaling(clusterId, currentReplicas, targetReplicas);
                
            } catch (Exception e) {
                log.error("Failed to execute read replica scaling for cluster: {}", clusterId, e);
                dbMetrics.recordReplicaScalingFailure(clusterId, e);
            }
        }
    }
    
    /**
     * Database connection pool scaling
     */
    @Component
    public static class ConnectionPoolScaler {
        
        @Autowired
        private HikariDataSource dataSource;
        
        @Autowired
        private DatabaseMetrics dbMetrics;
        
        @Scheduled(fixedRate = 60000) // Check every minute
        public void evaluateConnectionPoolScaling() {
            try {
                ConnectionPoolMetrics metrics = getConnectionPoolMetrics();
                ConnectionPoolDecision decision = evaluateConnectionPoolNeeds(metrics);
                
                if (decision.shouldScale()) {
                    executeConnectionPoolScaling(decision);
                }
                
            } catch (Exception e) {
                log.error("Failed to evaluate connection pool scaling", e);
            }
        }
        
        private ConnectionPoolMetrics getConnectionPoolMetrics() {
            HikariPoolMXBean poolMXBean = dataSource.getHikariPoolMXBean();
            
            return ConnectionPoolMetrics.builder()
                .activeConnections(poolMXBean.getActiveConnections())
                .idleConnections(poolMXBean.getIdleConnections())
                .totalConnections(poolMXBean.getTotalConnections())
                .threadsAwaitingConnection(poolMXBean.getThreadsAwaitingConnection())
                .maxPoolSize(dataSource.getMaximumPoolSize())
                .minPoolSize(dataSource.getMinimumIdle())
                .build();
        }
        
        private ConnectionPoolDecision evaluateConnectionPoolNeeds(ConnectionPoolMetrics metrics) {
            double utilizationRatio = (double) metrics.getActiveConnections() / metrics.getMaxPoolSize();
            
            int recommendedMaxSize = metrics.getMaxPoolSize();
            int recommendedMinSize = metrics.getMinPoolSize();
            
            // Scale up if utilization is high
            if (utilizationRatio > 0.8 || metrics.getThreadsAwaitingConnection() > 0) {
                recommendedMaxSize = Math.min(metrics.getMaxPoolSize() + 10, 100); // Cap at 100
            }
            
            // Scale down if utilization is very low
            if (utilizationRatio < 0.3 && metrics.getMaxPoolSize() > 20) {
                recommendedMaxSize = Math.max(metrics.getMaxPoolSize() - 5, 20); // Minimum 20
            }
            
            // Adjust minimum connections
            if (metrics.getIdleConnections() < 5 && metrics.getMinPoolSize() < 10) {
                recommendedMinSize = Math.min(metrics.getMinPoolSize() + 2, recommendedMaxSize / 2);
            }
            
            return ConnectionPoolDecision.builder()
                .currentMaxSize(metrics.getMaxPoolSize())
                .currentMinSize(metrics.getMinPoolSize())
                .recommendedMaxSize(recommendedMaxSize)
                .recommendedMinSize(recommendedMinSize)
                .shouldScale(recommendedMaxSize != metrics.getMaxPoolSize() || 
                           recommendedMinSize != metrics.getMinPoolSize())
                .utilizationRatio(utilizationRatio)
                .build();
        }
        
        private void executeConnectionPoolScaling(ConnectionPoolDecision decision) {
            try {
                if (decision.getRecommendedMaxSize() != decision.getCurrentMaxSize()) {
                    dataSource.setMaximumPoolSize(decision.getRecommendedMaxSize());
                    log.info("Updated connection pool max size from {} to {}", 
                        decision.getCurrentMaxSize(), decision.getRecommendedMaxSize());
                }
                
                if (decision.getRecommendedMinSize() != decision.getCurrentMinSize()) {
                    dataSource.setMinimumIdle(decision.getRecommendedMinSize());
                    log.info("Updated connection pool min size from {} to {}", 
                        decision.getCurrentMinSize(), decision.getRecommendedMinSize());
                }
                
                dbMetrics.recordConnectionPoolScaling(decision);
                
            } catch (Exception e) {
                log.error("Failed to execute connection pool scaling", e);
                dbMetrics.recordConnectionPoolScalingFailure(e);
            }
        }
    }
}
```

---

## 🎯 Interview Focus Areas

### Key Scalability Questions

**Q: How do you scale a web application to handle 10 million users?**
- **Horizontal scaling** with load balancers and auto-scaling
- **Database scaling** with read replicas and sharding
- **Caching layers** (CDN, Redis, application cache)
- **Microservices architecture** for independent scaling

**Q: How do you handle traffic spikes (e.g., Black Friday)?**
- **Auto-scaling policies** with predictive scaling
- **Queue-based processing** for traffic smoothing
- **Circuit breakers** to prevent cascade failures
- **Pre-scaling** based on historical patterns

**Q: How do you design for global scale?**
- **Geographic distribution** with multiple regions
- **CDN** for static content delivery
- **DNS-based load balancing** for traffic routing
- **Data locality** and regional compliance

**Q: How do you scale databases?**
- **Read replicas** for read-heavy workloads
- **Horizontal sharding** for write scalability
- **CQRS** for read/write separation
- **Connection pooling** optimization

---

## 🚀 Next Steps

1. **Complete the hands-on exercises** in the exercises folder
2. **Practice auto-scaling** configuration
3. **Design global distribution** strategies
4. **Implement performance monitoring** for scaling decisions
5. **Move to Module 10: Observability**

The scalability module provides the foundation for building systems that can grow from thousands to millions of users while maintaining performance and reliability.
