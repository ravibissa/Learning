// Production-ready auto-scaling implementation for system design interviews
package com.systemdesign.scalability.examples;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.cloud.kubernetes.fabric8.Fabric8AutoConfiguration;

import java.time.Instant;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.math.BigDecimal;

/**
 * Comprehensive auto-scaling implementation demonstrating
 * horizontal and vertical scaling patterns for distributed systems
 */
@Service
public class AutoScalingImplementation {
    
    @Autowired
    private KubernetesClient kubernetesClient;
    
    @Autowired
    private CloudProviderClient cloudClient;
    
    @Autowired
    private MetricsCollector metricsCollector;
    
    @Autowired
    private AlertingService alertingService;
    
    /**
     * Horizontal Pod Autoscaler with custom metrics
     */
    @Component
    public static class AdvancedHorizontalPodAutoscaler {
        
        private final Map<String, ScalingHistory> scalingHistory = new ConcurrentHashMap<>();
        
        @Scheduled(fixedRate = 30000) // Every 30 seconds
        public void evaluateScaling() {
            List<Deployment> deployments = getScalableDeployments();
            
            for (Deployment deployment : deployments) {
                try {
                    ScalingDecision decision = evaluateDeploymentScaling(deployment);
                    
                    if (decision.shouldScale()) {
                        executeScaling(deployment, decision);
                    }
                    
                } catch (Exception e) {
                    log.error("Failed to evaluate scaling for deployment: {}", 
                        deployment.getMetadata().getName(), e);
                }
            }
        }
        
        private ScalingDecision evaluateDeploymentScaling(Deployment deployment) {
            String deploymentName = deployment.getMetadata().getName();
            int currentReplicas = deployment.getSpec().getReplicas();
            
            // Collect comprehensive metrics
            DeploymentMetrics metrics = collectDeploymentMetrics(deploymentName);
            
            // Get scaling configuration
            ScalingConfig config = getScalingConfig(deployment);
            
            // Calculate desired replicas based on multiple factors
            int desiredReplicas = calculateDesiredReplicas(metrics, config, currentReplicas);
            
            // Apply scaling policies to prevent thrashing
            ScalingDecision decision = applyScalingPolicies(
                deploymentName, currentReplicas, desiredReplicas, metrics);
            
            return decision;
        }
        
        private DeploymentMetrics collectDeploymentMetrics(String deploymentName) {
            // CPU and Memory metrics
            ResourceMetrics resourceMetrics = metricsCollector.getResourceMetrics(deploymentName);
            
            // Application-specific metrics
            ApplicationMetrics appMetrics = metricsCollector.getApplicationMetrics(deploymentName);
            
            // Network and I/O metrics
            NetworkMetrics networkMetrics = metricsCollector.getNetworkMetrics(deploymentName);
            
            return DeploymentMetrics.builder()
                .cpuUtilization(resourceMetrics.getCpuUtilization())
                .memoryUtilization(resourceMetrics.getMemoryUtilization())
                .requestRate(appMetrics.getRequestRate())
                .responseTime(appMetrics.getAverageResponseTime())
                .errorRate(appMetrics.getErrorRate())
                .queueLength(appMetrics.getQueueLength())
                .networkThroughput(networkMetrics.getThroughput())
                .connectionCount(networkMetrics.getActiveConnections())
                .build();
        }
        
        private int calculateDesiredReplicas(DeploymentMetrics metrics, 
                                           ScalingConfig config, 
                                           int currentReplicas) {
            
            List<Integer> replicaSuggestions = new ArrayList<>();
            
            // CPU-based scaling
            if (config.isCpuScalingEnabled()) {
                int cpuReplicas = calculateCpuBasedReplicas(
                    currentReplicas, metrics.getCpuUtilization(), config.getTargetCpuUtilization());
                replicaSuggestions.add(cpuReplicas);
            }
            
            // Memory-based scaling
            if (config.isMemoryScalingEnabled()) {
                int memoryReplicas = calculateMemoryBasedReplicas(
                    currentReplicas, metrics.getMemoryUtilization(), config.getTargetMemoryUtilization());
                replicaSuggestions.add(memoryReplicas);
            }
            
            // Request rate-based scaling
            if (config.isRequestRateScalingEnabled()) {
                int requestReplicas = calculateRequestBasedReplicas(
                    metrics.getRequestRate(), config.getTargetRequestsPerReplica());
                replicaSuggestions.add(requestReplicas);
            }
            
            // Response time-based scaling
            if (config.isResponseTimeScalingEnabled()) {
                int responseTimeReplicas = calculateResponseTimeBasedReplicas(
                    currentReplicas, metrics.getResponseTime(), config.getTargetResponseTime());
                replicaSuggestions.add(responseTimeReplicas);
            }
            
            // Queue length-based scaling
            if (config.isQueueLengthScalingEnabled()) {
                int queueReplicas = calculateQueueBasedReplicas(
                    currentReplicas, metrics.getQueueLength(), config.getMaxQueueLength());
                replicaSuggestions.add(queueReplicas);
            }
            
            // Take the maximum to satisfy all constraints
            int desiredReplicas = replicaSuggestions.stream()
                .mapToInt(Integer::intValue)
                .max()
                .orElse(currentReplicas);
            
            // Apply min/max constraints
            return Math.max(config.getMinReplicas(), 
                   Math.min(config.getMaxReplicas(), desiredReplicas));
        }
        
        private int calculateCpuBasedReplicas(int currentReplicas, double currentCpu, double targetCpu) {
            if (targetCpu <= 0) return currentReplicas;
            
            double utilizationRatio = currentCpu / targetCpu;
            return (int) Math.ceil(currentReplicas * utilizationRatio);
        }
        
        private int calculateMemoryBasedReplicas(int currentReplicas, double currentMemory, double targetMemory) {
            if (targetMemory <= 0) return currentReplicas;
            
            double utilizationRatio = currentMemory / targetMemory;
            return (int) Math.ceil(currentReplicas * utilizationRatio);
        }
        
        private int calculateRequestBasedReplicas(double requestRate, double targetRequestsPerReplica) {
            if (targetRequestsPerReplica <= 0) return 1;
            
            return (int) Math.ceil(requestRate / targetRequestsPerReplica);
        }
        
        private int calculateResponseTimeBasedReplicas(int currentReplicas, 
                                                     Duration currentResponseTime, 
                                                     Duration targetResponseTime) {
            if (currentResponseTime.compareTo(targetResponseTime) <= 0) {
                return currentReplicas;
            }
            
            // Scale up based on response time degradation
            double timeRatio = (double) currentResponseTime.toMillis() / targetResponseTime.toMillis();
            return (int) Math.ceil(currentReplicas * Math.sqrt(timeRatio));
        }
        
        private int calculateQueueBasedReplicas(int currentReplicas, int queueLength, int maxQueueLength) {
            if (queueLength <= maxQueueLength) {
                return currentReplicas;
            }
            
            // Scale up based on queue overflow
            double queueRatio = (double) queueLength / maxQueueLength;
            return (int) Math.ceil(currentReplicas * queueRatio);
        }
        
        private ScalingDecision applyScalingPolicies(String deploymentName, 
                                                   int currentReplicas, 
                                                   int desiredReplicas,
                                                   DeploymentMetrics metrics) {
            
            ScalingHistory history = scalingHistory.computeIfAbsent(deploymentName, 
                k -> new ScalingHistory());
            
            // Check cooldown periods
            if (desiredReplicas > currentReplicas) {
                // Scale up
                if (!history.canScaleUp()) {
                    return ScalingDecision.noScaling(currentReplicas, "Scale up cooldown active");
                }
                
                // Apply scale-up limits
                int maxScaleUp = calculateMaxScaleUp(currentReplicas, history);
                desiredReplicas = Math.min(desiredReplicas, currentReplicas + maxScaleUp);
                
            } else if (desiredReplicas < currentReplicas) {
                // Scale down
                if (!history.canScaleDown()) {
                    return ScalingDecision.noScaling(currentReplicas, "Scale down cooldown active");
                }
                
                // Apply scale-down limits
                int maxScaleDown = calculateMaxScaleDown(currentReplicas, history);
                desiredReplicas = Math.max(desiredReplicas, currentReplicas - maxScaleDown);
            }
            
            if (desiredReplicas == currentReplicas) {
                return ScalingDecision.noScaling(currentReplicas, "No scaling needed");
            }
            
            // Check for oscillation prevention
            if (history.isOscillating(desiredReplicas)) {
                return ScalingDecision.noScaling(currentReplicas, "Preventing oscillation");
            }
            
            String reason = buildScalingReason(metrics, currentReplicas, desiredReplicas);
            
            return ScalingDecision.builder()
                .shouldScale(true)
                .currentReplicas(currentReplicas)
                .desiredReplicas(desiredReplicas)
                .reason(reason)
                .metrics(metrics)
                .build();
        }
        
        private int calculateMaxScaleUp(int currentReplicas, ScalingHistory history) {
            // Conservative scaling: limit to 50% increase or 10 replicas, whichever is smaller
            int percentageIncrease = Math.max(1, currentReplicas / 2);
            return Math.min(percentageIncrease, 10);
        }
        
        private int calculateMaxScaleDown(int currentReplicas, ScalingHistory history) {
            // Conservative scaling: limit to 25% decrease or 5 replicas, whichever is smaller
            int percentageDecrease = Math.max(1, currentReplicas / 4);
            return Math.min(percentageDecrease, 5);
        }
        
        private void executeScaling(Deployment deployment, ScalingDecision decision) {
            String deploymentName = deployment.getMetadata().getName();
            String namespace = deployment.getMetadata().getNamespace();
            
            try {
                log.info("Scaling deployment {} from {} to {} replicas. Reason: {}", 
                    deploymentName, decision.getCurrentReplicas(), 
                    decision.getDesiredReplicas(), decision.getReason());
                
                // Update deployment
                kubernetesClient.apps().deployments()
                    .inNamespace(namespace)
                    .withName(deploymentName)
                    .scale(decision.getDesiredReplicas());
                
                // Record scaling event
                recordScalingEvent(deploymentName, decision);
                
                // Update scaling history
                ScalingHistory history = scalingHistory.get(deploymentName);
                history.recordScalingEvent(decision);
                
                // Send metrics
                metricsCollector.recordScalingEvent(deploymentName, 
                    decision.getCurrentReplicas(), decision.getDesiredReplicas());
                
                // Send alert if significant scaling
                if (Math.abs(decision.getDesiredReplicas() - decision.getCurrentReplicas()) > 5) {
                    alertingService.sendScalingAlert(ScalingAlert.builder()
                        .deploymentName(deploymentName)
                        .scalingDirection(decision.getDesiredReplicas() > decision.getCurrentReplicas() ? 
                            "UP" : "DOWN")
                        .currentReplicas(decision.getCurrentReplicas())
                        .desiredReplicas(decision.getDesiredReplicas())
                        .reason(decision.getReason())
                        .severity(AlertSeverity.MEDIUM)
                        .build());
                }
                
            } catch (Exception e) {
                log.error("Failed to execute scaling for deployment: {}", deploymentName, e);
                metricsCollector.recordScalingFailure(deploymentName, e);
                
                alertingService.sendAlert(Alert.builder()
                    .title("Autoscaling Failure")
                    .message(STR."Failed to scale deployment \{deploymentName}: \{e.getMessage()}")
                    .severity(AlertSeverity.HIGH)
                    .build());
            }
        }
    }
    
    /**
     * Vertical Pod Autoscaler with machine learning-based recommendations
     */
    @Component
    public static class IntelligentVerticalPodAutoscaler {
        
        @Autowired
        private ResourceUsageAnalyzer usageAnalyzer;
        
        @Autowired
        private MLModelService mlModelService;
        
        @Scheduled(fixedRate = 300000) // Every 5 minutes
        public void evaluateVerticalScaling() {
            List<Deployment> deployments = getVpaEnabledDeployments();
            
            for (Deployment deployment : deployments) {
                try {
                    ResourceRecommendation recommendation = generateIntelligentRecommendation(deployment);
                    
                    if (recommendation.shouldUpdate()) {
                        applyResourceRecommendation(deployment, recommendation);
                    }
                    
                } catch (Exception e) {
                    log.error("Failed to evaluate VPA for deployment: {}", 
                        deployment.getMetadata().getName(), e);
                }
            }
        }
        
        private ResourceRecommendation generateIntelligentRecommendation(Deployment deployment) {
            String deploymentName = deployment.getMetadata().getName();
            
            // Collect historical usage data
            ResourceUsageHistory history = usageAnalyzer.getUsageHistory(
                deploymentName, Duration.ofDays(14));
            
            // Analyze usage patterns
            UsagePatterns patterns = usageAnalyzer.analyzePatterns(history);
            
            // Use ML model for prediction
            ResourcePrediction prediction = mlModelService.predictResourceNeeds(
                deploymentName, patterns);
            
            // Current resource allocation
            Container container = deployment.getSpec().getTemplate().getSpec().getContainers().get(0);
            ResourceRequirements current = container.getResources();
            
            // Generate recommendations
            ResourceRequirements recommended = generateOptimalResources(
                patterns, prediction, current);
            
            // Calculate confidence and impact
            double confidence = calculateRecommendationConfidence(patterns, prediction);
            ResourceImpact impact = calculateResourceImpact(current, recommended);
            
            return ResourceRecommendation.builder()
                .deploymentName(deploymentName)
                .currentRequests(current.getRequests())
                .currentLimits(current.getLimits())
                .recommendedRequests(recommended.getRequests())
                .recommendedLimits(recommended.getLimits())
                .confidence(confidence)
                .impact(impact)
                .shouldUpdate(shouldApplyRecommendation(confidence, impact))
                .reasoning(buildRecommendationReasoning(patterns, prediction))
                .build();
        }
        
        private ResourceRequirements generateOptimalResources(UsagePatterns patterns, 
                                                            ResourcePrediction prediction,
                                                            ResourceRequirements current) {
            
            // CPU recommendation
            double cpuRequest = calculateOptimalCpuRequest(patterns, prediction);
            double cpuLimit = calculateOptimalCpuLimit(patterns, prediction);
            
            // Memory recommendation
            long memoryRequest = calculateOptimalMemoryRequest(patterns, prediction);
            long memoryLimit = calculateOptimalMemoryLimit(patterns, prediction);
            
            // Apply safety margins
            cpuRequest *= 1.1; // 10% safety margin
            memoryRequest = (long) (memoryRequest * 1.1);
            
            // Ensure limits are higher than requests
            cpuLimit = Math.max(cpuLimit, cpuRequest * 1.5);
            memoryLimit = Math.max(memoryLimit, (long) (memoryRequest * 1.2));
            
            return ResourceRequirements.builder()
                .requests(Map.of(
                    "cpu", formatCpuResource(cpuRequest),
                    "memory", formatMemoryResource(memoryRequest)
                ))
                .limits(Map.of(
                    "cpu", formatCpuResource(cpuLimit),
                    "memory", formatMemoryResource(memoryLimit)
                ))
                .build();
        }
        
        private double calculateOptimalCpuRequest(UsagePatterns patterns, ResourcePrediction prediction) {
            // Use 80th percentile of historical usage as baseline
            double baselineCpu = patterns.getCpuPercentile(0.8);
            
            // Adjust for predicted growth
            double growthFactor = prediction.getCpuGrowthFactor();
            
            // Consider seasonality
            double seasonalityAdjustment = patterns.getSeasonalityAdjustment();
            
            return baselineCpu * growthFactor * seasonalityAdjustment;
        }
        
        private long calculateOptimalMemoryRequest(UsagePatterns patterns, ResourcePrediction prediction) {
            // Use 90th percentile for memory (less burstable than CPU)
            long baselineMemory = patterns.getMemoryPercentile(0.9);
            
            // Adjust for predicted growth
            double growthFactor = prediction.getMemoryGrowthFactor();
            
            return (long) (baselineMemory * growthFactor);
        }
        
        private boolean shouldApplyRecommendation(double confidence, ResourceImpact impact) {
            // Only apply if high confidence and significant impact
            return confidence > 0.8 && 
                   (impact.getCostSavings() > 10.0 || impact.getPerformanceImprovement() > 0.15);
        }
    }
    
    /**
     * Cluster-level autoscaling with intelligent node management
     */
    @Component
    public static class IntelligentClusterAutoscaler {
        
        @Scheduled(fixedRate = 60000) // Every minute
        public void evaluateClusterScaling() {
            try {
                ClusterState clusterState = analyzeClusterState();
                ClusterScalingDecision decision = determineScalingAction(clusterState);
                
                if (decision.shouldScale()) {
                    executeClusterScaling(decision);
                }
                
            } catch (Exception e) {
                log.error("Failed to evaluate cluster scaling", e);
            }
        }
        
        private ClusterState analyzeClusterState() {
            List<Node> nodes = kubernetesClient.nodes().list().getItems();
            List<Pod> pods = kubernetesClient.pods().inAnyNamespace().list().getItems();
            
            // Analyze resource utilization
            ClusterResourceUtilization utilization = calculateClusterUtilization(nodes, pods);
            
            // Find unschedulable pods
            List<Pod> unschedulablePods = findUnschedulablePods(pods);
            
            // Analyze node efficiency
            List<NodeEfficiencyMetrics> nodeEfficiency = analyzeNodeEfficiency(nodes, pods);
            
            // Predict future resource needs
            ResourceForecast forecast = predictResourceNeeds();
            
            return ClusterState.builder()
                .totalNodes(nodes.size())
                .readyNodes(countReadyNodes(nodes))
                .unschedulablePods(unschedulablePods.size())
                .resourceUtilization(utilization)
                .nodeEfficiency(nodeEfficiency)
                .resourceForecast(forecast)
                .build();
        }
        
        private ClusterScalingDecision determineScalingAction(ClusterState state) {
            // Scale up conditions
            if (shouldScaleUp(state)) {
                int nodesToAdd = calculateNodesToAdd(state);
                String nodeType = selectOptimalNodeType(state);
                
                return ClusterScalingDecision.scaleUp(nodesToAdd, nodeType, 
                    buildScaleUpReason(state));
            }
            
            // Scale down conditions
            if (shouldScaleDown(state)) {
                List<Node> nodesToRemove = selectNodesForRemoval(state);
                
                return ClusterScalingDecision.scaleDown(nodesToRemove, 
                    buildScaleDownReason(state));
            }
            
            return ClusterScalingDecision.noScaling("Cluster state is optimal");
        }
        
        private boolean shouldScaleUp(ClusterState state) {
            return state.getUnschedulablePods() > 0 ||
                   state.getResourceUtilization().getCpuUtilization() > 80 ||
                   state.getResourceUtilization().getMemoryUtilization() > 85 ||
                   state.getResourceForecast().predictsPressure(Duration.ofMinutes(10));
        }
        
        private boolean shouldScaleDown(ClusterState state) {
            return state.getResourceUtilization().getCpuUtilization() < 30 &&
                   state.getResourceUtilization().getMemoryUtilization() < 40 &&
                   state.getReadyNodes() > getMinimumNodes() &&
                   hasUnderutilizedNodes(state.getNodeEfficiency()) &&
                   !state.getResourceForecast().predictsPressure(Duration.ofHours(1));
        }
        
        private String selectOptimalNodeType(ClusterState state) {
            // Analyze workload characteristics
            WorkloadAnalysis workloadAnalysis = analyzeWorkloads();
            
            if (workloadAnalysis.isCpuIntensive()) {
                return "c5.xlarge"; // CPU optimized
            } else if (workloadAnalysis.isMemoryIntensive()) {
                return "r5.xlarge"; // Memory optimized
            } else if (workloadAnalysis.requiresGpu()) {
                return "p3.2xlarge"; // GPU instances
            } else {
                return "m5.large"; // General purpose
            }
        }
        
        private void executeClusterScaling(ClusterScalingDecision decision) {
            try {
                if (decision.getAction() == ScalingAction.SCALE_UP) {
                    scaleUpCluster(decision);
                } else if (decision.getAction() == ScalingAction.SCALE_DOWN) {
                    scaleDownCluster(decision);
                }
                
                // Record scaling metrics
                recordClusterScalingEvent(decision);
                
            } catch (Exception e) {
                log.error("Failed to execute cluster scaling", e);
                alertingService.sendAlert(Alert.builder()
                    .title("Cluster Autoscaling Failure")
                    .message(STR."Failed to execute cluster scaling: \{e.getMessage()}")
                    .severity(AlertSeverity.HIGH)
                    .build());
            }
        }
        
        private void scaleUpCluster(ClusterScalingDecision decision) {
            log.info("Scaling up cluster: adding {} nodes of type {}", 
                decision.getNodeCount(), decision.getNodeType());
            
            // Create node group if needed
            NodeGroup nodeGroup = ensureNodeGroupExists(decision.getNodeType());
            
            // Add nodes
            cloudClient.addNodesToGroup(nodeGroup.getName(), decision.getNodeCount());
            
            // Wait for nodes to be ready
            waitForNodesReady(decision.getNodeCount(), Duration.ofMinutes(10));
            
            // Validate scaling success
            validateScalingSuccess(decision);
        }
        
        private void scaleDownCluster(ClusterScalingDecision decision) {
            log.info("Scaling down cluster: removing {} nodes", decision.getNodesToRemove().size());
            
            for (Node node : decision.getNodesToRemove()) {
                try {
                    // Cordon node
                    cordonNode(node);
                    
                    // Drain pods gracefully
                    drainNodeGracefully(node);
                    
                    // Remove from cloud provider
                    cloudClient.removeNode(node.getMetadata().getName());
                    
                } catch (Exception e) {
                    log.error("Failed to remove node: {}", node.getMetadata().getName(), e);
                }
            }
        }
    }
    
    // Supporting classes and data structures
    
    @Data
    @Builder
    public static class ScalingDecision {
        private boolean shouldScale;
        private int currentReplicas;
        private int desiredReplicas;
        private String reason;
        private DeploymentMetrics metrics;
        
        public static ScalingDecision noScaling(int currentReplicas, String reason) {
            return ScalingDecision.builder()
                .shouldScale(false)
                .currentReplicas(currentReplicas)
                .desiredReplicas(currentReplicas)
                .reason(reason)
                .build();
        }
    }
    
    @Data
    @Builder
    public static class DeploymentMetrics {
        private double cpuUtilization;
        private double memoryUtilization;
        private double requestRate;
        private Duration responseTime;
        private double errorRate;
        private int queueLength;
        private double networkThroughput;
        private int connectionCount;
    }
    
    @Data
    @Builder
    public static class ScalingConfig {
        private boolean cpuScalingEnabled;
        private boolean memoryScalingEnabled;
        private boolean requestRateScalingEnabled;
        private boolean responseTimeScalingEnabled;
        private boolean queueLengthScalingEnabled;
        
        private double targetCpuUtilization;
        private double targetMemoryUtilization;
        private double targetRequestsPerReplica;
        private Duration targetResponseTime;
        private int maxQueueLength;
        
        private int minReplicas;
        private int maxReplicas;
        
        private Duration scaleUpCooldown;
        private Duration scaleDownCooldown;
    }
    
    public static class ScalingHistory {
        private final Queue<ScalingEvent> events = new ArrayDeque<>();
        private Instant lastScaleUp;
        private Instant lastScaleDown;
        
        public boolean canScaleUp() {
            return lastScaleUp == null || 
                   Duration.between(lastScaleUp, Instant.now()).toMinutes() >= 3;
        }
        
        public boolean canScaleDown() {
            return lastScaleDown == null || 
                   Duration.between(lastScaleDown, Instant.now()).toMinutes() >= 5;
        }
        
        public boolean isOscillating(int desiredReplicas) {
            if (events.size() < 3) return false;
            
            List<ScalingEvent> recentEvents = events.stream()
                .filter(e -> Duration.between(e.getTimestamp(), Instant.now()).toMinutes() < 10)
                .toList();
            
            // Check for rapid back-and-forth scaling
            return recentEvents.size() >= 3 && 
                   hasAlternatingScalingDirections(recentEvents);
        }
        
        public void recordScalingEvent(ScalingDecision decision) {
            ScalingEvent event = ScalingEvent.builder()
                .timestamp(Instant.now())
                .fromReplicas(decision.getCurrentReplicas())
                .toReplicas(decision.getDesiredReplicas())
                .reason(decision.getReason())
                .build();
            
            events.offer(event);
            
            if (decision.getDesiredReplicas() > decision.getCurrentReplicas()) {
                lastScaleUp = Instant.now();
            } else {
                lastScaleDown = Instant.now();
            }
            
            // Keep only recent events
            while (events.size() > 10) {
                events.poll();
            }
        }
        
        private boolean hasAlternatingScalingDirections(List<ScalingEvent> events) {
            for (int i = 1; i < events.size(); i++) {
                ScalingEvent current = events.get(i);
                ScalingEvent previous = events.get(i - 1);
                
                boolean currentIsScaleUp = current.getToReplicas() > current.getFromReplicas();
                boolean previousIsScaleUp = previous.getToReplicas() > previous.getFromReplicas();
                
                if (currentIsScaleUp == previousIsScaleUp) {
                    return false; // Same direction, not oscillating
                }
            }
            return true; // All events alternate direction
        }
    }
    
    @Data
    @Builder
    public static class ScalingEvent {
        private Instant timestamp;
        private int fromReplicas;
        private int toReplicas;
        private String reason;
    }
}
