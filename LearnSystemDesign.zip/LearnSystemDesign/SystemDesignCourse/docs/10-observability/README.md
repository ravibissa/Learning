# Module 10: Observability and Monitoring

## 👁️ Building Observable Distributed Systems

### 📚 Learning Objectives

By the end of this module, you will:
- Implement comprehensive monitoring with metrics, logs, and traces
- Design observability strategies for microservices architectures
- Build effective dashboards and alerting systems
- Handle distributed tracing across service boundaries
- Implement SLI/SLO monitoring and error budgets
- Design chaos engineering and reliability testing

---

## 🏗️ The Three Pillars of Observability

### 1. Metrics Collection and Monitoring

```java
// Comprehensive metrics implementation
@Component
public class ObservabilityService {
    
    /**
     * Custom metrics collection for business and technical metrics
     */
    @Component
    public static class MetricsCollector {
        
        private final MeterRegistry meterRegistry;
        private final DistributionSummary requestSizeDistribution;
        private final Timer requestDurationTimer;
        private final Counter requestCounter;
        private final Counter errorCounter;
        private final Gauge activeUsersGauge;
        private final Counter businessEventCounter;
        
        public MetricsCollector(MeterRegistry meterRegistry) {
            this.meterRegistry = meterRegistry;
            
            // Technical metrics
            this.requestSizeDistribution = DistributionSummary.builder("http.request.size")
                .description("HTTP request size distribution")
                .baseUnit("bytes")
                .publishPercentiles(0.5, 0.75, 0.95, 0.99)
                .minimumExpectedValue(1.0)
                .maximumExpectedValue(10000.0)
                .register(meterRegistry);
            
            this.requestDurationTimer = Timer.builder("http.request.duration")
                .description("HTTP request duration")
                .publishPercentiles(0.5, 0.75, 0.95, 0.99)
                .sla(Duration.ofMillis(100), Duration.ofMillis(500), Duration.ofSeconds(1))
                .register(meterRegistry);
            
            this.requestCounter = Counter.builder("http.requests.total")
                .description("Total HTTP requests")
                .register(meterRegistry);
            
            this.errorCounter = Counter.builder("http.errors.total")
                .description("Total HTTP errors")
                .register(meterRegistry);
            
            this.activeUsersGauge = Gauge.builder("users.active.current")
                .description("Currently active users")
                .register(meterRegistry, this, MetricsCollector::getActiveUserCount);
            
            // Business metrics
            this.businessEventCounter = Counter.builder("business.events.total")
                .description("Total business events")
                .register(meterRegistry);
        }
        
        public void recordHttpRequest(String method, String endpoint, int statusCode, 
                                    Duration duration, long requestSize) {
            
            Tags tags = Tags.of(
                "method", method,
                "endpoint", endpoint,
                "status", String.valueOf(statusCode),
                "status_class", getStatusClass(statusCode)
            );
            
            requestCounter.increment(tags);
            requestDurationTimer.record(duration, tags);
            requestSizeDistribution.record(requestSize, tags);
            
            if (statusCode >= 400) {
                errorCounter.increment(tags.and("error_type", getErrorType(statusCode)));
            }
        }
        
        public void recordBusinessEvent(String eventType, String userId, Map<String, String> attributes) {
            Tags.Builder tagsBuilder = Tags.of("event_type", eventType)
                .and("user_type", getUserType(userId));
            
            // Add custom attributes as tags (be careful with cardinality)
            for (Map.Entry<String, String> entry : attributes.entrySet()) {
                if (isLowCardinalityAttribute(entry.getKey())) {
                    tagsBuilder = tagsBuilder.and(entry.getKey(), entry.getValue());
                }
            }
            
            businessEventCounter.increment(tagsBuilder);
        }
        
        public void recordCustomMetric(String metricName, double value, Tags tags) {
            DistributionSummary.builder(metricName)
                .register(meterRegistry)
                .record(value, tags);
        }
        
        private String getStatusClass(int statusCode) {
            return switch (statusCode / 100) {
                case 2 -> "2xx";
                case 3 -> "3xx";
                case 4 -> "4xx";
                case 5 -> "5xx";
                default -> "unknown";
            };
        }
        
        private String getErrorType(int statusCode) {
            return switch (statusCode) {
                case 400 -> "bad_request";
                case 401 -> "unauthorized";
                case 403 -> "forbidden";
                case 404 -> "not_found";
                case 429 -> "rate_limited";
                case 500 -> "internal_error";
                case 502 -> "bad_gateway";
                case 503 -> "service_unavailable";
                case 504 -> "gateway_timeout";
                default -> "other";
            };
        }
        
        private double getActiveUserCount() {
            // Implementation to get current active user count
            return userSessionService.getActiveUserCount();
        }
        
        private String getUserType(String userId) {
            // Determine user type for segmentation
            return userService.getUserType(userId);
        }
        
        private boolean isLowCardinalityAttribute(String attributeName) {
            // Prevent high cardinality metrics that can overwhelm the system
            Set<String> lowCardinalityAttributes = Set.of(
                "region", "user_tier", "subscription_type", "experiment_group"
            );
            return lowCardinalityAttributes.contains(attributeName);
        }
    }
    
    /**
     * SLI/SLO monitoring implementation
     */
    @Component
    public static class SLIMonitor {
        
        @Autowired
        private MeterRegistry meterRegistry;
        
        @Autowired
        private AlertManager alertManager;
        
        private final Map<String, SLITracker> sliTrackers = new ConcurrentHashMap<>();
        
        @PostConstruct
        public void initializeSLIs() {
            // Define SLIs for the service
            defineSLI("api_availability", SLIDefinition.builder()
                .name("API Availability")
                .description("Percentage of successful API requests")
                .type(SLIType.AVAILABILITY)
                .target(0.999) // 99.9% availability
                .timeWindow(Duration.ofDays(30))
                .build());
            
            defineSLI("api_latency", SLIDefinition.builder()
                .name("API Latency")
                .description("95th percentile API response time")
                .type(SLIType.LATENCY)
                .target(500) // 500ms P95
                .timeWindow(Duration.ofDays(30))
                .build());
            
            defineSLI("data_freshness", SLIDefinition.builder()
                .name("Data Freshness")
                .description("Percentage of data updated within acceptable time")
                .type(SLIType.FRESHNESS)
                .target(0.95) // 95% of data fresh
                .timeWindow(Duration.ofHours(24))
                .build());
        }
        
        public void defineSLI(String sliId, SLIDefinition definition) {
            SLITracker tracker = new SLITracker(sliId, definition, meterRegistry);
            sliTrackers.put(sliId, tracker);
            
            log.info("Defined SLI: {} with target: {}", definition.getName(), definition.getTarget());
        }
        
        public void recordSLIEvent(String sliId, boolean successful, double value) {
            SLITracker tracker = sliTrackers.get(sliId);
            if (tracker != null) {
                tracker.recordEvent(successful, value);
                
                // Check if SLO is violated
                if (tracker.isSLOViolated()) {
                    handleSLOViolation(sliId, tracker);
                }
            }
        }
        
        private void handleSLOViolation(String sliId, SLITracker tracker) {
            SLOViolation violation = SLOViolation.builder()
                .sliId(sliId)
                .sliName(tracker.getDefinition().getName())
                .currentValue(tracker.getCurrentValue())
                .targetValue(tracker.getDefinition().getTarget())
                .severity(calculateSeverity(tracker))
                .timestamp(Instant.now())
                .build();
            
            alertManager.sendSLOViolationAlert(violation);
            
            log.warn("SLO violation detected for {}: current={}, target={}", 
                sliId, tracker.getCurrentValue(), tracker.getDefinition().getTarget());
        }
        
        private AlertSeverity calculateSeverity(SLITracker tracker) {
            double currentValue = tracker.getCurrentValue();
            double target = tracker.getDefinition().getTarget();
            double deviation = Math.abs(currentValue - target) / target;
            
            if (deviation > 0.1) return AlertSeverity.CRITICAL;
            if (deviation > 0.05) return AlertSeverity.HIGH;
            if (deviation > 0.02) return AlertSeverity.MEDIUM;
            return AlertSeverity.LOW;
        }
        
        @Scheduled(fixedRate = 300000) // Every 5 minutes
        public void evaluateErrorBudgets() {
            for (SLITracker tracker : sliTrackers.values()) {
                ErrorBudget budget = tracker.getErrorBudget();
                
                if (budget.getBurnRate() > 10) { // High burn rate
                    alertManager.sendErrorBudgetAlert(ErrorBudgetAlert.builder()
                        .sliId(tracker.getSliId())
                        .burnRate(budget.getBurnRate())
                        .remainingBudget(budget.getRemainingBudget())
                        .severity(AlertSeverity.HIGH)
                        .build());
                } else if (budget.getRemainingBudget() < 0.1) { // Less than 10% budget remaining
                    alertManager.sendErrorBudgetAlert(ErrorBudgetAlert.builder()
                        .sliId(tracker.getSliId())
                        .burnRate(budget.getBurnRate())
                        .remainingBudget(budget.getRemainingBudget())
                        .severity(AlertSeverity.MEDIUM)
                        .build());
                }
            }
        }
    }
    
    /**
     * Application Performance Monitoring (APM)
     */
    @Component
    public static class APMMonitor {
        
        @Autowired
        private MeterRegistry meterRegistry;
        
        @Autowired
        private Tracer tracer;
        
        private final Timer dbQueryTimer;
        private final Counter dbQueryCounter;
        private final Timer externalApiTimer;
        private final Counter externalApiCounter;
        private final Gauge jvmMemoryGauge;
        private final Gauge jvmThreadsGauge;
        
        public APMMonitor(MeterRegistry meterRegistry) {
            this.meterRegistry = meterRegistry;
            
            this.dbQueryTimer = Timer.builder("db.query.duration")
                .description("Database query execution time")
                .publishPercentiles(0.5, 0.95, 0.99)
                .register(meterRegistry);
            
            this.dbQueryCounter = Counter.builder("db.query.total")
                .description("Total database queries")
                .register(meterRegistry);
            
            this.externalApiTimer = Timer.builder("external.api.duration")
                .description("External API call duration")
                .publishPercentiles(0.5, 0.95, 0.99)
                .register(meterRegistry);
            
            this.externalApiCounter = Counter.builder("external.api.total")
                .description("Total external API calls")
                .register(meterRegistry);
            
            this.jvmMemoryGauge = Gauge.builder("jvm.memory.used")
                .description("JVM memory usage")
                .register(meterRegistry, this, APMMonitor::getJvmMemoryUsage);
            
            this.jvmThreadsGauge = Gauge.builder("jvm.threads.active")
                .description("Active JVM threads")
                .register(meterRegistry, this, APMMonitor::getActiveThreadCount);
        }
        
        @EventListener
        public void handleDatabaseQuery(DatabaseQueryEvent event) {
            Tags tags = Tags.of(
                "query_type", event.getQueryType(),
                "table", event.getTableName(),
                "status", event.isSuccessful() ? "success" : "error"
            );
            
            dbQueryCounter.increment(tags);
            dbQueryTimer.record(event.getDuration(), tags);
            
            // Add database query span
            Span span = tracer.nextSpan()
                .name("db.query")
                .tag("db.type", "postgresql")
                .tag("db.statement", event.getSanitizedQuery())
                .tag("db.table", event.getTableName())
                .start();
            
            try (Tracer.SpanInScope ws = tracer.withSpanInScope(span)) {
                if (!event.isSuccessful()) {
                    span.tag("error", true);
                    span.tag("error.message", event.getErrorMessage());
                }
            } finally {
                span.end();
            }
        }
        
        @EventListener
        public void handleExternalApiCall(ExternalApiCallEvent event) {
            Tags tags = Tags.of(
                "service", event.getServiceName(),
                "endpoint", event.getEndpoint(),
                "method", event.getHttpMethod(),
                "status_code", String.valueOf(event.getStatusCode())
            );
            
            externalApiCounter.increment(tags);
            externalApiTimer.record(event.getDuration(), tags);
            
            // Add external API span
            Span span = tracer.nextSpan()
                .name("http.client")
                .tag("http.method", event.getHttpMethod())
                .tag("http.url", event.getEndpoint())
                .tag("http.status_code", String.valueOf(event.getStatusCode()))
                .tag("service.name", event.getServiceName())
                .start();
            
            try (Tracer.SpanInScope ws = tracer.withSpanInScope(span)) {
                if (event.getStatusCode() >= 400) {
                    span.tag("error", true);
                    span.tag("error.message", event.getErrorMessage());
                }
            } finally {
                span.end();
            }
        }
        
        private double getJvmMemoryUsage() {
            MemoryMXBean memoryBean = ManagementFactory.getMemoryMXBean();
            return memoryBean.getHeapMemoryUsage().getUsed();
        }
        
        private double getActiveThreadCount() {
            ThreadMXBean threadBean = ManagementFactory.getThreadMXBean();
            return threadBean.getThreadCount();
        }
        
        @Scheduled(fixedRate = 60000) // Every minute
        public void collectSystemMetrics() {
            // CPU usage
            OperatingSystemMXBean osBean = ManagementFactory.getOperatingSystemMXBean();
            double cpuUsage = osBean.getProcessCpuLoad();
            
            Gauge.builder("system.cpu.usage")
                .register(meterRegistry, cpuUsage, value -> value);
            
            // Memory usage
            MemoryMXBean memoryBean = ManagementFactory.getMemoryMXBean();
            MemoryUsage heapUsage = memoryBean.getHeapMemoryUsage();
            
            Gauge.builder("jvm.memory.heap.used")
                .register(meterRegistry, heapUsage.getUsed(), value -> value);
            
            Gauge.builder("jvm.memory.heap.max")
                .register(meterRegistry, heapUsage.getMax(), value -> value);
            
            // Garbage collection
            for (GarbageCollectorMXBean gcBean : ManagementFactory.getGarbageCollectorMXBeans()) {
                Timer.builder("jvm.gc.duration")
                    .tag("gc", gcBean.getName())
                    .register(meterRegistry)
                    .record(gcBean.getCollectionTime(), TimeUnit.MILLISECONDS);
            }
        }
    }
}
```

### 2. Distributed Tracing Implementation

```java
// Comprehensive distributed tracing
@Component
public class DistributedTracingService {
    
    @Autowired
    private Tracer tracer;
    
    @Autowired
    private TracingMetrics tracingMetrics;
    
    /**
     * Trace context propagation across service boundaries
     */
    @Component
    public static class TraceContextPropagation {
        
        @Autowired
        private Tracer tracer;
        
        @Autowired
        private WebClient.Builder webClientBuilder;
        
        // Automatic trace propagation for HTTP clients
        @Bean
        public WebClient tracedWebClient() {
            return webClientBuilder
                .filter(this::addTracingHeaders)
                .build();
        }
        
        private Mono<ClientResponse> addTracingHeaders(ClientRequest request, ExchangeFunction next) {
            Span currentSpan = tracer.currentSpan();
            
            if (currentSpan != null) {
                TraceContext traceContext = currentSpan.context();
                
                ClientRequest.Builder requestBuilder = ClientRequest.from(request)
                    .header("X-Trace-ID", traceContext.traceId())
                    .header("X-Span-ID", traceContext.spanId())
                    .header("X-Parent-Span-ID", traceContext.parentId());
                
                // Add baggage items
                Map<String, String> baggage = currentSpan.getAllBaggage();
                for (Map.Entry<String, String> entry : baggage.entrySet()) {
                    requestBuilder.header("X-Baggage-" + entry.getKey(), entry.getValue());
                }
                
                return next.exchange(requestBuilder.build());
            }
            
            return next.exchange(request);
        }
        
        // Manual trace context extraction for message queues
        public Span createSpanFromMessage(Map<String, String> messageHeaders, String operationName) {
            SpanBuilder spanBuilder = tracer.nextSpan().name(operationName);
            
            String traceId = messageHeaders.get("X-Trace-ID");
            String spanId = messageHeaders.get("X-Span-ID");
            String parentSpanId = messageHeaders.get("X-Parent-Span-ID");
            
            if (traceId != null && spanId != null) {
                // Continue existing trace
                TraceContext.Builder contextBuilder = TraceContext.newBuilder()
                    .traceId(Long.parseUnsignedLong(traceId, 16))
                    .spanId(Long.parseUnsignedLong(spanId, 16));
                
                if (parentSpanId != null) {
                    contextBuilder.parentId(Long.parseUnsignedLong(parentSpanId, 16));
                }
                
                spanBuilder.setParent(contextBuilder.build());
            }
            
            // Add baggage from headers
            messageHeaders.entrySet().stream()
                .filter(entry -> entry.getKey().startsWith("X-Baggage-"))
                .forEach(entry -> {
                    String baggageKey = entry.getKey().substring("X-Baggage-".length());
                    spanBuilder.tag("baggage." + baggageKey, entry.getValue());
                });
            
            return spanBuilder.start();
        }
        
        // Add trace context to outgoing messages
        public Map<String, String> addTraceContextToMessage(Map<String, String> messageHeaders) {
            Span currentSpan = tracer.currentSpan();
            
            if (currentSpan != null) {
                TraceContext context = currentSpan.context();
                
                messageHeaders.put("X-Trace-ID", context.traceId());
                messageHeaders.put("X-Span-ID", context.spanId());
                if (context.parentId() != null) {
                    messageHeaders.put("X-Parent-Span-ID", context.parentId());
                }
                
                // Add baggage
                Map<String, String> baggage = currentSpan.getAllBaggage();
                for (Map.Entry<String, String> entry : baggage.entrySet()) {
                    messageHeaders.put("X-Baggage-" + entry.getKey(), entry.getValue());
                }
            }
            
            return messageHeaders;
        }
    }
    
    /**
     * Business transaction tracing
     */
    @Component
    public static class BusinessTransactionTracer {
        
        @Autowired
        private Tracer tracer;
        
        @NewSpan("user-registration")
        public UserRegistrationResult traceUserRegistration(@SpanTag("user.email") String email,
                                                           @SpanTag("user.source") String source) {
            
            Span span = tracer.currentSpan();
            span.tag("business.transaction", "user-registration");
            span.tag("user.email.domain", extractDomain(email));
            
            try {
                // Step 1: Validate user data
                Span validationSpan = tracer.nextSpan()
                    .name("user-validation")
                    .tag("validation.type", "email-and-profile")
                    .start();
                
                try (Tracer.SpanInScope ws = tracer.withSpanInScope(validationSpan)) {
                    validateUserData(email);
                    validationSpan.tag("validation.result", "success");
                } catch (Exception e) {
                    validationSpan.tag("validation.result", "failure");
                    validationSpan.tag("error.message", e.getMessage());
                    throw e;
                } finally {
                    validationSpan.end();
                }
                
                // Step 2: Create user account
                Span accountCreationSpan = tracer.nextSpan()
                    .name("account-creation")
                    .tag("account.type", "standard")
                    .start();
                
                String userId;
                try (Tracer.SpanInScope ws = tracer.withSpanInScope(accountCreationSpan)) {
                    userId = createUserAccount(email, source);
                    accountCreationSpan.tag("account.creation.result", "success");
                    accountCreationSpan.tag("user.id", userId);
                } catch (Exception e) {
                    accountCreationSpan.tag("account.creation.result", "failure");
                    accountCreationSpan.tag("error.message", e.getMessage());
                    throw e;
                } finally {
                    accountCreationSpan.end();
                }
                
                // Step 3: Send welcome email
                Span emailSpan = tracer.nextSpan()
                    .name("welcome-email")
                    .tag("email.type", "welcome")
                    .tag("email.provider", "sendgrid")
                    .start();
                
                try (Tracer.SpanInScope ws = tracer.withSpanInScope(emailSpan)) {
                    sendWelcomeEmail(email, userId);
                    emailSpan.tag("email.sent", true);
                } catch (Exception e) {
                    emailSpan.tag("email.sent", false);
                    emailSpan.tag("error.message", e.getMessage());
                    // Don't fail registration if email fails
                    log.warn("Failed to send welcome email", e);
                } finally {
                    emailSpan.end();
                }
                
                // Step 4: Record analytics event
                recordAnalyticsEvent("user_registered", userId, Map.of(
                    "source", source,
                    "email_domain", extractDomain(email)
                ));
                
                span.tag("registration.result", "success");
                span.tag("user.id", userId);
                
                return UserRegistrationResult.success(userId);
                
            } catch (Exception e) {
                span.tag("registration.result", "failure");
                span.tag("error.type", e.getClass().getSimpleName());
                span.tag("error.message", e.getMessage());
                
                return UserRegistrationResult.failure(e.getMessage());
            }
        }
        
        @NewSpan("order-processing")
        public OrderProcessingResult traceOrderProcessing(@SpanTag("order.id") String orderId,
                                                         @SpanTag("user.id") String userId) {
            
            Span span = tracer.currentSpan();
            span.tag("business.transaction", "order-processing");
            
            // Add user context to baggage for cross-service correlation
            span.setBaggageItem("user.id", userId);
            span.setBaggageItem("order.id", orderId);
            
            try {
                OrderProcessingResult result = processOrder(orderId, userId);
                
                span.tag("order.result", result.isSuccess() ? "success" : "failure");
                span.tag("order.total", String.valueOf(result.getTotalAmount()));
                span.tag("order.items", String.valueOf(result.getItemCount()));
                
                if (!result.isSuccess()) {
                    span.tag("error.message", result.getErrorMessage());
                }
                
                return result;
                
            } catch (Exception e) {
                span.tag("order.result", "error");
                span.tag("error.type", e.getClass().getSimpleName());
                span.tag("error.message", e.getMessage());
                
                throw e;
            }
        }
        
        // Cross-service correlation using baggage
        @EventListener
        public void handlePaymentEvent(PaymentProcessedEvent event) {
            // Extract context from baggage
            Span currentSpan = tracer.currentSpan();
            String orderId = currentSpan.getBaggageItem("order.id");
            String userId = currentSpan.getBaggageItem("user.id");
            
            Span paymentSpan = tracer.nextSpan()
                .name("payment-notification")
                .tag("payment.id", event.getPaymentId())
                .tag("payment.amount", String.valueOf(event.getAmount()))
                .tag("order.id", orderId)
                .tag("user.id", userId)
                .start();
            
            try (Tracer.SpanInScope ws = tracer.withSpanInScope(paymentSpan)) {
                // Process payment notification
                processPaymentNotification(event);
            } finally {
                paymentSpan.end();
            }
        }
        
        private String extractDomain(String email) {
            return email.substring(email.indexOf('@') + 1);
        }
    }
    
    /**
     * Performance profiling with traces
     */
    @Component
    public static class PerformanceProfiler {
        
        @Autowired
        private Tracer tracer;
        
        @Autowired
        private MeterRegistry meterRegistry;
        
        public void profileDatabaseOperation(String operation, Runnable dbOperation) {
            Span span = tracer.nextSpan()
                .name("db.operation.profile")
                .tag("db.operation", operation)
                .start();
            
            Timer.Sample sample = Timer.start(meterRegistry);
            
            try (Tracer.SpanInScope ws = tracer.withSpanInScope(span)) {
                // Measure time
                Instant start = Instant.now();
                
                dbOperation.run();
                
                Duration duration = Duration.between(start, Instant.now());
                
                // Add performance annotations
                span.tag("duration.ms", String.valueOf(duration.toMillis()));
                
                if (duration.toMillis() > 1000) {
                    span.tag("performance.slow", true);
                    span.annotate("slow_query_detected");
                }
                
                if (duration.toMillis() > 5000) {
                    span.tag("performance.very_slow", true);
                    span.annotate("very_slow_query_detected");
                }
                
            } finally {
                sample.stop(Timer.builder("db.operation.duration")
                    .tag("operation", operation)
                    .register(meterRegistry));
                
                span.end();
            }
        }
        
        @Async
        public void analyzeTracePerformance(String traceId) {
            // Analyze completed trace for performance issues
            Trace trace = getTraceById(traceId);
            
            if (trace != null) {
                PerformanceAnalysis analysis = analyzeTrace(trace);
                
                if (analysis.hasPerformanceIssues()) {
                    // Send performance alert
                    alertManager.sendPerformanceAlert(PerformanceAlert.builder()
                        .traceId(traceId)
                        .totalDuration(analysis.getTotalDuration())
                        .slowestSpan(analysis.getSlowestSpan())
                        .bottlenecks(analysis.getBottlenecks())
                        .severity(analysis.getSeverity())
                        .build());
                }
            }
        }
        
        private PerformanceAnalysis analyzeTrace(Trace trace) {
            List<Span> spans = trace.getSpans();
            
            // Find slowest span
            Span slowestSpan = spans.stream()
                .max(Comparator.comparing(Span::getDuration))
                .orElse(null);
            
            // Identify bottlenecks
            List<String> bottlenecks = new ArrayList<>();
            
            for (Span span : spans) {
                if (span.getDuration().toMillis() > 1000) {
                    bottlenecks.add(STR."\{span.getOperationName()}: \{span.getDuration().toMillis()}ms");
                }
            }
            
            // Calculate severity
            Duration totalDuration = trace.getDuration();
            PerformanceSeverity severity = PerformanceSeverity.LOW;
            
            if (totalDuration.toMillis() > 10000) {
                severity = PerformanceSeverity.CRITICAL;
            } else if (totalDuration.toMillis() > 5000) {
                severity = PerformanceSeverity.HIGH;
            } else if (totalDuration.toMillis() > 2000) {
                severity = PerformanceSeverity.MEDIUM;
            }
            
            return PerformanceAnalysis.builder()
                .traceId(trace.getTraceId())
                .totalDuration(totalDuration)
                .slowestSpan(slowestSpan)
                .bottlenecks(bottlenecks)
                .severity(severity)
                .hasPerformanceIssues(!bottlenecks.isEmpty() || totalDuration.toMillis() > 2000)
                .build();
        }
    }
}
```

### 3. Structured Logging Implementation

```java
// Comprehensive structured logging
@Component
public class StructuredLoggingService {
    
    private final Logger log = LoggerFactory.getLogger(StructuredLoggingService.class);
    private final ObjectMapper objectMapper;
    
    public StructuredLoggingService(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }
    
    /**
     * Business event logging
     */
    public void logBusinessEvent(String eventType, String userId, Map<String, Object> eventData) {
        try {
            BusinessEventLog eventLog = BusinessEventLog.builder()
                .timestamp(Instant.now())
                .eventType(eventType)
                .userId(userId)
                .correlationId(MDC.get("correlationId"))
                .traceId(MDC.get("traceId"))
                .eventData(eventData)
                .source("business-events")
                .build();
            
            String jsonLog = objectMapper.writeValueAsString(eventLog);
            log.info("BUSINESS_EVENT: {}", jsonLog);
            
        } catch (Exception e) {
            log.error("Failed to log business event", e);
        }
    }
    
    /**
     * Security event logging
     */
    public void logSecurityEvent(SecurityEventType eventType, String userId, 
                                String ipAddress, Map<String, Object> context) {
        try {
            SecurityEventLog securityLog = SecurityEventLog.builder()
                .timestamp(Instant.now())
                .eventType(eventType)
                .userId(userId)
                .ipAddress(ipAddress)
                .userAgent(context.get("userAgent"))
                .correlationId(MDC.get("correlationId"))
                .severity(determineSeverity(eventType))
                .context(context)
                .source("security-events")
                .build();
            
            String jsonLog = objectMapper.writeValueAsString(securityLog);
            
            if (securityLog.getSeverity() == SecuritySeverity.HIGH || 
                securityLog.getSeverity() == SecuritySeverity.CRITICAL) {
                log.warn("SECURITY_EVENT: {}", jsonLog);
            } else {
                log.info("SECURITY_EVENT: {}", jsonLog);
            }
            
        } catch (Exception e) {
            log.error("Failed to log security event", e);
        }
    }
    
    /**
     * Performance event logging
     */
    public void logPerformanceEvent(String operation, Duration duration, 
                                  Map<String, Object> performanceData) {
        try {
            PerformanceEventLog perfLog = PerformanceEventLog.builder()
                .timestamp(Instant.now())
                .operation(operation)
                .durationMs(duration.toMillis())
                .correlationId(MDC.get("correlationId"))
                .traceId(MDC.get("traceId"))
                .performanceData(performanceData)
                .threshold(getPerformanceThreshold(operation))
                .isSlowOperation(duration.toMillis() > getPerformanceThreshold(operation))
                .source("performance-events")
                .build();
            
            String jsonLog = objectMapper.writeValueAsString(perfLog);
            
            if (perfLog.isSlowOperation()) {
                log.warn("PERFORMANCE_EVENT: {}", jsonLog);
            } else {
                log.debug("PERFORMANCE_EVENT: {}", jsonLog);
            }
            
        } catch (Exception e) {
            log.error("Failed to log performance event", e);
        }
    }
    
    /**
     * Error logging with context
     */
    public void logError(String operation, Exception error, Map<String, Object> context) {
        try {
            ErrorEventLog errorLog = ErrorEventLog.builder()
                .timestamp(Instant.now())
                .operation(operation)
                .errorType(error.getClass().getSimpleName())
                .errorMessage(error.getMessage())
                .stackTrace(getStackTrace(error))
                .correlationId(MDC.get("correlationId"))
                .traceId(MDC.get("traceId"))
                .context(context)
                .severity(determineErrorSeverity(error))
                .source("error-events")
                .build();
            
            String jsonLog = objectMapper.writeValueAsString(errorLog);
            log.error("ERROR_EVENT: {}", jsonLog);
            
        } catch (Exception e) {
            log.error("Failed to log error event", e);
        }
    }
    
    /**
     * Audit logging for compliance
     */
    public void logAuditEvent(String action, String userId, String resourceType, 
                            String resourceId, Map<String, Object> changes) {
        try {
            AuditEventLog auditLog = AuditEventLog.builder()
                .timestamp(Instant.now())
                .action(action)
                .userId(userId)
                .resourceType(resourceType)
                .resourceId(resourceId)
                .changes(changes)
                .correlationId(MDC.get("correlationId"))
                .ipAddress(getClientIpAddress())
                .userAgent(getUserAgent())
                .source("audit-events")
                .build();
            
            String jsonLog = objectMapper.writeValueAsString(auditLog);
            log.info("AUDIT_EVENT: {}", jsonLog);
            
        } catch (Exception e) {
            log.error("Failed to log audit event", e);
        }
    }
    
    private SecuritySeverity determineSeverity(SecurityEventType eventType) {
        return switch (eventType) {
            case LOGIN_SUCCESS -> SecuritySeverity.LOW;
            case LOGIN_FAILURE -> SecuritySeverity.MEDIUM;
            case MULTIPLE_LOGIN_FAILURES -> SecuritySeverity.HIGH;
            case UNAUTHORIZED_ACCESS_ATTEMPT -> SecuritySeverity.HIGH;
            case PRIVILEGE_ESCALATION -> SecuritySeverity.CRITICAL;
            case DATA_BREACH_SUSPECTED -> SecuritySeverity.CRITICAL;
        };
    }
    
    private ErrorSeverity determineErrorSeverity(Exception error) {
        if (error instanceof SecurityException || error instanceof DataIntegrityException) {
            return ErrorSeverity.CRITICAL;
        } else if (error instanceof ServiceUnavailableException || error instanceof TimeoutException) {
            return ErrorSeverity.HIGH;
        } else if (error instanceof ValidationException || error instanceof IllegalArgumentException) {
            return ErrorSeverity.MEDIUM;
        } else {
            return ErrorSeverity.LOW;
        }
    }
    
    private long getPerformanceThreshold(String operation) {
        // Define performance thresholds for different operations
        return switch (operation.toLowerCase()) {
            case "db_query" -> 100L; // 100ms
            case "api_call" -> 500L; // 500ms
            case "file_upload" -> 5000L; // 5 seconds
            case "report_generation" -> 30000L; // 30 seconds
            default -> 1000L; // 1 second default
        };
    }
    
    private String getStackTrace(Exception error) {
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        error.printStackTrace(pw);
        return sw.toString();
    }
    
    private String getClientIpAddress() {
        // Extract client IP from request context
        return RequestContextHolder.currentRequestAttributes() != null ? 
            ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes())
                .getRequest().getRemoteAddr() : "unknown";
    }
    
    private String getUserAgent() {
        // Extract User-Agent from request context
        return RequestContextHolder.currentRequestAttributes() != null ? 
            ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes())
                .getRequest().getHeader("User-Agent") : "unknown";
    }
}
```

---

## 🎯 Interview Focus Areas

### Key Observability Questions

**Q: How do you monitor a distributed system?**
- **Three pillars**: Metrics, logs, and distributed traces
- **SLI/SLO monitoring** with error budgets
- **Correlation** between metrics, logs, and traces
- **Real-time alerting** with proper escalation

**Q: How do you implement distributed tracing?**
- **Trace context propagation** across service boundaries
- **Correlation IDs** for request tracking
- **Sampling strategies** to manage overhead
- **Performance analysis** from trace data

**Q: How do you design effective alerts?**
- **SLO-based alerting** instead of threshold-based
- **Actionable alerts** with clear remediation steps
- **Alert fatigue prevention** with proper filtering
- **Escalation policies** for critical issues

**Q: How do you handle observability at scale?**
- **Sampling and aggregation** for high-volume systems
- **Cost optimization** for telemetry data
- **Data retention policies** based on value
- **Performance impact** of observability tools

---

## 🚀 Next Steps

1. **Complete the hands-on exercises** in the exercises folder
2. **Implement SLI/SLO monitoring** for your services
3. **Set up distributed tracing** across your microservices
4. **Design effective dashboards** and alerting
5. **Move to Module 11: Security**

The observability module provides the foundation for building systems that are transparent, debuggable, and maintainable at scale.
