# Module 8: Data Consistency Patterns

## 🔄 Managing Consistency in Distributed Systems

### 📚 Learning Objectives

By the end of this module, you will:
- Understand different consistency models and their trade-offs
- Implement eventual consistency patterns in distributed systems
- Design conflict resolution strategies for concurrent updates
- Handle data synchronization across multiple services
- Implement CQRS and Event Sourcing patterns
- Design systems with strong vs eventual consistency

---

## 🏗️ Consistency Models and CAP Theorem

### 1. Understanding Consistency Trade-offs

```java
// Consistency model demonstration with practical examples
@Service
public class ConsistencyModelsDemo {
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private CacheService cacheService;
    
    @Autowired
    private EventPublisher eventPublisher;
    
    /**
     * Strong Consistency - Immediate consistency across all replicas
     * Use case: Financial transactions, critical user data
     */
    @Transactional(isolation = Isolation.SERIALIZABLE)
    public UserAccount updateAccountBalanceStrongly(String userId, BigDecimal amount) {
        // Read with exclusive lock
        UserAccount account = userRepository.findByIdForUpdate(userId)
            .orElseThrow(() -> new AccountNotFoundException(userId));
        
        // Validate business rules
        if (account.getBalance().add(amount).compareTo(BigDecimal.ZERO) < 0) {
            throw new InsufficientFundsException("Insufficient balance");
        }
        
        // Update balance
        account.setBalance(account.getBalance().add(amount));
        account.setLastModified(Instant.now());
        account.setVersion(account.getVersion() + 1);
        
        // Save with version check (optimistic locking)
        UserAccount savedAccount = userRepository.save(account);
        
        // Invalidate cache immediately for strong consistency
        cacheService.evict("user:account:" + userId);
        
        // Synchronously update all read replicas
        replicationService.replicateToAllNodes(savedAccount);
        
        return savedAccount;
    }
    
    /**
     * Eventual Consistency - Accepts temporary inconsistency for performance
     * Use case: User profiles, product catalogs, social media updates
     */
    public UserProfile updateUserProfileEventually(String userId, UserProfileUpdate update) {
        // Update primary database
        UserProfile profile = userRepository.findById(userId)
            .orElseThrow(() -> new UserNotFoundException(userId));
        
        profile.setDisplayName(update.getDisplayName());
        profile.setBio(update.getBio());
        profile.setLastModified(Instant.now());
        
        UserProfile savedProfile = userRepository.save(profile);
        
        // Update cache asynchronously
        CompletableFuture.runAsync(() -> {
            try {
                cacheService.put("user:profile:" + userId, savedProfile, Duration.ofHours(1));
            } catch (Exception e) {
                log.warn("Failed to update cache for user profile: {}", userId, e);
            }
        });
        
        // Publish event for eventual consistency across services
        ProfileUpdatedEvent event = ProfileUpdatedEvent.builder()
            .userId(userId)
            .displayName(savedProfile.getDisplayName())
            .bio(savedProfile.getBio())
            .timestamp(Instant.now())
            .build();
        
        eventPublisher.publishAsync(event);
        
        return savedProfile;
    }
    
    /**
     * Read Your Writes Consistency - User sees their own writes immediately
     * Use case: User-generated content, personal settings
     */
    public void updateUserPreferencesWithReadYourWrites(String userId, UserPreferences preferences) {
        // Update master database
        UserPreferences updated = preferencesRepository.save(
            UserPreferences.builder()
                .userId(userId)
                .preferences(preferences.getPreferences())
                .lastModified(Instant.now())
                .build()
        );
        
        // Store in user-specific cache for immediate read-your-writes
        String userCacheKey = STR."user:\{userId}:preferences";
        cacheService.put(userCacheKey, updated, Duration.ofMinutes(30));
        
        // Mark user session with latest timestamp
        sessionService.updateUserLastWrite(userId, Instant.now());
        
        // Asynchronously propagate to read replicas
        CompletableFuture.runAsync(() -> {
            try {
                replicationService.replicateToReadReplicas(updated);
            } catch (Exception e) {
                log.warn("Failed to replicate user preferences: {}", userId, e);
            }
        });
    }
    
    /**
     * Monotonic Read Consistency - Reads never go backwards in time
     * Use case: Time-series data, audit logs, message feeds
     */
    public List<Message> getUserMessagesWithMonotonicReads(String userId, 
                                                         Optional<Instant> lastReadTimestamp) {
        
        // Get user's last read timestamp
        Instant userLastRead = lastReadTimestamp.orElseGet(() -> 
            sessionService.getUserLastReadTimestamp(userId));
        
        // Ensure we read from a replica that has data at least as recent as user's last read
        DatabaseReplica replica = replicationService.findReplicaWithTimestamp(userLastRead);
        
        List<Message> messages = messageRepository.findByUserIdAndTimestampAfter(
            userId, userLastRead, replica);
        
        // Update user's last read timestamp
        if (!messages.isEmpty()) {
            Instant latestMessageTimestamp = messages.stream()
                .map(Message::getTimestamp)
                .max(Instant::compareTo)
                .orElse(userLastRead);
            
            sessionService.updateUserLastRead(userId, latestMessageTimestamp);
        }
        
        return messages;
    }
    
    /**
     * Causal Consistency - Causally related writes are seen in order
     * Use case: Comment threads, collaborative editing, social interactions
     */
    public Comment addCommentWithCausalConsistency(String postId, String userId, 
                                                  String content, Optional<String> parentCommentId) {
        
        VectorClock vectorClock = vectorClockService.getCurrentClock(userId);
        
        Comment comment = Comment.builder()
            .id(UUID.randomUUID().toString())
            .postId(postId)
            .userId(userId)
            .content(content)
            .parentCommentId(parentCommentId.orElse(null))
            .timestamp(Instant.now())
            .vectorClock(vectorClock.increment(userId))
            .build();
        
        // If replying to a comment, establish causal relationship
        if (parentCommentId.isPresent()) {
            Comment parentComment = commentRepository.findById(parentCommentId.get())
                .orElseThrow(() -> new CommentNotFoundException(parentCommentId.get()));
            
            // Merge vector clocks to maintain causal ordering
            comment.setVectorClock(
                vectorClock.merge(parentComment.getVectorClock()).increment(userId));
        }
        
        Comment savedComment = commentRepository.save(comment);
        
        // Update user's vector clock
        vectorClockService.updateUserClock(userId, savedComment.getVectorClock());
        
        // Publish event with vector clock for causal consistency
        CommentAddedEvent event = CommentAddedEvent.builder()
            .commentId(savedComment.getId())
            .postId(postId)
            .userId(userId)
            .parentCommentId(parentCommentId.orElse(null))
            .vectorClock(savedComment.getVectorClock())
            .timestamp(savedComment.getTimestamp())
            .build();
        
        eventPublisher.publishWithCausalOrdering(event);
        
        return savedComment;
    }
}
```

### 2. Conflict Resolution Strategies

```java
// Comprehensive conflict resolution for distributed systems
@Service
public class ConflictResolutionService {
    
    @Autowired
    private ConflictResolutionMetrics metrics;
    
    /**
     * Last Writer Wins (LWW) - Simple timestamp-based resolution
     * Use case: User preferences, configuration settings
     */
    public UserSettings resolveSettingsConflictLWW(UserSettings local, UserSettings remote) {
        if (local.getLastModified().isAfter(remote.getLastModified())) {
            metrics.recordConflictResolution("settings", "LWW", "local_wins");
            return local;
        } else if (remote.getLastModified().isAfter(local.getLastModified())) {
            metrics.recordConflictResolution("settings", "LWW", "remote_wins");
            return remote;
        } else {
            // Same timestamp - use deterministic tie-breaker (e.g., server ID)
            String localServerId = local.getServerId();
            String remoteServerId = remote.getServerId();
            
            if (localServerId.compareTo(remoteServerId) > 0) {
                metrics.recordConflictResolution("settings", "LWW", "tie_breaker_local");
                return local;
            } else {
                metrics.recordConflictResolution("settings", "LWW", "tie_breaker_remote");
                return remote;
            }
        }
    }
    
    /**
     * Vector Clock-based Resolution - Handles concurrent updates
     * Use case: Collaborative editing, distributed databases
     */
    public DocumentVersion resolveDocumentConflictVectorClock(DocumentVersion local, 
                                                             DocumentVersion remote) {
        
        VectorClock localClock = local.getVectorClock();
        VectorClock remoteClock = remote.getVectorClock();
        
        VectorClockComparison comparison = localClock.compareTo(remoteClock);
        
        switch (comparison) {
            case BEFORE:
                // Remote is strictly after local
                metrics.recordConflictResolution("document", "vector_clock", "remote_newer");
                return remote;
                
            case AFTER:
                // Local is strictly after remote
                metrics.recordConflictResolution("document", "vector_clock", "local_newer");
                return local;
                
            case CONCURRENT:
                // Concurrent updates - need to merge
                metrics.recordConflictResolution("document", "vector_clock", "concurrent_merge");
                return mergeDocumentVersions(local, remote);
                
            case SAME:
                // Same vector clock - documents are identical
                metrics.recordConflictResolution("document", "vector_clock", "identical");
                return local;
                
            default:
                throw new IllegalStateException("Unknown vector clock comparison result");
        }
    }
    
    /**
     * Three-way Merge - Git-style conflict resolution
     * Use case: Code repositories, document versioning, configuration files
     */
    public MergeResult resolveConfigConflictThreeWay(ConfigDocument base, 
                                                    ConfigDocument local, 
                                                    ConfigDocument remote) {
        
        Map<String, Object> baseConfig = base.getConfig();
        Map<String, Object> localConfig = local.getConfig();
        Map<String, Object> remoteConfig = remote.getConfig();
        
        Map<String, Object> mergedConfig = new HashMap<>(baseConfig);
        List<ConflictDetail> conflicts = new ArrayList<>();
        
        // Find all keys that changed
        Set<String> allKeys = new HashSet<>();
        allKeys.addAll(baseConfig.keySet());
        allKeys.addAll(localConfig.keySet());
        allKeys.addAll(remoteConfig.keySet());
        
        for (String key : allKeys) {
            Object baseValue = baseConfig.get(key);
            Object localValue = localConfig.get(key);
            Object remoteValue = remoteConfig.get(key);
            
            if (Objects.equals(localValue, remoteValue)) {
                // Both sides made the same change or no change
                if (localValue != null) {
                    mergedConfig.put(key, localValue);
                } else {
                    mergedConfig.remove(key);
                }
            } else if (Objects.equals(baseValue, localValue)) {
                // Only remote changed
                if (remoteValue != null) {
                    mergedConfig.put(key, remoteValue);
                } else {
                    mergedConfig.remove(key);
                }
            } else if (Objects.equals(baseValue, remoteValue)) {
                // Only local changed
                if (localValue != null) {
                    mergedConfig.put(key, localValue);
                } else {
                    mergedConfig.remove(key);
                }
            } else {
                // Both sides changed differently - conflict!
                ConflictDetail conflict = ConflictDetail.builder()
                    .key(key)
                    .baseValue(baseValue)
                    .localValue(localValue)
                    .remoteValue(remoteValue)
                    .resolutionStrategy(determineAutoResolutionStrategy(key, localValue, remoteValue))
                    .build();
                
                conflicts.add(conflict);
                
                // Apply auto-resolution if possible
                Object resolvedValue = applyAutoResolution(conflict);
                if (resolvedValue != null) {
                    mergedConfig.put(key, resolvedValue);
                } else {
                    mergedConfig.remove(key);
                }
            }
        }
        
        ConfigDocument mergedDocument = ConfigDocument.builder()
            .config(mergedConfig)
            .version(Math.max(local.getVersion(), remote.getVersion()) + 1)
            .lastModified(Instant.now())
            .mergedFrom(Arrays.asList(local.getId(), remote.getId()))
            .build();
        
        metrics.recordConflictResolution("config", "three_way_merge", 
            conflicts.isEmpty() ? "auto_resolved" : "manual_required");
        
        return MergeResult.builder()
            .merged(mergedDocument)
            .conflicts(conflicts)
            .autoResolved(conflicts.stream().allMatch(c -> c.getResolutionStrategy() != null))
            .build();
    }
    
    /**
     * Operational Transform - Real-time collaborative editing
     * Use case: Google Docs-style collaboration, real-time code editing
     */
    public List<Operation> resolveOperationsConflict(List<Operation> localOps, 
                                                    List<Operation> remoteOps,
                                                    DocumentState baseState) {
        
        List<Operation> transformedOps = new ArrayList<>();
        
        // Transform local operations against remote operations
        for (Operation localOp : localOps) {
            Operation transformedOp = localOp;
            
            for (Operation remoteOp : remoteOps) {
                transformedOp = operationalTransform.transform(transformedOp, remoteOp);
            }
            
            transformedOps.add(transformedOp);
        }
        
        // Transform remote operations against original local operations
        for (Operation remoteOp : remoteOps) {
            Operation transformedOp = remoteOp;
            
            for (Operation localOp : localOps) {
                transformedOp = operationalTransform.transform(transformedOp, localOp);
            }
            
            transformedOps.add(transformedOp);
        }
        
        // Sort operations by timestamp to maintain intention
        transformedOps.sort(Comparator.comparing(Operation::getTimestamp));
        
        metrics.recordConflictResolution("operations", "operational_transform", 
            "transformed_" + transformedOps.size() + "_ops");
        
        return transformedOps;
    }
    
    /**
     * CRDT-based Resolution - Conflict-free Replicated Data Types
     * Use case: Real-time collaboration, distributed counters
     */
    public GCounterCRDT resolveCounterConflict(GCounterCRDT local, GCounterCRDT remote) {
        // G-Counter: Grow-only counter CRDT
        Map<String, Long> localCounters = local.getCounters();
        Map<String, Long> remoteCounters = remote.getCounters();
        
        Map<String, Long> mergedCounters = new HashMap<>();
        
        // Take maximum value for each actor
        Set<String> allActors = new HashSet<>();
        allActors.addAll(localCounters.keySet());
        allActors.addAll(remoteCounters.keySet());
        
        for (String actor : allActors) {
            long localValue = localCounters.getOrDefault(actor, 0L);
            long remoteValue = remoteCounters.getOrDefault(actor, 0L);
            mergedCounters.put(actor, Math.max(localValue, remoteValue));
        }
        
        metrics.recordConflictResolution("counter", "crdt", "g_counter_merge");
        
        return GCounterCRDT.builder()
            .counters(mergedCounters)
            .lastModified(Instant.now())
            .build();
    }
    
    /**
     * Business Rule-based Resolution - Domain-specific conflict resolution
     * Use case: E-commerce inventory, booking systems, financial transactions
     */
    public InventoryItem resolveInventoryConflict(InventoryItem local, InventoryItem remote) {
        // Business rule: Always take the lower quantity for safety
        int safeQuantity = Math.min(local.getQuantity(), remote.getQuantity());
        
        // But take the latest price update
        BigDecimal latestPrice = local.getLastPriceUpdate().isAfter(remote.getLastPriceUpdate()) ?
            local.getPrice() : remote.getPrice();
        
        // Merge reservations
        Set<String> allReservations = new HashSet<>();
        allReservations.addAll(local.getReservations());
        allReservations.addAll(remote.getReservations());
        
        InventoryItem resolved = InventoryItem.builder()
            .productId(local.getProductId())
            .quantity(safeQuantity)
            .price(latestPrice)
            .reservations(allReservations)
            .lastModified(Instant.now())
            .conflictResolutionApplied(true)
            .build();
        
        metrics.recordConflictResolution("inventory", "business_rules", "conservative_merge");
        
        // Log conflict for business review
        conflictAuditService.logConflict(ConflictAuditRecord.builder()
            .resourceType("inventory")
            .resourceId(local.getProductId())
            .conflictType("quantity_price_mismatch")
            .localValue(local)
            .remoteValue(remote)
            .resolvedValue(resolved)
            .resolutionStrategy("conservative_merge")
            .timestamp(Instant.now())
            .build());
        
        return resolved;
    }
    
    // Helper methods
    
    private DocumentVersion mergeDocumentVersions(DocumentVersion local, DocumentVersion remote) {
        // Implement document merge logic based on content type
        // This would be specific to the document format (JSON, XML, text, etc.)
        return documentMergeService.merge(local, remote);
    }
    
    private ResolutionStrategy determineAutoResolutionStrategy(String key, Object localValue, Object remoteValue) {
        // Define auto-resolution rules based on key patterns
        if (key.startsWith("cache.")) {
            return ResolutionStrategy.TAKE_LARGER; // Cache settings - prefer larger values
        } else if (key.startsWith("security.")) {
            return ResolutionStrategy.TAKE_STRICTER; // Security settings - prefer stricter values
        } else if (key.startsWith("feature.")) {
            return ResolutionStrategy.MANUAL_REVIEW; // Feature flags need manual review
        } else {
            return ResolutionStrategy.LAST_WRITER_WINS; // Default strategy
        }
    }
    
    private Object applyAutoResolution(ConflictDetail conflict) {
        return switch (conflict.getResolutionStrategy()) {
            case TAKE_LARGER -> takeLargerValue(conflict.getLocalValue(), conflict.getRemoteValue());
            case TAKE_STRICTER -> takeStricterValue(conflict.getLocalValue(), conflict.getRemoteValue());
            case LAST_WRITER_WINS -> conflict.getRemoteValue(); // Assume remote is newer
            case MANUAL_REVIEW -> null; // Return null to indicate manual review needed
        };
    }
    
    private Object takeLargerValue(Object local, Object remote) {
        if (local instanceof Number localNum && remote instanceof Number remoteNum) {
            return localNum.doubleValue() > remoteNum.doubleValue() ? local : remote;
        }
        return local; // Default to local if not comparable
    }
    
    private Object takeStricterValue(Object local, Object remote) {
        // Implement stricter value logic based on security policies
        return securityPolicyEvaluator.getStricterValue(local, remote);
    }
}
```

---

## 🔄 CQRS and Event Sourcing

### 1. CQRS Implementation

```java
// Command Query Responsibility Segregation implementation
@Component
public class OrderCQRSSystem {
    
    // Command side - Write operations
    @Service
    public static class OrderCommandService {
        
        @Autowired
        private OrderWriteRepository writeRepository;
        
        @Autowired
        private EventStore eventStore;
        
        @Autowired
        private CommandValidator commandValidator;
        
        public CommandResult handleCreateOrder(CreateOrderCommand command) {
            try {
                // Validate command
                ValidationResult validation = commandValidator.validate(command);
                if (!validation.isValid()) {
                    return CommandResult.failure(validation.getErrors());
                }
                
                // Create aggregate
                OrderAggregate aggregate = OrderAggregate.create(
                    command.getUserId(),
                    command.getItems(),
                    command.getShippingAddress()
                );
                
                // Get uncommitted events
                List<DomainEvent> events = aggregate.getUncommittedEvents();
                
                // Store events
                for (DomainEvent event : events) {
                    eventStore.append(aggregate.getId(), event);
                }
                
                // Store current state for optimization
                OrderWriteModel writeModel = OrderWriteModel.fromAggregate(aggregate);
                writeRepository.save(writeModel);
                
                // Mark events as committed
                aggregate.markEventsAsCommitted();
                
                return CommandResult.success(aggregate.getId());
                
            } catch (Exception e) {
                return CommandResult.failure(e.getMessage());
            }
        }
        
        public CommandResult handleUpdateOrderStatus(UpdateOrderStatusCommand command) {
            try {
                // Load aggregate from events
                OrderAggregate aggregate = loadAggregateFromEvents(command.getOrderId());
                
                // Execute command
                aggregate.updateStatus(command.getNewStatus(), command.getReason());
                
                // Store new events
                List<DomainEvent> newEvents = aggregate.getUncommittedEvents();
                for (DomainEvent event : newEvents) {
                    eventStore.append(aggregate.getId(), event);
                }
                
                // Update write model
                OrderWriteModel writeModel = OrderWriteModel.fromAggregate(aggregate);
                writeRepository.save(writeModel);
                
                aggregate.markEventsAsCommitted();
                
                return CommandResult.success(aggregate.getId());
                
            } catch (Exception e) {
                return CommandResult.failure(e.getMessage());
            }
        }
        
        private OrderAggregate loadAggregateFromEvents(String orderId) {
            List<DomainEvent> events = eventStore.getEvents(orderId);
            OrderAggregate aggregate = new OrderAggregate();
            aggregate.replayEvents(events);
            return aggregate;
        }
    }
    
    // Query side - Read operations
    @Service
    public static class OrderQueryService {
        
        @Autowired
        private OrderReadRepository readRepository;
        
        @Autowired
        private OrderSearchRepository searchRepository;
        
        @Autowired
        private OrderAnalyticsRepository analyticsRepository;
        
        public Optional<OrderDetailsView> getOrderDetails(String orderId) {
            return readRepository.findOrderDetails(orderId);
        }
        
        public List<OrderSummaryView> getUserOrders(String userId, Pageable pageable) {
            return readRepository.findUserOrders(userId, pageable);
        }
        
        public OrderSearchResults searchOrders(OrderSearchCriteria criteria) {
            return searchRepository.search(criteria);
        }
        
        public OrderAnalytics getOrderAnalytics(AnalyticsRequest request) {
            return analyticsRepository.getAnalytics(request);
        }
        
        // Specialized read models for different use cases
        public List<OrderView> getOrdersByStatus(OrderStatus status, Pageable pageable) {
            return readRepository.findByStatus(status, pageable);
        }
        
        public List<RecentOrderView> getRecentOrders(int limit) {
            return readRepository.findRecentOrders(limit);
        }
        
        public OrderStatistics getOrderStatistics(String userId) {
            return readRepository.getOrderStatistics(userId);
        }
    }
    
    // Event handlers for updating read models
    @Component
    public static class OrderReadModelUpdater {
        
        @Autowired
        private OrderReadRepository readRepository;
        
        @Autowired
        private OrderSearchRepository searchRepository;
        
        @Autowired
        private OrderAnalyticsRepository analyticsRepository;
        
        @EventHandler
        public void handle(OrderCreatedEvent event) {
            // Update order details view
            OrderDetailsView detailsView = OrderDetailsView.builder()
                .orderId(event.getOrderId())
                .userId(event.getUserId())
                .status(event.getStatus())
                .totalAmount(event.getTotalAmount())
                .items(event.getItems())
                .createdAt(event.getTimestamp())
                .build();
            
            readRepository.saveOrderDetails(detailsView);
            
            // Update user orders summary
            OrderSummaryView summaryView = OrderSummaryView.builder()
                .orderId(event.getOrderId())
                .userId(event.getUserId())
                .status(event.getStatus())
                .totalAmount(event.getTotalAmount())
                .itemCount(event.getItems().size())
                .createdAt(event.getTimestamp())
                .build();
            
            readRepository.saveOrderSummary(summaryView);
            
            // Update search index
            OrderSearchDocument searchDoc = OrderSearchDocument.builder()
                .orderId(event.getOrderId())
                .userId(event.getUserId())
                .status(event.getStatus())
                .totalAmount(event.getTotalAmount())
                .customerName(event.getCustomerName())
                .items(convertItemsForSearch(event.getItems()))
                .createdAt(event.getTimestamp())
                .build();
            
            searchRepository.index(searchDoc);
            
            // Update analytics
            analyticsRepository.recordOrderCreated(event);
        }
        
        @EventHandler
        public void handle(OrderStatusUpdatedEvent event) {
            // Update all read models with new status
            readRepository.updateOrderStatus(event.getOrderId(), event.getNewStatus());
            searchRepository.updateOrderStatus(event.getOrderId(), event.getNewStatus());
            analyticsRepository.recordStatusChange(event);
        }
        
        @EventHandler
        public void handle(OrderCancelledEvent event) {
            // Update read models for cancellation
            readRepository.markOrderCancelled(event.getOrderId(), event.getReason());
            searchRepository.updateOrderStatus(event.getOrderId(), OrderStatus.CANCELLED);
            analyticsRepository.recordOrderCancelled(event);
        }
        
        private List<SearchableItem> convertItemsForSearch(List<OrderItem> items) {
            return items.stream()
                .map(item -> SearchableItem.builder()
                    .productId(item.getProductId())
                    .productName(item.getProductName())
                    .category(item.getCategory())
                    .price(item.getPrice())
                    .quantity(item.getQuantity())
                    .build())
                .collect(Collectors.toList());
        }
    }
}
```

### 2. Event Sourcing Implementation

```java
// Complete Event Sourcing implementation
@Service
public class EventSourcingService {
    
    @Autowired
    private EventStore eventStore;
    
    @Autowired
    private SnapshotStore snapshotStore;
    
    @Autowired
    private EventBus eventBus;
    
    /**
     * Event-sourced aggregate root
     */
    public abstract class EventSourcedAggregateRoot {
        
        protected String aggregateId;
        protected long version;
        private final List<DomainEvent> uncommittedEvents = new ArrayList<>();
        
        protected void applyEvent(DomainEvent event) {
            // Apply event to current state
            when(event);
            
            // Add to uncommitted events
            uncommittedEvents.add(event);
            version++;
        }
        
        protected abstract void when(DomainEvent event);
        
        public void replayEvents(List<DomainEvent> events) {
            for (DomainEvent event : events) {
                when(event);
                version++;
            }
        }
        
        public List<DomainEvent> getUncommittedEvents() {
            return new ArrayList<>(uncommittedEvents);
        }
        
        public void markEventsAsCommitted() {
            uncommittedEvents.clear();
        }
        
        // Getters
        public String getAggregateId() { return aggregateId; }
        public long getVersion() { return version; }
    }
    
    /**
     * User aggregate with event sourcing
     */
    public static class UserAggregate extends EventSourcedAggregateRoot {
        
        private String email;
        private String displayName;
        private UserStatus status;
        private Instant createdAt;
        private Instant lastLoginAt;
        private Set<String> roles = new HashSet<>();
        
        // Factory method
        public static UserAggregate createUser(String email, String displayName) {
            UserAggregate user = new UserAggregate();
            user.aggregateId = UUID.randomUUID().toString();
            
            user.applyEvent(UserCreatedEvent.builder()
                .userId(user.aggregateId)
                .email(email)
                .displayName(displayName)
                .createdAt(Instant.now())
                .build());
            
            return user;
        }
        
        // Business methods
        public void updateProfile(String newDisplayName) {
            if (!newDisplayName.equals(this.displayName)) {
                applyEvent(UserProfileUpdatedEvent.builder()
                    .userId(aggregateId)
                    .oldDisplayName(displayName)
                    .newDisplayName(newDisplayName)
                    .updatedAt(Instant.now())
                    .build());
            }
        }
        
        public void login() {
            applyEvent(UserLoggedInEvent.builder()
                .userId(aggregateId)
                .loginAt(Instant.now())
                .build());
        }
        
        public void assignRole(String role) {
            if (!roles.contains(role)) {
                applyEvent(UserRoleAssignedEvent.builder()
                    .userId(aggregateId)
                    .role(role)
                    .assignedAt(Instant.now())
                    .build());
            }
        }
        
        public void suspendUser(String reason) {
            if (status != UserStatus.SUSPENDED) {
                applyEvent(UserSuspendedEvent.builder()
                    .userId(aggregateId)
                    .reason(reason)
                    .suspendedAt(Instant.now())
                    .build());
            }
        }
        
        // Event handlers
        @Override
        protected void when(DomainEvent event) {
            switch (event) {
                case UserCreatedEvent e -> {
                    this.aggregateId = e.getUserId();
                    this.email = e.getEmail();
                    this.displayName = e.getDisplayName();
                    this.status = UserStatus.ACTIVE;
                    this.createdAt = e.getCreatedAt();
                }
                case UserProfileUpdatedEvent e -> {
                    this.displayName = e.getNewDisplayName();
                }
                case UserLoggedInEvent e -> {
                    this.lastLoginAt = e.getLoginAt();
                }
                case UserRoleAssignedEvent e -> {
                    this.roles.add(e.getRole());
                }
                case UserSuspendedEvent e -> {
                    this.status = UserStatus.SUSPENDED;
                }
                default -> {
                    // Ignore unknown events for forward compatibility
                }
            }
        }
        
        // Getters
        public String getEmail() { return email; }
        public String getDisplayName() { return displayName; }
        public UserStatus getStatus() { return status; }
        public Instant getCreatedAt() { return createdAt; }
        public Instant getLastLoginAt() { return lastLoginAt; }
        public Set<String> getRoles() { return new HashSet<>(roles); }
    }
    
    /**
     * Event store implementation
     */
    @Repository
    public static class PostgreSQLEventStore implements EventStore {
        
        @Autowired
        private JdbcTemplate jdbcTemplate;
        
        @Autowired
        private ObjectMapper objectMapper;
        
        @Override
        public void append(String aggregateId, DomainEvent event) {
            String sql = """
                INSERT INTO event_store (
                    aggregate_id, event_type, event_data, event_version, 
                    occurred_at, correlation_id, causation_id
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                """;
            
            try {
                long nextVersion = getNextVersion(aggregateId);
                
                jdbcTemplate.update(sql,
                    aggregateId,
                    event.getClass().getSimpleName(),
                    objectMapper.writeValueAsString(event),
                    nextVersion,
                    event.getOccurredAt(),
                    event.getCorrelationId(),
                    event.getCausationId()
                );
                
            } catch (Exception e) {
                throw new EventStoreException("Failed to append event", e);
            }
        }
        
        @Override
        public List<DomainEvent> getEvents(String aggregateId) {
            String sql = """
                SELECT event_type, event_data, event_version, occurred_at
                FROM event_store 
                WHERE aggregate_id = ? 
                ORDER BY event_version
                """;
            
            return jdbcTemplate.query(sql, (rs, rowNum) -> {
                try {
                    String eventType = rs.getString("event_type");
                    String eventData = rs.getString("event_data");
                    
                    Class<?> eventClass = Class.forName("com.example.events." + eventType);
                    return (DomainEvent) objectMapper.readValue(eventData, eventClass);
                    
                } catch (Exception e) {
                    throw new RuntimeException("Failed to deserialize event", e);
                }
            }, aggregateId);
        }
        
        @Override
        public List<DomainEvent> getEventsAfterVersion(String aggregateId, long version) {
            String sql = """
                SELECT event_type, event_data, event_version, occurred_at
                FROM event_store 
                WHERE aggregate_id = ? AND event_version > ?
                ORDER BY event_version
                """;
            
            return jdbcTemplate.query(sql, (rs, rowNum) -> {
                try {
                    String eventType = rs.getString("event_type");
                    String eventData = rs.getString("event_data");
                    
                    Class<?> eventClass = Class.forName("com.example.events." + eventType);
                    return (DomainEvent) objectMapper.readValue(eventData, eventClass);
                    
                } catch (Exception e) {
                    throw new RuntimeException("Failed to deserialize event", e);
                }
            }, aggregateId, version);
        }
        
        private long getNextVersion(String aggregateId) {
            String sql = "SELECT COALESCE(MAX(event_version), 0) + 1 FROM event_store WHERE aggregate_id = ?";
            return jdbcTemplate.queryForObject(sql, Long.class, aggregateId);
        }
    }
    
    /**
     * Snapshot store for performance optimization
     */
    @Repository
    public static class PostgreSQLSnapshotStore implements SnapshotStore {
        
        @Autowired
        private JdbcTemplate jdbcTemplate;
        
        @Autowired
        private ObjectMapper objectMapper;
        
        @Override
        public void saveSnapshot(String aggregateId, Object snapshot, long version) {
            String sql = """
                INSERT INTO snapshots (aggregate_id, snapshot_data, snapshot_version, created_at)
                VALUES (?, ?, ?, ?)
                ON CONFLICT (aggregate_id) 
                DO UPDATE SET 
                    snapshot_data = EXCLUDED.snapshot_data,
                    snapshot_version = EXCLUDED.snapshot_version,
                    created_at = EXCLUDED.created_at
                """;
            
            try {
                jdbcTemplate.update(sql,
                    aggregateId,
                    objectMapper.writeValueAsString(snapshot),
                    version,
                    Instant.now()
                );
            } catch (Exception e) {
                throw new SnapshotStoreException("Failed to save snapshot", e);
            }
        }
        
        @Override
        public <T> Optional<SnapshotData<T>> getSnapshot(String aggregateId, Class<T> snapshotType) {
            String sql = """
                SELECT snapshot_data, snapshot_version 
                FROM snapshots 
                WHERE aggregate_id = ?
                """;
            
            try {
                return jdbcTemplate.query(sql, rs -> {
                    if (rs.next()) {
                        String snapshotData = rs.getString("snapshot_data");
                        long version = rs.getLong("snapshot_version");
                        
                        T snapshot = objectMapper.readValue(snapshotData, snapshotType);
                        return Optional.of(new SnapshotData<>(snapshot, version));
                    }
                    return Optional.empty();
                }, aggregateId);
                
            } catch (Exception e) {
                throw new SnapshotStoreException("Failed to get snapshot", e);
            }
        }
    }
    
    /**
     * Aggregate repository with event sourcing and snapshots
     */
    @Repository
    public static class EventSourcedUserRepository {
        
        @Autowired
        private EventStore eventStore;
        
        @Autowired
        private SnapshotStore snapshotStore;
        
        private static final int SNAPSHOT_FREQUENCY = 10; // Snapshot every 10 events
        
        public void save(UserAggregate aggregate) {
            List<DomainEvent> events = aggregate.getUncommittedEvents();
            
            for (DomainEvent event : events) {
                eventStore.append(aggregate.getAggregateId(), event);
            }
            
            aggregate.markEventsAsCommitted();
            
            // Create snapshot if needed
            if (aggregate.getVersion() % SNAPSHOT_FREQUENCY == 0) {
                UserSnapshot snapshot = UserSnapshot.fromAggregate(aggregate);
                snapshotStore.saveSnapshot(aggregate.getAggregateId(), snapshot, aggregate.getVersion());
            }
        }
        
        public Optional<UserAggregate> findById(String userId) {
            // Try to load from snapshot first
            Optional<SnapshotData<UserSnapshot>> snapshotData = 
                snapshotStore.getSnapshot(userId, UserSnapshot.class);
            
            UserAggregate aggregate = new UserAggregate();
            long fromVersion = 0;
            
            if (snapshotData.isPresent()) {
                // Restore from snapshot
                UserSnapshot snapshot = snapshotData.get().getSnapshot();
                aggregate = snapshot.toAggregate();
                fromVersion = snapshotData.get().getVersion();
            }
            
            // Load events after snapshot
            List<DomainEvent> events = eventStore.getEventsAfterVersion(userId, fromVersion);
            
            if (events.isEmpty() && snapshotData.isEmpty()) {
                return Optional.empty();
            }
            
            // Replay events
            aggregate.replayEvents(events);
            
            return Optional.of(aggregate);
        }
    }
    
    public record SnapshotData<T>(T snapshot, long version) {}
    
    public enum UserStatus {
        ACTIVE, SUSPENDED, DELETED
    }
}
```

---

## 🎯 Interview Focus Areas

### Key Consistency Questions

**Q: How do you choose between strong and eventual consistency?**
- **Strong consistency**: Financial transactions, critical user data
- **Eventual consistency**: Social media feeds, analytics, recommendations
- **Read-your-writes**: User preferences, personal settings
- **Causal consistency**: Comment threads, collaborative editing

**Q: How do you handle conflicts in distributed systems?**
- **Last Writer Wins (LWW)**: Simple but can lose data
- **Vector clocks**: Handle concurrent updates properly
- **Three-way merge**: Git-style conflict resolution
- **CRDTs**: Conflict-free data structures

**Q: When would you use CQRS and Event Sourcing?**
- **CQRS**: Different read/write patterns, complex queries
- **Event Sourcing**: Audit trails, temporal queries, debugging
- **Both together**: High-scale systems with complex business logic

**Q: How do you ensure data consistency across microservices?**
- **Saga pattern**: Distributed transactions with compensation
- **Event-driven architecture**: Eventual consistency through events
- **Two-phase commit**: Strong consistency (limited scalability)

---

## 🚀 Next Steps

1. **Complete the hands-on exercises** in the exercises folder
2. **Practice conflict resolution** scenarios
3. **Implement CQRS patterns** in your applications
4. **Design event sourcing** for audit requirements
5. **Move to Module 9: Scalability Patterns**

The consistency module provides the foundation for building distributed systems that handle data consistency challenges while maintaining performance and availability.
