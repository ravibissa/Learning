# Module 11: Security Architecture

## 🔐 Building Secure Distributed Systems

### 📚 Learning Objectives

By the end of this module, you will:
- Design security-first architectures for distributed systems
- Implement authentication and authorization patterns
- Handle secure communication and data protection
- Design defense-in-depth security strategies
- Implement threat detection and incident response
- Ensure compliance with security standards (GDPR, SOC2, etc.)

---

## 🏗️ Security Architecture Patterns

### 1. Authentication and Authorization

```java
// Comprehensive authentication and authorization implementation
@Service
public class SecurityService {
    
    /**
     * JWT-based authentication service
     */
    @Component
    public static class JWTAuthenticationService {
        
        @Value("${jwt.secret}")
        private String jwtSecret;
        
        @Value("${jwt.expiration}")
        private int jwtExpirationInMs;
        
        @Value("${jwt.refresh-expiration}")
        private int refreshExpirationInMs;
        
        @Autowired
        private UserService userService;
        
        @Autowired
        private TokenBlacklistService tokenBlacklistService;
        
        @Autowired
        private SecurityAuditService auditService;
        
        private final Algorithm algorithm;
        private final JWTVerifier verifier;
        
        public JWTAuthenticationService() {
            this.algorithm = Algorithm.HMAC256(jwtSecret);
            this.verifier = JWT.require(algorithm).build();
        }
        
        public AuthenticationResult authenticate(String email, String password, String ipAddress) {
            try {
                // Validate credentials
                User user = userService.validateCredentials(email, password);
                
                if (user == null) {
                    auditService.logFailedAuthentication(email, ipAddress, "invalid_credentials");
                    return AuthenticationResult.failure("Invalid credentials");
                }
                
                // Check account status
                if (user.getStatus() == UserStatus.LOCKED) {
                    auditService.logFailedAuthentication(email, ipAddress, "account_locked");
                    return AuthenticationResult.failure("Account is locked");
                }
                
                if (user.getStatus() == UserStatus.SUSPENDED) {
                    auditService.logFailedAuthentication(email, ipAddress, "account_suspended");
                    return AuthenticationResult.failure("Account is suspended");
                }
                
                // Generate tokens
                String accessToken = generateAccessToken(user);
                String refreshToken = generateRefreshToken(user);
                
                // Create session
                UserSession session = UserSession.builder()
                    .userId(user.getId())
                    .sessionId(UUID.randomUUID().toString())
                    .ipAddress(ipAddress)
                    .userAgent(getCurrentUserAgent())
                    .createdAt(Instant.now())
                    .expiresAt(Instant.now().plus(Duration.ofDays(30)))
                    .build();
                
                userService.createSession(session);
                
                auditService.logSuccessfulAuthentication(user.getId(), ipAddress);
                
                return AuthenticationResult.success(TokenPair.builder()
                    .accessToken(accessToken)
                    .refreshToken(refreshToken)
                    .expiresIn(jwtExpirationInMs)
                    .tokenType("Bearer")
                    .build());
                
            } catch (Exception e) {
                auditService.logAuthenticationError(email, ipAddress, e.getMessage());
                return AuthenticationResult.failure("Authentication failed");
            }
        }
        
        private String generateAccessToken(User user) {
            Instant now = Instant.now();
            Instant expiration = now.plus(Duration.ofMillis(jwtExpirationInMs));
            
            return JWT.create()
                .withIssuer("system-design-course")
                .withSubject(user.getId())
                .withClaim("email", user.getEmail())
                .withClaim("roles", user.getRoles().stream().toList())
                .withClaim("permissions", getUserPermissions(user))
                .withClaim("session_id", getCurrentSessionId())
                .withIssuedAt(Date.from(now))
                .withExpiresAt(Date.from(expiration))
                .withJWTId(UUID.randomUUID().toString())
                .sign(algorithm);
        }
        
        private String generateRefreshToken(User user) {
            Instant now = Instant.now();
            Instant expiration = now.plus(Duration.ofMillis(refreshExpirationInMs));
            
            return JWT.create()
                .withIssuer("system-design-course")
                .withSubject(user.getId())
                .withClaim("type", "refresh")
                .withClaim("session_id", getCurrentSessionId())
                .withIssuedAt(Date.from(now))
                .withExpiresAt(Date.from(expiration))
                .withJWTId(UUID.randomUUID().toString())
                .sign(algorithm);
        }
        
        public TokenValidationResult validateToken(String token) {
            try {
                // Check if token is blacklisted
                if (tokenBlacklistService.isBlacklisted(token)) {
                    return TokenValidationResult.invalid("Token is blacklisted");
                }
                
                // Verify token signature and claims
                DecodedJWT decodedJWT = verifier.verify(token);
                
                // Extract claims
                String userId = decodedJWT.getSubject();
                String email = decodedJWT.getClaim("email").asString();
                List<String> roles = decodedJWT.getClaim("roles").asList(String.class);
                List<String> permissions = decodedJWT.getClaim("permissions").asList(String.class);
                String sessionId = decodedJWT.getClaim("session_id").asString();
                
                // Validate session
                if (!userService.isSessionValid(sessionId)) {
                    return TokenValidationResult.invalid("Session is invalid");
                }
                
                // Create security context
                SecurityContext context = SecurityContext.builder()
                    .userId(userId)
                    .email(email)
                    .roles(new HashSet<>(roles))
                    .permissions(new HashSet<>(permissions))
                    .sessionId(sessionId)
                    .tokenId(decodedJWT.getId())
                    .build();
                
                return TokenValidationResult.valid(context);
                
            } catch (JWTVerificationException e) {
                return TokenValidationResult.invalid("Invalid token: " + e.getMessage());
            }
        }
        
        public AuthenticationResult refreshToken(String refreshToken) {
            try {
                DecodedJWT decodedJWT = verifier.verify(refreshToken);
                
                // Verify it's a refresh token
                String tokenType = decodedJWT.getClaim("type").asString();
                if (!"refresh".equals(tokenType)) {
                    return AuthenticationResult.failure("Invalid token type");
                }
                
                String userId = decodedJWT.getSubject();
                String sessionId = decodedJWT.getClaim("session_id").asString();
                
                // Validate session
                if (!userService.isSessionValid(sessionId)) {
                    return AuthenticationResult.failure("Session expired");
                }
                
                User user = userService.findById(userId)
                    .orElseThrow(() -> new UserNotFoundException("User not found"));
                
                // Generate new tokens
                String newAccessToken = generateAccessToken(user);
                String newRefreshToken = generateRefreshToken(user);
                
                // Blacklist old refresh token
                tokenBlacklistService.blacklistToken(refreshToken);
                
                return AuthenticationResult.success(TokenPair.builder()
                    .accessToken(newAccessToken)
                    .refreshToken(newRefreshToken)
                    .expiresIn(jwtExpirationInMs)
                    .tokenType("Bearer")
                    .build());
                
            } catch (JWTVerificationException e) {
                return AuthenticationResult.failure("Invalid refresh token");
            }
        }
        
        public void logout(String accessToken, String refreshToken) {
            // Blacklist both tokens
            tokenBlacklistService.blacklistToken(accessToken);
            tokenBlacklistService.blacklistToken(refreshToken);
            
            // Invalidate session
            try {
                DecodedJWT decodedJWT = verifier.verify(accessToken);
                String sessionId = decodedJWT.getClaim("session_id").asString();
                userService.invalidateSession(sessionId);
                
                auditService.logLogout(decodedJWT.getSubject());
            } catch (Exception e) {
                log.warn("Failed to invalidate session during logout", e);
            }
        }
    }
    
    /**
     * Role-Based Access Control (RBAC) implementation
     */
    @Component
    public static class RBACAuthorizationService {
        
        @Autowired
        private RoleService roleService;
        
        @Autowired
        private PermissionService permissionService;
        
        @Autowired
        private SecurityAuditService auditService;
        
        public boolean hasPermission(SecurityContext context, String resource, String action) {
            try {
                // Check direct permissions
                String permission = STR."\{resource}:\{action}";
                if (context.getPermissions().contains(permission)) {
                    return true;
                }
                
                // Check role-based permissions
                for (String role : context.getRoles()) {
                    Set<String> rolePermissions = roleService.getRolePermissions(role);
                    if (rolePermissions.contains(permission)) {
                        return true;
                    }
                }
                
                // Check wildcard permissions
                String wildcardPermission = STR."\{resource}:*";
                if (context.getPermissions().contains(wildcardPermission)) {
                    return true;
                }
                
                // Check super admin role
                if (context.getRoles().contains("SUPER_ADMIN")) {
                    return true;
                }
                
                return false;
                
            } catch (Exception e) {
                log.error("Error checking permission", e);
                return false; // Fail closed
            }
        }
        
        public boolean hasAnyPermission(SecurityContext context, List<String> permissions) {
            return permissions.stream()
                .anyMatch(permission -> {
                    String[] parts = permission.split(":");
                    return hasPermission(context, parts[0], parts[1]);
                });
        }
        
        public boolean hasAllPermissions(SecurityContext context, List<String> permissions) {
            return permissions.stream()
                .allMatch(permission -> {
                    String[] parts = permission.split(":");
                    return hasPermission(context, parts[0], parts[1]);
                });
        }
        
        public AuthorizationResult authorize(SecurityContext context, AuthorizationRequest request) {
            try {
                boolean authorized = hasPermission(context, request.getResource(), request.getAction());
                
                if (authorized) {
                    auditService.logAuthorizationSuccess(context.getUserId(), 
                        request.getResource(), request.getAction());
                    
                    return AuthorizationResult.allowed();
                } else {
                    auditService.logAuthorizationFailure(context.getUserId(), 
                        request.getResource(), request.getAction(), "insufficient_permissions");
                    
                    return AuthorizationResult.denied("Insufficient permissions");
                }
                
            } catch (Exception e) {
                auditService.logAuthorizationError(context.getUserId(), 
                    request.getResource(), request.getAction(), e.getMessage());
                
                return AuthorizationResult.denied("Authorization check failed");
            }
        }
        
        // Attribute-Based Access Control (ABAC) for complex scenarios
        public boolean evaluateABACPolicy(SecurityContext context, ABACRequest request) {
            try {
                // Subject attributes (from context)
                Map<String, Object> subjectAttributes = Map.of(
                    "user.id", context.getUserId(),
                    "user.roles", context.getRoles(),
                    "user.department", getUserDepartment(context.getUserId()),
                    "session.ip", getSessionIpAddress(context.getSessionId())
                );
                
                // Resource attributes
                Map<String, Object> resourceAttributes = Map.of(
                    "resource.type", request.getResourceType(),
                    "resource.id", request.getResourceId(),
                    "resource.owner", getResourceOwner(request.getResourceId()),
                    "resource.classification", getResourceClassification(request.getResourceId())
                );
                
                // Environment attributes
                Map<String, Object> environmentAttributes = Map.of(
                    "time.hour", LocalTime.now().getHour(),
                    "time.dayOfWeek", LocalDate.now().getDayOfWeek(),
                    "location.country", getRequestCountry(),
                    "network.type", getNetworkType()
                );
                
                // Action attributes
                Map<String, Object> actionAttributes = Map.of(
                    "action.type", request.getAction(),
                    "action.risk", getActionRiskLevel(request.getAction())
                );
                
                // Evaluate ABAC policy
                return policyEngine.evaluate(ABACEvaluationContext.builder()
                    .subjectAttributes(subjectAttributes)
                    .resourceAttributes(resourceAttributes)
                    .environmentAttributes(environmentAttributes)
                    .actionAttributes(actionAttributes)
                    .build());
                
            } catch (Exception e) {
                log.error("Error evaluating ABAC policy", e);
                return false; // Fail closed
            }
        }
    }
    
    /**
     * OAuth2 and OpenID Connect implementation
     */
    @Component
    public static class OAuth2Service {
        
        @Autowired
        private OAuth2ClientService clientService;
        
        @Autowired
        private AuthorizationCodeService authCodeService;
        
        @Autowired
        private TokenService tokenService;
        
        public AuthorizationCodeResponse handleAuthorizationRequest(OAuth2AuthorizationRequest request) {
            try {
                // Validate client
                OAuth2Client client = clientService.validateClient(request.getClientId());
                if (client == null) {
                    return AuthorizationCodeResponse.error("invalid_client", "Unknown client");
                }
                
                // Validate redirect URI
                if (!client.getRedirectUris().contains(request.getRedirectUri())) {
                    return AuthorizationCodeResponse.error("invalid_redirect_uri", "Invalid redirect URI");
                }
                
                // Validate scope
                Set<String> requestedScopes = Set.of(request.getScope().split(" "));
                if (!client.getAllowedScopes().containsAll(requestedScopes)) {
                    return AuthorizationCodeResponse.error("invalid_scope", "Invalid scope requested");
                }
                
                // Generate authorization code
                String authCode = authCodeService.generateAuthorizationCode(
                    client.getClientId(),
                    request.getRedirectUri(),
                    requestedScopes,
                    getCurrentUserId()
                );
                
                return AuthorizationCodeResponse.success(authCode, request.getState());
                
            } catch (Exception e) {
                log.error("Error handling authorization request", e);
                return AuthorizationCodeResponse.error("server_error", "Internal server error");
            }
        }
        
        public TokenResponse handleTokenRequest(OAuth2TokenRequest request) {
            try {
                // Validate client credentials
                OAuth2Client client = clientService.authenticateClient(
                    request.getClientId(), request.getClientSecret());
                
                if (client == null) {
                    return TokenResponse.error("invalid_client", "Client authentication failed");
                }
                
                if ("authorization_code".equals(request.getGrantType())) {
                    return handleAuthorizationCodeGrant(request, client);
                } else if ("refresh_token".equals(request.getGrantType())) {
                    return handleRefreshTokenGrant(request, client);
                } else if ("client_credentials".equals(request.getGrantType())) {
                    return handleClientCredentialsGrant(request, client);
                } else {
                    return TokenResponse.error("unsupported_grant_type", "Grant type not supported");
                }
                
            } catch (Exception e) {
                log.error("Error handling token request", e);
                return TokenResponse.error("server_error", "Internal server error");
            }
        }
        
        private TokenResponse handleAuthorizationCodeGrant(OAuth2TokenRequest request, OAuth2Client client) {
            // Validate authorization code
            AuthorizationCode authCode = authCodeService.validateAndConsumeCode(
                request.getCode(), client.getClientId(), request.getRedirectUri());
            
            if (authCode == null) {
                return TokenResponse.error("invalid_grant", "Invalid authorization code");
            }
            
            // Generate tokens
            String accessToken = tokenService.generateAccessToken(
                authCode.getUserId(), authCode.getScopes());
            String refreshToken = tokenService.generateRefreshToken(
                authCode.getUserId(), authCode.getScopes());
            String idToken = generateIdToken(authCode.getUserId(), client.getClientId());
            
            return TokenResponse.success(OAuth2Tokens.builder()
                .accessToken(accessToken)
                .refreshToken(refreshToken)
                .idToken(idToken)
                .tokenType("Bearer")
                .expiresIn(3600)
                .scope(String.join(" ", authCode.getScopes()))
                .build());
        }
        
        private TokenResponse handleRefreshTokenGrant(OAuth2TokenRequest request, OAuth2Client client) {
            // Validate refresh token
            RefreshTokenInfo tokenInfo = tokenService.validateRefreshToken(request.getRefreshToken());
            
            if (tokenInfo == null || !tokenInfo.getClientId().equals(client.getClientId())) {
                return TokenResponse.error("invalid_grant", "Invalid refresh token");
            }
            
            // Generate new access token
            String accessToken = tokenService.generateAccessToken(
                tokenInfo.getUserId(), tokenInfo.getScopes());
            
            return TokenResponse.success(OAuth2Tokens.builder()
                .accessToken(accessToken)
                .tokenType("Bearer")
                .expiresIn(3600)
                .scope(String.join(" ", tokenInfo.getScopes()))
                .build());
        }
        
        private TokenResponse handleClientCredentialsGrant(OAuth2TokenRequest request, OAuth2Client client) {
            // Validate requested scopes
            Set<String> requestedScopes = request.getScope() != null ? 
                Set.of(request.getScope().split(" ")) : client.getDefaultScopes();
            
            if (!client.getAllowedScopes().containsAll(requestedScopes)) {
                return TokenResponse.error("invalid_scope", "Invalid scope requested");
            }
            
            // Generate access token for client
            String accessToken = tokenService.generateClientAccessToken(
                client.getClientId(), requestedScopes);
            
            return TokenResponse.success(OAuth2Tokens.builder()
                .accessToken(accessToken)
                .tokenType("Bearer")
                .expiresIn(3600)
                .scope(String.join(" ", requestedScopes))
                .build());
        }
        
        private String generateIdToken(String userId, String clientId) {
            User user = userService.findById(userId)
                .orElseThrow(() -> new UserNotFoundException("User not found"));
            
            Instant now = Instant.now();
            Instant expiration = now.plus(Duration.ofHours(1));
            
            return JWT.create()
                .withIssuer("https://system-design-course.com")
                .withSubject(userId)
                .withAudience(clientId)
                .withClaim("email", user.getEmail())
                .withClaim("name", user.getDisplayName())
                .withClaim("email_verified", user.isEmailVerified())
                .withIssuedAt(Date.from(now))
                .withExpiresAt(Date.from(expiration))
                .withJWTId(UUID.randomUUID().toString())
                .sign(algorithm);
        }
    }
}
```

### 2. Security Middleware and Filters

```java
// Security middleware implementation
@Component
public class SecurityMiddleware {
    
    /**
     * Web Application Firewall (WAF) implementation
     */
    @Component
    @Order(1)
    public static class WAFFilter implements Filter {
        
        @Autowired
        private ThreatDetectionService threatDetectionService;
        
        @Autowired
        private RateLimitingService rateLimitingService;
        
        @Autowired
        private SecurityMetrics securityMetrics;
        
        private final Set<String> suspiciousPatterns = Set.of(
            "(?i).*(union|select|insert|delete|update|drop|exec|script).*",
            "(?i).*(<script|javascript:|onload=|onerror=).*",
            "(?i).*(\\.\\.[\\/\\\\]|[\\/\\\\]\\.\\.)",
            "(?i).*(cmd|eval|system|exec)\\s*\\(",
            "(?i).*(sqlmap|nmap|nikto|burp)"
        );
        
        @Override
        public void doFilter(ServletRequest request, ServletResponse response, 
                           FilterChain chain) throws IOException, ServletException {
            
            HttpServletRequest httpRequest = (HttpServletRequest) request;
            HttpServletResponse httpResponse = (HttpServletResponse) response;
            
            SecurityContext securityContext = createSecurityContext(httpRequest);
            
            try {
                // 1. IP-based filtering
                if (isBlockedIp(securityContext.getClientIp())) {
                    securityMetrics.recordBlockedRequest("blocked_ip", securityContext.getClientIp());
                    sendSecurityResponse(httpResponse, 403, "Access denied");
                    return;
                }
                
                // 2. Rate limiting
                if (!rateLimitingService.allowRequest(securityContext)) {
                    securityMetrics.recordBlockedRequest("rate_limit", securityContext.getClientIp());
                    sendSecurityResponse(httpResponse, 429, "Rate limit exceeded");
                    return;
                }
                
                // 3. SQL injection detection
                if (containsSQLInjection(httpRequest)) {
                    threatDetectionService.reportThreat(ThreatReport.builder()
                        .threatType(ThreatType.SQL_INJECTION)
                        .clientIp(securityContext.getClientIp())
                        .userAgent(securityContext.getUserAgent())
                        .requestUri(httpRequest.getRequestURI())
                        .requestParams(getRequestParams(httpRequest))
                        .severity(ThreatSeverity.HIGH)
                        .build());
                    
                    securityMetrics.recordBlockedRequest("sql_injection", securityContext.getClientIp());
                    sendSecurityResponse(httpResponse, 400, "Invalid request");
                    return;
                }
                
                // 4. XSS detection
                if (containsXSS(httpRequest)) {
                    threatDetectionService.reportThreat(ThreatReport.builder()
                        .threatType(ThreatType.XSS)
                        .clientIp(securityContext.getClientIp())
                        .userAgent(securityContext.getUserAgent())
                        .requestUri(httpRequest.getRequestURI())
                        .requestParams(getRequestParams(httpRequest))
                        .severity(ThreatSeverity.MEDIUM)
                        .build());
                    
                    securityMetrics.recordBlockedRequest("xss", securityContext.getClientIp());
                    sendSecurityResponse(httpResponse, 400, "Invalid request");
                    return;
                }
                
                // 5. Path traversal detection
                if (containsPathTraversal(httpRequest)) {
                    threatDetectionService.reportThreat(ThreatReport.builder()
                        .threatType(ThreatType.PATH_TRAVERSAL)
                        .clientIp(securityContext.getClientIp())
                        .userAgent(securityContext.getUserAgent())
                        .requestUri(httpRequest.getRequestURI())
                        .severity(ThreatSeverity.HIGH)
                        .build());
                    
                    securityMetrics.recordBlockedRequest("path_traversal", securityContext.getClientIp());
                    sendSecurityResponse(httpResponse, 400, "Invalid request");
                    return;
                }
                
                // 6. Bot detection
                if (isSuspiciousBot(httpRequest)) {
                    securityMetrics.recordBlockedRequest("suspicious_bot", securityContext.getClientIp());
                    sendSecurityResponse(httpResponse, 403, "Access denied");
                    return;
                }
                
                // Request passed all security checks
                securityMetrics.recordAllowedRequest(securityContext.getClientIp());
                chain.doFilter(request, response);
                
            } catch (Exception e) {
                log.error("Error in WAF filter", e);
                chain.doFilter(request, response); // Fail open for availability
            }
        }
        
        private boolean containsSQLInjection(HttpServletRequest request) {
            return checkParameters(request, "(?i).*(union|select|insert|delete|update|drop|exec).*") ||
                   checkHeaders(request, "(?i).*(union|select|insert|delete|update|drop|exec).*");
        }
        
        private boolean containsXSS(HttpServletRequest request) {
            return checkParameters(request, "(?i).*(<script|javascript:|onload=|onerror=).*") ||
                   checkHeaders(request, "(?i).*(<script|javascript:|onload=|onerror=).*");
        }
        
        private boolean containsPathTraversal(HttpServletRequest request) {
            String uri = request.getRequestURI();
            return uri.contains("../") || uri.contains("..\\") ||
                   checkParameters(request, "(?i).*(\\.\\.[\\/\\\\]|[\\/\\\\]\\.\\.).*");
        }
        
        private boolean isSuspiciousBot(HttpServletRequest request) {
            String userAgent = request.getHeader("User-Agent");
            if (userAgent == null) return true;
            
            return userAgent.toLowerCase().matches("(?i).*(sqlmap|nmap|nikto|burp|scanner).*");
        }
        
        private boolean checkParameters(HttpServletRequest request, String pattern) {
            return request.getParameterMap().values().stream()
                .flatMap(Arrays::stream)
                .anyMatch(value -> value.matches(pattern));
        }
        
        private boolean checkHeaders(HttpServletRequest request, String pattern) {
            return Collections.list(request.getHeaderNames()).stream()
                .anyMatch(headerName -> {
                    String headerValue = request.getHeader(headerName);
                    return headerValue != null && headerValue.matches(pattern);
                });
        }
    }
    
    /**
     * Input validation and sanitization
     */
    @Component
    public static class InputValidationService {
        
        private final Validator validator;
        private final HtmlPolicyFactory htmlPolicyFactory;
        
        public InputValidationService() {
            this.validator = Validation.buildDefaultValidatorFactory().getValidator();
            this.htmlPolicyFactory = new HtmlPolicyFactory()
                .allowElements("p", "br", "strong", "em")
                .allowAttributes("class").onElements("p")
                .requireRelNofollowOnLinks();
        }
        
        public <T> ValidationResult validateAndSanitize(T object) {
            List<String> errors = new ArrayList<>();
            
            // Bean validation
            Set<ConstraintViolation<T>> violations = validator.validate(object);
            for (ConstraintViolation<T> violation : violations) {
                errors.add(STR."\{violation.getPropertyPath()}: \{violation.getMessage()}");
            }
            
            // Custom sanitization
            T sanitizedObject = sanitizeObject(object);
            
            return ValidationResult.builder()
                .valid(errors.isEmpty())
                .errors(errors)
                .sanitizedObject(sanitizedObject)
                .build();
        }
        
        public String sanitizeHtml(String input) {
            if (input == null) return null;
            
            PolicyFactory policy = htmlPolicyFactory.toFactory();
            return policy.sanitize(input);
        }
        
        public String sanitizeSql(String input) {
            if (input == null) return null;
            
            // Remove SQL keywords and dangerous characters
            return input.replaceAll("(?i)(union|select|insert|delete|update|drop|exec|;|--|/\\*|\\*/)", "");
        }
        
        public String sanitizeFileName(String fileName) {
            if (fileName == null) return null;
            
            // Remove path traversal and special characters
            return fileName.replaceAll("[^a-zA-Z0-9._-]", "");
        }
        
        @SuppressWarnings("unchecked")
        private <T> T sanitizeObject(T object) {
            // Use reflection to sanitize string fields
            try {
                Class<?> clazz = object.getClass();
                Field[] fields = clazz.getDeclaredFields();
                
                for (Field field : fields) {
                    field.setAccessible(true);
                    
                    if (field.getType() == String.class) {
                        String value = (String) field.get(object);
                        if (value != null) {
                            String sanitizedValue = sanitizeString(value, field);
                            field.set(object, sanitizedValue);
                        }
                    }
                }
                
                return object;
                
            } catch (Exception e) {
                log.error("Error sanitizing object", e);
                return object;
            }
        }
        
        private String sanitizeString(String value, Field field) {
            // Determine sanitization strategy based on field annotations
            if (field.isAnnotationPresent(HtmlContent.class)) {
                return sanitizeHtml(value);
            } else if (field.isAnnotationPresent(SqlSafe.class)) {
                return sanitizeSql(value);
            } else if (field.isAnnotationPresent(FileName.class)) {
                return sanitizeFileName(value);
            } else {
                // Default sanitization - remove potentially dangerous characters
                return value.replaceAll("[<>\"'&]", "");
            }
        }
    }
    
    /**
     * CSRF protection
     */
    @Component
    public static class CSRFProtectionService {
        
        @Autowired
        private RedisTemplate<String, String> redisTemplate;
        
        private static final String CSRF_TOKEN_HEADER = "X-CSRF-Token";
        private static final String CSRF_TOKEN_PARAMETER = "_csrf";
        private static final Duration TOKEN_EXPIRY = Duration.ofHours(1);
        
        public String generateCSRFToken(String sessionId) {
            String token = generateSecureToken();
            String key = STR."csrf:token:\{sessionId}";
            
            redisTemplate.opsForValue().set(key, token, TOKEN_EXPIRY);
            
            return token;
        }
        
        public boolean validateCSRFToken(String sessionId, String providedToken) {
            if (providedToken == null) return false;
            
            String key = STR."csrf:token:\{sessionId}";
            String storedToken = redisTemplate.opsForValue().get(key);
            
            return providedToken.equals(storedToken);
        }
        
        public boolean requiresCSRFProtection(HttpServletRequest request) {
            String method = request.getMethod();
            return "POST".equals(method) || "PUT".equals(method) || 
                   "DELETE".equals(method) || "PATCH".equals(method);
        }
        
        public String extractCSRFToken(HttpServletRequest request) {
            // Try header first
            String token = request.getHeader(CSRF_TOKEN_HEADER);
            if (token != null) return token;
            
            // Try parameter
            return request.getParameter(CSRF_TOKEN_PARAMETER);
        }
        
        private String generateSecureToken() {
            SecureRandom random = new SecureRandom();
            byte[] bytes = new byte[32];
            random.nextBytes(bytes);
            return Base64.getEncoder().encodeToString(bytes);
        }
    }
}
```

### 3. Data Protection and Encryption

```java
// Data protection and encryption service
@Service
public class DataProtectionService {
    
    /**
     * Encryption service for data at rest and in transit
     */
    @Component
    public static class EncryptionService {
        
        @Value("${encryption.key}")
        private String encryptionKey;
        
        @Value("${encryption.algorithm:AES/GCM/NoPadding}")
        private String algorithm;
        
        private SecretKeySpec secretKey;
        private SecureRandom secureRandom;
        
        @PostConstruct
        public void initialize() {
            byte[] key = Base64.getDecoder().decode(encryptionKey);
            this.secretKey = new SecretKeySpec(key, "AES");
            this.secureRandom = new SecureRandom();
        }
        
        public EncryptionResult encryptData(String plaintext) {
            try {
                Cipher cipher = Cipher.getInstance(algorithm);
                
                // Generate random IV
                byte[] iv = new byte[12]; // GCM standard IV size
                secureRandom.nextBytes(iv);
                GCMParameterSpec gcmSpec = new GCMParameterSpec(128, iv);
                
                cipher.init(Cipher.ENCRYPT_MODE, secretKey, gcmSpec);
                
                byte[] ciphertext = cipher.doFinal(plaintext.getBytes(StandardCharsets.UTF_8));
                
                return EncryptionResult.builder()
                    .ciphertext(Base64.getEncoder().encodeToString(ciphertext))
                    .iv(Base64.getEncoder().encodeToString(iv))
                    .algorithm(algorithm)
                    .keyVersion("v1")
                    .build();
                
            } catch (Exception e) {
                throw new EncryptionException("Failed to encrypt data", e);
            }
        }
        
        public String decryptData(EncryptionResult encryptionResult) {
            try {
                Cipher cipher = Cipher.getInstance(algorithm);
                
                byte[] iv = Base64.getDecoder().decode(encryptionResult.getIv());
                GCMParameterSpec gcmSpec = new GCMParameterSpec(128, iv);
                
                cipher.init(Cipher.DECRYPT_MODE, secretKey, gcmSpec);
                
                byte[] ciphertext = Base64.getDecoder().decode(encryptionResult.getCiphertext());
                byte[] plaintext = cipher.doFinal(ciphertext);
                
                return new String(plaintext, StandardCharsets.UTF_8);
                
            } catch (Exception e) {
                throw new DecryptionException("Failed to decrypt data", e);
            }
        }
        
        public String hashPassword(String password) {
            return BCrypt.hashpw(password, BCrypt.gensalt(12));
        }
        
        public boolean verifyPassword(String password, String hashedPassword) {
            return BCrypt.checkpw(password, hashedPassword);
        }
        
        public String generateSecureToken(int length) {
            byte[] bytes = new byte[length];
            secureRandom.nextBytes(bytes);
            return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
        }
        
        public String generateApiKey() {
            return generateSecureToken(32);
        }
        
        public String hashApiKey(String apiKey) {
            try {
                MessageDigest digest = MessageDigest.getInstance("SHA-256");
                byte[] hash = digest.digest(apiKey.getBytes(StandardCharsets.UTF_8));
                return Base64.getEncoder().encodeToString(hash);
            } catch (Exception e) {
                throw new RuntimeException("Failed to hash API key", e);
            }
        }
    }
    
    /**
     * Personal data anonymization for GDPR compliance
     */
    @Component
    public static class DataAnonymizationService {
        
        @Autowired
        private EncryptionService encryptionService;
        
        public AnonymizedUser anonymizeUser(User user) {
            return AnonymizedUser.builder()
                .id(user.getId())
                .email(anonymizeEmail(user.getEmail()))
                .displayName(anonymizeName(user.getDisplayName()))
                .phoneNumber(anonymizePhoneNumber(user.getPhoneNumber()))
                .address(anonymizeAddress(user.getAddress()))
                .birthDate(anonymizeBirthDate(user.getBirthDate()))
                .ipAddress(anonymizeIpAddress(user.getLastLoginIp()))
                .createdAt(user.getCreatedAt())
                .lastLoginAt(user.getLastLoginAt())
                .build();
        }
        
        private String anonymizeEmail(String email) {
            if (email == null) return null;
            
            String[] parts = email.split("@");
            if (parts.length != 2) return "***@***.***";
            
            String username = parts[0];
            String domain = parts[1];
            
            String anonymizedUsername = username.length() > 2 ? 
                username.substring(0, 2) + "*".repeat(username.length() - 2) : "***";
            
            String[] domainParts = domain.split("\\.");
            String anonymizedDomain = domainParts.length > 1 ?
                "*".repeat(domainParts[0].length()) + "." + domainParts[domainParts.length - 1] :
                "*".repeat(domain.length());
            
            return anonymizedUsername + "@" + anonymizedDomain;
        }
        
        private String anonymizeName(String name) {
            if (name == null) return null;
            
            String[] parts = name.split(" ");
            StringBuilder anonymized = new StringBuilder();
            
            for (int i = 0; i < parts.length; i++) {
                if (i > 0) anonymized.append(" ");
                
                String part = parts[i];
                if (part.length() > 1) {
                    anonymized.append(part.charAt(0)).append("*".repeat(part.length() - 1));
                } else {
                    anonymized.append("*");
                }
            }
            
            return anonymized.toString();
        }
        
        private String anonymizePhoneNumber(String phoneNumber) {
            if (phoneNumber == null) return null;
            
            String digits = phoneNumber.replaceAll("[^0-9]", "");
            if (digits.length() < 4) return "***";
            
            return digits.substring(0, 3) + "*".repeat(digits.length() - 6) + 
                   digits.substring(digits.length() - 3);
        }
        
        private Address anonymizeAddress(Address address) {
            if (address == null) return null;
            
            return Address.builder()
                .street(anonymizeStreet(address.getStreet()))
                .city(address.getCity()) // Keep city for analytics
                .state(address.getState()) // Keep state for analytics
                .zipCode(anonymizeZipCode(address.getZipCode()))
                .country(address.getCountry()) // Keep country for analytics
                .build();
        }
        
        private String anonymizeStreet(String street) {
            if (street == null) return null;
            
            String[] parts = street.split(" ");
            if (parts.length > 0) {
                // Keep street number, anonymize street name
                return parts[0] + " " + "*".repeat(Math.max(1, street.length() - parts[0].length() - 1));
            }
            return "*".repeat(street.length());
        }
        
        private String anonymizeZipCode(String zipCode) {
            if (zipCode == null) return null;
            
            // Keep first 3 digits for geographic analytics
            return zipCode.length() > 3 ? 
                zipCode.substring(0, 3) + "*".repeat(zipCode.length() - 3) : 
                zipCode;
        }
        
        private LocalDate anonymizeBirthDate(LocalDate birthDate) {
            if (birthDate == null) return null;
            
            // Keep birth year for age analytics, anonymize month and day
            return LocalDate.of(birthDate.getYear(), 1, 1);
        }
        
        private String anonymizeIpAddress(String ipAddress) {
            if (ipAddress == null) return null;
            
            String[] parts = ipAddress.split("\\.");
            if (parts.length == 4) {
                // Keep first two octets for geographic analytics
                return parts[0] + "." + parts[1] + ".***.***.";
            }
            
            return "***.***.***.***.";
        }
        
        public void secureDeleteUserData(String userId) {
            try {
                // 1. Delete from primary database
                userRepository.deleteById(userId);
                
                // 2. Delete from caches
                cacheService.evictUser(userId);
                
                // 3. Delete from search indexes
                searchService.deleteUserIndex(userId);
                
                // 4. Delete from analytics databases
                analyticsService.deleteUserData(userId);
                
                // 5. Delete from backups (mark for deletion)
                backupService.markUserDataForDeletion(userId);
                
                // 6. Delete from logs (if legally required)
                logService.anonymizeUserLogs(userId);
                
                // 7. Notify external systems
                dataRetentionService.notifyExternalSystems(userId);
                
                log.info("Securely deleted all data for user: {}", userId);
                
            } catch (Exception e) {
                log.error("Failed to securely delete user data: {}", userId, e);
                throw new DataDeletionException("Failed to delete user data", e);
            }
        }
    }
}
```

---

## 🎯 Interview Focus Areas

### Key Security Questions

**Q: How do you implement authentication in a distributed system?**
- **JWT tokens** with proper signing and validation
- **OAuth2/OpenID Connect** for third-party integration
- **Session management** with secure storage
- **Multi-factor authentication** for sensitive operations

**Q: How do you handle authorization at scale?**
- **RBAC (Role-Based Access Control)** for simple scenarios
- **ABAC (Attribute-Based Access Control)** for complex policies
- **Policy engines** for centralized authorization
- **Caching** authorization decisions for performance

**Q: How do you protect against common web vulnerabilities?**
- **Input validation** and sanitization
- **SQL injection** prevention with parameterized queries
- **XSS protection** with output encoding and CSP
- **CSRF protection** with tokens and SameSite cookies

**Q: How do you handle sensitive data?**
- **Encryption** at rest and in transit
- **Key management** with proper rotation
- **Data classification** and handling policies
- **GDPR compliance** with anonymization and deletion

---

## 🚀 Next Steps

1. **Complete the hands-on exercises** in the exercises folder
2. **Implement security middleware** for your applications
3. **Design authentication and authorization** systems
4. **Practice threat modeling** for your architecture
5. **Move to Module 12: Cloud AWS**

The security module provides the foundation for building systems that protect user data and prevent common attack vectors while maintaining usability and performance.
