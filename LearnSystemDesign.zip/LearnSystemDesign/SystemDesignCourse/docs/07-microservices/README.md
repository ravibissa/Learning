# Module 7: Microservices Architecture

## 🏗️ Building Scalable Distributed Systems

### 📚 Learning Objectives

By the end of this module, you will:
- Design microservices architectures that scale to millions of users
- Implement service discovery and communication patterns
- Handle distributed transactions and data consistency
- Design API gateways and service mesh architectures
- Implement monitoring, logging, and distributed tracing
- Deploy microservices with containers and orchestration

---

## 🏗️ Microservices Design Patterns

### 1. Service Decomposition Strategy

```java
// Domain-driven microservices decomposition
@RestController
@RequestMapping("/api/v1")
public class ECommerceDecompositionExample {
    
    // User Service - Identity and authentication domain
    @Service
    public class UserService {
        
        @Autowired
        private UserRepository userRepository;
        
        @Autowired
        private AuthenticationService authService;
        
        public UserProfile createUser(CreateUserRequest request) {
            // Validate user data
            validateUserRequest(request);
            
            // Create user entity
            User user = User.builder()
                .email(request.getEmail())
                .username(request.getUsername())
                .passwordHash(authService.hashPassword(request.getPassword()))
                .createdAt(Instant.now())
                .status(UserStatus.ACTIVE)
                .build();
            
            User savedUser = userRepository.save(user);
            
            // Publish user created event
            publishUserCreatedEvent(savedUser);
            
            return UserProfile.from(savedUser);
        }
        
        @EventListener
        public void handleOrderCompleted(OrderCompletedEvent event) {
            // Update user statistics when order is completed
            updateUserOrderStats(event.getUserId(), event.getOrderValue());
        }
        
        private void publishUserCreatedEvent(User user) {
            UserCreatedEvent event = UserCreatedEvent.builder()
                .userId(user.getId())
                .email(user.getEmail())
                .createdAt(user.getCreatedAt())
                .build();
            
            eventPublisher.publishEvent(event);
        }
    }
    
    // Product Service - Catalog and inventory domain
    @Service
    public class ProductService {
        
        @Autowired
        private ProductRepository productRepository;
        
        @Autowired
        private InventoryService inventoryService;
        
        @Autowired
        private PricingService pricingService;
        
        public Product createProduct(CreateProductRequest request) {
            // Create product in catalog
            Product product = Product.builder()
                .name(request.getName())
                .description(request.getDescription())
                .categoryId(request.getCategoryId())
                .basePrice(request.getBasePrice())
                .createdAt(Instant.now())
                .status(ProductStatus.ACTIVE)
                .build();
            
            Product savedProduct = productRepository.save(product);
            
            // Initialize inventory
            inventoryService.initializeInventory(savedProduct.getId(), request.getInitialStock());
            
            // Set up pricing rules
            pricingService.createPricingRules(savedProduct.getId(), request.getPricingRules());
            
            // Publish product created event
            publishProductCreatedEvent(savedProduct);
            
            return savedProduct;
        }
        
        public ProductDetails getProductDetails(String productId) {
            Product product = productRepository.findById(productId)
                .orElseThrow(() -> new ProductNotFoundException(productId));
            
            // Get current inventory (from separate service)
            InventoryInfo inventory = inventoryService.getInventory(productId);
            
            // Get current pricing (from separate service)
            PricingInfo pricing = pricingService.getCurrentPricing(productId);
            
            return ProductDetails.builder()
                .product(product)
                .availableQuantity(inventory.getAvailableQuantity())
                .currentPrice(pricing.getCurrentPrice())
                .priceHistory(pricing.getRecentPriceHistory())
                .build();
        }
        
        private void publishProductCreatedEvent(Product product) {
            ProductCreatedEvent event = ProductCreatedEvent.builder()
                .productId(product.getId())
                .name(product.getName())
                .categoryId(product.getCategoryId())
                .createdAt(product.getCreatedAt())
                .build();
            
            eventPublisher.publishEvent(event);
        }
    }
    
    // Order Service - Order management and workflow domain
    @Service
    public class OrderService {
        
        @Autowired
        private OrderRepository orderRepository;
        
        @Autowired
        private PaymentServiceClient paymentServiceClient;
        
        @Autowired
        private InventoryServiceClient inventoryServiceClient;
        
        @Autowired
        private ShippingServiceClient shippingServiceClient;
        
        @Autowired
        private SagaOrchestrator sagaOrchestrator;
        
        public OrderResult createOrder(CreateOrderRequest request) {
            // Validate order request
            validateOrderRequest(request);
            
            // Create order entity
            Order order = Order.builder()
                .userId(request.getUserId())
                .items(request.getItems())
                .totalAmount(calculateTotalAmount(request.getItems()))
                .status(OrderStatus.CREATED)
                .createdAt(Instant.now())
                .build();
            
            Order savedOrder = orderRepository.save(order);
            
            // Start order processing saga
            OrderProcessingSaga saga = OrderProcessingSaga.builder()
                .orderId(savedOrder.getId())
                .userId(savedOrder.getUserId())
                .items(savedOrder.getItems())
                .totalAmount(savedOrder.getTotalAmount())
                .build();
            
            sagaOrchestrator.startSaga(saga);
            
            return OrderResult.builder()
                .orderId(savedOrder.getId())
                .status(savedOrder.getStatus())
                .estimatedDelivery(calculateEstimatedDelivery())
                .build();
        }
        
        @SagaStep(step = "RESERVE_INVENTORY")
        public void reserveInventory(OrderProcessingSaga saga) {
            try {
                for (OrderItem item : saga.getItems()) {
                    inventoryServiceClient.reserveItem(
                        item.getProductId(), 
                        item.getQuantity(),
                        saga.getOrderId()
                    );
                }
                saga.markStepCompleted("RESERVE_INVENTORY");
            } catch (Exception e) {
                saga.markStepFailed("RESERVE_INVENTORY", e.getMessage());
                throw new SagaStepException("Failed to reserve inventory", e);
            }
        }
        
        @SagaStep(step = "PROCESS_PAYMENT")
        public void processPayment(OrderProcessingSaga saga) {
            try {
                PaymentRequest paymentRequest = PaymentRequest.builder()
                    .orderId(saga.getOrderId())
                    .userId(saga.getUserId())
                    .amount(saga.getTotalAmount())
                    .paymentMethod(saga.getPaymentMethod())
                    .build();
                
                PaymentResult result = paymentServiceClient.processPayment(paymentRequest);
                
                if (result.isSuccess()) {
                    saga.setPaymentId(result.getPaymentId());
                    saga.markStepCompleted("PROCESS_PAYMENT");
                } else {
                    saga.markStepFailed("PROCESS_PAYMENT", result.getFailureReason());
                    throw new PaymentFailedException(result.getFailureReason());
                }
            } catch (Exception e) {
                saga.markStepFailed("PROCESS_PAYMENT", e.getMessage());
                throw new SagaStepException("Failed to process payment", e);
            }
        }
        
        @SagaStep(step = "CREATE_SHIPMENT")
        public void createShipment(OrderProcessingSaga saga) {
            try {
                ShipmentRequest shipmentRequest = ShipmentRequest.builder()
                    .orderId(saga.getOrderId())
                    .items(saga.getItems())
                    .shippingAddress(saga.getShippingAddress())
                    .build();
                
                ShipmentResult result = shippingServiceClient.createShipment(shipmentRequest);
                
                saga.setShipmentId(result.getShipmentId());
                saga.markStepCompleted("CREATE_SHIPMENT");
                
            } catch (Exception e) {
                saga.markStepFailed("CREATE_SHIPMENT", e.getMessage());
                throw new SagaStepException("Failed to create shipment", e);
            }
        }
        
        // Compensation methods for saga rollback
        @SagaCompensation(step = "RESERVE_INVENTORY")
        public void releaseInventoryReservation(OrderProcessingSaga saga) {
            for (OrderItem item : saga.getItems()) {
                try {
                    inventoryServiceClient.releaseReservation(
                        item.getProductId(), 
                        saga.getOrderId()
                    );
                } catch (Exception e) {
                    log.error("Failed to release inventory reservation", e);
                }
            }
        }
        
        @SagaCompensation(step = "PROCESS_PAYMENT")
        public void refundPayment(OrderProcessingSaga saga) {
            if (saga.getPaymentId() != null) {
                try {
                    paymentServiceClient.refundPayment(saga.getPaymentId());
                } catch (Exception e) {
                    log.error("Failed to refund payment", e);
                }
            }
        }
        
        @SagaCompensation(step = "CREATE_SHIPMENT")
        public void cancelShipment(OrderProcessingSaga saga) {
            if (saga.getShipmentId() != null) {
                try {
                    shippingServiceClient.cancelShipment(saga.getShipmentId());
                } catch (Exception e) {
                    log.error("Failed to cancel shipment", e);
                }
            }
        }
    }
}
```

### 2. Service Communication Patterns

```java
// Inter-service communication with resilience patterns
@Component
public class ServiceCommunicationPatterns {
    
    // Synchronous communication with circuit breaker
    @Service
    public class UserServiceClient {
        
        @Autowired
        private WebClient webClient;
        
        @Autowired
        private CircuitBreaker circuitBreaker;
        
        @Retryable(value = {ConnectException.class, TimeoutException.class}, 
                  maxAttempts = 3, 
                  backoff = @Backoff(delay = 1000, multiplier = 2))
        public Optional<UserProfile> getUserProfile(String userId) {
            return circuitBreaker.executeSupplier(() -> {
                try {
                    UserProfile profile = webClient
                        .get()
                        .uri("/api/v1/users/{userId}", userId)
                        .retrieve()
                        .bodyToMono(UserProfile.class)
                        .timeout(Duration.ofSeconds(5))
                        .block();
                    
                    return Optional.ofNullable(profile);
                    
                } catch (Exception e) {
                    log.warn("Failed to fetch user profile for userId: {}", userId, e);
                    return Optional.empty();
                }
            });
        }
        
        @Recover
        public Optional<UserProfile> recoverGetUserProfile(Exception ex, String userId) {
            log.error("All retries exhausted for getUserProfile, userId: {}", userId, ex);
            
            // Return cached profile if available
            return cacheService.getCachedUserProfile(userId);
        }
        
        // Async communication with message queues
        public void updateUserPreferences(String userId, UserPreferences preferences) {
            UserPreferencesUpdateEvent event = UserPreferencesUpdateEvent.builder()
                .userId(userId)
                .preferences(preferences)
                .timestamp(Instant.now())
                .build();
            
            // Publish event asynchronously
            eventPublisher.publishEvent(event);
        }
    }
    
    // Asynchronous event-driven communication
    @Component
    public class EventDrivenCommunication {
        
        @Autowired
        private KafkaTemplate<String, Object> kafkaTemplate;
        
        @Autowired
        private MessageDeduplicationService deduplicationService;
        
        // Event publishing with deduplication
        public void publishOrderEvent(OrderEvent event) {
            String eventId = event.getEventId();
            
            // Check for duplicate events
            if (deduplicationService.isDuplicate(eventId)) {
                log.debug("Duplicate event detected, skipping: {}", eventId);
                return;
            }
            
            try {
                // Add metadata
                event.setPublishedAt(Instant.now());
                event.setPublisher("order-service");
                
                // Publish to Kafka
                ListenableFuture<SendResult<String, Object>> future = kafkaTemplate.send(
                    "order-events", 
                    event.getOrderId(),
                    event
                );
                
                // Handle success/failure
                future.addCallback(
                    result -> {
                        deduplicationService.markAsProcessed(eventId);
                        log.debug("Event published successfully: {}", eventId);
                    },
                    failure -> {
                        log.error("Failed to publish event: {}", eventId, failure);
                    }
                );
                
            } catch (Exception e) {
                log.error("Failed to publish order event", e);
                throw new EventPublishException("Failed to publish event", e);
            }
        }
        
        // Event consumption with idempotency
        @KafkaListener(topics = "order-events", groupId = "inventory-service")
        public void handleOrderEvent(@Payload OrderEvent event, 
                                   @Header Map<String, Object> headers) {
            String eventId = event.getEventId();
            
            // Idempotency check
            if (eventProcessingRepository.existsByEventId(eventId)) {
                log.debug("Event already processed, skipping: {}", eventId);
                return;
            }
            
            try {
                // Process event based on type
                switch (event.getEventType()) {
                    case ORDER_CREATED:
                        handleOrderCreated((OrderCreatedEvent) event);
                        break;
                    case ORDER_CANCELLED:
                        handleOrderCancelled((OrderCancelledEvent) event);
                        break;
                    case ORDER_SHIPPED:
                        handleOrderShipped((OrderShippedEvent) event);
                        break;
                    default:
                        log.warn("Unknown event type: {}", event.getEventType());
                }
                
                // Mark as processed
                eventProcessingRepository.save(
                    EventProcessingRecord.builder()
                        .eventId(eventId)
                        .processedAt(Instant.now())
                        .build()
                );
                
            } catch (Exception e) {
                log.error("Failed to process order event: {}", eventId, e);
                throw e; // Let Kafka retry
            }
        }
        
        private void handleOrderCreated(OrderCreatedEvent event) {
            // Reserve inventory for order items
            for (OrderItem item : event.getItems()) {
                inventoryService.reserveItem(
                    item.getProductId(), 
                    item.getQuantity(),
                    event.getOrderId()
                );
            }
        }
        
        private void handleOrderCancelled(OrderCancelledEvent event) {
            // Release inventory reservations
            inventoryService.releaseReservation(event.getOrderId());
        }
        
        private void handleOrderShipped(OrderShippedEvent event) {
            // Commit inventory changes
            inventoryService.commitReservation(event.getOrderId());
        }
    }
}
```

### 3. Service Discovery and Load Balancing

```java
// Service discovery with Eureka and client-side load balancing
@Configuration
@EnableEurekaClient
public class ServiceDiscoveryConfig {
    
    @Bean
    @LoadBalanced
    public WebClient.Builder webClientBuilder() {
        return WebClient.builder()
            .codecs(configurer -> configurer.defaultCodecs().maxInMemorySize(2 * 1024 * 1024))
            .defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
    }
    
    @Bean
    public ReactorLoadBalancerExchangeFilterFunction lbFunction(
            ReactiveLoadBalancer.Factory<ServiceInstance> lbClientFactory) {
        return new ReactorLoadBalancerExchangeFilterFunction(lbClientFactory);
    }
}

@Service
public class ServiceDiscoveryManager {
    
    @Autowired
    private DiscoveryClient discoveryClient;
    
    @Autowired
    private LoadBalancerClient loadBalancerClient;
    
    @Autowired
    private ServiceHealthIndicator healthIndicator;
    
    public List<ServiceInstance> getAvailableInstances(String serviceName) {
        List<ServiceInstance> instances = discoveryClient.getInstances(serviceName);
        
        // Filter healthy instances
        return instances.stream()
            .filter(this::isInstanceHealthy)
            .collect(Collectors.toList());
    }
    
    public ServiceInstance chooseInstance(String serviceName) {
        ServiceInstance instance = loadBalancerClient.choose(serviceName);
        
        if (instance == null) {
            throw new ServiceUnavailableException(
                STR."No available instances for service: \{serviceName}");
        }
        
        return instance;
    }
    
    public URI getServiceUri(String serviceName, String path) {
        ServiceInstance instance = chooseInstance(serviceName);
        return UriComponentsBuilder
            .fromUri(instance.getUri())
            .path(path)
            .build()
            .toUri();
    }
    
    private boolean isInstanceHealthy(ServiceInstance instance) {
        try {
            // Perform health check
            WebClient webClient = WebClient.create();
            String healthUrl = STR."\{instance.getUri()}/actuator/health";
            
            String healthResponse = webClient
                .get()
                .uri(healthUrl)
                .retrieve()
                .bodyToMono(String.class)
                .timeout(Duration.ofSeconds(2))
                .block();
            
            return healthResponse != null && healthResponse.contains("\"status\":\"UP\"");
            
        } catch (Exception e) {
            log.debug("Health check failed for instance: {}", instance.getInstanceId(), e);
            return false;
        }
    }
    
    @EventListener
    public void handleServiceRegistration(InstanceRegisteredEvent event) {
        log.info("Service instance registered: {}", event.getInstanceInfo());
        
        // Warm up connection pools
        warmUpConnectionPools(event.getInstanceInfo().getAppName());
    }
    
    @EventListener
    public void handleServiceDeregistration(InstanceRegisteredEvent event) {
        log.info("Service instance deregistered: {}", event.getInstanceInfo());
        
        // Clean up connection pools
        cleanUpConnectionPools(event.getInstanceInfo().getAppName());
    }
    
    private void warmUpConnectionPools(String serviceName) {
        // Pre-establish connections to improve performance
        CompletableFuture.runAsync(() -> {
            try {
                List<ServiceInstance> instances = getAvailableInstances(serviceName);
                
                for (ServiceInstance instance : instances) {
                    // Make a lightweight request to warm up the connection
                    WebClient.create()
                        .get()
                        .uri(STR."\{instance.getUri()}/actuator/health")
                        .retrieve()
                        .bodyToMono(String.class)
                        .timeout(Duration.ofSeconds(1))
                        .subscribe();
                }
            } catch (Exception e) {
                log.debug("Failed to warm up connections for service: {}", serviceName, e);
            }
        });
    }
    
    private void cleanUpConnectionPools(String serviceName) {
        // Implementation for cleaning up connection pools
        connectionPoolManager.cleanup(serviceName);
    }
}
```

---

## 🌐 API Gateway Patterns

### 1. Centralized API Gateway

```java
// API Gateway with routing, authentication, and rate limiting
@Configuration
@EnableWebFluxSecurity
public class ApiGatewayConfig {
    
    @Bean
    public RouteLocator customRouteLocator(RouteLocatorBuilder builder) {
        return builder.routes()
            
            // User Service Routes
            .route("user-service", r -> r
                .path("/api/v1/users/**")
                .filters(f -> f
                    .circuitBreaker(c -> c
                        .setName("user-service-cb")
                        .setFallbackUri("/fallback/users"))
                    .requestRateLimiter(rl -> rl
                        .setRateLimiter(redisRateLimiter())
                        .setKeyResolver(userKeyResolver()))
                    .retry(retry -> retry
                        .setRetries(3)
                        .setBackoff(Duration.ofMillis(100), Duration.ofMillis(500), 2, true))
                    .addRequestHeader("X-Gateway-Source", "api-gateway")
                    .addResponseHeader("X-Gateway-Response-Time", 
                        () -> String.valueOf(System.currentTimeMillis())))
                .uri("lb://user-service"))
            
            // Product Service Routes  
            .route("product-service", r -> r
                .path("/api/v1/products/**")
                .filters(f -> f
                    .circuitBreaker(c -> c
                        .setName("product-service-cb")
                        .setFallbackUri("/fallback/products"))
                    .requestRateLimiter(rl -> rl
                        .setRateLimiter(redisRateLimiter())
                        .setKeyResolver(ipKeyResolver()))
                    .modifyRequestBody(String.class, String.class, 
                        (exchange, body) -> sanitizeProductRequest(body))
                    .modifyResponseBody(String.class, String.class,
                        (exchange, body) -> enrichProductResponse(body)))
                .uri("lb://product-service"))
            
            // Order Service Routes (requires authentication)
            .route("order-service", r -> r
                .path("/api/v1/orders/**")
                .and()
                .header("Authorization")
                .filters(f -> f
                    .filter(authenticationGatewayFilterFactory.apply(
                        new AuthenticationGatewayFilterFactory.Config()))
                    .circuitBreaker(c -> c
                        .setName("order-service-cb")
                        .setFallbackUri("/fallback/orders"))
                    .requestRateLimiter(rl -> rl
                        .setRateLimiter(strictRateLimiter())
                        .setKeyResolver(userKeyResolver()))
                    .addRequestHeader("X-User-ID", 
                        exchange -> extractUserIdFromToken(exchange)))
                .uri("lb://order-service"))
            
            // Admin Routes (strict authentication)
            .route("admin-routes", r -> r
                .path("/api/v1/admin/**")
                .filters(f -> f
                    .filter(adminAuthenticationGatewayFilterFactory.apply(
                        new AdminAuthenticationGatewayFilterFactory.Config()))
                    .requestRateLimiter(rl -> rl
                        .setRateLimiter(adminRateLimiter())
                        .setKeyResolver(userKeyResolver()))
                    .addRequestHeader("X-Admin-Request", "true"))
                .uri("lb://admin-service"))
            
            .build();
    }
    
    @Bean
    public RedisRateLimiter redisRateLimiter() {
        return new RedisRateLimiter(100, 200); // 100 requests per second, burst of 200
    }
    
    @Bean
    public RedisRateLimiter strictRateLimiter() {
        return new RedisRateLimiter(10, 50); // 10 requests per second, burst of 50
    }
    
    @Bean
    public RedisRateLimiter adminRateLimiter() {
        return new RedisRateLimiter(5, 10); // 5 requests per second, burst of 10
    }
    
    @Bean
    public KeyResolver userKeyResolver() {
        return exchange -> {
            String userId = extractUserIdFromRequest(exchange);
            return Mono.just(userId != null ? userId : "anonymous");
        };
    }
    
    @Bean
    public KeyResolver ipKeyResolver() {
        return exchange -> {
            String xForwardedFor = exchange.getRequest().getHeaders().getFirst("X-Forwarded-For");
            String clientIp = xForwardedFor != null ? 
                xForwardedFor.split(",")[0].trim() : 
                exchange.getRequest().getRemoteAddress().getAddress().getHostAddress();
            return Mono.just(clientIp);
        };
    }
    
    private String extractUserIdFromRequest(ServerWebExchange exchange) {
        // Extract user ID from JWT token or session
        String authHeader = exchange.getRequest().getHeaders().getFirst("Authorization");
        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            return jwtService.extractUserId(authHeader.substring(7));
        }
        return null;
    }
    
    private Mono<String> sanitizeProductRequest(String body) {
        // Sanitize product request body
        return Mono.just(requestSanitizer.sanitize(body));
    }
    
    private Mono<String> enrichProductResponse(String body) {
        // Add additional data to product responses
        return Mono.just(responseEnricher.enrich(body));
    }
}

// Custom authentication filter
@Component
public class AuthenticationGatewayFilterFactory 
        extends AbstractGatewayFilterFactory<AuthenticationGatewayFilterFactory.Config> {
    
    @Autowired
    private JwtService jwtService;
    
    @Autowired
    private UserService userService;
    
    public AuthenticationGatewayFilterFactory() {
        super(Config.class);
    }
    
    @Override
    public GatewayFilter apply(Config config) {
        return (exchange, chain) -> {
            ServerHttpRequest request = exchange.getRequest();
            
            String authHeader = request.getHeaders().getFirst("Authorization");
            if (authHeader == null || !authHeader.startsWith("Bearer ")) {
                return onError(exchange, "Missing or invalid Authorization header", HttpStatus.UNAUTHORIZED);
            }
            
            String token = authHeader.substring(7);
            
            return validateTokenAsync(token)
                .flatMap(claims -> {
                    if (claims != null && !claims.isEmpty()) {
                        // Add user context to request
                        ServerHttpRequest mutatedRequest = request.mutate()
                            .header("X-User-ID", claims.get("sub").toString())
                            .header("X-User-Roles", claims.get("roles").toString())
                            .header("X-User-Email", claims.get("email").toString())
                            .build();
                        
                        return chain.filter(exchange.mutate().request(mutatedRequest).build());
                    } else {
                        return onError(exchange, "Invalid token", HttpStatus.UNAUTHORIZED);
                    }
                })
                .onErrorResume(ex -> onError(exchange, "Authentication failed", HttpStatus.UNAUTHORIZED));
        };
    }
    
    private Mono<Map<String, Object>> validateTokenAsync(String token) {
        return Mono.fromCallable(() -> jwtService.validateToken(token))
            .subscribeOn(Schedulers.boundedElastic())
            .timeout(Duration.ofSeconds(2))
            .onErrorReturn(Collections.emptyMap());
    }
    
    private Mono<Void> onError(ServerWebExchange exchange, String err, HttpStatus httpStatus) {
        ServerHttpResponse response = exchange.getResponse();
        response.setStatusCode(httpStatus);
        response.getHeaders().add("Content-Type", "application/json");
        
        String body = STR."""
            {
                "error": "\{err}",
                "timestamp": "\{Instant.now()}",
                "path": "\{exchange.getRequest().getPath()}"
            }
            """;
        
        DataBuffer buffer = response.bufferFactory().wrap(body.getBytes());
        return response.writeWith(Mono.just(buffer));
    }
    
    public static class Config {
        private boolean validateAudience = true;
        private Duration timeout = Duration.ofSeconds(2);
        
        // Getters and setters
        public boolean isValidateAudience() { return validateAudience; }
        public void setValidateAudience(boolean validateAudience) { this.validateAudience = validateAudience; }
        
        public Duration getTimeout() { return timeout; }
        public void setTimeout(Duration timeout) { this.timeout = timeout; }
    }
}
```

### 2. Service Mesh with Istio

```yaml
# Istio service mesh configuration for microservices
apiVersion: networking.istio.io/v1alpha3
kind: VirtualService
metadata:
  name: ecommerce-routing
spec:
  hosts:
  - api.ecommerce.com
  gateways:
  - ecommerce-gateway
  http:
  # User service routing with fault injection
  - match:
    - uri:
        prefix: /api/v1/users
    fault:
      delay:
        percentage:
          value: 0.1
        fixedDelay: 5s
      abort:
        percentage:
          value: 0.01
        httpStatus: 500
    route:
    - destination:
        host: user-service
        subset: v1
      weight: 90
    - destination:
        host: user-service
        subset: v2
      weight: 10
    retries:
      attempts: 3
      perTryTimeout: 2s
    timeout: 10s
  
  # Product service routing with traffic splitting
  - match:
    - uri:
        prefix: /api/v1/products
    route:
    - destination:
        host: product-service
        subset: stable
      weight: 80
    - destination:
        host: product-service
        subset: canary
      weight: 20
  
  # Order service routing (authenticated users only)
  - match:
    - uri:
        prefix: /api/v1/orders
      headers:
        authorization:
          prefix: "Bearer "
    route:
    - destination:
        host: order-service
        subset: v1
    timeout: 30s

---
apiVersion: networking.istio.io/v1alpha3
kind: DestinationRule
metadata:
  name: ecommerce-destination-rules
spec:
  hosts:
  - user-service
  - product-service
  - order-service
  trafficPolicy:
    circuitBreaker:
      connectionPool:
        tcp:
          maxConnections: 100
        http:
          http1MaxPendingRequests: 50
          http2MaxRequests: 100
          maxRequestsPerConnection: 2
          maxRetries: 3
          consecutiveGatewayErrors: 5
          interval: 30s
          baseEjectionTime: 30s
          maxEjectionPercent: 50
  subsets:
  - name: v1
    labels:
      version: v1
  - name: v2
    labels:
      version: v2
  - name: stable
    labels:
      version: stable
  - name: canary
    labels:
      version: canary

---
apiVersion: security.istio.io/v1beta1
kind: PeerAuthentication
metadata:
  name: default
  namespace: ecommerce
spec:
  mtls:
    mode: STRICT

---
apiVersion: security.istio.io/v1beta1
kind: AuthorizationPolicy
metadata:
  name: order-service-authz
  namespace: ecommerce
spec:
  selector:
    matchLabels:
      app: order-service
  rules:
  - from:
    - source:
        principals: ["cluster.local/ns/ecommerce/sa/api-gateway"]
  - to:
    - operation:
        methods: ["GET", "POST", "PUT", "DELETE"]
  - when:
    - key: request.headers[authorization]
      values: ["Bearer *"]
```

---

## 📊 Monitoring and Observability

### 1. Distributed Tracing

```java
// Distributed tracing with OpenTelemetry
@Service
public class TracingService {
    
    private final Tracer tracer;
    private final MeterRegistry meterRegistry;
    
    public TracingService(Tracer tracer, MeterRegistry meterRegistry) {
        this.tracer = tracer;
        this.meterRegistry = meterRegistry;
    }
    
    @TraceAsync
    public CompletableFuture<OrderResult> processOrderWithTracing(CreateOrderRequest request) {
        return CompletableFuture.supplyAsync(() -> {
            Span span = tracer.nextSpan()
                .name("order-processing")
                .tag("order.user_id", request.getUserId())
                .tag("order.item_count", String.valueOf(request.getItems().size()))
                .tag("order.total_amount", request.getTotalAmount().toString())
                .start();
            
            try (Tracer.SpanInScope ws = tracer.withSpanInScope(span)) {
                // Add custom attributes
                span.setTag("service.name", "order-service");
                span.setTag("service.version", "1.0.0");
                
                // Step 1: Validate order
                Span validationSpan = tracer.nextSpan()
                    .name("order-validation")
                    .start();
                
                try (Tracer.SpanInScope validationScope = tracer.withSpanInScope(validationSpan)) {
                    validateOrder(request);
                    validationSpan.setTag("validation.result", "success");
                } catch (Exception e) {
                    validationSpan.setTag("validation.result", "failure");
                    validationSpan.setTag("error", e.getMessage());
                    throw e;
                } finally {
                    validationSpan.end();
                }
                
                // Step 2: Check inventory
                Span inventorySpan = tracer.nextSpan()
                    .name("inventory-check")
                    .start();
                
                try (Tracer.SpanInScope inventoryScope = tracer.withSpanInScope(inventorySpan)) {
                    InventoryCheckResult inventoryResult = checkInventory(request.getItems());
                    inventorySpan.setTag("inventory.available", String.valueOf(inventoryResult.isAvailable()));
                    inventorySpan.setTag("inventory.reserved_items", String.valueOf(inventoryResult.getReservedItems().size()));
                } finally {
                    inventorySpan.end();
                }
                
                // Step 3: Process payment
                Span paymentSpan = tracer.nextSpan()
                    .name("payment-processing")
                    .start();
                
                try (Tracer.SpanInScope paymentScope = tracer.withSpanInScope(paymentSpan)) {
                    PaymentResult paymentResult = processPayment(request);
                    paymentSpan.setTag("payment.method", paymentResult.getPaymentMethod());
                    paymentSpan.setTag("payment.status", paymentResult.getStatus());
                    paymentSpan.setTag("payment.transaction_id", paymentResult.getTransactionId());
                } finally {
                    paymentSpan.end();
                }
                
                // Step 4: Create order
                Order order = createOrder(request);
                
                span.setTag("order.id", order.getId());
                span.setTag("order.status", order.getStatus().toString());
                
                // Record metrics
                meterRegistry.counter("orders.created.total",
                    "user_id", request.getUserId(),
                    "status", "success"
                ).increment();
                
                meterRegistry.timer("orders.processing.duration").record(() -> {
                    // Processing time is automatically recorded
                });
                
                return OrderResult.from(order);
                
            } catch (Exception e) {
                span.setTag("error", true);
                span.setTag("error.message", e.getMessage());
                span.setTag("error.type", e.getClass().getSimpleName());
                
                // Record error metrics
                meterRegistry.counter("orders.created.total",
                    "user_id", request.getUserId(),
                    "status", "failure",
                    "error_type", e.getClass().getSimpleName()
                ).increment();
                
                throw e;
            } finally {
                span.end();
            }
        });
    }
    
    // Cross-service tracing
    @NewSpan("external-service-call")
    public UserProfile getUserProfileWithTracing(@SpanTag("user_id") String userId) {
        Span currentSpan = tracer.currentSpan();
        
        // Add correlation ID for request tracking
        String correlationId = UUID.randomUUID().toString();
        currentSpan.setTag("correlation.id", correlationId);
        
        try {
            UserProfile profile = webClient
                .get()
                .uri("/api/v1/users/{userId}", userId)
                .header("X-Correlation-ID", correlationId)
                .header("X-Trace-ID", currentSpan.context().traceId())
                .header("X-Span-ID", currentSpan.context().spanId())
                .retrieve()
                .bodyToMono(UserProfile.class)
                .timeout(Duration.ofSeconds(5))
                .block();
            
            currentSpan.setTag("user.profile.found", profile != null);
            if (profile != null) {
                currentSpan.setTag("user.profile.email", profile.getEmail());
                currentSpan.setTag("user.profile.status", profile.getStatus());
            }
            
            return profile;
            
        } catch (Exception e) {
            currentSpan.setTag("error", true);
            currentSpan.setTag("error.message", e.getMessage());
            throw e;
        }
    }
    
    // Custom span creation for business logic
    public void processComplexBusinessLogic(String entityId) {
        Span businessSpan = tracer.nextSpan()
            .name("complex-business-logic")
            .tag("entity.id", entityId)
            .start();
        
        try (Tracer.SpanInScope ws = tracer.withSpanInScope(businessSpan)) {
            // Nested span for database operations
            Span dbSpan = tracer.nextSpan()
                .name("database-operations")
                .tag("db.type", "postgresql")
                .start();
            
            try (Tracer.SpanInScope dbScope = tracer.withSpanInScope(dbSpan)) {
                // Database operations
                performDatabaseOperations(entityId);
                dbSpan.setTag("db.rows_affected", "5");
            } finally {
                dbSpan.end();
            }
            
            // Nested span for external API calls
            Span apiSpan = tracer.nextSpan()
                .name("external-api-calls")
                .tag("api.endpoint", "/external/service")
                .start();
            
            try (Tracer.SpanInScope apiScope = tracer.withSpanInScope(apiSpan)) {
                // External API calls
                callExternalAPIs(entityId);
                apiSpan.setTag("api.response.status", "200");
            } finally {
                apiSpan.end();
            }
            
            businessSpan.setTag("business.logic.result", "success");
            
        } catch (Exception e) {
            businessSpan.setTag("error", true);
            businessSpan.setTag("error.message", e.getMessage());
            throw e;
        } finally {
            businessSpan.end();
        }
    }
}
```

### 2. Centralized Logging

```java
// Centralized logging with structured logging and correlation IDs
@Component
public class StructuredLoggingService {
    
    private final Logger log = LoggerFactory.getLogger(StructuredLoggingService.class);
    private final ObjectMapper objectMapper;
    
    public StructuredLoggingService(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }
    
    public void logOrderEvent(OrderEvent event, String action, Map<String, Object> context) {
        try {
            LogEntry logEntry = LogEntry.builder()
                .timestamp(Instant.now())
                .level("INFO")
                .service("order-service")
                .action(action)
                .correlationId(MDC.get("correlationId"))
                .traceId(MDC.get("traceId"))
                .spanId(MDC.get("spanId"))
                .userId(event.getUserId())
                .orderId(event.getOrderId())
                .eventType(event.getEventType())
                .context(context)
                .build();
            
            String jsonLog = objectMapper.writeValueAsString(logEntry);
            log.info(jsonLog);
            
        } catch (Exception e) {
            log.error("Failed to create structured log entry", e);
        }
    }
    
    public void logError(String action, Exception error, Map<String, Object> context) {
        try {
            ErrorLogEntry errorEntry = ErrorLogEntry.builder()
                .timestamp(Instant.now())
                .level("ERROR")
                .service("order-service")
                .action(action)
                .correlationId(MDC.get("correlationId"))
                .traceId(MDC.get("traceId"))
                .spanId(MDC.get("spanId"))
                .errorType(error.getClass().getSimpleName())
                .errorMessage(error.getMessage())
                .stackTrace(getStackTrace(error))
                .context(context)
                .build();
            
            String jsonLog = objectMapper.writeValueAsString(errorEntry);
            log.error(jsonLog);
            
        } catch (Exception e) {
            log.error("Failed to create error log entry", e);
        }
    }
    
    public void logPerformanceMetrics(String operation, Duration duration, 
                                    Map<String, Object> metrics) {
        try {
            PerformanceLogEntry perfEntry = PerformanceLogEntry.builder()
                .timestamp(Instant.now())
                .level("INFO")
                .service("order-service")
                .operation(operation)
                .correlationId(MDC.get("correlationId"))
                .traceId(MDC.get("traceId"))
                .durationMs(duration.toMillis())
                .metrics(metrics)
                .build();
            
            String jsonLog = objectMapper.writeValueAsString(perfEntry);
            log.info(jsonLog);
            
        } catch (Exception e) {
            log.error("Failed to create performance log entry", e);
        }
    }
    
    private String getStackTrace(Exception error) {
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        error.printStackTrace(pw);
        return sw.toString();
    }
    
    @Data
    @Builder
    public static class LogEntry {
        private Instant timestamp;
        private String level;
        private String service;
        private String action;
        private String correlationId;
        private String traceId;
        private String spanId;
        private String userId;
        private String orderId;
        private String eventType;
        private Map<String, Object> context;
    }
    
    @Data
    @Builder
    public static class ErrorLogEntry {
        private Instant timestamp;
        private String level;
        private String service;
        private String action;
        private String correlationId;
        private String traceId;
        private String spanId;
        private String errorType;
        private String errorMessage;
        private String stackTrace;
        private Map<String, Object> context;
    }
    
    @Data
    @Builder
    public static class PerformanceLogEntry {
        private Instant timestamp;
        private String level;
        private String service;
        private String operation;
        private String correlationId;
        private String traceId;
        private long durationMs;
        private Map<String, Object> metrics;
    }
}

// Correlation ID filter for request tracking
@Component
@Order(Ordered.HIGHEST_PRECEDENCE)
public class CorrelationIdFilter implements Filter {
    
    private static final String CORRELATION_ID_HEADER = "X-Correlation-ID";
    private static final String TRACE_ID_HEADER = "X-Trace-ID";
    private static final String SPAN_ID_HEADER = "X-Span-ID";
    
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, 
                        FilterChain chain) throws IOException, ServletException {
        
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;
        
        // Extract or generate correlation ID
        String correlationId = httpRequest.getHeader(CORRELATION_ID_HEADER);
        if (correlationId == null || correlationId.trim().isEmpty()) {
            correlationId = UUID.randomUUID().toString();
        }
        
        // Extract tracing headers
        String traceId = httpRequest.getHeader(TRACE_ID_HEADER);
        String spanId = httpRequest.getHeader(SPAN_ID_HEADER);
        
        // Set MDC for logging
        MDC.put("correlationId", correlationId);
        if (traceId != null) MDC.put("traceId", traceId);
        if (spanId != null) MDC.put("spanId", spanId);
        
        // Add to response headers
        httpResponse.setHeader(CORRELATION_ID_HEADER, correlationId);
        
        try {
            chain.doFilter(request, response);
        } finally {
            // Clean up MDC
            MDC.remove("correlationId");
            MDC.remove("traceId");
            MDC.remove("spanId");
        }
    }
}
```

---

## 🎯 Interview Focus Areas

### Key Microservices Questions

**Q: How do you decompose a monolith into microservices?**
- **Domain-driven design** with bounded contexts
- **Database per service** pattern
- **Strangler fig pattern** for gradual migration
- **Event-driven communication** for loose coupling

**Q: How do you handle distributed transactions?**
- **Saga pattern** with orchestration or choreography
- **Two-phase commit** for strong consistency (limited use)
- **Event sourcing** for audit trails
- **Compensation actions** for rollback

**Q: How do you ensure service reliability?**
- **Circuit breaker** pattern for fault isolation
- **Retry mechanisms** with exponential backoff
- **Bulkhead pattern** for resource isolation
- **Health checks** and automatic failover

**Q: How do you handle service discovery and communication?**
- **Service registry** (Eureka, Consul)
- **Client-side load balancing**
- **API Gateway** for external communication
- **Service mesh** for internal communication

---

## 🚀 Next Steps

1. **Complete the hands-on exercises** in the exercises folder
2. **Practice service decomposition** strategies
3. **Implement distributed tracing** in your applications
4. **Design API gateways** with proper routing and security
5. **Move to Module 8: Data Consistency Patterns**

The microservices module provides the foundation for building scalable, resilient distributed systems that can handle enterprise-level complexity while maintaining operational simplicity.
