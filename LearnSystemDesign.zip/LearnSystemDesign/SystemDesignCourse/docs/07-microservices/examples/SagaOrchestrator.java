/* // Saga Orchestrator Implementation for Microservices
// Demonstrates distributed transaction patterns for system design interviews

package com.systemdesign.microservices.examples;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.scheduling.annotation.Async;

import java.time.Instant;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Production-ready Saga Orchestrator for managing distributed transactions
 * Demonstrates patterns commonly asked in system design interviews
 */
@Service
public class SagaOrchestrator {
    
    @Autowired
    private SagaRepository sagaRepository;
    
    @Autowired
    private SagaStepRepository stepRepository;
    
    @Autowired
    private ApplicationEventPublisher eventPublisher;
    
    @Autowired
    private SagaMetrics sagaMetrics;
    
    private final Map<String, SagaDefinition> sagaDefinitions = new ConcurrentHashMap<>();
    private final Map<String, SagaExecution> activeSagas = new ConcurrentHashMap<>();
    
    /**
     * Order Processing Saga - Complex multi-service transaction
     */
    public String startOrderProcessingSaga(OrderProcessingRequest request) {
        String sagaId = UUID.randomUUID().toString();
        
        // Define saga steps
        SagaDefinition sagaDefinition = SagaDefinition.builder()
            .sagaId(sagaId)
            .sagaType("ORDER_PROCESSING")
            .steps(Arrays.asList(
                createSagaStep("VALIDATE_USER", this::validateUser, this::compensateValidateUser),
                createSagaStep("RESERVE_INVENTORY", this::reserveInventory, this::compensateReserveInventory),
                createSagaStep("PROCESS_PAYMENT", this::processPayment, this::compensateProcessPayment),
                createSagaStep("CREATE_SHIPMENT", this::createShipment, this::compensateCreateShipment),
                createSagaStep("SEND_CONFIRMATION", this::sendConfirmation, this::compensateSendConfirmation)
            ))
            .timeout(Duration.ofMinutes(10))
            .build();
        
        sagaDefinitions.put(sagaId, sagaDefinition);
        
        // Create saga execution context
        SagaExecution execution = SagaExecution.builder()
            .sagaId(sagaId)
            .sagaType("ORDER_PROCESSING")
            .status(SagaStatus.STARTED)
            .context(createOrderContext(request))
            .startTime(Instant.now())
            .currentStepIndex(0)
            .build();
        
        activeSagas.put(sagaId, execution);
        
        // Persist saga state
        persistSagaState(execution);
        
        // Start execution
        executeNextStep(sagaId);
        
        sagaMetrics.recordSagaStarted("ORDER_PROCESSING");
        
        return sagaId;
    }
    
    /**
     * Execute the next step in the saga
     */
    @Async
    public void executeNextStep(String sagaId) {
        SagaExecution execution = activeSagas.get(sagaId);
        SagaDefinition definition = sagaDefinitions.get(sagaId);
        
        if (execution == null || definition == null) {
            log.error("Saga not found: {}", sagaId);
            return;
        }
        
        if (execution.getCurrentStepIndex() >= definition.getSteps().size()) {
            // All steps completed successfully
            completeSaga(sagaId);
            return;
        }
        
        SagaStep currentStep = definition.getSteps().get(execution.getCurrentStepIndex());
        
        try {
            log.info("Executing saga step: {} for saga: {}", currentStep.getName(), sagaId);
            
            // Execute step
            Timer.Sample sample = sagaMetrics.startStepTimer();
            SagaStepResult result = currentStep.getAction().execute(execution.getContext());
            sample.stop();
            
            if (result.isSuccess()) {
                // Step succeeded, move to next step
                execution.setCurrentStepIndex(execution.getCurrentStepIndex() + 1);
                execution.getCompletedSteps().add(currentStep.getName());
                
                // Update context with step result
                execution.getContext().putAll(result.getContextUpdates());
                
                persistSagaState(execution);
                
                sagaMetrics.recordStepSuccess(currentStep.getName());
                
                // Execute next step
                executeNextStep(sagaId);
                
            } else {
                // Step failed, start compensation
                log.warn("Saga step failed: {} for saga: {}, reason: {}", 
                    currentStep.getName(), sagaId, result.getErrorMessage());
                
                execution.setStatus(SagaStatus.COMPENSATING);
                execution.setFailureReason(result.getErrorMessage());
                
                persistSagaState(execution);
                
                sagaMetrics.recordStepFailure(currentStep.getName(), result.getErrorMessage());
                
                // Start compensation process
                startCompensation(sagaId);
            }
            
        } catch (Exception e) {
            log.error("Unexpected error executing saga step: {} for saga: {}", 
                currentStep.getName(), sagaId, e);
            
            execution.setStatus(SagaStatus.COMPENSATING);
            execution.setFailureReason(e.getMessage());
            
            persistSagaState(execution);
            
            sagaMetrics.recordStepError(currentStep.getName(), e);
            
            // Start compensation process
            startCompensation(sagaId);
        }
    }
    
    /**
     * Start compensation process (rollback)
     */
    @Async
    public void startCompensation(String sagaId) {
        SagaExecution execution = activeSagas.get(sagaId);
        SagaDefinition definition = sagaDefinitions.get(sagaId);
        
        if (execution == null || definition == null) {
            log.error("Saga not found for compensation: {}", sagaId);
            return;
        }
        
        log.info("Starting compensation for saga: {}", sagaId);
        
        // Compensate completed steps in reverse order
        List<String> completedSteps = new ArrayList<>(execution.getCompletedSteps());
        Collections.reverse(completedSteps);
        
        for (String stepName : completedSteps) {
            try {
                SagaStep step = definition.getSteps().stream()
                    .filter(s -> s.getName().equals(stepName))
                    .findFirst()
                    .orElse(null);
                
                if (step != null && step.getCompensationAction() != null) {
                    log.info("Compensating step: {} for saga: {}", stepName, sagaId);
                    
                    Timer.Sample sample = sagaMetrics.startCompensationTimer();
                    SagaStepResult compensationResult = step.getCompensationAction().execute(execution.getContext());
                    sample.stop();
                    
                    if (compensationResult.isSuccess()) {
                        sagaMetrics.recordCompensationSuccess(stepName);
                    } else {
                        log.error("Compensation failed for step: {} in saga: {}, reason: {}", 
                            stepName, sagaId, compensationResult.getErrorMessage());
                        sagaMetrics.recordCompensationFailure(stepName, compensationResult.getErrorMessage());
                    }
                } else {
                    log.warn("No compensation action defined for step: {}", stepName);
                }
                
            } catch (Exception e) {
                log.error("Error during compensation for step: {} in saga: {}", stepName, sagaId, e);
                sagaMetrics.recordCompensationError(stepName, e);
            }
        }
        
        // Mark saga as compensated
        execution.setStatus(SagaStatus.COMPENSATED);
        execution.setEndTime(Instant.now());
        
        persistSagaState(execution);
        activeSagas.remove(sagaId);
        
        // Publish saga compensated event
        publishSagaEvent(new SagaCompensatedEvent(sagaId, execution.getFailureReason()));
        
        sagaMetrics.recordSagaCompensated("ORDER_PROCESSING");
        
        log.info("Saga compensation completed: {}", sagaId);
    }
    
    /**
     * Complete saga successfully
     */
    private void completeSaga(String sagaId) {
        SagaExecution execution = activeSagas.get(sagaId);
        
        if (execution != null) {
            execution.setStatus(SagaStatus.COMPLETED);
            execution.setEndTime(Instant.now());
            
            persistSagaState(execution);
            activeSagas.remove(sagaId);
            
            // Publish saga completed event
            publishSagaEvent(new SagaCompletedEvent(sagaId, execution.getContext()));
            
            sagaMetrics.recordSagaCompleted("ORDER_PROCESSING");
            
            log.info("Saga completed successfully: {}", sagaId);
        }
    }
    
    /**
     * Saga step implementations
     */
    
    private SagaStepResult validateUser(Map<String, Object> context) {
        try {
            String userId = (String) context.get("userId");
            log.info("Validating user: {}", userId);
            
            // Call User Service
            UserProfile userProfile = userServiceClient.getUserProfile(userId)
                .orElseThrow(() -> new UserNotFoundException("User not found: " + userId));
            
            if (!userProfile.isActive()) {
                return SagaStepResult.failure("User account is not active");
            }
            
            // Add user profile to context
            Map<String, Object> updates = Map.of("userProfile", userProfile);
            
            return SagaStepResult.success(updates);
            
        } catch (Exception e) {
            return SagaStepResult.failure("User validation failed: " + e.getMessage());
        }
    }
    
    private SagaStepResult reserveInventory(Map<String, Object> context) {
        try {
            @SuppressWarnings("unchecked")
            List<OrderItem> items = (List<OrderItem>) context.get("orderItems");
            String orderId = (String) context.get("orderId");
            
            log.info("Reserving inventory for order: {}", orderId);
            
            // Call Inventory Service
            InventoryReservationResult result = inventoryServiceClient.reserveItems(
                InventoryReservationRequest.builder()
                    .orderId(orderId)
                    .items(items)
                    .build()
            );
            
            if (!result.isSuccess()) {
                return SagaStepResult.failure("Inventory reservation failed: " + result.getFailureReason());
            }
            
            // Add reservation details to context
            Map<String, Object> updates = Map.of(
                "reservationId", result.getReservationId(),
                "reservedItems", result.getReservedItems()
            );
            
            return SagaStepResult.success(updates);
            
        } catch (Exception e) {
            return SagaStepResult.failure("Inventory reservation failed: " + e.getMessage());
        }
    }
    
    private SagaStepResult processPayment(Map<String, Object> context) {
        try {
            String userId = (String) context.get("userId");
            BigDecimal amount = (BigDecimal) context.get("totalAmount");
            String paymentMethodId = (String) context.get("paymentMethodId");
            String orderId = (String) context.get("orderId");
            
            log.info("Processing payment for order: {}, amount: {}", orderId, amount);
            
            // Call Payment Service
            PaymentResult result = paymentServiceClient.processPayment(
                PaymentRequest.builder()
                    .orderId(orderId)
                    .userId(userId)
                    .amount(amount)
                    .paymentMethodId(paymentMethodId)
                    .build()
            );
            
            if (!result.isSuccess()) {
                return SagaStepResult.failure("Payment processing failed: " + result.getFailureReason());
            }
            
            // Add payment details to context
            Map<String, Object> updates = Map.of(
                "paymentId", result.getPaymentId(),
                "transactionId", result.getTransactionId()
            );
            
            return SagaStepResult.success(updates);
            
        } catch (Exception e) {
            return SagaStepResult.failure("Payment processing failed: " + e.getMessage());
        }
    }
    
    private SagaStepResult createShipment(Map<String, Object> context) {
        try {
            String orderId = (String) context.get("orderId");
            @SuppressWarnings("unchecked")
            Map<String, Object> shippingAddress = (Map<String, Object>) context.get("shippingAddress");
            @SuppressWarnings("unchecked")
            List<OrderItem> items = (List<OrderItem>) context.get("orderItems");
            
            log.info("Creating shipment for order: {}", orderId);
            
            // Call Shipping Service
            ShipmentResult result = shippingServiceClient.createShipment(
                ShipmentRequest.builder()
                    .orderId(orderId)
                    .shippingAddress(shippingAddress)
                    .items(items)
                    .build()
            );
            
            if (!result.isSuccess()) {
                return SagaStepResult.failure("Shipment creation failed: " + result.getFailureReason());
            }
            
            // Add shipment details to context
            Map<String, Object> updates = Map.of(
                "shipmentId", result.getShipmentId(),
                "trackingNumber", result.getTrackingNumber(),
                "estimatedDeliveryDate", result.getEstimatedDeliveryDate()
            );
            
            return SagaStepResult.success(updates);
            
        } catch (Exception e) {
            return SagaStepResult.failure("Shipment creation failed: " + e.getMessage());
        }
    }
    
    private SagaStepResult sendConfirmation(Map<String, Object> context) {
        try {
            String userId = (String) context.get("userId");
            String orderId = (String) context.get("orderId");
            String trackingNumber = (String) context.get("trackingNumber");
            
            log.info("Sending confirmation for order: {}", orderId);
            
            // Call Notification Service
            NotificationResult result = notificationServiceClient.sendOrderConfirmation(
                OrderConfirmationRequest.builder()
                    .userId(userId)
                    .orderId(orderId)
                    .trackingNumber(trackingNumber)
                    .build()
            );
            
            if (!result.isSuccess()) {
                // Non-critical step - log warning but don't fail saga
                log.warn("Order confirmation failed for order: {}, reason: {}", 
                    orderId, result.getFailureReason());
            }
            
            return SagaStepResult.success(Collections.emptyMap());
            
        } catch (Exception e) {
            // Non-critical step - log warning but don't fail saga
            log.warn("Order confirmation failed for order: {}", context.get("orderId"), e);
            return SagaStepResult.success(Collections.emptyMap());
        }
    }
    
    /**
     * Compensation methods
     */
    
    private SagaStepResult compensateValidateUser(Map<String, Object> context) {
        // No compensation needed for user validation
        return SagaStepResult.success(Collections.emptyMap());
    }
    
    private SagaStepResult compensateReserveInventory(Map<String, Object> context) {
        try {
            String reservationId = (String) context.get("reservationId");
            if (reservationId != null) {
                log.info("Releasing inventory reservation: {}", reservationId);
                inventoryServiceClient.releaseReservation(reservationId);
            }
            return SagaStepResult.success(Collections.emptyMap());
        } catch (Exception e) {
            return SagaStepResult.failure("Failed to release inventory reservation: " + e.getMessage());
        }
    }
    
    private SagaStepResult compensateProcessPayment(Map<String, Object> context) {
        try {
            String paymentId = (String) context.get("paymentId");
            if (paymentId != null) {
                log.info("Refunding payment: {}", paymentId);
                paymentServiceClient.refundPayment(paymentId);
            }
            return SagaStepResult.success(Collections.emptyMap());
        } catch (Exception e) {
            return SagaStepResult.failure("Failed to refund payment: " + e.getMessage());
        }
    }
    
    private SagaStepResult compensateCreateShipment(Map<String, Object> context) {
        try {
            String shipmentId = (String) context.get("shipmentId");
            if (shipmentId != null) {
                log.info("Cancelling shipment: {}", shipmentId);
                shippingServiceClient.cancelShipment(shipmentId);
            }
            return SagaStepResult.success(Collections.emptyMap());
        } catch (Exception e) {
            return SagaStepResult.failure("Failed to cancel shipment: " + e.getMessage());
        }
    }
    
    private SagaStepResult compensateSendConfirmation(Map<String, Object> context) {
        // No compensation needed for notifications
        return SagaStepResult.success(Collections.emptyMap());
    }
    
    /**
     * Helper methods
     */
    
    private SagaStep createSagaStep(String name, SagaStepAction action, SagaStepAction compensationAction) {
        return SagaStep.builder()
            .name(name)
            .action(action)
            .compensationAction(compensationAction)
            .timeout(Duration.ofSeconds(30))
            .build();
    }
    
    private Map<String, Object> createOrderContext(OrderProcessingRequest request) {
        Map<String, Object> context = new HashMap<>();
        context.put("orderId", request.getOrderId());
        context.put("userId", request.getUserId());
        context.put("orderItems", request.getItems());
        context.put("totalAmount", request.getTotalAmount());
        context.put("paymentMethodId", request.getPaymentMethodId());
        context.put("shippingAddress", request.getShippingAddress());
        return context;
    }
    
    private void persistSagaState(SagaExecution execution) {
        try {
            sagaRepository.save(SagaStateRecord.from(execution));
        } catch (Exception e) {
            log.error("Failed to persist saga state for saga: {}", execution.getSagaId(), e);
        }
    }
    
    private void publishSagaEvent(SagaEvent event) {
        try {
            eventPublisher.publishEvent(event);
        } catch (Exception e) {
            log.error("Failed to publish saga event: {}", event.getClass().getSimpleName(), e);
        }
    }
    
    /**
     * Saga recovery for failed instances
     */
    @Scheduled(fixedRate = 60000) // Every minute
    public void recoverStallSagas() {
        try {
            Instant cutoff = Instant.now().minus(Duration.ofMinutes(5));
            
            List<SagaStateRecord> stalledSagas = sagaRepository.findStalledSagas(cutoff);
            
            for (SagaStateRecord record : stalledSagas) {
                log.info("Recovering stalled saga: {}", record.getSagaId());
                
                // Recreate saga execution
                SagaExecution execution = SagaExecution.from(record);
                activeSagas.put(record.getSagaId(), execution);
                
                // Resume execution based on status
                if (execution.getStatus() == SagaStatus.STARTED) {
                    executeNextStep(execution.getSagaId());
                } else if (execution.getStatus() == SagaStatus.COMPENSATING) {
                    startCompensation(execution.getSagaId());
                }
            }
            
        } catch (Exception e) {
            log.error("Error during saga recovery", e);
        }
    }
    
    /**
     * Get saga status
     */
    public SagaStatus getSagaStatus(String sagaId) {
        SagaExecution execution = activeSagas.get(sagaId);
        if (execution != null) {
            return execution.getStatus();
        }
        
        // Check persisted state
        return sagaRepository.findBySagaId(sagaId)
            .map(SagaStateRecord::getStatus)
            .orElse(null);
    }
    
    /**
     * Cancel saga
     */
    public void cancelSaga(String sagaId) {
        SagaExecution execution = activeSagas.get(sagaId);
        if (execution != null && execution.getStatus() == SagaStatus.STARTED) {
            execution.setStatus(SagaStatus.COMPENSATING);
            execution.setFailureReason("Manually cancelled");
            
            persistSagaState(execution);
            startCompensation(sagaId);
            
            sagaMetrics.recordSagaCancelled("ORDER_PROCESSING");
        }
    }
}

// Supporting classes and interfaces

@FunctionalInterface
interface SagaStepAction {
    SagaStepResult execute(Map<String, Object> context) throws Exception;
}

@Data
@Builder
class SagaStep {
    private String name;
    private SagaStepAction action;
    private SagaStepAction compensationAction;
    private Duration timeout;
}

@Data
@Builder
class SagaDefinition {
    private String sagaId;
    private String sagaType;
    private List<SagaStep> steps;
    private Duration timeout;
}

@Data
@Builder
class SagaExecution {
    private String sagaId;
    private String sagaType;
    private SagaStatus status;
    private Map<String, Object> context;
    private Instant startTime;
    private Instant endTime;
    private int currentStepIndex;
    private List<String> completedSteps = new ArrayList<>();
    private String failureReason;
    
    public static SagaExecution from(SagaStateRecord record) {
        return SagaExecution.builder()
            .sagaId(record.getSagaId())
            .sagaType(record.getSagaType())
            .status(record.getStatus())
            .context(record.getContext())
            .startTime(record.getStartTime())
            .endTime(record.getEndTime())
            .currentStepIndex(record.getCurrentStepIndex())
            .completedSteps(record.getCompletedSteps())
            .failureReason(record.getFailureReason())
            .build();
    }
}

@Data
@Builder
class SagaStepResult {
    private boolean success;
    private String errorMessage;
    private Map<String, Object> contextUpdates;
    
    public static SagaStepResult success(Map<String, Object> contextUpdates) {
        return SagaStepResult.builder()
            .success(true)
            .contextUpdates(contextUpdates)
            .build();
    }
    
    public static SagaStepResult failure(String errorMessage) {
        return SagaStepResult.builder()
            .success(false)
            .errorMessage(errorMessage)
            .contextUpdates(Collections.emptyMap())
            .build();
    }
}

enum SagaStatus {
    STARTED, COMPLETED, COMPENSATING, COMPENSATED, FAILED
}

// Event classes
abstract class SagaEvent {
    protected String sagaId;
    protected Instant timestamp = Instant.now();
}

class SagaCompletedEvent extends SagaEvent {
    private Map<String, Object> context;
    
    public SagaCompletedEvent(String sagaId, Map<String, Object> context) {
        this.sagaId = sagaId;
        this.context = context;
    }
}

class SagaCompensatedEvent extends SagaEvent {
    private String failureReason;
    
    public SagaCompensatedEvent(String sagaId, String failureReason) {
        this.sagaId = sagaId;
        this.failureReason = failureReason;
    }
}
 */