# Mock Interview Sessions - System Design

## 🎯 Complete Mock Interview Practice

This document provides comprehensive mock interview sessions for practicing system design interviews at top tech companies.

---

## 📋 **Interview Session 1: Design a URL Shortener (Bit.ly)**

### **Interview Format: 45 minutes**

#### **Phase 1: Requirements Gathering (5-8 minutes)**

**Interviewer Questions:**
- "Design a URL shortening service like bit.ly. What would you include?"

**Expected Candidate Approach:**
1. **Clarify functional requirements:**
   - Shorten long URLs to shorter ones
   - Redirect short URLs to original URLs
   - Custom aliases (optional)
   - Analytics (click tracking)
   - URL expiration

2. **Clarify non-functional requirements:**
   - Scale: 100M URLs shortened per day
   - Read:Write ratio 100:1 (heavy read)
   - Latency: < 100ms for redirects
   - Availability: 99.9%
   - Storage: 5 years retention

3. **Capacity Estimation:**
   - Writes: 100M/day = 1,157 writes/second
   - Reads: 11.57K reads/second
   - Storage: 100M * 365 * 5 = 182.5B URLs
   - Bandwidth: Assuming 500 bytes per URL = 50GB/day

#### **Phase 2: High-Level Design (10-15 minutes)**

**Expected Components:**
```
[Client] → [Load Balancer] → [API Gateway] → [URL Service]
                                          ↓
[Cache Layer (Redis)] ← [Database (NoSQL/SQL)]
                                          ↓
                                    [Analytics Service]
```

**Key APIs:**
```
POST /api/v1/shorten
{
  "originalUrl": "https://example.com/very/long/url",
  "customAlias": "mylink", // optional
  "expirationDate": "2024-12-31" // optional
}

GET /api/v1/{shortUrl}
→ 302 Redirect to original URL
```

#### **Phase 3: Detailed Design (15-20 minutes)**

**URL Encoding Algorithm:**
```java
public class URLEncoder {
    private static final String BASE62 = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    
    public String encode(long id) {
        StringBuilder encoded = new StringBuilder();
        while (id > 0) {
            encoded.append(BASE62.charAt((int)(id % 62)));
            id /= 62;
        }
        return encoded.reverse().toString();
    }
    
    public long decode(String encoded) {
        long decoded = 0;
        for (char c : encoded.toCharArray()) {
            decoded = decoded * 62 + BASE62.indexOf(c);
        }
        return decoded;
    }
}
```

**Database Schema:**
```sql
-- URLs table
CREATE TABLE urls (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    short_url VARCHAR(10) UNIQUE NOT NULL,
    original_url TEXT NOT NULL,
    user_id BIGINT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP,
    click_count BIGINT DEFAULT 0,
    INDEX idx_short_url (short_url),
    INDEX idx_user_id (user_id)
);

-- Analytics table (separate for performance)
CREATE TABLE url_analytics (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    short_url VARCHAR(10),
    ip_address VARCHAR(45),
    user_agent TEXT,
    referer TEXT,
    clicked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_short_url_time (short_url, clicked_at)
);
```

**Caching Strategy:**
- Cache popular URLs in Redis
- TTL based on access frequency
- Cache-aside pattern
- Precompute analytics for dashboards

#### **Phase 4: Scale and Optimization (8-10 minutes)**

**Scaling Solutions:**
1. **Database Sharding:** Shard by URL hash
2. **Caching:** Multi-level caching (CDN + Redis)
3. **Analytics:** Use Kafka + time-series DB
4. **Global Distribution:** Deploy in multiple regions

**Deep Dive Questions:**
- "How would you handle 1 billion URLs?"
- "What if a URL goes viral and gets 1M clicks/minute?"
- "How would you prevent abuse?"

---

## 📋 **Interview Session 2: Design a Chat System (WhatsApp)**

### **Interview Format: 45 minutes**

#### **Phase 1: Requirements Gathering (5-8 minutes)**

**Expected Requirements:**
1. **Functional:**
   - Send/receive messages (1-on-1 and group)
   - Online status
   - Message delivery confirmation
   - Push notifications
   - Media sharing

2. **Non-Functional:**
   - 500M daily active users
   - 40 billion messages/day
   - Real-time delivery < 1 second
   - 99.99% availability

3. **Capacity Estimation:**
   - Messages/second: 40B/86400 = 462K/sec
   - Storage: 40B * 100 bytes = 4TB/day
   - Bandwidth: Peak traffic 5x = 2.3M messages/sec

#### **Phase 2: High-Level Architecture (10-15 minutes)**

```
[Mobile Client] ←→ [WebSocket Gateway] ←→ [Message Service]
                          ↓                      ↓
[Push Notification] ← [Notification Service] → [Message Queue]
                                                   ↓
[User Service] ← [Database (Cassandra)] ← [Message Storage]
     ↓
[Presence Service]
```

#### **Phase 3: Detailed Design (15-20 minutes)**

**WebSocket Connection Management:**
```java
@Component
public class WebSocketConnectionManager {
    private final Map<String, WebSocketSession> userSessions = new ConcurrentHashMap<>();
    private final Map<String, Set<String>> serverConnections = new ConcurrentHashMap<>();
    
    public void handleUserConnection(String userId, WebSocketSession session) {
        userSessions.put(userId, session);
        updateUserPresence(userId, UserStatus.ONLINE);
        
        // Register connection with discovery service
        serviceDiscovery.registerUserConnection(userId, getServerNodeId());
    }
    
    public void sendMessage(String toUserId, Message message) {
        WebSocketSession session = userSessions.get(toUserId);
        
        if (session != null && session.isOpen()) {
            // User connected to this server
            sendDirectly(session, message);
        } else {
            // User might be on different server
            String serverNode = serviceDiscovery.getUserServer(toUserId);
            if (serverNode != null) {
                forwardToServer(serverNode, toUserId, message);
            } else {
                // User offline - queue for delivery
                messageQueue.enqueue(toUserId, message);
                sendPushNotification(toUserId, message);
            }
        }
    }
}
```

**Message Storage Schema:**
```sql
-- Messages table (partitioned by date)
CREATE TABLE messages (
    message_id UUID PRIMARY KEY,
    chat_id VARCHAR(50),
    sender_id VARCHAR(50),
    recipient_id VARCHAR(50),
    message_type ENUM('text', 'image', 'video', 'document'),
    content TEXT,
    media_url VARCHAR(500),
    sent_at TIMESTAMP,
    delivered_at TIMESTAMP,
    read_at TIMESTAMP,
    INDEX idx_chat_time (chat_id, sent_at),
    INDEX idx_recipient_delivered (recipient_id, delivered_at)
) PARTITION BY RANGE (YEAR(sent_at));

-- Chat participants
CREATE TABLE chat_participants (
    chat_id VARCHAR(50),
    user_id VARCHAR(50),
    joined_at TIMESTAMP,
    last_read_message_id UUID,
    PRIMARY KEY (chat_id, user_id)
);
```

#### **Phase 4: Advanced Features (8-10 minutes)**

**Message Delivery Guarantees:**
- At-least-once delivery using message acknowledgments
- Idempotency keys to prevent duplicates
- Exponential backoff for retries

**Group Chat Optimization:**
- Fan-out approach for small groups (< 100 members)
- Message queue approach for large groups
- Read receipts aggregation

---

## 📋 **Interview Session 3: Design a Social Media Timeline (Facebook/Twitter)**

### **Interview Format: 45 minutes**

#### **Phase 1: Requirements Clarification (5-8 minutes)**

**Functional Requirements:**
- Users can post updates (text, images, videos)
- Follow other users
- Timeline shows posts from followed users
- Like and comment on posts
- Real-time updates

**Non-Functional Requirements:**
- 1 billion users, 500M daily active
- 300M posts per day
- Timeline generation < 200ms
- Real-time updates < 5 seconds

#### **Phase 2: High-Level Design (10-15 minutes)**

```
[Mobile App] → [CDN] → [Load Balancer] → [API Gateway]
                                              ↓
[Timeline Service] ← [Cache Layer] → [Post Service]
        ↓                               ↓
[Timeline DB] ← [Message Queue] ← [User Service]
                                        ↓
                                 [Media Service]
```

#### **Phase 3: Timeline Generation Strategies (15-20 minutes)**

**Pull Model (Timeline on Read):**
```java
@Service
public class PullTimelineService {
    
    @Cacheable("timeline")
    public List<Post> generateTimeline(String userId, int limit) {
        // Get users that this user follows
        List<String> followedUsers = userService.getFollowedUsers(userId);
        
        // Fetch recent posts from followed users
        List<Post> posts = new ArrayList<>();
        for (String followedUser : followedUsers) {
            List<Post> userPosts = postService.getRecentPosts(followedUser, limit);
            posts.addAll(userPosts);
        }
        
        // Sort by timestamp and return top posts
        return posts.stream()
            .sorted((p1, p2) -> p2.getCreatedAt().compareTo(p1.getCreatedAt()))
            .limit(limit)
            .collect(Collectors.toList());
    }
}
```

**Push Model (Timeline on Write):**
```java
@Service
public class PushTimelineService {
    
    @EventListener
    public void handleNewPost(PostCreatedEvent event) {
        Post post = event.getPost();
        String authorId = post.getAuthorId();
        
        // Get all followers of the post author
        List<String> followers = userService.getFollowers(authorId);
        
        // Add post to each follower's timeline
        for (String followerId : followers) {
            timelineCache.addToTimeline(followerId, post);
            
            // Send real-time update if user is online
            if (webSocketService.isUserOnline(followerId)) {
                webSocketService.sendUpdate(followerId, post);
            }
        }
    }
}
```

**Hybrid Approach:**
- Push for users with few followers (< 1000)
- Pull for celebrities with many followers
- Pre-compute timelines for active users
- Real-time computation for inactive users

#### **Phase 4: Advanced Optimizations (8-10 minutes)**

**Ranking Algorithm:**
```java
public double calculatePostScore(Post post, User viewer) {
    double score = 0.0;
    
    // Recency factor (exponential decay)
    long ageInHours = Duration.between(post.getCreatedAt(), Instant.now()).toHours();
    double recencyScore = Math.exp(-ageInHours / 24.0); // Decay over 24 hours
    
    // Engagement factor
    double engagementScore = Math.log(1 + post.getLikeCount() + post.getCommentCount() * 2);
    
    // Relationship factor
    double relationshipScore = userService.getRelationshipStrength(viewer.getId(), post.getAuthorId());
    
    // Content type factor
    double contentScore = getContentTypeMultiplier(post.getContentType());
    
    return recencyScore * 0.3 + engagementScore * 0.3 + relationshipScore * 0.3 + contentScore * 0.1;
}
```

---

## 📋 **Interview Session 4: Design a Search Engine (Google/Elasticsearch)**

### **Interview Format: 45 minutes**

#### **Phase 1: Requirements Definition (5-8 minutes)**

**Functional Requirements:**
- Crawl and index web pages
- Search query processing
- Ranked search results
- Real-time indexing updates
- Support for different content types

**Scale Requirements:**
- 100 billion web pages
- 10 billion searches per day
- Index update latency < 1 hour
- Search latency < 100ms
- 99.9% availability

#### **Phase 2: Architecture Overview (10-15 minutes)**

```
[Web Crawler] → [Content Processor] → [Indexer] → [Search Index]
                                                        ↓
[User Query] → [Query Processor] → [Ranking Engine] → [Results]
                                         ↓
                                  [Machine Learning Models]
```

#### **Phase 3: Deep Dive Components (15-20 minutes)**

**Web Crawler Design:**
```java
@Service
public class DistributedWebCrawler {
    
    @Autowired
    private URLQueue urlQueue;
    
    @Autowired
    private ContentStorage contentStorage;
    
    @Scheduled(fixedDelay = 1000)
    public void crawlPages() {
        List<String> urls = urlQueue.getBatch(100);
        
        for (String url : urls) {
            try {
                if (shouldCrawl(url)) {
                    CrawlResult result = crawlPage(url);
                    
                    if (result.isSuccess()) {
                        // Store content
                        contentStorage.store(result.getContent());
                        
                        // Extract new URLs
                        List<String> newUrls = extractUrls(result.getContent());
                        urlQueue.addUrls(newUrls);
                        
                        // Update crawl metadata
                        updateCrawlMetadata(url, result);
                    }
                }
            } catch (Exception e) {
                log.error("Failed to crawl URL: {}", url, e);
                handleCrawlError(url, e);
            }
        }
    }
    
    private boolean shouldCrawl(String url) {
        // Check robots.txt
        // Rate limiting per domain
        // Duplicate detection
        // Content freshness
        return robotsChecker.isAllowed(url) && 
               rateLimiter.allowRequest(getDomain(url)) &&
               !duplicateDetector.isDuplicate(url) &&
               contentFreshnessChecker.needsUpdate(url);
    }
}
```

**Inverted Index Structure:**
```java
public class InvertedIndex {
    // Term -> List of documents containing the term
    private Map<String, List<DocumentEntry>> termIndex;
    
    // Document metadata
    private Map<String, DocumentMetadata> documentMetadata;
    
    public static class DocumentEntry {
        private String documentId;
        private int termFrequency;
        private List<Integer> positions; // Word positions in document
        private double tfIdf;
    }
    
    public void addDocument(String documentId, String content) {
        List<String> tokens = tokenizer.tokenize(content);
        Map<String, Integer> termFrequencies = calculateTermFrequencies(tokens);
        
        for (Map.Entry<String, Integer> entry : termFrequencies.entrySet()) {
            String term = entry.getKey();
            int frequency = entry.getValue();
            
            DocumentEntry docEntry = new DocumentEntry(documentId, frequency, 
                getTermPositions(tokens, term));
            
            termIndex.computeIfAbsent(term, k -> new ArrayList<>()).add(docEntry);
        }
        
        // Calculate and store document metadata
        DocumentMetadata metadata = DocumentMetadata.builder()
            .documentId(documentId)
            .wordCount(tokens.size())
            .uniqueTerms(termFrequencies.size())
            .pageRank(calculatePageRank(documentId))
            .lastIndexed(Instant.now())
            .build();
        
        documentMetadata.put(documentId, metadata);
    }
}
```

**Search Ranking Algorithm:**
```java
@Service
public class SearchRankingService {
    
    public List<SearchResult> rankResults(String query, List<Document> candidateDocuments) {
        List<SearchResult> results = new ArrayList<>();
        
        for (Document doc : candidateDocuments) {
            double score = calculateRelevanceScore(query, doc);
            results.add(new SearchResult(doc, score));
        }
        
        return results.stream()
            .sorted((r1, r2) -> Double.compare(r2.getScore(), r1.getScore()))
            .limit(100)
            .collect(Collectors.toList());
    }
    
    private double calculateRelevanceScore(String query, Document document) {
        double tfIdfScore = calculateTfIdfScore(query, document);
        double pageRankScore = document.getPageRank();
        double freshnessScore = calculateFreshnessScore(document);
        double personalizedScore = calculatePersonalizationScore(query, document);
        
        // Weighted combination
        return tfIdfScore * 0.4 + 
               pageRankScore * 0.3 + 
               freshnessScore * 0.2 + 
               personalizedScore * 0.1;
    }
}
```

---

## 🎯 **General Interview Tips**

### **📝 RADIO Framework**
- **R**equirements: Always clarify functional and non-functional requirements
- **A**rchitecture: Start with high-level design, then dive deep
- **D**ata: Design data models and storage strategies
- **I**nterface: Define APIs and protocols
- **O**ptimization: Scale and optimize for the requirements

### **⏰ Time Management**
- Requirements: 10-15% of time
- High-level design: 30-35% of time
- Detailed design: 40-45% of time
- Scale & optimization: 10-15% of time

### **🔑 Key Success Factors**
1. **Ask clarifying questions** - Don't make assumptions
2. **Start simple** - Build incrementally
3. **Think out loud** - Communicate your thought process
4. **Consider trade-offs** - Discuss pros and cons
5. **Handle edge cases** - Think about failure scenarios
6. **Estimate capacity** - Show you understand scale

### **❌ Common Mistakes to Avoid**
1. Jumping into implementation without requirements
2. Over-engineering the initial solution
3. Ignoring non-functional requirements
4. Not considering failure scenarios
5. Poor time management
6. Not engaging with the interviewer

### **🎯 Practice Schedule**
- **Week 1**: Focus on basic system components (URL shortener, Chat)
- **Week 2**: Practice data-heavy systems (Search, Timeline)
- **Week 3**: Complex distributed systems (Video streaming, Payments)
- **Week 4**: Mock interviews with peers/mentors

Remember: The goal is to demonstrate your systematic thinking, technical knowledge, and ability to handle scale and complexity!
