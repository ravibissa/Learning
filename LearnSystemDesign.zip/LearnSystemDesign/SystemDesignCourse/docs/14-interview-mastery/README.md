# Module 14: Interview Mastery

## 🎯 Master System Design Interviews at Top Companies

This module provides comprehensive interview preparation including company-specific question patterns, mock interview scenarios, and proven strategies for success.

## 📚 Table of Contents

1. [Interview Framework](#interview-framework)
2. [Company-Specific Prep](#company-specific-prep)
3. [Mock Interview Packs](#mock-interview-packs)
4. [Common Patterns & Solutions](#common-patterns)
5. [Whiteboard Techniques](#whiteboard-techniques)
6. [Behavioral Questions](#behavioral-questions)
7. [Salary Negotiation](#salary-negotiation)

---

## 🎪 Interview Framework: The RADIO Method

### R - Requirements Gathering (5-10 minutes)
**Ask clarifying questions to understand the problem:**

```
Functional Requirements:
- What specific features do we need?
- Who are the users? How many?
- What operations are most important?

Non-Functional Requirements:
- What's the expected scale (users, data, requests)?
- What are the performance requirements?
- What's the availability requirement?
- Are there any specific constraints?
```

### A - API Design (5-10 minutes)
**Define the interface before diving into architecture:**

```java
// Example: Chat System APIs
@RestController
public class ChatController {
    
    // Send message
    @PostMapping("/messages")
    ResponseEntity<Message> sendMessage(@RequestBody SendMessageRequest request);
    
    // Get chat history
    @GetMapping("/chats/{chatId}/messages")
    ResponseEntity<List<Message>> getMessages(
        @PathVariable String chatId,
        @RequestParam(defaultValue = "0") int page,
        @RequestParam(defaultValue = "50") int size
    );
    
    // Join chat room
    @PostMapping("/chats/{chatId}/join")
    ResponseEntity<Void> joinChat(@PathVariable String chatId);
}
```

### D - Data Model (10-15 minutes)
**Design the database schema and key entities:**

```sql
-- Chat system example
CREATE TABLE users (
    id UUID PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE chats (
    id UUID PRIMARY KEY,
    name VARCHAR(100),
    type ENUM('direct', 'group', 'channel'),
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE messages (
    id UUID PRIMARY KEY,
    chat_id UUID REFERENCES chats(id),
    sender_id UUID REFERENCES users(id),
    content TEXT NOT NULL,
    message_type ENUM('text', 'image', 'file'),
    created_at TIMESTAMP DEFAULT NOW(),
    
    INDEX idx_chat_created (chat_id, created_at)
);
```

### I - Initial Design (15-20 minutes)
**Draw high-level architecture:**

```mermaid
graph TB
    Client[Mobile/Web Client] --> LB[Load Balancer]
    LB --> AS1[App Server 1]
    LB --> AS2[App Server 2]
    LB --> ASN[App Server N]
    
    AS1 --> Cache[Redis Cache]
    AS2 --> Cache
    ASN --> Cache
    
    AS1 --> DB[(Message DB<br/>Sharded)]
    AS2 --> DB
    ASN --> DB
    
    AS1 --> WS[WebSocket Server]
    AS2 --> WS
    ASN --> WS
    
    WS --> MQ[Message Queue<br/>Kafka]
```

### O - Optimize & Scale (15-20 minutes)
**Address bottlenecks and scaling concerns:**

1. **Database Scaling**: Sharding, read replicas
2. **Caching**: Redis for hot data, CDN for static content
3. **Message Queue**: Kafka for reliable message delivery
4. **Monitoring**: Metrics, logging, alerting
5. **Security**: Authentication, rate limiting, encryption

---

## 🏢 Company-Specific Preparation

### Google/Alphabet
**Focus Areas**: Distributed systems, scalability, algorithms
**Common Questions**:
- Design Google Search
- Design YouTube
- Design Google Maps
- Design Gmail

**Key Patterns**:
- MapReduce for large-scale processing
- Bigtable for structured storage
- Spanner for global consistency
- Emphasis on efficiency and algorithmic complexity

### Amazon/AWS
**Focus Areas**: Microservices, AWS services, operational excellence
**Common Questions**:
- Design Amazon.com product catalog
- Design AWS S3
- Design Amazon Prime Video
- Design Alexa

**Key Patterns**:
- Service-oriented architecture
- Eventually consistent systems
- Auto-scaling and elasticity
- Cost optimization

### Meta/Facebook
**Focus Areas**: Social systems, real-time features, massive scale
**Common Questions**:
- Design Facebook News Feed
- Design Instagram
- Design WhatsApp
- Design Facebook Messenger

**Key Patterns**:
- Graph databases for social connections
- Real-time message delivery
- Image/video processing pipelines
- Feed ranking algorithms

### Netflix
**Focus Areas**: Content delivery, streaming, chaos engineering
**Common Questions**:
- Design Netflix video streaming
- Design content recommendation system
- Design Netflix's encoding pipeline
- Design global content distribution

**Key Patterns**:
- CDN optimization
- Microservices resilience
- A/B testing frameworks
- Chaos engineering principles

### Uber/Lyft
**Focus Areas**: Real-time systems, geospatial data, matching algorithms
**Common Questions**:
- Design Uber ride matching
- Design Uber Eats delivery
- Design surge pricing
- Design driver location tracking

**Key Patterns**:
- Geospatial indexing (QuadTree, S2)
- Real-time location tracking
- Dynamic pricing algorithms
- Event-driven architecture

---

## 🎭 Mock Interview Packs

### Pack 1: Data-Intensive Systems

#### Mock Interview 1: Design Twitter (45 minutes)

**Interviewer Script:**
```
[0-5 min] Requirements:
- Post tweets (280 chars max)
- Follow/unfollow users
- View timeline (home + user)
- 300M active users, 600 tweets/sec

[5-10 min] API Design:
- POST /tweets
- GET /timeline/home
- GET /timeline/user/{userId}
- POST /users/{userId}/follow

[10-25 min] Architecture:
- Load balancers + app servers
- Tweet storage (sharded by user_id)
- Timeline generation (push vs pull)
- Cache layer for timelines

[25-40 min] Scale:
- Celebrity user problem
- Timeline fanout strategies
- Hot user handling
- Content delivery optimization

[40-45 min] Q&A and feedback
```

**Solution Framework:**
```java
// Core entities
@Entity
public class Tweet {
    private UUID id;
    private UUID userId;
    private String content;
    private Instant createdAt;
    private int likeCount;
    private int retweetCount;
}

@Entity 
public class Follow {
    private UUID followerId;
    private UUID followeeId;
    private Instant createdAt;
}

// Timeline service
@Service
public class TimelineService {
    
    // Push model - fanout on write
    public void fanoutTweet(Tweet tweet) {
        List<UUID> followers = followService.getFollowers(tweet.getUserId());
        
        // For normal users - fanout to all followers
        if (followers.size() < 10000) {
            followers.parallelStream().forEach(followerId -> 
                timelineCache.addToTimeline(followerId, tweet)
            );
        } else {
            // For celebrities - hybrid approach
            celebrityTweetCache.put(tweet.getUserId(), tweet);
        }
    }
    
    // Pull model - fanout on read
    public List<Tweet> getHomeTimeline(UUID userId, int page, int size) {
        List<Tweet> timeline = timelineCache.getTimeline(userId, page, size);
        
        // Merge celebrity tweets
        List<UUID> celebrityFollows = followService.getCelebrityFollows(userId);
        List<Tweet> celebrityTweets = getCelebrityTweets(celebrityFollows);
        
        return mergeAndSort(timeline, celebrityTweets, size);
    }
}
```

### Pack 2: Real-Time Systems

#### Mock Interview 2: Design WhatsApp (45 minutes)

**Key Focus Areas:**
- WebSocket connections for real-time messaging
- Message delivery guarantees
- Online presence indicators
- End-to-end encryption
- Group chat scalability

**Solution Highlights:**
```java
@Component
public class MessageDeliveryService {
    
    public void sendMessage(Message message) {
        // 1. Store message
        messageRepository.save(message);
        
        // 2. Try real-time delivery
        if (isUserOnline(message.getRecipientId())) {
            webSocketService.sendMessage(message.getRecipientId(), message);
            markAsDelivered(message.getId());
        } else {
            // 3. Queue for offline delivery
            offlineMessageQueue.add(message);
        }
        
        // 4. Send push notification
        pushNotificationService.send(message.getRecipientId(), message);
    }
}
```

### Pack 3: Content Systems

#### Mock Interview 3: Design YouTube (45 minutes)

**Key Components:**
- Video upload and encoding pipeline
- Metadata storage and search
- Video streaming and CDN
- Recommendation system
- Content moderation

---

## 🎨 Whiteboard Techniques

### 1. Start with High-Level Boxes
```
[Client] → [Load Balancer] → [App Servers] → [Database]
```

### 2. Add Detail Progressively
```
[Mobile App]     [Load Balancer]    [App Server 1]    [PostgreSQL]
[Web Client]  →      (Nginx)     →  [App Server 2] →  [Master/Slave]
[API Client]                        [App Server N]    [Sharded]
```

### 3. Show Data Flow with Arrows
- Use different arrow styles for different types of requests
- Label arrows with protocols (HTTP, WebSocket, gRPC)
- Show read vs write paths

### 4. Include Numbers and Estimates
```
100M users → 1000 req/sec → 5 app servers → 100GB storage
```

### 5. Address the "What If" Questions
- What if this component fails?
- What if traffic increases 10x?
- How do we handle hot spots?

---

## 🗣️ Behavioral Questions for System Design Roles

### Leadership & Collaboration
**Q: "Tell me about a time you had to make a difficult architectural decision."**

**STAR Framework Answer:**
- **Situation**: Microservices vs monolith decision for new feature
- **Task**: Evaluate options and make recommendation
- **Action**: Created proof of concept, gathered team input, analyzed trade-offs
- **Result**: Chose monolith-first approach, delivered 30% faster

### Problem Solving
**Q: "Describe a system outage you helped resolve."**

**Sample Answer:**
- Identified database connection pool exhaustion
- Implemented circuit breakers and connection monitoring
- Reduced mean recovery time from 2 hours to 15 minutes

### Technical Leadership
**Q: "How do you handle technical disagreements in your team?"**

**Key Points:**
- Listen to all perspectives
- Use data and prototypes to validate approaches
- Focus on business outcomes
- Document decisions and rationale

---

## 💰 Salary Negotiation for System Design Roles

### Research Market Rates
- **Senior SDE**: $150K-$300K+ (varies by location/company)
- **Principal Engineer**: $250K-$500K+
- **Architect**: $200K-$400K+

### Negotiation Tactics
1. **Multiple offers**: Create competitive situations
2. **Total compensation**: Consider stock, bonuses, benefits
3. **Non-salary benefits**: Flexible work, learning budget, title
4. **Performance metrics**: Agree on success criteria

### Sample Counter-Offer Email
```
Thank you for the offer. I'm excited about the role and the 
technical challenges. Based on my research and experience with 
distributed systems at scale, I was expecting a total 
compensation closer to $X. Can we explore options to bridge 
this gap?

I'm particularly interested in:
- Base salary adjustment
- Additional equity grant
- Professional development budget
- Flexible work arrangements

I'm confident I can deliver significant value in this role 
and look forward to discussing further.
```

---

## 📊 Interview Success Metrics

### Technical Assessment
- [ ] **Requirements clarification** (showed good judgment)
- [ ] **API design** (RESTful, well-structured)
- [ ] **Data modeling** (normalized, indexed properly)
- [ ] **System architecture** (scalable, reliable)
- [ ] **Trade-off analysis** (understood pros/cons)
- [ ] **Scaling strategies** (identified bottlenecks)

### Communication
- [ ] **Clear explanations** (easy to follow logic)
- [ ] **Structured approach** (followed methodology)
- [ ] **Interactive discussion** (asked good questions)
- [ ] **Handled feedback** (incorporated suggestions)

### Problem Solving
- [ ] **Breaking down complex problems**
- [ ] **Identifying core requirements**
- [ ] **Proposing multiple solutions**
- [ ] **Optimizing based on constraints**

---

## 🎯 Final Preparation Checklist

### 2 Weeks Before
- [ ] Complete all case studies
- [ ] Practice 10+ mock interviews
- [ ] Research target companies
- [ ] Prepare behavioral stories

### 1 Week Before
- [ ] Review system design patterns
- [ ] Practice whiteboarding
- [ ] Prepare questions to ask interviewer
- [ ] Plan arrival and logistics

### Day Before
- [ ] Review company-specific examples
- [ ] Get good sleep
- [ ] Prepare materials (laptop, markers, etc.)
- [ ] Practice elevator pitch

### During Interview
- [ ] Listen carefully to requirements
- [ ] Ask clarifying questions
- [ ] Think out loud
- [ ] Acknowledge trade-offs
- [ ] Stay calm and confident

---

## 🚀 Post-Interview

### Follow-Up
- Send thank you email within 24 hours
- Reference specific discussion points
- Reiterate interest and fit
- Provide any additional information requested

### Continuous Improvement
- Document interview questions and feedback
- Identify knowledge gaps
- Practice weak areas
- Update preparation materials

---

## 🎓 Success Stories

### "From Java Developer to Senior Architect at Google"
*"The systematic approach in this course helped me structure my thinking. I practiced the URL shortener design 10 times before my interview, and when they asked me to design a link shortening service, I was ready!"*

### "Landed Principal Engineer Role at Netflix"
*"The company-specific preparation was invaluable. Understanding Netflix's chaos engineering principles and content delivery patterns gave me confidence to discuss trade-offs at their scale."*

---

**You're now ready to ace your system design interviews! Remember: practice makes perfect, and confidence comes from preparation.**

## 📚 Additional Resources

- **Books**: "System Design Interview" by Alex Xu
- **Videos**: YouTube channels on system design
- **Practice**: LeetCode System Design, Pramp mock interviews
- **Communities**: Join system design Discord/Slack groups

---

**Ready to land your dream job?** Start with our [Mock Interview Simulator](exercises/mock-interview-simulator.md) and track your progress!
