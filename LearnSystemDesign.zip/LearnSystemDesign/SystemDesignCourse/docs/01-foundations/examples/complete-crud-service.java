// Complete CRUD service implementation for foundations module
package com.systemdesign.foundations.examples;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;
import java.util.Optional;
import java.util.List;
import java.util.UUID;
import javax.validation.Valid;

/**
 * Complete CRUD service demonstrating foundational patterns
 * for system design interviews and production systems
 */
@RestController
@RequestMapping("/api/v1/users")
public class CompleteCRUDService {
    
    @Autowired
    private UserService userService;
    
    @Autowired
    private UserMetrics userMetrics;
    
    /**
     * CREATE - Create a new user
     */
    @PostMapping
    public ResponseEntity<UserResponse> createUser(@Valid @RequestBody CreateUserRequest request) {
        try {
            userMetrics.recordApiCall("create_user");
            
            UserResponse user = userService.createUser(request);
            
            userMetrics.recordApiSuccess("create_user");
            return ResponseEntity.status(HttpStatus.CREATED).body(user);
            
        } catch (UserAlreadyExistsException e) {
            userMetrics.recordApiError("create_user", "user_exists");
            return ResponseEntity.status(HttpStatus.CONFLICT)
                .body(UserResponse.error("User already exists"));
                
        } catch (ValidationException e) {
            userMetrics.recordApiError("create_user", "validation_failed");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(UserResponse.error(e.getMessage()));
                
        } catch (Exception e) {
            userMetrics.recordApiError("create_user", "internal_error");
            log.error("Failed to create user", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(UserResponse.error("Internal server error"));
        }
    }
    
    /**
     * READ - Get user by ID
     */
    @GetMapping("/{userId}")
    public ResponseEntity<UserResponse> getUser(@PathVariable String userId) {
        try {
            userMetrics.recordApiCall("get_user");
            
            Optional<UserResponse> user = userService.getUserById(userId);
            
            if (user.isPresent()) {
                userMetrics.recordApiSuccess("get_user");
                return ResponseEntity.ok(user.get());
            } else {
                userMetrics.recordApiError("get_user", "user_not_found");
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(UserResponse.error("User not found"));
            }
            
        } catch (Exception e) {
            userMetrics.recordApiError("get_user", "internal_error");
            log.error("Failed to get user: {}", userId, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(UserResponse.error("Internal server error"));
        }
    }
    
    /**
     * READ - Get all users with pagination
     */
    @GetMapping
    public ResponseEntity<PagedResponse<UserResponse>> getUsers(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size,
            @RequestParam(required = false) String search) {
        
        try {
            userMetrics.recordApiCall("get_users");
            
            Pageable pageable = PageRequest.of(page, size);
            Page<UserResponse> users = userService.getUsers(search, pageable);
            
            PagedResponse<UserResponse> response = PagedResponse.<UserResponse>builder()
                .content(users.getContent())
                .totalElements(users.getTotalElements())
                .totalPages(users.getTotalPages())
                .currentPage(page)
                .pageSize(size)
                .build();
            
            userMetrics.recordApiSuccess("get_users");
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            userMetrics.recordApiError("get_users", "internal_error");
            log.error("Failed to get users", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(PagedResponse.error("Internal server error"));
        }
    }
    
    /**
     * UPDATE - Update user
     */
    @PutMapping("/{userId}")
    public ResponseEntity<UserResponse> updateUser(@PathVariable String userId,
                                                  @Valid @RequestBody UpdateUserRequest request) {
        try {
            userMetrics.recordApiCall("update_user");
            
            Optional<UserResponse> updatedUser = userService.updateUser(userId, request);
            
            if (updatedUser.isPresent()) {
                userMetrics.recordApiSuccess("update_user");
                return ResponseEntity.ok(updatedUser.get());
            } else {
                userMetrics.recordApiError("update_user", "user_not_found");
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(UserResponse.error("User not found"));
            }
            
        } catch (ValidationException e) {
            userMetrics.recordApiError("update_user", "validation_failed");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(UserResponse.error(e.getMessage()));
                
        } catch (Exception e) {
            userMetrics.recordApiError("update_user", "internal_error");
            log.error("Failed to update user: {}", userId, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(UserResponse.error("Internal server error"));
        }
    }
    
    /**
     * DELETE - Soft delete user
     */
    @DeleteMapping("/{userId}")
    public ResponseEntity<Void> deleteUser(@PathVariable String userId) {
        try {
            userMetrics.recordApiCall("delete_user");
            
            boolean deleted = userService.deleteUser(userId);
            
            if (deleted) {
                userMetrics.recordApiSuccess("delete_user");
                return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
            } else {
                userMetrics.recordApiError("delete_user", "user_not_found");
                return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
            }
            
        } catch (Exception e) {
            userMetrics.recordApiError("delete_user", "internal_error");
            log.error("Failed to delete user: {}", userId, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
}

/**
 * Service layer with business logic, caching, and resilience patterns
 */
@Service
@Transactional
public class UserService {
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private UserCacheService cacheService;
    
    @Autowired
    private UserValidator userValidator;
    
    @Autowired
    private AuditService auditService;
    
    @Autowired
    private EventPublisher eventPublisher;
    
    /**
     * Create user with validation and caching
     */
    public UserResponse createUser(CreateUserRequest request) {
        // Validate request
        userValidator.validateCreateRequest(request);
        
        // Check if user already exists
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new UserAlreadyExistsException("User with email already exists");
        }
        
        if (userRepository.existsByUsername(request.getUsername())) {
            throw new UserAlreadyExistsException("User with username already exists");
        }
        
        // Create user entity
        User user = User.builder()
            .id(UUID.randomUUID().toString())
            .email(request.getEmail())
            .username(request.getUsername())
            .firstName(request.getFirstName())
            .lastName(request.getLastName())
            .passwordHash(passwordEncoder.encode(request.getPassword()))
            .status(UserStatus.ACTIVE)
            .createdAt(Instant.now())
            .updatedAt(Instant.now())
            .version(1L)
            .build();
        
        // Save to database
        User savedUser = userRepository.save(user);
        
        // Cache the user
        cacheService.cacheUser(savedUser);
        
        // Create audit log
        auditService.logUserCreation(savedUser.getId(), getCurrentUserId());
        
        // Publish event
        eventPublisher.publishUserCreatedEvent(UserCreatedEvent.builder()
            .userId(savedUser.getId())
            .email(savedUser.getEmail())
            .username(savedUser.getUsername())
            .createdAt(savedUser.getCreatedAt())
            .build());
        
        return UserResponse.from(savedUser);
    }
    
    /**
     * Get user by ID with caching
     */
    @Cacheable(value = "users", key = "#userId")
    public Optional<UserResponse> getUserById(String userId) {
        // Try cache first (handled by @Cacheable)
        
        return userRepository.findByIdAndDeletedAtIsNull(userId)
            .map(UserResponse::from);
    }
    
    /**
     * Get users with search and pagination
     */
    @Transactional(readOnly = true)
    public Page<UserResponse> getUsers(String search, Pageable pageable) {
        Page<User> users;
        
        if (search != null && !search.trim().isEmpty()) {
            // Search by email, username, or name
            users = userRepository.findBySearchCriteria(search.trim(), pageable);
        } else {
            // Get all active users
            users = userRepository.findByDeletedAtIsNull(pageable);
        }
        
        return users.map(UserResponse::from);
    }
    
    /**
     * Update user with optimistic locking
     */
    @CachePut(value = "users", key = "#userId")
    public Optional<UserResponse> updateUser(String userId, UpdateUserRequest request) {
        return userRepository.findByIdAndDeletedAtIsNull(userId)
            .map(existingUser -> {
                // Validate request
                userValidator.validateUpdateRequest(request, existingUser);
                
                // Check for concurrent updates (optimistic locking)
                if (!existingUser.getVersion().equals(request.getVersion())) {
                    throw new OptimisticLockException("User was modified by another process");
                }
                
                // Update fields
                User updatedUser = existingUser.toBuilder()
                    .firstName(request.getFirstName())
                    .lastName(request.getLastName())
                    .email(request.getEmail())
                    .updatedAt(Instant.now())
                    .version(existingUser.getVersion() + 1)
                    .build();
                
                // Check for email uniqueness if changed
                if (!existingUser.getEmail().equals(request.getEmail()) &&
                    userRepository.existsByEmailAndIdNot(request.getEmail(), userId)) {
                    throw new UserAlreadyExistsException("Email already in use");
                }
                
                // Save updated user
                User savedUser = userRepository.save(updatedUser);
                
                // Create audit log
                auditService.logUserUpdate(savedUser.getId(), existingUser, savedUser, getCurrentUserId());
                
                // Publish event
                eventPublisher.publishUserUpdatedEvent(UserUpdatedEvent.builder()
                    .userId(savedUser.getId())
                    .updatedFields(getUpdatedFields(existingUser, savedUser))
                    .updatedAt(savedUser.getUpdatedAt())
                    .build());
                
                return UserResponse.from(savedUser);
            });
    }
    
    /**
     * Soft delete user
     */
    @CacheEvict(value = "users", key = "#userId")
    public boolean deleteUser(String userId) {
        return userRepository.findByIdAndDeletedAtIsNull(userId)
            .map(user -> {
                // Soft delete
                User deletedUser = user.toBuilder()
                    .deletedAt(Instant.now())
                    .updatedAt(Instant.now())
                    .version(user.getVersion() + 1)
                    .build();
                
                userRepository.save(deletedUser);
                
                // Create audit log
                auditService.logUserDeletion(userId, getCurrentUserId());
                
                // Publish event
                eventPublisher.publishUserDeletedEvent(UserDeletedEvent.builder()
                    .userId(userId)
                    .deletedAt(deletedUser.getDeletedAt())
                    .build());
                
                return true;
            })
            .orElse(false);
    }
    
    private String getCurrentUserId() {
        // Get current user from security context
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        return auth != null ? auth.getName() : "system";
    }
    
    private Map<String, Object> getUpdatedFields(User oldUser, User newUser) {
        Map<String, Object> changes = new HashMap<>();
        
        if (!Objects.equals(oldUser.getFirstName(), newUser.getFirstName())) {
            changes.put("firstName", Map.of("old", oldUser.getFirstName(), "new", newUser.getFirstName()));
        }
        
        if (!Objects.equals(oldUser.getLastName(), newUser.getLastName())) {
            changes.put("lastName", Map.of("old", oldUser.getLastName(), "new", newUser.getLastName()));
        }
        
        if (!Objects.equals(oldUser.getEmail(), newUser.getEmail())) {
            changes.put("email", Map.of("old", oldUser.getEmail(), "new", newUser.getEmail()));
        }
        
        return changes;
    }
}

/**
 * Repository with custom queries and optimizations
 */
@Repository
public interface UserRepository extends JpaRepository<User, String> {
    
    boolean existsByEmail(String email);
    boolean existsByUsername(String username);
    boolean existsByEmailAndIdNot(String email, String id);
    
    Optional<User> findByIdAndDeletedAtIsNull(String id);
    Optional<User> findByEmailAndDeletedAtIsNull(String email);
    Optional<User> findByUsernameAndDeletedAtIsNull(String username);
    
    Page<User> findByDeletedAtIsNull(Pageable pageable);
    
    @Query("""
        SELECT u FROM User u 
        WHERE u.deletedAt IS NULL 
        AND (
            LOWER(u.email) LIKE LOWER(CONCAT('%', :search, '%')) OR
            LOWER(u.username) LIKE LOWER(CONCAT('%', :search, '%')) OR
            LOWER(CONCAT(u.firstName, ' ', u.lastName)) LIKE LOWER(CONCAT('%', :search, '%'))
        )
        """)
    Page<User> findBySearchCriteria(@Param("search") String search, Pageable pageable);
    
    @Query("SELECT COUNT(u) FROM User u WHERE u.deletedAt IS NULL")
    long countActiveUsers();
    
    @Query("""
        SELECT u FROM User u 
        WHERE u.deletedAt IS NULL 
        AND u.createdAt >= :fromDate 
        ORDER BY u.createdAt DESC
        """)
    List<User> findRecentUsers(@Param("fromDate") Instant fromDate, Pageable pageable);
}

/**
 * Caching service for user data
 */
@Service
public class UserCacheService {
    
    @Autowired
    private RedisTemplate<String, Object> redisTemplate;
    
    private static final String USER_CACHE_PREFIX = "user:";
    private static final Duration CACHE_TTL = Duration.ofHours(1);
    
    public void cacheUser(User user) {
        try {
            String key = USER_CACHE_PREFIX + user.getId();
            UserResponse response = UserResponse.from(user);
            
            redisTemplate.opsForValue().set(key, response, CACHE_TTL);
            
        } catch (Exception e) {
            log.warn("Failed to cache user: {}", user.getId(), e);
        }
    }
    
    public Optional<UserResponse> getCachedUser(String userId) {
        try {
            String key = USER_CACHE_PREFIX + userId;
            UserResponse cached = (UserResponse) redisTemplate.opsForValue().get(key);
            
            return Optional.ofNullable(cached);
            
        } catch (Exception e) {
            log.warn("Failed to get cached user: {}", userId, e);
            return Optional.empty();
        }
    }
    
    public void evictUser(String userId) {
        try {
            String key = USER_CACHE_PREFIX + userId;
            redisTemplate.delete(key);
            
        } catch (Exception e) {
            log.warn("Failed to evict user from cache: {}", userId, e);
        }
    }
    
    public void evictAllUsers() {
        try {
            Set<String> keys = redisTemplate.keys(USER_CACHE_PREFIX + "*");
            if (keys != null && !keys.isEmpty()) {
                redisTemplate.delete(keys);
            }
            
        } catch (Exception e) {
            log.warn("Failed to evict all users from cache", e);
        }
    }
}

// Data Transfer Objects

@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UserResponse {
    private String id;
    private String email;
    private String username;
    private String firstName;
    private String lastName;
    private String fullName;
    private UserStatus status;
    private Instant createdAt;
    private Instant updatedAt;
    private Long version;
    private String error;
    
    public static UserResponse from(User user) {
        return UserResponse.builder()
            .id(user.getId())
            .email(user.getEmail())
            .username(user.getUsername())
            .firstName(user.getFirstName())
            .lastName(user.getLastName())
            .fullName(STR."\{user.getFirstName()} \{user.getLastName()}")
            .status(user.getStatus())
            .createdAt(user.getCreatedAt())
            .updatedAt(user.getUpdatedAt())
            .version(user.getVersion())
            .build();
    }
    
    public static UserResponse error(String error) {
        return UserResponse.builder()
            .error(error)
            .build();
    }
}

@Data
@Builder
public class CreateUserRequest {
    @NotBlank(message = "Email is required")
    @Email(message = "Email must be valid")
    private String email;
    
    @NotBlank(message = "Username is required")
    @Size(min = 3, max = 50, message = "Username must be between 3 and 50 characters")
    private String username;
    
    @NotBlank(message = "First name is required")
    @Size(max = 100, message = "First name cannot exceed 100 characters")
    private String firstName;
    
    @NotBlank(message = "Last name is required")
    @Size(max = 100, message = "Last name cannot exceed 100 characters")
    private String lastName;
    
    @NotBlank(message = "Password is required")
    @Size(min = 8, message = "Password must be at least 8 characters")
    private String password;
}

@Data
@Builder
public class UpdateUserRequest {
    @NotBlank(message = "First name is required")
    @Size(max = 100, message = "First name cannot exceed 100 characters")
    private String firstName;
    
    @NotBlank(message = "Last name is required")
    @Size(max = 100, message = "Last name cannot exceed 100 characters")
    private String lastName;
    
    @NotBlank(message = "Email is required")
    @Email(message = "Email must be valid")
    private String email;
    
    @NotNull(message = "Version is required for optimistic locking")
    private Long version;
}

@Data
@Builder
public class PagedResponse<T> {
    private List<T> content;
    private long totalElements;
    private int totalPages;
    private int currentPage;
    private int pageSize;
    private String error;
    
    public static <T> PagedResponse<T> error(String error) {
        return PagedResponse.<T>builder()
            .error(error)
            .build();
    }
}
