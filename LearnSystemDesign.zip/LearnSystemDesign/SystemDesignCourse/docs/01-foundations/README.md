# Module 01: System Design Foundations

## 🎯 Learning Objectives

By the end of this module, you will understand:
- ✅ Fundamental principles of distributed systems
- ✅ CAP theorem and its practical implications
- ✅ Scalability patterns and trade-offs
- ✅ Performance metrics and capacity planning
- ✅ Failure modes and reliability patterns
- ✅ How to approach system design interviews

## 📚 Table of Contents

1. [Core Concepts](#core-concepts)
2. [CAP Theorem Deep Dive](#cap-theorem)
3. [Scalability Fundamentals](#scalability)
4. [Performance & Capacity Planning](#performance)
5. [Reliability & Fault Tolerance](#reliability)
6. [Java 21 Implementation Examples](#java-examples)
7. [Hands-On Lab](#hands-on-lab)
8. [Interview Questions & Answers](#interview-qa)
9. [Capacity Planning Exercise](#capacity-planning)
10. [Failure Scenarios](#failure-scenarios)

---

## 🏗️ Core Concepts

### System Design Triangle

```mermaid
graph TB
    A[Performance] --> D[System Design]
    B[Scalability] --> D
    C[Reliability] --> D
    
    A --> E[Latency<br/>Throughput<br/>Response Time]
    B --> F[Horizontal Scaling<br/>Vertical Scaling<br/>Load Distribution]
    C --> G[Fault Tolerance<br/>High Availability<br/>Disaster Recovery]
```

### Key Principles

| Principle | Description | Example |
|-----------|-------------|---------|
| **Scalability** | Ability to handle increased load | Add more servers when traffic grows |
| **Reliability** | System continues working correctly | 99.9% uptime guarantee |
| **Availability** | System remains operational | No single point of failure |
| **Consistency** | All nodes see the same data | Database ACID properties |
| **Partition Tolerance** | System continues despite network failures | Service mesh resilience |

---

## 🔺 CAP Theorem Deep Dive

### The Impossible Triangle

**CAP Theorem**: In a distributed system, you can only guarantee TWO of:
- **Consistency** (C): All nodes see the same data simultaneously
- **Availability** (A): System remains operational
- **Partition Tolerance** (P): System continues despite network failures

```mermaid
graph LR
    subgraph "CAP Triangle"
        C[Consistency<br/>Strong consistency<br/>ACID guarantees]
        A[Availability<br/>Always operational<br/>No downtime]
        P[Partition Tolerance<br/>Network fault tolerant<br/>Split-brain resilience]
        
        C --- A
        A --- P
        P --- C
    end
    
    subgraph "Real Systems"
        CP[CA Systems<br/>Traditional RDBMS<br/>PostgreSQL<br/>Single datacenter]
        AP[AP Systems<br/>DNS<br/>Web caches<br/>Cassandra]
        PC[CP Systems<br/>MongoDB<br/>Redis Cluster<br/>HBase]
    end
    
    C --- CP
    A --- AP
    P --- PC
```

### CAP in Practice

#### CA Systems (Consistency + Availability)
```java
@Entity
@Table(name = "bank_accounts")
public class BankAccount {
    @Id
    private UUID id;
    
    @Column(nullable = false)
    private BigDecimal balance;
    
    @Version
    private Long version; // Optimistic locking for consistency
    
    @Transactional
    public void transfer(BankAccount target, BigDecimal amount) {
        // ACID transaction ensures consistency
        this.balance = this.balance.subtract(amount);
        target.balance = target.balance.add(amount);
        // Fails entirely if network partition occurs
    }
}
```

#### AP Systems (Availability + Partition Tolerance)
```java
@Service
public class EventuallyConsistentUserService {
    
    @Autowired
    private List<UserRepository> replicatedRepositories;
    
    public User saveUser(User user) {
        // Write to all available replicas
        List<CompletableFuture<Void>> futures = replicatedRepositories.stream()
            .map(repo -> CompletableFuture.runAsync(() -> {
                try {
                    repo.save(user);
                } catch (Exception e) {
                    // Log but don't fail - eventual consistency
                    log.warn("Failed to replicate to node: {}", e.getMessage());
                }
            }))
            .toList();
            
        // Don't wait for all - return immediately (availability)
        return user;
    }
}
```

#### CP Systems (Consistency + Partition Tolerance)
```java
@Service
public class ConsistentConfigService {
    
    @Autowired
    private EtcdClient etcdClient; // CP system
    
    public void updateConfig(String key, String value) {
        try {
            // Requires majority consensus
            etcdClient.put(key, value);
        } catch (EtcdException e) {
            // System becomes unavailable during partition
            throw new ServiceUnavailableException("Cannot maintain consistency");
        }
    }
}
```

---

## 📈 Scalability Fundamentals

### Vertical vs Horizontal Scaling

```mermaid
graph TB
    subgraph "Vertical Scaling (Scale Up)"
        VS1[Single Server<br/>4 CPU, 8GB RAM] --> VS2[Bigger Server<br/>16 CPU, 64GB RAM]
        VS2 --> VS3[Huge Server<br/>64 CPU, 512GB RAM]
    end
    
    subgraph "Horizontal Scaling (Scale Out)"
        HS1[Server 1<br/>4 CPU, 8GB] 
        HS2[Server 2<br/>4 CPU, 8GB]
        HS3[Server 3<br/>4 CPU, 8GB]
        HS4[Server N<br/>4 CPU, 8GB]
        
        LB[Load Balancer] --> HS1
        LB --> HS2
        LB --> HS3
        LB --> HS4
    end
```

### Load Balancing Strategies

```java
public enum LoadBalancingStrategy {
    ROUND_ROBIN,
    LEAST_CONNECTIONS,
    WEIGHTED_ROUND_ROBIN,
    IP_HASH,
    LEAST_RESPONSE_TIME
}

@Component
public class LoadBalancer {
    
    private final List<Server> servers;
    private AtomicInteger currentIndex = new AtomicInteger(0);
    
    public Server selectServer(LoadBalancingStrategy strategy) {
        return switch (strategy) {
            case ROUND_ROBIN -> roundRobin();
            case LEAST_CONNECTIONS -> leastConnections();
            case WEIGHTED_ROUND_ROBIN -> weightedRoundRobin();
            case IP_HASH -> ipHash();
            case LEAST_RESPONSE_TIME -> leastResponseTime();
        };
    }
    
    private Server roundRobin() {
        int index = currentIndex.getAndIncrement() % servers.size();
        return servers.get(index);
    }
    
    private Server leastConnections() {
        return servers.stream()
            .min(Comparator.comparing(Server::getActiveConnections))
            .orElseThrow();
    }
}
```

---

## ⚡ Performance & Capacity Planning

### Key Metrics

| Metric | Definition | Target |
|--------|------------|---------|
| **Latency** | Time to process single request | < 100ms p95 |
| **Throughput** | Requests per second | > 10K RPS |
| **Response Time** | End-to-end user experience | < 200ms p99 |
| **Availability** | Uptime percentage | 99.9% (8.76h/year) |
| **Error Rate** | Failed requests percentage | < 0.1% |

### Capacity Planning Calculator

```java
@Component
public class CapacityPlanner {
    
    public record CapacityRequirements(
        int expectedUsers,
        double avgRequestsPerUser,
        int peakMultiplier,
        double averageResponseTime,
        double cpuUtilizationTarget
    ) {}
    
    public record CapacityPlan(
        int requiredServers,
        int recommendedServers,
        double expectedCpuUsage,
        int maxThroughput
    ) {}
    
    public CapacityPlan calculateCapacity(CapacityRequirements req) {
        // Peak RPS calculation
        double dailyRequests = req.expectedUsers * req.avgRequestsPerUser;
        double peakRPS = (dailyRequests / 86400) * req.peakMultiplier;
        
        // Server capacity (rule of thumb: 1 server = 1000 RPS)
        int serverCapacityRPS = 1000;
        
        // Required servers for load
        int requiredForLoad = (int) Math.ceil(peakRPS / serverCapacityRPS);
        
        // CPU utilization consideration
        double cpuMultiplier = 1.0 / req.cpuUtilizationTarget;
        int requiredForCPU = (int) Math.ceil(requiredForLoad * cpuMultiplier);
        
        // Add redundancy (N+1)
        int recommended = requiredForCPU + 1;
        
        return new CapacityPlan(
            requiredForCPU,
            recommended,
            (peakRPS / recommended) / serverCapacityRPS,
            recommended * serverCapacityRPS
        );
    }
}
```

### Performance Testing with JMeter

```java
@Component
public class PerformanceTestRunner {
    
    public void runLoadTest(String targetUrl, int users, int duration) {
        TestPlan testPlan = new TestPlan("Load Test");
        
        ThreadGroup threadGroup = new ThreadGroup();
        threadGroup.setNumThreads(users);
        threadGroup.setRampUp(60); // 1 minute ramp-up
        threadGroup.setDuration(duration);
        
        HTTPSampler httpSampler = new HTTPSampler();
        httpSampler.setDomain(targetUrl);
        httpSampler.setPath("/api/users");
        httpSampler.setMethod("GET");
        
        // Add listeners for results
        ResultCollector resultCollector = new ResultCollector();
        
        testPlan.addTestElement(threadGroup);
        threadGroup.addTestElement(httpSampler);
        testPlan.addTestElement(resultCollector);
        
        // Run test
        StandardJMeterEngine jmeter = new StandardJMeterEngine();
        jmeter.configure(testPlan);
        jmeter.run();
    }
}
```

---

## 🛡️ Reliability & Fault Tolerance

### Circuit Breaker Pattern

```java
@Component
public class CircuitBreaker {
    
    public enum State {
        CLOSED,    // Normal operation
        OPEN,      // Failing fast
        HALF_OPEN  // Testing if service recovered
    }
    
    private State state = State.CLOSED;
    private int failureCount = 0;
    private long lastFailureTime = 0;
    private final int failureThreshold = 5;
    private final long timeout = 60000; // 1 minute
    
    public <T> T execute(Supplier<T> operation) throws Exception {
        if (state == State.OPEN) {
            if (System.currentTimeMillis() - lastFailureTime >= timeout) {
                state = State.HALF_OPEN;
            } else {
                throw new CircuitBreakerOpenException("Circuit breaker is OPEN");
            }
        }
        
        try {
            T result = operation.get();
            onSuccess();
            return result;
        } catch (Exception e) {
            onFailure();
            throw e;
        }
    }
    
    private void onSuccess() {
        failureCount = 0;
        state = State.CLOSED;
    }
    
    private void onFailure() {
        failureCount++;
        lastFailureTime = System.currentTimeMillis();
        
        if (failureCount >= failureThreshold) {
            state = State.OPEN;
        }
    }
}
```

### Retry with Exponential Backoff

```java
@Component
public class RetryHandler {
    
    public <T> T executeWithRetry(
            Supplier<T> operation,
            int maxRetries,
            Duration initialDelay) {
        
        Exception lastException = null;
        
        for (int attempt = 0; attempt <= maxRetries; attempt++) {
            try {
                return operation.get();
            } catch (Exception e) {
                lastException = e;
                
                if (attempt == maxRetries) {
                    break; // Last attempt failed
                }
                
                // Exponential backoff: 2^attempt * initialDelay
                Duration delay = initialDelay.multipliedBy((long) Math.pow(2, attempt));
                
                try {
                    Thread.sleep(delay.toMillis());
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    throw new RuntimeException("Retry interrupted", ie);
                }
            }
        }
        
        throw new RuntimeException("Operation failed after " + maxRetries + " retries", lastException);
    }
}
```

---

## 🧪 Hands-On Lab: Building a Scalable Service

### Lab Overview
Build a user management service that demonstrates scalability patterns.

### Step 1: Create the Service

```java
@RestController
@RequestMapping("/api/users")
public class UserController {
    
    @Autowired
    private UserService userService;
    
    @Autowired
    private CircuitBreaker circuitBreaker;
    
    @GetMapping("/{id}")
    public ResponseEntity<User> getUser(@PathVariable UUID id) {
        try {
            User user = circuitBreaker.execute(() -> userService.findById(id));
            return ResponseEntity.ok(user);
        } catch (CircuitBreakerOpenException e) {
            return ResponseEntity.status(503).build();
        } catch (UserNotFoundException e) {
            return ResponseEntity.notFound().build();
        }
    }
    
    @PostMapping
    public ResponseEntity<User> createUser(@RequestBody @Valid CreateUserRequest request) {
        User user = userService.createUser(request);
        return ResponseEntity.status(201).body(user);
    }
}

@Service
public class UserService {
    
    @Autowired
    private UserRepository repository;
    
    @Autowired
    private RetryHandler retryHandler;
    
    @Cacheable("users")
    public User findById(UUID id) {
        return retryHandler.executeWithRetry(
            () -> repository.findById(id)
                .orElseThrow(() -> new UserNotFoundException(id)),
            3, // max retries
            Duration.ofMillis(100) // initial delay
        );
    }
    
    @Transactional
    public User createUser(CreateUserRequest request) {
        User user = User.builder()
            .id(UUID.randomUUID())
            .username(request.username())
            .email(request.email())
            .createdAt(Instant.now())
            .build();
            
        return repository.save(user);
    }
}
```

### Step 2: Add Caching

```java
@Configuration
@EnableCaching
public class CacheConfig {
    
    @Bean
    public CacheManager cacheManager() {
        RedisCacheManager.Builder builder = RedisCacheManager
            .RedisCacheManagerBuilder
            .fromConnectionFactory(redisConnectionFactory())
            .cacheDefaults(cacheConfiguration());
            
        return builder.build();
    }
    
    private RedisCacheConfiguration cacheConfiguration() {
        return RedisCacheConfiguration.defaultCacheConfig()
            .entryTtl(Duration.ofMinutes(10))
            .serializeKeysWith(RedisSerializationContext.SerializationPair
                .fromSerializer(new StringRedisSerializer()))
            .serializeValuesWith(RedisSerializationContext.SerializationPair
                .fromSerializer(new GenericJackson2JsonRedisSerializer()));
    }
}
```

### Step 3: Add Metrics

```java
@Component
public class UserMetrics {
    
    private final Counter userCreations;
    private final Timer userLookupTimer;
    private final Gauge activeUsers;
    
    public UserMetrics(MeterRegistry meterRegistry) {
        this.userCreations = Counter.builder("user.creations")
            .description("Number of users created")
            .register(meterRegistry);
            
        this.userLookupTimer = Timer.builder("user.lookup.duration")
            .description("User lookup duration")
            .register(meterRegistry);
            
        this.activeUsers = Gauge.builder("user.active.count")
            .description("Number of active users")
            .register(meterRegistry, this, UserMetrics::getActiveUserCount);
    }
    
    public void recordUserCreation() {
        userCreations.increment();
    }
    
    public Timer.Sample startLookupTimer() {
        return Timer.start();
    }
    
    private double getActiveUserCount() {
        // Implementation to count active users
        return userService.countActiveUsers();
    }
}
```

---

## 📝 Interview Questions & Answers

### Basic Questions

**Q1: What is the CAP theorem and can you give real-world examples?**

**A:** The CAP theorem states that in a distributed system, you can only guarantee two out of three properties: Consistency, Availability, and Partition tolerance.

Real examples:
- **CA (Traditional RDBMS)**: PostgreSQL in a single datacenter - provides consistency and availability but fails during network partitions
- **AP (DNS, CDNs)**: DNS system prioritizes availability and partition tolerance but allows eventual consistency
- **CP (MongoDB, Consul)**: These systems maintain consistency and partition tolerance but may become unavailable during network splits

**Q2: How would you design a system to handle 1 million concurrent users?**

**A:** Key strategies:
1. **Horizontal scaling**: Multiple application servers behind load balancers
2. **Database sharding**: Distribute data across multiple databases
3. **Caching**: Redis/Memcached for frequently accessed data
4. **CDN**: Static content delivery
5. **Asynchronous processing**: Message queues for heavy operations
6. **Microservices**: Independent scaling of different features

**Q3: What's the difference between latency and throughput?**

**A:**
- **Latency**: Time to process a single request (milliseconds)
- **Throughput**: Number of requests processed per unit time (requests/second)

They're often inversely related - optimizing for one may hurt the other.

### Advanced Questions

**Q4: How would you handle database failover in a distributed system?**

**A:** 
```java
@Component
public class DatabaseFailoverHandler {
    
    private final DataSource primaryDb;
    private final DataSource replicaDb;
    private final HealthChecker healthChecker;
    
    public <T> T executeQuery(Function<DataSource, T> query) {
        if (healthChecker.isPrimaryHealthy()) {
            try {
                return query.apply(primaryDb);
            } catch (Exception e) {
                log.warn("Primary DB failed, switching to replica");
                healthChecker.markPrimaryUnhealthy();
            }
        }
        
        return query.apply(replicaDb);
    }
}
```

**Q5: Design a rate limiting system for an API.**

**A:** See the complete implementation in [Module 05: Caching](../05-caching/) and [Rate Limiter Case Study](../13-case-studies/rate-limiter/).

---

## 📊 Capacity Planning Exercise

### Scenario: Social Media Platform

**Requirements:**
- 100M daily active users
- Each user posts 2 times per day on average
- Each user reads 50 posts per day
- Peak traffic is 3x average
- Target response time: 200ms
- Target availability: 99.9%

### Calculate:

1. **Read QPS**: 
   - Daily reads: 100M × 50 = 5B
   - Average RPS: 5B / 86400 = 57,870
   - Peak RPS: 57,870 × 3 = 173,610

2. **Write QPS**:
   - Daily writes: 100M × 2 = 200M  
   - Average RPS: 200M / 86400 = 2,315
   - Peak RPS: 2,315 × 3 = 6,945

3. **Storage**:
   - Average post size: 1KB
   - Daily storage: 200M × 1KB = 200GB
   - Annual storage: 200GB × 365 = 73TB

4. **Servers Required**:
   - Assuming 1 server handles 1000 RPS
   - Read servers: 173,610 / 1000 = 174 servers
   - Write servers: 6,945 / 1000 = 7 servers
   - Total: 181 servers + redundancy = ~200 servers

---

## ⚠️ Failure Scenarios

### Scenario 1: Database Goes Down

**Impact**: All read/write operations fail
**Detection**: Health checks, monitoring alerts
**Recovery**:
```java
@Component
public class DatabaseFailureHandler {
    
    @EventListener
    public void handleDatabaseFailure(DatabaseFailureEvent event) {
        // 1. Switch to read replicas for reads
        routingDataSource.switchToReplica();
        
        // 2. Enable write buffering
        writeBuffer.enableBuffering();
        
        // 3. Notify operations team
        alertService.sendCriticalAlert("Database primary failed");
        
        // 4. Start automatic recovery process
        recoveryService.startDatabaseRecovery();
    }
}
```

### Scenario 2: Load Balancer Failure

**Impact**: Traffic can't reach servers
**Detection**: External monitoring, synthetic tests
**Recovery**:
- DNS failover to backup load balancer
- Auto-scaling triggers to handle traffic redistribution
- Circuit breakers prevent cascade failures

### Scenario 3: Memory Leak

**Impact**: Gradual performance degradation, eventual OOM
**Detection**: Memory monitoring, GC metrics
**Recovery**:
```java
@Component
public class MemoryMonitor {
    
    @Scheduled(fixedRate = 30000) // Every 30 seconds
    public void checkMemoryUsage() {
        MemoryMXBean memoryBean = ManagementFactory.getMemoryMXBean();
        MemoryUsage heapUsage = memoryBean.getHeapMemoryUsage();
        
        double usedPercent = (double) heapUsage.getUsed() / heapUsage.getMax();
        
        if (usedPercent > 0.9) {
            // Trigger alerts and graceful shutdown
            log.error("Memory usage critical: {}%", usedPercent * 100);
            shutdownService.initiateGracefulShutdown();
        }
    }
}
```

---

## 🎯 Key Takeaways

1. **No Perfect Solution**: Every design involves trade-offs
2. **Start Simple**: Begin with a monolith, scale when needed
3. **Measure Everything**: You can't improve what you don't measure
4. **Plan for Failure**: Everything will fail eventually
5. **Understand Your Requirements**: Different systems need different patterns

## 📚 Additional Resources

- **Books**: "Designing Data-Intensive Applications" by Martin Kleppmann
- **Papers**: "The CAP Theorem" by Eric Brewer
- **Tools**: Apache JMeter, Gatling, Artillery for load testing
- **Monitoring**: Prometheus + Grafana setup guides

---

## 🚀 Next Module

Ready for [Module 02: Networking](../02-networking/)? You'll learn about load balancers, CDNs, and network protocols that make distributed systems possible.

## 🎯 Module Completion Checklist

- [ ] Read all core concepts
- [ ] Understand CAP theorem implications  
- [ ] Complete hands-on lab
- [ ] Practice interview questions
- [ ] Run capacity planning exercise
- [ ] Review failure scenarios
- [ ] Take module quiz (80%+ to pass)

**Estimated Time**: 12-15 hours
