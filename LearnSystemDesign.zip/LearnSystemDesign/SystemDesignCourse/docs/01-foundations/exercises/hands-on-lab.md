# Foundations Module - Hands-On Lab

## 🎯 Lab Objectives

By completing this lab, you will:
- Build a scalable user management service using Java 21 and Spring Boot
- Implement resilience patterns (Circuit Breaker, Retry, Rate Limiting)
- Add comprehensive monitoring and metrics
- Practice capacity planning and load testing
- Experience system design interview scenarios

## 📋 Prerequisites

- Java 21 installed
- Docker and Docker Compose
- Maven 3.9+
- Your favorite IDE (IntelliJ IDEA recommended)
- Postman or curl for API testing

## 🚀 Lab Setup

### 1. Start Infrastructure
```bash
# Navigate to course directory
cd SystemDesignCourse

# Start all required services
./scripts/start-infra.sh

# Verify services are running
docker ps
```

### 2. Build and Run the Service
```bash
# Navigate to foundations module
cd code/modules/01-foundations

# Build the application
mvn clean compile

# Run the application
mvn spring-boot:run
```

### 3. Verify Setup
```bash
# Health check
curl http://localhost:8080/api/v1/users/health

# Actuator endpoints
curl http://localhost:8080/actuator/health
curl http://localhost:8080/actuator/metrics
```

---

## 🧪 Exercise 1: Basic CRUD Operations

### Task: Implement and test basic user operations

#### 1.1 Create Users
```bash
# Create a new user
curl -X POST http://localhost:8080/api/v1/users \
  -H "Content-Type: application/json" \
  -d '{
    "username": "john.doe",
    "email": "john@example.com",
    "firstName": "John",
    "lastName": "Doe"
  }'

# Expected response: 201 Created with user details
```

#### 1.2 Retrieve Users
```bash
# Get user by ID (use ID from creation response)
curl http://localhost:8080/api/v1/users/{USER_ID}

# Get user by username
curl http://localhost:8080/api/v1/users/username/john.doe

# List all users with pagination
curl "http://localhost:8080/api/v1/users?page=0&size=10&sortBy=createdAt&sortDir=desc"
```

#### 1.3 Search Users
```bash
# Search by username
curl "http://localhost:8080/api/v1/users/search?query=john"

# Search by email domain
curl "http://localhost:8080/api/v1/users/search?query=example.com"
```

#### 1.4 Update and Delete
```bash
# Update user
curl -X PUT http://localhost:8080/api/v1/users/{USER_ID} \
  -H "Content-Type: application/json" \
  -d '{
    "username": "john.doe.updated",
    "email": "john.updated@example.com",
    "firstName": "John",
    "lastName": "Doe"
  }'

# Soft delete user
curl -X DELETE http://localhost:8080/api/v1/users/{USER_ID}

# Verify user is marked as deleted
curl http://localhost:8080/api/v1/users/{USER_ID}
```

### ✅ Exercise 1 Validation
- [ ] Successfully created multiple users
- [ ] Retrieved users by ID and username
- [ ] Paginated through user lists
- [ ] Searched users with different queries
- [ ] Updated user information
- [ ] Soft deleted users

---

## 🔧 Exercise 2: Resilience Patterns

### Task: Test circuit breaker and retry mechanisms

#### 2.1 Circuit Breaker Testing

**Simulate Database Failures:**
```bash
# Stop PostgreSQL to trigger circuit breaker
docker stop system-design-postgres

# Try to fetch users (should trigger circuit breaker)
for i in {1..10}; do
  curl -w "Status: %{http_code}, Time: %{time_total}s\n" \
    http://localhost:8080/api/v1/users/health
  sleep 1
done

# Restart PostgreSQL
docker start system-design-postgres

# Test recovery
for i in {1..5}; do
  curl -w "Status: %{http_code}, Time: %{time_total}s\n" \
    http://localhost:8080/api/v1/users/health
  sleep 2
done
```

#### 2.2 Retry Mechanism Testing

**Create Custom Failure Test:**
```java
// Add this test method to UserServiceTest.java
@Test
void testRetryMechanism() {
    // Given - Repository fails first 2 times, succeeds on 3rd
    when(userRepository.findById(testUserId))
        .thenThrow(new DataAccessException("DB Error") {})
        .thenThrow(new DataAccessException("DB Error") {})
        .thenReturn(Optional.of(testUser));
    
    when(retryHandler.executeWithRetry(any(), eq(3), any()))
        .thenCallRealMethod();
    
    // When
    User result = userService.findById(testUserId);
    
    // Then
    assertNotNull(result);
    verify(userRepository, times(3)).findById(testUserId);
}
```

#### 2.3 Monitor Circuit Breaker State
```bash
# Check circuit breaker metrics
curl http://localhost:8080/actuator/metrics/resilience4j.circuitbreaker.state

# Check retry metrics
curl http://localhost:8080/actuator/metrics/resilience4j.retry.calls
```

### ✅ Exercise 2 Validation
- [ ] Circuit breaker opens under failure conditions
- [ ] Circuit breaker transitions through states correctly
- [ ] Retry mechanism attempts configured number of retries
- [ ] Service recovers when dependencies are restored
- [ ] Metrics accurately reflect resilience state

---

## 📊 Exercise 3: Monitoring and Metrics

### Task: Implement comprehensive monitoring

#### 3.1 Custom Metrics Implementation

**Add Business Metrics:**
```java
// In UserService.java, add this method
@Timed(value = "user.business.operation", description = "Business operation timing")
public BusinessOperationResult performBusinessOperation(String userId) {
    Timer.Sample sample = Timer.start();
    
    try {
        // Simulate business logic
        User user = findById(UUID.fromString(userId));
        
        // Record success
        userMetrics.recordUserLogin(true);
        
        return BusinessOperationResult.success(user);
    } catch (Exception e) {
        // Record failure
        userMetrics.recordUserLogin(false);
        userMetrics.recordUserErrorRate("business_operation_failed");
        
        throw e;
    } finally {
        sample.stop();
    }
}
```

#### 3.2 Load Testing with Metrics
```bash
# Generate load to see metrics
for i in {1..100}; do
  curl -X POST http://localhost:8080/api/v1/users \
    -H "Content-Type: application/json" \
    -d "{
      \"username\": \"user$i\",
      \"email\": \"user$i@example.com\",
      \"firstName\": \"User\",
      \"lastName\": \"$i\"
    }" &
done

# Wait for requests to complete
wait

# Check metrics
curl http://localhost:8080/actuator/metrics/users.created.total
curl http://localhost:8080/actuator/metrics/users.lookup.duration
curl http://localhost:8080/actuator/metrics/http.server.requests
```

#### 3.3 View Metrics in Grafana
```bash
# Open Grafana dashboard
open http://localhost:3000

# Login: admin/admin
# Import dashboard from: infra/monitoring/grafana/dashboards/user-service.json
```

### ✅ Exercise 3 Validation
- [ ] Custom metrics are recorded correctly
- [ ] Metrics appear in Prometheus targets
- [ ] Grafana dashboard displays service metrics
- [ ] Load testing generates realistic metric data
- [ ] Alert rules trigger on threshold breaches

---

## 🏋️ Exercise 4: Capacity Planning

### Task: Calculate capacity requirements and test limits

#### 4.1 Performance Baseline
```bash
# Create baseline performance test
cd scripts/load-tests

# Run performance test
./run-performance-test.sh --users=50 --duration=60s --endpoint=/api/v1/users
```

#### 4.2 Capacity Calculations

**Given Requirements:**
- 10,000 daily active users
- Each user makes 20 requests per day on average
- Peak traffic is 3x average
- Target response time: < 200ms p95

**Calculate:**
```java
// Use the CapacityPlanner from the code
CapacityPlanner planner = new CapacityPlanner();

CapacityRequirements requirements = new CapacityRequirements(
    10000,  // expectedUsers
    20.0,   // avgRequestsPerUser
    3,      // peakMultiplier
    0.2,    // averageResponseTime (200ms)
    0.7     // cpuUtilizationTarget (70%)
);

CapacityPlan plan = planner.calculateCapacity(requirements);
System.out.println(plan);
```

#### 4.3 Stress Testing
```bash
# Gradually increase load to find breaking point
./gradual-load-test.sh

# Results should show:
# - Maximum sustainable RPS
# - Response time degradation points
# - Error rate thresholds
# - Resource utilization limits
```

#### 4.4 Database Connection Pool Testing
```bash
# Test connection pool limits
# Simulate 200 concurrent database requests
for i in {1..200}; do
  curl http://localhost:8080/api/v1/users/{USER_ID} &
done

# Monitor connection pool metrics
curl http://localhost:8080/actuator/metrics/hikaricp.connections.active
```

### ✅ Exercise 4 Validation
- [ ] Baseline performance established
- [ ] Capacity calculations completed for given requirements
- [ ] Breaking point identified through stress testing
- [ ] Database connection limits understood
- [ ] Recommendations documented for scaling

---

## 🚨 Exercise 5: Failure Scenarios

### Task: Test system behavior under various failure conditions

#### 5.1 Database Failure Recovery
```bash
# Test scenario: Database goes down during high load
# 1. Start load test
./run-load-test.sh --users=100 --duration=300s &

# 2. Wait 60 seconds, then stop database
sleep 60
docker stop system-design-postgres

# 3. Observe circuit breaker behavior for 120 seconds
# 4. Restart database
docker start system-design-postgres

# 5. Observe recovery behavior
```

#### 5.2 Memory Pressure Testing
```bash
# Simulate memory pressure
# Create many users in batch to increase memory usage
curl -X POST "http://localhost:8080/api/v1/users/batch?count=1000"

# Monitor memory usage
curl http://localhost:8080/actuator/metrics/jvm.memory.used
curl http://localhost:8080/actuator/metrics/jvm.gc.pause
```

#### 5.3 Redis Cache Failure
```bash
# Stop Redis cache
docker stop system-design-redis

# Test application behavior (should fall back to database)
for i in {1..10}; do
  time curl http://localhost:8080/api/v1/users/{USER_ID}
done

# Restart Redis
docker start system-design-redis

# Verify cache is working again
for i in {1..10}; do
  time curl http://localhost:8080/api/v1/users/{USER_ID}
done
```

#### 5.4 Network Partition Simulation
```bash
# Simulate network issues with increased latency
# This requires additional tools like toxiproxy or network configuration
# Document the expected behavior and recovery mechanisms
```

### ✅ Exercise 5 Validation
- [ ] Circuit breaker activates during database failures
- [ ] Application gracefully degrades during cache failures
- [ ] Memory pressure is handled without crashes
- [ ] Recovery mechanisms work when dependencies restore
- [ ] Monitoring alerts trigger for all failure scenarios

---

## 🎭 Exercise 6: Interview Simulation

### Task: Practice explaining your implementation in interview format

#### 6.1 System Design Questions

**Question 1: "Explain the architecture of your user service"**

*Practice Response Structure:*
1. **High-level overview** (2 minutes)
2. **Data model** (2 minutes)
3. **API design** (2 minutes)
4. **Scalability considerations** (3 minutes)
5. **Reliability patterns** (3 minutes)

**Question 2: "How would you scale this to handle 1 million users?"**

*Key Points to Cover:*
- Database sharding strategies
- Caching layers (Redis cluster)
- Load balancing (horizontal scaling)
- Connection pooling optimization
- Async processing for heavy operations

**Question 3: "What happens when the database goes down?"**

*Demonstrate:*
- Circuit breaker pattern
- Graceful degradation
- Cache fallback strategies
- Monitoring and alerting

#### 6.2 Code Review Simulation

**Prepare to explain:**
- Why you chose specific patterns
- Trade-offs in your implementation
- Alternative approaches considered
- Performance optimizations applied

#### 6.3 Capacity Planning Interview

**Be ready to:**
- Calculate RPS requirements from user stories
- Estimate database storage needs
- Plan for traffic growth patterns
- Justify infrastructure costs

### ✅ Exercise 6 Validation
- [ ] Can explain architecture clearly in 10 minutes
- [ ] Handles follow-up questions confidently
- [ ] Demonstrates deep understanding of trade-offs
- [ ] Shows practical implementation knowledge
- [ ] Connects code to system design principles

---

## 📈 Exercise 7: Advanced Scenarios

### Task: Implement advanced system design patterns

#### 7.1 Read/Write Splitting
```java
// Implement read replica routing
@Service
public class UserReadService {
    
    @Autowired
    @Qualifier("readOnlyUserRepository")
    private UserRepository readRepository;
    
    @Transactional(readOnly = true)
    public User findById(UUID id) {
        return readRepository.findById(id)
            .orElseThrow(() -> new UserNotFoundException("User not found: " + id));
    }
}
```

#### 7.2 Event-Driven Architecture
```java
// Add event publishing to user operations
@EventListener
public void handleUserCreated(UserCreatedEvent event) {
    // Send welcome email
    // Update search index
    // Generate analytics events
}
```

#### 7.3 API Versioning
```java
// Implement API versioning
@RestController
@RequestMapping("/api/v2/users")
public class UserV2Controller {
    // Enhanced user API with additional features
}
```

### ✅ Exercise 7 Validation
- [ ] Read/write splitting implemented
- [ ] Event-driven patterns demonstrated
- [ ] API versioning strategy applied
- [ ] Backward compatibility maintained
- [ ] Performance impact measured

---

## 🎯 Lab Completion Checklist

### Core Functionality
- [ ] User CRUD operations working
- [ ] Pagination and search implemented
- [ ] Input validation and error handling
- [ ] Database integration with JPA

### Resilience Patterns
- [ ] Circuit breaker pattern implemented
- [ ] Retry mechanism with exponential backoff
- [ ] Timeout handling
- [ ] Graceful degradation

### Monitoring & Observability
- [ ] Custom metrics implemented
- [ ] Health checks configured
- [ ] Distributed tracing enabled
- [ ] Log aggregation working

### Performance & Scale
- [ ] Load testing completed
- [ ] Capacity planning calculated
- [ ] Breaking points identified
- [ ] Optimization recommendations

### Interview Readiness
- [ ] Can explain architecture in 10 minutes
- [ ] Handles technical deep-dive questions
- [ ] Demonstrates practical trade-offs
- [ ] Shows production readiness

---

## 🚀 Next Steps

### For Further Learning
1. **Complete Additional Modules**: Move to networking, databases, caching
2. **Build Case Studies**: Implement URL shortener, chat system
3. **Practice Interviews**: Use the interview mastery module
4. **Contribute**: Add new features or optimizations

### Real-World Application
1. **Deploy to Cloud**: Try AWS, GCP, or Azure deployment
2. **Add More Services**: Build a complete microservices ecosystem
3. **Production Hardening**: Add security, compliance, and monitoring
4. **Performance Tuning**: Optimize for specific use cases

---

## 📚 Resources

### Documentation
- [Spring Boot Reference](https://docs.spring.io/spring-boot/docs/current/reference/html/)
- [Resilience4j Documentation](https://resilience4j.readme.io/)
- [Micrometer Metrics](https://micrometer.io/docs)

### Tools
- [Grafana Dashboards](http://localhost:3000)
- [Prometheus Metrics](http://localhost:9090)
- [Application Health](http://localhost:8080/actuator)

### Further Reading
- "Building Microservices" by Sam Newman
- "Release It!" by Michael Nygard
- "Java Performance" by Scott Oaks

**Congratulations! You've completed the Foundations module hands-on lab. You now have practical experience with building scalable, resilient microservices using Java 21 and Spring Boot.**
