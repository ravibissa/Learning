# Caching Systems Lab - Hands-On Exercises

## 🎯 **Lab Overview**

This comprehensive lab provides hands-on experience with multi-tier caching patterns, Redis implementation, and cache optimization strategies essential for system design interviews and production systems.

---

## 🔧 **Lab Setup**

### Prerequisites
- Java 21
- Docker & Docker Compose
- Redis CLI
- Spring Boot 3.2+
- Micrometer for metrics

### Environment Setup

```bash
# Clone the lab repository
git clone https://github.com/system-design-course/caching-lab.git
cd caching-lab

# Start Redis cluster with Docker Compose
docker-compose up -d redis-cluster

# Verify Redis cluster
redis-cli -c -p 7001 cluster nodes
redis-cli -c -p 7001 cluster info

# Start monitoring stack
docker-compose up -d prometheus grafana

# Access Grafana dashboard
open http://localhost:3000 (admin/admin)
```

### Docker Compose Configuration

```yaml
# docker-compose.yml
version: '3.8'
services:
  redis-master-1:
    image: redis:7.2-alpine
    ports:
      - "7001:7001"
    command: >
      redis-server --port 7001 --cluster-enabled yes
      --cluster-config-file nodes-7001.conf
      --cluster-node-timeout 5000
      --appendonly yes
    volumes:
      - redis-data-1:/data

  redis-master-2:
    image: redis:7.2-alpine
    ports:
      - "7002:7002"
    command: >
      redis-server --port 7002 --cluster-enabled yes
      --cluster-config-file nodes-7002.conf
      --cluster-node-timeout 5000
      --appendonly yes
    volumes:
      - redis-data-2:/data

  redis-master-3:
    image: redis:7.2-alpine
    ports:
      - "7003:7003"
    command: >
      redis-server --port 7003 --cluster-enabled yes
      --cluster-config-file nodes-7003.conf
      --cluster-node-timeout 5000
      --appendonly yes
    volumes:
      - redis-data-3:/data

  prometheus:
    image: prom/prometheus:latest
    ports:
      - "9090:9090"
    volumes:
      - ./monitoring/prometheus.yml:/etc/prometheus/prometheus.yml

  grafana:
    image: grafana/grafana:latest
    ports:
      - "3000:3000"
    environment:
      - GF_SECURITY_ADMIN_PASSWORD=admin
    volumes:
      - grafana-data:/var/lib/grafana

volumes:
  redis-data-1:
  redis-data-2:
  redis-data-3:
  grafana-data:
```

---

## 🏋️ **Exercise 1: Multi-Tier Cache Implementation**

### **Objective**
Implement a three-tier caching system (Local → Redis → Database) with proper metrics and monitoring.

### **Tasks**

#### **Task 1.1: Implement Local Cache (L1)**

```java
// LocalCacheManager.java
@Component
public class LocalCacheManager {
    
    private final Map<String, CacheEntry> cache = new ConcurrentHashMap<>();
    private final int maxSize = 10000;
    private final Duration defaultTTL = Duration.ofMinutes(5);
    
    // TODO: Implement LRU eviction policy
    public void put(String key, Object value, Duration ttl) {
        // Your implementation here
    }
    
    // TODO: Implement get with access time tracking
    public <T> Optional<T> get(String key, Class<T> type) {
        // Your implementation here
    }
    
    // TODO: Implement automatic cleanup of expired entries
    @Scheduled(fixedRate = 60000)
    public void cleanupExpired() {
        // Your implementation here
    }
    
    // TODO: Implement cache statistics
    public CacheStats getStats() {
        // Your implementation here
    }
}
```

**Requirements:**
- Implement LRU (Least Recently Used) eviction when cache is full
- Track access times and counts for each entry
- Automatic cleanup of expired entries every minute
- Thread-safe operations
- Comprehensive cache statistics

**Validation Criteria:**
- Cache hit rate > 85% for repeated access patterns
- LRU eviction works correctly under memory pressure
- No memory leaks from expired entries
- Thread safety under concurrent access

#### **Task 1.2: Implement Redis Distributed Cache (L2)**

```java
// RedisDistributedCache.java
@Service
public class RedisDistributedCache {
    
    @Autowired
    private RedisTemplate<String, Object> redisTemplate;
    
    // TODO: Implement cache-aside pattern
    public <T> Optional<T> get(String key, Class<T> type) {
        // Your implementation here
    }
    
    // TODO: Implement write-through caching
    public void put(String key, Object value, Duration ttl) {
        // Your implementation here
    }
    
    // TODO: Implement pattern-based cache invalidation
    public void evictPattern(String pattern) {
        // Your implementation here using Lua script
    }
    
    // TODO: Implement distributed locking
    public boolean acquireLock(String lockKey, String lockValue, Duration timeout) {
        // Your implementation here
    }
    
    public void releaseLock(String lockKey, String lockValue) {
        // Your implementation here using Lua script
    }
}
```

**Requirements:**
- Implement cache-aside pattern with fallback to database
- Use Lua scripts for atomic operations
- Implement distributed locking mechanism
- Pattern-based cache invalidation
- Connection pooling and error handling

#### **Task 1.3: Multi-Tier Cache Service Integration**

```java
// MultiTierCacheService.java
@Service
public class MultiTierCacheService {
    
    @Autowired
    private LocalCacheManager localCache;
    
    @Autowired
    private RedisDistributedCache distributedCache;
    
    @Autowired
    private UserRepository userRepository;
    
    // TODO: Implement multi-tier cache retrieval
    public Optional<User> getUser(String userId) {
        // Check L1 cache first
        // Then L2 cache (Redis)
        // Finally database
        // Populate upper cache levels on cache miss
    }
    
    // TODO: Implement cache invalidation cascade
    public void invalidateUser(String userId) {
        // Invalidate from all cache levels
        // Invalidate related cache entries
    }
    
    // TODO: Implement cache warming strategy
    public void warmCache(List<String> popularUserIds) {
        // Pre-load popular users into cache
    }
}
```

### **Exercise 1 Deliverables**
1. Complete multi-tier cache implementation
2. Unit tests with 90%+ coverage
3. Performance benchmarks showing cache effectiveness
4. Monitoring dashboard showing cache metrics

---

## 🏋️ **Exercise 2: Cache Consistency Patterns**

### **Objective**
Implement different cache consistency patterns and understand their trade-offs.

### **Tasks**

#### **Task 2.1: Write-Through Cache Pattern**

```java
// WriteThroughCacheService.java
@Service
public class WriteThroughCacheService {
    
    // TODO: Implement write-through for user updates
    @Transactional
    public User updateUser(String userId, UserUpdateRequest request) {
        // Update database first
        // Update cache immediately
        // Handle errors and rollback if needed
    }
    
    // TODO: Implement cache consistency validation
    public boolean validateCacheConsistency(String userId) {
        // Compare cache and database values
        // Return true if consistent
    }
}
```

#### **Task 2.2: Write-Behind (Write-Back) Cache Pattern**

```java
// WriteBehindCacheService.java
@Service
public class WriteBehindCacheService {
    
    private final Map<String, PendingWrite> writeBuffer = new ConcurrentHashMap<>();
    
    // TODO: Implement write-behind for analytics data
    public void recordUserActivity(String userId, ActivityEvent event) {
        // Update cache immediately
        // Buffer database write
        // Batch writes for performance
    }
    
    // TODO: Implement batch flush mechanism
    @Scheduled(fixedDelay = 30000)
    public void flushPendingWrites() {
        // Batch write buffered data to database
        // Handle failures and retries
    }
}
```

#### **Task 2.3: Event-Driven Cache Invalidation**

```java
// CacheInvalidationService.java
@Service
public class CacheInvalidationService {
    
    // TODO: Implement event-driven cache invalidation
    @EventListener
    public void handleUserUpdated(UserUpdatedEvent event) {
        // Invalidate user cache
        // Invalidate related caches (user lists, search results)
        // Notify other service instances
    }
    
    // TODO: Implement distributed cache invalidation
    @KafkaListener(topics = "cache-invalidation")
    public void handleCacheInvalidationEvent(CacheInvalidationEvent event) {
        // Process cache invalidation from other services
    }
}
```

### **Exercise 2 Deliverables**
1. Implementation of all three consistency patterns
2. Consistency validation tests
3. Performance comparison between patterns
4. Documentation of trade-offs and use cases

---

## 🏋️ **Exercise 3: Redis Cluster and Sharding**

### **Objective**
Configure and optimize Redis cluster for high availability and performance.

### **Tasks**

#### **Task 3.1: Redis Cluster Configuration**

```bash
# Initialize Redis cluster
redis-cli --cluster create \
  127.0.0.1:7001 127.0.0.1:7002 127.0.0.1:7003 \
  127.0.0.1:7004 127.0.0.1:7005 127.0.0.1:7006 \
  --cluster-replicas 1

# Verify cluster status
redis-cli -c -p 7001 cluster info
redis-cli -c -p 7001 cluster nodes

# Test slot distribution
for i in {1..1000}; do
  redis-cli -c -p 7001 set "user:$i" "value$i"
done

# Check slot distribution
redis-cli -c -p 7001 cluster nodes | grep master
```

#### **Task 3.2: Consistent Hashing Implementation**

```java
// ConsistentHashingService.java
@Service
public class ConsistentHashingService {
    
    private final TreeMap<Long, String> hashRing = new TreeMap<>();
    private final int virtualNodes = 150;
    
    // TODO: Implement consistent hashing algorithm
    public void addNode(String node) {
        // Add virtual nodes to the ring
    }
    
    public void removeNode(String node) {
        // Remove virtual nodes from the ring
    }
    
    public String getNode(String key) {
        // Find the appropriate node for the key
    }
    
    // TODO: Implement hash function with good distribution
    private long hash(String input) {
        // Use a hash function with good distribution properties
    }
}
```

#### **Task 3.3: Cluster Client Implementation**

```java
// RedisClusterClient.java
@Service
public class RedisClusterClient {
    
    @Autowired
    private RedisClusterTemplate<String, Object> clusterTemplate;
    
    // TODO: Implement cluster-aware operations
    public void setWithSharding(String key, Object value, Duration ttl) {
        // Handle Redis cluster redirection
        // Implement retry logic for cluster failures
    }
    
    // TODO: Implement cluster health monitoring
    public ClusterHealth getClusterHealth() {
        // Check all nodes
        // Return cluster status and metrics
    }
    
    // TODO: Implement cluster rebalancing
    public void rebalanceCluster() {
        // Redistribute slots if needed
        // Handle data migration
    }
}
```

### **Exercise 3 Deliverables**
1. Working Redis cluster configuration
2. Consistent hashing implementation with tests
3. Cluster monitoring dashboard
4. Failover and recovery testing results

---

## 🏋️ **Exercise 4: Cache Performance Optimization**

### **Objective**
Optimize cache performance and implement comprehensive monitoring.

### **Tasks**

#### **Task 4.1: Cache Hit Rate Optimization**

```java
// CacheOptimizationService.java
@Service
public class CacheOptimizationService {
    
    // TODO: Implement intelligent TTL calculation
    public Duration calculateOptimalTTL(String cacheKey, Object value) {
        // Analyze access patterns
        // Calculate optimal TTL based on data volatility
    }
    
    // TODO: Implement cache warming strategies
    public void warmCacheBasedOnPredictions() {
        // Predict which data will be accessed
        // Pre-load into cache
    }
    
    // TODO: Implement adaptive cache sizing
    public void adjustCacheSize() {
        // Monitor memory usage and hit rates
        // Adjust cache size dynamically
    }
}
```

#### **Task 4.2: Performance Monitoring Dashboard**

```java
// CacheMetricsCollector.java
@Component
public class CacheMetricsCollector {
    
    @Autowired
    private MeterRegistry meterRegistry;
    
    // TODO: Implement comprehensive cache metrics
    public void recordCacheOperation(String operation, String result, Duration duration) {
        // Record cache operations with detailed metrics
    }
    
    // TODO: Implement cache health scoring
    public double calculateCacheHealthScore() {
        // Calculate overall cache health based on multiple metrics
    }
    
    // TODO: Implement predictive alerting
    public void checkForPerformanceAnomalies() {
        // Detect performance degradation early
        // Send alerts before issues become critical
    }
}
```

#### **Task 4.3: Load Testing and Benchmarking**

```java
// CacheLoadTest.java
@Component
public class CacheLoadTest {
    
    // TODO: Implement realistic load testing
    public void runLoadTest(int concurrentUsers, Duration testDuration) {
        // Simulate realistic access patterns
        // Measure performance under load
    }
    
    // TODO: Implement cache performance benchmarking
    public BenchmarkResults benchmarkCachePerformance() {
        // Test different cache configurations
        // Compare performance metrics
    }
}
```

### **Exercise 4 Deliverables**
1. Performance optimization implementations
2. Comprehensive monitoring dashboard
3. Load testing results and analysis
4. Performance tuning recommendations

---

## 🏋️ **Exercise 5: Advanced Caching Patterns**

### **Objective**
Implement advanced caching patterns for complex scenarios.

### **Tasks**

#### **Task 5.1: Cache-Aside with Refresh-Ahead**

```java
// RefreshAheadCacheService.java
@Service
public class RefreshAheadCacheService {
    
    // TODO: Implement refresh-ahead pattern
    public <T> Optional<T> getWithRefreshAhead(String key, Class<T> type, 
                                              Supplier<Optional<T>> dataLoader) {
        // Check if cache entry is near expiration
        // Trigger background refresh if needed
        // Return current cached value immediately
    }
    
    // TODO: Implement background refresh scheduling
    @Async
    public void refreshCacheEntry(String key, Supplier<Optional<Object>> dataLoader) {
        // Load fresh data in background
        // Update cache asynchronously
    }
}
```

#### **Task 5.2: Hierarchical Cache with Dependencies**

```java
// HierarchicalCacheService.java
@Service
public class HierarchicalCacheService {
    
    // TODO: Implement cache dependencies
    public void putWithDependencies(String key, Object value, 
                                   Duration ttl, Set<String> dependencies) {
        // Store cache entry with dependency information
        // Track reverse dependencies
    }
    
    // TODO: Implement cascading invalidation
    public void invalidateWithDependencies(String key) {
        // Invalidate the key
        // Invalidate all dependent cache entries
        // Handle circular dependencies
    }
}
```

#### **Task 5.3: Distributed Cache Synchronization**

```java
// DistributedCacheSyncService.java
@Service
public class DistributedCacheSyncService {
    
    // TODO: Implement cross-region cache synchronization
    public void synchronizeCacheAcrossRegions(String key, Object value) {
        // Replicate cache updates to other regions
        // Handle network partitions and failures
    }
    
    // TODO: Implement conflict resolution
    public Object resolveCacheConflict(String key, Object local, Object remote) {
        // Implement last-writer-wins or custom resolution
    }
}
```

### **Exercise 5 Deliverables**
1. Advanced caching pattern implementations
2. Dependency management system
3. Cross-region synchronization testing
4. Conflict resolution strategies

---

## 📊 **Lab Assessment and Validation**

### **Performance Benchmarks**

| Metric | Target | Your Result |
|--------|--------|-------------|
| Cache Hit Rate | > 95% | _____ |
| L1 Cache Latency | < 0.1ms | _____ |
| L2 Cache Latency | < 2ms | _____ |
| Database Fallback | < 50ms | _____ |
| Cluster Failover Time | < 5s | _____ |
| Write Throughput | > 10,000 ops/sec | _____ |
| Read Throughput | > 50,000 ops/sec | _____ |

### **Validation Tests**

```bash
# Run performance tests
./gradlew test --tests "*CachePerformanceTest"

# Run consistency tests
./gradlew test --tests "*CacheConsistencyTest"

# Run load tests
./gradlew test --tests "*CacheLoadTest"

# Generate performance report
./gradlew jacocoTestReport
```

### **Monitoring Validation**

1. **Grafana Dashboards**
   - Cache hit/miss rates
   - Latency percentiles
   - Error rates and recovery times
   - Resource utilization

2. **Alerting Rules**
   - Cache hit rate < 90%
   - Latency > 10ms P99
   - Error rate > 1%
   - Memory usage > 85%

---

## 🎯 **Interview Preparation**

### **Common Questions**

1. **"How would you design a caching system for 1 million concurrent users?"**
   - Multi-tier caching strategy
   - Redis cluster configuration
   - Cache warming and invalidation
   - Performance monitoring

2. **"What caching pattern would you use for a read-heavy vs write-heavy system?"**
   - Cache-aside for read-heavy
   - Write-through for data consistency
   - Write-behind for write-heavy with eventual consistency

3. **"How do you handle cache consistency in a distributed system?"**
   - Event-driven invalidation
   - TTL-based expiration
   - Versioning strategies
   - Trade-offs between consistency and performance

4. **"How would you monitor and optimize cache performance?"**
   - Key metrics to track
   - Performance tuning strategies
   - Capacity planning
   - Failure scenarios and recovery

### **Best Practices Learned**

1. **Design Principles**
   - Fail-fast with graceful degradation
   - Monitor everything with proper alerting
   - Design for scale from the beginning
   - Consider data consistency requirements

2. **Implementation Guidelines**
   - Use appropriate TTL values
   - Implement proper error handling
   - Monitor cache hit rates and performance
   - Plan for cache warming and invalidation

3. **Production Considerations**
   - Capacity planning and auto-scaling
   - Disaster recovery procedures
   - Security and access control
   - Cost optimization strategies

---

## 🚀 **Next Steps**

1. **Deploy to Production**
   - Set up Redis cluster in production
   - Implement monitoring and alerting
   - Configure auto-scaling policies

2. **Advanced Topics**
   - Multi-region cache synchronization
   - ML-based cache optimization
   - Custom eviction policies
   - Cache analytics and insights

3. **Integration**
   - Integrate with existing microservices
   - Implement in message queues
   - Add to API gateways
   - Database query optimization

**Congratulations!** You've completed the comprehensive caching systems lab. You now have hands-on experience with production-ready caching patterns essential for system design interviews and building scalable distributed systems.
