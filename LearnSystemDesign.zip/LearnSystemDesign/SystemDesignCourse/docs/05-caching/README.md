# Module 5: Caching Strategies for High Performance

## ⚡ Building Ultra-Fast Systems with Strategic Caching

### 📚 Learning Objectives

By the end of this module, you will:
- Design multi-tier caching architectures
- Implement cache eviction policies and strategies
- Handle cache consistency and invalidation
- Choose appropriate caching technologies for different use cases
- Optimize cache performance and hit ratios
- Design distributed caching systems

---

## 🏗️ Caching Architecture Patterns

### 1. Multi-Tier Caching Implementation

```java
// Comprehensive caching service with multiple tiers
@Service
public class MultiTierCacheService {
    
    private final LocalCache localCache;        // L1: In-memory (fastest)
    private final RedisTemplate<String, Object> redisTemplate;  // L2: Distributed
    private final DatabaseService databaseService;              // L3: Persistent storage
    private final CacheMetrics cacheMetrics;
    
    public MultiTierCacheService(LocalCache localCache, 
                               RedisTemplate<String, Object> redisTemplate,
                               DatabaseService databaseService,
                               CacheMetrics cacheMetrics) {
        this.localCache = localCache;
        this.redisTemplate = redisTemplate;
        this.databaseService = databaseService;
        this.cacheMetrics = cacheMetrics;
    }
    
    public <T> Optional<T> get(String key, Class<T> type) {
        Timer.Sample sample = cacheMetrics.startLookupTimer();
        
        try {
            // L1: Check local cache first (sub-millisecond)
            Optional<T> localResult = localCache.get(key, type);
            if (localResult.isPresent()) {
                cacheMetrics.recordHit("L1");
                return localResult;
            }
            
            // L2: Check Redis cache (low milliseconds)
            T redisResult = getFromRedis(key, type);
            if (redisResult != null) {
                // Warm up L1 cache
                localCache.put(key, redisResult, Duration.ofMinutes(5));
                cacheMetrics.recordHit("L2");
                return Optional.of(redisResult);
            }
            
            // L3: Load from database (high milliseconds)
            T dbResult = loadFromDatabase(key, type);
            if (dbResult != null) {
                // Warm up both cache tiers
                localCache.put(key, dbResult, Duration.ofMinutes(5));
                putToRedis(key, dbResult, Duration.ofHours(1));
                cacheMetrics.recordMiss();
                return Optional.of(dbResult);
            }
            
            cacheMetrics.recordMiss();
            return Optional.empty();
            
        } finally {
            sample.stop();
        }
    }
    
    public <T> void put(String key, T value, CachingPolicy policy) {
        // Store based on policy
        switch (policy.getTier()) {
            case ALL_TIERS:
                localCache.put(key, value, policy.getLocalTTL());
                putToRedis(key, value, policy.getDistributedTTL());
                break;
                
            case DISTRIBUTED_ONLY:
                putToRedis(key, value, policy.getDistributedTTL());
                break;
                
            case LOCAL_ONLY:
                localCache.put(key, value, policy.getLocalTTL());
                break;
        }
        
        cacheMetrics.recordWrite(policy.getTier().name());
    }
    
    public void invalidate(String key) {
        // Invalidate all tiers
        localCache.evict(key);
        redisTemplate.delete(key);
        cacheMetrics.recordInvalidation();
    }
    
    public void invalidatePattern(String pattern) {
        // Pattern-based invalidation
        localCache.evictPattern(pattern);
        
        // Redis pattern deletion
        Set<String> keys = redisTemplate.keys(pattern);
        if (!keys.isEmpty()) {
            redisTemplate.delete(keys);
        }
        
        cacheMetrics.recordPatternInvalidation(keys.size());
    }
    
    @SuppressWarnings("unchecked")
    private <T> T getFromRedis(String key, Class<T> type) {
        try {
            Object value = redisTemplate.opsForValue().get(key);
            return type.isInstance(value) ? (T) value : null;
        } catch (Exception e) {
            log.warn("Redis cache access failed for key: {}", key, e);
            cacheMetrics.recordError("redis_read");
            return null;
        }
    }
    
    private <T> void putToRedis(String key, T value, Duration ttl) {
        try {
            redisTemplate.opsForValue().set(key, value, ttl);
        } catch (Exception e) {
            log.warn("Redis cache write failed for key: {}", key, e);
            cacheMetrics.recordError("redis_write");
        }
    }
    
    private <T> T loadFromDatabase(String key, Class<T> type) {
        // Load from appropriate service based on key pattern
        if (key.startsWith("user:")) {
            String userId = key.substring(5);
            return type.cast(databaseService.getUserById(userId));
        } else if (key.startsWith("product:")) {
            String productId = key.substring(8);
            return type.cast(databaseService.getProductById(productId));
        }
        // Add more patterns as needed
        
        return null;
    }
}
```

### 2. Advanced Local Cache Implementation

```java
// High-performance local cache with multiple eviction policies
@Component
public class LocalCache {
    
    private final Cache<String, CacheEntry> lruCache;
    private final Cache<String, CacheEntry> lfoCache;
    private final Cache<String, CacheEntry> timeBasedCache;
    private final CacheStats stats;
    
    public LocalCache(@Value("${cache.local.max-size:10000}") int maxSize) {
        // LRU Cache for general purpose
        this.lruCache = Caffeine.newBuilder()
            .maximumSize(maxSize / 3)
            .expireAfterAccess(Duration.ofMinutes(30))
            .expireAfterWrite(Duration.ofHours(2))
            .recordStats()
            .removalListener(this::onRemoval)
            .build();
        
        // LFO (Least Frequently Used) Cache for hot data
        this.lfoCache = Caffeine.newBuilder()
            .maximumSize(maxSize / 3)
            .expireAfterAccess(Duration.ofHours(1))
            .recordStats()
            .build();
        
        // Time-based cache for time-sensitive data
        this.timeBasedCache = Caffeine.newBuilder()
            .maximumSize(maxSize / 3)
            .expireAfterWrite(Duration.ofMinutes(10))
            .recordStats()
            .build();
        
        this.stats = new CacheStats();
    }
    
    public <T> Optional<T> get(String key, Class<T> type) {
        // Try caches in order of likelihood
        CacheEntry entry = getCacheEntry(key);
        
        if (entry != null && !entry.isExpired() && type.isInstance(entry.getValue())) {
            stats.recordHit();
            updateAccessPattern(key, entry);
            return Optional.of(type.cast(entry.getValue()));
        }
        
        stats.recordMiss();
        return Optional.empty();
    }
    
    public <T> void put(String key, T value, Duration ttl) {
        CacheEntry entry = new CacheEntry(value, Instant.now().plus(ttl), calculatePriority(key, value));
        
        // Choose cache based on access pattern and priority
        if (entry.getPriority() == CachePriority.HIGH) {
            lfoCache.put(key, entry);
        } else if (ttl.compareTo(Duration.ofMinutes(30)) < 0) {
            timeBasedCache.put(key, entry);
        } else {
            lruCache.put(key, entry);
        }
        
        stats.recordWrite();
    }
    
    public void evict(String key) {
        lruCache.invalidate(key);
        lfoCache.invalidate(key);
        timeBasedCache.invalidate(key);
        stats.recordEviction();
    }
    
    public void evictPattern(String pattern) {
        Pattern regex = Pattern.compile(pattern.replace("*", ".*"));
        
        evictFromCacheByPattern(lruCache, regex);
        evictFromCacheByPattern(lfoCache, regex);
        evictFromCacheByPattern(timeBasedCache, regex);
    }
    
    private CacheEntry getCacheEntry(String key) {
        // Check all caches
        CacheEntry entry = lfoCache.getIfPresent(key);
        if (entry != null) return entry;
        
        entry = lruCache.getIfPresent(key);
        if (entry != null) return entry;
        
        return timeBasedCache.getIfPresent(key);
    }
    
    private void updateAccessPattern(String key, CacheEntry entry) {
        // Update access frequency for LFO cache decisions
        entry.incrementAccessCount();
        
        // Promote frequently accessed items to LFO cache
        if (entry.getAccessCount() > 10 && !lfoCache.asMap().containsKey(key)) {
            lfoCache.put(key, entry);
        }
    }
    
    private <T> CachePriority calculatePriority(String key, T value) {
        // Determine cache priority based on key patterns and value characteristics
        if (key.startsWith("user:session:") || key.startsWith("auth:")) {
            return CachePriority.HIGH;
        } else if (key.startsWith("product:hot:") || key.startsWith("trending:")) {
            return CachePriority.HIGH;
        } else if (value instanceof String && ((String) value).length() > 10000) {
            return CachePriority.LOW; // Large objects get lower priority
        }
        
        return CachePriority.MEDIUM;
    }
    
    private void evictFromCacheByPattern(Cache<String, CacheEntry> cache, Pattern pattern) {
        Set<String> keysToEvict = cache.asMap().keySet().stream()
            .filter(key -> pattern.matcher(key).matches())
            .collect(Collectors.toSet());
        
        cache.invalidateAll(keysToEvict);
    }
    
    private void onRemoval(String key, CacheEntry entry, RemovalCause cause) {
        stats.recordRemoval(cause);
        log.debug("Cache entry removed: key={}, cause={}", key, cause);
    }
    
    public CacheStats getStats() {
        return stats.merge(
            lruCache.stats(),
            lfoCache.stats(),
            timeBasedCache.stats()
        );
    }
    
    // Cache entry with metadata
    private static class CacheEntry {
        private final Object value;
        private final Instant expiry;
        private final CachePriority priority;
        private final AtomicLong accessCount = new AtomicLong(0);
        private final Instant createdAt = Instant.now();
        
        public CacheEntry(Object value, Instant expiry, CachePriority priority) {
            this.value = value;
            this.expiry = expiry;
            this.priority = priority;
        }
        
        public Object getValue() { return value; }
        public boolean isExpired() { return Instant.now().isAfter(expiry); }
        public CachePriority getPriority() { return priority; }
        public long getAccessCount() { return accessCount.get(); }
        public void incrementAccessCount() { accessCount.incrementAndGet(); }
        public Instant getCreatedAt() { return createdAt; }
    }
    
    public enum CachePriority {
        LOW, MEDIUM, HIGH
    }
}
```

### 3. Distributed Cache with Redis Cluster

```java
// Redis cluster cache implementation
@Service
public class DistributedCacheService {
    
    private final RedisTemplate<String, Object> redisTemplate;
    private final RedisScript<Boolean> distributedLockScript;
    private final RedisScript<Long> atomicIncrementScript;
    private final CacheMetrics cacheMetrics;
    
    public DistributedCacheService(RedisTemplate<String, Object> redisTemplate,
                                 CacheMetrics cacheMetrics) {
        this.redisTemplate = redisTemplate;
        this.cacheMetrics = cacheMetrics;
        this.distributedLockScript = loadLockScript();
        this.atomicIncrementScript = loadIncrementScript();
    }
    
    public <T> Optional<T> get(String key, Class<T> type) {
        try {
            Timer.Sample sample = cacheMetrics.startDistributedLookupTimer();
            
            Object value = redisTemplate.opsForValue().get(key);
            
            sample.stop();
            
            if (value != null && type.isInstance(value)) {
                cacheMetrics.recordDistributedHit();
                return Optional.of(type.cast(value));
            }
            
            cacheMetrics.recordDistributedMiss();
            return Optional.empty();
            
        } catch (Exception e) {
            cacheMetrics.recordDistributedError();
            log.warn("Distributed cache get failed for key: {}", key, e);
            return Optional.empty();
        }
    }
    
    public <T> void put(String key, T value, Duration ttl) {
        try {
            redisTemplate.opsForValue().set(key, value, ttl);
            cacheMetrics.recordDistributedWrite();
        } catch (Exception e) {
            cacheMetrics.recordDistributedError();
            log.warn("Distributed cache put failed for key: {}", key, e);
        }
    }
    
    public <T> void putIfAbsent(String key, T value, Duration ttl) {
        try {
            Boolean wasSet = redisTemplate.opsForValue().setIfAbsent(key, value, ttl);
            if (Boolean.TRUE.equals(wasSet)) {
                cacheMetrics.recordDistributedWrite();
            }
        } catch (Exception e) {
            cacheMetrics.recordDistributedError();
            log.warn("Distributed cache putIfAbsent failed for key: {}", key, e);
        }
    }
    
    // Distributed locking for cache warming and consistency
    public boolean acquireDistributedLock(String lockKey, Duration expiry, String requestId) {
        try {
            Boolean acquired = redisTemplate.execute(distributedLockScript,
                Collections.singletonList(lockKey),
                requestId,
                String.valueOf(expiry.toMillis()));
            
            if (Boolean.TRUE.equals(acquired)) {
                cacheMetrics.recordLockAcquired();
                return true;
            }
            
            cacheMetrics.recordLockFailed();
            return false;
            
        } catch (Exception e) {
            cacheMetrics.recordDistributedError();
            log.warn("Distributed lock acquisition failed for key: {}", lockKey, e);
            return false;
        }
    }
    
    public boolean releaseDistributedLock(String lockKey, String requestId) {
        try {
            String script = """
                if redis.call('get', KEYS[1]) == ARGV[1] then
                    return redis.call('del', KEYS[1])
                else
                    return 0
                end
                """;
            
            Long result = redisTemplate.execute(RedisScript.of(script, Long.class),
                Collections.singletonList(lockKey), requestId);
            
            boolean released = result != null && result == 1;
            if (released) {
                cacheMetrics.recordLockReleased();
            }
            
            return released;
            
        } catch (Exception e) {
            cacheMetrics.recordDistributedError();
            log.warn("Distributed lock release failed for key: {}", lockKey, e);
            return false;
        }
    }
    
    // Atomic operations for cache consistency
    public long atomicIncrement(String key, long delta, Duration expiry) {
        try {
            Long result = redisTemplate.execute(atomicIncrementScript,
                Collections.singletonList(key),
                String.valueOf(delta),
                String.valueOf(expiry.getSeconds()));
            
            cacheMetrics.recordAtomicOperation();
            return result != null ? result : 0;
            
        } catch (Exception e) {
            cacheMetrics.recordDistributedError();
            log.warn("Atomic increment failed for key: {}", key, e);
            return 0;
        }
    }
    
    // Bulk operations for efficiency
    public Map<String, Object> multiGet(List<String> keys) {
        try {
            List<Object> values = redisTemplate.opsForValue().multiGet(keys);
            Map<String, Object> result = new HashMap<>();
            
            for (int i = 0; i < keys.size(); i++) {
                if (values.get(i) != null) {
                    result.put(keys.get(i), values.get(i));
                }
            }
            
            cacheMetrics.recordBulkOperation("multiGet", keys.size());
            return result;
            
        } catch (Exception e) {
            cacheMetrics.recordDistributedError();
            log.warn("Multi-get failed for keys: {}", keys, e);
            return Collections.emptyMap();
        }
    }
    
    public void multiSet(Map<String, Object> keyValues, Duration ttl) {
        try {
            redisTemplate.executePipelined((RedisCallback<Object>) connection -> {
                keyValues.forEach((key, value) -> {
                    redisTemplate.opsForValue().set(key, value, ttl);
                });
                return null;
            });
            
            cacheMetrics.recordBulkOperation("multiSet", keyValues.size());
            
        } catch (Exception e) {
            cacheMetrics.recordDistributedError();
            log.warn("Multi-set failed for {} keys", keyValues.size(), e);
        }
    }
    
    // Cache warming strategies
    public void warmUpCache(String pattern, CacheWarmupStrategy strategy) {
        String lockKey = "warmup:lock:" + pattern;
        String requestId = UUID.randomUUID().toString();
        
        if (acquireDistributedLock(lockKey, Duration.ofMinutes(10), requestId)) {
            try {
                switch (strategy) {
                    case POPULAR_ITEMS:
                        warmUpPopularItems(pattern);
                        break;
                    case RECENT_ITEMS:
                        warmUpRecentItems(pattern);
                        break;
                    case PREDICTIVE:
                        warmUpPredictiveItems(pattern);
                        break;
                }
                
                cacheMetrics.recordWarmupCompleted(strategy);
                
            } finally {
                releaseDistributedLock(lockKey, requestId);
            }
        }
    }
    
    private void warmUpPopularItems(String pattern) {
        // Load most frequently accessed items based on analytics
        List<String> popularKeys = analyticsService.getPopularKeys(pattern, 1000);
        
        for (String key : popularKeys) {
            if (!redisTemplate.hasKey(key)) {
                Object value = loadFromDataSource(key);
                if (value != null) {
                    put(key, value, Duration.ofHours(2));
                }
            }
        }
    }
    
    private void warmUpRecentItems(String pattern) {
        // Load recently accessed items
        List<String> recentKeys = analyticsService.getRecentKeys(pattern, 500);
        
        for (String key : recentKeys) {
            if (!redisTemplate.hasKey(key)) {
                Object value = loadFromDataSource(key);
                if (value != null) {
                    put(key, value, Duration.ofMinutes(30));
                }
            }
        }
    }
    
    private void warmUpPredictiveItems(String pattern) {
        // Use ML model to predict likely-to-be-accessed items
        List<String> predictedKeys = mlPredictionService.predictPopularKeys(pattern, 200);
        
        for (String key : predictedKeys) {
            if (!redisTemplate.hasKey(key)) {
                Object value = loadFromDataSource(key);
                if (value != null) {
                    put(key, value, Duration.ofMinutes(15));
                }
            }
        }
    }
    
    private Object loadFromDataSource(String key) {
        // Load data from the appropriate data source
        return dataSourceService.loadByKey(key);
    }
    
    private RedisScript<Boolean> loadLockScript() {
        String script = """
            if redis.call('set', KEYS[1], ARGV[1], 'PX', ARGV[2], 'NX') then
                return true
            else
                return false
            end
            """;
        return RedisScript.of(script, Boolean.class);
    }
    
    private RedisScript<Long> loadIncrementScript() {
        String script = """
            local current = redis.call('incrby', KEYS[1], ARGV[1])
            redis.call('expire', KEYS[1], ARGV[2])
            return current
            """;
        return RedisScript.of(script, Long.class);
    }
    
    public enum CacheWarmupStrategy {
        POPULAR_ITEMS, RECENT_ITEMS, PREDICTIVE
    }
}
```

---

## 🔄 Cache Patterns and Strategies

### 1. Cache-Aside Pattern

```java
// Cache-aside (lazy loading) implementation
@Service
public class CacheAsideService {
    
    @Autowired
    private MultiTierCacheService cacheService;
    
    @Autowired
    private UserRepository userRepository;
    
    public User getUser(String userId) {
        String cacheKey = "user:" + userId;
        
        // Try to get from cache first
        Optional<User> cachedUser = cacheService.get(cacheKey, User.class);
        if (cachedUser.isPresent()) {
            return cachedUser.get();
        }
        
        // Load from database
        User user = userRepository.findById(userId)
            .orElseThrow(() -> new UserNotFoundException(userId));
        
        // Store in cache for future requests
        CachingPolicy policy = CachingPolicy.builder()
            .tier(CacheTier.ALL_TIERS)
            .localTTL(Duration.ofMinutes(5))
            .distributedTTL(Duration.ofHours(1))
            .build();
        
        cacheService.put(cacheKey, user, policy);
        
        return user;
    }
    
    public User updateUser(String userId, UserUpdateRequest request) {
        // Update in database
        User updatedUser = userRepository.update(userId, request);
        
        // Invalidate cache to maintain consistency
        String cacheKey = "user:" + userId;
        cacheService.invalidate(cacheKey);
        
        // Optionally, warm up cache with new data
        CachingPolicy policy = CachingPolicy.builder()
            .tier(CacheTier.ALL_TIERS)
            .localTTL(Duration.ofMinutes(5))
            .distributedTTL(Duration.ofHours(1))
            .build();
        
        cacheService.put(cacheKey, updatedUser, policy);
        
        return updatedUser;
    }
}
```

### 2. Write-Through Cache Pattern

```java
// Write-through cache implementation
@Service
public class WriteThroughCacheService {
    
    @Autowired
    private MultiTierCacheService cacheService;
    
    @Autowired
    private ProductRepository productRepository;
    
    public Product createProduct(CreateProductRequest request) {
        // Create in database first
        Product product = productRepository.save(Product.from(request));
        
        // Immediately store in cache
        String cacheKey = "product:" + product.getId();
        CachingPolicy policy = CachingPolicy.builder()
            .tier(CacheTier.ALL_TIERS)
            .localTTL(Duration.ofMinutes(10))
            .distributedTTL(Duration.ofHours(2))
            .build();
        
        cacheService.put(cacheKey, product, policy);
        
        return product;
    }
    
    public Product updateProduct(String productId, UpdateProductRequest request) {
        // Update in database
        Product updatedProduct = productRepository.update(productId, request);
        
        // Update cache immediately
        String cacheKey = "product:" + productId;
        CachingPolicy policy = CachingPolicy.builder()
            .tier(CacheTier.ALL_TIERS)
            .localTTL(Duration.ofMinutes(10))
            .distributedTTL(Duration.ofHours(2))
            .build();
        
        cacheService.put(cacheKey, updatedProduct, policy);
        
        // Invalidate related caches
        cacheService.invalidatePattern("product:category:" + updatedProduct.getCategoryId() + ":*");
        cacheService.invalidatePattern("search:products:*");
        
        return updatedProduct;
    }
}
```

### 3. Write-Behind (Write-Back) Cache Pattern

```java
// Write-behind cache with batching
@Service
public class WriteBehindCacheService {
    
    @Autowired
    private MultiTierCacheService cacheService;
    
    @Autowired
    private AnalyticsRepository analyticsRepository;
    
    private final BlockingQueue<AnalyticsEvent> writeQueue = new LinkedBlockingQueue<>();
    private final ScheduledExecutorService batchProcessor = Executors.newScheduledThreadPool(2);
    
    @PostConstruct
    public void startBatchProcessor() {
        // Process write queue every 5 seconds
        batchProcessor.scheduleAtFixedRate(this::processBatch, 5, 5, TimeUnit.SECONDS);
        
        // Process write queue when it reaches batch size
        batchProcessor.scheduleAtFixedRate(this::processIfBatchSizeReached, 1, 1, TimeUnit.SECONDS);
    }
    
    public void recordAnalyticsEvent(AnalyticsEvent event) {
        // Store in cache immediately
        String cacheKey = STR."analytics:\{event.getUserId()}:\{event.getEventType()}:\{event.getTimestamp()}";
        
        CachingPolicy policy = CachingPolicy.builder()
            .tier(CacheTier.DISTRIBUTED_ONLY) // Don't use local cache for analytics
            .distributedTTL(Duration.ofHours(6))
            .build();
        
        cacheService.put(cacheKey, event, policy);
        
        // Queue for eventual database write
        try {
            writeQueue.offer(event, 1, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            log.warn("Failed to queue analytics event for database write", e);
        }
    }
    
    private void processBatch() {
        List<AnalyticsEvent> batch = new ArrayList<>();
        
        // Drain up to 1000 events
        writeQueue.drainTo(batch, 1000);
        
        if (!batch.isEmpty()) {
            try {
                // Batch write to database
                analyticsRepository.saveAll(batch);
                log.debug("Processed batch of {} analytics events", batch.size());
                
                // Remove from cache after successful database write
                batch.forEach(event -> {
                    String cacheKey = STR."analytics:\{event.getUserId()}:\{event.getEventType()}:\{event.getTimestamp()}";
                    cacheService.invalidate(cacheKey);
                });
                
            } catch (Exception e) {
                log.error("Failed to process analytics batch", e);
                
                // Re-queue failed events
                writeQueue.addAll(batch);
            }
        }
    }
    
    private void processIfBatchSizeReached() {
        if (writeQueue.size() >= 1000) {
            processBatch();
        }
    }
    
    @PreDestroy
    public void shutdown() {
        batchProcessor.shutdown();
        
        // Process remaining events
        if (!writeQueue.isEmpty()) {
            processBatch();
        }
    }
}
```

---

## 🎯 Cache Consistency and Invalidation

### 1. Event-Driven Cache Invalidation

```java
// Event-driven cache invalidation system
@Component
public class CacheInvalidationService {
    
    @Autowired
    private MultiTierCacheService cacheService;
    
    @Autowired
    private DistributedCacheService distributedCacheService;
    
    @EventListener
    @Async
    public void handleUserUpdated(UserUpdatedEvent event) {
        String userId = event.getUserId();
        
        // Invalidate user-specific caches
        cacheService.invalidate("user:" + userId);
        cacheService.invalidate("user:profile:" + userId);
        cacheService.invalidate("user:preferences:" + userId);
        
        // Invalidate related caches
        cacheService.invalidatePattern("user:friends:" + userId + ":*");
        cacheService.invalidatePattern("notifications:user:" + userId + ":*");
        
        log.debug("Invalidated caches for user: {}", userId);
    }
    
    @EventListener
    @Async
    public void handleProductUpdated(ProductUpdatedEvent event) {
        String productId = event.getProductId();
        String categoryId = event.getCategoryId();
        
        // Invalidate product-specific caches
        cacheService.invalidate("product:" + productId);
        cacheService.invalidate("product:details:" + productId);
        
        // Invalidate category caches
        cacheService.invalidatePattern("category:" + categoryId + ":*");
        cacheService.invalidatePattern("search:category:" + categoryId + ":*");
        
        // Invalidate search result caches
        cacheService.invalidatePattern("search:products:*");
        
        log.debug("Invalidated caches for product: {}", productId);
    }
    
    @EventListener
    @Async
    public void handleInventoryChanged(InventoryChangedEvent event) {
        String productId = event.getProductId();
        
        // Invalidate availability caches
        cacheService.invalidate("inventory:" + productId);
        cacheService.invalidate("product:availability:" + productId);
        
        // If out of stock, invalidate search caches that might include this product
        if (event.getNewQuantity() == 0) {
            cacheService.invalidatePattern("search:*");
            cacheService.invalidatePattern("recommendations:*");
        }
        
        log.debug("Invalidated inventory caches for product: {}", productId);
    }
    
    // Distributed cache invalidation across multiple service instances
    @EventListener
    @Async
    public void handleDistributedCacheInvalidation(DistributedCacheInvalidationEvent event) {
        switch (event.getInvalidationType()) {
            case SINGLE_KEY:
                cacheService.invalidate(event.getKey());
                break;
                
            case PATTERN:
                cacheService.invalidatePattern(event.getPattern());
                break;
                
            case TAGGED:
                invalidateByTags(event.getTags());
                break;
                
            case FULL_FLUSH:
                invalidateAll();
                break;
        }
        
        log.debug("Processed distributed cache invalidation: {}", event.getInvalidationType());
    }
    
    private void invalidateByTags(Set<String> tags) {
        // Invalidate all cache entries that match any of the provided tags
        for (String tag : tags) {
            cacheService.invalidatePattern("*:tag:" + tag + ":*");
        }
    }
    
    private void invalidateAll() {
        // Full cache flush - use sparingly
        log.warn("Performing full cache invalidation");
        
        try {
            // Clear local caches
            cacheService.invalidatePattern("*");
            
            // Clear distributed cache
            distributedCacheService.flushAll();
            
        } catch (Exception e) {
            log.error("Failed to perform full cache invalidation", e);
        }
    }
}
```

### 2. Cache Coherence with Versioning

```java
// Versioned cache entries for consistency
@Service
public class VersionedCacheService {
    
    @Autowired
    private DistributedCacheService distributedCacheService;
    
    @Autowired
    private VersionService versionService;
    
    public <T> Optional<T> getVersionedEntry(String key, Class<T> type) {
        Optional<VersionedCacheEntry> cachedEntry = distributedCacheService.get(key, VersionedCacheEntry.class);
        
        if (cachedEntry.isPresent()) {
            VersionedCacheEntry entry = cachedEntry.get();
            
            // Check if the cached version is still current
            long currentVersion = versionService.getCurrentVersion(key);
            
            if (entry.getVersion() == currentVersion) {
                return Optional.of(type.cast(entry.getData()));
            } else {
                // Version mismatch, invalidate cache
                distributedCacheService.invalidate(key);
            }
        }
        
        return Optional.empty();
    }
    
    public <T> void putVersionedEntry(String key, T data, Duration ttl) {
        long currentVersion = versionService.getCurrentVersion(key);
        
        VersionedCacheEntry entry = new VersionedCacheEntry(
            data, 
            currentVersion, 
            Instant.now()
        );
        
        distributedCacheService.put(key, entry, ttl);
    }
    
    public void incrementVersion(String key) {
        versionService.incrementVersion(key);
        
        // Invalidate cache to force reload with new version
        distributedCacheService.invalidate(key);
    }
    
    private static class VersionedCacheEntry {
        private final Object data;
        private final long version;
        private final Instant timestamp;
        
        public VersionedCacheEntry(Object data, long version, Instant timestamp) {
            this.data = data;
            this.version = version;
            this.timestamp = timestamp;
        }
        
        public Object getData() { return data; }
        public long getVersion() { return version; }
        public Instant getTimestamp() { return timestamp; }
    }
}
```

---

## 📊 Cache Performance Monitoring

### 1. Comprehensive Cache Metrics

```java
@Component
public class CacheMetrics {
    
    private final Counter hitCounter;
    private final Counter missCounter;
    private final Counter writeCounter;
    private final Counter evictionCounter;
    private final Timer lookupTimer;
    private final Timer writeTimer;
    private final Gauge hitRatio;
    private final DistributionSummary entrySizeDistribution;
    
    public CacheMetrics(MeterRegistry meterRegistry) {
        this.hitCounter = Counter.builder("cache.hits")
            .description("Cache hits")
            .register(meterRegistry);
            
        this.missCounter = Counter.builder("cache.misses")
            .description("Cache misses")
            .register(meterRegistry);
            
        this.writeCounter = Counter.builder("cache.writes")
            .description("Cache writes")
            .register(meterRegistry);
            
        this.evictionCounter = Counter.builder("cache.evictions")
            .description("Cache evictions")
            .register(meterRegistry);
            
        this.lookupTimer = Timer.builder("cache.lookup.duration")
            .description("Cache lookup duration")
            .register(meterRegistry);
            
        this.writeTimer = Timer.builder("cache.write.duration")
            .description("Cache write duration")
            .register(meterRegistry);
            
        this.hitRatio = Gauge.builder("cache.hit.ratio")
            .description("Cache hit ratio")
            .register(meterRegistry, this, CacheMetrics::calculateHitRatio);
            
        this.entrySizeDistribution = DistributionSummary.builder("cache.entry.size")
            .description("Cache entry size distribution")
            .register(meterRegistry);
    }
    
    public void recordHit(String tier) {
        hitCounter.increment(Tags.of("tier", tier));
    }
    
    public void recordMiss() {
        missCounter.increment();
    }
    
    public void recordWrite(String tier) {
        writeCounter.increment(Tags.of("tier", tier));
    }
    
    public void recordEviction(String reason) {
        evictionCounter.increment(Tags.of("reason", reason));
    }
    
    public Timer.Sample startLookupTimer() {
        return Timer.start();
    }
    
    public Timer.Sample startWriteTimer() {
        return Timer.start();
    }
    
    public void recordEntrySize(long sizeBytes) {
        entrySizeDistribution.record(sizeBytes);
    }
    
    private double calculateHitRatio() {
        double hits = hitCounter.count();
        double misses = missCounter.count();
        double total = hits + misses;
        
        return total > 0 ? hits / total : 0.0;
    }
    
    // Additional metrics for monitoring cache health
    public void recordCacheWarmupTime(Duration duration) {
        Timer.builder("cache.warmup.duration")
            .description("Cache warmup duration")
            .register(Metrics.globalRegistry)
            .record(duration);
    }
    
    public void recordMemoryPressure(double percentage) {
        Gauge.builder("cache.memory.pressure")
            .description("Cache memory pressure percentage")
            .register(Metrics.globalRegistry, percentage, p -> p);
    }
    
    public void recordNetworkLatency(String operation, Duration latency) {
        Timer.builder("cache.network.latency")
            .tag("operation", operation)
            .description("Cache network operation latency")
            .register(Metrics.globalRegistry)
            .record(latency);
    }
}
```

---

## 🎯 Interview Focus Areas

### Key Caching Questions

**Q: When would you use different cache eviction policies?**
- **LRU**: General purpose, good for temporal locality
- **LFU**: For hot data that's accessed frequently
- **TTL**: Time-sensitive data with natural expiration
- **Random**: Simple, works well for uniform access patterns

**Q: How do you handle cache consistency in a distributed system?**
- **Event-driven invalidation** for real-time consistency
- **Versioning** to detect stale data
- **Write-through/write-behind** patterns
- **Cache-aside** with proper invalidation

**Q: How do you determine cache size and TTL values?**
- **Monitor access patterns** and hit ratios
- **Measure data freshness requirements**
- **Consider memory constraints** and costs
- **Use gradual rollout** for optimization

**Q: How do you handle cache failures?**
- **Circuit breaker** patterns for cache services
- **Graceful degradation** to data sources
- **Monitoring and alerting** for cache health
- **Multiple cache tiers** for redundancy

---

## 🚀 Next Steps

1. **Complete the hands-on exercises** in the exercises folder
2. **Implement cache monitoring** for your applications
3. **Practice cache sizing** and performance tuning
4. **Design cache invalidation** strategies
5. **Move to Module 6: Messaging Systems**

The caching module provides the foundation for building high-performance systems that can handle massive scale with sub-millisecond response times.
