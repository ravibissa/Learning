// Production-ready Redis caching implementation
package com.systemdesign.caching.examples;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.script.DefaultRedisScript;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.CacheEvict;

import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Advanced Redis caching implementation demonstrating
 * multi-tier caching patterns for system design interviews
 */
@Service
public class AdvancedRedisCacheImplementation {
    
    @Autowired
    private RedisTemplate<String, Object> redisTemplate;
    
    @Autowired
    private RedisClusterTemplate<String, Object> clusterTemplate;
    
    @Autowired
    private CacheMetrics cacheMetrics;
    
    /**
     * Multi-tier cache service with local and distributed caching
     */
    @Component
    public static class MultiTierCacheService {
        
        // Local cache (L1)
        private final Map<String, CacheEntry> localCache = new ConcurrentHashMap<>();
        private final int localCacheMaxSize = 10000;
        
        @Autowired
        private RedisTemplate<String, Object> redisTemplate; // Distributed cache (L2)
        
        @Autowired
        private CacheMetrics metrics;
        
        public <T> Optional<T> get(String key, Class<T> type) {
            // L1 Cache check
            CacheEntry localEntry = localCache.get(key);
            if (localEntry != null && !localEntry.isExpired()) {
                metrics.recordCacheHit("L1", key);
                return Optional.of(type.cast(localEntry.getValue()));
            }
            
            // L2 Cache check (Redis)
            try {
                Object redisValue = redisTemplate.opsForValue().get(key);
                if (redisValue != null) {
                    metrics.recordCacheHit("L2", key);
                    
                    // Populate L1 cache
                    putLocal(key, redisValue, Duration.ofMinutes(5));
                    
                    return Optional.of(type.cast(redisValue));
                }
            } catch (Exception e) {
                log.warn("Redis cache error for key: {}", key, e);
                metrics.recordCacheError("L2", key, e);
            }
            
            metrics.recordCacheMiss(key);
            return Optional.empty();
        }
        
        public void put(String key, Object value, Duration ttl) {
            // Store in both L1 and L2
            putLocal(key, value, ttl);
            putDistributed(key, value, ttl);
        }
        
        private void putLocal(String key, Object value, Duration ttl) {
            // Implement LRU eviction if cache is full
            if (localCache.size() >= localCacheMaxSize) {
                evictLRUFromLocal();
            }
            
            CacheEntry entry = CacheEntry.builder()
                .value(value)
                .createdAt(Instant.now())
                .expiresAt(Instant.now().plus(ttl))
                .accessCount(1)
                .lastAccessTime(Instant.now())
                .build();
            
            localCache.put(key, entry);
        }
        
        private void putDistributed(String key, Object value, Duration ttl) {
            try {
                redisTemplate.opsForValue().set(key, value, ttl);
                metrics.recordCachePut("L2", key);
            } catch (Exception e) {
                log.error("Failed to store in Redis cache: {}", key, e);
                metrics.recordCacheError("L2", key, e);
            }
        }
        
        public void evict(String key) {
            localCache.remove(key);
            
            try {
                redisTemplate.delete(key);
                metrics.recordCacheEviction(key);
            } catch (Exception e) {
                log.error("Failed to evict from Redis cache: {}", key, e);
            }
        }
        
        public void evictPattern(String pattern) {
            // Evict from local cache
            localCache.keySet().removeIf(key -> key.matches(pattern.replace("*", ".*")));
            
            // Evict from Redis using Lua script
            try {
                String luaScript = """
                    local keys = redis.call('KEYS', ARGV[1])
                    local count = 0
                    for i=1,#keys do
                        redis.call('DEL', keys[i])
                        count = count + 1
                    end
                    return count
                    """;
                
                DefaultRedisScript<Long> script = new DefaultRedisScript<>(luaScript, Long.class);
                Long deletedCount = redisTemplate.execute(script, Collections.emptyList(), pattern);
                
                log.info("Evicted {} keys matching pattern: {}", deletedCount, pattern);
                
            } catch (Exception e) {
                log.error("Failed to evict pattern from Redis: {}", pattern, e);
            }
        }
        
        private void evictLRUFromLocal() {
            String lruKey = localCache.entrySet().stream()
                .min(Comparator.comparing(entry -> entry.getValue().getLastAccessTime()))
                .map(Map.Entry::getKey)
                .orElse(null);
            
            if (lruKey != null) {
                localCache.remove(lruKey);
                metrics.recordLocalCacheEviction(lruKey);
            }
        }
        
        @Scheduled(fixedRate = 60000) // Every minute
        public void cleanupExpiredEntries() {
            Instant now = Instant.now();
            
            localCache.entrySet().removeIf(entry -> 
                entry.getValue().getExpiresAt().isBefore(now));
        }
    }
    
    /**
     * Cache-aside pattern implementation
     */
    @Service
    public static class CacheAsideService {
        
        @Autowired
        private UserRepository userRepository;
        
        @Autowired
        private MultiTierCacheService cacheService;
        
        public Optional<User> getUser(String userId) {
            String cacheKey = STR."user:\{userId}";
            
            // Try cache first
            Optional<User> cachedUser = cacheService.get(cacheKey, User.class);
            if (cachedUser.isPresent()) {
                return cachedUser;
            }
            
            // Cache miss - fetch from database
            Optional<User> user = userRepository.findById(userId);
            
            if (user.isPresent()) {
                // Store in cache for future requests
                cacheService.put(cacheKey, user.get(), Duration.ofHours(1));
            }
            
            return user;
        }
        
        public User updateUser(String userId, UserUpdateRequest request) {
            // Update database
            User updatedUser = userRepository.updateUser(userId, request);
            
            // Update cache
            String cacheKey = STR."user:\{userId}";
            cacheService.put(cacheKey, updatedUser, Duration.ofHours(1));
            
            // Invalidate related caches
            cacheService.evictPattern(STR."user_list:*");
            cacheService.evictPattern(STR."user_search:*");
            
            return updatedUser;
        }
        
        public void deleteUser(String userId) {
            // Delete from database
            userRepository.deleteById(userId);
            
            // Remove from cache
            String cacheKey = STR."user:\{userId}";
            cacheService.evict(cacheKey);
            
            // Invalidate related caches
            cacheService.evictPattern(STR."user_list:*");
        }
    }
    
    /**
     * Write-through cache implementation
     */
    @Service
    public static class WriteThroughCacheService {
        
        @Autowired
        private ProductRepository productRepository;
        
        @Autowired
        private RedisTemplate<String, Object> redisTemplate;
        
        public Product createProduct(CreateProductRequest request) {
            // Create in database
            Product product = productRepository.save(Product.from(request));
            
            // Immediately cache the new product
            String cacheKey = STR."product:\{product.getId()}";
            redisTemplate.opsForValue().set(cacheKey, product, Duration.ofHours(2));
            
            return product;
        }
        
        public Product updateProduct(String productId, UpdateProductRequest request) {
            // Update database and cache atomically
            Product updatedProduct = productRepository.updateProduct(productId, request);
            
            // Update cache
            String cacheKey = STR."product:\{productId}";
            redisTemplate.opsForValue().set(cacheKey, updatedProduct, Duration.ofHours(2));
            
            return updatedProduct;
        }
        
        @Cacheable(value = "products", key = "#productId")
        public Optional<Product> getProduct(String productId) {
            return productRepository.findById(productId);
        }
    }
    
    /**
     * Write-behind (Write-back) cache implementation
     */
    @Service
    public static class WriteBehindCacheService {
        
        @Autowired
        private RedisTemplate<String, Object> redisTemplate;
        
        @Autowired
        private AnalyticsRepository analyticsRepository;
        
        // Buffer for pending writes
        private final Map<String, PendingWrite> writeBuffer = new ConcurrentHashMap<>();
        private final int batchSize = 100;
        
        public void recordUserActivity(String userId, ActivityEvent event) {
            // Immediately store in cache
            String cacheKey = STR."user_activity:\{userId}";
            redisTemplate.opsForList().leftPush(cacheKey, event);
            redisTemplate.expire(cacheKey, Duration.ofHours(24));
            
            // Buffer for batch database write
            PendingWrite pendingWrite = PendingWrite.builder()
                .userId(userId)
                .event(event)
                .timestamp(Instant.now())
                .build();
            
            writeBuffer.put(UUID.randomUUID().toString(), pendingWrite);
            
            // Trigger batch write if buffer is full
            if (writeBuffer.size() >= batchSize) {
                flushWriteBuffer();
            }
        }
        
        @Scheduled(fixedRate = 30000) // Every 30 seconds
        public void flushWriteBuffer() {
            if (writeBuffer.isEmpty()) return;
            
            List<PendingWrite> writes = new ArrayList<>(writeBuffer.values());
            writeBuffer.clear();
            
            CompletableFuture.runAsync(() -> {
                try {
                    // Batch insert to database
                    analyticsRepository.batchInsertActivities(writes);
                    log.info("Flushed {} pending writes to database", writes.size());
                    
                } catch (Exception e) {
                    log.error("Failed to flush write buffer", e);
                    
                    // Re-add failed writes to buffer for retry
                    writes.forEach(write -> 
                        writeBuffer.put(UUID.randomUUID().toString(), write));
                }
            });
        }
        
        public List<ActivityEvent> getUserRecentActivity(String userId) {
            String cacheKey = STR."user_activity:\{userId}";
            
            try {
                List<Object> activities = redisTemplate.opsForList().range(cacheKey, 0, 99);
                
                if (activities != null && !activities.isEmpty()) {
                    return activities.stream()
                        .map(obj -> (ActivityEvent) obj)
                        .toList();
                }
            } catch (Exception e) {
                log.warn("Failed to get activities from cache: {}", userId, e);
            }
            
            // Fallback to database
            return analyticsRepository.getUserRecentActivity(userId, 100);
        }
    }
    
    /**
     * Distributed cache with Redis Cluster
     */
    @Service
    public static class DistributedCacheService {
        
        @Autowired
        private RedisClusterTemplate<String, Object> clusterTemplate;
        
        @Autowired
        private ConsistentHashRing hashRing;
        
        public void putWithSharding(String key, Object value, Duration ttl) {
            // Use consistent hashing to determine shard
            String shardKey = hashRing.getNode(key);
            String fullKey = STR."\{shardKey}:\{key}";
            
            try {
                clusterTemplate.opsForValue().set(fullKey, value, ttl);
                
            } catch (Exception e) {
                log.error("Failed to store in distributed cache: {}", fullKey, e);
                throw new CacheException("Distributed cache write failed", e);
            }
        }
        
        public <T> Optional<T> getWithSharding(String key, Class<T> type) {
            String shardKey = hashRing.getNode(key);
            String fullKey = STR."\{shardKey}:\{key}";
            
            try {
                Object value = clusterTemplate.opsForValue().get(fullKey);
                
                if (value != null) {
                    return Optional.of(type.cast(value));
                }
                
            } catch (Exception e) {
                log.warn("Failed to read from distributed cache: {}", fullKey, e);
            }
            
            return Optional.empty();
        }
        
        public void distributedLock(String lockKey, Duration lockTime, Runnable operation) {
            String lockValue = UUID.randomUUID().toString();
            String redisKey = STR."lock:\{lockKey}";
            
            // Acquire distributed lock
            Boolean acquired = clusterTemplate.opsForValue().setIfAbsent(
                redisKey, lockValue, lockTime);
            
            if (Boolean.TRUE.equals(acquired)) {
                try {
                    operation.run();
                } finally {
                    // Release lock using Lua script for atomicity
                    releaseLock(redisKey, lockValue);
                }
            } else {
                throw new LockAcquisitionException(STR."Failed to acquire lock: \{lockKey}");
            }
        }
        
        private void releaseLock(String lockKey, String lockValue) {
            String luaScript = """
                if redis.call('GET', KEYS[1]) == ARGV[1] then
                    return redis.call('DEL', KEYS[1])
                else
                    return 0
                end
                """;
            
            DefaultRedisScript<Long> script = new DefaultRedisScript<>(luaScript, Long.class);
            clusterTemplate.execute(script, List.of(lockKey), lockValue);
        }
    }
    
    /**
     * Cache warming service
     */
    @Service
    public static class CacheWarmingService {
        
        @Autowired
        private MultiTierCacheService cacheService;
        
        @Autowired
        private UserRepository userRepository;
        
        @Autowired
        private ProductRepository productRepository;
        
        @EventListener
        public void warmCacheOnStartup(ApplicationReadyEvent event) {
            log.info("Starting cache warming process");
            
            CompletableFuture.allOf(
                CompletableFuture.runAsync(this::warmUserCache),
                CompletableFuture.runAsync(this::warmProductCache),
                CompletableFuture.runAsync(this::warmConfigCache)
            ).thenRun(() -> {
                log.info("Cache warming completed successfully");
            }).exceptionally(throwable -> {
                log.error("Cache warming failed", throwable);
                return null;
            });
        }
        
        private void warmUserCache() {
            try {
                // Warm cache with recently active users
                List<User> activeUsers = userRepository.findRecentlyActiveUsers(1000);
                
                for (User user : activeUsers) {
                    String cacheKey = STR."user:\{user.getId()}";
                    cacheService.put(cacheKey, user, Duration.ofHours(1));
                }
                
                log.info("Warmed user cache with {} entries", activeUsers.size());
                
            } catch (Exception e) {
                log.error("Failed to warm user cache", e);
            }
        }
        
        private void warmProductCache() {
            try {
                // Warm cache with popular products
                List<Product> popularProducts = productRepository.findPopularProducts(500);
                
                for (Product product : popularProducts) {
                    String cacheKey = STR."product:\{product.getId()}";
                    cacheService.put(cacheKey, product, Duration.ofHours(2));
                }
                
                log.info("Warmed product cache with {} entries", popularProducts.size());
                
            } catch (Exception e) {
                log.error("Failed to warm product cache", e);
            }
        }
        
        private void warmConfigCache() {
            try {
                // Warm cache with application configuration
                Map<String, Object> configs = configService.getAllConfigurations();
                
                for (Map.Entry<String, Object> entry : configs.entrySet()) {
                    String cacheKey = STR."config:\{entry.getKey()}";
                    cacheService.put(cacheKey, entry.getValue(), Duration.ofHours(12));
                }
                
                log.info("Warmed config cache with {} entries", configs.size());
                
            } catch (Exception e) {
                log.error("Failed to warm config cache", e);
            }
        }
    }
    
    // Supporting classes and data structures
    
    @Data
    @Builder
    public static class CacheEntry {
        private Object value;
        private Instant createdAt;
        private Instant expiresAt;
        private Instant lastAccessTime;
        private long accessCount;
        
        public boolean isExpired() {
            return Instant.now().isAfter(expiresAt);
        }
        
        public void recordAccess() {
            this.lastAccessTime = Instant.now();
            this.accessCount++;
        }
    }
    
    @Data
    @Builder
    public static class PendingWrite {
        private String userId;
        private ActivityEvent event;
        private Instant timestamp;
    }
    
    /**
     * Consistent hashing for cache sharding
     */
    @Component
    public static class ConsistentHashRing {
        
        private final TreeMap<Long, String> ring = new TreeMap<>();
        private final int virtualNodes = 150;
        
        @PostConstruct
        public void initialize() {
            // Initialize with Redis cluster nodes
            List<String> nodes = List.of("redis-1", "redis-2", "redis-3");
            
            for (String node : nodes) {
                addNode(node);
            }
        }
        
        public void addNode(String node) {
            for (int i = 0; i < virtualNodes; i++) {
                long hash = hash(STR."\{node}:\{i}");
                ring.put(hash, node);
            }
        }
        
        public void removeNode(String node) {
            for (int i = 0; i < virtualNodes; i++) {
                long hash = hash(STR."\{node}:\{i}");
                ring.remove(hash);
            }
        }
        
        public String getNode(String key) {
            if (ring.isEmpty()) {
                return null;
            }
            
            long hash = hash(key);
            Map.Entry<Long, String> entry = ring.ceilingEntry(hash);
            
            if (entry == null) {
                entry = ring.firstEntry();
            }
            
            return entry.getValue();
        }
        
        private long hash(String input) {
            // Use FNV-1a hash for better distribution
            long hash = 2166136261L;
            for (byte b : input.getBytes()) {
                hash ^= b;
                hash *= 16777619L;
            }
            return Math.abs(hash);
        }
    }
    
    /**
     * Cache metrics and monitoring
     */
    @Component
    public static class CacheMetrics {
        
        @Autowired
        private MeterRegistry meterRegistry;
        
        private final Counter cacheHits;
        private final Counter cacheMisses;
        private final Counter cacheErrors;
        private final Timer cacheOperationTime;
        
        public CacheMetrics(MeterRegistry meterRegistry) {
            this.meterRegistry = meterRegistry;
            
            this.cacheHits = Counter.builder("cache.hits.total")
                .description("Total cache hits")
                .register(meterRegistry);
            
            this.cacheMisses = Counter.builder("cache.misses.total")
                .description("Total cache misses")
                .register(meterRegistry);
            
            this.cacheErrors = Counter.builder("cache.errors.total")
                .description("Total cache errors")
                .register(meterRegistry);
            
            this.cacheOperationTime = Timer.builder("cache.operation.duration")
                .description("Cache operation duration")
                .register(meterRegistry);
        }
        
        public void recordCacheHit(String cacheLevel, String key) {
            cacheHits.increment(
                Tags.of("level", cacheLevel, "operation", "get"));
        }
        
        public void recordCacheMiss(String key) {
            cacheMisses.increment(Tags.of("operation", "get"));
        }
        
        public void recordCachePut(String cacheLevel, String key) {
            cacheHits.increment(
                Tags.of("level", cacheLevel, "operation", "put"));
        }
        
        public void recordCacheEviction(String key) {
            cacheHits.increment(Tags.of("operation", "evict"));
        }
        
        public void recordCacheError(String cacheLevel, String key, Exception error) {
            cacheErrors.increment(
                Tags.of("level", cacheLevel, "error_type", error.getClass().getSimpleName()));
        }
        
        public void recordLocalCacheEviction(String key) {
            cacheHits.increment(Tags.of("level", "L1", "operation", "lru_evict"));
        }
        
        public Timer.Sample startTimer() {
            return Timer.start(meterRegistry);
        }
    }
}
