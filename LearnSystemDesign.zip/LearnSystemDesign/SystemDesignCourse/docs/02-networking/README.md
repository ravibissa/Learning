# Module 2: Networking for System Design

## 🌐 Understanding Network Architecture for Scalable Systems

### 📚 Learning Objectives

By the end of this module, you will:
- Understand TCP/UDP protocols and when to use each
- Design load balancing strategies for high availability
- Implement CDN patterns for global content delivery
- Configure API gateways for microservices
- Handle network failures and partitions gracefully
- Optimize network performance for various use cases

---

## 🏗️ Core Networking Concepts

### 1. Protocol Selection

#### TCP vs UDP Trade-offs
```java
// TCP: Reliable, ordered, connection-oriented
@Service
public class ReliableMessageService {
    
    @Autowired
    private KafkaTemplate<String, Object> kafkaTemplate;
    
    // Uses TCP for guaranteed delivery
    public void sendCriticalUpdate(String userId, UpdateMessage message) {
        // Kafka uses TCP underneath for reliable delivery
        kafkaTemplate.send("critical-updates", userId, message)
            .addCallback(
                result -> log.info("Message sent successfully: {}", result),
                error -> log.error("Failed to send message", error)
            );
    }
}

// UDP: Fast, connectionless, best-effort
@Component
public class MetricsCollector {
    
    @EventListener
    public void collectMetrics(MetricEvent event) {
        // Use UDP for high-frequency, non-critical metrics
        // Acceptable to lose some data points for performance
        sendUdpMetric(event);
    }
    
    private void sendUdpMetric(MetricEvent event) {
        // StatsD uses UDP for high-performance metrics
        // Metrics.counter("app.events", event.getTags()).increment();
    }
}
```

#### HTTP/1.1 vs HTTP/2 vs HTTP/3
```yaml
# HTTP/1.1 - Traditional request/response
Characteristics:
  - One request per connection
  - Head-of-line blocking
  - Multiple connections needed
  - Text-based protocol

Use Cases:
  - Simple APIs
  - Legacy systems
  - Internal services

# HTTP/2 - Multiplexing and server push
Characteristics:
  - Multiple streams per connection
  - Binary protocol
  - Header compression
  - Server push capability

Use Cases:
  - Modern web applications
  - API gateways
  - High-performance services

# HTTP/3 - QUIC-based
Characteristics:
  - Built on UDP
  - No head-of-line blocking
  - Faster connection establishment
  - Better mobile performance

Use Cases:
  - Real-time applications
  - Mobile-first services
  - Gaming platforms
```

### 2. Load Balancing Strategies

#### Application Load Balancer with Spring Cloud
```java
// Load balancer configuration
@Configuration
public class LoadBalancerConfig {
    
    @Bean
    @LoadBalanced
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }
    
    @Bean
    public ReactorLoadBalancerExchangeFilterFunction lbFunction(
            ReactiveLoadBalancer.Factory<ServiceInstance> lbClientFactory) {
        return new ReactorLoadBalancerExchangeFilterFunction(lbClientFactory);
    }
}

// Service with client-side load balancing
@Service
public class OrderService {
    
    @Autowired
    @LoadBalanced
    private RestTemplate restTemplate;
    
    public PaymentResponse processPayment(PaymentRequest request) {
        // Automatically load-balanced across payment service instances
        return restTemplate.postForObject(
            "http://payment-service/api/payments",
            request,
            PaymentResponse.class
        );
    }
}

// Custom load balancing algorithm
@Component
public class WeightedRoundRobinLoadBalancer implements ReactorServiceInstanceLoadBalancer {
    
    private final String serviceId;
    private final ObjectProvider<ServiceInstanceListSupplier> serviceInstanceListSupplierProvider;
    private final AtomicInteger position = new AtomicInteger(0);
    
    @Override
    public Mono<Response<ServiceInstance>> choose(Request request) {
        return serviceInstanceListSupplierProvider.getIfAvailable()
            .get()
            .next()
            .map(serviceInstances -> getInstanceResponse(serviceInstances));
    }
    
    private Response<ServiceInstance> getInstanceResponse(List<ServiceInstance> instances) {
        if (instances.isEmpty()) {
            return new EmptyResponse();
        }
        
        // Implement weighted selection based on instance metadata
        ServiceInstance instance = selectByWeight(instances);
        return new DefaultResponse(instance);
    }
    
    private ServiceInstance selectByWeight(List<ServiceInstance> instances) {
        // Calculate total weight
        int totalWeight = instances.stream()
            .mapToInt(instance -> getWeight(instance))
            .sum();
        
        // Select based on weight
        int randomWeight = ThreadLocalRandom.current().nextInt(totalWeight);
        
        for (ServiceInstance instance : instances) {
            randomWeight -= getWeight(instance);
            if (randomWeight < 0) {
                return instance;
            }
        }
        
        return instances.get(0); // fallback
    }
    
    private int getWeight(ServiceInstance instance) {
        String weight = instance.getMetadata().get("weight");
        return weight != null ? Integer.parseInt(weight) : 1;
    }
}
```

#### Health Checks for Load Balancing
```java
// Custom health check for load balancer
@Component
public class ServiceHealthIndicator implements HealthIndicator {
    
    @Autowired
    private DataSource dataSource;
    
    @Autowired
    private RedisTemplate<String, String> redisTemplate;
    
    @Override
    public Health health() {
        Health.Builder status = Health.up();
        
        // Check database
        if (!isDatabaseHealthy()) {
            status.down().withDetail("database", "Connection failed");
            return status.build();
        }
        
        // Check Redis
        if (!isRedisHealthy()) {
            status.down().withDetail("redis", "Connection failed");
            return status.build();
        }
        
        // Check current load
        double currentLoad = getCurrentLoad();
        if (currentLoad > 0.9) {
            status.down().withDetail("load", "High CPU usage: " + currentLoad);
            return status.build();
        }
        
        return status
            .withDetail("database", "UP")
            .withDetail("redis", "UP")
            .withDetail("load", currentLoad)
            .build();
    }
    
    private boolean isDatabaseHealthy() {
        try (Connection connection = dataSource.getConnection()) {
            return connection.isValid(1);
        } catch (SQLException e) {
            return false;
        }
    }
    
    private boolean isRedisHealthy() {
        try {
            redisTemplate.opsForValue().get("health-check");
            return true;
        } catch (Exception e) {
            return false;
        }
    }
    
    private double getCurrentLoad() {
        return ManagementFactory.getOperatingSystemMXBean().getProcessCpuLoad();
    }
}
```

### 3. API Gateway Patterns

#### Spring Cloud Gateway Implementation
```java
@Configuration
public class GatewayConfig {
    
    @Bean
    public RouteLocator customRoutes(RouteLocatorBuilder builder) {
        return builder.routes()
            // User service with authentication
            .route("user-service", r -> r
                .path("/api/users/**")
                .filters(f -> f
                    .filter(authenticationFilter())
                    .circuitBreaker(c -> c
                        .setName("user-service-cb")
                        .setFallbackUri("/fallback/users"))
                    .retry(retryConfig -> retryConfig
                        .setRetries(3)
                        .setBackoff(Duration.ofMillis(100), Duration.ofMillis(500), 2, true))
                    .requestRateLimiter(rlConfig -> rlConfig
                        .setRateLimiter(redisRateLimiter())
                        .setKeyResolver(userKeyResolver())))
                .uri("lb://user-service"))
            
            // Order service with request transformation
            .route("order-service", r -> r
                .path("/api/orders/**")
                .filters(f -> f
                    .addRequestHeader("X-Gateway-Source", "api-gateway")
                    .modifyRequestBody(String.class, String.class, 
                        (exchange, body) -> sanitizeRequest(body))
                    .modifyResponseBody(String.class, String.class,
                        (exchange, body) -> enhanceResponse(body)))
                .uri("lb://order-service"))
            
            // Websocket routing
            .route("websocket-service", r -> r
                .path("/ws/**")
                .uri("lb://websocket-service"))
            
            build();
    }
    
    @Bean
    public GatewayFilter authenticationFilter() {
        return (exchange, chain) -> {
            ServerHttpRequest request = exchange.getRequest();
            
            // Extract JWT token
            String authHeader = request.getHeaders().getFirst("Authorization");
            if (authHeader == null || !authHeader.startsWith("Bearer ")) {
                return unauthorizedResponse(exchange);
            }
            
            String token = authHeader.substring(7);
            
            // Validate token
            return validateTokenAsync(token)
                .flatMap(isValid -> {
                    if (isValid) {
                        // Add user context to request
                        ServerHttpRequest mutatedRequest = request.mutate()
                            .header("X-User-ID", extractUserId(token))
                            .header("X-User-Roles", extractUserRoles(token))
                            .build();
                        
                        return chain.filter(exchange.mutate().request(mutatedRequest).build());
                    } else {
                        return unauthorizedResponse(exchange);
                    }
                });
        };
    }
    
    @Bean
    public RedisRateLimiter redisRateLimiter() {
        return new RedisRateLimiter(100, 200); // replenishRate, burstCapacity
    }
    
    @Bean
    public KeyResolver userKeyResolver() {
        return exchange -> {
            String userId = exchange.getRequest().getHeaders().getFirst("X-User-ID");
            return Mono.justOrEmpty(userId).switchIfEmpty(Mono.just("anonymous"));
        };
    }
    
    private Mono<ServerResponse> unauthorizedResponse(ServerWebExchange exchange) {
        ServerHttpResponse response = exchange.getResponse();
        response.setStatusCode(HttpStatus.UNAUTHORIZED);
        response.getHeaders().add("Content-Type", "application/json");
        
        String body = "{\"error\":\"Unauthorized\",\"message\":\"Valid JWT token required\"}";
        DataBuffer buffer = response.bufferFactory().wrap(body.getBytes());
        
        return response.writeWith(Mono.just(buffer));
    }
}
```

#### Gateway Metrics and Monitoring
```java
@Component
public class GatewayMetrics {
    
    private final Counter requestCounter;
    private final Timer requestTimer;
    private final Gauge activeConnections;
    
    public GatewayMetrics(MeterRegistry meterRegistry) {
        this.requestCounter = Counter.builder("gateway.requests.total")
            .description("Total requests through gateway")
            .register(meterRegistry);
            
        this.requestTimer = Timer.builder("gateway.request.duration")
            .description("Request duration through gateway")
            .register(meterRegistry);
            
        this.activeConnections = Gauge.builder("gateway.connections.active")
            .description("Active connections through gateway")
            .register(meterRegistry, this, GatewayMetrics::getActiveConnections);
    }
    
    @EventListener
    public void handleGatewayRequest(GatewayRequestEvent event) {
        requestCounter.increment(
            Tags.of(
                "service", event.getTargetService(),
                "method", event.getMethod(),
                "status", String.valueOf(event.getStatusCode())
            )
        );
        
        requestTimer.record(
            event.getDuration(),
            Tags.of(
                "service", event.getTargetService(),
                "method", event.getMethod()
            )
        );
    }
    
    private double getActiveConnections() {
        // Return current active connection count
        return connectionManager.getActiveCount();
    }
}
```

### 4. Content Delivery Networks (CDN)

#### CDN Strategy Implementation
```java
@Service
public class ContentDeliveryService {
    
    @Autowired
    private S3Client s3Client;
    
    @Autowired
    private CloudFrontClient cloudFrontClient;
    
    public ContentUrl uploadAndDistribute(String fileName, InputStream content, String contentType) {
        // Upload to S3
        String s3Key = generateS3Key(fileName);
        PutObjectRequest putRequest = PutObjectRequest.builder()
            .bucket("content-bucket")
            .key(s3Key)
            .contentType(contentType)
            .cacheControl("max-age=31536000") // 1 year
            .build();
        
        s3Client.putObject(putRequest, RequestBody.fromInputStream(content, content.available()));
        
        // Create CloudFront distribution if needed
        String distributionDomain = getOrCreateDistribution();
        
        return ContentUrl.builder()
            .originalUrl("https://content-bucket.s3.amazonaws.com/" + s3Key)
            .cdnUrl("https://" + distributionDomain + "/" + s3Key)
            .fileName(fileName)
            .contentType(contentType)
            .build();
    }
    
    @Cacheable("cdn-urls")
    public String getCdnUrl(String fileName) {
        // Get optimized CDN URL based on user location
        String userRegion = getCurrentUserRegion();
        return selectOptimalCdnEndpoint(fileName, userRegion);
    }
    
    private String selectOptimalCdnEndpoint(String fileName, String region) {
        // Route to nearest edge location
        return switch (region) {
            case "us-east" -> "https://d1234567890.cloudfront.net/" + fileName;
            case "us-west" -> "https://d0987654321.cloudfront.net/" + fileName;
            case "eu-west" -> "https://d1122334455.cloudfront.net/" + fileName;
            case "ap-southeast" -> "https://d5544332211.cloudfront.net/" + fileName;
            default -> "https://global.example.com/" + fileName;
        };
    }
    
    public void invalidateCache(List<String> paths) {
        // Invalidate CloudFront cache
        CreateInvalidationRequest invalidationRequest = CreateInvalidationRequest.builder()
            .distributionId("E1234567890ABC")
            .invalidationBatch(InvalidationBatch.builder()
                .paths(Paths.builder()
                    .quantity(paths.size())
                    .items(paths)
                    .build())
                .callerReference(UUID.randomUUID().toString())
                .build())
            .build();
        
        cloudFrontClient.createInvalidation(invalidationRequest);
    }
}

// CDN optimization strategies
@Component
public class CdnOptimizer {
    
    public void optimizeImages(String imagePath) {
        // Implement image optimization
        // - WebP conversion for modern browsers
        // - Responsive image sizes
        // - Lazy loading implementation
    }
    
    public void preloadCriticalResources(List<String> resources) {
        // Push critical resources to edge caches
        resources.forEach(this::warmUpEdgeCache);
    }
    
    private void warmUpEdgeCache(String resource) {
        // Pre-fetch to edge locations
        CompletableFuture.runAsync(() -> {
            // Make requests to different edge locations
            // to warm up the cache
        });
    }
}
```

### 5. Network Security

#### SSL/TLS Configuration
```java
@Configuration
public class SecurityConfig {
    
    @Bean
    public TomcatServletWebServerFactory servletContainer() {
        TomcatServletWebServerFactory tomcat = new TomcatServletWebServerFactory() {
            @Override
            protected void postProcessContext(Context context) {
                // Configure security headers
                SecurityConstraint securityConstraint = new SecurityConstraint();
                securityConstraint.setUserConstraint("CONFIDENTIAL");
                SecurityCollection collection = new SecurityCollection();
                collection.addPattern("/*");
                securityConstraint.addCollection(collection);
                context.addConstraint(securityConstraint);
            }
        };
        
        // HTTP to HTTPS redirect
        tomcat.addAdditionalTomcatConnectors(createHttpConnector());
        return tomcat;
    }
    
    private Connector createHttpConnector() {
        Connector connector = new Connector(TomcatServletWebServerFactory.DEFAULT_PROTOCOL);
        connector.setScheme("http");
        connector.setPort(8080);
        connector.setSecure(false);
        connector.setRedirectPort(8443);
        return connector;
    }
}

// Rate limiting for DDoS protection
@Component
public class DdosProtectionFilter implements Filter {
    
    private final Map<String, AtomicInteger> requestCounts = new ConcurrentHashMap<>();
    private final Map<String, Long> lastRequestTime = new ConcurrentHashMap<>();
    
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;
        
        String clientIp = getClientIp(httpRequest);
        
        if (isRateLimited(clientIp)) {
            httpResponse.setStatus(HttpStatus.TOO_MANY_REQUESTS.value());
            httpResponse.getWriter().write("{\"error\":\"Rate limit exceeded\"}");
            return;
        }
        
        chain.doFilter(request, response);
    }
    
    private boolean isRateLimited(String clientIp) {
        long currentTime = System.currentTimeMillis();
        long lastTime = lastRequestTime.getOrDefault(clientIp, 0L);
        
        // Reset counter every minute
        if (currentTime - lastTime > 60000) {
            requestCounts.put(clientIp, new AtomicInteger(0));
            lastRequestTime.put(clientIp, currentTime);
        }
        
        int count = requestCounts.computeIfAbsent(clientIp, k -> new AtomicInteger(0))
            .incrementAndGet();
        
        return count > 1000; // 1000 requests per minute limit
    }
    
    private String getClientIp(HttpServletRequest request) {
        String xForwardedFor = request.getHeader("X-Forwarded-For");
        if (xForwardedFor != null && !xForwardedFor.isEmpty()) {
            return xForwardedFor.split(",")[0].trim();
        }
        
        String xRealIp = request.getHeader("X-Real-IP");
        if (xRealIp != null && !xRealIp.isEmpty()) {
            return xRealIp;
        }
        
        return request.getRemoteAddr();
    }
}
```

### 6. Network Performance Optimization

#### Connection Pooling
```java
@Configuration
public class HttpClientConfig {
    
    @Bean
    public RestTemplate restTemplate() {
        HttpComponentsClientHttpRequestFactory factory = 
            new HttpComponentsClientHttpRequestFactory();
        
        // Configure connection pooling
        PoolingHttpClientConnectionManager connectionManager = 
            new PoolingHttpClientConnectionManager();
        connectionManager.setMaxTotal(200);
        connectionManager.setDefaultMaxPerRoute(50);
        
        CloseableHttpClient httpClient = HttpClients.custom()
            .setConnectionManager(connectionManager)
            .setConnectionTimeToLive(30, TimeUnit.SECONDS)
            .setDefaultRequestConfig(RequestConfig.custom()
                .setSocketTimeout(5000)
                .setConnectTimeout(3000)
                .setConnectionRequestTimeout(3000)
                .build())
            .build();
        
        factory.setHttpClient(httpClient);
        factory.setConnectTimeout(3000);
        factory.setReadTimeout(5000);
        
        return new RestTemplate(factory);
    }
    
    @Bean
    public WebClient webClient() {
        // Reactive HTTP client with connection pooling
        ConnectionProvider connectionProvider = ConnectionProvider.builder("custom")
            .maxConnections(200)
            .maxIdleTime(Duration.ofSeconds(20))
            .maxLifeTime(Duration.ofMinutes(5))
            .pendingAcquireTimeout(Duration.ofSeconds(3))
            .evictInBackground(Duration.ofSeconds(120))
            .build();
        
        HttpClient httpClient = HttpClient.create(connectionProvider)
            .option(ChannelOption.CONNECT_TIMEOUT_MILLIS, 3000)
            .responseTimeout(Duration.ofSeconds(5))
            .doOnConnected(conn -> 
                conn.addHandlerLast(new ReadTimeoutHandler(5))
                    .addHandlerLast(new WriteTimeoutHandler(5)));
        
        return WebClient.builder()
            .clientConnector(new ReactorClientHttpConnector(httpClient))
            .build();
    }
}
```

#### Compression and Optimization
```java
@Configuration
public class CompressionConfig {
    
    @Bean
    public FilterRegistrationBean<GzipFilter> gzipFilter() {
        FilterRegistrationBean<GzipFilter> registration = new FilterRegistrationBean<>();
        registration.setFilter(new GzipFilter());
        registration.addUrlPatterns("/api/*");
        registration.setOrder(1);
        return registration;
    }
}

@Component
public class GzipFilter implements Filter {
    
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;
        
        String acceptEncoding = httpRequest.getHeader("Accept-Encoding");
        
        if (acceptEncoding != null && acceptEncoding.contains("gzip")) {
            GzipResponseWrapper wrappedResponse = new GzipResponseWrapper(httpResponse);
            chain.doFilter(request, wrappedResponse);
            wrappedResponse.finishResponse();
        } else {
            chain.doFilter(request, response);
        }
    }
}
```

---

## 🎯 Interview Focus Areas

### Key Questions & Concepts

**Q: How do you design a globally distributed system?**
- CDN strategy with edge locations
- Geographic load balancing
- Data locality and compliance
- Multi-region failover

**Q: How do you handle network failures?**
- Circuit breaker patterns
- Retry with exponential backoff
- Graceful degradation
- Timeout strategies

**Q: How do you optimize for mobile networks?**
- HTTP/3 for better performance
- Compression strategies
- Adaptive bitrate streaming
- Offline-first architecture

**Q: How do you secure network communications?**
- TLS everywhere
- Certificate management
- DDoS protection
- Rate limiting strategies

---

## 📊 Performance Metrics

### Key Network Metrics to Monitor

```java
@Component
public class NetworkMetrics {
    
    @EventListener
    public void recordNetworkMetrics(NetworkEvent event) {
        // Latency metrics
        Metrics.timer("network.latency", 
            "endpoint", event.getEndpoint(),
            "region", event.getRegion())
            .record(event.getLatency(), TimeUnit.MILLISECONDS);
        
        // Throughput metrics
        Metrics.counter("network.requests.total",
            "method", event.getMethod(),
            "status", String.valueOf(event.getStatusCode()))
            .increment();
        
        // Error rate metrics
        if (event.getStatusCode() >= 400) {
            Metrics.counter("network.errors.total",
                "type", event.getErrorType())
                .increment();
        }
        
        // Connection pool metrics
        Metrics.gauge("network.connections.active", 
            connectionManager.getActiveConnections());
        Metrics.gauge("network.connections.idle", 
            connectionManager.getIdleConnections());
    }
}
```

### Capacity Planning
- **Bandwidth requirements**: Peak concurrent users × average request size
- **Connection limits**: Consider OS limits (ulimit) and load balancer capacity
- **Latency budgets**: P95 < 200ms for user-facing APIs
- **Failover capacity**: N+1 redundancy for critical services

---

## 🚀 Next Steps

1. **Complete the hands-on exercises** in the exercises folder
2. **Review the networking diagrams** to understand traffic flow
3. **Implement sample load balancers** using provided examples
4. **Practice capacity planning** calculations
5. **Move to Module 3: Storage Systems**

The networking module provides the foundation for building distributed systems that can scale globally while maintaining performance and reliability.
