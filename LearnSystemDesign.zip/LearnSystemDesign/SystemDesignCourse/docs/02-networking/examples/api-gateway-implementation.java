// API Gateway Implementation Example
// Demonstrates Spring Cloud Gateway patterns for system design

package com.systemdesign.networking.examples;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

/**
 * Production-ready API Gateway implementation
 * Demonstrates patterns used in system design interviews
 */
@SpringBootApplication
public class ApiGatewayExample {
    
    public static void main(String[] args) {
        SpringApplication.run(ApiGatewayExample.class, args);
    }
    
    /**
     * Route configuration demonstrating various gateway patterns
     */
    @Bean
    public RouteLocator customRoutes(RouteLocatorBuilder builder) {
        return builder.routes()
            
            // User Service Routes with Authentication
            .route("user-service", r -> r
                .path("/api/v1/users/**")
                .filters(f -> f
                    // Add authentication filter
                    .filter(new JwtAuthenticationGatewayFilterFactory().apply(
                        new JwtAuthenticationGatewayFilterFactory.Config()))
                    
                    // Circuit breaker for resilience
                    .circuitBreaker(c -> c
                        .setName("user-service-cb")
                        .setFallbackUri("/fallback/users")
                        .setRouteId("user-service"))
                    
                    // Retry with exponential backoff
                    .retry(retryConfig -> retryConfig
                        .setRetries(3)
                        .setBackoff(
                            Duration.ofMillis(100), 
                            Duration.ofMillis(500), 
                            2, 
                            true))
                    
                    // Rate limiting per user
                    .requestRateLimiter(rlConfig -> rlConfig
                        .setRateLimiter(userRateLimiter())
                        .setKeyResolver(userKeyResolver())
                        .setStatusCode(HttpStatus.TOO_MANY_REQUESTS))
                    
                    // Request/Response transformation
                    .modifyRequestBody(String.class, String.class, 
                        (exchange, body) -> sanitizeUserRequest(body))
                    .addRequestHeader("X-Gateway-Timestamp", 
                        () -> Instant.now().toString())
                    .addResponseHeader("X-Response-Source", "api-gateway"))
                
                .uri("lb://user-service")
                .metadata("version", "v1")
                .metadata("timeout", 5000))
            
            // Order Service Routes with Enhanced Security
            .route("order-service", r -> r
                .path("/api/v1/orders/**")
                .and()
                .method("POST", "PUT", "DELETE")
                .filters(f -> f
                    // HTTPS enforcement
                    .redirect(HttpStatus.MOVED_PERMANENTLY, 
                        "https://api.example.com${path}")
                    
                    // Enhanced authentication for write operations
                    .filter(new EnhancedAuthGatewayFilterFactory().apply(
                        new EnhancedAuthGatewayFilterFactory.Config()
                            .setRequiredRoles(Arrays.asList("USER", "ORDER_WRITE"))
                            .setMfaRequired(true)))
                    
                    // Order-specific rate limiting (stricter for writes)
                    .requestRateLimiter(rlConfig -> rlConfig
                        .setRateLimiter(orderWriteRateLimiter())
                        .setKeyResolver(userKeyResolver()))
                    
                    // Request validation
                    .filter(new RequestValidationGatewayFilterFactory().apply(
                        new RequestValidationGatewayFilterFactory.Config()
                            .setMaxPayloadSize(1024 * 1024) // 1MB limit
                            .setRequiredHeaders(Arrays.asList("Content-Type", "X-Request-ID"))))
                    
                    // Audit logging
                    .filter(new AuditLoggingGatewayFilterFactory().apply(
                        new AuditLoggingGatewayFilterFactory.Config()
                            .setLogLevel("INFO")
                            .setIncludePayload(true))))
                
                .uri("lb://order-service"))
            
            // Public API Routes (Read-only, higher rate limits)
            .route("public-api", r -> r
                .path("/public/api/**")
                .filters(f -> f
                    .stripPrefix(1) // Remove /public prefix
                    
                    // Public API rate limiting (more permissive)
                    .requestRateLimiter(rlConfig -> rlConfig
                        .setRateLimiter(publicApiRateLimiter())
                        .setKeyResolver(ipKeyResolver()))
                    
                    // CORS configuration
                    .filter(new CorsGatewayFilterFactory().apply(
                        new CorsGatewayFilterFactory.Config()
                            .setAllowedOrigins(Arrays.asList("*"))
                            .setAllowedMethods(Arrays.asList("GET", "HEAD", "OPTIONS"))
                            .setAllowedHeaders(Arrays.asList("*"))
                            .setMaxAge(Duration.ofHours(1))))
                    
                    // Response caching
                    .filter(new ResponseCacheGatewayFilterFactory().apply(
                        new ResponseCacheGatewayFilterFactory.Config()
                            .setTtl(Duration.ofMinutes(5))
                            .setCacheKeyGenerator(new PathBasedCacheKeyGenerator()))))
                
                .uri("lb://public-service"))
            
            // WebSocket Routes for Real-time Communication
            .route("websocket-service", r -> r
                .path("/ws/**")
                .filters(f -> f
                    // WebSocket authentication
                    .filter(new WebSocketAuthGatewayFilterFactory().apply(
                        new WebSocketAuthGatewayFilterFactory.Config()))
                    
                    // Connection limiting
                    .filter(new ConnectionLimitGatewayFilterFactory().apply(
                        new ConnectionLimitGatewayFilterFactory.Config()
                            .setMaxConnectionsPerUser(10)
                            .setMaxTotalConnections(10000))))
                
                .uri("lb://websocket-service"))
            
            // Admin Routes with Strict Security
            .route("admin-api", r -> r
                .path("/admin/**")
                .filters(f -> f
                    // Admin-only authentication
                    .filter(new AdminAuthGatewayFilterFactory().apply(
                        new AdminAuthGatewayFilterFactory.Config()
                            .setRequiredRoles(Arrays.asList("ADMIN", "SUPER_ADMIN"))
                            .setMfaRequired(true)
                            .setIpWhitelist(Arrays.asList("10.0.0.0/8", "192.168.0.0/16"))))
                    
                    // Strict rate limiting for admin operations
                    .requestRateLimiter(rlConfig -> rlConfig
                        .setRateLimiter(adminRateLimiter())
                        .setKeyResolver(userKeyResolver()))
                    
                    // Comprehensive audit logging
                    .filter(new ComprehensiveAuditGatewayFilterFactory().apply(
                        new ComprehensiveAuditGatewayFilterFactory.Config()
                            .setLogAllRequests(true)
                            .setLogAllResponses(true)
                            .setLogPayloads(true))))
                
                .uri("lb://admin-service"))
            
            // Health and Monitoring Routes
            .route("health-check", r -> r
                .path("/health/**", "/actuator/**")
                .filters(f -> f
                    .stripPrefix(0)
                    .addResponseHeader("Cache-Control", "no-cache"))
                .uri("lb://health-service"))
            
            .build();
    }
    
    /**
     * Rate limiter configurations for different service tiers
     */
    
    @Bean
    public RedisRateLimiter userRateLimiter() {
        return new RedisRateLimiter(
            100,  // replenishRate: tokens per second
            200   // burstCapacity: max tokens in bucket
        );
    }
    
    @Bean
    public RedisRateLimiter orderWriteRateLimiter() {
        return new RedisRateLimiter(
            10,   // replenishRate: stricter for write operations
            50    // burstCapacity: lower burst for orders
        );
    }
    
    @Bean
    public RedisRateLimiter publicApiRateLimiter() {
        return new RedisRateLimiter(
            1000, // replenishRate: higher for public API
            2000  // burstCapacity: allow higher bursts
        );
    }
    
    @Bean
    public RedisRateLimiter adminRateLimiter() {
        return new RedisRateLimiter(
            5,    // replenishRate: very strict for admin operations
            10    // burstCapacity: minimal burst allowance
        );
    }
    
    /**
     * Key resolvers for rate limiting
     */
    
    @Bean
    public KeyResolver userKeyResolver() {
        return exchange -> exchange.getRequest().getHeaders()
            .getFirst("X-User-ID") != null ? 
            Mono.just(exchange.getRequest().getHeaders().getFirst("X-User-ID")) :
            Mono.just("anonymous");
    }
    
    @Bean
    public KeyResolver ipKeyResolver() {
        return exchange -> {
            String xForwardedFor = exchange.getRequest().getHeaders().getFirst("X-Forwarded-For");
            String clientIp = xForwardedFor != null ? 
                xForwardedFor.split(",")[0].trim() : 
                exchange.getRequest().getRemoteAddress().getAddress().getHostAddress();
            return Mono.just(clientIp);
        };
    }
    
    /**
     * Fallback controllers for circuit breaker
     */
    
    @RestController
    public static class FallbackController {
        
        @RequestMapping("/fallback/users")
        public Mono<ResponseEntity<Object>> usersFallback() {
            return Mono.just(ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE)
                .body(Map.of(
                    "error", "User service temporarily unavailable",
                    "message", "Please try again later",
                    "timestamp", Instant.now().toString(),
                    "retryAfter", "60"
                )));
        }
        
        @RequestMapping("/fallback/orders")
        public Mono<ResponseEntity<Object>> ordersFallback() {
            return Mono.just(ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE)
                .body(Map.of(
                    "error", "Order service temporarily unavailable",
                    "message", "Your order will be processed when service is restored",
                    "timestamp", Instant.now().toString(),
                    "supportContact", "support@example.com"
                )));
        }
    }
    
    /**
     * Request sanitization utility
     */
    private Mono<String> sanitizeUserRequest(String body) {
        // Remove potentially harmful content
        String sanitized = body
            .replaceAll("<script[^>]*>.*?</script>", "") // Remove script tags
            .replaceAll("javascript:", "")               // Remove javascript protocols
            .trim();
        
        // Validate JSON structure
        try {
            ObjectMapper mapper = new ObjectMapper();
            JsonNode node = mapper.readTree(sanitized);
            return Mono.just(mapper.writeValueAsString(node));
        } catch (Exception e) {
            return Mono.error(new InvalidRequestException("Invalid JSON payload"));
        }
    }
    
    /**
     * Custom Gateway Filter for JWT Authentication
     */
    public static class JwtAuthenticationGatewayFilterFactory 
            extends AbstractGatewayFilterFactory<JwtAuthenticationGatewayFilterFactory.Config> {
        
        public JwtAuthenticationGatewayFilterFactory() {
            super(Config.class);
        }
        
        @Override
        public GatewayFilter apply(Config config) {
            return (exchange, chain) -> {
                ServerHttpRequest request = exchange.getRequest();
                
                String authHeader = request.getHeaders().getFirst("Authorization");
                if (authHeader == null || !authHeader.startsWith("Bearer ")) {
                    return handleUnauthorized(exchange);
                }
                
                String token = authHeader.substring(7);
                
                return validateTokenAsync(token)
                    .flatMap(claims -> {
                        if (claims != null && !claims.isEmpty()) {
                            // Add user context to request
                            ServerHttpRequest mutatedRequest = request.mutate()
                                .header("X-User-ID", claims.get("sub").toString())
                                .header("X-User-Roles", claims.get("roles").toString())
                                .header("X-User-Email", claims.get("email").toString())
                                .build();
                            
                            return chain.filter(exchange.mutate().request(mutatedRequest).build());
                        } else {
                            return handleUnauthorized(exchange);
                        }
                    })
                    .onErrorResume(ex -> handleUnauthorized(exchange));
            };
        }
        
        private Mono<ServerResponse> handleUnauthorized(ServerWebExchange exchange) {
            ServerHttpResponse response = exchange.getResponse();
            response.setStatusCode(HttpStatus.UNAUTHORIZED);
            response.getHeaders().add("Content-Type", "application/json");
            
            String body = """
                {
                    "error": "Unauthorized",
                    "message": "Valid JWT token required",
                    "timestamp": "%s"
                }
                """.formatted(Instant.now().toString());
            
            DataBuffer buffer = response.bufferFactory().wrap(body.getBytes());
            return response.writeWith(Mono.just(buffer));
        }
        
        private Mono<Map<String, Object>> validateTokenAsync(String token) {
            return Mono.fromCallable(() -> {
                // JWT validation logic here
                // This would typically involve:
                // 1. Verifying signature
                // 2. Checking expiration
                // 3. Validating issuer
                // 4. Extracting claims
                
                return Map.of(
                    "sub", "user123",
                    "email", "user@example.com",
                    "roles", "USER,ORDER_READ"
                );
            })
            .subscribeOn(Schedulers.boundedElastic())
            .timeout(Duration.ofSeconds(2))
            .onErrorReturn(Collections.emptyMap());
        }
        
        public static class Config {
            // Configuration properties for JWT authentication
            private String issuer = "api-gateway";
            private Duration timeout = Duration.ofSeconds(2);
            private boolean validateAudience = true;
            
            // Getters and setters
            public String getIssuer() { return issuer; }
            public void setIssuer(String issuer) { this.issuer = issuer; }
            
            public Duration getTimeout() { return timeout; }
            public void setTimeout(Duration timeout) { this.timeout = timeout; }
            
            public boolean isValidateAudience() { return validateAudience; }
            public void setValidateAudience(boolean validateAudience) { this.validateAudience = validateAudience; }
        }
    }
    
    /**
     * Custom exception for invalid requests
     */
    public static class InvalidRequestException extends RuntimeException {
        public InvalidRequestException(String message) {
            super(message);
        }
    }
    
    /**
     * Gateway metrics for monitoring
     */
    @Component
    public static class GatewayMetrics {
        
        private final Counter requestCounter;
        private final Timer responseTimer;
        private final Gauge activeConnections;
        private final Counter errorCounter;
        
        public GatewayMetrics(MeterRegistry meterRegistry) {
            this.requestCounter = Counter.builder("gateway.requests.total")
                .description("Total requests through gateway")
                .register(meterRegistry);
                
            this.responseTimer = Timer.builder("gateway.response.time")
                .description("Response time through gateway")
                .register(meterRegistry);
                
            this.activeConnections = Gauge.builder("gateway.connections.active")
                .description("Active connections through gateway")
                .register(meterRegistry, this, GatewayMetrics::getActiveConnectionCount);
                
            this.errorCounter = Counter.builder("gateway.errors.total")
                .description("Total errors in gateway")
                .register(meterRegistry);
        }
        
        public void recordRequest(String route, String method, int statusCode, Duration responseTime) {
            requestCounter.increment(
                Tags.of(
                    "route", route,
                    "method", method,
                    "status", String.valueOf(statusCode)
                )
            );
            
            responseTimer.record(responseTime, Tags.of("route", route));
            
            if (statusCode >= 400) {
                errorCounter.increment(
                    Tags.of(
                        "route", route,
                        "error_type", getErrorType(statusCode)
                    )
                );
            }
        }
        
        private double getActiveConnectionCount() {
            // Return current active connection count
            // This would be implemented based on your connection tracking mechanism
            return 0.0; // Placeholder
        }
        
        private String getErrorType(int statusCode) {
            return switch (statusCode / 100) {
                case 4 -> "client_error";
                case 5 -> "server_error";
                default -> "unknown";
            };
        }
    }
}

/**
 * Configuration properties for the API Gateway
 */
@ConfigurationProperties(prefix = "api.gateway")
public class ApiGatewayProperties {
    
    private Security security = new Security();
    private RateLimit rateLimit = new RateLimit();
    private Circuit circuit = new Circuit();
    private Timeout timeout = new Timeout();
    
    // Getters and setters
    public Security getSecurity() { return security; }
    public RateLimit getRateLimit() { return rateLimit; }
    public Circuit getCircuit() { return circuit; }
    public Timeout getTimeout() { return timeout; }
    
    public static class Security {
        private boolean jwtValidationEnabled = true;
        private String jwtSecret = "default-secret";
        private Duration jwtExpiration = Duration.ofHours(24);
        private List<String> allowedOrigins = Arrays.asList("*");
        
        // Getters and setters
        public boolean isJwtValidationEnabled() { return jwtValidationEnabled; }
        public void setJwtValidationEnabled(boolean jwtValidationEnabled) { this.jwtValidationEnabled = jwtValidationEnabled; }
        
        public String getJwtSecret() { return jwtSecret; }
        public void setJwtSecret(String jwtSecret) { this.jwtSecret = jwtSecret; }
        
        public Duration getJwtExpiration() { return jwtExpiration; }
        public void setJwtExpiration(Duration jwtExpiration) { this.jwtExpiration = jwtExpiration; }
        
        public List<String> getAllowedOrigins() { return allowedOrigins; }
        public void setAllowedOrigins(List<String> allowedOrigins) { this.allowedOrigins = allowedOrigins; }
    }
    
    public static class RateLimit {
        private int defaultReplenishRate = 100;
        private int defaultBurstCapacity = 200;
        private Duration keyResolverTimeout = Duration.ofMillis(500);
        
        // Getters and setters
        public int getDefaultReplenishRate() { return defaultReplenishRate; }
        public void setDefaultReplenishRate(int defaultReplenishRate) { this.defaultReplenishRate = defaultReplenishRate; }
        
        public int getDefaultBurstCapacity() { return defaultBurstCapacity; }
        public void setDefaultBurstCapacity(int defaultBurstCapacity) { this.defaultBurstCapacity = defaultBurstCapacity; }
        
        public Duration getKeyResolverTimeout() { return keyResolverTimeout; }
        public void setKeyResolverTimeout(Duration keyResolverTimeout) { this.keyResolverTimeout = keyResolverTimeout; }
    }
    
    public static class Circuit {
        private int failureRateThreshold = 50;
        private Duration waitDurationInOpenState = Duration.ofSeconds(60);
        private int slidingWindowSize = 10;
        private int minimumNumberOfCalls = 5;
        
        // Getters and setters
        public int getFailureRateThreshold() { return failureRateThreshold; }
        public void setFailureRateThreshold(int failureRateThreshold) { this.failureRateThreshold = failureRateThreshold; }
        
        public Duration getWaitDurationInOpenState() { return waitDurationInOpenState; }
        public void setWaitDurationInOpenState(Duration waitDurationInOpenState) { this.waitDurationInOpenState = waitDurationInOpenState; }
        
        public int getSlidingWindowSize() { return slidingWindowSize; }
        public void setSlidingWindowSize(int slidingWindowSize) { this.slidingWindowSize = slidingWindowSize; }
        
        public int getMinimumNumberOfCalls() { return minimumNumberOfCalls; }
        public void setMinimumNumberOfCalls(int minimumNumberOfCalls) { this.minimumNumberOfCalls = minimumNumberOfCalls; }
    }
    
    public static class Timeout {
        private Duration connectTimeout = Duration.ofSeconds(3);
        private Duration responseTimeout = Duration.ofSeconds(10);
        private Duration globalTimeout = Duration.ofSeconds(30);
        
        // Getters and setters
        public Duration getConnectTimeout() { return connectTimeout; }
        public void setConnectTimeout(Duration connectTimeout) { this.connectTimeout = connectTimeout; }
        
        public Duration getResponseTimeout() { return responseTimeout; }
        public void setResponseTimeout(Duration responseTimeout) { this.responseTimeout = responseTimeout; }
        
        public Duration getGlobalTimeout() { return globalTimeout; }
        public void setGlobalTimeout(Duration globalTimeout) { this.globalTimeout = globalTimeout; }
    }
}
