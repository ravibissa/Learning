# Networking Module - Load Balancer Lab

## 🎯 **Lab Objectives**

By completing this lab, you will:
- Implement various load balancing algorithms
- Configure health checks and failover
- Measure performance under different strategies
- Handle network failures gracefully
- Practice capacity planning for load balancers

## 📋 **Prerequisites**

- Completed Module 1 (Foundations)
- Docker and Docker Compose installed
- Basic understanding of HTTP protocols
- Java 21 and Spring Boot knowledge

---

## 🚀 **Exercise 1: Basic Load Balancer Implementation**

### **Objective**: Build a simple round-robin load balancer

#### **Step 1: Create Load Balancer Service**

```java
// Create: src/main/java/com/systemdesign/networking/LoadBalancerService.java
@Service
public class LoadBalancerService {
    
    private final List<ServiceInstance> instances = new ArrayList<>();
    private final AtomicInteger currentIndex = new AtomicInteger(0);
    private final RestTemplate restTemplate;
    
    public LoadBalancerService() {
        this.restTemplate = new RestTemplate();
        
        // Configure connection pooling
        HttpComponentsClientHttpRequestFactory factory = 
            new HttpComponentsClientHttpRequestFactory();
        factory.setConnectTimeout(3000);
        factory.setReadTimeout(5000);
        this.restTemplate.setRequestFactory(factory);
    }
    
    public void registerInstance(String id, String host, int port, int weight) {
        ServiceInstance instance = new ServiceInstance(id, host, port, weight);
        instances.add(instance);
        log.info("Registered service instance: {}", instance);
    }
    
    public ServiceInstance getNextInstance() {
        if (instances.isEmpty()) {
            throw new NoAvailableInstanceException("No service instances available");
        }
        
        // Round-robin selection
        int index = currentIndex.getAndUpdate(i -> (i + 1) % instances.size());
        return instances.get(index);
    }
    
    public <T> T executeRequest(String path, Class<T> responseType, Object... pathVars) {
        int maxRetries = 3;
        Exception lastException = null;
        
        for (int attempt = 0; attempt < maxRetries; attempt++) {
            try {
                ServiceInstance instance = getNextInstance();
                if (!instance.isHealthy()) {
                    continue; // Skip unhealthy instances
                }
                
                String url = STR."http://\{instance.getHost()}:\{instance.getPort()}\{path}";
                return restTemplate.getForObject(url, responseType, pathVars);
                
            } catch (Exception e) {
                lastException = e;
                log.warn("Request failed on attempt {}: {}", attempt + 1, e.getMessage());
                
                if (attempt < maxRetries - 1) {
                    try {
                        Thread.sleep(100 * (attempt + 1)); // Exponential backoff
                    } catch (InterruptedException ie) {
                        Thread.currentThread().interrupt();
                        break;
                    }
                }
            }
        }
        
        throw new ServiceUnavailableException("All instances failed", lastException);
    }
}
```

#### **Step 2: Implement Service Instance Model**

```java
public class ServiceInstance {
    private final String id;
    private final String host;
    private final int port;
    private final int weight;
    private volatile boolean healthy = true;
    private volatile Instant lastHealthCheck = Instant.now();
    
    public ServiceInstance(String id, String host, int port, int weight) {
        this.id = id;
        this.host = host;
        this.port = port;
        this.weight = weight;
    }
    
    // Getters and health check methods
    public boolean isHealthy() { return healthy; }
    public void setHealthy(boolean healthy) { this.healthy = healthy; }
    public String getHost() { return host; }
    public int getPort() { return port; }
    public int getWeight() { return weight; }
    public String getId() { return id; }
}
```

#### **Step 3: Test Your Implementation**

```bash
# Start 3 backend instances
docker run -d -p 8081:8080 --name backend1 nginx
docker run -d -p 8082:8080 --name backend2 nginx  
docker run -d -p 8083:8080 --name backend3 nginx

# Test load balancer
curl http://localhost:8080/api/test
# Should distribute requests across all 3 instances
```

### ✅ **Validation Criteria**
- [ ] Requests are distributed evenly across instances
- [ ] Failed instances are automatically skipped
- [ ] Load balancer handles instance failures gracefully
- [ ] Connection pooling is working correctly

---

## ⚖️ **Exercise 2: Weighted Load Balancing**

### **Objective**: Implement weighted round-robin algorithm

#### **Step 1: Enhance Load Balancer with Weights**

```java
@Service
public class WeightedLoadBalancerService {
    
    private final List<WeightedInstance> instances = new ArrayList<>();
    private int totalWeight = 0;
    
    public void registerInstance(String id, String host, int port, int weight) {
        WeightedInstance instance = new WeightedInstance(id, host, port, weight);
        instances.add(instance);
        totalWeight += weight;
        rebuildWeightedList();
    }
    
    public ServiceInstance getNextInstanceByWeight() {
        if (weightedInstances.isEmpty()) {
            throw new NoAvailableInstanceException("No healthy instances available");
        }
        
        int randomWeight = ThreadLocalRandom.current().nextInt(totalHealthyWeight);
        
        for (WeightedInstance instance : weightedInstances) {
            randomWeight -= instance.getWeight();
            if (randomWeight < 0) {
                return instance;
            }
        }
        
        // Fallback to first instance
        return weightedInstances.get(0);
    }
    
    private void rebuildWeightedList() {
        // Rebuild list of healthy instances with their weights
        weightedInstances.clear();
        totalHealthyWeight = 0;
        
        for (WeightedInstance instance : instances) {
            if (instance.isHealthy()) {
                weightedInstances.add(instance);
                totalHealthyWeight += instance.getWeight();
            }
        }
    }
}
```

#### **Step 2: Performance Testing**

```java
@Test
void testWeightedDistribution() {
    // Given
    loadBalancer.registerInstance("server1", "localhost", 8081, 1);
    loadBalancer.registerInstance("server2", "localhost", 8082, 3);
    loadBalancer.registerInstance("server3", "localhost", 8083, 6);
    
    // When - make 1000 requests
    Map<String, Integer> distribution = new HashMap<>();
    for (int i = 0; i < 1000; i++) {
        ServiceInstance instance = loadBalancer.getNextInstanceByWeight();
        distribution.merge(instance.getId(), 1, Integer::sum);
    }
    
    // Then - verify distribution matches weights (approximately)
    double server1Percentage = distribution.get("server1") / 1000.0;
    double server2Percentage = distribution.get("server2") / 1000.0;
    double server3Percentage = distribution.get("server3") / 1000.0;
    
    assertThat(server1Percentage).isBetween(0.08, 0.12); // ~10%
    assertThat(server2Percentage).isBetween(0.28, 0.32); // ~30%
    assertThat(server3Percentage).isBetween(0.58, 0.62); // ~60%
}
```

### ✅ **Validation Criteria**
- [ ] Higher weighted instances receive more traffic
- [ ] Distribution ratios match configured weights
- [ ] Zero-weight instances receive no traffic
- [ ] Algorithm handles weight changes dynamically

---

## 🏥 **Exercise 3: Health Check Implementation**

### **Objective**: Add automatic health checking and failover

#### **Step 1: Health Check Service**

```java
@Service
public class HealthCheckService {
    
    private final RestTemplate healthCheckTemplate;
    private final ScheduledExecutorService scheduler;
    private final LoadBalancerService loadBalancer;
    
    @PostConstruct
    public void startHealthChecks() {
        scheduler.scheduleWithFixedDelay(
            this::performHealthChecks, 
            10, 10, TimeUnit.SECONDS
        );
    }
    
    private void performHealthChecks() {
        List<ServiceInstance> instances = loadBalancer.getAllInstances();
        
        instances.parallelStream().forEach(instance -> {
            boolean isHealthy = checkInstanceHealth(instance);
            instance.setHealthy(isHealthy);
            
            if (!isHealthy) {
                log.warn("Instance {} is unhealthy", instance.getId());
                // Optionally notify monitoring system
                notifyInstanceDown(instance);
            }
        });
    }
    
    private boolean checkInstanceHealth(ServiceInstance instance) {
        try {
            String healthUrl = STR."http://\{instance.getHost()}:\{instance.getPort()}/actuator/health";
            
            ResponseEntity<HealthResponse> response = healthCheckTemplate.getForEntity(
                healthUrl, HealthResponse.class
            );
            
            return response.getStatusCode().is2xxSuccessful() && 
                   "UP".equals(response.getBody().getStatus());
                   
        } catch (Exception e) {
            log.debug("Health check failed for {}: {}", instance.getId(), e.getMessage());
            return false;
        }
    }
    
    private void notifyInstanceDown(ServiceInstance instance) {
        // Send alert to monitoring system
        // Could integrate with PagerDuty, Slack, etc.
        metricsService.recordInstanceDown(instance.getId());
    }
    
    public record HealthResponse(String status, Map<String, Object> details) {}
}
```

#### **Step 2: Circuit Breaker Integration**

```java
@Component
public class LoadBalancerCircuitBreaker {
    
    private final Map<String, CircuitBreakerState> instanceStates = new ConcurrentHashMap<>();
    
    public boolean isCircuitOpen(String instanceId) {
        CircuitBreakerState state = instanceStates.get(instanceId);
        return state != null && state.isOpen();
    }
    
    public void recordSuccess(String instanceId) {
        instanceStates.computeIfAbsent(instanceId, k -> new CircuitBreakerState())
                     .recordSuccess();
    }
    
    public void recordFailure(String instanceId) {
        instanceStates.computeIfAbsent(instanceId, k -> new CircuitBreakerState())
                     .recordFailure();
    }
    
    private static class CircuitBreakerState {
        private int consecutiveFailures = 0;
        private Instant lastFailureTime;
        private static final int FAILURE_THRESHOLD = 5;
        private static final Duration RECOVERY_TIMEOUT = Duration.ofMinutes(1);
        
        public synchronized void recordSuccess() {
            consecutiveFailures = 0;
            lastFailureTime = null;
        }
        
        public synchronized void recordFailure() {
            consecutiveFailures++;
            lastFailureTime = Instant.now();
        }
        
        public synchronized boolean isOpen() {
            if (consecutiveFailures < FAILURE_THRESHOLD) {
                return false;
            }
            
            if (lastFailureTime != null) {
                return Duration.between(lastFailureTime, Instant.now()).compareTo(RECOVERY_TIMEOUT) < 0;
            }
            
            return false;
        }
    }
}
```

### ✅ **Validation Criteria**
- [ ] Health checks run automatically every 10 seconds
- [ ] Unhealthy instances are removed from rotation
- [ ] Instances recover automatically when healthy
- [ ] Circuit breaker prevents cascade failures

---

## 📊 **Exercise 4: Load Balancer Metrics and Monitoring**

### **Objective**: Add comprehensive monitoring and alerting

#### **Step 1: Metrics Collection**

```java
@Component
public class LoadBalancerMetrics {
    
    private final Counter requestCounter;
    private final Timer responseTimer;
    private final Gauge healthyInstancesGauge;
    private final Counter failoverCounter;
    
    public LoadBalancerMetrics(MeterRegistry meterRegistry) {
        this.requestCounter = Counter.builder("loadbalancer.requests.total")
            .description("Total requests through load balancer")
            .register(meterRegistry);
            
        this.responseTimer = Timer.builder("loadbalancer.response.time")
            .description("Response time through load balancer")
            .register(meterRegistry);
            
        this.healthyInstancesGauge = Gauge.builder("loadbalancer.instances.healthy")
            .description("Number of healthy instances")
            .register(meterRegistry, this, LoadBalancerMetrics::getHealthyInstanceCount);
            
        this.failoverCounter = Counter.builder("loadbalancer.failovers.total")
            .description("Total number of failovers")
            .register(meterRegistry);
    }
    
    public void recordRequest(String instanceId, Duration responseTime, boolean success) {
        requestCounter.increment(
            Tags.of(
                "instance", instanceId,
                "status", success ? "success" : "failure"
            )
        );
        
        responseTimer.record(responseTime, Tags.of("instance", instanceId));
        
        if (!success) {
            failoverCounter.increment(Tags.of("instance", instanceId));
        }
    }
    
    private double getHealthyInstanceCount() {
        return loadBalancerService.getHealthyInstanceCount();
    }
}
```

#### **Step 2: Performance Dashboard**

Create Grafana dashboard queries:

```promql
# Request rate per instance
rate(loadbalancer_requests_total[5m])

# Average response time
rate(loadbalancer_response_time_sum[5m]) / rate(loadbalancer_response_time_count[5m])

# Error rate
rate(loadbalancer_requests_total{status="failure"}[5m]) / rate(loadbalancer_requests_total[5m])

# Healthy instances
loadbalancer_instances_healthy

# Failover rate
rate(loadbalancer_failovers_total[5m])
```

### ✅ **Validation Criteria**
- [ ] Metrics are collected for all requests
- [ ] Dashboard shows real-time load balancer status
- [ ] Alerts trigger when error rate exceeds threshold
- [ ] Historical performance data is available

---

## 🧪 **Exercise 5: Stress Testing and Capacity Planning**

### **Objective**: Determine load balancer capacity limits

#### **Step 1: Load Testing Script**

```java
@Component
public class LoadBalancerStressTest {
    
    @Autowired
    private LoadBalancerService loadBalancer;
    
    public StressTestResult performStressTest(int concurrentUsers, Duration testDuration) {
        ExecutorService executor = Executors.newFixedThreadPool(concurrentUsers);
        CountDownLatch startLatch = new CountDownLatch(1);
        CountDownLatch endLatch = new CountDownLatch(concurrentUsers);
        
        AtomicLong successCount = new AtomicLong(0);
        AtomicLong errorCount = new AtomicLong(0);
        List<Long> responseTimes = Collections.synchronizedList(new ArrayList<>());
        
        // Start all threads
        for (int i = 0; i < concurrentUsers; i++) {
            executor.submit(() -> {
                try {
                    startLatch.await(); // Wait for all threads to be ready
                    
                    long endTime = System.currentTimeMillis() + testDuration.toMillis();
                    
                    while (System.currentTimeMillis() < endTime) {
                        long start = System.currentTimeMillis();
                        
                        try {
                            loadBalancer.executeRequest("/api/test", String.class);
                            successCount.incrementAndGet();
                            
                        } catch (Exception e) {
                            errorCount.incrementAndGet();
                        }
                        
                        long responseTime = System.currentTimeMillis() - start;
                        responseTimes.add(responseTime);
                        
                        // Small delay to prevent overwhelming
                        Thread.sleep(10);
                    }
                    
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                } finally {
                    endLatch.countDown();
                }
            });
        }
        
        // Start the test
        startLatch.countDown();
        
        try {
            endLatch.await();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        
        executor.shutdown();
        
        return calculateResults(successCount.get(), errorCount.get(), responseTimes);
    }
    
    private StressTestResult calculateResults(long successCount, long errorCount, List<Long> responseTimes) {
        responseTimes.sort(Long::compareTo);
        
        long totalRequests = successCount + errorCount;
        double errorRate = totalRequests > 0 ? (double) errorCount / totalRequests : 0;
        
        long p50 = responseTimes.get((int) (responseTimes.size() * 0.5));
        long p95 = responseTimes.get((int) (responseTimes.size() * 0.95));
        long p99 = responseTimes.get((int) (responseTimes.size() * 0.99));
        
        return new StressTestResult(
            totalRequests,
            successCount,
            errorCount,
            errorRate,
            p50, p95, p99
        );
    }
    
    public record StressTestResult(
        long totalRequests,
        long successfulRequests,
        long errorRequests,
        double errorRate,
        long p50ResponseTime,
        long p95ResponseTime,
        long p99ResponseTime
    ) {}
}
```

#### **Step 2: Capacity Planning Analysis**

```java
@Service
public class CapacityPlanningService {
    
    public CapacityPlan calculateCapacity(CapacityRequirements requirements) {
        // Calculate requests per second
        double dailyRequests = requirements.expectedUsers() * requirements.avgRequestsPerUser();
        double avgRps = dailyRequests / (24 * 60 * 60);
        double peakRps = avgRps * requirements.peakMultiplier();
        
        // Calculate required instances
        double requestsPerInstance = 1000; // Based on stress testing
        int requiredInstances = (int) Math.ceil(peakRps / requestsPerInstance);
        
        // Add safety margin
        int recommendedInstances = (int) (requiredInstances * 1.5);
        
        // Calculate bandwidth requirements
        long avgRequestSize = 1024; // 1KB
        long avgResponseSize = 2048; // 2KB
        double bandwidthMbps = (peakRps * (avgRequestSize + avgResponseSize) * 8) / (1024 * 1024);
        
        return new CapacityPlan(
            avgRps,
            peakRps,
            requiredInstances,
            recommendedInstances,
            bandwidthMbps
        );
    }
    
    public record CapacityRequirements(
        int expectedUsers,
        double avgRequestsPerUser,
        double peakMultiplier
    ) {}
    
    public record CapacityPlan(
        double averageRps,
        double peakRps,
        int minimumInstances,
        int recommendedInstances,
        double requiredBandwidthMbps
    ) {}
}
```

### ✅ **Validation Criteria**
- [ ] Load balancer handles expected concurrent load
- [ ] Response times remain acceptable under stress
- [ ] Error rate stays below 1% during normal operation
- [ ] Capacity plan accounts for growth and peak traffic

---

## 🎯 **Exercise 6: Advanced Load Balancing Algorithms**

### **Objective**: Implement least connections and consistent hashing

#### **Step 1: Least Connections Algorithm**

```java
@Service
public class LeastConnectionsLoadBalancer {
    
    private final Map<String, AtomicInteger> activeConnections = new ConcurrentHashMap<>();
    private final List<ServiceInstance> instances = new ArrayList<>();
    
    public ServiceInstance getNextInstance() {
        return instances.stream()
            .filter(ServiceInstance::isHealthy)
            .min(Comparator.comparingInt(instance -> 
                activeConnections.getOrDefault(instance.getId(), new AtomicInteger(0)).get()))
            .orElseThrow(() -> new NoAvailableInstanceException("No healthy instances"));
    }
    
    public void incrementConnections(String instanceId) {
        activeConnections.computeIfAbsent(instanceId, k -> new AtomicInteger(0))
                         .incrementAndGet();
    }
    
    public void decrementConnections(String instanceId) {
        AtomicInteger connections = activeConnections.get(instanceId);
        if (connections != null) {
            connections.decrementAndGet();
        }
    }
}
```

#### **Step 2: Consistent Hashing for Sticky Sessions**

```java
@Service
public class ConsistentHashLoadBalancer {
    
    private final SortedMap<Long, ServiceInstance> ring = new TreeMap<>();
    private final int virtualNodes = 150;
    
    public void addInstance(ServiceInstance instance) {
        for (int i = 0; i < virtualNodes; i++) {
            String virtualKey = instance.getId() + ":" + i;
            long hash = hashFunction(virtualKey);
            ring.put(hash, instance);
        }
    }
    
    public void removeInstance(ServiceInstance instance) {
        for (int i = 0; i < virtualNodes; i++) {
            String virtualKey = instance.getId() + ":" + i;
            long hash = hashFunction(virtualKey);
            ring.remove(hash);
        }
    }
    
    public ServiceInstance getInstance(String key) {
        if (ring.isEmpty()) {
            throw new NoAvailableInstanceException("No instances in hash ring");
        }
        
        long hash = hashFunction(key);
        
        // Find the first instance clockwise from the hash
        SortedMap<Long, ServiceInstance> tailMap = ring.tailMap(hash);
        Long instanceHash = tailMap.isEmpty() ? ring.firstKey() : tailMap.firstKey();
        
        ServiceInstance instance = ring.get(instanceHash);
        
        // Check if instance is healthy, if not, try next one
        if (!instance.isHealthy()) {
            return getNextHealthyInstance(instanceHash);
        }
        
        return instance;
    }
    
    private ServiceInstance getNextHealthyInstance(Long startHash) {
        SortedMap<Long, ServiceInstance> tailMap = ring.tailMap(startHash + 1);
        
        // Try instances clockwise
        for (ServiceInstance instance : tailMap.values()) {
            if (instance.isHealthy()) {
                return instance;
            }
        }
        
        // Wrap around to beginning
        for (ServiceInstance instance : ring.values()) {
            if (instance.isHealthy()) {
                return instance;
            }
        }
        
        throw new NoAvailableInstanceException("No healthy instances in hash ring");
    }
    
    private long hashFunction(String key) {
        // Use consistent hash function (e.g., SHA-1)
        return key.hashCode() & 0x7fffffffL; // Ensure positive value
    }
}
```

### ✅ **Validation Criteria**
- [ ] Least connections distributes load based on active connections
- [ ] Consistent hashing maintains session affinity
- [ ] Hash ring rebalances properly when instances change
- [ ] All algorithms handle instance failures gracefully

---

## 📈 **Lab Completion Summary**

### **What You've Built**
1. **Round-robin load balancer** with basic failover
2. **Weighted load balancing** for different instance capacities
3. **Health check system** with automatic recovery
4. **Comprehensive monitoring** with metrics and alerts
5. **Stress testing framework** for capacity planning
6. **Advanced algorithms** (least connections, consistent hashing)

### **Key Learnings**
- Load balancing strategies and trade-offs
- Health check patterns and failover mechanisms
- Performance monitoring and capacity planning
- Advanced algorithms for specific use cases

### **Next Steps**
1. **Deploy to production** using the provided configurations
2. **Integrate with service discovery** (Consul, Eureka)
3. **Add SSL termination** and security features
4. **Implement geographic load balancing**
5. **Move to Module 3: Storage Systems**

**🎉 Congratulations! You've built a production-ready load balancing system with comprehensive monitoring and multiple algorithms.**
