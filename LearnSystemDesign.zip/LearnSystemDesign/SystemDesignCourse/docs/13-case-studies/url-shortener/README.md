# Case Study: URL Shortener (like bit.ly)

## 🎯 Problem Statement

Design a URL shortening service like bit.ly that can:
- Shorten long URLs to compact aliases
- Redirect short URLs to original URLs
- Handle 100M URLs shortened per day
- Provide analytics on click tracking
- Support custom aliases
- Have 99.9% availability

## 📋 Requirements

### Functional Requirements
- ✅ URL shortening: Convert long URL to short URL
- ✅ URL redirection: Redirect short URL to original URL  
- ✅ Custom aliases: Allow users to choose custom short URLs
- ✅ Analytics: Track clicks, locations, devices, referrers
- ✅ Expiration: Support URL expiration dates
- ✅ User accounts: Allow users to manage their URLs

### Non-Functional Requirements
- ✅ **Scale**: 100M URLs shortened per day, 10:1 read/write ratio
- ✅ **Latency**: < 100ms for redirection, < 200ms for shortening
- ✅ **Availability**: 99.9% uptime
- ✅ **Durability**: URLs should not be lost
- ✅ **Security**: Prevent malicious URLs, rate limiting

## 🧮 Capacity Estimation

### Traffic Estimation
```
URLs shortened per day: 100M
Read:Write ratio: 10:1

Write requests:
- 100M URLs / day = 1,157 writes/second
- Peak (3x average): 3,472 writes/second

Read requests:
- 1B redirections / day = 11,574 reads/second
- Peak (3x average): 34,722 reads/second

Total QPS: 35K+ at peak
```

### Storage Estimation
```
Average URL length: 2KB (original + metadata)
URLs per day: 100M
Daily storage: 100M × 2KB = 200GB
5-year storage: 200GB × 365 × 5 = 365TB

With replication (3x): ~1PB total storage
```

### Bandwidth Estimation
```
Write bandwidth: 3,472 × 2KB = 6.9MB/s
Read bandwidth: 34,722 × 2KB = 69.4MB/s (cache misses)
Total: ~76MB/s peak bandwidth
```

## 🏗️ High-Level Architecture

```mermaid
graph TB
    User[User] --> CDN[CDN/CloudFlare]
    CDN --> LB[Load Balancer]
    
    LB --> AS1[App Server 1]
    LB --> AS2[App Server 2]
    LB --> ASN[App Server N]
    
    AS1 --> Cache[Redis Cache]
    AS2 --> Cache
    ASN --> Cache
    
    AS1 --> DB[(URL Database<br/>PostgreSQL)]
    AS2 --> DB
    ASN --> DB
    
    AS1 --> Analytics[(Analytics DB<br/>ClickHouse)]
    AS2 --> Analytics
    ASN --> Analytics
    
    DB --> Backup[(Backup Storage<br/>S3)]
    
    subgraph "Monitoring"
        Metrics[Prometheus]
        Logs[ELK Stack]
        Alerts[AlertManager]
    end
    
    AS1 --> Metrics
    Cache --> Metrics
    DB --> Metrics
```

## 🗄️ Database Design

### URL Table (PostgreSQL)
```sql
CREATE TABLE urls (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    short_code VARCHAR(7) UNIQUE NOT NULL,
    long_url TEXT NOT NULL,
    user_id UUID REFERENCES users(id),
    created_at TIMESTAMP DEFAULT NOW(),
    expires_at TIMESTAMP,
    is_active BOOLEAN DEFAULT true,
    click_count BIGINT DEFAULT 0
);

CREATE INDEX idx_short_code ON urls(short_code);
CREATE INDEX idx_user_id ON urls(user_id);
CREATE INDEX idx_created_at ON urls(created_at);
```

### Analytics Table (ClickHouse)
```sql
CREATE TABLE clicks (
    id UUID,
    short_code String,
    clicked_at DateTime,
    ip_address String,
    user_agent String,
    referrer String,
    country String,
    city String
) ENGINE = MergeTree()
ORDER BY clicked_at
PARTITION BY toYYYYMM(clicked_at);
```

## 🔧 Core Algorithm: Base62 Encoding

### Java 21 Implementation
```java
@Component
public class Base62Encoder {
    
    private static final String ALPHABET = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    private static final int BASE = ALPHABET.length(); // 62
    
    /**
     * Encode number to Base62 string
     */
    public String encode(long number) {
        if (number == 0) return "a";
        
        StringBuilder encoded = new StringBuilder();
        
        while (number > 0) {
            int remainder = (int) (number % BASE);
            encoded.append(ALPHABET.charAt(remainder));
            number = number / BASE;
        }
        
        return encoded.reverse().toString();
    }
    
    /**
     * Decode Base62 string to number
     */
    public long decode(String encoded) {
        long decoded = 0;
        long multiplier = 1;
        
        for (int i = encoded.length() - 1; i >= 0; i--) {
            char character = encoded.charAt(i);
            int index = ALPHABET.indexOf(character);
            
            if (index == -1) {
                throw new IllegalArgumentException(STR."Invalid character in encoded string: \{character}");
            }
            
            decoded += index * multiplier;
            multiplier *= BASE;
        }
        
        return decoded;
    }
    
    /**
     * Generate short code from counter
     */
    public String generateShortCode(long counter) {
        // Add randomness to prevent sequential guessing
        long encoded = counter * 1000000 + System.currentTimeMillis() % 1000000;
        return encode(encoded);
    }
}
```

## 🚀 URL Shortener Service

```java
@Service
@Transactional
public class UrlShortenerService {
    
    private final UrlRepository urlRepository;
    private final Base62Encoder encoder;
    private final RedisTemplate<String, String> redisTemplate;
    private final CounterService counterService;
    private final AnalyticsService analyticsService;
    
    private static final String CACHE_PREFIX = "url:";
    private static final Duration CACHE_TTL = Duration.ofHours(24);
    
    public UrlShortenerService(UrlRepository urlRepository,
                              Base62Encoder encoder,
                              RedisTemplate<String, String> redisTemplate,
                              CounterService counterService,
                              AnalyticsService analyticsService) {
        this.urlRepository = urlRepository;
        this.encoder = encoder;
        this.redisTemplate = redisTemplate;
        this.counterService = counterService;
        this.analyticsService = analyticsService;
    }
    
    /**
     * Shorten a URL
     */
    public ShortenUrlResponse shortenUrl(ShortenUrlRequest request) {
        // Validate URL
        if (!isValidUrl(request.longUrl())) {
            throw new InvalidUrlException("Invalid URL format");
        }
        
        // Check for existing URL to avoid duplicates
        Optional<Url> existing = urlRepository.findByLongUrlAndUserId(
            request.longUrl(), request.userId()
        );
        
        if (existing.isPresent() && existing.get().isActive()) {
            return new ShortenUrlResponse(
                existing.get().getShortCode(),
                existing.get().getLongUrl(),
                existing.get().getCreatedAt()
            );
        }
        
        // Generate short code
        String shortCode = request.customAlias() != null ? 
            validateCustomAlias(request.customAlias()) :
            generateUniqueShortCode();
        
        // Create URL entity
        Url url = Url.builder()
            .shortCode(shortCode)
            .longUrl(request.longUrl())
            .userId(request.userId())
            .expiresAt(request.expiresAt())
            .build();
        
        // Save to database
        Url savedUrl = urlRepository.save(url);
        
        // Cache the mapping
        cacheUrlMapping(shortCode, request.longUrl());
        
        return new ShortenUrlResponse(
            savedUrl.getShortCode(),
            savedUrl.getLongUrl(),
            savedUrl.getCreatedAt()
        );
    }
    
    /**
     * Redirect short URL to original URL
     */
    public RedirectResponse redirect(String shortCode, HttpServletRequest request) {
        // Try cache first
        String cachedUrl = getCachedUrl(shortCode);
        if (cachedUrl != null) {
            recordClick(shortCode, request);
            return new RedirectResponse(cachedUrl, true);
        }
        
        // Fallback to database
        Url url = urlRepository.findByShortCodeAndIsActive(shortCode, true)
            .orElseThrow(() -> new UrlNotFoundException(STR."Short code not found: \{shortCode}"));
        
        // Check expiration
        if (url.getExpiresAt() != null && url.getExpiresAt().isBefore(Instant.now())) {
            throw new UrlExpiredException(STR."URL has expired: \{shortCode}");
        }
        
        // Cache for future requests
        cacheUrlMapping(shortCode, url.getLongUrl());
        
        // Record analytics
        recordClick(shortCode, request);
        
        return new RedirectResponse(url.getLongUrl(), false);
    }
    
    private String generateUniqueShortCode() {
        int maxAttempts = 5;
        
        for (int attempt = 0; attempt < maxAttempts; attempt++) {
            long counter = counterService.getNextValue();
            String shortCode = encoder.generateShortCode(counter);
            
            if (!urlRepository.existsByShortCode(shortCode)) {
                return shortCode;
            }
        }
        
        throw new ShortCodeGenerationException("Unable to generate unique short code");
    }
    
    private String validateCustomAlias(String customAlias) {
        if (customAlias.length() < 3 || customAlias.length() > 20) {
            throw new InvalidAliasException("Custom alias must be 3-20 characters");
        }
        
        if (!customAlias.matches("^[a-zA-Z0-9_-]+$")) {
            throw new InvalidAliasException("Custom alias can only contain letters, numbers, underscore, and hyphen");
        }
        
        if (urlRepository.existsByShortCode(customAlias)) {
            throw new AliasAlreadyExistsException(STR."Custom alias already exists: \{customAlias}");
        }
        
        return customAlias;
    }
    
    private void cacheUrlMapping(String shortCode, String longUrl) {
        String cacheKey = CACHE_PREFIX + shortCode;
        redisTemplate.opsForValue().set(cacheKey, longUrl, CACHE_TTL);
    }
    
    private String getCachedUrl(String shortCode) {
        String cacheKey = CACHE_PREFIX + shortCode;
        return redisTemplate.opsForValue().get(cacheKey);
    }
    
    private void recordClick(String shortCode, HttpServletRequest request) {
        // Async analytics recording
        CompletableFuture.runAsync(() -> {
            ClickEvent event = ClickEvent.builder()
                .shortCode(shortCode)
                .ipAddress(getClientIpAddress(request))
                .userAgent(request.getHeader("User-Agent"))
                .referrer(request.getHeader("Referer"))
                .clickedAt(Instant.now())
                .build();
                
            analyticsService.recordClick(event);
        });
        
        // Update click counter
        urlRepository.incrementClickCount(shortCode);
    }
    
    private boolean isValidUrl(String url) {
        try {
            new URL(url);
            return url.startsWith("http://") || url.startsWith("https://");
        } catch (MalformedURLException e) {
            return false;
        }
    }
    
    private String getClientIpAddress(HttpServletRequest request) {
        String xForwardedFor = request.getHeader("X-Forwarded-For");
        if (xForwardedFor != null && !xForwardedFor.isEmpty()) {
            return xForwardedFor.split(",")[0].trim();
        }
        
        String xRealIp = request.getHeader("X-Real-IP");
        if (xRealIp != null && !xRealIp.isEmpty()) {
            return xRealIp;
        }
        
        return request.getRemoteAddr();
    }
}
```

## 🎯 Interview Questions & Answers

### Basic Questions

**Q1: How would you generate short URLs?**

**A:** Multiple approaches:
1. **Counter-based**: Use auto-incrementing counter + Base62 encoding
2. **Hash-based**: MD5/SHA1 hash + truncate (collision handling needed)
3. **Random**: Generate random strings (check uniqueness)

Base62 encoding is preferred because:
- Predictable length (7 chars = 62^7 = 3.5 trillion URLs)
- URL-safe characters only
- Easy to implement and scale

**Q2: How do you handle scaling to 100M URLs per day?**

**A:** 
- **Database sharding**: Partition by short_code hash
- **Caching**: Redis for hot URLs (80/20 rule)
- **CDN**: Geographic distribution for redirects
- **Load balancing**: Distribute requests across app servers
- **Read replicas**: Separate read/write database loads

**Q3: What if the database goes down?**

**A:**
- **Cache**: Redis can serve most redirects
- **Replication**: Master-slave database setup
- **Backup**: Regular database backups to S3
- **Graceful degradation**: Return cached results only

### Advanced Questions

**Q4: How would you implement analytics?**

**A:** Use separate analytics pipeline:
```java
@Component
public class AnalyticsService {
    
    @Async
    public void recordClick(ClickEvent event) {
        // 1. Send to Kafka for real-time processing
        kafkaTemplate.send("click-events", event);
        
        // 2. Batch insert to ClickHouse for analytics
        clickHouseWriter.write(event);
        
        // 3. Update real-time counters in Redis
        redisTemplate.opsForHyperLogLog()
            .add("unique_clicks:" + event.shortCode(), event.ipAddress());
    }
}
```

**Q5: How do you prevent malicious URLs?**

**A:**
- **Blacklist checking**: Against known malicious domains
- **Content scanning**: Basic URL content analysis
- **Rate limiting**: Prevent abuse from single IP/user
- **User reporting**: Community-driven moderation
- **ML models**: Train on malicious URL patterns

## 🧪 Testing Strategy

### Unit Tests
```java
@ExtendWith(MockitoExtension.class)
class UrlShortenerServiceTest {
    
    @Mock
    private UrlRepository urlRepository;
    
    @Mock
    private Base62Encoder encoder;
    
    @InjectMocks
    private UrlShortenerService service;
    
    @Test
    void shouldShortenUrl() {
        // Given
        ShortenUrlRequest request = new ShortenUrlRequest(
            "https://example.com/very-long-url",
            null, null, null
        );
        
        when(encoder.generateShortCode(anyLong())).thenReturn("abc123");
        when(urlRepository.save(any())).thenReturn(createMockUrl());
        
        // When
        ShortenUrlResponse response = service.shortenUrl(request);
        
        // Then
        assertThat(response.shortCode()).isEqualTo("abc123");
        assertThat(response.longUrl()).isEqualTo("https://example.com/very-long-url");
    }
}
```

### Load Tests
```java
@Test
void loadTestRedirects() {
    int concurrentUsers = 1000;
    int requestsPerUser = 100;
    
    List<CompletableFuture<Void>> futures = IntStream.range(0, concurrentUsers)
        .mapToObj(i -> CompletableFuture.runAsync(() -> {
            for (int j = 0; j < requestsPerUser; j++) {
                String shortCode = generateRandomShortCode();
                testRedirect(shortCode);
            }
        }))
        .toList();
    
    CompletableFuture.allOf(futures.toArray(new CompletableFuture[0])).join();
}
```

## 🎯 Key Takeaways

1. **Base62 encoding** is ideal for short URL generation
2. **Caching is critical** for read-heavy workloads (10:1 ratio)
3. **Database sharding** needed for write scalability
4. **Separate analytics pipeline** to avoid impacting core functionality
5. **Security considerations** are important for URL shorteners
6. **Monitoring and alerting** essential for high-availability service

## 📚 Next Steps

- Implement custom domain support
- Add URL preview functionality
- Build real-time analytics dashboard
- Add geographic load balancing
- Implement A/B testing for click tracking

---

**Ready for the next case study?** Check out [Rate Limiter](../rate-limiter/) to learn distributed rate limiting patterns.
