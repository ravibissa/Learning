# Storage Module - Object Storage Lab

## 🎯 **Lab Objectives**

By completing this lab, you will:
- Implement a scalable object storage system
- Design file versioning and deduplication strategies
- Handle large file uploads with chunking
- Implement backup and disaster recovery
- Practice capacity planning for storage systems

## 📋 **Prerequisites**

- Completed Module 1 (Foundations) and Module 2 (Networking)
- AWS S3 or MinIO access
- Docker and Docker Compose installed
- Java 21 and Spring Boot knowledge

---

## 🚀 **Exercise 1: Basic Object Storage Implementation**

### **Objective**: Build a simple object storage service

#### **Step 1: Create Object Storage Service**

```java
// Create: src/main/java/com/systemdesign/storage/ObjectStorageService.java
@Service
public class ObjectStorageService {
    
    @Autowired
    private S3Client s3Client;
    
    @Autowired
    private ObjectMetadataRepository metadataRepository;
    
    public ObjectUploadResult uploadObject(String bucketName, String key, 
                                         InputStream data, ObjectMetadata metadata) {
        try {
            // Validate inputs
            validateUploadRequest(bucketName, key, metadata);
            
            // Calculate content hash for integrity
            byte[] dataBytes = data.readAllBytes();
            String contentHash = calculateSHA256(dataBytes);
            
            // Upload to S3
            PutObjectRequest putRequest = PutObjectRequest.builder()
                .bucket(bucketName)
                .key(key)
                .contentType(metadata.getContentType())
                .contentLength((long) dataBytes.length)
                .serverSideEncryption(ServerSideEncryption.AES256)
                .build();
            
            PutObjectResponse response = s3Client.putObject(putRequest, 
                RequestBody.fromBytes(dataBytes));
            
            // Store metadata
            ObjectMetadata storedMetadata = ObjectMetadata.builder()
                .bucketName(bucketName)
                .objectKey(key)
                .contentType(metadata.getContentType())
                .size((long) dataBytes.length)
                .contentHash(contentHash)
                .eTag(response.eTag())
                .uploadTime(Instant.now())
                .build();
            
            metadataRepository.save(storedMetadata);
            
            return ObjectUploadResult.builder()
                .bucketName(bucketName)
                .objectKey(key)
                .eTag(response.eTag())
                .contentHash(contentHash)
                .size((long) dataBytes.length)
                .build();
            
        } catch (Exception e) {
            throw new ObjectStorageException("Failed to upload object", e);
        }
    }
    
    public ObjectDownloadResult downloadObject(String bucketName, String key) {
        try {
            GetObjectRequest getRequest = GetObjectRequest.builder()
                .bucket(bucketName)
                .key(key)
                .build();
            
            ResponseInputStream<GetObjectResponse> response = s3Client.getObject(getRequest);
            
            byte[] data = response.readAllBytes();
            
            return ObjectDownloadResult.builder()
                .bucketName(bucketName)
                .objectKey(key)
                .data(data)
                .contentType(response.response().contentType())
                .contentLength(response.response().contentLength())
                .eTag(response.response().eTag())
                .lastModified(response.response().lastModified())
                .build();
            
        } catch (Exception e) {
            throw new ObjectStorageException("Failed to download object", e);
        }
    }
    
    public void deleteObject(String bucketName, String key) {
        try {
            DeleteObjectRequest deleteRequest = DeleteObjectRequest.builder()
                .bucket(bucketName)
                .key(key)
                .build();
            
            s3Client.deleteObject(deleteRequest);
            
            // Remove metadata
            metadataRepository.deleteByBucketNameAndObjectKey(bucketName, key);
            
        } catch (Exception e) {
            throw new ObjectStorageException("Failed to delete object", e);
        }
    }
    
    private String calculateSHA256(byte[] data) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(data);
            return Base64.getEncoder().encodeToString(hash);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-256 not available", e);
        }
    }
    
    private void validateUploadRequest(String bucketName, String key, ObjectMetadata metadata) {
        if (bucketName == null || bucketName.trim().isEmpty()) {
            throw new IllegalArgumentException("Bucket name cannot be empty");
        }
        if (key == null || key.trim().isEmpty()) {
            throw new IllegalArgumentException("Object key cannot be empty");
        }
        if (metadata == null) {
            throw new IllegalArgumentException("Metadata cannot be null");
        }
    }
}
```

#### **Step 2: Create REST Controller**

```java
@RestController
@RequestMapping("/api/v1/storage")
public class ObjectStorageController {
    
    @Autowired
    private ObjectStorageService storageService;
    
    @PostMapping("/objects")
    public ResponseEntity<ObjectUploadResult> uploadObject(
            @RequestParam("file") MultipartFile file,
            @RequestParam("bucket") String bucketName,
            @RequestParam("key") String key) {
        
        try {
            ObjectMetadata metadata = ObjectMetadata.builder()
                .contentType(file.getContentType())
                .originalFileName(file.getOriginalFilename())
                .build();
            
            ObjectUploadResult result = storageService.uploadObject(
                bucketName, key, file.getInputStream(), metadata);
            
            return ResponseEntity.ok(result);
            
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(null);
        }
    }
    
    @GetMapping("/objects")
    public ResponseEntity<byte[]> downloadObject(
            @RequestParam("bucket") String bucketName,
            @RequestParam("key") String key) {
        
        try {
            ObjectDownloadResult result = storageService.downloadObject(bucketName, key);
            
            return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(result.getContentType()))
                .contentLength(result.getContentLength())
                .header("ETag", result.getETag())
                .body(result.getData());
            
        } catch (ObjectNotFoundException e) {
            return ResponseEntity.notFound().build();
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
    
    @DeleteMapping("/objects")
    public ResponseEntity<Void> deleteObject(
            @RequestParam("bucket") String bucketName,
            @RequestParam("key") String key) {
        
        try {
            storageService.deleteObject(bucketName, key);
            return ResponseEntity.noContent().build();
            
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
}
```

#### **Step 3: Test Your Implementation**

```bash
# Upload a file
curl -X POST \
  http://localhost:8080/api/v1/storage/objects \
  -F "file=@test-file.txt" \
  -F "bucket=test-bucket" \
  -F "key=test-files/test-file.txt"

# Download the file
curl -X GET \
  "http://localhost:8080/api/v1/storage/objects?bucket=test-bucket&key=test-files/test-file.txt" \
  -o downloaded-file.txt

# Delete the file
curl -X DELETE \
  "http://localhost:8080/api/v1/storage/objects?bucket=test-bucket&key=test-files/test-file.txt"
```

### ✅ **Validation Criteria**
- [ ] Files can be uploaded and downloaded successfully
- [ ] Content integrity is verified with SHA-256 hashes
- [ ] Metadata is stored and retrieved correctly
- [ ] Error handling works for invalid requests

---

## 📦 **Exercise 2: Large File Upload with Chunking**

### **Objective**: Implement multipart upload for large files

#### **Step 1: Multipart Upload Service**

```java
@Service
public class MultipartUploadService {
    
    @Autowired
    private S3Client s3Client;
    
    @Autowired
    private UploadSessionRepository sessionRepository;
    
    private final Map<String, UploadSession> activeSessions = new ConcurrentHashMap<>();
    
    public String initiateMultipartUpload(String bucketName, String key, 
                                        MultipartUploadRequest request) {
        try {
            // Create S3 multipart upload
            CreateMultipartUploadRequest createRequest = CreateMultipartUploadRequest.builder()
                .bucket(bucketName)
                .key(key)
                .contentType(request.getContentType())
                .serverSideEncryption(ServerSideEncryption.AES256)
                .build();
            
            CreateMultipartUploadResponse response = s3Client.createMultipartUpload(createRequest);
            
            // Create upload session
            String sessionId = UUID.randomUUID().toString();
            UploadSession session = UploadSession.builder()
                .sessionId(sessionId)
                .bucketName(bucketName)
                .objectKey(key)
                .s3UploadId(response.uploadId())
                .totalSize(request.getTotalSize())
                .chunkSize(request.getChunkSize())
                .startTime(Instant.now())
                .status(UploadStatus.IN_PROGRESS)
                .build();
            
            activeSessions.put(sessionId, session);
            sessionRepository.save(session);
            
            return sessionId;
            
        } catch (Exception e) {
            throw new MultipartUploadException("Failed to initiate multipart upload", e);
        }
    }
    
    public PartUploadResult uploadPart(String sessionId, int partNumber, 
                                     InputStream data, long partSize) {
        UploadSession session = activeSessions.get(sessionId);
        if (session == null) {
            session = sessionRepository.findBySessionId(sessionId)
                .orElseThrow(() -> new IllegalArgumentException("Invalid session ID"));
            activeSessions.put(sessionId, session);
        }
        
        try {
            UploadPartRequest uploadRequest = UploadPartRequest.builder()
                .bucket(session.getBucketName())
                .key(session.getObjectKey())
                .uploadId(session.getS3UploadId())
                .partNumber(partNumber)
                .contentLength(partSize)
                .build();
            
            UploadPartResponse response = s3Client.uploadPart(uploadRequest, 
                RequestBody.fromInputStream(data, partSize));
            
            // Record completed part
            CompletedPart completedPart = CompletedPart.builder()
                .partNumber(partNumber)
                .eTag(response.eTag())
                .build();
            
            session.addCompletedPart(completedPart);
            sessionRepository.save(session);
            
            return PartUploadResult.builder()
                .partNumber(partNumber)
                .eTag(response.eTag())
                .size(partSize)
                .build();
            
        } catch (Exception e) {
            throw new PartUploadException("Failed to upload part", e);
        }
    }
    
    public ObjectUploadResult completeMultipartUpload(String sessionId) {
        UploadSession session = activeSessions.remove(sessionId);
        if (session == null) {
            session = sessionRepository.findBySessionId(sessionId)
                .orElseThrow(() -> new IllegalArgumentException("Invalid session ID"));
        }
        
        try {
            // Complete S3 multipart upload
            CompleteMultipartUploadRequest completeRequest = CompleteMultipartUploadRequest.builder()
                .bucket(session.getBucketName())
                .key(session.getObjectKey())
                .uploadId(session.getS3UploadId())
                .multipartUpload(CompletedMultipartUpload.builder()
                    .parts(session.getCompletedParts())
                    .build())
                .build();
            
            CompleteMultipartUploadResponse response = s3Client.completeMultipartUpload(completeRequest);
            
            // Update session status
            session.setStatus(UploadStatus.COMPLETED);
            session.setCompletionTime(Instant.now());
            session.setFinalETag(response.eTag());
            sessionRepository.save(session);
            
            return ObjectUploadResult.builder()
                .bucketName(session.getBucketName())
                .objectKey(session.getObjectKey())
                .eTag(response.eTag())
                .size(session.getTotalSize())
                .uploadSessionId(sessionId)
                .build();
            
        } catch (Exception e) {
            // Abort the multipart upload on failure
            abortMultipartUpload(sessionId);
            throw new MultipartUploadException("Failed to complete multipart upload", e);
        }
    }
    
    public void abortMultipartUpload(String sessionId) {
        UploadSession session = activeSessions.remove(sessionId);
        if (session == null) {
            session = sessionRepository.findBySessionId(sessionId)
                .orElse(null);
        }
        
        if (session != null) {
            try {
                AbortMultipartUploadRequest abortRequest = AbortMultipartUploadRequest.builder()
                    .bucket(session.getBucketName())
                    .key(session.getObjectKey())
                    .uploadId(session.getS3UploadId())
                    .build();
                
                s3Client.abortMultipartUpload(abortRequest);
                
                session.setStatus(UploadStatus.ABORTED);
                sessionRepository.save(session);
                
            } catch (Exception e) {
                log.error("Failed to abort multipart upload", e);
            }
        }
    }
    
    public List<UploadSession> listInProgressUploads() {
        return sessionRepository.findByStatus(UploadStatus.IN_PROGRESS);
    }
    
    @Scheduled(fixedRate = 3600000) // Every hour
    public void cleanupStaleUploads() {
        Instant cutoff = Instant.now().minus(Duration.ofHours(24));
        List<UploadSession> staleUploads = sessionRepository
            .findByStatusAndStartTimeBefore(UploadStatus.IN_PROGRESS, cutoff);
        
        for (UploadSession session : staleUploads) {
            try {
                abortMultipartUpload(session.getSessionId());
                log.info("Cleaned up stale upload: {}", session.getSessionId());
            } catch (Exception e) {
                log.error("Failed to cleanup stale upload: {}", session.getSessionId(), e);
            }
        }
    }
}
```

#### **Step 2: Resumable Upload Controller**

```java
@RestController
@RequestMapping("/api/v1/storage/multipart")
public class MultipartUploadController {
    
    @Autowired
    private MultipartUploadService multipartService;
    
    @PostMapping("/init")
    public ResponseEntity<InitiateUploadResponse> initiateUpload(
            @RequestBody InitiateUploadRequest request) {
        
        try {
            String sessionId = multipartService.initiateMultipartUpload(
                request.getBucketName(),
                request.getObjectKey(),
                MultipartUploadRequest.builder()
                    .contentType(request.getContentType())
                    .totalSize(request.getTotalSize())
                    .chunkSize(request.getChunkSize())
                    .build()
            );
            
            return ResponseEntity.ok(InitiateUploadResponse.builder()
                .sessionId(sessionId)
                .chunkSize(request.getChunkSize())
                .build());
            
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
    
    @PostMapping("/{sessionId}/parts/{partNumber}")
    public ResponseEntity<PartUploadResponse> uploadPart(
            @PathVariable String sessionId,
            @PathVariable int partNumber,
            @RequestParam("chunk") MultipartFile chunk) {
        
        try {
            PartUploadResult result = multipartService.uploadPart(
                sessionId, partNumber, chunk.getInputStream(), chunk.getSize());
            
            return ResponseEntity.ok(PartUploadResponse.builder()
                .partNumber(result.getPartNumber())
                .eTag(result.getETag())
                .size(result.getSize())
                .build());
            
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
    
    @PostMapping("/{sessionId}/complete")
    public ResponseEntity<CompleteUploadResponse> completeUpload(
            @PathVariable String sessionId) {
        
        try {
            ObjectUploadResult result = multipartService.completeMultipartUpload(sessionId);
            
            return ResponseEntity.ok(CompleteUploadResponse.builder()
                .bucketName(result.getBucketName())
                .objectKey(result.getObjectKey())
                .eTag(result.getETag())
                .size(result.getSize())
                .build());
            
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
    
    @DeleteMapping("/{sessionId}")
    public ResponseEntity<Void> abortUpload(@PathVariable String sessionId) {
        try {
            multipartService.abortMultipartUpload(sessionId);
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
    
    @GetMapping("/sessions")
    public ResponseEntity<List<UploadSessionInfo>> listInProgressUploads() {
        try {
            List<UploadSession> sessions = multipartService.listInProgressUploads();
            
            List<UploadSessionInfo> sessionInfos = sessions.stream()
                .map(session -> UploadSessionInfo.builder()
                    .sessionId(session.getSessionId())
                    .bucketName(session.getBucketName())
                    .objectKey(session.getObjectKey())
                    .totalSize(session.getTotalSize())
                    .startTime(session.getStartTime())
                    .completedParts(session.getCompletedParts().size())
                    .build())
                .toList();
            
            return ResponseEntity.ok(sessionInfos);
            
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
}
```

### ✅ **Validation Criteria**
- [ ] Large files (>100MB) can be uploaded successfully
- [ ] Upload can be resumed after interruption
- [ ] Failed uploads are properly cleaned up
- [ ] Concurrent part uploads work correctly

---

## 🔄 **Exercise 3: File Versioning and Deduplication**

### **Objective**: Implement file versioning and content deduplication

#### **Step 1: Content Deduplication Service**

```java
@Service
public class DeduplicationService {
    
    @Autowired
    private ContentHashRepository hashRepository;
    
    @Autowired
    private ObjectStorageService storageService;
    
    public DeduplicationResult checkForDuplication(String contentHash, 
                                                 DeduplicationRequest request) {
        
        // Check if content already exists
        Optional<ContentHashRecord> existingRecord = hashRepository.findByContentHash(contentHash);
        
        if (existingRecord.isPresent()) {
            ContentHashRecord record = existingRecord.get();
            
            // Verify the referenced object still exists
            if (objectExists(record.getBucketName(), record.getObjectKey())) {
                // Create reference instead of storing duplicate
                String referenceKey = createContentReference(record, request);
                
                return DeduplicationResult.builder()
                    .isDuplicate(true)
                    .existingBucketName(record.getBucketName())
                    .existingObjectKey(record.getObjectKey())
                    .referenceKey(referenceKey)
                    .spacesSaved(record.getSize())
                    .build();
            } else {
                // Referenced object no longer exists, cleanup the hash record
                hashRepository.delete(record);
            }
        }
        
        return DeduplicationResult.builder()
            .isDuplicate(false)
            .build();
    }
    
    public void recordContentHash(String contentHash, String bucketName, 
                                String objectKey, long size) {
        
        ContentHashRecord record = ContentHashRecord.builder()
            .contentHash(contentHash)
            .bucketName(bucketName)
            .objectKey(objectKey)
            .size(size)
            .createdAt(Instant.now())
            .referenceCount(1)
            .build();
        
        hashRepository.save(record);
    }
    
    public void incrementReferenceCount(String contentHash) {
        ContentHashRecord record = hashRepository.findByContentHash(contentHash)
            .orElseThrow(() -> new IllegalArgumentException("Content hash not found"));
        
        record.setReferenceCount(record.getReferenceCount() + 1);
        hashRepository.save(record);
    }
    
    public void decrementReferenceCount(String contentHash) {
        ContentHashRecord record = hashRepository.findByContentHash(contentHash)
            .orElseThrow(() -> new IllegalArgumentException("Content hash not found"));
        
        record.setReferenceCount(record.getReferenceCount() - 1);
        
        if (record.getReferenceCount() <= 0) {
            // Delete the actual object when no more references exist
            storageService.deleteObject(record.getBucketName(), record.getObjectKey());
            hashRepository.delete(record);
        } else {
            hashRepository.save(record);
        }
    }
    
    private String createContentReference(ContentHashRecord sourceRecord, 
                                        DeduplicationRequest request) {
        
        ContentReference reference = ContentReference.builder()
            .sourceBucketName(sourceRecord.getBucketName())
            .sourceObjectKey(sourceRecord.getObjectKey())
            .targetBucketName(request.getTargetBucketName())
            .targetObjectKey(request.getTargetObjectKey())
            .contentHash(sourceRecord.getContentHash())
            .createdAt(Instant.now())
            .build();
        
        // Store the reference as a small JSON object
        String referenceJson = createReferenceJson(reference);
        
        try {
            storageService.uploadObject(
                request.getTargetBucketName(),
                request.getTargetObjectKey(),
                new ByteArrayInputStream(referenceJson.getBytes()),
                ObjectMetadata.builder()
                    .contentType("application/json")
                    .metadata(Map.of("content-reference", "true"))
                    .build()
            );
            
            return request.getTargetObjectKey();
            
        } catch (Exception e) {
            throw new DeduplicationException("Failed to create content reference", e);
        }
    }
    
    private String createReferenceJson(ContentReference reference) {
        Map<String, Object> referenceData = Map.of(
            "type", "content-reference",
            "sourceBucket", reference.getSourceBucketName(),
            "sourceKey", reference.getSourceObjectKey(),
            "contentHash", reference.getContentHash(),
            "createdAt", reference.getCreatedAt().toString()
        );
        
        try {
            return new ObjectMapper().writeValueAsString(referenceData);
        } catch (Exception e) {
            throw new RuntimeException("Failed to create reference JSON", e);
        }
    }
    
    private boolean objectExists(String bucketName, String objectKey) {
        try {
            storageService.getObjectMetadata(bucketName, objectKey);
            return true;
        } catch (ObjectNotFoundException e) {
            return false;
        }
    }
}
```

#### **Step 2: File Versioning Service**

```java
@Service
public class FileVersioningService {
    
    @Autowired
    private FileVersionRepository versionRepository;
    
    @Autowired
    private ObjectStorageService storageService;
    
    @Autowired
    private DeduplicationService deduplicationService;
    
    public FileVersion createVersion(String fileId, InputStream content, 
                                   VersioningOptions options) {
        
        // Calculate content hash
        byte[] contentBytes;
        try {
            contentBytes = content.readAllBytes();
        } catch (IOException e) {
            throw new VersioningException("Failed to read content", e);
        }
        
        String contentHash = calculateContentHash(contentBytes);
        
        // Get current version number
        int currentVersion = versionRepository.getLatestVersionNumber(fileId);
        int newVersionNumber = currentVersion + 1;
        
        // Check for deduplication
        DeduplicationResult dedupResult = deduplicationService.checkForDuplication(
            contentHash, 
            DeduplicationRequest.builder()
                .targetBucketName(options.getBucketName())
                .targetObjectKey(generateVersionKey(fileId, newVersionNumber))
                .build()
        );
        
        String storageKey;
        boolean isDuplicate = dedupResult.isDuplicate();
        
        if (isDuplicate) {
            storageKey = dedupResult.getReferenceKey();
            deduplicationService.incrementReferenceCount(contentHash);
        } else {
            // Upload new content
            storageKey = generateVersionKey(fileId, newVersionNumber);
            ObjectUploadResult uploadResult = storageService.uploadObject(
                options.getBucketName(),
                storageKey,
                new ByteArrayInputStream(contentBytes),
                ObjectMetadata.builder()
                    .contentType(options.getContentType())
                    .build()
            );
            
            // Record content hash
            deduplicationService.recordContentHash(
                contentHash, options.getBucketName(), storageKey, contentBytes.length);
        }
        
        // Create version record
        FileVersion version = FileVersion.builder()
            .fileId(fileId)
            .versionNumber(newVersionNumber)
            .bucketName(options.getBucketName())
            .objectKey(storageKey)
            .contentHash(contentHash)
            .size((long) contentBytes.length)
            .contentType(options.getContentType())
            .createdBy(options.getCreatedBy())
            .createdAt(Instant.now())
            .comment(options.getComment())
            .isDuplicate(isDuplicate)
            .build();
        
        versionRepository.save(version);
        
        // Cleanup old versions if needed
        if (options.getMaxVersions() > 0) {
            cleanupOldVersions(fileId, options.getMaxVersions());
        }
        
        return version;
    }
    
    public FileVersion getVersion(String fileId, int versionNumber) {
        return versionRepository.findByFileIdAndVersionNumber(fileId, versionNumber)
            .orElseThrow(() -> new VersionNotFoundException(
                STR."Version \{versionNumber} not found for file \{fileId}"));
    }
    
    public List<FileVersion> getVersionHistory(String fileId) {
        return versionRepository.findByFileIdOrderByVersionNumberDesc(fileId);
    }
    
    public ObjectDownloadResult downloadVersion(String fileId, int versionNumber) {
        FileVersion version = getVersion(fileId, versionNumber);
        
        if (version.isDuplicate()) {
            // Resolve content reference
            ContentReference reference = resolveContentReference(
                version.getBucketName(), version.getObjectKey());
            
            return storageService.downloadObject(
                reference.getSourceBucketName(), reference.getSourceObjectKey());
        } else {
            return storageService.downloadObject(
                version.getBucketName(), version.getObjectKey());
        }
    }
    
    public void deleteVersion(String fileId, int versionNumber) {
        FileVersion version = getVersion(fileId, versionNumber);
        
        if (version.isDuplicate()) {
            // Decrement reference count
            deduplicationService.decrementReferenceCount(version.getContentHash());
        } else {
            // Delete actual object
            storageService.deleteObject(version.getBucketName(), version.getObjectKey());
            deduplicationService.decrementReferenceCount(version.getContentHash());
        }
        
        versionRepository.delete(version);
    }
    
    public FileVersion promoteVersion(String fileId, int versionNumber) {
        FileVersion sourceVersion = getVersion(fileId, versionNumber);
        
        // Create new version as current
        ObjectDownloadResult downloadResult = downloadVersion(fileId, versionNumber);
        
        VersioningOptions options = VersioningOptions.builder()
            .bucketName(sourceVersion.getBucketName())
            .contentType(sourceVersion.getContentType())
            .createdBy("system")
            .comment(STR."Promoted from version \{versionNumber}")
            .build();
        
        return createVersion(fileId, 
            new ByteArrayInputStream(downloadResult.getData()), options);
    }
    
    private void cleanupOldVersions(String fileId, int maxVersions) {
        List<FileVersion> versions = versionRepository
            .findByFileIdOrderByVersionNumberDesc(fileId);
        
        if (versions.size() > maxVersions) {
            List<FileVersion> versionsToDelete = versions.subList(maxVersions, versions.size());
            
            for (FileVersion version : versionsToDelete) {
                try {
                    deleteVersion(fileId, version.getVersionNumber());
                } catch (Exception e) {
                    log.error("Failed to cleanup old version: {} v{}", 
                        fileId, version.getVersionNumber(), e);
                }
            }
        }
    }
    
    private String generateVersionKey(String fileId, int versionNumber) {
        return STR."versions/\{fileId}/v\{versionNumber}";
    }
    
    private String calculateContentHash(byte[] content) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(content);
            return Base64.getEncoder().encodeToString(hash);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-256 not available", e);
        }
    }
    
    private ContentReference resolveContentReference(String bucketName, String objectKey) {
        try {
            ObjectDownloadResult result = storageService.downloadObject(bucketName, objectKey);
            String referenceJson = new String(result.getData());
            
            ObjectMapper mapper = new ObjectMapper();
            Map<String, Object> referenceData = mapper.readValue(referenceJson, Map.class);
            
            return ContentReference.builder()
                .sourceBucketName((String) referenceData.get("sourceBucket"))
                .sourceObjectKey((String) referenceData.get("sourceKey"))
                .contentHash((String) referenceData.get("contentHash"))
                .build();
                
        } catch (Exception e) {
            throw new ContentReferenceException("Failed to resolve content reference", e);
        }
    }
}
```

### ✅ **Validation Criteria**
- [ ] Duplicate files are detected and referenced instead of stored
- [ ] File versions can be created, retrieved, and deleted
- [ ] Version history is maintained correctly
- [ ] Space savings from deduplication are measurable

---

## 📊 **Exercise 4: Storage Performance Monitoring**

### **Objective**: Implement comprehensive storage monitoring

#### **Step 1: Storage Metrics Collection**

```java
@Component
public class StorageMetrics {
    
    private final Counter uploadCounter;
    private final Counter downloadCounter;
    private final Timer uploadTimer;
    private final Timer downloadTimer;
    private final DistributionSummary fileSizeDistribution;
    private final Gauge storageUtilization;
    private final Counter errorCounter;
    
    public StorageMetrics(MeterRegistry meterRegistry) {
        this.uploadCounter = Counter.builder("storage.uploads.total")
            .description("Total file uploads")
            .register(meterRegistry);
            
        this.downloadCounter = Counter.builder("storage.downloads.total")
            .description("Total file downloads")
            .register(meterRegistry);
            
        this.uploadTimer = Timer.builder("storage.upload.duration")
            .description("File upload duration")
            .register(meterRegistry);
            
        this.downloadTimer = Timer.builder("storage.download.duration")
            .description("File download duration")
            .register(meterRegistry);
            
        this.fileSizeDistribution = DistributionSummary.builder("storage.file.size")
            .description("File size distribution")
            .baseUnit("bytes")
            .register(meterRegistry);
            
        this.storageUtilization = Gauge.builder("storage.utilization.bytes")
            .description("Total storage utilization")
            .register(meterRegistry, this, StorageMetrics::getTotalStorageUsage);
            
        this.errorCounter = Counter.builder("storage.errors.total")
            .description("Storage operation errors")
            .register(meterRegistry);
    }
    
    public Timer.Sample startUploadTimer() {
        return Timer.start();
    }
    
    public Timer.Sample startDownloadTimer() {
        return Timer.start();
    }
    
    public void recordUploadSuccess(long fileSizeBytes, int shardCount) {
        uploadCounter.increment(
            Tags.of(
                "status", "success",
                "sharded", shardCount > 1 ? "true" : "false"
            )
        );
        fileSizeDistribution.record(fileSizeBytes);
    }
    
    public void recordUploadFailure(Exception error) {
        uploadCounter.increment(
            Tags.of(
                "status", "failure",
                "error_type", error.getClass().getSimpleName()
            )
        );
        errorCounter.increment(Tags.of("operation", "upload"));
    }
    
    public void recordDownloadSuccess(long fileSizeBytes) {
        downloadCounter.increment(Tags.of("status", "success"));
        fileSizeDistribution.record(fileSizeBytes);
    }
    
    public void recordDownloadFailure(Exception error) {
        downloadCounter.increment(
            Tags.of(
                "status", "failure",
                "error_type", error.getClass().getSimpleName()
            )
        );
        errorCounter.increment(Tags.of("operation", "download"));
    }
    
    public void recordDeduplicationSavings(long bytesSaved) {
        Counter.builder("storage.deduplication.bytes_saved")
            .description("Bytes saved through deduplication")
            .register(Metrics.globalRegistry)
            .increment(bytesSaved);
    }
    
    private double getTotalStorageUsage() {
        // Calculate total storage usage across all buckets
        return storageUsageCalculator.calculateTotalUsage();
    }
}
```

#### **Step 2: Performance Dashboard**

```yaml
# Grafana dashboard queries for storage monitoring

# Upload/Download Rate
rate(storage_uploads_total[5m])
rate(storage_downloads_total[5m])

# Average File Size
rate(storage_file_size_sum[5m]) / rate(storage_file_size_count[5m])

# Error Rate
rate(storage_errors_total[5m]) / rate(storage_uploads_total[5m])

# Storage Utilization
storage_utilization_bytes

# Upload/Download Duration Percentiles
histogram_quantile(0.95, rate(storage_upload_duration_bucket[5m]))
histogram_quantile(0.99, rate(storage_download_duration_bucket[5m]))

# Deduplication Efficiency
rate(storage_deduplication_bytes_saved[1h])
```

### ✅ **Validation Criteria**
- [ ] All storage operations are instrumented with metrics
- [ ] Performance dashboards show real-time statistics
- [ ] Alerts trigger when error rates exceed thresholds
- [ ] Capacity planning data is available

---

## 🎯 **Exercise 5: Disaster Recovery Implementation**

### **Objective**: Implement backup and disaster recovery strategies

#### **Step 1: Cross-Region Replication**

```java
@Service
public class DisasterRecoveryService {
    
    @Autowired
    private S3Client primaryS3Client;
    
    @Autowired
    private S3Client backupS3Client;
    
    @Autowired
    private ReplicationStatusRepository replicationRepository;
    
    public void enableCrossRegionReplication(String bucketName, String backupBucketName) {
        try {
            // Configure replication on primary bucket
            ReplicationConfiguration replicationConfig = ReplicationConfiguration.builder()
                .role("arn:aws:iam::123456789012:role/replication-role")
                .rules(ReplicationRule.builder()
                    .id("ReplicateToBackupRegion")
                    .status(ReplicationRuleStatus.ENABLED)
                    .priority(1)
                    .filter(ReplicationRuleFilter.builder()
                        .prefix("")
                        .build())
                    .destination(Destination.builder()
                        .bucket(STR."arn:aws:s3:::\{backupBucketName}")
                        .storageClass(ReplicationStorageClass.STANDARD_IA)
                        .build())
                    .deleteMarkerReplication(DeleteMarkerReplication.builder()
                        .status(DeleteMarkerReplicationStatus.ENABLED)
                        .build())
                    .build())
                .build();
            
            PutBucketReplicationRequest request = PutBucketReplicationRequest.builder()
                .bucket(bucketName)
                .replicationConfiguration(replicationConfig)
                .build();
            
            primaryS3Client.putBucketReplication(request);
            
            log.info("Enabled cross-region replication from {} to {}", 
                bucketName, backupBucketName);
            
        } catch (Exception e) {
            throw new DisasterRecoveryException("Failed to enable cross-region replication", e);
        }
    }
    
    public BackupStatus performIncrementalBackup(String bucketName, String backupBucketName) {
        try {
            // Get last backup timestamp
            Instant lastBackupTime = getLastBackupTime(bucketName);
            
            // List objects modified since last backup
            List<S3Object> modifiedObjects = listModifiedObjects(bucketName, lastBackupTime);
            
            int successCount = 0;
            int failureCount = 0;
            List<String> failedObjects = new ArrayList<>();
            
            for (S3Object object : modifiedObjects) {
                try {
                    copyObjectToBackup(bucketName, object.key(), backupBucketName);
                    successCount++;
                } catch (Exception e) {
                    failureCount++;
                    failedObjects.add(object.key());
                    log.error("Failed to backup object: {}", object.key(), e);
                }
            }
            
            // Record backup completion
            BackupRecord record = BackupRecord.builder()
                .bucketName(bucketName)
                .backupTime(Instant.now())
                .objectsBackedUp(successCount)
                .failedObjects(failureCount)
                .backupType(BackupType.INCREMENTAL)
                .build();
            
            replicationRepository.save(record);
            
            return BackupStatus.builder()
                .success(failureCount == 0)
                .objectsProcessed(modifiedObjects.size())
                .successCount(successCount)
                .failureCount(failureCount)
                .failedObjects(failedObjects)
                .build();
            
        } catch (Exception e) {
            throw new DisasterRecoveryException("Incremental backup failed", e);
        }
    }
    
    public RestoreStatus restoreFromBackup(String backupBucketName, String targetBucketName, 
                                         RestoreOptions options) {
        try {
            // List objects in backup bucket
            List<S3Object> backupObjects = listAllObjects(backupBucketName);
            
            int successCount = 0;
            int failureCount = 0;
            List<String> failedObjects = new ArrayList<>();
            
            for (S3Object object : backupObjects) {
                try {
                    if (shouldRestoreObject(object, options)) {
                        restoreObject(backupBucketName, object.key(), targetBucketName);
                        successCount++;
                    }
                } catch (Exception e) {
                    failureCount++;
                    failedObjects.add(object.key());
                    log.error("Failed to restore object: {}", object.key(), e);
                }
            }
            
            return RestoreStatus.builder()
                .success(failureCount == 0)
                .objectsProcessed(backupObjects.size())
                .successCount(successCount)
                .failureCount(failureCount)
                .failedObjects(failedObjects)
                .build();
            
        } catch (Exception e) {
            throw new DisasterRecoveryException("Restore from backup failed", e);
        }
    }
    
    @Scheduled(cron = "0 0 2 * * *") // Daily at 2 AM
    public void performScheduledBackup() {
        List<String> bucketsToBackup = getBucketsForBackup();
        
        for (String bucket : bucketsToBackup) {
            try {
                String backupBucket = getBackupBucketForPrimary(bucket);
                BackupStatus status = performIncrementalBackup(bucket, backupBucket);
                
                if (status.isSuccess()) {
                    log.info("Scheduled backup completed successfully for bucket: {}", bucket);
                } else {
                    log.warn("Scheduled backup completed with {} failures for bucket: {}", 
                        status.getFailureCount(), bucket);
                }
                
            } catch (Exception e) {
                log.error("Scheduled backup failed for bucket: {}", bucket, e);
            }
        }
    }
    
    public void validateBackupIntegrity(String bucketName, String backupBucketName) {
        try {
            List<S3Object> primaryObjects = listAllObjects(bucketName);
            List<S3Object> backupObjects = listAllObjects(backupBucketName);
            
            Map<String, S3Object> backupMap = backupObjects.stream()
                .collect(Collectors.toMap(S3Object::key, obj -> obj));
            
            List<String> missingObjects = new ArrayList<>();
            List<String> modifiedObjects = new ArrayList<>();
            
            for (S3Object primaryObj : primaryObjects) {
                S3Object backupObj = backupMap.get(primaryObj.key());
                
                if (backupObj == null) {
                    missingObjects.add(primaryObj.key());
                } else if (!Objects.equals(primaryObj.eTag(), backupObj.eTag())) {
                    modifiedObjects.add(primaryObj.key());
                }
            }
            
            if (!missingObjects.isEmpty() || !modifiedObjects.isEmpty()) {
                log.warn("Backup integrity check failed. Missing: {}, Modified: {}", 
                    missingObjects.size(), modifiedObjects.size());
                
                // Trigger corrective action
                triggerBackupCorrection(bucketName, backupBucketName, 
                    missingObjects, modifiedObjects);
            } else {
                log.info("Backup integrity check passed for bucket: {}", bucketName);
            }
            
        } catch (Exception e) {
            log.error("Backup integrity validation failed", e);
        }
    }
    
    private List<S3Object> listModifiedObjects(String bucketName, Instant since) {
        // Implementation to list objects modified since timestamp
        // This would use S3 inventory or custom tracking
        return Collections.emptyList(); // Placeholder
    }
    
    private void copyObjectToBackup(String sourceBucket, String sourceKey, String targetBucket) {
        CopyObjectRequest copyRequest = CopyObjectRequest.builder()
            .sourceBucket(sourceBucket)
            .sourceKey(sourceKey)
            .destinationBucket(targetBucket)
            .destinationKey(sourceKey)
            .build();
        
        backupS3Client.copyObject(copyRequest);
    }
    
    private boolean shouldRestoreObject(S3Object object, RestoreOptions options) {
        // Check if object matches restore criteria
        if (options.getRestorePattern() != null) {
            return object.key().matches(options.getRestorePattern());
        }
        
        if (options.getMaxAge() != null) {
            return object.lastModified().isAfter(Instant.now().minus(options.getMaxAge()));
        }
        
        return true;
    }
    
    private void restoreObject(String sourceBucket, String sourceKey, String targetBucket) {
        copyObjectToBackup(sourceBucket, sourceKey, targetBucket);
    }
}
```

### ✅ **Validation Criteria**
- [ ] Cross-region replication is configured and working
- [ ] Incremental backups run successfully
- [ ] Backup integrity checks detect and correct issues
- [ ] Restore operations work correctly
- [ ] Recovery time objectives (RTO) are met

---

## 📈 **Lab Completion Summary**

### **What You've Built**
1. **Object Storage Service** with basic upload/download functionality
2. **Multipart Upload System** for large files with resumable uploads
3. **File Versioning** with content deduplication
4. **Performance Monitoring** with comprehensive metrics
5. **Disaster Recovery** with cross-region replication and backup

### **Key Learnings**
- Object storage patterns and best practices
- Large file handling with chunking and multipart uploads
- Content deduplication for storage efficiency
- Storage performance monitoring and optimization
- Backup and disaster recovery strategies

### **Next Steps**
1. **Deploy to production** using the provided configurations
2. **Integrate with CDN** for global content delivery
3. **Add encryption** at rest and in transit
4. **Implement lifecycle policies** for cost optimization
5. **Move to Module 4: Database Systems**

**🎉 Congratulations! You've built a production-ready object storage system with enterprise-grade features for versioning, deduplication, and disaster recovery.**
