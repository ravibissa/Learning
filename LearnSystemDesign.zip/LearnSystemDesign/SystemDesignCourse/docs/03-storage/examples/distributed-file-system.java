// Distributed File System Implementation
// Demonstrates storage patterns for system design interviews

package com.systemdesign.storage.examples;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.*;

import java.io.*;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Production-ready distributed file system implementation
 * Demonstrates patterns commonly asked in system design interviews
 */
@Service
public class DistributedFileSystemService {
    
    @Autowired
    private S3Client s3Client;
    
    @Autowired
    private FileMetadataRepository metadataRepository;
    
    @Autowired
    private FileReplicationService replicationService;
    
    @Autowired
    private FileStorageMetrics storageMetrics;
    
    private final Map<String, FileUploadSession> activeUploads = new ConcurrentHashMap<>();
    
    /**
     * Upload file with automatic sharding for large files
     */
    public FileUploadResult uploadFile(MultipartFile file, FileUploadOptions options) {
        Timer.Sample sample = storageMetrics.startUploadTimer();
        
        try {
            // Generate unique file ID
            String fileId = generateFileId();
            String contentHash = calculateFileHash(file.getInputStream());
            
            // Check for deduplication
            Optional<FileMetadata> existingFile = metadataRepository.findByContentHash(contentHash);
            if (existingFile.isPresent() && options.isDeduplicationEnabled()) {
                return FileUploadResult.builder()
                    .fileId(existingFile.get().getFileId())
                    .isDuplicate(true)
                    .spacesSaved(file.getSize())
                    .build();
            }
            
            FileUploadResult result;
            
            if (file.getSize() > options.getShardingThreshold()) {
                result = uploadLargeFileWithSharding(fileId, file, options);
            } else {
                result = uploadSmallFile(fileId, file, options);
            }
            
            // Store metadata
            FileMetadata metadata = FileMetadata.builder()
                .fileId(fileId)
                .originalName(file.getOriginalFilename())
                .contentType(file.getContentType())
                .size(file.getSize())
                .contentHash(contentHash)
                .uploadTime(Instant.now())
                .shardCount(result.getShardCount())
                .replicationFactor(options.getReplicationFactor())
                .storageClass(determineStorageClass(options))
                .build();
            
            metadataRepository.save(metadata);
            
            // Schedule replication if required
            if (options.getReplicationFactor() > 1) {
                scheduleReplication(fileId, options.getReplicationFactor());
            }
            
            storageMetrics.recordUploadSuccess(file.getSize(), result.getShardCount());
            return result;
            
        } catch (Exception e) {
            storageMetrics.recordUploadFailure(e);
            throw new FileUploadException("Failed to upload file", e);
        } finally {
            sample.stop();
        }
    }
    
    /**
     * Download file with automatic shard reassembly
     */
    public FileDownloadResult downloadFile(String fileId, FileDownloadOptions options) {
        Timer.Sample sample = storageMetrics.startDownloadTimer();
        
        try {
            FileMetadata metadata = metadataRepository.findByFileId(fileId)
                .orElseThrow(() -> new FileNotFoundException("File not found: " + fileId));
            
            // Check access permissions
            if (!hasReadAccess(fileId, options.getUserId())) {
                throw new AccessDeniedException("No read access to file: " + fileId);
            }
            
            FileDownloadResult result;
            
            if (metadata.getShardCount() > 1) {
                result = downloadShardedFile(fileId, metadata, options);
            } else {
                result = downloadSingleFile(fileId, metadata, options);
            }
            
            storageMetrics.recordDownloadSuccess(metadata.getSize());
            return result;
            
        } catch (Exception e) {
            storageMetrics.recordDownloadFailure(e);
            throw e;
        } finally {
            sample.stop();
        }
    }
    
    /**
     * Stream large file download to avoid memory issues
     */
    public InputStream streamFile(String fileId, FileStreamOptions options) {
        FileMetadata metadata = metadataRepository.findByFileId(fileId)
            .orElseThrow(() -> new FileNotFoundException("File not found: " + fileId));
        
        if (!hasReadAccess(fileId, options.getUserId())) {
            throw new AccessDeniedException("No read access to file: " + fileId);
        }
        
        if (metadata.getShardCount() > 1) {
            return createShardedFileStream(fileId, metadata, options);
        } else {
            return createSingleFileStream(fileId, metadata, options);
        }
    }
    
    /**
     * Multipart upload for very large files with resumable capability
     */
    public String initializeMultipartUpload(String fileName, long fileSize, FileUploadOptions options) {
        String uploadId = generateUploadId();
        String fileId = generateFileId();
        
        FileUploadSession session = FileUploadSession.builder()
            .uploadId(uploadId)
            .fileId(fileId)
            .fileName(fileName)
            .totalSize(fileSize)
            .options(options)
            .startTime(Instant.now())
            .build();
        
        activeUploads.put(uploadId, session);
        
        // Initialize S3 multipart upload if needed
        if (fileSize > options.getS3MultipartThreshold()) {
            String s3UploadId = initializeS3MultipartUpload(fileId, options);
            session.setS3UploadId(s3UploadId);
        }
        
        return uploadId;
    }
    
    /**
     * Upload file part for multipart upload
     */
    public PartUploadResult uploadPart(String uploadId, int partNumber, InputStream data, long partSize) {
        FileUploadSession session = activeUploads.get(uploadId);
        if (session == null) {
            throw new IllegalArgumentException("Invalid upload ID: " + uploadId);
        }
        
        try {
            String partETag;
            
            if (session.getS3UploadId() != null) {
                partETag = uploadS3Part(session, partNumber, data, partSize);
            } else {
                partETag = uploadLocalPart(session, partNumber, data, partSize);
            }
            
            session.addCompletedPart(partNumber, partETag);
            
            return PartUploadResult.builder()
                .partNumber(partNumber)
                .eTag(partETag)
                .size(partSize)
                .build();
            
        } catch (Exception e) {
            throw new PartUploadException("Failed to upload part", e);
        }
    }
    
    /**
     * Complete multipart upload
     */
    public FileUploadResult completeMultipartUpload(String uploadId) {
        FileUploadSession session = activeUploads.remove(uploadId);
        if (session == null) {
            throw new IllegalArgumentException("Invalid upload ID: " + uploadId);
        }
        
        try {
            String finalETag;
            
            if (session.getS3UploadId() != null) {
                finalETag = completeS3MultipartUpload(session);
            } else {
                finalETag = completeLocalMultipartUpload(session);
            }
            
            // Save metadata
            FileMetadata metadata = FileMetadata.builder()
                .fileId(session.getFileId())
                .originalName(session.getFileName())
                .size(session.getTotalSize())
                .uploadTime(Instant.now())
                .shardCount(session.getCompletedParts().size())
                .eTag(finalETag)
                .build();
            
            metadataRepository.save(metadata);
            
            return FileUploadResult.builder()
                .fileId(session.getFileId())
                .eTag(finalETag)
                .shardCount(session.getCompletedParts().size())
                .build();
            
        } catch (Exception e) {
            throw new MultipartUploadException("Failed to complete multipart upload", e);
        }
    }
    
    /**
     * File versioning support
     */
    public FileVersion createFileVersion(String fileId, MultipartFile newVersion, VersioningOptions options) {
        FileMetadata currentMetadata = metadataRepository.findByFileId(fileId)
            .orElseThrow(() -> new FileNotFoundException("File not found: " + fileId));
        
        // Check versioning limits
        int currentVersionCount = fileVersionRepository.countByFileId(fileId);
        if (currentVersionCount >= options.getMaxVersions()) {
            // Cleanup old versions
            cleanupOldVersions(fileId, options.getMaxVersions() - 1);
        }
        
        // Upload new version
        String versionId = generateVersionId();
        FileUploadResult uploadResult = uploadFile(newVersion, 
            FileUploadOptions.builder()
                .replicationFactor(currentMetadata.getReplicationFactor())
                .storageClass(currentMetadata.getStorageClass())
                .build());
        
        // Create version record
        FileVersion version = FileVersion.builder()
            .versionId(versionId)
            .fileId(fileId)
            .versionNumber(currentVersionCount + 1)
            .contentFileId(uploadResult.getFileId())
            .size(newVersion.getSize())
            .createdBy(options.getUserId())
            .createdAt(Instant.now())
            .comment(options.getComment())
            .build();
        
        fileVersionRepository.save(version);
        
        return version;
    }
    
    /**
     * File deletion with retention policy
     */
    public void deleteFile(String fileId, FileDeletionOptions options) {
        FileMetadata metadata = metadataRepository.findByFileId(fileId)
            .orElseThrow(() -> new FileNotFoundException("File not found: " + fileId));
        
        if (!hasDeleteAccess(fileId, options.getUserId())) {
            throw new AccessDeniedException("No delete access to file: " + fileId);
        }
        
        if (options.isSoftDelete()) {
            // Mark as deleted but keep data
            metadata.setDeletedAt(Instant.now());
            metadata.setDeletedBy(options.getUserId());
            metadataRepository.save(metadata);
        } else {
            // Actually delete the file data
            deleteFileData(fileId, metadata);
            
            // Delete metadata
            metadataRepository.delete(metadata);
            
            // Delete all versions
            fileVersionRepository.deleteByFileId(fileId);
        }
        
        storageMetrics.recordFileDeletion(options.isSoftDelete());
    }
    
    // Private helper methods
    
    private FileUploadResult uploadLargeFileWithSharding(String fileId, MultipartFile file, 
                                                       FileUploadOptions options) throws IOException {
        int shardSize = options.getShardSize();
        List<CompletableFuture<String>> shardFutures = new ArrayList<>();
        
        try (InputStream inputStream = file.getInputStream();
             BufferedInputStream bufferedStream = new BufferedInputStream(inputStream)) {
            
            int shardIndex = 0;
            byte[] buffer = new byte[shardSize];
            int bytesRead;
            
            while ((bytesRead = bufferedStream.read(buffer)) > 0) {
                final int currentShardIndex = shardIndex;
                final byte[] shardData = Arrays.copyOf(buffer, bytesRead);
                
                CompletableFuture<String> shardFuture = CompletableFuture.supplyAsync(() -> {
                    try {
                        return uploadShard(fileId, currentShardIndex, shardData);
                    } catch (Exception e) {
                        throw new RuntimeException("Failed to upload shard " + currentShardIndex, e);
                    }
                });
                
                shardFutures.add(shardFuture);
                shardIndex++;
            }
            
            // Wait for all shards to complete
            List<String> shardETags = shardFutures.stream()
                .map(CompletableFuture::join)
                .toList();
            
            return FileUploadResult.builder()
                .fileId(fileId)
                .shardCount(shardETags.size())
                .shardETags(shardETags)
                .build();
        }
    }
    
    private FileUploadResult uploadSmallFile(String fileId, MultipartFile file, 
                                           FileUploadOptions options) throws IOException {
        String bucketName = determineBucket(options);
        String key = generateS3Key(fileId);
        
        PutObjectRequest putRequest = PutObjectRequest.builder()
            .bucket(bucketName)
            .key(key)
            .contentType(file.getContentType())
            .contentLength(file.getSize())
            .serverSideEncryption(ServerSideEncryption.AES256)
            .storageClass(mapToS3StorageClass(options.getStorageClass()))
            .build();
        
        PutObjectResponse response = s3Client.putObject(putRequest, 
            RequestBody.fromInputStream(file.getInputStream(), file.getSize()));
        
        return FileUploadResult.builder()
            .fileId(fileId)
            .eTag(response.eTag())
            .shardCount(1)
            .build();
    }
    
    private String uploadShard(String fileId, int shardIndex, byte[] shardData) {
        String bucketName = getShardBucket();
        String key = generateShardKey(fileId, shardIndex);
        
        PutObjectRequest putRequest = PutObjectRequest.builder()
            .bucket(bucketName)
            .key(key)
            .contentLength((long) shardData.length)
            .serverSideEncryption(ServerSideEncryption.AES256)
            .build();
        
        PutObjectResponse response = s3Client.putObject(putRequest, 
            RequestBody.fromBytes(shardData));
        
        return response.eTag();
    }
    
    private FileDownloadResult downloadShardedFile(String fileId, FileMetadata metadata, 
                                                 FileDownloadOptions options) {
        List<CompletableFuture<byte[]>> shardFutures = new ArrayList<>();
        
        for (int i = 0; i < metadata.getShardCount(); i++) {
            final int shardIndex = i;
            
            CompletableFuture<byte[]> shardFuture = CompletableFuture.supplyAsync(() -> {
                try {
                    return downloadShard(fileId, shardIndex);
                } catch (Exception e) {
                    throw new RuntimeException("Failed to download shard " + shardIndex, e);
                }
            });
            
            shardFutures.add(shardFuture);
        }
        
        // Combine all shards
        ByteArrayOutputStream combinedStream = new ByteArrayOutputStream();
        
        for (CompletableFuture<byte[]> shardFuture : shardFutures) {
            byte[] shardData = shardFuture.join();
            combinedStream.writeBytes(shardData);
        }
        
        return FileDownloadResult.builder()
            .fileId(fileId)
            .data(combinedStream.toByteArray())
            .contentType(metadata.getContentType())
            .size(metadata.getSize())
            .build();
    }
    
    private FileDownloadResult downloadSingleFile(String fileId, FileMetadata metadata, 
                                                FileDownloadOptions options) {
        String bucketName = determineBucketFromMetadata(metadata);
        String key = generateS3Key(fileId);
        
        GetObjectRequest getRequest = GetObjectRequest.builder()
            .bucket(bucketName)
            .key(key)
            .build();
        
        ResponseInputStream<GetObjectResponse> response = s3Client.getObject(getRequest);
        
        try (ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
            response.transferTo(outputStream);
            
            return FileDownloadResult.builder()
                .fileId(fileId)
                .data(outputStream.toByteArray())
                .contentType(metadata.getContentType())
                .size(metadata.getSize())
                .eTag(response.response().eTag())
                .build();
                
        } catch (IOException e) {
            throw new FileDownloadException("Failed to download file", e);
        }
    }
    
    private byte[] downloadShard(String fileId, int shardIndex) {
        String bucketName = getShardBucket();
        String key = generateShardKey(fileId, shardIndex);
        
        GetObjectRequest getRequest = GetObjectRequest.builder()
            .bucket(bucketName)
            .key(key)
            .build();
        
        ResponseInputStream<GetObjectResponse> response = s3Client.getObject(getRequest);
        
        try {
            return response.readAllBytes();
        } catch (IOException e) {
            throw new ShardDownloadException("Failed to download shard", e);
        }
    }
    
    private InputStream createShardedFileStream(String fileId, FileMetadata metadata, 
                                              FileStreamOptions options) {
        return new ShardedFileInputStream(fileId, metadata.getShardCount(), this);
    }
    
    private InputStream createSingleFileStream(String fileId, FileMetadata metadata, 
                                             FileStreamOptions options) {
        String bucketName = determineBucketFromMetadata(metadata);
        String key = generateS3Key(fileId);
        
        GetObjectRequest getRequest = GetObjectRequest.builder()
            .bucket(bucketName)
            .key(key)
            .build();
        
        return s3Client.getObject(getRequest);
    }
    
    private String calculateFileHash(InputStream inputStream) throws IOException {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] buffer = new byte[8192];
            int bytesRead;
            
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                digest.update(buffer, 0, bytesRead);
            }
            
            return Base64.getEncoder().encodeToString(digest.digest());
            
        } catch (Exception e) {
            throw new IOException("Failed to calculate file hash", e);
        }
    }
    
    private String generateFileId() {
        return UUID.randomUUID().toString();
    }
    
    private String generateUploadId() {
        return UUID.randomUUID().toString();
    }
    
    private String generateVersionId() {
        return UUID.randomUUID().toString();
    }
    
    private String generateS3Key(String fileId) {
        return STR."files/\{fileId.substring(0, 2)}/\{fileId}";
    }
    
    private String generateShardKey(String fileId, int shardIndex) {
        return STR."shards/\{fileId}/\{shardIndex}";
    }
    
    private StorageClass determineStorageClass(FileUploadOptions options) {
        return switch (options.getAccessPattern()) {
            case FREQUENT -> StorageClass.STANDARD;
            case INFREQUENT -> StorageClass.INFREQUENT_ACCESS;
            case ARCHIVE -> StorageClass.ARCHIVE;
            case COLD_ARCHIVE -> StorageClass.COLD_ARCHIVE;
        };
    }
    
    private boolean hasReadAccess(String fileId, String userId) {
        return accessControlService.hasPermission(userId, fileId, Permission.READ);
    }
    
    private boolean hasDeleteAccess(String fileId, String userId) {
        return accessControlService.hasPermission(userId, fileId, Permission.DELETE);
    }
    
    // Inner classes for better organization
    
    public static class ShardedFileInputStream extends InputStream {
        private final String fileId;
        private final int totalShards;
        private final DistributedFileSystemService fileService;
        private int currentShard = 0;
        private byte[] currentShardData;
        private int currentPosition = 0;
        
        public ShardedFileInputStream(String fileId, int totalShards, 
                                    DistributedFileSystemService fileService) {
            this.fileId = fileId;
            this.totalShards = totalShards;
            this.fileService = fileService;
        }
        
        @Override
        public int read() throws IOException {
            if (currentShardData == null || currentPosition >= currentShardData.length) {
                if (!loadNextShard()) {
                    return -1; // End of stream
                }
            }
            
            return currentShardData[currentPosition++] & 0xFF;
        }
        
        @Override
        public int read(byte[] b, int off, int len) throws IOException {
            if (currentShardData == null || currentPosition >= currentShardData.length) {
                if (!loadNextShard()) {
                    return -1; // End of stream
                }
            }
            
            int available = currentShardData.length - currentPosition;
            int toRead = Math.min(len, available);
            
            System.arraycopy(currentShardData, currentPosition, b, off, toRead);
            currentPosition += toRead;
            
            return toRead;
        }
        
        private boolean loadNextShard() {
            if (currentShard >= totalShards) {
                return false;
            }
            
            try {
                currentShardData = fileService.downloadShard(fileId, currentShard);
                currentPosition = 0;
                currentShard++;
                return true;
            } catch (Exception e) {
                throw new RuntimeException("Failed to load shard " + currentShard, e);
            }
        }
    }
}

// Supporting classes and enums

enum AccessPattern {
    FREQUENT, INFREQUENT, ARCHIVE, COLD_ARCHIVE
}

enum StorageClass {
    STANDARD, INFREQUENT_ACCESS, ARCHIVE, COLD_ARCHIVE
}

enum Permission {
    READ, WRITE, DELETE, ADMIN
}

// Exception classes
class FileUploadException extends RuntimeException {
    public FileUploadException(String message, Throwable cause) {
        super(message, cause);
    }
}

class FileDownloadException extends RuntimeException {
    public FileDownloadException(String message, Throwable cause) {
        super(message, cause);
    }
}

class FileNotFoundException extends RuntimeException {
    public FileNotFoundException(String message) {
        super(message);
    }
}

class AccessDeniedException extends RuntimeException {
    public AccessDeniedException(String message) {
        super(message);
    }
}

class PartUploadException extends RuntimeException {
    public PartUploadException(String message, Throwable cause) {
        super(message, cause);
    }
}

class MultipartUploadException extends RuntimeException {
    public MultipartUploadException(String message, Throwable cause) {
        super(message, cause);
    }
}

class ShardDownloadException extends RuntimeException {
    public ShardDownloadException(String message, Throwable cause) {
        super(message, cause);
    }
}
