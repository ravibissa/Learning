# Module 3: Storage Systems for Scale

## 💾 Designing Storage Architecture for High-Performance Systems

### 📚 Learning Objectives

By the end of this module, you will:
- Design storage systems for different access patterns
- Choose between object, block, and file storage
- Implement distributed file systems
- Design backup and disaster recovery strategies
- Optimize storage performance for various workloads
- Handle storage scaling challenges

---

## 🏗️ Storage System Types and Use Cases

### 1. Storage Decision Framework

```java
// Storage selection service for system design
@Service
public class StorageSelectionService {
    
    public StorageRecommendation recommendStorage(StorageRequirements requirements) {
        StorageRecommendation.Builder recommendation = StorageRecommendation.builder();
        
        // Analyze access patterns
        if (requirements.isFrequentRandomAccess()) {
            if (requirements.getDataSize() < 1024) { // < 1KB
                recommendation.primary(StorageType.REDIS)
                    .reason("Redis for sub-millisecond access to small data");
            } else if (requirements.isStructuredData()) {
                recommendation.primary(StorageType.SSD_BLOCK_STORAGE)
                    .reason("SSD block storage for fast random access to larger structured data");
            } else {
                recommendation.primary(StorageType.OBJECT_STORAGE)
                    .reason("Object storage for unstructured data with caching layer");
            }
        }
        
        if (requirements.isSequentialAccess()) {
            if (requirements.getDataSize() > 100 * 1024 * 1024) { // > 100MB
                recommendation.primary(StorageType.HDD_BLOCK_STORAGE)
                    .reason("HDD block storage cost-effective for large sequential access");
            } else {
                recommendation.primary(StorageType.FILE_STORAGE)
                    .reason("Network file storage for shared sequential access");
            }
        }
        
        if (requirements.isArchivalData()) {
            recommendation.primary(StorageType.COLD_STORAGE)
                .reason("Glacier/Cold storage for long-term archival");
        }
        
        if (requirements.isGlobalAccess()) {
            recommendation.secondary(StorageType.CDN)
                .reason("CDN for global content distribution");
        }
        
        return recommendation.build();
    }
    
    public enum StorageType {
        REDIS("In-memory key-value store"),
        SSD_BLOCK_STORAGE("High-performance block storage"),
        HDD_BLOCK_STORAGE("Cost-effective block storage"),
        OBJECT_STORAGE("Scalable object storage (S3)"),
        FILE_STORAGE("Network file system (EFS)"),
        COLD_STORAGE("Archive storage (Glacier)"),
        CDN("Content delivery network");
        
        private final String description;
        
        StorageType(String description) {
            this.description = description;
        }
        
        public String getDescription() { return description; }
    }
}
```

### 2. Object Storage Implementation

```java
// S3-compatible object storage service
@Service
public class ObjectStorageService {
    
    @Autowired
    private S3Client s3Client;
    
    @Autowired
    private CloudFrontClient cloudFrontClient;
    
    @Autowired
    private StorageMetrics storageMetrics;
    
    public ObjectMetadata uploadObject(String bucketName, String key, InputStream data, 
                                     ObjectUploadOptions options) {
        Timer.Sample sample = storageMetrics.startUploadTimer();
        
        try {
            // Determine optimal upload strategy based on size
            if (options.getContentLength() > 100 * 1024 * 1024) { // > 100MB
                return uploadLargeObject(bucketName, key, data, options);
            } else {
                return uploadSmallObject(bucketName, key, data, options);
            }
        } finally {
            sample.stop();
            storageMetrics.recordUpload(bucketName, options.getContentLength());
        }
    }
    
    private ObjectMetadata uploadLargeObject(String bucketName, String key, 
                                           InputStream data, ObjectUploadOptions options) {
        
        // Multipart upload for large files
        CreateMultipartUploadRequest createRequest = CreateMultipartUploadRequest.builder()
            .bucket(bucketName)
            .key(key)
            .contentType(options.getContentType())
            .metadata(options.getMetadata())
            .serverSideEncryption(ServerSideEncryption.AES256)
            .build();
        
        CreateMultipartUploadResponse createResponse = s3Client.createMultipartUpload(createRequest);
        String uploadId = createResponse.uploadId();
        
        List<CompletedPart> completedParts = new ArrayList<>();
        int partNumber = 1;
        
        try (BufferedInputStream bufferedData = new BufferedInputStream(data)) {
            byte[] buffer = new byte[5 * 1024 * 1024]; // 5MB chunks
            int bytesRead;
            
            while ((bytesRead = bufferedData.read(buffer)) > 0) {
                ByteArrayInputStream partData = new ByteArrayInputStream(buffer, 0, bytesRead);
                
                UploadPartRequest uploadPartRequest = UploadPartRequest.builder()
                    .bucket(bucketName)
                    .key(key)
                    .uploadId(uploadId)
                    .partNumber(partNumber)
                    .contentLength((long) bytesRead)
                    .build();
                
                UploadPartResponse uploadPartResponse = s3Client.uploadPart(
                    uploadPartRequest, RequestBody.fromInputStream(partData, bytesRead));
                
                completedParts.add(CompletedPart.builder()
                    .partNumber(partNumber)
                    .eTag(uploadPartResponse.eTag())
                    .build());
                
                partNumber++;
            }
            
            // Complete multipart upload
            CompleteMultipartUploadRequest completeRequest = CompleteMultipartUploadRequest.builder()
                .bucket(bucketName)
                .key(key)
                .uploadId(uploadId)
                .multipartUpload(CompletedMultipartUpload.builder()
                    .parts(completedParts)
                    .build())
                .build();
            
            CompleteMultipartUploadResponse completeResponse = s3Client.completeMultipartUpload(completeRequest);
            
            return ObjectMetadata.builder()
                .bucketName(bucketName)
                .key(key)
                .eTag(completeResponse.eTag())
                .contentLength(options.getContentLength())
                .uploadId(uploadId)
                .build();
                
        } catch (Exception e) {
            // Abort multipart upload on failure
            AbortMultipartUploadRequest abortRequest = AbortMultipartUploadRequest.builder()
                .bucket(bucketName)
                .key(key)
                .uploadId(uploadId)
                .build();
            
            s3Client.abortMultipartUpload(abortRequest);
            throw new StorageException("Failed to upload large object", e);
        }
    }
    
    private ObjectMetadata uploadSmallObject(String bucketName, String key, 
                                           InputStream data, ObjectUploadOptions options) {
        
        PutObjectRequest putRequest = PutObjectRequest.builder()
            .bucket(bucketName)
            .key(key)
            .contentType(options.getContentType())
            .contentLength(options.getContentLength())
            .metadata(options.getMetadata())
            .serverSideEncryption(ServerSideEncryption.AES256)
            .storageClass(determineStorageClass(options))
            .build();
        
        try {
            PutObjectResponse putResponse = s3Client.putObject(
                putRequest, RequestBody.fromInputStream(data, options.getContentLength()));
            
            return ObjectMetadata.builder()
                .bucketName(bucketName)
                .key(key)
                .eTag(putResponse.eTag())
                .contentLength(options.getContentLength())
                .storageClass(putRequest.storageClass())
                .build();
                
        } catch (Exception e) {
            throw new StorageException("Failed to upload object", e);
        }
    }
    
    public ObjectData downloadObject(String bucketName, String key, DownloadOptions options) {
        Timer.Sample sample = storageMetrics.startDownloadTimer();
        
        try {
            GetObjectRequest.Builder requestBuilder = GetObjectRequest.builder()
                .bucket(bucketName)
                .key(key);
            
            // Add range request for partial downloads
            if (options.getRange() != null) {
                requestBuilder.range(options.getRange());
            }
            
            GetObjectRequest getRequest = requestBuilder.build();
            ResponseInputStream<GetObjectResponse> response = s3Client.getObject(getRequest);
            
            storageMetrics.recordDownload(bucketName, response.response().contentLength());
            
            return ObjectData.builder()
                .data(response)
                .metadata(response.response().metadata())
                .contentType(response.response().contentType())
                .contentLength(response.response().contentLength())
                .lastModified(response.response().lastModified())
                .eTag(response.response().eTag())
                .build();
                
        } finally {
            sample.stop();
        }
    }
    
    private StorageClass determineStorageClass(ObjectUploadOptions options) {
        if (options.isFrequentAccess()) {
            return StorageClass.STANDARD;
        } else if (options.isInfrequentAccess()) {
            return StorageClass.STANDARD_IA;
        } else if (options.isArchivalData()) {
            return StorageClass.GLACIER;
        } else {
            return StorageClass.INTELLIGENT_TIERING;
        }
    }
    
    // Implement lifecycle management
    public void configureLifecycle(String bucketName, LifecycleConfiguration lifecycle) {
        PutBucketLifecycleConfigurationRequest request = PutBucketLifecycleConfigurationRequest.builder()
            .bucket(bucketName)
            .lifecycleConfiguration(lifecycle)
            .build();
        
        s3Client.putBucketLifecycleConfiguration(request);
    }
    
    // Implement cross-region replication
    public void configureCrossRegionReplication(String bucketName, String destinationBucket, String roleArn) {
        ReplicationConfiguration replicationConfig = ReplicationConfiguration.builder()
            .role(roleArn)
            .rules(ReplicationRule.builder()
                .id("ReplicateEverything")
                .status(ReplicationRuleStatus.ENABLED)
                .prefix("")
                .destination(Destination.builder()
                    .bucket("arn:aws:s3:::" + destinationBucket)
                    .storageClass(ReplicationStorageClass.STANDARD_IA)
                    .build())
                .build())
            .build();
        
        PutBucketReplicationRequest request = PutBucketReplicationRequest.builder()
            .bucket(bucketName)
            .replicationConfiguration(replicationConfig)
            .build();
        
        s3Client.putBucketReplication(request);
    }
}
```

### 3. Block Storage Implementation

```java
// EBS-style block storage management
@Service
public class BlockStorageService {
    
    @Autowired
    private Ec2Client ec2Client;
    
    @Autowired
    private StorageMetrics storageMetrics;
    
    public Volume createVolume(VolumeCreationRequest request) {
        CreateVolumeRequest createRequest = CreateVolumeRequest.builder()
            .size(request.getSizeGB())
            .volumeType(determineVolumeType(request.getPerformanceRequirements()))
            .availabilityZone(request.getAvailabilityZone())
            .encrypted(true)
            .kmsKeyId(request.getKmsKeyId())
            .iops(calculateIops(request))
            .throughput(calculateThroughput(request))
            .tagSpecifications(TagSpecification.builder()
                .resourceType(ResourceType.VOLUME)
                .tags(request.getTags())
                .build())
            .build();
        
        CreateVolumeResponse response = ec2Client.createVolume(createRequest);
        
        // Wait for volume to be available
        waitForVolumeAvailable(response.volumeId());
        
        storageMetrics.recordVolumeCreation(response.volumeId(), request.getSizeGB());
        
        return Volume.builder()
            .volumeId(response.volumeId())
            .sizeGB(response.size())
            .volumeType(response.volumeType())
            .state(response.state())
            .availabilityZone(response.availabilityZone())
            .encrypted(response.encrypted())
            .build();
    }
    
    public void attachVolume(String volumeId, String instanceId, String device) {
        AttachVolumeRequest attachRequest = AttachVolumeRequest.builder()
            .volumeId(volumeId)
            .instanceId(instanceId)
            .device(device)
            .build();
        
        ec2Client.attachVolume(attachRequest);
        
        // Wait for attachment to complete
        waitForVolumeAttached(volumeId, instanceId);
        
        storageMetrics.recordVolumeAttachment(volumeId, instanceId);
    }
    
    public Snapshot createSnapshot(String volumeId, String description) {
        CreateSnapshotRequest snapshotRequest = CreateSnapshotRequest.builder()
            .volumeId(volumeId)
            .description(description)
            .tagSpecifications(TagSpecification.builder()
                .resourceType(ResourceType.SNAPSHOT)
                .tags(Tag.builder()
                    .key("CreatedBy")
                    .value("BlockStorageService")
                    .build())
                .build())
            .build();
        
        CreateSnapshotResponse response = ec2Client.createSnapshot(snapshotRequest);
        
        storageMetrics.recordSnapshotCreation(response.snapshotId(), volumeId);
        
        return Snapshot.builder()
            .snapshotId(response.snapshotId())
            .volumeId(response.volumeId())
            .state(response.state())
            .description(response.description())
            .startTime(response.startTime())
            .build();
    }
    
    public void resizeVolume(String volumeId, int newSizeGB) {
        ModifyVolumeRequest modifyRequest = ModifyVolumeRequest.builder()
            .volumeId(volumeId)
            .size(newSizeGB)
            .build();
        
        ec2Client.modifyVolume(modifyRequest);
        
        // Wait for modification to complete
        waitForVolumeModification(volumeId);
        
        storageMetrics.recordVolumeResize(volumeId, newSizeGB);
    }
    
    private VolumeType determineVolumeType(PerformanceRequirements requirements) {
        if (requirements.getIopsRequirement() > 16000) {
            return VolumeType.IO2; // High IOPS SSD
        } else if (requirements.getIopsRequirement() > 3000) {
            return VolumeType.GP3; // General Purpose SSD
        } else if (requirements.getThroughputRequirement() > 500) {
            return VolumeType.ST1; // Throughput Optimized HDD
        } else {
            return VolumeType.GP3; // Default to GP3
        }
    }
    
    private Integer calculateIops(VolumeCreationRequest request) {
        PerformanceRequirements perf = request.getPerformanceRequirements();
        
        if (perf.getIopsRequirement() != null) {
            return Math.min(perf.getIopsRequirement(), 64000); // Max IOPS limit
        }
        
        // Calculate based on volume size (3 IOPS per GB for GP3)
        return Math.min(request.getSizeGB() * 3, 16000);
    }
    
    private Integer calculateThroughput(VolumeCreationRequest request) {
        PerformanceRequirements perf = request.getPerformanceRequirements();
        
        if (perf.getThroughputRequirement() != null) {
            return Math.min(perf.getThroughputRequirement(), 1000); // Max throughput limit
        }
        
        // Default throughput based on volume type
        return 250; // MB/s
    }
    
    private void waitForVolumeAvailable(String volumeId) {
        // Implementation for waiting until volume is available
        // Use waiter pattern or polling
    }
    
    private void waitForVolumeAttached(String volumeId, String instanceId) {
        // Implementation for waiting until volume is attached
    }
    
    private void waitForVolumeModification(String volumeId) {
        // Implementation for waiting until volume modification is complete
    }
}
```

### 4. File Storage Implementation

```java
// EFS-style distributed file system
@Service
public class FileStorageService {
    
    @Autowired
    private EfsClient efsClient;
    
    @Autowired
    private StorageMetrics storageMetrics;
    
    public FileSystem createFileSystem(FileSystemCreationRequest request) {
        CreateFileSystemRequest createRequest = CreateFileSystemRequest.builder()
            .creationToken(UUID.randomUUID().toString())
            .performanceMode(determinePerformanceMode(request.getPerformanceRequirements()))
            .throughputMode(determineThroughputMode(request.getPerformanceRequirements()))
            .provisionedThroughputInMibps(request.getProvisionedThroughput())
            .encrypted(true)
            .kmsKeyId(request.getKmsKeyId())
            .tags(request.getTags())
            .build();
        
        CreateFileSystemResponse response = efsClient.createFileSystem(createRequest);
        
        // Wait for file system to be available
        waitForFileSystemAvailable(response.fileSystemId());
        
        storageMetrics.recordFileSystemCreation(response.fileSystemId());
        
        return FileSystem.builder()
            .fileSystemId(response.fileSystemId())
            .creationToken(response.creationToken())
            .lifecycleState(response.lifeCycleState())
            .performanceMode(response.performanceMode())
            .throughputMode(response.throughputMode())
            .encrypted(response.encrypted())
            .build();
    }
    
    public MountTarget createMountTarget(String fileSystemId, String subnetId, 
                                       List<String> securityGroups) {
        CreateMountTargetRequest mountRequest = CreateMountTargetRequest.builder()
            .fileSystemId(fileSystemId)
            .subnetId(subnetId)
            .securityGroups(securityGroups)
            .build();
        
        CreateMountTargetResponse response = efsClient.createMountTarget(mountRequest);
        
        // Wait for mount target to be available
        waitForMountTargetAvailable(response.mountTargetId());
        
        storageMetrics.recordMountTargetCreation(response.mountTargetId(), fileSystemId);
        
        return MountTarget.builder()
            .mountTargetId(response.mountTargetId())
            .fileSystemId(response.fileSystemId())
            .subnetId(response.subnetId())
            .ipAddress(response.ipAddress())
            .lifecycleState(response.lifeCycleState())
            .build();
    }
    
    public void configureLifecyclePolicy(String fileSystemId, LifecyclePolicyRequest request) {
        List<LifecyclePolicy> policies = new ArrayList<>();
        
        if (request.isInfrequentAccessEnabled()) {
            policies.add(LifecyclePolicy.builder()
                .transitionToIA(TransitionToIARules.AFTER_30_DAYS)
                .transitionToPrimaryStorageClass(TransitionToPrimaryStorageClassRules.AFTER_1_ACCESS)
                .build());
        }
        
        PutLifecycleConfigurationRequest lifecycleRequest = PutLifecycleConfigurationRequest.builder()
            .fileSystemId(fileSystemId)
            .lifecyclePolicies(policies)
            .build();
        
        efsClient.putLifecycleConfiguration(lifecycleRequest);
    }
    
    public FileSystemMetrics getFileSystemMetrics(String fileSystemId) {
        DescribeFileSystemsRequest request = DescribeFileSystemsRequest.builder()
            .fileSystemId(fileSystemId)
            .build();
        
        DescribeFileSystemsResponse response = efsClient.describeFileSystems(request);
        
        if (response.fileSystems().isEmpty()) {
            throw new FileSystemNotFoundException("File system not found: " + fileSystemId);
        }
        
        software.amazon.awssdk.services.efs.model.FileSystemDescription fs = response.fileSystems().get(0);
        
        return FileSystemMetrics.builder()
            .fileSystemId(fileSystemId)
            .sizeInBytes(fs.sizeInBytes().value())
            .sizeInStandard(fs.sizeInBytes().valueInStandard())
            .sizeInIA(fs.sizeInBytes().valueInIA())
            .numberOfMountTargets(fs.numberOfMountTargets())
            .performanceMode(fs.performanceMode())
            .throughputMode(fs.throughputMode())
            .build();
    }
    
    private PerformanceMode determinePerformanceMode(PerformanceRequirements requirements) {
        if (requirements.getMaxIOPS() > 7000) {
            return PerformanceMode.MAX_IO;
        } else {
            return PerformanceMode.GENERAL_PURPOSE;
        }
    }
    
    private ThroughputMode determineThroughputMode(PerformanceRequirements requirements) {
        if (requirements.getThroughputRequirement() != null && 
            requirements.getThroughputRequirement() > 100) {
            return ThroughputMode.PROVISIONED;
        } else {
            return ThroughputMode.BURSTING;
        }
    }
    
    private void waitForFileSystemAvailable(String fileSystemId) {
        // Implementation for waiting until file system is available
    }
    
    private void waitForMountTargetAvailable(String mountTargetId) {
        // Implementation for waiting until mount target is available
    }
}
```

---

## 💾 Storage Performance Optimization

### 1. Caching Strategies

```java
// Multi-tier storage caching
@Service
public class StorageCacheService {
    
    @Autowired
    private RedisTemplate<String, Object> redisTemplate;
    
    @Autowired
    private ObjectStorageService objectStorageService;
    
    @Autowired
    private LocalCacheManager localCacheManager;
    
    public byte[] getObject(String bucketName, String key) {
        // L1: Local cache (fastest, smallest)
        byte[] data = localCacheManager.get(key);
        if (data != null) {
            storageMetrics.recordCacheHit("local");
            return data;
        }
        
        // L2: Redis cache (fast, medium size)
        data = (byte[]) redisTemplate.opsForValue().get(key);
        if (data != null) {
            // Populate L1 cache
            localCacheManager.put(key, data, Duration.ofMinutes(5));
            storageMetrics.recordCacheHit("redis");
            return data;
        }
        
        // L3: Object storage (slow, unlimited size)
        ObjectData objectData = objectStorageService.downloadObject(bucketName, key, 
            DownloadOptions.builder().build());
        
        data = objectData.getData().readAllBytes();
        
        // Populate caches if object is small enough
        if (data.length < 1024 * 1024) { // < 1MB
            // Populate L2 cache
            redisTemplate.opsForValue().set(key, data, Duration.ofMinutes(30));
            
            // Populate L1 cache
            localCacheManager.put(key, data, Duration.ofMinutes(5));
        }
        
        storageMetrics.recordCacheMiss();
        return data;
    }
    
    public void putObject(String bucketName, String key, byte[] data) {
        // Store in object storage
        objectStorageService.uploadObject(bucketName, key, 
            new ByteArrayInputStream(data), 
            ObjectUploadOptions.builder()
                .contentLength((long) data.length)
                .build());
        
        // Update caches
        if (data.length < 1024 * 1024) { // < 1MB
            redisTemplate.opsForValue().set(key, data, Duration.ofMinutes(30));
            localCacheManager.put(key, data, Duration.ofMinutes(5));
        }
    }
    
    public void invalidateCache(String key) {
        localCacheManager.evict(key);
        redisTemplate.delete(key);
    }
}

// Local cache implementation
@Component
public class LocalCacheManager {
    
    private final Cache<String, CacheEntry> cache;
    
    public LocalCacheManager() {
        this.cache = Caffeine.newBuilder()
            .maximumSize(1000)
            .expireAfterWrite(Duration.ofMinutes(10))
            .recordStats()
            .build();
    }
    
    public byte[] get(String key) {
        CacheEntry entry = cache.getIfPresent(key);
        if (entry != null && !entry.isExpired()) {
            return entry.getData();
        }
        return null;
    }
    
    public void put(String key, byte[] data, Duration ttl) {
        CacheEntry entry = new CacheEntry(data, Instant.now().plus(ttl));
        cache.put(key, entry);
    }
    
    public void evict(String key) {
        cache.invalidate(key);
    }
    
    public CacheStats getStats() {
        return cache.stats();
    }
    
    private static class CacheEntry {
        private final byte[] data;
        private final Instant expiryTime;
        
        public CacheEntry(byte[] data, Instant expiryTime) {
            this.data = data;
            this.expiryTime = expiryTime;
        }
        
        public byte[] getData() { return data; }
        public boolean isExpired() { return Instant.now().isAfter(expiryTime); }
    }
}
```

### 2. Storage Compression and Deduplication

```java
// Storage optimization service
@Service
public class StorageOptimizationService {
    
    @Autowired
    private ObjectStorageService objectStorageService;
    
    public ObjectMetadata uploadWithCompression(String bucketName, String key, 
                                              InputStream data, ObjectUploadOptions options) {
        
        // Determine if compression is beneficial
        if (shouldCompress(options)) {
            try (ByteArrayOutputStream compressedOutput = new ByteArrayOutputStream();
                 GZIPOutputStream gzipOutput = new GZIPOutputStream(compressedOutput)) {
                
                data.transferTo(gzipOutput);
                gzipOutput.finish();
                
                byte[] compressedData = compressedOutput.toByteArray();
                
                // Only use compression if it reduces size significantly
                if (compressedData.length < options.getContentLength() * 0.9) {
                    ObjectUploadOptions compressedOptions = options.toBuilder()
                        .contentLength((long) compressedData.length)
                        .contentEncoding("gzip")
                        .addMetadata("original-size", String.valueOf(options.getContentLength()))
                        .build();
                    
                    return objectStorageService.uploadObject(bucketName, key, 
                        new ByteArrayInputStream(compressedData), compressedOptions);
                }
            } catch (IOException e) {
                log.warn("Compression failed, uploading original data", e);
            }
        }
        
        // Upload without compression
        return objectStorageService.uploadObject(bucketName, key, data, options);
    }
    
    public DeduplicationResult deduplicateData(String bucketName, String key, 
                                             byte[] data, ObjectUploadOptions options) {
        
        // Calculate hash of the data
        String contentHash = calculateSHA256Hash(data);
        
        // Check if we already have this content
        String existingKey = findExistingContent(bucketName, contentHash);
        if (existingKey != null) {
            // Create a reference instead of storing duplicate data
            createContentReference(bucketName, key, existingKey, contentHash);
            
            return DeduplicationResult.builder()
                .isDuplicate(true)
                .existingKey(existingKey)
                .contentHash(contentHash)
                .spacesSaved(data.length)
                .build();
        }
        
        // Store the new content with hash metadata
        ObjectUploadOptions enhancedOptions = options.toBuilder()
            .addMetadata("content-hash", contentHash)
            .addMetadata("dedup-original", "true")
            .build();
        
        ObjectMetadata metadata = objectStorageService.uploadObject(bucketName, key, 
            new ByteArrayInputStream(data), enhancedOptions);
        
        // Index the content hash for future deduplication
        indexContentHash(bucketName, key, contentHash);
        
        return DeduplicationResult.builder()
            .isDuplicate(false)
            .contentHash(contentHash)
            .metadata(metadata)
            .build();
    }
    
    private boolean shouldCompress(ObjectUploadOptions options) {
        String contentType = options.getContentType();
        
        // Don't compress already compressed formats
        if (contentType != null) {
            String lowerContentType = contentType.toLowerCase();
            if (lowerContentType.contains("image/") || 
                lowerContentType.contains("video/") ||
                lowerContentType.contains("audio/") ||
                lowerContentType.contains("zip") ||
                lowerContentType.contains("gzip")) {
                return false;
            }
        }
        
        // Compress text-based content
        return options.getContentLength() > 1024; // Only compress files > 1KB
    }
    
    private String calculateSHA256Hash(byte[] data) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(data);
            return Base64.getEncoder().encodeToString(hash);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-256 algorithm not available", e);
        }
    }
    
    private String findExistingContent(String bucketName, String contentHash) {
        // Query content index (could be in database, Redis, etc.)
        return contentIndexService.findByHash(bucketName, contentHash);
    }
    
    private void createContentReference(String bucketName, String key, 
                                      String existingKey, String contentHash) {
        // Create a lightweight reference object
        String referenceData = STR."""
            {
                "type": "content-reference",
                "target": "\{existingKey}",
                "hash": "\{contentHash}",
                "created": "\{Instant.now()}"
            }
            """;
        
        ObjectUploadOptions referenceOptions = ObjectUploadOptions.builder()
            .contentType("application/json")
            .contentLength((long) referenceData.length())
            .addMetadata("content-type", "reference")
            .addMetadata("target-key", existingKey)
            .build();
        
        objectStorageService.uploadObject(bucketName, key, 
            new ByteArrayInputStream(referenceData.getBytes()), referenceOptions);
    }
    
    private void indexContentHash(String bucketName, String key, String contentHash) {
        contentIndexService.indexContent(bucketName, key, contentHash);
    }
}
```

---

## 🔄 Backup and Disaster Recovery

### 1. Automated Backup Strategy

```java
// Comprehensive backup service
@Service
public class BackupService {
    
    @Autowired
    private ObjectStorageService objectStorageService;
    
    @Autowired
    private BlockStorageService blockStorageService;
    
    @Autowired
    private DatabaseService databaseService;
    
    @Autowired
    private BackupMetrics backupMetrics;
    
    @Scheduled(cron = "0 0 2 * * *") // Daily at 2 AM
    public void performDailyBackup() {
        BackupJob job = BackupJob.builder()
            .jobId(UUID.randomUUID().toString())
            .type(BackupType.DAILY)
            .startTime(Instant.now())
            .build();
        
        try {
            log.info("Starting daily backup job: {}", job.getJobId());
            
            // Backup databases
            List<DatabaseBackupResult> dbBackups = backupDatabases();
            
            // Backup volumes
            List<VolumeBackupResult> volumeBackups = backupVolumes();
            
            // Backup application data
            ApplicationBackupResult appBackup = backupApplicationData();
            
            // Store backup metadata
            BackupManifest manifest = BackupManifest.builder()
                .jobId(job.getJobId())
                .backupTime(job.getStartTime())
                .databaseBackups(dbBackups)
                .volumeBackups(volumeBackups)
                .applicationBackup(appBackup)
                .retentionPolicy(RetentionPolicy.DAILY_30_DAYS)
                .build();
            
            storeBackupManifest(manifest);
            
            backupMetrics.recordSuccessfulBackup(job.getType(), 
                Duration.between(job.getStartTime(), Instant.now()));
            
            log.info("Daily backup completed successfully: {}", job.getJobId());
            
        } catch (Exception e) {
            backupMetrics.recordFailedBackup(job.getType(), e);
            log.error("Daily backup failed: {}", job.getJobId(), e);
            
            // Send alert
            alertService.sendBackupFailureAlert(job.getJobId(), e);
        }
    }
    
    private List<DatabaseBackupResult> backupDatabases() {
        List<DatabaseBackupResult> results = new ArrayList<>();
        
        // Backup primary database
        DatabaseBackupResult primaryBackup = databaseService.createBackup(
            "primary-db", 
            BackupOptions.builder()
                .type(BackupType.FULL)
                .encryption(true)
                .compression(true)
                .build()
        );
        results.add(primaryBackup);
        
        // Backup Redis cache (optional)
        if (isRedisBackupEnabled()) {
            DatabaseBackupResult redisBackup = createRedisBackup();
            results.add(redisBackup);
        }
        
        return results;
    }
    
    private List<VolumeBackupResult> backupVolumes() {
        List<VolumeBackupResult> results = new ArrayList<>();
        
        // Get all volumes that need backup
        List<Volume> volumes = blockStorageService.getVolumesForBackup();
        
        for (Volume volume : volumes) {
            try {
                Snapshot snapshot = blockStorageService.createSnapshot(
                    volume.getVolumeId(), 
                    STR."Daily backup - \{Instant.now()}"
                );
                
                VolumeBackupResult result = VolumeBackupResult.builder()
                    .volumeId(volume.getVolumeId())
                    .snapshotId(snapshot.getSnapshotId())
                    .backupTime(Instant.now())
                    .sizeGB(volume.getSizeGB())
                    .build();
                
                results.add(result);
                
            } catch (Exception e) {
                log.error("Failed to backup volume: {}", volume.getVolumeId(), e);
                // Continue with other volumes
            }
        }
        
        return results;
    }
    
    private ApplicationBackupResult backupApplicationData() {
        // Backup application configuration
        String configBackupKey = STR."backups/config/\{Instant.now()}/app-config.json";
        ConfigurationBackup configBackup = createConfigurationBackup();
        
        objectStorageService.uploadObject(
            "backup-bucket", 
            configBackupKey,
            new ByteArrayInputStream(configBackup.toJson().getBytes()),
            ObjectUploadOptions.builder()
                .contentType("application/json")
                .contentLength((long) configBackup.toJson().length())
                .addMetadata("backup-type", "configuration")
                .build()
        );
        
        // Backup user-uploaded files
        String filesBackupKey = STR."backups/files/\{Instant.now()}/";
        UserFilesBackupResult filesBackup = backupUserFiles(filesBackupKey);
        
        return ApplicationBackupResult.builder()
            .configBackupKey(configBackupKey)
            .filesBackupResult(filesBackup)
            .backupTime(Instant.now())
            .build();
    }
    
    public RestoreResult restoreFromBackup(String backupJobId, RestoreOptions options) {
        BackupManifest manifest = getBackupManifest(backupJobId);
        
        if (manifest == null) {
            throw new BackupNotFoundException("Backup not found: " + backupJobId);
        }
        
        RestoreJob restoreJob = RestoreJob.builder()
            .jobId(UUID.randomUUID().toString())
            .sourceBackupId(backupJobId)
            .restoreTime(Instant.now())
            .options(options)
            .build();
        
        try {
            log.info("Starting restore job: {} from backup: {}", 
                restoreJob.getJobId(), backupJobId);
            
            if (options.isRestoreDatabases()) {
                restoreDatabases(manifest.getDatabaseBackups(), options);
            }
            
            if (options.isRestoreVolumes()) {
                restoreVolumes(manifest.getVolumeBackups(), options);
            }
            
            if (options.isRestoreApplicationData()) {
                restoreApplicationData(manifest.getApplicationBackup(), options);
            }
            
            log.info("Restore completed successfully: {}", restoreJob.getJobId());
            
            return RestoreResult.builder()
                .restoreJobId(restoreJob.getJobId())
                .success(true)
                .restoredItems(calculateRestoredItems(manifest, options))
                .build();
            
        } catch (Exception e) {
            log.error("Restore failed: {}", restoreJob.getJobId(), e);
            
            return RestoreResult.builder()
                .restoreJobId(restoreJob.getJobId())
                .success(false)
                .error(e.getMessage())
                .build();
        }
    }
    
    @Scheduled(cron = "0 0 3 * * SUN") // Weekly cleanup
    public void cleanupOldBackups() {
        log.info("Starting backup cleanup process");
        
        List<BackupManifest> allBackups = getAllBackupManifests();
        List<BackupManifest> expiredBackups = allBackups.stream()
            .filter(this::isBackupExpired)
            .toList();
        
        for (BackupManifest backup : expiredBackups) {
            try {
                deleteBackup(backup);
                log.info("Deleted expired backup: {}", backup.getJobId());
            } catch (Exception e) {
                log.error("Failed to delete backup: {}", backup.getJobId(), e);
            }
        }
        
        log.info("Backup cleanup completed. Deleted {} backups", expiredBackups.size());
    }
    
    private boolean isBackupExpired(BackupManifest backup) {
        Instant expiryDate = backup.getBackupTime().plus(
            backup.getRetentionPolicy().getRetentionPeriod()
        );
        return Instant.now().isAfter(expiryDate);
    }
}
```

---

## 📊 Storage Monitoring and Metrics

### 1. Storage Performance Monitoring

```java
@Component
public class StorageMetrics {
    
    private final Counter uploadCounter;
    private final Counter downloadCounter;
    private final Timer uploadTimer;
    private final Timer downloadTimer;
    private final Gauge storageUtilization;
    private final Counter errorCounter;
    
    public StorageMetrics(MeterRegistry meterRegistry) {
        this.uploadCounter = Counter.builder("storage.uploads.total")
            .description("Total storage uploads")
            .register(meterRegistry);
            
        this.downloadCounter = Counter.builder("storage.downloads.total")
            .description("Total storage downloads")
            .register(meterRegistry);
            
        this.uploadTimer = Timer.builder("storage.upload.duration")
            .description("Storage upload duration")
            .register(meterRegistry);
            
        this.downloadTimer = Timer.builder("storage.download.duration")
            .description("Storage download duration")
            .register(meterRegistry);
            
        this.storageUtilization = Gauge.builder("storage.utilization.percent")
            .description("Storage utilization percentage")
            .register(meterRegistry, this, StorageMetrics::calculateStorageUtilization);
            
        this.errorCounter = Counter.builder("storage.errors.total")
            .description("Total storage errors")
            .register(meterRegistry);
    }
    
    public Timer.Sample startUploadTimer() {
        return Timer.start();
    }
    
    public Timer.Sample startDownloadTimer() {
        return Timer.start();
    }
    
    public void recordUpload(String bucket, long sizeBytes) {
        uploadCounter.increment(
            Tags.of(
                "bucket", bucket,
                "size_category", getSizeCategory(sizeBytes)
            )
        );
    }
    
    public void recordDownload(String bucket, long sizeBytes) {
        downloadCounter.increment(
            Tags.of(
                "bucket", bucket,
                "size_category", getSizeCategory(sizeBytes)
            )
        );
    }
    
    public void recordError(String operation, String errorType) {
        errorCounter.increment(
            Tags.of(
                "operation", operation,
                "error_type", errorType
            )
        );
    }
    
    private String getSizeCategory(long sizeBytes) {
        if (sizeBytes < 1024) return "small";
        else if (sizeBytes < 1024 * 1024) return "medium";
        else if (sizeBytes < 100 * 1024 * 1024) return "large";
        else return "xlarge";
    }
    
    private double calculateStorageUtilization() {
        // Calculate based on actual storage usage
        return storageUsageService.getCurrentUtilizationPercentage();
    }
}
```

---

## 🎯 Interview Focus Areas

### Key Storage Questions

**Q: How do you choose between different storage types?**
- **Access patterns**: Random vs sequential
- **Performance requirements**: IOPS, throughput, latency
- **Durability needs**: Replication, backup requirements
- **Cost considerations**: Storage class, lifecycle policies

**Q: How do you design a globally distributed storage system?**
- **CDN integration** for global content delivery
- **Cross-region replication** for disaster recovery
- **Data locality** for compliance and performance
- **Consistency models** across regions

**Q: How do you handle storage failures?**
- **Redundancy strategies**: RAID, replication
- **Backup and restore** procedures
- **Monitoring and alerting** systems
- **Graceful degradation** patterns

**Q: How do you optimize storage costs?**
- **Lifecycle policies** for automatic tiering
- **Compression and deduplication**
- **Storage class selection** based on access patterns
- **Capacity planning** and rightsizing

---

## 🚀 Next Steps

1. **Complete the hands-on exercises** in the exercises folder
2. **Practice storage selection** using the decision framework
3. **Implement backup strategies** for critical data
4. **Set up monitoring** for storage performance
5. **Move to Module 4: Database Systems**

The storage module provides the foundation for building data-intensive applications with proper storage architecture, performance optimization, and disaster recovery capabilities.
