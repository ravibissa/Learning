# Module 12: Cloud Architecture with AWS

## ☁️ Building Scalable Systems on AWS

### 📚 Learning Objectives

By the end of this module, you will:
- Design cloud-native architectures using AWS services
- Implement serverless patterns with Lambda and API Gateway
- Build scalable data pipelines with AWS data services
- Design for high availability and disaster recovery
- Implement Infrastructure as Code with CloudFormation/CDK
- Optimize costs and performance in cloud environments

---

## 🏗️ AWS Core Services for System Design

### 1. Compute Services Architecture

```java
// AWS Lambda functions with Spring Cloud Function
@Component
public class AWSLambdaFunctions {
    
    /**
     * Order processing Lambda function
     */
    @Bean
    public Function<OrderEvent, OrderProcessingResult> processOrder() {
        return orderEvent -> {
            try {
                log.info("Processing order: {}", orderEvent.getOrderId());
                
                // Validate order
                if (!isValidOrder(orderEvent)) {
                    return OrderProcessingResult.failure("Invalid order data");
                }
                
                // Process payment
                PaymentResult paymentResult = processPayment(orderEvent);
                if (!paymentResult.isSuccess()) {
                    return OrderProcessingResult.failure("Payment failed: " + paymentResult.getErrorMessage());
                }
                
                // Update inventory
                InventoryResult inventoryResult = updateInventory(orderEvent);
                if (!inventoryResult.isSuccess()) {
                    // Compensate payment
                    refundPayment(paymentResult.getTransactionId());
                    return OrderProcessingResult.failure("Inventory update failed");
                }
                
                // Send confirmation
                sendOrderConfirmation(orderEvent);
                
                return OrderProcessingResult.success(orderEvent.getOrderId());
                
            } catch (Exception e) {
                log.error("Error processing order: {}", orderEvent.getOrderId(), e);
                return OrderProcessingResult.failure("Internal error: " + e.getMessage());
            }
        };
    }
    
    /**
     * Image processing Lambda function
     */
    @Bean
    public Function<S3Event, ImageProcessingResult> processImage() {
        return s3Event -> {
            try {
                for (S3EventNotification.S3EventNotificationRecord record : s3Event.getRecords()) {
                    String bucketName = record.getS3().getBucket().getName();
                    String objectKey = record.getS3().getObject().getKey();
                    
                    log.info("Processing image: s3://{}/{}", bucketName, objectKey);
                    
                    // Download image from S3
                    S3Object s3Object = s3Client.getObject(bucketName, objectKey);
                    InputStream imageStream = s3Object.getObjectContent();
                    
                    // Process image (resize, optimize, etc.)
                    List<ProcessedImage> processedImages = processImageVariants(imageStream, objectKey);
                    
                    // Upload processed images back to S3
                    for (ProcessedImage processedImage : processedImages) {
                        String processedKey = STR."processed/\{processedImage.getVariant()}/\{objectKey}";
                        
                        s3Client.putObject(PutObjectRequest.builder()
                            .bucket(bucketName)
                            .key(processedKey)
                            .contentType(processedImage.getContentType())
                            .metadata(Map.of(
                                "original-key", objectKey,
                                "variant", processedImage.getVariant(),
                                "size", String.valueOf(processedImage.getSize())
                            ))
                            .build(), 
                            RequestBody.fromBytes(processedImage.getData()));
                    }
                    
                    // Update database with processed image URLs
                    updateImageMetadata(objectKey, processedImages);
                    
                    // Send completion notification
                    snsClient.publish(PublishRequest.builder()
                        .topicArn(imageProcessingTopicArn)
                        .message(STR."""
                            {
                                "originalKey": "\{objectKey}",
                                "processedVariants": \{processedImages.size()},
                                "status": "completed",
                                "timestamp": "\{Instant.now()}"
                            }
                            """)
                        .build());
                }
                
                return ImageProcessingResult.success(s3Event.getRecords().size());
                
            } catch (Exception e) {
                log.error("Error processing images", e);
                return ImageProcessingResult.failure(e.getMessage());
            }
        };
    }
    
    /**
     * Real-time analytics Lambda function triggered by Kinesis
     */
    @Bean
    public Function<KinesisEvent, AnalyticsResult> processAnalytics() {
        return kinesisEvent -> {
            try {
                List<AnalyticsRecord> records = new ArrayList<>();
                
                for (KinesisEvent.KinesisEventRecord record : kinesisEvent.getRecords()) {
                    // Decode base64 data
                    String data = new String(Base64.getDecoder().decode(
                        record.getKinesis().getData().array()));
                    
                    // Parse JSON event
                    AnalyticsEvent event = objectMapper.readValue(data, AnalyticsEvent.class);
                    
                    // Enrich event data
                    AnalyticsRecord enrichedRecord = enrichAnalyticsEvent(event);
                    records.add(enrichedRecord);
                }
                
                // Batch write to DynamoDB
                batchWriteAnalyticsRecords(records);
                
                // Update real-time metrics
                updateRealTimeMetrics(records);
                
                // Check for anomalies
                checkForAnomalies(records);
                
                return AnalyticsResult.success(records.size());
                
            } catch (Exception e) {
                log.error("Error processing analytics", e);
                return AnalyticsResult.failure(e.getMessage());
            }
        };
    }
    
    /**
     * Scheduled Lambda function for data cleanup
     */
    @Bean
    public Supplier<CleanupResult> scheduleCleanup() {
        return () -> {
            try {
                log.info("Starting scheduled data cleanup");
                
                // Clean up expired sessions
                int expiredSessions = cleanupExpiredSessions();
                
                // Archive old logs
                int archivedLogs = archiveOldLogs();
                
                // Delete temporary files
                int deletedFiles = deleteTemporaryFiles();
                
                // Compact DynamoDB tables
                compactDynamoDBTables();
                
                // Update CloudWatch metrics
                cloudWatchClient.putMetricData(PutMetricDataRequest.builder()
                    .namespace("SystemDesign/Cleanup")
                    .metricData(
                        MetricDatum.builder()
                            .metricName("ExpiredSessionsCleanup")
                            .value((double) expiredSessions)
                            .unit(StandardUnit.COUNT)
                            .timestamp(Instant.now())
                            .build(),
                        MetricDatum.builder()
                            .metricName("ArchivedLogs")
                            .value((double) archivedLogs)
                            .unit(StandardUnit.COUNT)
                            .timestamp(Instant.now())
                            .build(),
                        MetricDatum.builder()
                            .metricName("DeletedTempFiles")
                            .value((double) deletedFiles)
                            .unit(StandardUnit.COUNT)
                            .timestamp(Instant.now())
                            .build()
                    )
                    .build());
                
                return CleanupResult.success(expiredSessions, archivedLogs, deletedFiles);
                
            } catch (Exception e) {
                log.error("Error during scheduled cleanup", e);
                return CleanupResult.failure(e.getMessage());
            }
        };
    }
    
    private boolean isValidOrder(OrderEvent orderEvent) {
        return orderEvent.getOrderId() != null && 
               orderEvent.getUserId() != null && 
               orderEvent.getItems() != null && 
               !orderEvent.getItems().isEmpty() &&
               orderEvent.getTotalAmount() != null &&
               orderEvent.getTotalAmount().compareTo(BigDecimal.ZERO) > 0;
    }
    
    private PaymentResult processPayment(OrderEvent orderEvent) {
        // Integrate with payment service (Stripe, PayPal, etc.)
        return paymentService.processPayment(PaymentRequest.builder()
            .orderId(orderEvent.getOrderId())
            .amount(orderEvent.getTotalAmount())
            .paymentMethodId(orderEvent.getPaymentMethodId())
            .build());
    }
    
    private InventoryResult updateInventory(OrderEvent orderEvent) {
        // Update inventory for each item
        for (OrderItem item : orderEvent.getItems()) {
            InventoryResult result = inventoryService.reserveItem(
                item.getProductId(), item.getQuantity());
            
            if (!result.isSuccess()) {
                return result;
            }
        }
        
        return InventoryResult.success();
    }
    
    private List<ProcessedImage> processImageVariants(InputStream imageStream, String originalKey) {
        List<ProcessedImage> variants = new ArrayList<>();
        
        try {
            BufferedImage originalImage = ImageIO.read(imageStream);
            
            // Create different size variants
            Map<String, Dimension> variants = Map.of(
                "thumbnail", new Dimension(150, 150),
                "small", new Dimension(300, 300),
                "medium", new Dimension(600, 600),
                "large", new Dimension(1200, 1200)
            );
            
            for (Map.Entry<String, Dimension> variant : variants.entrySet()) {
                BufferedImage resizedImage = resizeImage(originalImage, variant.getValue());
                byte[] imageData = imageToByteArray(resizedImage, "JPEG");
                
                variants.add(ProcessedImage.builder()
                    .variant(variant.getKey())
                    .data(imageData)
                    .size(imageData.length)
                    .contentType("image/jpeg")
                    .dimensions(variant.getValue())
                    .build());
            }
            
        } catch (Exception e) {
            log.error("Error processing image variants for: {}", originalKey, e);
        }
        
        return variants;
    }
    
    private AnalyticsRecord enrichAnalyticsEvent(AnalyticsEvent event) {
        return AnalyticsRecord.builder()
            .eventId(UUID.randomUUID().toString())
            .userId(event.getUserId())
            .eventType(event.getEventType())
            .eventData(event.getEventData())
            .timestamp(event.getTimestamp())
            .sessionId(event.getSessionId())
            .userAgent(event.getUserAgent())
            .ipAddress(event.getIpAddress())
            .geolocation(geoLocationService.getLocation(event.getIpAddress()))
            .userSegment(userSegmentationService.getUserSegment(event.getUserId()))
            .deviceType(deviceDetectionService.getDeviceType(event.getUserAgent()))
            .build();
    }
}
```

### 2. Database Services Integration

```java
// AWS database services integration
@Service
public class AWSDatabaseService {
    
    /**
     * DynamoDB integration with Spring Data
     */
    @Repository
    public interface UserSessionRepository extends CrudRepository<UserSession, String> {
        
        @Query("SELECT * FROM user_sessions WHERE userId = :userId AND expiresAt > :currentTime")
        List<UserSession> findActiveSessionsByUserId(@Param("userId") String userId, 
                                                    @Param("currentTime") Instant currentTime);
        
        @Query("SELECT * FROM user_sessions WHERE expiresAt < :expirationTime")
        List<UserSession> findExpiredSessions(@Param("expirationTime") Instant expirationTime);
    }
    
    @DynamoDBTable(tableName = "user-sessions")
    public static class UserSession {
        
        @DynamoDBHashKey
        private String sessionId;
        
        @DynamoDBAttribute
        private String userId;
        
        @DynamoDBAttribute
        private String ipAddress;
        
        @DynamoDBAttribute
        private String userAgent;
        
        @DynamoDBAttribute
        private Instant createdAt;
        
        @DynamoDBAttribute
        private Instant expiresAt;
        
        @DynamoDBAttribute
        private Instant lastAccessedAt;
        
        @DynamoDBIndexHashKey(globalSecondaryIndexName = "user-id-index")
        public String getUserId() { return userId; }
        
        @DynamoDBIndexRangeKey(globalSecondaryIndexName = "expiration-index")
        public Instant getExpiresAt() { return expiresAt; }
        
        // Getters and setters...
    }
    
    /**
     * RDS integration with advanced patterns
     */
    @Component
    public static class RDSIntegrationService {
        
        @Autowired
        @Qualifier("primaryDataSource")
        private DataSource primaryDataSource;
        
        @Autowired
        @Qualifier("replicaDataSource") 
        private DataSource replicaDataSource;
        
        @Autowired
        private JdbcTemplate primaryJdbcTemplate;
        
        @Autowired
        private JdbcTemplate replicaJdbcTemplate;
        
        // Read-write splitting
        @Transactional
        public void writeToDatabase(String sql, Object... params) {
            primaryJdbcTemplate.update(sql, params);
        }
        
        @Transactional(readOnly = true)
        public <T> List<T> readFromDatabase(String sql, RowMapper<T> rowMapper, Object... params) {
            return replicaJdbcTemplate.query(sql, rowMapper, params);
        }
        
        // Connection pooling optimization
        @EventListener
        public void optimizeConnectionPool(DatabaseMetricsEvent event) {
            if (event.getConnectionUtilization() > 0.8) {
                // Scale up connection pool
                HikariDataSource hikariDataSource = (HikariDataSource) primaryDataSource;
                int currentSize = hikariDataSource.getMaximumPoolSize();
                int newSize = Math.min(currentSize + 5, 50); // Cap at 50
                
                hikariDataSource.setMaximumPoolSize(newSize);
                log.info("Increased connection pool size from {} to {}", currentSize, newSize);
            }
        }
        
        // Database sharding implementation
        @Service
        public static class DatabaseShardingService {
            
            private final Map<String, DataSource> shards;
            
            public DatabaseShardingService() {
                this.shards = Map.of(
                    "shard1", createDataSource("shard1-endpoint"),
                    "shard2", createDataSource("shard2-endpoint"),
                    "shard3", createDataSource("shard3-endpoint"),
                    "shard4", createDataSource("shard4-endpoint")
                );
            }
            
            public String determineShardKey(String userId) {
                // Consistent hashing for shard determination
                int hash = userId.hashCode();
                int shardIndex = Math.abs(hash) % shards.size();
                return STR."shard\{shardIndex + 1}";
            }
            
            public DataSource getShardDataSource(String userId) {
                String shardKey = determineShardKey(userId);
                return shards.get(shardKey);
            }
            
            public <T> T executeOnShard(String userId, ShardOperation<T> operation) {
                DataSource shardDataSource = getShardDataSource(userId);
                JdbcTemplate shardJdbcTemplate = new JdbcTemplate(shardDataSource);
                
                return operation.execute(shardJdbcTemplate, userId);
            }
            
            public <T> List<T> executeOnAllShards(ShardOperation<List<T>> operation) {
                List<T> results = new ArrayList<>();
                
                for (Map.Entry<String, DataSource> shard : shards.entrySet()) {
                    JdbcTemplate shardJdbcTemplate = new JdbcTemplate(shard.getValue());
                    List<T> shardResults = operation.execute(shardJdbcTemplate, shard.getKey());
                    results.addAll(shardResults);
                }
                
                return results;
            }
            
            private DataSource createDataSource(String endpoint) {
                HikariConfig config = new HikariConfig();
                config.setJdbcUrl(STR."jdbc:postgresql://\{endpoint}:5432/systemdesign");
                config.setUsername("${database.username}");
                config.setPassword("${database.password}");
                config.setMaximumPoolSize(20);
                config.setMinimumIdle(5);
                config.setConnectionTimeout(30000);
                config.setIdleTimeout(600000);
                config.setMaxLifetime(1800000);
                
                return new HikariDataSource(config);
            }
        }
        
        @FunctionalInterface
        public interface ShardOperation<T> {
            T execute(JdbcTemplate jdbcTemplate, String shardKey);
        }
    }
    
    /**
     * ElastiCache integration for distributed caching
     */
    @Component
    public static class ElastiCacheService {
        
        @Autowired
        private RedisClusterTemplate<String, Object> redisClusterTemplate;
        
        @Autowired
        private RedisTemplate<String, Object> redisTemplate;
        
        public void cacheUserSession(String sessionId, UserSession session) {
            String key = STR."session:\{sessionId}";
            redisTemplate.opsForValue().set(key, session, Duration.ofHours(24));
            
            // Also cache by user ID for quick lookup
            String userKey = STR."user:sessions:\{session.getUserId()}";
            redisTemplate.opsForSet().add(userKey, sessionId);
            redisTemplate.expire(userKey, Duration.ofHours(24));
        }
        
        public Optional<UserSession> getUserSession(String sessionId) {
            String key = STR."session:\{sessionId}";
            UserSession session = (UserSession) redisTemplate.opsForValue().get(key);
            return Optional.ofNullable(session);
        }
        
        public Set<String> getUserSessions(String userId) {
            String userKey = STR."user:sessions:\{userId}";
            return redisTemplate.opsForSet().members(userKey);
        }
        
        public void invalidateUserSession(String sessionId) {
            String key = STR."session:\{sessionId}";
            UserSession session = (UserSession) redisTemplate.opsForValue().get(key);
            
            if (session != null) {
                // Remove session
                redisTemplate.delete(key);
                
                // Remove from user's session set
                String userKey = STR."user:sessions:\{session.getUserId()}";
                redisTemplate.opsForSet().remove(userKey, sessionId);
            }
        }
        
        // Distributed locking with Redis
        public boolean acquireDistributedLock(String lockKey, String lockValue, Duration ttl) {
            Boolean acquired = redisTemplate.opsForValue().setIfAbsent(
                STR."lock:\{lockKey}", lockValue, ttl);
            
            return Boolean.TRUE.equals(acquired);
        }
        
        public void releaseDistributedLock(String lockKey, String lockValue) {
            // Use Lua script for atomic check-and-delete
            String luaScript = """
                if redis.call('GET', KEYS[1]) == ARGV[1] then
                    return redis.call('DEL', KEYS[1])
                else
                    return 0
                end
                """;
            
            redisTemplate.execute(new DefaultRedisScript<>(luaScript, Long.class),
                List.of(STR."lock:\{lockKey}"), lockValue);
        }
        
        // Cache warming strategies
        @EventListener
        public void warmCache(ApplicationReadyEvent event) {
            log.info("Starting cache warming");
            
            // Warm popular user data
            List<String> popularUsers = getPopularUsers();
            for (String userId : popularUsers) {
                UserProfile profile = userService.getUserProfile(userId);
                cacheUserProfile(userId, profile);
            }
            
            // Warm popular product data
            List<String> popularProducts = getPopularProducts();
            for (String productId : popularProducts) {
                Product product = productService.getProduct(productId);
                cacheProduct(productId, product);
            }
            
            log.info("Cache warming completed");
        }
        
        private void cacheUserProfile(String userId, UserProfile profile) {
            String key = STR."user:profile:\{userId}";
            redisTemplate.opsForValue().set(key, profile, Duration.ofHours(1));
        }
        
        private void cacheProduct(String productId, Product product) {
            String key = STR."product:\{productId}";
            redisTemplate.opsForValue().set(key, product, Duration.ofMinutes(30));
        }
    }
}
```

### 3. Event-Driven Architecture with AWS Services

```java
// Event-driven architecture using AWS services
@Service
public class AWSEventDrivenService {
    
    /**
     * SNS/SQS integration for reliable messaging
     */
    @Component
    public static class EventPublishingService {
        
        @Autowired
        private SnsClient snsClient;
        
        @Autowired
        private SqsClient sqsClient;
        
        @Value("${aws.sns.topic.user-events}")
        private String userEventsTopicArn;
        
        @Value("${aws.sns.topic.order-events}")
        private String orderEventsTopicArn;
        
        public void publishUserEvent(UserEvent event) {
            try {
                String message = objectMapper.writeValueAsString(event);
                
                PublishRequest request = PublishRequest.builder()
                    .topicArn(userEventsTopicArn)
                    .message(message)
                    .messageAttributes(Map.of(
                        "eventType", MessageAttributeValue.builder()
                            .stringValue(event.getEventType())
                            .dataType("String")
                            .build(),
                        "userId", MessageAttributeValue.builder()
                            .stringValue(event.getUserId())
                            .dataType("String")
                            .build(),
                        "timestamp", MessageAttributeValue.builder()
                            .stringValue(event.getTimestamp().toString())
                            .dataType("String")
                            .build()
                    ))
                    .build();
                
                PublishResponse response = snsClient.publish(request);
                log.info("Published user event: {} with messageId: {}", 
                    event.getEventType(), response.messageId());
                
            } catch (Exception e) {
                log.error("Failed to publish user event: {}", event.getEventType(), e);
                // Send to DLQ or retry logic
                handleEventPublishingFailure(event, e);
            }
        }
        
        public void publishOrderEvent(OrderEvent event) {
            try {
                String message = objectMapper.writeValueAsString(event);
                
                // Add message deduplication for FIFO topics
                PublishRequest.Builder requestBuilder = PublishRequest.builder()
                    .topicArn(orderEventsTopicArn)
                    .message(message)
                    .messageAttributes(Map.of(
                        "eventType", MessageAttributeValue.builder()
                            .stringValue(event.getEventType())
                            .dataType("String")
                            .build(),
                        "orderId", MessageAttributeValue.builder()
                            .stringValue(event.getOrderId())
                            .dataType("String")
                            .build()
                    ));
                
                // For FIFO topics, add deduplication ID and group ID
                if (orderEventsTopicArn.endsWith(".fifo")) {
                    requestBuilder
                        .messageDeduplicationId(generateDeduplicationId(event))
                        .messageGroupId(event.getOrderId()); // Group by order ID
                }
                
                PublishResponse response = snsClient.publish(requestBuilder.build());
                log.info("Published order event: {} for order: {} with messageId: {}", 
                    event.getEventType(), event.getOrderId(), response.messageId());
                
            } catch (Exception e) {
                log.error("Failed to publish order event: {} for order: {}", 
                    event.getEventType(), event.getOrderId(), e);
                handleEventPublishingFailure(event, e);
            }
        }
        
        private String generateDeduplicationId(OrderEvent event) {
            // Create unique deduplication ID based on event content
            String content = STR."\{event.getOrderId()}-\{event.getEventType()}-\{event.getTimestamp()}";
            return DigestUtils.sha256Hex(content);
        }
        
        private void handleEventPublishingFailure(Object event, Exception error) {
            // Send to DLQ for manual processing
            FailedEvent failedEvent = FailedEvent.builder()
                .originalEvent(event)
                .error(error.getMessage())
                .timestamp(Instant.now())
                .retryCount(0)
                .build();
            
            try {
                String dlqMessage = objectMapper.writeValueAsString(failedEvent);
                sqsClient.sendMessage(SendMessageRequest.builder()
                    .queueUrl(failedEventsDlqUrl)
                    .messageBody(dlqMessage)
                    .build());
                
            } catch (Exception dlqError) {
                log.error("Failed to send event to DLQ", dlqError);
            }
        }
    }
    
    /**
     * SQS message processing
     */
    @Component
    public static class EventConsumerService {
        
        @SqsListener("${aws.sqs.queue.user-events}")
        public void handleUserEvent(UserEvent event, @Header Map<String, String> headers) {
            try {
                log.info("Processing user event: {} for user: {}", 
                    event.getEventType(), event.getUserId());
                
                switch (event.getEventType()) {
                    case "USER_REGISTERED":
                        handleUserRegistered((UserRegisteredEvent) event);
                        break;
                    case "USER_PROFILE_UPDATED":
                        handleUserProfileUpdated((UserProfileUpdatedEvent) event);
                        break;
                    case "USER_DELETED":
                        handleUserDeleted((UserDeletedEvent) event);
                        break;
                    default:
                        log.warn("Unknown user event type: {}", event.getEventType());
                }
                
            } catch (Exception e) {
                log.error("Error processing user event: {}", event.getEventType(), e);
                throw e; // Let SQS handle retry and DLQ
            }
        }
        
        @SqsListener("${aws.sqs.queue.order-events}")
        public void handleOrderEvent(OrderEvent event, @Header Map<String, String> headers) {
            try {
                log.info("Processing order event: {} for order: {}", 
                    event.getEventType(), event.getOrderId());
                
                switch (event.getEventType()) {
                    case "ORDER_CREATED":
                        handleOrderCreated((OrderCreatedEvent) event);
                        break;
                    case "ORDER_PAYMENT_PROCESSED":
                        handleOrderPaymentProcessed((OrderPaymentProcessedEvent) event);
                        break;
                    case "ORDER_SHIPPED":
                        handleOrderShipped((OrderShippedEvent) event);
                        break;
                    case "ORDER_CANCELLED":
                        handleOrderCancelled((OrderCancelledEvent) event);
                        break;
                    default:
                        log.warn("Unknown order event type: {}", event.getEventType());
                }
                
            } catch (Exception e) {
                log.error("Error processing order event: {}", event.getEventType(), e);
                throw e; // Let SQS handle retry and DLQ
            }
        }
        
        // Event handlers
        private void handleUserRegistered(UserRegisteredEvent event) {
            // Send welcome email
            emailService.sendWelcomeEmail(event.getUserId(), event.getEmail());
            
            // Create user analytics profile
            analyticsService.createUserProfile(event.getUserId());
            
            // Add to marketing automation
            marketingService.addToWelcomeCampaign(event.getUserId());
        }
        
        private void handleUserProfileUpdated(UserProfileUpdatedEvent event) {
            // Update search index
            searchService.updateUserIndex(event.getUserId(), event.getUpdatedFields());
            
            // Invalidate caches
            cacheService.invalidateUserCache(event.getUserId());
            
            // Update recommendations
            recommendationService.updateUserPreferences(event.getUserId());
        }
        
        private void handleOrderCreated(OrderCreatedEvent event) {
            // Update inventory
            inventoryService.reserveItems(event.getOrderId(), event.getItems());
            
            // Create payment processing job
            paymentService.schedulePaymentProcessing(event.getOrderId());
            
            // Update user statistics
            userService.updateOrderStatistics(event.getUserId());
        }
        
        private void handleOrderPaymentProcessed(OrderPaymentProcessedEvent event) {
            if (event.isPaymentSuccessful()) {
                // Confirm inventory reservation
                inventoryService.confirmReservation(event.getOrderId());
                
                // Create shipment
                shippingService.createShipment(event.getOrderId());
                
                // Send confirmation email
                emailService.sendOrderConfirmation(event.getOrderId());
            } else {
                // Release inventory reservation
                inventoryService.releaseReservation(event.getOrderId());
                
                // Cancel order
                orderService.cancelOrder(event.getOrderId(), "Payment failed");
            }
        }
    }
    
    /**
     * Kinesis integration for real-time data processing
     */
    @Component
    public static class KinesisStreamService {
        
        @Autowired
        private KinesisClient kinesisClient;
        
        @Value("${aws.kinesis.stream.analytics}")
        private String analyticsStreamName;
        
        @Value("${aws.kinesis.stream.logs}")
        private String logsStreamName;
        
        public void publishAnalyticsEvent(AnalyticsEvent event) {
            try {
                String eventData = objectMapper.writeValueAsString(event);
                
                PutRecordRequest request = PutRecordRequest.builder()
                    .streamName(analyticsStreamName)
                    .data(SdkBytes.fromUtf8String(eventData))
                    .partitionKey(event.getUserId()) // Partition by user ID
                    .build();
                
                PutRecordResponse response = kinesisClient.putRecord(request);
                log.debug("Published analytics event to Kinesis: {}", response.sequenceNumber());
                
            } catch (Exception e) {
                log.error("Failed to publish analytics event to Kinesis", e);
            }
        }
        
        public void publishLogEvent(LogEvent event) {
            try {
                String eventData = objectMapper.writeValueAsString(event);
                
                PutRecordRequest request = PutRecordRequest.builder()
                    .streamName(logsStreamName)
                    .data(SdkBytes.fromUtf8String(eventData))
                    .partitionKey(event.getServiceName()) // Partition by service
                    .build();
                
                kinesisClient.putRecord(request);
                
            } catch (Exception e) {
                log.error("Failed to publish log event to Kinesis", e);
            }
        }
        
        // Batch processing for higher throughput
        public void publishAnalyticsEventsBatch(List<AnalyticsEvent> events) {
            try {
                List<PutRecordsRequestEntry> records = events.stream()
                    .map(event -> {
                        try {
                            String eventData = objectMapper.writeValueAsString(event);
                            return PutRecordsRequestEntry.builder()
                                .data(SdkBytes.fromUtf8String(eventData))
                                .partitionKey(event.getUserId())
                                .build();
                        } catch (Exception e) {
                            log.error("Failed to serialize analytics event", e);
                            return null;
                        }
                    })
                    .filter(Objects::nonNull)
                    .toList();
                
                if (!records.isEmpty()) {
                    PutRecordsRequest request = PutRecordsRequest.builder()
                        .streamName(analyticsStreamName)
                        .records(records)
                        .build();
                    
                    PutRecordsResponse response = kinesisClient.putRecords(request);
                    
                    if (response.failedRecordCount() > 0) {
                        log.warn("Failed to publish {} out of {} analytics events", 
                            response.failedRecordCount(), records.size());
                    }
                }
                
            } catch (Exception e) {
                log.error("Failed to publish analytics events batch to Kinesis", e);
            }
        }
    }
}
```

---

## 🎯 Interview Focus Areas

### Key AWS Architecture Questions

**Q: How do you design a serverless architecture on AWS?**
- **Lambda functions** for compute with proper error handling
- **API Gateway** for HTTP endpoints with authentication
- **DynamoDB** for NoSQL storage with auto-scaling
- **S3** for object storage with lifecycle policies

**Q: How do you handle data consistency in AWS services?**
- **DynamoDB transactions** for ACID operations
- **SQS FIFO queues** for ordered processing
- **EventBridge** for event routing and filtering
- **Step Functions** for workflow orchestration

**Q: How do you design for high availability on AWS?**
- **Multi-AZ deployments** for database high availability
- **Auto Scaling Groups** for compute resilience
- **Application Load Balancer** with health checks
- **CloudFront** for global content delivery

**Q: How do you optimize costs in AWS?**
- **Reserved Instances** for predictable workloads
- **Spot Instances** for fault-tolerant processing
- **S3 Intelligent Tiering** for automatic cost optimization
- **Lambda provisioned concurrency** vs on-demand

---

## 🚀 Next Steps

1. **Complete the hands-on exercises** in the exercises folder
2. **Practice Infrastructure as Code** with CloudFormation/CDK
3. **Design multi-region architectures** for global scale
4. **Implement cost optimization** strategies
5. **Move to Module 13: Case Studies**

The Cloud AWS module provides the foundation for building production-ready, scalable systems on AWS with proper cost optimization and operational excellence.
