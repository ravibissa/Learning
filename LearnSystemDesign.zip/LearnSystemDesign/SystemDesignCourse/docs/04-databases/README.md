# Module 4: Database Systems for Scale

## 🗄️ Designing Data Storage for System Design

### 📚 Learning Objectives

By the end of this module, you will:
- Choose appropriate database types for different use cases
- Design database schemas for scalability
- Implement database sharding and partitioning strategies
- Handle data consistency in distributed systems
- Optimize database performance for high-throughput applications
- Design backup and disaster recovery strategies

---

## 🏗️ Database Selection Framework

### 1. Database Decision Matrix

```java
// Database selection utility for system design decisions
@Service
public class DatabaseSelectionService {
    
    public DatabaseRecommendation recommendDatabase(DataRequirements requirements) {
        DatabaseRecommendation.Builder recommendation = DatabaseRecommendation.builder();
        
        // Analyze requirements
        if (requirements.isACIDRequired()) {
            if (requirements.getExpectedQPS() < 10000) {
                recommendation.primary(DatabaseType.POSTGRESQL)
                    .reason("Strong ACID guarantees with good performance for moderate scale");
            } else {
                recommendation.primary(DatabaseType.POSTGRESQL_CLUSTER)
                    .secondary(DatabaseType.READ_REPLICAS)
                    .reason("PostgreSQL with read replicas for high read workloads");
            }
        }
        
        if (requirements.isEventualConsistencyAcceptable()) {
            if (requirements.isKeyValueWorkload()) {
                recommendation.primary(DatabaseType.DYNAMODB)
                    .reason("DynamoDB for simple key-value operations with high scalability");
            } else if (requirements.isDocumentOriented()) {
                recommendation.primary(DatabaseType.MONGODB)
                    .reason("MongoDB for document storage with flexible schema");
            }
        }
        
        if (requirements.isSearchHeavy()) {
            recommendation.secondary(DatabaseType.ELASTICSEARCH)
                .reason("Elasticsearch for full-text search and analytics");
        }
        
        if (requirements.isAnalyticsWorkload()) {
            recommendation.secondary(DatabaseType.CLICKHOUSE)
                .reason("ClickHouse for OLAP and real-time analytics");
        }
        
        return recommendation.build();
    }
    
    public enum DatabaseType {
        POSTGRESQL("Relational, ACID compliant"),
        POSTGRESQL_CLUSTER("Distributed PostgreSQL"),
        MYSQL("Relational, widely adopted"),
        MONGODB("Document database"),
        DYNAMODB("Managed NoSQL key-value"),
        CASSANDRA("Wide-column, high availability"),
        REDIS("In-memory key-value"),
        ELASTICSEARCH("Search and analytics"),
        CLICKHOUSE("Columnar OLAP database");
        
        private final String description;
        
        DatabaseType(String description) {
            this.description = description;
        }
        
        public String getDescription() { return description; }
    }
}
```

### 2. Data Modeling Patterns

#### Relational Database Design
```java
// User entity with proper indexing strategy
@Entity
@Table(name = "users", indexes = {
    @Index(name = "idx_users_email", columnList = "email", unique = true),
    @Index(name = "idx_users_username", columnList = "username", unique = true),
    @Index(name = "idx_users_created_at", columnList = "created_at"),
    @Index(name = "idx_users_status", columnList = "status")
})
public class User {
    
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;
    
    @Column(nullable = false, unique = true, length = 50)
    private String username;
    
    @Column(nullable = false, unique = true, length = 255)
    private String email;
    
    @Column(name = "first_name", length = 100)
    private String firstName;
    
    @Column(name = "last_name", length = 100)
    private String lastName;
    
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private UserStatus status = UserStatus.ACTIVE;
    
    @Column(name = "created_at", nullable = false)
    private Instant createdAt = Instant.now();
    
    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt = Instant.now();
    
    @Version
    private Long version;
    
    // Soft delete pattern
    @Column(name = "deleted_at")
    private Instant deletedAt;
    
    // JSON column for flexible attributes (PostgreSQL)
    @Column(columnDefinition = "jsonb")
    @Convert(converter = JsonNodeConverter.class)
    private JsonNode attributes;
    
    // Audit fields
    @Column(name = "created_by")
    private String createdBy;
    
    @Column(name = "updated_by")
    private String updatedBy;
    
    public enum UserStatus {
        ACTIVE, INACTIVE, SUSPENDED, PENDING_VERIFICATION
    }
}

// Orders table with partitioning strategy
@Entity
@Table(name = "orders")
@PartitionBy("RANGE (created_at)")
public class Order {
    
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;
    
    @Column(name = "user_id", nullable = false)
    private UUID userId;
    
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private OrderStatus status = OrderStatus.CREATED;
    
    @Column(name = "total_amount", precision = 10, scale = 2)
    private BigDecimal totalAmount;
    
    @Column(name = "created_at", nullable = false)
    private Instant createdAt = Instant.now();
    
    // Foreign key with proper cascading
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", insertable = false, updatable = false)
    private User user;
    
    // One-to-many relationship with order items
    @OneToMany(mappedBy = "order", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<OrderItem> items = new ArrayList<>();
    
    public enum OrderStatus {
        CREATED, PAID, SHIPPED, DELIVERED, CANCELLED, REFUNDED
    }
}

// Optimized repository with custom queries
@Repository
public interface OrderRepository extends JpaRepository<Order, UUID> {
    
    // Query with proper indexing
    @Query("SELECT o FROM Order o WHERE o.userId = :userId AND o.status != 'CANCELLED' ORDER BY o.createdAt DESC")
    Page<Order> findActiveOrdersByUserId(@Param("userId") UUID userId, Pageable pageable);
    
    // Native query for complex analytics
    @Query(value = """
        SELECT DATE_TRUNC('day', created_at) as order_date,
               COUNT(*) as order_count,
               SUM(total_amount) as total_revenue
        FROM orders 
        WHERE created_at >= :startDate AND created_at < :endDate
        GROUP BY DATE_TRUNC('day', created_at)
        ORDER BY order_date
        """, nativeQuery = true)
    List<DailyOrderStats> getDailyOrderStatistics(
        @Param("startDate") Instant startDate,
        @Param("endDate") Instant endDate
    );
    
    // Bulk operations for performance
    @Modifying
    @Query("UPDATE Order o SET o.status = :newStatus WHERE o.status = :oldStatus AND o.createdAt < :cutoffDate")
    int bulkUpdateOrderStatus(
        @Param("oldStatus") OrderStatus oldStatus,
        @Param("newStatus") OrderStatus newStatus,
        @Param("cutoffDate") Instant cutoffDate
    );
    
    interface DailyOrderStats {
        LocalDate getOrderDate();
        Long getOrderCount();
        BigDecimal getTotalRevenue();
    }
}
```

#### NoSQL Document Design
```java
// MongoDB document model for flexible schema
@Document(collection = "user_profiles")
@CompoundIndex(name = "user_location_idx", def = "{'userId': 1, 'location.country': 1}")
@CompoundIndex(name = "preferences_idx", def = "{'preferences.category': 1, 'preferences.priority': -1}")
public class UserProfile {
    
    @Id
    private String id;
    
    @Indexed(unique = true)
    private String userId;
    
    private PersonalInfo personalInfo;
    private Location location;
    private List<Preference> preferences;
    private Map<String, Object> customAttributes;
    private Instant createdAt;
    private Instant updatedAt;
    
    @DBRef
    private List<Tag> tags;
    
    public static class PersonalInfo {
        private String firstName;
        private String lastName;
        private LocalDate dateOfBirth;
        private String phoneNumber;
        private Gender gender;
        
        public enum Gender {
            MALE, FEMALE, OTHER, PREFER_NOT_TO_SAY
        }
    }
    
    public static class Location {
        private String country;
        private String state;
        private String city;
        private String postalCode;
        private GeoJsonPoint coordinates; // For geospatial queries
    }
    
    public static class Preference {
        private String category;
        private String value;
        private int priority;
        private boolean enabled;
    }
}

// Repository with MongoDB-specific features
@Repository
public interface UserProfileRepository extends MongoRepository<UserProfile, String> {
    
    // Geospatial query
    @Query("{ 'location.coordinates': { $near: { $geometry: ?0, $maxDistance: ?1 } } }")
    List<UserProfile> findByLocationNear(Point location, double maxDistance);
    
    // Complex aggregation
    @Aggregation(pipeline = {
        "{ $match: { 'preferences.category': ?0 } }",
        "{ $unwind: '$preferences' }",
        "{ $match: { 'preferences.category': ?0, 'preferences.enabled': true } }",
        "{ $group: { _id: '$preferences.value', count: { $sum: 1 } } }",
        "{ $sort: { count: -1 } }",
        "{ $limit: 10 }"
    })
    List<PreferenceStats> getTopPreferencesByCategory(String category);
    
    interface PreferenceStats {
        String getId();
        Integer getCount();
    }
}
```

---

## 🔀 Database Sharding and Partitioning

### 1. Horizontal Sharding Implementation

```java
// Shard routing service
@Service
public class ShardRoutingService {
    
    private final Map<String, DataSource> shardDataSources;
    private final ShardingStrategy shardingStrategy;
    
    public ShardRoutingService(Map<String, DataSource> shardDataSources) {
        this.shardDataSources = shardDataSources;
        this.shardingStrategy = new HashBasedShardingStrategy(shardDataSources.size());
    }
    
    public DataSource getShardForUser(String userId) {
        String shardKey = shardingStrategy.getShardKey(userId);
        return shardDataSources.get(shardKey);
    }
    
    public List<DataSource> getAllShards() {
        return new ArrayList<>(shardDataSources.values());
    }
    
    // Execute query across all shards
    public <T> List<T> executeAcrossAllShards(String sql, RowMapper<T> rowMapper, Object... params) {
        List<T> results = new ArrayList<>();
        
        List<CompletableFuture<List<T>>> futures = shardDataSources.values().stream()
            .map(dataSource -> CompletableFuture.supplyAsync(() -> {
                JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
                return jdbcTemplate.query(sql, rowMapper, params);
            }))
            .toList();
        
        // Wait for all shards to complete
        CompletableFuture.allOf(futures.toArray(new CompletableFuture[0]))
            .thenApply(v -> futures.stream()
                .map(CompletableFuture::join)
                .flatMap(List::stream)
                .collect(Collectors.toList()))
            .join();
        
        return results;
    }
}

// Sharding strategy interface
public interface ShardingStrategy {
    String getShardKey(String identifier);
    int getShardCount();
}

// Hash-based sharding implementation
public class HashBasedShardingStrategy implements ShardingStrategy {
    
    private final int shardCount;
    private final MessageDigest messageDigest;
    
    public HashBasedShardingStrategy(int shardCount) {
        this.shardCount = shardCount;
        try {
            this.messageDigest = MessageDigest.getInstance("SHA-256");
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-256 algorithm not available", e);
        }
    }
    
    @Override
    public String getShardKey(String identifier) {
        byte[] hash = messageDigest.digest(identifier.getBytes(StandardCharsets.UTF_8));
        int shardIndex = Math.abs(ByteBuffer.wrap(hash).getInt()) % shardCount;
        return "shard-" + shardIndex;
    }
    
    @Override
    public int getShardCount() {
        return shardCount;
    }
}

// Consistent hashing for dynamic sharding
public class ConsistentHashingStrategy implements ShardingStrategy {
    
    private final SortedMap<Long, String> ring = new TreeMap<>();
    private final int virtualNodes = 150;
    
    public ConsistentHashingStrategy(List<String> shardKeys) {
        for (String shardKey : shardKeys) {
            addShard(shardKey);
        }
    }
    
    public void addShard(String shardKey) {
        for (int i = 0; i < virtualNodes; i++) {
            String virtualKey = shardKey + ":" + i;
            long hash = hashFunction(virtualKey);
            ring.put(hash, shardKey);
        }
    }
    
    public void removeShard(String shardKey) {
        for (int i = 0; i < virtualNodes; i++) {
            String virtualKey = shardKey + ":" + i;
            long hash = hashFunction(virtualKey);
            ring.remove(hash);
        }
    }
    
    @Override
    public String getShardKey(String identifier) {
        if (ring.isEmpty()) {
            throw new IllegalStateException("No shards available");
        }
        
        long hash = hashFunction(identifier);
        SortedMap<Long, String> tailMap = ring.tailMap(hash);
        
        return tailMap.isEmpty() ? ring.get(ring.firstKey()) : tailMap.get(tailMap.firstKey());
    }
    
    private long hashFunction(String input) {
        return input.hashCode() & 0x7fffffffL; // Ensure positive value
    }
    
    @Override
    public int getShardCount() {
        return (int) ring.values().stream().distinct().count();
    }
}
```

### 2. Database Partitioning Strategies

```sql
-- Time-based partitioning for orders table
CREATE TABLE orders (
    id UUID PRIMARY KEY,
    user_id UUID NOT NULL,
    status VARCHAR(50) NOT NULL,
    total_amount DECIMAL(10,2),
    created_at TIMESTAMP NOT NULL
) PARTITION BY RANGE (created_at);

-- Create monthly partitions
CREATE TABLE orders_2024_01 PARTITION OF orders
    FOR VALUES FROM ('2024-01-01') TO ('2024-02-01');

CREATE TABLE orders_2024_02 PARTITION OF orders
    FOR VALUES FROM ('2024-02-01') TO ('2024-03-01');

-- Auto-create future partitions
CREATE OR REPLACE FUNCTION create_monthly_partition(table_name text, start_date date)
RETURNS void AS $$
DECLARE
    partition_name text;
    end_date date;
BEGIN
    partition_name := table_name || '_' || to_char(start_date, 'YYYY_MM');
    end_date := start_date + interval '1 month';
    
    EXECUTE format('CREATE TABLE %I PARTITION OF %I FOR VALUES FROM (%L) TO (%L)',
                  partition_name, table_name, start_date, end_date);
    
    -- Create index on partition
    EXECUTE format('CREATE INDEX %I ON %I (user_id, created_at)',
                  partition_name || '_user_id_idx', partition_name);
END;
$$ LANGUAGE plpgsql;

-- Hash partitioning for users table
CREATE TABLE users (
    id UUID PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    created_at TIMESTAMP NOT NULL
) PARTITION BY HASH (id);

-- Create hash partitions
CREATE TABLE users_0 PARTITION OF users FOR VALUES WITH (modulus 4, remainder 0);
CREATE TABLE users_1 PARTITION OF users FOR VALUES WITH (modulus 4, remainder 1);
CREATE TABLE users_2 PARTITION OF users FOR VALUES WITH (modulus 4, remainder 2);
CREATE TABLE users_3 PARTITION OF users FOR VALUES WITH (modulus 4, remainder 3);
```

---

## 🔄 Data Consistency Patterns

### 1. Distributed Transactions with Saga Pattern

```java
// Saga orchestrator for order processing
@Component
public class OrderProcessingSaga {
    
    @Autowired
    private SagaManager sagaManager;
    
    @Autowired
    private InventoryService inventoryService;
    
    @Autowired
    private PaymentService paymentService;
    
    @Autowired
    private ShippingService shippingService;
    
    public void processOrder(OrderCreatedEvent event) {
        SagaTransaction saga = SagaTransaction.builder()
            .sagaId(UUID.randomUUID().toString())
            .orderId(event.getOrderId())
            .build();
        
        // Step 1: Reserve inventory
        saga.addStep(
            SagaStep.builder()
                .stepId("reserve-inventory")
                .action(() -> inventoryService.reserveItems(event.getOrderItems()))
                .compensation(() -> inventoryService.releaseReservation(event.getOrderId()))
                .timeout(Duration.ofSeconds(30))
                .build()
        );
        
        // Step 2: Process payment
        saga.addStep(
            SagaStep.builder()
                .stepId("process-payment")
                .action(() -> paymentService.chargeCustomer(event.getPaymentInfo()))
                .compensation(() -> paymentService.refundPayment(event.getOrderId()))
                .timeout(Duration.ofSeconds(60))
                .build()
        );
        
        // Step 3: Create shipment
        saga.addStep(
            SagaStep.builder()
                .stepId("create-shipment")
                .action(() -> shippingService.createShipment(event.getShippingInfo()))
                .compensation(() -> shippingService.cancelShipment(event.getOrderId()))
                .timeout(Duration.ofSeconds(45))
                .build()
        );
        
        sagaManager.execute(saga);
    }
    
    @EventListener
    public void handleSagaCompleted(SagaCompletedEvent event) {
        log.info("Order processing saga completed successfully: {}", event.getSagaId());
        // Update order status to CONFIRMED
        orderService.updateOrderStatus(event.getOrderId(), OrderStatus.CONFIRMED);
    }
    
    @EventListener
    public void handleSagaFailed(SagaFailedEvent event) {
        log.error("Order processing saga failed: {}", event.getSagaId(), event.getCause());
        // Update order status to FAILED
        orderService.updateOrderStatus(event.getOrderId(), OrderStatus.FAILED);
        
        // Notify customer service
        customerService.notifyOrderFailure(event.getOrderId(), event.getCause());
    }
}

// Saga step implementation
public class SagaStep {
    private final String stepId;
    private final Supplier<SagaStepResult> action;
    private final Runnable compensation;
    private final Duration timeout;
    private SagaStepStatus status = SagaStepStatus.PENDING;
    
    public SagaStepResult execute() {
        try {
            log.info("Executing saga step: {}", stepId);
            SagaStepResult result = action.get();
            
            if (result.isSuccess()) {
                status = SagaStepStatus.COMPLETED;
                log.info("Saga step completed successfully: {}", stepId);
            } else {
                status = SagaStepStatus.FAILED;
                log.warn("Saga step failed: {}, reason: {}", stepId, result.getErrorMessage());
            }
            
            return result;
            
        } catch (Exception e) {
            status = SagaStepStatus.FAILED;
            log.error("Saga step execution failed: {}", stepId, e);
            return SagaStepResult.failure(e.getMessage());
        }
    }
    
    public void compensate() {
        try {
            log.info("Compensating saga step: {}", stepId);
            compensation.run();
            status = SagaStepStatus.COMPENSATED;
            log.info("Saga step compensated successfully: {}", stepId);
        } catch (Exception e) {
            status = SagaStepStatus.COMPENSATION_FAILED;
            log.error("Saga step compensation failed: {}", stepId, e);
        }
    }
    
    public enum SagaStepStatus {
        PENDING, COMPLETED, FAILED, COMPENSATED, COMPENSATION_FAILED
    }
}
```

### 2. Event Sourcing Implementation

```java
// Event store for maintaining event history
@Entity
@Table(name = "event_store")
public class EventStoreEntry {
    
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;
    
    @Column(name = "aggregate_id", nullable = false)
    private String aggregateId;
    
    @Column(name = "aggregate_type", nullable = false)
    private String aggregateType;
    
    @Column(name = "event_type", nullable = false)
    private String eventType;
    
    @Column(name = "event_version", nullable = false)
    private Long eventVersion;
    
    @Column(name = "event_data", columnDefinition = "jsonb")
    private String eventData;
    
    @Column(name = "metadata", columnDefinition = "jsonb")
    private String metadata;
    
    @Column(name = "occurred_at", nullable = false)
    private Instant occurredAt;
    
    // Indexes for performance
    // CREATE INDEX idx_event_store_aggregate ON event_store(aggregate_id, event_version);
    // CREATE INDEX idx_event_store_type_time ON event_store(aggregate_type, occurred_at);
}

// Event sourced aggregate root
public abstract class EventSourcedAggregateRoot {
    
    private String aggregateId;
    private Long version = 0L;
    private final List<DomainEvent> uncommittedEvents = new ArrayList<>();
    
    protected void applyEvent(DomainEvent event) {
        // Apply event to current state
        when(event);
        
        // Add to uncommitted events for persistence
        uncommittedEvents.add(event);
        version++;
    }
    
    protected abstract void when(DomainEvent event);
    
    public void markEventsAsCommitted() {
        uncommittedEvents.clear();
    }
    
    public List<DomainEvent> getUncommittedEvents() {
        return new ArrayList<>(uncommittedEvents);
    }
    
    public void replayEvents(List<DomainEvent> events) {
        for (DomainEvent event : events) {
            when(event);
            version++;
        }
    }
    
    // Getters
    public String getAggregateId() { return aggregateId; }
    public Long getVersion() { return version; }
    
    protected void setAggregateId(String aggregateId) { this.aggregateId = aggregateId; }
}

// Order aggregate with event sourcing
public class Order extends EventSourcedAggregateRoot {
    
    private OrderStatus status;
    private BigDecimal totalAmount;
    private List<OrderItem> items = new ArrayList<>();
    private Instant createdAt;
    
    // Factory method for creating new orders
    public static Order createOrder(String orderId, String userId, List<OrderItem> items) {
        Order order = new Order();
        
        BigDecimal total = items.stream()
            .map(item -> item.getPrice().multiply(BigDecimal.valueOf(item.getQuantity())))
            .reduce(BigDecimal.ZERO, BigDecimal::add);
        
        order.applyEvent(new OrderCreatedEvent(
            orderId, userId, items, total, Instant.now()
        ));
        
        return order;
    }
    
    public void confirmPayment(String paymentId, BigDecimal amount) {
        if (status != OrderStatus.CREATED) {
            throw new IllegalStateException("Cannot confirm payment for order in status: " + status);
        }
        
        applyEvent(new PaymentConfirmedEvent(
            getAggregateId(), paymentId, amount, Instant.now()
        ));
    }
    
    public void shipOrder(String shipmentId, String trackingNumber) {
        if (status != OrderStatus.PAID) {
            throw new IllegalStateException("Cannot ship order in status: " + status);
        }
        
        applyEvent(new OrderShippedEvent(
            getAggregateId(), shipmentId, trackingNumber, Instant.now()
        ));
    }
    
    @Override
    protected void when(DomainEvent event) {
        switch (event) {
            case OrderCreatedEvent e -> {
                setAggregateId(e.getOrderId());
                this.status = OrderStatus.CREATED;
                this.totalAmount = e.getTotalAmount();
                this.items = new ArrayList<>(e.getItems());
                this.createdAt = e.getOccurredAt();
            }
            case PaymentConfirmedEvent e -> {
                this.status = OrderStatus.PAID;
            }
            case OrderShippedEvent e -> {
                this.status = OrderStatus.SHIPPED;
            }
            case OrderCancelledEvent e -> {
                this.status = OrderStatus.CANCELLED;
            }
            default -> {
                // Ignore unknown events for forward compatibility
            }
        }
    }
    
    // Getters
    public OrderStatus getStatus() { return status; }
    public BigDecimal getTotalAmount() { return totalAmount; }
    public List<OrderItem> getItems() { return items; }
    public Instant getCreatedAt() { return createdAt; }
}

// Event sourced repository
@Repository
public class EventSourcedOrderRepository {
    
    @Autowired
    private EventStoreRepository eventStoreRepository;
    
    @Autowired
    private ObjectMapper objectMapper;
    
    @Autowired
    private ApplicationEventPublisher eventPublisher;
    
    public void save(Order order) {
        List<DomainEvent> events = order.getUncommittedEvents();
        
        for (DomainEvent event : events) {
            EventStoreEntry entry = new EventStoreEntry();
            entry.setAggregateId(order.getAggregateId());
            entry.setAggregateType("Order");
            entry.setEventType(event.getClass().getSimpleName());
            entry.setEventVersion(order.getVersion());
            entry.setEventData(serializeEvent(event));
            entry.setMetadata(createMetadata(event));
            entry.setOccurredAt(event.getOccurredAt());
            
            eventStoreRepository.save(entry);
            
            // Publish event for projections and external systems
            eventPublisher.publishEvent(event);
        }
        
        order.markEventsAsCommitted();
    }
    
    public Optional<Order> findById(String orderId) {
        List<EventStoreEntry> events = eventStoreRepository
            .findByAggregateIdOrderByEventVersion(orderId);
        
        if (events.isEmpty()) {
            return Optional.empty();
        }
        
        Order order = new Order();
        List<DomainEvent> domainEvents = events.stream()
            .map(this::deserializeEvent)
            .toList();
        
        order.replayEvents(domainEvents);
        
        return Optional.of(order);
    }
    
    private String serializeEvent(DomainEvent event) {
        try {
            return objectMapper.writeValueAsString(event);
        } catch (JsonProcessingException e) {
            throw new RuntimeException("Failed to serialize event", e);
        }
    }
    
    private DomainEvent deserializeEvent(EventStoreEntry entry) {
        try {
            Class<?> eventClass = Class.forName("com.example.events." + entry.getEventType());
            return (DomainEvent) objectMapper.readValue(entry.getEventData(), eventClass);
        } catch (Exception e) {
            throw new RuntimeException("Failed to deserialize event", e);
        }
    }
    
    private String createMetadata(DomainEvent event) {
        Map<String, Object> metadata = Map.of(
            "eventId", UUID.randomUUID().toString(),
            "correlationId", event.getCorrelationId(),
            "causationId", event.getCausationId(),
            "userId", event.getUserId()
        );
        
        try {
            return objectMapper.writeValueAsString(metadata);
        } catch (JsonProcessingException e) {
            throw new RuntimeException("Failed to serialize metadata", e);
        }
    }
}
```

---

## 🔧 Database Performance Optimization

### 1. Connection Pool Optimization

```java
// Optimized HikariCP configuration
@Configuration
public class DatabaseConfig {
    
    @Bean
    @Primary
    public DataSource primaryDataSource() {
        HikariConfig config = new HikariConfig();
        config.setJdbcUrl("jdbc:postgresql://localhost:5432/systemdesign");
        config.setUsername("app_user");
        config.setPassword("app_password");
        
        // Connection pool optimization
        config.setMaximumPoolSize(50);                    // Based on load testing
        config.setMinimumIdle(10);                       // Keep connections warm
        config.setConnectionTimeout(30000);              // 30 seconds
        config.setIdleTimeout(600000);                   // 10 minutes
        config.setMaxLifetime(1800000);                  // 30 minutes
        config.setLeakDetectionThreshold(60000);         // 1 minute
        
        // Performance optimizations
        config.addDataSourceProperty("cachePrepStmts", "true");
        config.addDataSourceProperty("prepStmtCacheSize", "250");
        config.addDataSourceProperty("prepStmtCacheSqlLimit", "2048");
        config.addDataSourceProperty("useServerPrepStmts", "true");
        config.addDataSourceProperty("useLocalSessionState", "true");
        config.addDataSourceProperty("rewriteBatchedStatements", "true");
        config.addDataSourceProperty("cacheResultSetMetadata", "true");
        config.addDataSourceProperty("cacheServerConfiguration", "true");
        config.addDataSourceProperty("elideSetAutoCommits", "true");
        config.addDataSourceProperty("maintainTimeStats", "false");
        
        return new HikariDataSource(config);
    }
    
    @Bean
    public DataSource readOnlyDataSource() {
        HikariConfig config = new HikariConfig();
        config.setJdbcUrl("jdbc:postgresql://readonly-replica:5432/systemdesign");
        config.setUsername("readonly_user");
        config.setPassword("readonly_password");
        
        // Read-only optimizations
        config.setMaximumPoolSize(30);
        config.setReadOnly(true);
        config.addDataSourceProperty("defaultQueryTimeout", "30");
        
        return new HikariDataSource(config);
    }
}

// Read/Write splitting with routing data source
@Configuration
public class ReadWriteSplittingConfig {
    
    @Bean
    public DataSource routingDataSource(
            @Qualifier("primaryDataSource") DataSource writeDataSource,
            @Qualifier("readOnlyDataSource") DataSource readDataSource) {
        
        RoutingDataSource routingDataSource = new RoutingDataSource();
        
        Map<Object, Object> dataSourceMap = new HashMap<>();
        dataSourceMap.put("write", writeDataSource);
        dataSourceMap.put("read", readDataSource);
        
        routingDataSource.setTargetDataSources(dataSourceMap);
        routingDataSource.setDefaultTargetDataSource(writeDataSource);
        
        return routingDataSource;
    }
}

// Custom routing data source
public class RoutingDataSource extends AbstractRoutingDataSource {
    
    @Override
    protected Object determineCurrentLookupKey() {
        return DatabaseContextHolder.getDataSourceType();
    }
}

// Thread-local context for routing
public class DatabaseContextHolder {
    
    private static final ThreadLocal<String> contextHolder = new ThreadLocal<>();
    
    public static void setDataSourceType(String dataSourceType) {
        contextHolder.set(dataSourceType);
    }
    
    public static String getDataSourceType() {
        return contextHolder.get();
    }
    
    public static void clearDataSourceType() {
        contextHolder.remove();
    }
}

// Aspect for automatic read/write routing
@Aspect
@Component
public class ReadWriteRoutingAspect {
    
    @Around("@annotation(Transactional)")
    public Object routeDataSource(ProceedingJoinPoint joinPoint) throws Throwable {
        try {
            Transactional transactional = getTransactionalAnnotation(joinPoint);
            
            if (transactional != null && transactional.readOnly()) {
                DatabaseContextHolder.setDataSourceType("read");
            } else {
                DatabaseContextHolder.setDataSourceType("write");
            }
            
            return joinPoint.proceed();
            
        } finally {
            DatabaseContextHolder.clearDataSourceType();
        }
    }
    
    private Transactional getTransactionalAnnotation(ProceedingJoinPoint joinPoint) {
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        Method method = signature.getMethod();
        
        // Check method annotation first
        Transactional annotation = method.getAnnotation(Transactional.class);
        if (annotation != null) {
            return annotation;
        }
        
        // Check class annotation
        return joinPoint.getTarget().getClass().getAnnotation(Transactional.class);
    }
}
```

### 2. Query Optimization Strategies

```java
// Repository with optimized queries
@Repository
public class OptimizedOrderRepository {
    
    @Autowired
    private JdbcTemplate jdbcTemplate;
    
    @Autowired
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
    
    // Batch insert optimization
    public void createOrdersBatch(List<Order> orders) {
        String sql = """
            INSERT INTO orders (id, user_id, status, total_amount, created_at) 
            VALUES (?, ?, ?, ?, ?)
            """;
        
        List<Object[]> batchArgs = orders.stream()
            .map(order -> new Object[]{
                order.getId(),
                order.getUserId(),
                order.getStatus().name(),
                order.getTotalAmount(),
                order.getCreatedAt()
            })
            .toList();
        
        jdbcTemplate.batchUpdate(sql, batchArgs);
    }
    
    // Pagination with cursor-based approach for large datasets
    public List<Order> findOrdersWithCursor(String cursor, int limit) {
        String sql = """
            SELECT id, user_id, status, total_amount, created_at
            FROM orders 
            WHERE created_at < ? 
            ORDER BY created_at DESC 
            LIMIT ?
            """;
        
        Instant cursorTime = cursor != null ? 
            Instant.parse(cursor) : Instant.now();
        
        return jdbcTemplate.query(sql, orderRowMapper(), cursorTime, limit);
    }
    
    // Optimized count query for pagination
    public long countOrdersByUserIdOptimized(UUID userId) {
        String sql = """
            SELECT count_estimate('SELECT 1 FROM orders WHERE user_id = ?')
            """;
        
        // Use estimation for large tables to avoid full table scan
        return jdbcTemplate.queryForObject(sql, Long.class, userId);
    }
    
    // Bulk update with optimistic locking
    @Modifying
    public int bulkUpdateOrderStatusWithLocking(
            OrderStatus fromStatus, 
            OrderStatus toStatus, 
            Instant cutoffDate) {
        
        String sql = """
            UPDATE orders 
            SET status = :toStatus, 
                updated_at = :updatedAt,
                version = version + 1
            WHERE status = :fromStatus 
              AND created_at < :cutoffDate
              AND version = (
                  SELECT version FROM orders o2 
                  WHERE o2.id = orders.id
              )
            """;
        
        MapSqlParameterSource params = new MapSqlParameterSource()
            .addValue("fromStatus", fromStatus.name())
            .addValue("toStatus", toStatus.name())
            .addValue("cutoffDate", cutoffDate)
            .addValue("updatedAt", Instant.now());
        
        return namedParameterJdbcTemplate.update(sql, params);
    }
    
    // Efficient EXISTS query instead of COUNT
    public boolean hasActiveOrders(UUID userId) {
        String sql = """
            SELECT EXISTS(
                SELECT 1 FROM orders 
                WHERE user_id = ? 
                  AND status NOT IN ('CANCELLED', 'DELIVERED')
                LIMIT 1
            )
            """;
        
        return Boolean.TRUE.equals(
            jdbcTemplate.queryForObject(sql, Boolean.class, userId)
        );
    }
    
    // Window function for analytics
    public List<OrderAnalytics> getOrderAnalytics(int days) {
        String sql = """
            SELECT 
                DATE(created_at) as order_date,
                COUNT(*) as daily_orders,
                SUM(total_amount) as daily_revenue,
                AVG(total_amount) as avg_order_value,
                LAG(COUNT(*)) OVER (ORDER BY DATE(created_at)) as prev_day_orders,
                (COUNT(*) - LAG(COUNT(*)) OVER (ORDER BY DATE(created_at))) * 100.0 / 
                    NULLIF(LAG(COUNT(*)) OVER (ORDER BY DATE(created_at)), 0) as growth_rate
            FROM orders 
            WHERE created_at >= CURRENT_DATE - INTERVAL ? DAY
            GROUP BY DATE(created_at)
            ORDER BY order_date
            """;
        
        return jdbcTemplate.query(sql, orderAnalyticsRowMapper(), days);
    }
    
    private RowMapper<Order> orderRowMapper() {
        return (rs, rowNum) -> Order.builder()
            .id(UUID.fromString(rs.getString("id")))
            .userId(UUID.fromString(rs.getString("user_id")))
            .status(OrderStatus.valueOf(rs.getString("status")))
            .totalAmount(rs.getBigDecimal("total_amount"))
            .createdAt(rs.getTimestamp("created_at").toInstant())
            .build();
    }
    
    private RowMapper<OrderAnalytics> orderAnalyticsRowMapper() {
        return (rs, rowNum) -> OrderAnalytics.builder()
            .orderDate(rs.getDate("order_date").toLocalDate())
            .dailyOrders(rs.getLong("daily_orders"))
            .dailyRevenue(rs.getBigDecimal("daily_revenue"))
            .avgOrderValue(rs.getBigDecimal("avg_order_value"))
            .prevDayOrders(rs.getLong("prev_day_orders"))
            .growthRate(rs.getBigDecimal("growth_rate"))
            .build();
    }
}
```

---

## 📊 Database Monitoring and Alerting

### 1. Database Metrics Collection

```java
@Component
public class DatabaseMetrics {
    
    private final Gauge connectionPoolActive;
    private final Gauge connectionPoolIdle;
    private final Timer queryExecutionTime;
    private final Counter queryCount;
    private final Counter connectionErrors;
    
    public DatabaseMetrics(MeterRegistry meterRegistry, DataSource dataSource) {
        this.connectionPoolActive = Gauge.builder("db.connections.active")
            .description("Active database connections")
            .register(meterRegistry, dataSource, this::getActiveConnections);
            
        this.connectionPoolIdle = Gauge.builder("db.connections.idle")
            .description("Idle database connections")
            .register(meterRegistry, dataSource, this::getIdleConnections);
            
        this.queryExecutionTime = Timer.builder("db.query.duration")
            .description("Database query execution time")
            .register(meterRegistry);
            
        this.queryCount = Counter.builder("db.queries.total")
            .description("Total database queries")
            .register(meterRegistry);
            
        this.connectionErrors = Counter.builder("db.connection.errors")
            .description("Database connection errors")
            .register(meterRegistry);
    }
    
    public void recordQuery(String operation, Duration duration, boolean success) {
        queryCount.increment(
            Tags.of(
                "operation", operation,
                "status", success ? "success" : "error"
            )
        );
        
        queryExecutionTime.record(duration, Tags.of("operation", operation));
        
        if (!success) {
            connectionErrors.increment(Tags.of("operation", operation));
        }
    }
    
    private double getActiveConnections(DataSource dataSource) {
        if (dataSource instanceof HikariDataSource hikariDataSource) {
            return hikariDataSource.getHikariPoolMXBean().getActiveConnections();
        }
        return 0;
    }
    
    private double getIdleConnections(DataSource dataSource) {
        if (dataSource instanceof HikariDataSource hikariDataSource) {
            return hikariDataSource.getHikariPoolMXBean().getIdleConnections();
        }
        return 0;
    }
}

// Database health indicator
@Component
public class DatabaseHealthIndicator implements HealthIndicator {
    
    @Autowired
    private DataSource dataSource;
    
    @Autowired
    private DatabaseMetrics databaseMetrics;
    
    @Override
    public Health health() {
        try {
            // Test database connectivity
            try (Connection connection = dataSource.getConnection()) {
                boolean isValid = connection.isValid(5);
                
                if (isValid) {
                    // Get connection pool statistics
                    Map<String, Object> details = getConnectionPoolDetails();
                    
                    // Check for concerning metrics
                    if (isConnectionPoolHealthy(details)) {
                        return Health.up()
                            .withDetails(details)
                            .build();
                    } else {
                        return Health.down()
                            .withDetail("reason", "Connection pool unhealthy")
                            .withDetails(details)
                            .build();
                    }
                } else {
                    return Health.down()
                        .withDetail("reason", "Database connection validation failed")
                        .build();
                }
            }
        } catch (SQLException e) {
            return Health.down()
                .withDetail("reason", "Cannot establish database connection")
                .withException(e)
                .build();
        }
    }
    
    private Map<String, Object> getConnectionPoolDetails() {
        Map<String, Object> details = new HashMap<>();
        
        if (dataSource instanceof HikariDataSource hikariDataSource) {
            HikariPoolMXBean poolMXBean = hikariDataSource.getHikariPoolMXBean();
            
            details.put("active", poolMXBean.getActiveConnections());
            details.put("idle", poolMXBean.getIdleConnections());
            details.put("total", poolMXBean.getTotalConnections());
            details.put("threadsAwaitingConnection", poolMXBean.getThreadsAwaitingConnection());
            details.put("maxConnections", hikariDataSource.getMaximumPoolSize());
            details.put("minConnections", hikariDataSource.getMinimumIdle());
        }
        
        return details;
    }
    
    private boolean isConnectionPoolHealthy(Map<String, Object> details) {
        Integer active = (Integer) details.get("active");
        Integer total = (Integer) details.get("total");
        Integer threadsWaiting = (Integer) details.get("threadsAwaitingConnection");
        
        // Check if connection pool is at capacity
        if (active != null && total != null && active.equals(total)) {
            return false;
        }
        
        // Check if threads are waiting for connections
        if (threadsWaiting != null && threadsWaiting > 0) {
            return false;
        }
        
        return true;
    }
}
```

---

## 🎯 Interview Focus Areas

### Key Database Questions

**Q: How do you choose between SQL and NoSQL databases?**
- **ACID requirements**: Use SQL for strong consistency
- **Scalability needs**: NoSQL for horizontal scaling
- **Query complexity**: SQL for complex relationships
- **Schema flexibility**: NoSQL for evolving schemas

**Q: How do you scale a database to handle millions of users?**
- **Read replicas** for read-heavy workloads
- **Sharding** for write scalability
- **Caching layers** (Redis, Memcached)
- **Connection pooling** optimization

**Q: How do you ensure data consistency in distributed systems?**
- **Saga pattern** for distributed transactions
- **Event sourcing** for audit trails
- **CQRS** for read/write separation
- **Eventual consistency** models

**Q: How do you handle database failures?**
- **Multi-AZ deployments** for high availability
- **Point-in-time recovery** from backups
- **Circuit breakers** for database calls
- **Graceful degradation** strategies

---

## 🚀 Next Steps

1. **Complete the hands-on exercises** in the exercises folder
2. **Practice sharding strategies** with the provided examples
3. **Implement event sourcing** for a sample application
4. **Set up monitoring** for database performance
5. **Move to Module 5: Caching Strategies**

The database module provides the foundation for building data-intensive applications that can scale to millions of users while maintaining consistency and performance.
