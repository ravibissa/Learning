# Module 6: Messaging Systems for Distributed Architecture

## 📨 Building Scalable Event-Driven Systems

### 📚 Learning Objectives

By the end of this module, you will:
- Design message queuing architectures for different scenarios
- Implement reliable message delivery patterns
- Choose between different messaging technologies (Kafka, RabbitMQ, SQS)
- Handle message ordering, deduplication, and retry mechanisms
- Design event-driven architectures with proper decoupling
- Implement saga patterns for distributed transactions

---

## 🏗️ Messaging Architecture Patterns

### 1. Message Queue vs Event Streaming

```java
// Comprehensive messaging service supporting multiple patterns
@Service
public class MessagingOrchestrator {
    
    @Autowired
    private KafkaEventStreamingService kafkaService;
    
    @Autowired
    private RabbitMQMessageQueueService rabbitMQService;
    
    @Autowired
    private SQSCloudQueueService sqsService;
    
    @Autowired
    private MessagingMetrics messagingMetrics;
    
    public void publishMessage(Message message, MessagingOptions options) {
        Timer.Sample sample = messagingMetrics.startPublishTimer();
        
        try {
            switch (options.getPattern()) {
                case EVENT_STREAMING:
                    publishToEventStream(message, options);
                    break;
                    
                case MESSAGE_QUEUE:
                    publishToMessageQueue(message, options);
                    break;
                    
                case CLOUD_QUEUE:
                    publishToCloudQueue(message, options);
                    break;
                    
                case HYBRID:
                    publishToMultipleChannels(message, options);
                    break;
            }
            
            messagingMetrics.recordPublishSuccess(options.getPattern().name());
            
        } catch (Exception e) {
            messagingMetrics.recordPublishFailure(options.getPattern().name(), e);
            throw new MessagingException("Failed to publish message", e);
        } finally {
            sample.stop();
        }
    }
    
    private void publishToEventStream(Message message, MessagingOptions options) {
        // Use Kafka for high-throughput event streaming
        KafkaPublishOptions kafkaOptions = KafkaPublishOptions.builder()
            .topic(options.getDestination())
            .partition(determinePartition(message, options))
            .key(message.getKey())
            .headers(message.getHeaders())
            .guarantees(options.getDeliveryGuarantees())
            .build();
        
        kafkaService.publish(message.getPayload(), kafkaOptions);
    }
    
    private void publishToMessageQueue(Message message, MessagingOptions options) {
        // Use RabbitMQ for traditional message queuing
        RabbitMQPublishOptions rabbitOptions = RabbitMQPublishOptions.builder()
            .exchange(options.getExchange())
            .routingKey(options.getRoutingKey())
            .persistent(options.isPersistent())
            .priority(options.getPriority())
            .ttl(options.getTtl())
            .deadLetterExchange(options.getDeadLetterExchange())
            .build();
        
        rabbitMQService.publish(message.getPayload(), rabbitOptions);
    }
    
    private void publishToCloudQueue(Message message, MessagingOptions options) {
        // Use SQS for cloud-native queuing
        SQSPublishOptions sqsOptions = SQSPublishOptions.builder()
            .queueUrl(options.getQueueUrl())
            .delaySeconds(options.getDelaySeconds())
            .messageAttributes(message.getAttributes())
            .messageGroupId(options.getMessageGroupId())
            .messageDeduplicationId(generateDeduplicationId(message))
            .build();
        
        sqsService.publish(message.getPayload(), sqsOptions);
    }
    
    private void publishToMultipleChannels(Message message, MessagingOptions options) {
        // Publish to multiple messaging systems for redundancy
        List<CompletableFuture<Void>> publishFutures = new ArrayList<>();
        
        if (options.getChannels().contains(MessagingChannel.KAFKA)) {
            publishFutures.add(CompletableFuture.runAsync(() -> 
                publishToEventStream(message, options)));
        }
        
        if (options.getChannels().contains(MessagingChannel.RABBITMQ)) {
            publishFutures.add(CompletableFuture.runAsync(() -> 
                publishToMessageQueue(message, options)));
        }
        
        if (options.getChannels().contains(MessagingChannel.SQS)) {
            publishFutures.add(CompletableFuture.runAsync(() -> 
                publishToCloudQueue(message, options)));
        }
        
        // Wait for all to complete
        CompletableFuture.allOf(publishFutures.toArray(new CompletableFuture[0]))
            .join();
    }
    
    private Integer determinePartition(Message message, MessagingOptions options) {
        if (options.getPartitionStrategy() == PartitionStrategy.KEY_HASH) {
            return Math.abs(message.getKey().hashCode()) % options.getPartitionCount();
        } else if (options.getPartitionStrategy() == PartitionStrategy.ROUND_ROBIN) {
            return ThreadLocalRandom.current().nextInt(options.getPartitionCount());
        } else {
            return null; // Let Kafka decide
        }
    }
    
    private String generateDeduplicationId(Message message) {
        // Generate consistent deduplication ID
        String content = message.getKey() + message.getPayload().toString() + message.getTimestamp();
        return DigestUtils.sha256Hex(content);
    }
}
```

### 2. Kafka Event Streaming Implementation

```java
// High-performance Kafka producer and consumer implementation
@Service
public class KafkaEventStreamingService {
    
    private final KafkaTemplate<String, Object> kafkaTemplate;
    private final KafkaAdmin kafkaAdmin;
    private final MessagingMetrics messagingMetrics;
    private final RetryTemplate retryTemplate;
    
    public KafkaEventStreamingService(KafkaTemplate<String, Object> kafkaTemplate,
                                    KafkaAdmin kafkaAdmin,
                                    MessagingMetrics messagingMetrics) {
        this.kafkaTemplate = kafkaTemplate;
        this.kafkaAdmin = kafkaAdmin;
        this.messagingMetrics = messagingMetrics;
        this.retryTemplate = createRetryTemplate();
    }
    
    public void publish(Object payload, KafkaPublishOptions options) {
        try {
            ProducerRecord<String, Object> record = new ProducerRecord<>(
                options.getTopic(),
                options.getPartition(),
                options.getKey(),
                payload
            );
            
            // Add headers
            if (options.getHeaders() != null) {
                options.getHeaders().forEach((key, value) -> 
                    record.headers().add(key, value.getBytes()));
            }
            
            // Add tracing headers
            addTracingHeaders(record);
            
            // Send with callback
            ListenableFuture<SendResult<String, Object>> future = kafkaTemplate.send(record);
            
            future.addCallback(
                result -> {
                    messagingMetrics.recordKafkaPublishSuccess(options.getTopic());
                    log.debug("Message published successfully to topic: {}, partition: {}, offset: {}",
                        result.getRecordMetadata().topic(),
                        result.getRecordMetadata().partition(),
                        result.getRecordMetadata().offset());
                },
                failure -> {
                    messagingMetrics.recordKafkaPublishFailure(options.getTopic(), failure);
                    log.error("Failed to publish message to topic: {}", options.getTopic(), failure);
                }
            );
            
        } catch (Exception e) {
            messagingMetrics.recordKafkaPublishFailure(options.getTopic(), e);
            throw new KafkaPublishException("Failed to publish to Kafka", e);
        }
    }
    
    public void publishWithTransaction(List<PublishRequest> requests) {
        kafkaTemplate.executeInTransaction(operations -> {
            for (PublishRequest request : requests) {
                ProducerRecord<String, Object> record = new ProducerRecord<>(
                    request.getTopic(),
                    request.getKey(),
                    request.getPayload()
                );
                
                operations.send(record);
            }
            return null;
        });
    }
    
    @KafkaListener(topics = "user-events", groupId = "user-service-group")
    public void handleUserEvent(@Payload UserEvent event,
                               @Header Map<String, Object> headers,
                               Acknowledgment ack) {
        try {
            log.info("Processing user event: {}", event.getEventType());
            
            // Process the event
            processUserEvent(event);
            
            // Manual acknowledgment
            ack.acknowledge();
            
            messagingMetrics.recordKafkaConsumerSuccess("user-events");
            
        } catch (Exception e) {
            messagingMetrics.recordKafkaConsumerFailure("user-events", e);
            log.error("Failed to process user event", e);
            
            // Don't acknowledge - let Kafka retry
            throw e;
        }
    }
    
    @KafkaListener(topics = "order-events", groupId = "order-service-group")
    public void handleOrderEvent(@Payload OrderEvent event,
                                @Header("kafka_receivedPartitionId") int partition,
                                @Header("kafka_offset") long offset,
                                ConsumerRecord<String, OrderEvent> record) {
        
        String traceId = extractTraceId(record.headers());
        
        try (MDCCloseable mdc = MDC.putCloseable("traceId", traceId)) {
            log.info("Processing order event: {} from partition: {}, offset: {}", 
                event.getEventType(), partition, offset);
            
            // Idempotency check
            if (isDuplicateEvent(event, partition, offset)) {
                log.warn("Duplicate order event detected, skipping: {}", event.getOrderId());
                return;
            }
            
            // Process with retry logic
            retryTemplate.execute(context -> {
                processOrderEvent(event);
                return null;
            });
            
            // Record processing
            recordEventProcessed(event, partition, offset);
            
            messagingMetrics.recordKafkaConsumerSuccess("order-events");
            
        } catch (Exception e) {
            messagingMetrics.recordKafkaConsumerFailure("order-events", e);
            log.error("Failed to process order event after retries", e);
            
            // Send to dead letter topic
            sendToDeadLetterTopic(event, e);
        }
    }
    
    // Batch processing for high throughput
    @KafkaListener(topics = "analytics-events", 
                  groupId = "analytics-batch-group",
                  containerFactory = "batchListenerFactory")
    public void handleAnalyticsEventsBatch(List<AnalyticsEvent> events,
                                         List<Acknowledgment> acknowledgments) {
        try {
            log.info("Processing batch of {} analytics events", events.size());
            
            // Process events in batch for efficiency
            analyticsService.processBatch(events);
            
            // Acknowledge all messages
            acknowledgments.forEach(Acknowledgment::acknowledge);
            
            messagingMetrics.recordKafkaBatchProcessed("analytics-events", events.size());
            
        } catch (Exception e) {
            log.error("Failed to process analytics batch", e);
            // Don't acknowledge - let Kafka retry the entire batch
            throw e;
        }
    }
    
    // Topic management
    public void createTopicIfNotExists(String topicName, int partitions, short replicationFactor) {
        try {
            NewTopic newTopic = TopicBuilder.name(topicName)
                .partitions(partitions)
                .replicas(replicationFactor)
                .config(TopicConfig.CLEANUP_POLICY_CONFIG, TopicConfig.CLEANUP_POLICY_DELETE)
                .config(TopicConfig.RETENTION_MS_CONFIG, String.valueOf(Duration.ofDays(7).toMillis()))
                .config(TopicConfig.COMPRESSION_TYPE_CONFIG, "snappy")
                .build();
            
            kafkaAdmin.createOrModifyTopics(newTopic);
            
            log.info("Created Kafka topic: {} with {} partitions", topicName, partitions);
            
        } catch (Exception e) {
            log.warn("Failed to create topic: {}", topicName, e);
        }
    }
    
    private void addTracingHeaders(ProducerRecord<String, Object> record) {
        String traceId = MDC.get("traceId");
        if (traceId != null) {
            record.headers().add("traceId", traceId.getBytes());
        }
        
        record.headers().add("timestamp", String.valueOf(Instant.now().toEpochMilli()).getBytes());
        record.headers().add("source", "kafka-producer".getBytes());
    }
    
    private String extractTraceId(Headers headers) {
        Header traceHeader = headers.lastHeader("traceId");
        return traceHeader != null ? new String(traceHeader.value()) : UUID.randomUUID().toString();
    }
    
    private boolean isDuplicateEvent(OrderEvent event, int partition, long offset) {
        // Check if we've already processed this event
        return eventProcessingRepository.existsByEventIdAndPartitionAndOffset(
            event.getEventId(), partition, offset);
    }
    
    private void recordEventProcessed(OrderEvent event, int partition, long offset) {
        EventProcessingRecord record = new EventProcessingRecord(
            event.getEventId(), partition, offset, Instant.now());
        eventProcessingRepository.save(record);
    }
    
    private void sendToDeadLetterTopic(OrderEvent event, Exception error) {
        try {
            DeadLetterEvent deadLetterEvent = new DeadLetterEvent(
                event, error.getMessage(), Instant.now());
            
            kafkaTemplate.send("order-events-dlq", event.getOrderId(), deadLetterEvent);
            
        } catch (Exception e) {
            log.error("Failed to send event to dead letter topic", e);
        }
    }
    
    private RetryTemplate createRetryTemplate() {
        return RetryTemplate.builder()
            .maxAttempts(3)
            .exponentialBackoff(1000, 2, 10000)
            .retryOn(RetryableException.class)
            .build();
    }
    
    private void processUserEvent(UserEvent event) {
        // Implementation for user event processing
        userEventProcessor.process(event);
    }
    
    private void processOrderEvent(OrderEvent event) {
        // Implementation for order event processing
        orderEventProcessor.process(event);
    }
}
```

### 3. RabbitMQ Message Queue Implementation

```java
// RabbitMQ implementation with advanced routing and reliability
@Service
public class RabbitMQMessageQueueService {
    
    private final RabbitTemplate rabbitTemplate;
    private final RabbitAdmin rabbitAdmin;
    private final MessagingMetrics messagingMetrics;
    
    public RabbitMQMessageQueueService(RabbitTemplate rabbitTemplate,
                                     RabbitAdmin rabbitAdmin,
                                     MessagingMetrics messagingMetrics) {
        this.rabbitTemplate = rabbitTemplate;
        this.rabbitAdmin = rabbitAdmin;
        this.messagingMetrics = messagingMetrics;
        
        configureRabbitTemplate();
    }
    
    public void publish(Object payload, RabbitMQPublishOptions options) {
        try {
            // Create message with properties
            Message message = createMessage(payload, options);
            
            // Publish with publisher confirms
            rabbitTemplate.convertAndSend(
                options.getExchange(),
                options.getRoutingKey(),
                message,
                messagePostProcessor -> {
                    // Add custom headers
                    messagePostProcessor.getMessageProperties().setHeader("publishTime", Instant.now());
                    messagePostProcessor.getMessageProperties().setHeader("source", "rabbitmq-producer");
                    
                    return messagePostProcessor;
                }
            );
            
            messagingMetrics.recordRabbitMQPublishSuccess(options.getExchange());
            
        } catch (Exception e) {
            messagingMetrics.recordRabbitMQPublishFailure(options.getExchange(), e);
            throw new RabbitMQPublishException("Failed to publish to RabbitMQ", e);
        }
    }
    
    @RabbitListener(queues = "notification.queue")
    public void handleNotificationMessage(@Payload NotificationEvent notification,
                                        @Header Map<String, Object> headers,
                                        Channel channel,
                                        @Header(AmqpHeaders.DELIVERY_TAG) long deliveryTag) {
        try {
            log.info("Processing notification: {}", notification.getNotificationId());
            
            // Process the notification
            notificationService.sendNotification(notification);
            
            // Manual acknowledgment
            channel.basicAck(deliveryTag, false);
            
            messagingMetrics.recordRabbitMQConsumerSuccess("notification.queue");
            
        } catch (RetryableException e) {
            log.warn("Retryable error processing notification, rejecting for retry", e);
            
            try {
                // Reject and requeue for retry
                channel.basicReject(deliveryTag, true);
            } catch (IOException ioException) {
                log.error("Failed to reject message", ioException);
            }
            
        } catch (Exception e) {
            messagingMetrics.recordRabbitMQConsumerFailure("notification.queue", e);
            log.error("Failed to process notification", e);
            
            try {
                // Send to dead letter queue
                channel.basicReject(deliveryTag, false);
            } catch (IOException ioException) {
                log.error("Failed to reject message for DLQ", ioException);
            }
        }
    }
    
    @RabbitListener(queues = "email.queue", concurrency = "5-10")
    public void handleEmailMessage(@Payload EmailEvent email) {
        try {
            log.info("Processing email: {}", email.getEmailId());
            
            // Process email with circuit breaker
            circuitBreaker.executeSupplier(() -> {
                emailService.sendEmail(email);
                return null;
            });
            
            messagingMetrics.recordRabbitMQConsumerSuccess("email.queue");
            
        } catch (Exception e) {
            messagingMetrics.recordRabbitMQConsumerFailure("email.queue", e);
            log.error("Failed to process email", e);
            throw new AmqpRejectAndDontRequeueException("Email processing failed", e);
        }
    }
    
    // Priority queue handling
    @RabbitListener(queues = "priority.queue")
    public void handlePriorityMessage(@Payload PriorityEvent event,
                                    Message message) {
        Integer priority = (Integer) message.getMessageProperties().getHeaders().get("priority");
        
        try {
            log.info("Processing priority event: {} with priority: {}", 
                event.getEventId(), priority);
            
            // Process based on priority
            if (priority != null && priority > 5) {
                priorityService.processHighPriority(event);
            } else {
                priorityService.processNormalPriority(event);
            }
            
            messagingMetrics.recordRabbitMQConsumerSuccess("priority.queue");
            
        } catch (Exception e) {
            messagingMetrics.recordRabbitMQConsumerFailure("priority.queue", e);
            throw e;
        }
    }
    
    // Delayed message handling
    public void publishDelayedMessage(Object payload, RabbitMQPublishOptions options, Duration delay) {
        try {
            MessageProperties properties = new MessageProperties();
            properties.setHeader("x-delay", delay.toMillis());
            properties.setDeliveryMode(MessageDeliveryMode.PERSISTENT);
            
            Message message = new Message(objectMapper.writeValueAsBytes(payload), properties);
            
            rabbitTemplate.send("delayed.exchange", options.getRoutingKey(), message);
            
            messagingMetrics.recordDelayedMessageScheduled(delay);
            
        } catch (Exception e) {
            log.error("Failed to publish delayed message", e);
            throw new RabbitMQPublishException("Failed to publish delayed message", e);
        }
    }
    
    // Queue and exchange management
    public void setupQueueTopology() {
        // Create exchanges
        createExchange("notification.exchange", ExchangeTypes.TOPIC);
        createExchange("email.exchange", ExchangeTypes.DIRECT);
        createExchange("priority.exchange", ExchangeTypes.TOPIC, true); // with priority support
        createExchange("delayed.exchange", "x-delayed-message"); // delayed message plugin
        
        // Create queues
        createQueue("notification.queue", "notification.dlq");
        createQueue("email.queue", "email.dlq");
        createPriorityQueue("priority.queue", "priority.dlq", 10);
        
        // Create bindings
        createBinding("notification.queue", "notification.exchange", "notification.*");
        createBinding("email.queue", "email.exchange", "email");
        createBinding("priority.queue", "priority.exchange", "priority.*");
    }
    
    private void createExchange(String exchangeName, String exchangeType) {
        createExchange(exchangeName, exchangeType, false);
    }
    
    private void createExchange(String exchangeName, String exchangeType, boolean withPriority) {
        Exchange exchange;
        
        switch (exchangeType) {
            case ExchangeTypes.DIRECT:
                exchange = ExchangeBuilder.directExchange(exchangeName).durable(true).build();
                break;
            case ExchangeTypes.TOPIC:
                exchange = ExchangeBuilder.topicExchange(exchangeName).durable(true).build();
                break;
            case ExchangeTypes.FANOUT:
                exchange = ExchangeBuilder.fanoutExchange(exchangeName).durable(true).build();
                break;
            case "x-delayed-message":
                exchange = new CustomExchange(exchangeName, "x-delayed-message", true, false,
                    Map.of("x-delayed-type", "topic"));
                break;
            default:
                throw new IllegalArgumentException("Unsupported exchange type: " + exchangeType);
        }
        
        rabbitAdmin.declareExchange(exchange);
    }
    
    private void createQueue(String queueName, String dlqName) {
        // Create dead letter queue first
        Queue dlq = QueueBuilder.durable(dlqName).build();
        rabbitAdmin.declareQueue(dlq);
        
        // Create main queue with DLQ configuration
        Queue queue = QueueBuilder.durable(queueName)
            .withArgument("x-dead-letter-exchange", "")
            .withArgument("x-dead-letter-routing-key", dlqName)
            .withArgument("x-message-ttl", 300000) // 5 minutes TTL
            .build();
        
        rabbitAdmin.declareQueue(queue);
    }
    
    private void createPriorityQueue(String queueName, String dlqName, int maxPriority) {
        // Create dead letter queue
        Queue dlq = QueueBuilder.durable(dlqName).build();
        rabbitAdmin.declareQueue(dlq);
        
        // Create priority queue
        Queue queue = QueueBuilder.durable(queueName)
            .withArgument("x-max-priority", maxPriority)
            .withArgument("x-dead-letter-exchange", "")
            .withArgument("x-dead-letter-routing-key", dlqName)
            .build();
        
        rabbitAdmin.declareQueue(queue);
    }
    
    private void createBinding(String queueName, String exchangeName, String routingKey) {
        Binding binding = BindingBuilder
            .bind(new Queue(queueName))
            .to(new TopicExchange(exchangeName))
            .with(routingKey);
        
        rabbitAdmin.declareBinding(binding);
    }
    
    private Message createMessage(Object payload, RabbitMQPublishOptions options) throws JsonProcessingException {
        MessageProperties properties = new MessageProperties();
        
        // Set basic properties
        properties.setContentType("application/json");
        properties.setDeliveryMode(options.isPersistent() ? 
            MessageDeliveryMode.PERSISTENT : MessageDeliveryMode.NON_PERSISTENT);
        
        // Set priority
        if (options.getPriority() != null) {
            properties.setPriority(options.getPriority());
        }
        
        // Set TTL
        if (options.getTtl() != null) {
            properties.setExpiration(String.valueOf(options.getTtl().toMillis()));
        }
        
        // Set headers
        properties.setHeader("messageId", UUID.randomUUID().toString());
        properties.setHeader("timestamp", Instant.now().toEpochMilli());
        
        byte[] body = objectMapper.writeValueAsBytes(payload);
        return new Message(body, properties);
    }
    
    private void configureRabbitTemplate() {
        // Enable publisher confirms
        rabbitTemplate.setConfirmCallback((correlationData, ack, cause) -> {
            if (ack) {
                messagingMetrics.recordPublisherConfirmSuccess();
            } else {
                messagingMetrics.recordPublisherConfirmFailure(cause);
                log.error("Publisher confirm failed: {}", cause);
            }
        });
        
        // Enable publisher returns
        rabbitTemplate.setReturnsCallback(returned -> {
            messagingMetrics.recordPublisherReturn();
            log.warn("Message returned: {}", returned.getMessage());
        });
        
        // Set mandatory flag
        rabbitTemplate.setMandatory(true);
    }
}
```

---

## 🔄 Reliability Patterns

### 1. Message Deduplication

```java
// Message deduplication service
@Service
public class MessageDeduplicationService {
    
    @Autowired
    private RedisTemplate<String, String> redisTemplate;
    
    @Autowired
    private MessageRepository messageRepository;
    
    public boolean isDuplicate(String messageId, Duration windowDuration) {
        String key = "dedup:" + messageId;
        
        // Check Redis first (fast path)
        Boolean exists = redisTemplate.hasKey(key);
        if (Boolean.TRUE.equals(exists)) {
            return true;
        }
        
        // Check database for longer-term deduplication
        boolean existsInDb = messageRepository.existsByMessageIdAndTimestampAfter(
            messageId, Instant.now().minus(windowDuration));
        
        if (existsInDb) {
            // Cache the result in Redis
            redisTemplate.opsForValue().set(key, "1", windowDuration);
            return true;
        }
        
        return false;
    }
    
    public void markAsProcessed(String messageId, Duration windowDuration) {
        String key = "dedup:" + messageId;
        
        // Store in Redis for fast lookup
        redisTemplate.opsForValue().set(key, "1", windowDuration);
        
        // Store in database for long-term deduplication
        MessageDeduplicationRecord record = new MessageDeduplicationRecord(
            messageId, Instant.now());
        messageRepository.save(record);
    }
    
    @Scheduled(fixedRate = 3600000) // Run every hour
    public void cleanupOldRecords() {
        Instant cutoff = Instant.now().minus(Duration.ofDays(1));
        int deletedCount = messageRepository.deleteByTimestampBefore(cutoff);
        
        log.info("Cleaned up {} old deduplication records", deletedCount);
    }
}
```

### 2. Retry and Dead Letter Queue Management

```java
// Comprehensive retry and DLQ management
@Service
public class RetryAndDLQService {
    
    @Autowired
    private KafkaTemplate<String, Object> kafkaTemplate;
    
    @Autowired
    private RabbitTemplate rabbitTemplate;
    
    @Autowired
    private MessagingMetrics messagingMetrics;
    
    @Value("${messaging.retry.max-attempts:3}")
    private int maxRetryAttempts;
    
    @Value("${messaging.retry.base-delay:1000}")
    private long baseDelayMs;
    
    public void processWithRetry(ProcessableMessage message, MessageProcessor processor) {
        RetryPolicy retryPolicy = createRetryPolicy(message);
        
        try {
            retryPolicy.execute(() -> {
                try {
                    processor.process(message);
                    messagingMetrics.recordProcessingSuccess(message.getType());
                    return null;
                } catch (Exception e) {
                    messagingMetrics.recordProcessingFailure(message.getType(), e);
                    
                    // Increment retry count
                    message.incrementRetryCount();
                    
                    if (message.getRetryCount() >= maxRetryAttempts) {
                        sendToDeadLetterQueue(message, e);
                        throw new MaxRetriesExceededException("Max retries exceeded", e);
                    }
                    
                    // Determine if exception is retryable
                    if (isRetryableException(e)) {
                        throw new RetryableException("Retryable error", e);
                    } else {
                        sendToDeadLetterQueue(message, e);
                        throw new NonRetryableException("Non-retryable error", e);
                    }
                }
            });
            
        } catch (MaxRetriesExceededException | NonRetryableException e) {
            log.error("Message processing failed permanently: {}", message.getId(), e);
        }
    }
    
    private RetryPolicy createRetryPolicy(ProcessableMessage message) {
        return RetryPolicy.builder()
            .maxAttempts(maxRetryAttempts - message.getRetryCount())
            .exponentialBackoff(baseDelayMs, 2.0, Duration.ofMinutes(5))
            .jitter(0.1)
            .retryOn(RetryableException.class)
            .build();
    }
    
    private void sendToDeadLetterQueue(ProcessableMessage message, Exception error) {
        try {
            DeadLetterMessage dlqMessage = new DeadLetterMessage(
                message,
                error.getMessage(),
                Instant.now(),
                determineRetryEligibility(error)
            );
            
            if (message.getSource() == MessageSource.KAFKA) {
                sendToKafkaDLQ(dlqMessage);
            } else if (message.getSource() == MessageSource.RABBITMQ) {
                sendToRabbitMQDLQ(dlqMessage);
            }
            
            messagingMetrics.recordDeadLetterMessage(message.getType());
            
        } catch (Exception e) {
            log.error("Failed to send message to DLQ", e);
        }
    }
    
    private void sendToKafkaDLQ(DeadLetterMessage dlqMessage) {
        String dlqTopic = dlqMessage.getOriginalMessage().getTopic() + "-dlq";
        
        kafkaTemplate.send(dlqTopic, dlqMessage.getOriginalMessage().getKey(), dlqMessage);
    }
    
    private void sendToRabbitMQDLQ(DeadLetterMessage dlqMessage) {
        String dlqRoutingKey = dlqMessage.getOriginalMessage().getRoutingKey() + ".dlq";
        
        rabbitTemplate.convertAndSend("dlq.exchange", dlqRoutingKey, dlqMessage);
    }
    
    // DLQ processing for retry-eligible messages
    @KafkaListener(topics = "#{'${messaging.dlq.topics}'.split(',')}")
    public void processDLQMessage(@Payload DeadLetterMessage dlqMessage) {
        if (dlqMessage.isRetryEligible() && shouldRetryFromDLQ(dlqMessage)) {
            try {
                // Reprocess the original message
                processWithRetry(dlqMessage.getOriginalMessage(), getProcessorForType(dlqMessage.getOriginalMessage().getType()));
                
                messagingMetrics.recordDLQRetrySuccess(dlqMessage.getOriginalMessage().getType());
                
            } catch (Exception e) {
                log.error("DLQ retry failed for message: {}", dlqMessage.getOriginalMessage().getId(), e);
                messagingMetrics.recordDLQRetryFailure(dlqMessage.getOriginalMessage().getType(), e);
            }
        }
    }
    
    private boolean isRetryableException(Exception e) {
        return e instanceof TimeoutException ||
               e instanceof ConnectException ||
               e instanceof SocketTimeoutException ||
               e instanceof ServiceUnavailableException ||
               (e instanceof RuntimeException && e.getCause() instanceof IOException);
    }
    
    private RetryEligibility determineRetryEligibility(Exception error) {
        if (error instanceof ValidationException || 
            error instanceof IllegalArgumentException ||
            error instanceof SecurityException) {
            return RetryEligibility.NOT_ELIGIBLE;
        } else if (error instanceof TimeoutException ||
                  error instanceof ConnectException) {
            return RetryEligibility.ELIGIBLE_IMMEDIATE;
        } else {
            return RetryEligibility.ELIGIBLE_DELAYED;
        }
    }
    
    private boolean shouldRetryFromDLQ(DeadLetterMessage dlqMessage) {
        // Check if enough time has passed since the message was sent to DLQ
        Duration timeSinceDLQ = Duration.between(dlqMessage.getDlqTimestamp(), Instant.now());
        
        return timeSinceDLQ.compareTo(Duration.ofMinutes(30)) > 0 && // Wait at least 30 minutes
               dlqMessage.getOriginalMessage().getRetryCount() < maxRetryAttempts * 2; // Allow extended retries from DLQ
    }
    
    private MessageProcessor getProcessorForType(String messageType) {
        return messageProcessorRegistry.getProcessor(messageType);
    }
}
```

---

## 🎯 Interview Focus Areas

### Key Messaging Questions

**Q: When would you choose Kafka vs RabbitMQ vs SQS?**
- **Kafka**: High-throughput event streaming, log aggregation
- **RabbitMQ**: Complex routing, reliability, traditional messaging
- **SQS**: Cloud-native, simple queuing, managed service

**Q: How do you ensure message ordering?**
- **Single partition** in Kafka for strict ordering
- **Message groups** in SQS FIFO queues
- **Single consumer** per partition/queue
- **Sequence numbers** for application-level ordering

**Q: How do you handle message failures and retries?**
- **Exponential backoff** with jitter
- **Dead letter queues** for failed messages
- **Circuit breakers** for downstream failures
- **Idempotency** for safe retries

**Q: How do you scale message processing?**
- **Horizontal scaling** with multiple consumers
- **Partitioning** for parallel processing
- **Batch processing** for efficiency
- **Back pressure** handling

---

## 🚀 Next Steps

1. **Complete the hands-on exercises** in the exercises folder
2. **Practice message broker selection** for different scenarios
3. **Implement retry mechanisms** with proper error handling
4. **Design event-driven architectures** with loose coupling
5. **Move to Module 7: Microservices Architecture**

The messaging module provides the foundation for building scalable, reliable, and loosely-coupled distributed systems.
