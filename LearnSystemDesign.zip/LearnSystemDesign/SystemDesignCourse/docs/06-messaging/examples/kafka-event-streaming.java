// Production-ready Kafka event streaming implementation
package com.systemdesign.messaging.examples;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Comprehensive Kafka event streaming implementation
 * demonstrating event-driven architecture patterns for system design
 */
@Service
public class KafkaEventStreamingImplementation {
    
    @Autowired
    private KafkaTemplate<String, Object> kafkaTemplate;
    
    @Autowired
    private EventStore eventStore;
    
    @Autowired
    private MetricsCollector metricsCollector;
    
    /**
     * Event producer with guaranteed delivery and ordering
     */
    @Component
    public static class ReliableEventProducer {
        
        @Autowired
        private KafkaTemplate<String, Object> kafkaTemplate;
        
        @Autowired
        private EventDeduplicationService deduplicationService;
        
        @Autowired
        private EventMetrics eventMetrics;
        
        /**
         * Publish event with guaranteed delivery
         */
        public CompletableFuture<EventPublishResult> publishEvent(DomainEvent event) {
            String eventId = event.getEventId();
            
            // Check for duplicate events
            if (deduplicationService.isDuplicate(eventId)) {
                log.debug("Duplicate event detected, skipping: {}", eventId);
                return CompletableFuture.completedFuture(
                    EventPublishResult.duplicate(eventId));
            }
            
            // Add event metadata
            event.setPublishedAt(Instant.now());
            event.setProducerId(getProducerId());
            
            // Determine partition key for ordering
            String partitionKey = determinePartitionKey(event);
            
            try {
                // Publish to Kafka with callback
                ListenableFuture<SendResult<String, Object>> future = kafkaTemplate.send(
                    event.getTopicName(), 
                    partitionKey, 
                    event
                );
                
                return toCompletableFuture(future, event);
                
            } catch (Exception e) {
                eventMetrics.recordPublishFailure(event.getTopicName(), e);
                return CompletableFuture.completedFuture(
                    EventPublishResult.failure(eventId, e.getMessage()));
            }
        }
        
        /**
         * Batch publish for high throughput scenarios
         */
        public CompletableFuture<BatchPublishResult> publishEventsBatch(List<DomainEvent> events) {
            List<CompletableFuture<EventPublishResult>> futures = new ArrayList<>();
            
            for (DomainEvent event : events) {
                futures.add(publishEvent(event));
            }
            
            return CompletableFuture.allOf(futures.toArray(new CompletableFuture[0]))
                .thenApply(v -> {
                    List<EventPublishResult> results = futures.stream()
                        .map(CompletableFuture::join)
                        .toList();
                    
                    return BatchPublishResult.from(results);
                });
        }
        
        /**
         * Publish event with transactional guarantees
         */
        @Transactional
        public void publishEventTransactionally(DomainEvent event) {
            // Store event in local transaction
            eventStore.storeEvent(event);
            
            // Publish to Kafka (will be committed with DB transaction)
            kafkaTemplate.send(event.getTopicName(), event);
            
            eventMetrics.recordTransactionalPublish(event.getTopicName());
        }
        
        private String determinePartitionKey(DomainEvent event) {
            // Ensure events for the same entity go to the same partition
            return switch (event.getEventType()) {
                case "USER_CREATED", "USER_UPDATED", "USER_DELETED" -> 
                    STR."user:\{event.getAggregateId()}";
                case "ORDER_CREATED", "ORDER_UPDATED", "ORDER_CANCELLED" -> 
                    STR."order:\{event.getAggregateId()}";
                case "PAYMENT_PROCESSED", "PAYMENT_FAILED" -> 
                    STR."payment:\{event.getAggregateId()}";
                default -> event.getAggregateId();
            };
        }
        
        private CompletableFuture<EventPublishResult> toCompletableFuture(
                ListenableFuture<SendResult<String, Object>> future, DomainEvent event) {
            
            CompletableFuture<EventPublishResult> completableFuture = new CompletableFuture<>();
            
            future.addCallback(
                result -> {
                    // Success callback
                    deduplicationService.markAsPublished(event.getEventId());
                    eventMetrics.recordPublishSuccess(event.getTopicName());
                    
                    RecordMetadata metadata = result.getRecordMetadata();
                    EventPublishResult publishResult = EventPublishResult.success(
                        event.getEventId(),
                        metadata.topic(),
                        metadata.partition(),
                        metadata.offset()
                    );
                    
                    completableFuture.complete(publishResult);
                },
                failure -> {
                    // Failure callback
                    eventMetrics.recordPublishFailure(event.getTopicName(), failure);
                    
                    EventPublishResult publishResult = EventPublishResult.failure(
                        event.getEventId(), failure.getMessage());
                    
                    completableFuture.complete(publishResult);
                }
            );
            
            return completableFuture;
        }
        
        private String getProducerId() {
            return STR."\{getHostname()}-\{getProcessId()}";
        }
    }
    
    /**
     * Event consumer with reliable processing and error handling
     */
    @Component
    public static class ReliableEventConsumer {
        
        @Autowired
        private EventProcessingService processingService;
        
        @Autowired
        private DeadLetterQueueService dlqService;
        
        @Autowired
        private EventMetrics eventMetrics;
        
        /**
         * Process user events with idempotency and error handling
         */
        @KafkaListener(
            topics = "user-events",
            groupId = "user-event-processor",
            containerFactory = "kafkaListenerContainerFactory"
        )
        public void processUserEvent(
                @Payload UserEvent event,
                @Header(KafkaHeaders.RECEIVED_TOPIC) String topic,
                @Header(KafkaHeaders.RECEIVED_PARTITION_ID) int partition,
                @Header(KafkaHeaders.RECEIVED_MESSAGE_KEY) String key,
                @Header(KafkaHeaders.OFFSET) long offset,
                Acknowledgment acknowledgment) {
            
            String eventId = event.getEventId();
            
            try {
                log.info("Processing user event: {} from partition: {}, offset: {}", 
                    eventId, partition, offset);
                
                // Check if already processed (idempotency)
                if (processingService.isAlreadyProcessed(eventId)) {
                    log.debug("Event already processed, skipping: {}", eventId);
                    acknowledgment.acknowledge();
                    return;
                }
                
                // Process the event
                EventProcessingResult result = processUserEventInternal(event);
                
                if (result.isSuccess()) {
                    // Mark as processed
                    processingService.markAsProcessed(eventId);
                    
                    // Acknowledge successful processing
                    acknowledgment.acknowledge();
                    
                    eventMetrics.recordProcessingSuccess(topic, event.getEventType());
                    
                } else {
                    // Handle processing failure
                    handleProcessingFailure(event, result.getError(), acknowledgment);
                }
                
            } catch (Exception e) {
                log.error("Unexpected error processing user event: {}", eventId, e);
                handleProcessingFailure(event, e, acknowledgment);
            }
        }
        
        /**
         * Process order events with saga coordination
         */
        @KafkaListener(
            topics = "order-events",
            groupId = "order-event-processor"
        )
        public void processOrderEvent(@Payload OrderEvent event, Acknowledgment acknowledgment) {
            try {
                log.info("Processing order event: {} for order: {}", 
                    event.getEventType(), event.getOrderId());
                
                switch (event.getEventType()) {
                    case "ORDER_CREATED":
                        handleOrderCreated((OrderCreatedEvent) event);
                        break;
                    case "ORDER_PAYMENT_PROCESSED":
                        handleOrderPaymentProcessed((OrderPaymentProcessedEvent) event);
                        break;
                    case "ORDER_SHIPPED":
                        handleOrderShipped((OrderShippedEvent) event);
                        break;
                    case "ORDER_CANCELLED":
                        handleOrderCancelled((OrderCancelledEvent) event);
                        break;
                    default:
                        log.warn("Unknown order event type: {}", event.getEventType());
                }
                
                acknowledgment.acknowledge();
                eventMetrics.recordProcessingSuccess("order-events", event.getEventType());
                
            } catch (Exception e) {
                log.error("Failed to process order event: {}", event.getEventId(), e);
                handleProcessingFailure(event, e, acknowledgment);
            }
        }
        
        /**
         * Process payment events with retry logic
         */
        @RetryableTopic(
            attempts = "3",
            backoff = @Backoff(delay = 1000, multiplier = 2),
            dltStrategy = DltStrategy.FAIL_ON_ERROR
        )
        @KafkaListener(topics = "payment-events", groupId = "payment-processor")
        public void processPaymentEvent(@Payload PaymentEvent event) {
            try {
                log.info("Processing payment event: {} for payment: {}", 
                    event.getEventType(), event.getPaymentId());
                
                PaymentProcessingResult result = paymentProcessor.processEvent(event);
                
                if (!result.isSuccess()) {
                    throw new PaymentProcessingException(result.getErrorMessage());
                }
                
                eventMetrics.recordProcessingSuccess("payment-events", event.getEventType());
                
            } catch (Exception e) {
                log.error("Payment processing failed: {}", event.getEventId(), e);
                eventMetrics.recordProcessingFailure("payment-events", event.getEventType(), e);
                throw e; // Will trigger retry or DLT
            }
        }
        
        /**
         * Handle events that couldn't be processed after retries
         */
        @DltHandler
        public void handleDltEvent(@Payload Object event, 
                                  @Header(KafkaHeaders.RECEIVED_TOPIC) String originalTopic) {
            log.error("Event sent to DLT from topic: {}, event: {}", originalTopic, event);
            
            dlqService.handleFailedEvent(FailedEvent.builder()
                .originalTopic(originalTopic)
                .event(event)
                .failedAt(Instant.now())
                .build());
            
            eventMetrics.recordDltEvent(originalTopic);
        }
        
        private EventProcessingResult processUserEventInternal(UserEvent event) {
            return switch (event.getEventType()) {
                case "USER_CREATED" -> handleUserCreated((UserCreatedEvent) event);
                case "USER_UPDATED" -> handleUserUpdated((UserUpdatedEvent) event);
                case "USER_DELETED" -> handleUserDeleted((UserDeletedEvent) event);
                default -> EventProcessingResult.failure(
                    STR."Unknown user event type: \{event.getEventType()}");
            };
        }
        
        private EventProcessingResult handleUserCreated(UserCreatedEvent event) {
            try {
                // Send welcome email
                emailService.sendWelcomeEmail(event.getUserId(), event.getEmail());
                
                // Create user analytics profile
                analyticsService.createUserProfile(event.getUserId());
                
                // Add to marketing campaign
                marketingService.addToWelcomeCampaign(event.getUserId());
                
                return EventProcessingResult.success();
                
            } catch (Exception e) {
                return EventProcessingResult.failure(e.getMessage());
            }
        }
        
        private void handleProcessingFailure(Object event, Throwable error, Acknowledgment acknowledgment) {
            if (isRetryableError(error)) {
                // Don't acknowledge - let Kafka retry
                log.warn("Retryable error processing event, will retry: {}", error.getMessage());
                eventMetrics.recordProcessingRetry(event.getClass().getSimpleName());
            } else {
                // Non-retryable error - send to DLQ and acknowledge
                dlqService.sendToDeadLetterQueue(event, error);
                acknowledgment.acknowledge();
                eventMetrics.recordProcessingFailure(event.getClass().getSimpleName(), error);
            }
        }
        
        private boolean isRetryableError(Throwable error) {
            return error instanceof TransientException ||
                   error instanceof TimeoutException ||
                   error instanceof ConnectException;
        }
    }
    
    /**
     * Event sourcing implementation with Kafka as event store
     */
    @Component
    public static class EventSourcingService {
        
        @Autowired
        private KafkaTemplate<String, Object> kafkaTemplate;
        
        @Autowired
        private EventDeserializer eventDeserializer;
        
        /**
         * Store events in Kafka for event sourcing
         */
        public void storeEvent(String aggregateId, DomainEvent event) {
            String topicName = STR."events-\{event.getAggregateType()}";
            
            // Use aggregate ID as partition key for ordering
            kafkaTemplate.send(topicName, aggregateId, event)
                .addCallback(
                    result -> log.debug("Event stored: {}", event.getEventId()),
                    failure -> log.error("Failed to store event: {}", event.getEventId(), failure)
                );
        }
        
        /**
         * Replay events to rebuild aggregate state
         */
        public List<DomainEvent> getEvents(String aggregateId, String aggregateType) {
            String topicName = STR."events-\{aggregateType}";
            
            // Use Kafka Consumer to read events for specific aggregate
            return readEventsFromTopic(topicName, aggregateId);
        }
        
        /**
         * Project events to read models
         */
        @KafkaListener(topics = "events-user", groupId = "user-projection")
        public void projectUserEvents(@Payload UserDomainEvent event) {
            try {
                switch (event.getEventType()) {
                    case "UserCreated":
                        userProjection.createUser((UserCreatedEvent) event);
                        break;
                    case "UserUpdated":
                        userProjection.updateUser((UserUpdatedEvent) event);
                        break;
                    case "UserDeleted":
                        userProjection.deleteUser((UserDeletedEvent) event);
                        break;
                }
                
            } catch (Exception e) {
                log.error("Failed to project user event: {}", event.getEventId(), e);
                throw e;
            }
        }
        
        private List<DomainEvent> readEventsFromTopic(String topicName, String aggregateId) {
            // Implementation to read events from Kafka topic
            // Filter by aggregate ID and return in order
            return kafkaConsumerService.readEventsForAggregate(topicName, aggregateId);
        }
    }
    
    /**
     * Event deduplication service
     */
    @Service
    public static class EventDeduplicationService {
        
        @Autowired
        private RedisTemplate<String, String> redisTemplate;
        
        private static final String DEDUP_PREFIX = "event:dedup:";
        private static final Duration DEDUP_TTL = Duration.ofHours(24);
        
        public boolean isDuplicate(String eventId) {
            String key = DEDUP_PREFIX + eventId;
            return Boolean.TRUE.equals(redisTemplate.hasKey(key));
        }
        
        public void markAsPublished(String eventId) {
            String key = DEDUP_PREFIX + eventId;
            redisTemplate.opsForValue().set(key, "published", DEDUP_TTL);
        }
        
        public void markAsProcessed(String eventId) {
            String key = DEDUP_PREFIX + eventId;
            redisTemplate.opsForValue().set(key, "processed", DEDUP_TTL);
        }
    }
    
    /**
     * Dead Letter Queue service for failed events
     */
    @Service
    public static class DeadLetterQueueService {
        
        @Autowired
        private KafkaTemplate<String, Object> kafkaTemplate;
        
        @Autowired
        private FailedEventRepository failedEventRepository;
        
        public void sendToDeadLetterQueue(Object event, Throwable error) {
            FailedEvent failedEvent = FailedEvent.builder()
                .eventData(serializeEvent(event))
                .eventType(event.getClass().getSimpleName())
                .errorMessage(error.getMessage())
                .stackTrace(getStackTrace(error))
                .failedAt(Instant.now())
                .retryCount(0)
                .build();
            
            // Store in database for analysis
            failedEventRepository.save(failedEvent);
            
            // Send to DLQ topic
            kafkaTemplate.send("dead-letter-queue", failedEvent);
            
            log.error("Event sent to DLQ: {}", failedEvent.getId());
        }
        
        public void handleFailedEvent(FailedEvent failedEvent) {
            // Store failed event for manual investigation
            failedEventRepository.save(failedEvent);
            
            // Send alert for manual intervention
            alertService.sendFailedEventAlert(failedEvent);
        }
        
        /**
         * Retry failed events after fixing issues
         */
        public void retryFailedEvent(String failedEventId) {
            FailedEvent failedEvent = failedEventRepository.findById(failedEventId)
                .orElseThrow(() -> new EntityNotFoundException("Failed event not found"));
            
            try {
                // Increment retry count
                failedEvent.setRetryCount(failedEvent.getRetryCount() + 1);
                failedEvent.setLastRetryAt(Instant.now());
                
                // Deserialize and republish event
                Object originalEvent = deserializeEvent(failedEvent.getEventData(), 
                    failedEvent.getEventType());
                
                String originalTopic = determineOriginalTopic(failedEvent.getEventType());
                kafkaTemplate.send(originalTopic, originalEvent);
                
                log.info("Retrying failed event: {}", failedEventId);
                
            } catch (Exception e) {
                log.error("Failed to retry event: {}", failedEventId, e);
                failedEvent.setLastRetryError(e.getMessage());
            } finally {
                failedEventRepository.save(failedEvent);
            }
        }
    }
    
    // Supporting classes and data structures
    
    @Data
    @Builder
    public static class EventPublishResult {
        private String eventId;
        private boolean success;
        private String errorMessage;
        private String topic;
        private int partition;
        private long offset;
        
        public static EventPublishResult success(String eventId, String topic, int partition, long offset) {
            return EventPublishResult.builder()
                .eventId(eventId)
                .success(true)
                .topic(topic)
                .partition(partition)
                .offset(offset)
                .build();
        }
        
        public static EventPublishResult failure(String eventId, String errorMessage) {
            return EventPublishResult.builder()
                .eventId(eventId)
                .success(false)
                .errorMessage(errorMessage)
                .build();
        }
        
        public static EventPublishResult duplicate(String eventId) {
            return EventPublishResult.builder()
                .eventId(eventId)
                .success(true)
                .build();
        }
    }
    
    @Data
    @Builder
    public static class BatchPublishResult {
        private int totalEvents;
        private int successfulEvents;
        private int failedEvents;
        private List<EventPublishResult> results;
        
        public static BatchPublishResult from(List<EventPublishResult> results) {
            int successful = (int) results.stream().filter(EventPublishResult::isSuccess).count();
            int failed = results.size() - successful;
            
            return BatchPublishResult.builder()
                .totalEvents(results.size())
                .successfulEvents(successful)
                .failedEvents(failed)
                .results(results)
                .build();
        }
    }
    
    @Data
    @Builder
    public static class EventProcessingResult {
        private boolean success;
        private String errorMessage;
        
        public static EventProcessingResult success() {
            return EventProcessingResult.builder().success(true).build();
        }
        
        public static EventProcessingResult failure(String errorMessage) {
            return EventProcessingResult.builder()
                .success(false)
                .errorMessage(errorMessage)
                .build();
        }
        
        public Throwable getError() {
            return success ? null : new RuntimeException(errorMessage);
        }
    }
    
    @Data
    @Builder
    public static class FailedEvent {
        private String id;
        private String eventData;
        private String eventType;
        private String originalTopic;
        private String errorMessage;
        private String stackTrace;
        private Instant failedAt;
        private int retryCount;
        private Instant lastRetryAt;
        private String lastRetryError;
        private Object event;
    }
    
    // Base event classes
    public abstract static class DomainEvent {
        protected String eventId = UUID.randomUUID().toString();
        protected String aggregateId;
        protected String aggregateType;
        protected String eventType;
        protected Instant occurredAt = Instant.now();
        protected Instant publishedAt;
        protected String producerId;
        
        public abstract String getTopicName();
        
        // Getters and setters...
    }
    
    public static class UserEvent extends DomainEvent {
        protected String userId;
        
        @Override
        public String getTopicName() {
            return "user-events";
        }
    }
    
    public static class UserCreatedEvent extends UserEvent {
        private String email;
        private String username;
        
        public UserCreatedEvent() {
            this.eventType = "USER_CREATED";
            this.aggregateType = "User";
        }
    }
}
