#!/bin/bash

# System Design Course Deployment Script
# Supports local, staging, and production deployments

set -e  # Exit on any error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
ENVIRONMENT=${1:-local}
SERVICE=${2:-all}

# Print colored output
print_status() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_header() {
    echo -e "${BLUE}===============================================${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}===============================================${NC}"
}

# Show usage
show_usage() {
    echo "Usage: $0 [ENVIRONMENT] [SERVICE]"
    echo ""
    echo "ENVIRONMENT:"
    echo "  local      - Local Docker deployment (default)"
    echo "  staging    - Staging Kubernetes deployment"
    echo "  production - Production Kubernetes deployment"
    echo ""
    echo "SERVICE:"
    echo "  all        - Deploy all services (default)"
    echo "  user       - Deploy user service only"
    echo "  infra      - Deploy infrastructure only"
    echo ""
    echo "Examples:"
    echo "  $0 local all"
    echo "  $0 staging user"
    echo "  $0 production infra"
}

# Validate environment
validate_environment() {
    case $ENVIRONMENT in
        local|staging|production)
            print_status "Deploying to environment: $ENVIRONMENT"
            ;;
        *)
            print_error "Invalid environment: $ENVIRONMENT"
            show_usage
            exit 1
            ;;
    esac
}

# Check prerequisites
check_prerequisites() {
    print_header "Checking Prerequisites"
    
    local missing_tools=()
    
    # Common tools
    if ! command -v docker &> /dev/null; then
        missing_tools+=("docker")
    fi
    
    if ! command -v docker-compose &> /dev/null; then
        missing_tools+=("docker-compose")
    fi
    
    # Environment-specific tools
    if [[ "$ENVIRONMENT" != "local" ]]; then
        if ! command -v kubectl &> /dev/null; then
            missing_tools+=("kubectl")
        fi
        
        if ! command -v helm &> /dev/null; then
            missing_tools+=("helm")
        fi
    fi
    
    if [ ${#missing_tools[@]} -ne 0 ]; then
        print_error "Missing required tools: ${missing_tools[*]}"
        exit 1
    fi
    
    print_status "All prerequisites satisfied"
}

# Build services
build_services() {
    print_header "Building Services"
    
    cd "$PROJECT_ROOT"
    
    if [[ "$SERVICE" == "all" || "$SERVICE" == "user" ]]; then
        print_status "Building user service..."
        cd code/modules/01-foundations
        ./mvnw clean package -DskipTests
        
        if [[ "$ENVIRONMENT" != "local" ]]; then
            print_status "Building Docker image for user service..."
            docker build -t system-design/user-service:latest .
            
            if [[ "$ENVIRONMENT" == "production" ]]; then
                # Tag for production registry
                docker tag system-design/user-service:latest \
                    your-registry.com/system-design/user-service:$(git rev-parse --short HEAD)
                docker push your-registry.com/system-design/user-service:$(git rev-parse --short HEAD)
            fi
        fi
        
        cd "$PROJECT_ROOT"
    fi
    
    print_status "Build completed successfully"
}

# Deploy to local environment
deploy_local() {
    print_header "Deploying to Local Environment"
    
    cd "$PROJECT_ROOT"
    
    if [[ "$SERVICE" == "all" || "$SERVICE" == "infra" ]]; then
        print_status "Starting infrastructure services..."
        docker-compose -f infra/docker/local-stack.yml up -d
        
        # Wait for services to be ready
        print_status "Waiting for services to be ready..."
        sleep 30
        
        # Verify services
        check_service_health "PostgreSQL" "localhost" "5432"
        check_service_health "Redis" "localhost" "6379"
        check_service_health "Kafka" "localhost" "9092"
    fi
    
    if [[ "$SERVICE" == "all" || "$SERVICE" == "user" ]]; then
        print_status "Starting user service..."
        cd code/modules/01-foundations
        
        # Run in background if deploying all services
        if [[ "$SERVICE" == "all" ]]; then
            nohup ./mvnw spring-boot:run > /tmp/user-service.log 2>&1 &
            sleep 10
            check_service_health "User Service" "localhost" "8080"
        else
            ./mvnw spring-boot:run
        fi
    fi
}

# Deploy to Kubernetes
deploy_kubernetes() {
    print_header "Deploying to Kubernetes ($ENVIRONMENT)"
    
    # Set kubectl context
    local context=""
    case $ENVIRONMENT in
        staging)
            context="staging-cluster"
            ;;
        production)
            context="production-cluster"
            ;;
    esac
    
    if [[ -n "$context" ]]; then
        print_status "Setting kubectl context to $context"
        kubectl config use-context $context
    fi
    
    # Create namespace if it doesn't exist
    kubectl create namespace system-design --dry-run=client -o yaml | kubectl apply -f -
    
    if [[ "$SERVICE" == "all" || "$SERVICE" == "infra" ]]; then
        print_status "Deploying infrastructure components..."
        
        # Deploy PostgreSQL
        helm repo add bitnami https://charts.bitnami.com/bitnami
        helm upgrade --install postgres bitnami/postgresql \
            --namespace system-design \
            --set auth.postgresPassword=devpassword \
            --set auth.database=systemdesign \
            --set primary.persistence.size=20Gi \
            --set metrics.enabled=true
        
        # Deploy Redis
        helm upgrade --install redis bitnami/redis \
            --namespace system-design \
            --set auth.password=devpassword \
            --set metrics.enabled=true
        
        # Deploy Kafka
        helm upgrade --install kafka bitnami/kafka \
            --namespace system-design \
            --set metrics.kafka.enabled=true
        
        # Deploy monitoring stack
        if [[ "$ENVIRONMENT" == "production" ]]; then
            helm repo add prometheus-community https://prometheus-community.github.io/helm-charts
            helm upgrade --install monitoring prometheus-community/kube-prometheus-stack \
                --namespace monitoring \
                --create-namespace \
                --values infra/monitoring/values.yaml
        fi
    fi
    
    if [[ "$SERVICE" == "all" || "$SERVICE" == "user" ]]; then
        print_status "Deploying user service..."
        kubectl apply -f infra/kubernetes/user-service-deployment.yaml
        
        # Wait for deployment to be ready
        kubectl rollout status deployment/user-service -n system-design --timeout=300s
        
        # Verify deployment
        kubectl get pods -n system-design -l app=user-service
    fi
}

# Health check helper
check_service_health() {
    local service_name="$1"
    local host="$2"
    local port="$3"
    local max_attempts=30
    local attempt=1
    
    print_status "Checking $service_name health..."
    
    while [ $attempt -le $max_attempts ]; do
        if nc -z "$host" "$port" 2>/dev/null; then
            print_status "$service_name is ready"
            return 0
        fi
        
        print_warning "$service_name not ready, attempt $attempt/$max_attempts"
        sleep 2
        ((attempt++))
    done
    
    print_error "$service_name failed to start"
    return 1
}

# Run database migrations
run_migrations() {
    print_header "Running Database Migrations"
    
    case $ENVIRONMENT in
        local)
            cd "$PROJECT_ROOT/code/modules/01-foundations"
            ./mvnw flyway:migrate -Dflyway.url=jdbc:postgresql://localhost:5432/systemdesign
            ;;
        staging|production)
            kubectl exec -n system-design deployment/user-service -- \
                java -jar app.jar --spring.profiles.active=migration
            ;;
    esac
    
    print_status "Database migrations completed"
}

# Verify deployment
verify_deployment() {
    print_header "Verifying Deployment"
    
    case $ENVIRONMENT in
        local)
            local base_url="http://localhost:8080"
            ;;
        staging)
            local base_url="https://api-staging.systemdesign.example.com"
            ;;
        production)
            local base_url="https://api.systemdesign.example.com"
            ;;
    esac
    
    if [[ "$SERVICE" == "all" || "$SERVICE" == "user" ]]; then
        print_status "Testing user service endpoints..."
        
        # Health check
        if curl -f "$base_url/api/v1/users/health" &>/dev/null; then
            print_status "✓ Health endpoint working"
        else
            print_error "✗ Health endpoint failed"
            return 1
        fi
        
        # Metrics endpoint
        if curl -f "$base_url/actuator/health" &>/dev/null; then
            print_status "✓ Actuator endpoint working"
        else
            print_warning "⚠ Actuator endpoint not accessible"
        fi
        
        # Create test user
        local test_response=$(curl -s -X POST "$base_url/api/v1/users" \
            -H "Content-Type: application/json" \
            -d '{"username":"test-deploy","email":"test@example.com","firstName":"Test","lastName":"Deploy"}')
        
        if [[ $? -eq 0 && "$test_response" =~ "test-deploy" ]]; then
            print_status "✓ User creation working"
        else
            print_error "✗ User creation failed"
            return 1
        fi
    fi
    
    print_status "Deployment verification completed successfully"
}

# Rollback deployment
rollback() {
    print_header "Rolling Back Deployment"
    
    case $ENVIRONMENT in
        local)
            print_status "Stopping local services..."
            docker-compose -f infra/docker/local-stack.yml down
            pkill -f "spring-boot:run" || true
            ;;
        staging|production)
            print_status "Rolling back Kubernetes deployment..."
            kubectl rollout undo deployment/user-service -n system-design
            kubectl rollout status deployment/user-service -n system-design
            ;;
    esac
    
    print_status "Rollback completed"
}

# Main deployment function
main() {
    print_header "System Design Course Deployment"
    print_status "Environment: $ENVIRONMENT"
    print_status "Service: $SERVICE"
    
    validate_environment
    check_prerequisites
    
    # Handle special commands
    if [[ "$SERVICE" == "rollback" ]]; then
        rollback
        exit 0
    fi
    
    build_services
    
    case $ENVIRONMENT in
        local)
            deploy_local
            ;;
        staging|production)
            deploy_kubernetes
            ;;
    esac
    
    run_migrations
    verify_deployment
    
    print_header "Deployment Completed Successfully"
    
    # Show access information
    case $ENVIRONMENT in
        local)
            echo ""
            echo "🌐 Access URLs:"
            echo "- User Service: http://localhost:8080"
            echo "- Swagger UI: http://localhost:8080/swagger-ui.html"
            echo "- Actuator: http://localhost:8080/actuator"
            echo "- Grafana: http://localhost:3000 (admin/admin)"
            echo "- Prometheus: http://localhost:9090"
            echo ""
            ;;
        staging)
            echo ""
            echo "🌐 Staging URLs:"
            echo "- API: https://api-staging.systemdesign.example.com"
            echo "- Monitoring: https://grafana-staging.systemdesign.example.com"
            echo ""
            ;;
        production)
            echo ""
            echo "🌐 Production URLs:"
            echo "- API: https://api.systemdesign.example.com"
            echo "- Monitoring: https://grafana.systemdesign.example.com"
            echo ""
            ;;
    esac
}

# Handle script arguments
if [[ "$1" == "-h" || "$1" == "--help" ]]; then
    show_usage
    exit 0
fi

# Run main function
main "$@"
