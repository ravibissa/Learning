# AWS Services for System Design Cheat Sheet

## 🚀 Essential AWS Services for System Design Interviews

### 🖥️ Compute Services

#### EC2 (Elastic Compute Cloud)
```yaml
Use Cases:
  - Web applications
  - Microservices
  - Batch processing
  - Legacy application migration

Instance Types:
  - t3.micro: 2 vCPU, 1GB RAM (Burstable)
  - m5.large: 2 vCPU, 8GB RAM (General purpose)
  - c5.xlarge: 4 vCPU, 8GB RAM (Compute optimized)
  - r5.large: 2 vCPU, 16GB RAM (Memory optimized)

Pricing Models:
  - On-Demand: Pay per second/hour
  - Reserved: 1-3 year commitments (up to 75% savings)
  - Spot: Bid for unused capacity (up to 90% savings)
  - Dedicated: Physical isolation

Auto Scaling:
  - Target Tracking: CPU, ALB requests
  - Step Scaling: Based on CloudWatch alarms
  - Scheduled: Predictable load patterns
```

#### Lambda (Serverless Functions)
```yaml
Use Cases:
  - Event-driven processing
  - API backends
  - Data transformation
  - Scheduled tasks

Limits:
  - Memory: 128MB - 10GB
  - Timeout: 15 minutes max
  - Payload: 6MB sync, 256KB async
  - Concurrent executions: 1000 (default)

Event Sources:
  - API Gateway
  - S3 events
  - DynamoDB streams
  - SQS/SNS
  - CloudWatch Events
  - Kinesis

Cold Start Optimization:
  - Provisioned concurrency
  - Connection pooling
  - Minimize dependencies
  - Use smaller deployment packages
```

#### ECS (Elastic Container Service)
```yaml
Launch Types:
  - EC2: Manage the cluster
  - Fargate: Serverless containers

Task Definition:
  cpu: 256 (.25 vCPU)
  memory: 512 (MB)
  image: myapp:latest
  portMappings:
    - containerPort: 8080
      protocol: tcp

Service Configuration:
  desiredCount: 3
  launchType: FARGATE
  networkConfiguration:
    subnets: [subnet-123, subnet-456]
    securityGroups: [sg-789]
    assignPublicIp: ENABLED

Auto Scaling:
  - Target tracking (CPU/Memory)
  - Step scaling
  - Scheduled scaling
```

### 💾 Storage Services

#### S3 (Simple Storage Service)
```yaml
Storage Classes:
  - Standard: Frequently accessed data
  - Intelligent-Tiering: Automatic cost optimization
  - Standard-IA: Infrequently accessed
  - Glacier: Archival (minutes to hours retrieval)
  - Glacier Deep Archive: Long-term archival (12+ hours)

Use Cases:
  - Static website hosting
  - Data archival and backup
  - Content distribution
  - Data lakes
  - Application data storage

Performance:
  - 3,500 PUT/COPY/POST/DELETE per second per prefix
  - 5,500 GET/HEAD per second per prefix
  - Multi-part upload for files > 100MB
  - Transfer acceleration via CloudFront

Best Practices:
  - Use meaningful prefixes for performance
  - Enable versioning for data protection
  - Lifecycle policies for cost optimization
  - Cross-region replication for DR
```

#### EBS (Elastic Block Store)
```yaml
Volume Types:
  - gp3: General purpose SSD (up to 16,000 IOPS)
  - io2: Provisioned IOPS SSD (up to 64,000 IOPS)
  - st1: Throughput optimized HDD
  - sc1: Cold HDD

Use Cases:
  - Database storage
  - File systems
  - Boot volumes
  - Application data

Features:
  - Snapshots to S3
  - Encryption at rest
  - Multi-attach (io1/io2)
  - Elastic volumes (resize on-the-fly)
```

#### EFS (Elastic File System)
```yaml
Performance Modes:
  - General Purpose: Up to 7,000 file operations/second
  - Max I/O: Higher performance, slightly higher latency

Throughput Modes:
  - Bursting: Based on file system size
  - Provisioned: Independent of storage amount

Use Cases:
  - Shared storage across multiple EC2 instances
  - Content repositories
  - Web serving
  - Data analytics
```

### 🗄️ Database Services

#### RDS (Relational Database Service)
```yaml
Engines:
  - MySQL: 5.7, 8.0
  - PostgreSQL: 11, 12, 13, 14
  - MariaDB: 10.4, 10.5, 10.6
  - Oracle: 19c, 21c
  - SQL Server: 2017, 2019

Instance Classes:
  - db.t3.micro: 2 vCPU, 1GB RAM
  - db.m5.large: 2 vCPU, 8GB RAM
  - db.r5.xlarge: 4 vCPU, 32GB RAM

High Availability:
  - Multi-AZ deployments
  - Read replicas (up to 5)
  - Automated backups (35 days max)
  - Point-in-time recovery

Performance:
  - Performance Insights
  - Enhanced monitoring
  - Parameter groups for tuning
```

#### DynamoDB (NoSQL Database)
```yaml
Capacity Modes:
  - On-Demand: Pay per request
  - Provisioned: Predictable workloads

Performance:
  - Single-digit millisecond latency
  - Automatically scales to handle traffic
  - DAX for microsecond latency caching
  - Global tables for multi-region

Data Model:
  - Partition key (required)
  - Sort key (optional)
  - Global Secondary Index (GSI)
  - Local Secondary Index (LSI)

Best Practices:
  - Design for uniform access patterns
  - Use composite keys for hierarchical data
  - Consider hot partitions
  - Implement sparse indexes
```

#### ElastiCache
```yaml
Engines:
  - Redis: In-memory data structure store
  - Memcached: Simple caching

Redis Features:
  - Persistence options
  - Replication and clustering
  - Pub/Sub messaging
  - Lua scripting
  - Geospatial support

Use Cases:
  - Database caching
  - Session storage
  - Real-time analytics
  - Message broker
  - Leaderboards
```

### 🔗 Networking Services

#### VPC (Virtual Private Cloud)
```yaml
Components:
  - Subnets: Public, private, isolated
  - Route tables: Traffic routing rules
  - Internet Gateway: Internet access
  - NAT Gateway: Outbound internet for private subnets
  - Security Groups: Instance-level firewall
  - NACLs: Subnet-level firewall

CIDR Blocks:
  - VPC: 10.0.0.0/16 (65,536 IPs)
  - Public Subnet: 10.0.1.0/24 (256 IPs)
  - Private Subnet: 10.0.2.0/24 (256 IPs)

Best Practices:
  - Use multiple AZs for high availability
  - Separate public and private subnets
  - Use VPC endpoints for AWS services
  - Implement defense in depth
```

#### Application Load Balancer (ALB)
```yaml
Features:
  - Layer 7 load balancing
  - Path-based routing
  - Host-based routing
  - WebSocket support
  - HTTP/2 support
  - SSL termination

Target Types:
  - Instance: EC2 instances
  - IP: IP addresses
  - Lambda: Lambda functions

Health Checks:
  - Protocol: HTTP, HTTPS
  - Path: /health
  - Port: 8080
  - Interval: 30 seconds
  - Timeout: 5 seconds
  - Healthy threshold: 5
  - Unhealthy threshold: 2
```

#### CloudFront (CDN)
```yaml
Distribution Types:
  - Web: Static and dynamic content
  - RTMP: Media streaming (deprecated)

Cache Behaviors:
  - Path patterns: /api/*, /images/*
  - TTL: Default, maximum, minimum
  - Headers: Forward specific headers
  - Query strings: Forward parameters

Origins:
  - S3 bucket
  - Application Load Balancer
  - EC2 instance
  - Custom HTTP server

Performance:
  - Edge locations: 400+ worldwide
  - Regional edge caches
  - HTTP/2 support
  - Compression
```

### 📨 Messaging Services

#### SQS (Simple Queue Service)
```yaml
Queue Types:
  - Standard: At-least-once delivery, best-effort ordering
  - FIFO: Exactly-once processing, strict ordering

Configuration:
  - Visibility timeout: 0 seconds - 12 hours
  - Message retention: 1 minute - 14 days
  - Delivery delay: 0 - 15 minutes
  - Receive message wait time: 0 - 20 seconds

Use Cases:
  - Decouple microservices
  - Handle traffic spikes
  - Batch processing
  - Error handling with DLQ
```

#### SNS (Simple Notification Service)
```yaml
Protocol Support:
  - HTTP/HTTPS endpoints
  - Email/Email-JSON
  - SMS
  - SQS
  - Lambda
  - Mobile push notifications

Message Attributes:
  - String: Text data
  - Number: Numeric data
  - Binary: Binary data

Fan-out Pattern:
  SNS Topic → Multiple SQS Queues
  SNS Topic → Lambda + SQS + HTTP endpoint

Message Filtering:
  - Attribute-based filtering
  - Policy-based subscriptions
```

#### Kinesis (Real-time Data Streaming)
```yaml
Services:
  - Kinesis Data Streams: Real-time data ingestion
  - Kinesis Data Firehose: Data delivery to S3, Redshift
  - Kinesis Data Analytics: Real-time analytics
  - Kinesis Video Streams: Video streaming

Data Streams:
  - Shards: 1MB/sec or 1,000 records/sec per shard
  - Retention: 24 hours - 365 days
  - Partition key determines shard
  - Consumers: Lambda, EC2, EMR

Use Cases:
  - Real-time analytics
  - Log aggregation
  - IoT data processing
  - Clickstream analysis
```

### 🔐 Security Services

#### IAM (Identity and Access Management)
```yaml
Components:
  - Users: Individual people or services
  - Groups: Collection of users
  - Roles: Permissions for AWS resources
  - Policies: JSON documents defining permissions

Policy Types:
  - AWS Managed: Maintained by AWS
  - Customer Managed: Custom policies
  - Inline: Embedded in users/groups/roles

Best Practices:
  - Principle of least privilege
  - Use roles for applications
  - Enable MFA
  - Rotate access keys regularly
  - Use AWS SSO for multiple accounts
```

#### Secrets Manager
```yaml
Features:
  - Automatic rotation
  - Fine-grained access control
  - Cross-region replication
  - Integration with RDS, Redshift, DocumentDB

Use Cases:
  - Database credentials
  - API keys
  - OAuth tokens
  - Encryption keys

Rotation:
  - Automatic rotation for supported services
  - Custom Lambda functions for other secrets
  - Configurable rotation schedules
```

### 📊 Monitoring Services

#### CloudWatch
```yaml
Metrics:
  - Default metrics: CPU, network, disk
  - Custom metrics: Application-specific
  - Detailed monitoring: 1-minute intervals
  - High-resolution metrics: 1-second intervals

Alarms:
  - Threshold alarms: Static thresholds
  - Anomaly detection: ML-based
  - Composite alarms: Multiple metrics

Logs:
  - Log groups and streams
  - Retention policies
  - Metric filters
  - Insights for querying

Dashboards:
  - Custom visualizations
  - Cross-region metrics
  - Automatic dashboards
```

#### X-Ray (Distributed Tracing)
```yaml
Components:
  - Segments: Individual service calls
  - Subsegments: Remote calls within segments
  - Traces: End-to-end request flow
  - Service map: Visual representation

Integration:
  - Lambda: Built-in support
  - EC2: X-Ray daemon
  - ECS: Sidecar container
  - API Gateway: Enable tracing

Use Cases:
  - Performance bottlenecks
  - Error root cause analysis
  - Service dependencies
  - Latency optimization
```

### 🏗️ Architecture Patterns

#### Multi-Tier Web Application
```yaml
Presentation Tier:
  - CloudFront (CDN)
  - S3 (Static content)
  - Route 53 (DNS)

Application Tier:
  - Application Load Balancer
  - EC2 Auto Scaling Group
  - ECS/Fargate containers

Data Tier:
  - RDS Multi-AZ
  - ElastiCache cluster
  - S3 for file storage

Cross-cutting:
  - CloudWatch monitoring
  - X-Ray tracing
  - Secrets Manager
  - IAM roles
```

#### Serverless Architecture
```yaml
API Layer:
  - API Gateway
  - Lambda authorizers
  - CloudFront distribution

Compute Layer:
  - Lambda functions
  - Step Functions (orchestration)
  - EventBridge (event routing)

Data Layer:
  - DynamoDB
  - S3
  - RDS Proxy

Integration:
  - SQS/SNS messaging
  - Kinesis streaming
  - AppSync (GraphQL)
```

#### Microservices on AWS
```yaml
Service Discovery:
  - AWS Cloud Map
  - ECS Service Discovery
  - Route 53 private hosted zones

Container Orchestration:
  - ECS with Fargate
  - EKS (Kubernetes)
  - Lambda for event-driven services

API Management:
  - API Gateway
  - Application Load Balancer
  - Service mesh (App Mesh)

Data Persistence:
  - Database per service
  - DynamoDB for NoSQL
  - RDS for relational data
  - S3 for object storage
```

### 💰 Cost Optimization

#### Compute Optimization
```yaml
EC2:
  - Right-sizing instances
  - Reserved instances for predictable workloads
  - Spot instances for fault-tolerant workloads
  - Auto Scaling for variable demand

Lambda:
  - Optimize memory allocation
  - Minimize cold starts
  - Use provisioned concurrency sparingly

ECS/Fargate:
  - Right-size task definitions
  - Use Spot capacity for non-critical workloads
  - Optimize container images
```

#### Storage Optimization
```yaml
S3:
  - Use appropriate storage classes
  - Implement lifecycle policies
  - Enable intelligent tiering
  - Compress data before upload

EBS:
  - Use gp3 instead of gp2
  - Right-size volumes
  - Delete unused snapshots
  - Use EBS optimization

Data Transfer:
  - Use CloudFront for global distribution
  - VPC endpoints to avoid NAT gateway costs
  - Direct Connect for high-volume transfer
```

### 🎯 Interview Quick Reference

#### Common Questions & Solutions

**Q: How would you design a scalable web application?**
```yaml
Solution:
  - CloudFront + S3 for static content
  - ALB + Auto Scaling EC2 for application
  - RDS Multi-AZ + Read Replicas for database
  - ElastiCache for session storage
  - CloudWatch for monitoring
```

**Q: How would you handle sudden traffic spikes?**
```yaml
Solution:
  - Auto Scaling Groups with target tracking
  - CloudFront caching
  - ElastiCache for database offloading
  - SQS for request queuing
  - Lambda for serverless processing
```

**Q: How would you ensure high availability?**
```yaml
Solution:
  - Multi-AZ deployments
  - Cross-region replication
  - Health checks and auto recovery
  - Database failover mechanisms
  - Multiple availability zones
```

**Q: How would you implement a data pipeline?**
```yaml
Solution:
  - Kinesis for real-time ingestion
  - Lambda for transformation
  - S3 for data lake storage
  - Athena for ad-hoc queries
  - Redshift for data warehousing
```

---

### 📊 Service Comparison Matrix

| Use Case | Option 1 | Option 2 | Option 3 |
|----------|----------|----------|----------|
| **Compute** | EC2 (Full control) | Lambda (Serverless) | Fargate (Containers) |
| **Database** | RDS (Relational) | DynamoDB (NoSQL) | Redshift (Analytics) |
| **Caching** | ElastiCache (In-memory) | CloudFront (CDN) | DAX (DynamoDB) |
| **Messaging** | SQS (Queuing) | SNS (Pub/Sub) | Kinesis (Streaming) |
| **Storage** | S3 (Object) | EBS (Block) | EFS (File) |

---

**This cheat sheet provides the essential AWS services and patterns needed to design scalable, cost-effective, and highly available systems for system design interviews.**
