# Spring Boot Microservices Patterns Cheat Sheet

## 🚀 Essential Patterns for System Design Interviews

### 🏗️ Service Discovery

#### Eureka Service Discovery
```java
// Service Registration
@SpringBootApplication
@EnableEurekaClient
public class UserServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(UserServiceApplication.class, args);
    }
}

// application.yml
eureka:
  client:
    service-url:
      defaultZone: http://localhost:8761/eureka/
  instance:
    prefer-ip-address: true
    health-check-url-path: /actuator/health
```

#### Consul Service Discovery
```java
@SpringBootApplication
@EnableDiscoveryClient
public class OrderServiceApplication {
    // Service auto-registers with Consul
}

// application.yml
spring:
  cloud:
    consul:
      host: localhost
      port: 8500
      discovery:
        health-check-path: /actuator/health
        health-check-interval: 10s
```

### 🔄 API Gateway Patterns

#### Spring Cloud Gateway
```java
@Configuration
public class GatewayConfig {
    
    @Bean
    public RouteLocator customRoutes(RouteLocatorBuilder builder) {
        return builder.routes()
            .route("user-service", r -> r.path("/api/users/**")
                .filters(f -> f
                    .circuitBreaker(c -> c.setName("user-service-cb"))
                    .retry(retryConfig -> retryConfig
                        .setRetries(3)
                        .setBackoff(Duration.ofMillis(100), Duration.ofMillis(500), 2, true))
                    .requestRateLimiter(config -> config
                        .setRateLimiter(redisRateLimiter())
                        .setKeyResolver(userKeyResolver())))
                .uri("lb://user-service"))
            .route("order-service", r -> r.path("/api/orders/**")
                .filters(f -> f
                    .addRequestHeader("X-Gateway", "spring-cloud-gateway")
                    .hystrix(hystrixConfig -> hystrixConfig
                        .setName("order-service-hystrix")
                        .setFallbackUri("/fallback/orders")))
                .uri("lb://order-service"))
            .build();
    }
    
    @Bean
    public RedisRateLimiter redisRateLimiter() {
        return new RedisRateLimiter(10, 20); // replenishRate, burstCapacity
    }
    
    @Bean
    public KeyResolver userKeyResolver() {
        return exchange -> exchange.getRequest().getHeaders()
            .getFirst("X-User-ID") != null ? 
            Mono.just(exchange.getRequest().getHeaders().getFirst("X-User-ID")) :
            Mono.just("anonymous");
    }
}
```

### 🛡️ Circuit Breaker Pattern

#### Resilience4j Implementation
```java
@Service
public class OrderService {
    
    @Autowired
    private PaymentServiceClient paymentClient;
    
    @CircuitBreaker(name = "payment-service", fallbackMethod = "fallbackPayment")
    @Retry(name = "payment-service")
    @TimeLimiter(name = "payment-service")
    public CompletableFuture<PaymentResponse> processPayment(PaymentRequest request) {
        return CompletableFuture.supplyAsync(() -> paymentClient.processPayment(request));
    }
    
    public CompletableFuture<PaymentResponse> fallbackPayment(PaymentRequest request, Exception ex) {
        log.warn("Payment service unavailable, using fallback: {}", ex.getMessage());
        return CompletableFuture.completedFuture(
            PaymentResponse.builder()
                .status("PENDING")
                .message("Payment queued for later processing")
                .build()
        );
    }
}

// application.yml
resilience4j:
  circuitbreaker:
    instances:
      payment-service:
        registerHealthIndicator: true
        slidingWindowSize: 10
        failureRateThreshold: 50
        waitDurationInOpenState: 10000
        permittedNumberOfCallsInHalfOpenState: 3
        slidingWindowType: COUNT_BASED
        minimumNumberOfCalls: 5
        automaticTransitionFromOpenToHalfOpenEnabled: true
```

### 📊 Configuration Management

#### Spring Cloud Config
```java
// Config Server
@SpringBootApplication
@EnableConfigServer
public class ConfigServerApplication {
    public static void main(String[] args) {
        SpringApplication.run(ConfigServerApplication.class, args);
    }
}

// Client Configuration
@RestController
@RefreshScope // Enables dynamic config refresh
public class UserController {
    
    @Value("${app.feature.new-user-validation:false}")
    private boolean newUserValidationEnabled;
    
    @Value("${app.limits.max-users-per-request:100}")
    private int maxUsersPerRequest;
    
    @PostMapping("/users")
    public ResponseEntity<User> createUser(@RequestBody User user) {
        if (newUserValidationEnabled) {
            validateUser(user);
        }
        // Process user creation
        return ResponseEntity.ok(userService.createUser(user));
    }
}
```

#### Feature Flags with Spring
```java
@Component
public class FeatureFlags {
    
    @Value("${features.advanced-search:false}")
    private boolean advancedSearchEnabled;
    
    @Value("${features.ai-recommendations:false}")
    private boolean aiRecommendationsEnabled;
    
    @ConditionalOnProperty(name = "features.advanced-search", havingValue = "true")
    @Bean
    public SearchService advancedSearchService() {
        return new AdvancedSearchService();
    }
    
    @ConditionalOnProperty(name = "features.advanced-search", havingValue = "false", matchIfMissing = true)
    @Bean
    public SearchService basicSearchService() {
        return new BasicSearchService();
    }
}
```

### 📈 Distributed Tracing

#### Sleuth + Zipkin
```java
@RestController
public class UserController {
    
    @Autowired
    private OrderService orderService;
    
    @GetMapping("/users/{id}/orders")
    @NewSpan("get-user-orders")
    public List<Order> getUserOrders(@PathVariable String id, Span span) {
        span.tag("user.id", id);
        span.tag("operation", "get-user-orders");
        
        // This call will be traced automatically
        List<Order> orders = orderService.getOrdersByUserId(id);
        
        span.tag("order.count", String.valueOf(orders.size()));
        return orders;
    }
}

// Custom span annotation
@Component
public class OrderService {
    
    @NewSpan("fetch-orders-from-db")
    public List<Order> getOrdersByUserId(@SpanTag("userId") String userId) {
        // Database call will be automatically traced
        return orderRepository.findByUserId(userId);
    }
}
```

### 🔐 Security Patterns

#### OAuth2 Resource Server
```java
@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class SecurityConfig {
    
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            .authorizeHttpRequests(authz -> authz
                .requestMatchers("/actuator/health").permitAll()
                .requestMatchers("/api/public/**").permitAll()
                .requestMatchers(HttpMethod.GET, "/api/users/**").hasRole("USER")
                .requestMatchers(HttpMethod.POST, "/api/users/**").hasRole("ADMIN")
                .anyRequest().authenticated())
            .oauth2ResourceServer(oauth2 -> oauth2
                .jwt(jwt -> jwt
                    .jwtAuthenticationConverter(jwtAuthenticationConverter())));
        
        return http.build();
    }
    
    @Bean
    public JwtAuthenticationConverter jwtAuthenticationConverter() {
        JwtGrantedAuthoritiesConverter authoritiesConverter = new JwtGrantedAuthoritiesConverter();
        authoritiesConverter.setAuthorityPrefix("ROLE_");
        authoritiesConverter.setAuthoritiesClaimName("roles");
        
        JwtAuthenticationConverter converter = new JwtAuthenticationConverter();
        converter.setJwtGrantedAuthoritiesConverter(authoritiesConverter);
        return converter;
    }
}
```

#### Method-Level Security
```java
@Service
public class UserService {
    
    @PreAuthorize("hasRole('ADMIN') or #userId == authentication.name")
    public User getUser(String userId) {
        return userRepository.findById(userId);
    }
    
    @PreAuthorize("hasRole('ADMIN')")
    @PostAuthorize("returnObject.createdBy == authentication.name or hasRole('ADMIN')")
    public User createUser(User user) {
        return userRepository.save(user);
    }
    
    @PreAuthorize("@userService.isOwner(#orderId, authentication.name)")
    public Order getOrder(String orderId) {
        return orderRepository.findById(orderId);
    }
    
    public boolean isOwner(String orderId, String username) {
        return orderRepository.findById(orderId)
            .map(order -> order.getCreatedBy().equals(username))
            .orElse(false);
    }
}
```

### 📊 Health Checks & Monitoring

#### Custom Health Indicators
```java
@Component
public class DatabaseHealthIndicator implements HealthIndicator {
    
    @Autowired
    private DataSource dataSource;
    
    @Override
    public Health health() {
        try (Connection connection = dataSource.getConnection()) {
            if (connection.isValid(1)) {
                return Health.up()
                    .withDetail("database", "Available")
                    .withDetail("connectionPool", getConnectionPoolStatus())
                    .build();
            }
        } catch (SQLException e) {
            return Health.down()
                .withDetail("database", "Unavailable")
                .withException(e)
                .build();
        }
        return Health.down().withDetail("database", "Connection validation failed").build();
    }
    
    private Map<String, Object> getConnectionPoolStatus() {
        // Get connection pool metrics
        return Map.of(
            "active", 10,
            "idle", 5,
            "max", 20
        );
    }
}

@Component
public class ExternalServiceHealthIndicator implements HealthIndicator {
    
    @Autowired
    private PaymentServiceClient paymentClient;
    
    @Override
    public Health health() {
        try {
            boolean isHealthy = paymentClient.checkHealth();
            if (isHealthy) {
                return Health.up()
                    .withDetail("payment-service", "Available")
                    .withDetail("lastCheck", Instant.now())
                    .build();
            }
        } catch (Exception e) {
            return Health.down()
                .withDetail("payment-service", "Unavailable")
                .withDetail("error", e.getMessage())
                .build();
        }
        return Health.down().build();
    }
}
```

#### Custom Metrics
```java
@Component
public class BusinessMetrics {
    
    private final Counter orderCreatedCounter;
    private final Timer orderProcessingTimer;
    private final Gauge activeUsersGauge;
    
    public BusinessMetrics(MeterRegistry meterRegistry) {
        this.orderCreatedCounter = Counter.builder("orders.created")
            .description("Number of orders created")
            .tag("service", "order-service")
            .register(meterRegistry);
            
        this.orderProcessingTimer = Timer.builder("orders.processing.time")
            .description("Order processing time")
            .register(meterRegistry);
            
        this.activeUsersGauge = Gauge.builder("users.active")
            .description("Number of active users")
            .register(meterRegistry, this, BusinessMetrics::getActiveUserCount);
    }
    
    public void recordOrderCreated(String orderType) {
        orderCreatedCounter.increment(Tags.of("type", orderType));
    }
    
    public Timer.Sample startOrderProcessing() {
        return Timer.start();
    }
    
    public void recordOrderProcessingTime(Timer.Sample sample, String status) {
        sample.stop(Timer.builder("orders.processing.time")
            .tag("status", status)
            .register(Metrics.globalRegistry));
    }
    
    private double getActiveUserCount() {
        // Return current active user count
        return userService.getActiveUserCount();
    }
}
```

### 🗄️ Data Patterns

#### JPA with Multiple Databases
```java
@Configuration
public class DatabaseConfig {
    
    @Primary
    @Bean
    @ConfigurationProperties("spring.datasource.primary")
    public DataSource primaryDataSource() {
        return DataSourceBuilder.create().build();
    }
    
    @Bean
    @ConfigurationProperties("spring.datasource.secondary")
    public DataSource secondaryDataSource() {
        return DataSourceBuilder.create().build();
    }
    
    @Primary
    @Bean
    public LocalContainerEntityManagerFactoryBean primaryEntityManager() {
        LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
        em.setDataSource(primaryDataSource());
        em.setPackagesToScan("com.example.primary.entity");
        em.setJpaVendorAdapter(new HibernateJpaVendorAdapter());
        return em;
    }
    
    @Bean
    public LocalContainerEntityManagerFactoryBean secondaryEntityManager() {
        LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
        em.setDataSource(secondaryDataSource());
        em.setPackagesToScan("com.example.secondary.entity");
        em.setJpaVendorAdapter(new HibernateJpaVendorAdapter());
        return em;
    }
}
```

#### CQRS with Spring Data
```java
// Command side
@Service
@Transactional
public class UserCommandService {
    
    @Autowired
    private UserWriteRepository writeRepository;
    
    @Autowired
    private ApplicationEventPublisher eventPublisher;
    
    public void createUser(CreateUserCommand command) {
        User user = new User(command.getUsername(), command.getEmail());
        User savedUser = writeRepository.save(user);
        
        // Publish event for read side projection
        eventPublisher.publishEvent(new UserCreatedEvent(savedUser.getId(), savedUser.getUsername()));
    }
}

// Query side
@Service
@Transactional(readOnly = true)
public class UserQueryService {
    
    @Autowired
    private UserReadRepository readRepository;
    
    public UserView findUserById(String userId) {
        return readRepository.findById(userId);
    }
    
    public Page<UserView> searchUsers(String query, Pageable pageable) {
        return readRepository.findByUsernameContaining(query, pageable);
    }
}

// Event handler for projections
@EventListener
@Async
public void handleUserCreated(UserCreatedEvent event) {
    UserView userView = new UserView(event.getUserId(), event.getUsername());
    userViewRepository.save(userView);
}
```

### 🔄 Event-Driven Patterns

#### Kafka Integration
```java
@Service
public class OrderEventService {
    
    @Autowired
    private KafkaTemplate<String, Object> kafkaTemplate;
    
    @EventListener
    public void handleOrderCreated(OrderCreatedEvent event) {
        OrderEventMessage message = OrderEventMessage.builder()
            .orderId(event.getOrderId())
            .userId(event.getUserId())
            .amount(event.getAmount())
            .timestamp(Instant.now())
            .build();
            
        kafkaTemplate.send("order-events", event.getOrderId(), message);
    }
}

@KafkaListener(topics = "order-events", groupId = "notification-service")
public void handleOrderEvent(OrderEventMessage message) {
    // Send notification to user
    notificationService.sendOrderConfirmation(message.getUserId(), message.getOrderId());
}

// Retry and error handling
@KafkaListener(topics = "order-events", groupId = "payment-service")
public void processPayment(OrderEventMessage message) {
    try {
        paymentService.processPayment(message);
    } catch (PaymentException e) {
        // Send to DLQ
        kafkaTemplate.send("order-events-dlq", message);
    }
}
```

#### Saga Pattern Implementation
```java
@Component
public class OrderSaga {
    
    @SagaOrchestrationStart
    public void processOrder(OrderCreatedEvent event) {
        choreographer.step("reserve-inventory")
            .invokeParticipant("inventory-service")
            .withCompensation("release-inventory");
            
        choreographer.step("process-payment")
            .invokeParticipant("payment-service")
            .withCompensation("refund-payment");
            
        choreographer.step("ship-order")
            .invokeParticipant("shipping-service")
            .withCompensation("cancel-shipment");
    }
    
    @SagaOrchestrationEnd
    public void orderCompleted(OrderCompletedEvent event) {
        log.info("Order {} completed successfully", event.getOrderId());
    }
    
    @SagaOrchestrationError
    public void orderFailed(OrderFailedEvent event) {
        log.error("Order {} failed: {}", event.getOrderId(), event.getReason());
        // Trigger compensations
    }
}
```

### 🎯 Testing Patterns

#### Integration Testing with TestContainers
```java
@SpringBootTest
@Testcontainers
class OrderServiceIntegrationTest {
    
    @Container
    static PostgreSQLContainer<?> postgres = new PostgreSQLContainer<>("postgres:15")
            .withDatabaseName("test")
            .withUsername("test")
            .withPassword("test");
    
    @Container
    static KafkaContainer kafka = new KafkaContainer(DockerImageName.parse("confluentinc/cp-kafka:latest"));
    
    @Container
    static GenericContainer<?> redis = new GenericContainer<>("redis:7-alpine")
            .withExposedPorts(6379);
    
    @DynamicPropertySource
    static void configureProperties(DynamicPropertyRegistry registry) {
        registry.add("spring.datasource.url", postgres::getJdbcUrl);
        registry.add("spring.datasource.username", postgres::getUsername);
        registry.add("spring.datasource.password", postgres::getPassword);
        registry.add("spring.kafka.bootstrap-servers", kafka::getBootstrapServers);
        registry.add("spring.redis.host", redis::getHost);
        registry.add("spring.redis.port", redis::getFirstMappedPort);
    }
    
    @Test
    void shouldProcessOrderEndToEnd() {
        // Given
        CreateOrderRequest request = new CreateOrderRequest(
            "user123", Arrays.asList("item1", "item2"), new BigDecimal("99.99")
        );
        
        // When
        ResponseEntity<Order> response = restTemplate.postForEntity(
            "/api/orders", request, Order.class
        );
        
        // Then
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.CREATED);
        assertThat(response.getBody().getStatus()).isEqualTo(OrderStatus.CREATED);
        
        // Verify event was published
        await().atMost(Duration.ofSeconds(5)).untilAsserted(() -> {
            // Check that inventory was reserved, payment processed, etc.
        });
    }
}
```

### 🚀 Performance Patterns

#### Async Processing
```java
@Service
public class AsyncOrderProcessor {
    
    @Async("orderTaskExecutor")
    public CompletableFuture<Void> processOrderAsync(Order order) {
        // Heavy processing
        processInventory(order);
        processPayment(order);
        generateInvoice(order);
        
        return CompletableFuture.completedFuture(null);
    }
    
    @Bean("orderTaskExecutor")
    public TaskExecutor orderTaskExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(5);
        executor.setMaxPoolSize(20);
        executor.setQueueCapacity(100);
        executor.setThreadNamePrefix("order-processor-");
        executor.setRejectedExecutionHandler(new ThreadPoolExecutor.CallerRunsPolicy());
        executor.initialize();
        return executor;
    }
}
```

#### Caching Strategies
```java
@Service
public class ProductService {
    
    @Cacheable(value = "products", key = "#id")
    public Product getProduct(String id) {
        return productRepository.findById(id);
    }
    
    @CacheEvict(value = "products", key = "#product.id")
    public Product updateProduct(Product product) {
        return productRepository.save(product);
    }
    
    @Cacheable(value = "search-results", key = "#query + '_' + #pageable.pageNumber + '_' + #pageable.pageSize")
    public Page<Product> searchProducts(String query, Pageable pageable) {
        return productRepository.findByNameContaining(query, pageable);
    }
    
    @CacheEvict(value = "search-results", allEntries = true)
    public void clearSearchCache() {
        // Called when products are updated
    }
}
```

---

## 🎯 Interview Quick Reference

### Common Questions & Patterns

**Q: How do you handle service-to-service communication?**
- **Synchronous**: REST APIs, gRPC
- **Asynchronous**: Message queues (Kafka, RabbitMQ)
- **Circuit breaker** for fault tolerance
- **Retry with exponential backoff**

**Q: How do you manage configuration across services?**
- **Spring Cloud Config** for centralized configuration
- **Feature flags** for runtime toggles
- **Environment-specific profiles**

**Q: How do you ensure data consistency?**
- **Saga pattern** for distributed transactions
- **Event sourcing** for audit trails
- **CQRS** for read/write separation

**Q: How do you monitor microservices?**
- **Distributed tracing** (Sleuth + Zipkin)
- **Custom metrics** with Micrometer
- **Health checks** with Actuator
- **Centralized logging** with ELK stack

---

**This cheat sheet covers the essential Spring Boot patterns for building scalable microservices that demonstrate system design expertise in interviews.**
