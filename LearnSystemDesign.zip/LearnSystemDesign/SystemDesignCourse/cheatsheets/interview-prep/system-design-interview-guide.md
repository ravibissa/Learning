# System Design Interview Guide

## 🎯 Complete Interview Strategy for Java Developers

### 🎭 The RADIO Framework

**R** - Requirements gathering  
**A** - Architecture design  
**D** - Data modeling  
**I** - Implementation details  
**O** - Operations & scaling  

---

## 📋 Phase 1: Requirements Gathering (5-10 minutes)

### ✅ Functional Requirements Checklist
```
□ Who are the users? (B2B, B2C, internal)
□ What are the core features?
□ What's the expected user flow?
□ Are there any specific business rules?
□ What integrations are needed?
□ What's the MVP vs nice-to-have?
```

### ✅ Non-Functional Requirements
```
□ Scale: How many users? (DAU, concurrent)
□ Performance: Latency requirements (p95, p99)
□ Availability: Uptime requirements (99.9%, 99.99%)
□ Consistency: Strong vs eventual consistency
□ Security: Authentication, authorization, compliance
□ Geography: Global vs regional deployment
```

### 🎯 Sample Questions to Ask
```java
// Scale Questions
"How many daily active users do we expect?"
"What's the expected read/write ratio?"
"How much data will we store initially and over time?"
"What's the expected growth rate?"

// Performance Questions  
"What's the acceptable response time for core features?"
"Are there any real-time requirements?"
"What's the acceptable downtime during deployments?"

// Business Questions
"Who are the primary users of this system?"
"What's the most critical feature that must never fail?"
"Are there any compliance requirements (GDPR, SOX, etc.)?"
```

---

## 🏗️ Phase 2: Architecture Design (15-20 minutes)

### 🎨 High-Level Architecture Pattern
```
[ Load Balancer ]
       ↓
[ API Gateway ]
       ↓
[ Microservices Layer ]
       ↓
[ Database Layer ]
```

### 🔧 Java/Spring Boot Architecture
```java
// Typical microservice structure
@RestController
@RequestMapping("/api/v1")
public class OrderController {
    
    @Autowired
    private OrderService orderService;
    
    @PostMapping("/orders")
    @CircuitBreaker(name = "order-service")
    @RateLimiter(name = "order-api")
    @Retryable(value = {Exception.class}, maxAttempts = 3)
    public ResponseEntity<Order> createOrder(@RequestBody CreateOrderRequest request) {
        // Implementation
    }
}

// Service layer with resilience patterns
@Service
@Transactional
public class OrderService {
    
    @Autowired
    private OrderRepository orderRepository;
    
    @Autowired
    private PaymentServiceClient paymentClient;
    
    @Cacheable("orders")
    public Order getOrder(String orderId) {
        return orderRepository.findById(orderId)
            .orElseThrow(() -> new OrderNotFoundException(orderId));
    }
}
```

### 🗄️ Database Selection Decision Tree
```
Need ACID transactions? 
├─ Yes → PostgreSQL/MySQL
└─ No → Continue

Need complex queries?
├─ Yes → PostgreSQL (JSONB) / Elasticsearch
└─ No → Continue

Need high write throughput?
├─ Yes → Cassandra/DynamoDB
└─ No → Continue

Need simple key-value?
├─ Yes → Redis/DynamoDB
└─ Default → PostgreSQL
```

### 🔄 Common Patterns to Discuss

#### 1. API Gateway Pattern
```yaml
Features:
  - Authentication/Authorization
  - Rate limiting
  - Request routing
  - Response caching
  - API versioning
  - Monitoring/Logging

Java Implementation:
  - Spring Cloud Gateway
  - Netflix Zuul
  - Kong with Spring Boot
```

#### 2. Circuit Breaker Pattern
```java
@CircuitBreaker(name = "payment-service", fallbackMethod = "fallbackPayment")
public PaymentResponse processPayment(PaymentRequest request) {
    return paymentServiceClient.process(request);
}

public PaymentResponse fallbackPayment(PaymentRequest request, Exception ex) {
    return PaymentResponse.builder()
        .status("PENDING")
        .message("Payment will be processed later")
        .build();
}
```

#### 3. CQRS Pattern
```java
// Command side
@Service
public class OrderCommandService {
    public void createOrder(CreateOrderCommand command) {
        Order order = new Order(command);
        orderRepository.save(order);
        eventPublisher.publish(new OrderCreatedEvent(order));
    }
}

// Query side  
@Service
public class OrderQueryService {
    @Cacheable("order-views")
    public OrderView getOrderView(String orderId) {
        return orderViewRepository.findById(orderId);
    }
}
```

---

## 📊 Phase 3: Data Modeling (10-15 minutes)

### 🗄️ Database Design Patterns

#### Relational Model Example
```sql
-- Users table
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Orders table with partitioning
CREATE TABLE orders (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id),
    status VARCHAR(20) NOT NULL,
    total_amount DECIMAL(10,2),
    created_at TIMESTAMP DEFAULT NOW()
) PARTITION BY RANGE (created_at);

-- Indexes for performance
CREATE INDEX idx_orders_user_id ON orders(user_id);
CREATE INDEX idx_orders_status ON orders(status);
CREATE INDEX idx_orders_created_at ON orders(created_at);
```

#### NoSQL Model Example (DynamoDB)
```java
// User entity
@DynamoDBTable(tableName = "Users")
public class User {
    @DynamoDBHashKey
    private String userId;
    
    @DynamoDBAttribute
    private String email;
    
    @DynamoDBAttribute
    private UserProfile profile;
    
    @DynamoDBAttribute
    private Set<String> permissions;
}

// Order entity with GSI
@DynamoDBTable(tableName = "Orders")
public class Order {
    @DynamoDBHashKey
    private String orderId;
    
    @DynamoDBRangeKey
    private String createdAt;
    
    @DynamoDBIndexHashKey(globalSecondaryIndexName = "UserIdIndex")
    private String userId;
    
    @DynamoDBAttribute
    private OrderStatus status;
}
```

### 🔄 Caching Strategy
```java
// Multi-level caching
@Service
public class ProductService {
    
    @Autowired
    private RedisTemplate<String, Object> redisTemplate;
    
    @Cacheable(value = "products", key = "#id", unless = "#result == null")
    public Product getProduct(String id) {
        // Check L1 cache (Redis)
        Product cached = (Product) redisTemplate.opsForValue().get("product:" + id);
        if (cached != null) {
            return cached;
        }
        
        // Fetch from database
        Product product = productRepository.findById(id)
            .orElseThrow(() -> new ProductNotFoundException(id));
        
        // Cache for 1 hour
        redisTemplate.opsForValue().set("product:" + id, product, Duration.ofHours(1));
        
        return product;
    }
}
```

---

## ⚡ Phase 4: Implementation Details (10-15 minutes)

### 🔧 Technology Stack Decisions

#### For High-Throughput Systems
```java
// Async processing with Spring WebFlux
@RestController
public class OrderController {
    
    @PostMapping("/orders")
    public Mono<OrderResponse> createOrder(@RequestBody Mono<CreateOrderRequest> request) {
        return request
            .flatMap(orderService::validateOrder)
            .flatMap(orderService::createOrder)
            .flatMap(orderService::processPayment)
            .map(order -> OrderResponse.from(order))
            .doOnError(error -> log.error("Order creation failed", error));
    }
}

// Reactive database access
@Repository
public class ReactiveOrderRepository {
    
    @Autowired
    private R2dbcEntityTemplate template;
    
    public Mono<Order> save(Order order) {
        return template.insert(order);
    }
    
    public Flux<Order> findByUserId(String userId) {
        return template.select(Order.class)
            .matching(query(where("user_id").is(userId)))
            .all();
    }
}
```

#### For Event-Driven Architecture
```java
// Kafka producer
@Service
public class OrderEventPublisher {
    
    @Autowired
    private KafkaTemplate<String, Object> kafkaTemplate;
    
    @EventListener
    public void handleOrderCreated(OrderCreatedEvent event) {
        OrderEventMessage message = OrderEventMessage.builder()
            .orderId(event.getOrderId())
            .userId(event.getUserId())
            .timestamp(Instant.now())
            .build();
            
        kafkaTemplate.send("order-events", event.getOrderId(), message);
    }
}

// Kafka consumer with retry
@KafkaListener(topics = "order-events", groupId = "notification-service")
public void handleOrderEvent(OrderEventMessage message) {
    try {
        notificationService.sendOrderConfirmation(message);
    } catch (Exception e) {
        // Send to DLQ for manual processing
        kafkaTemplate.send("order-events-dlq", message);
    }
}
```

### 🔒 Security Implementation
```java
// JWT-based authentication
@Configuration
@EnableWebSecurity
public class SecurityConfig {
    
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        return http
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/api/public/**").permitAll()
                .requestMatchers(HttpMethod.GET, "/api/orders/**").hasRole("USER")
                .requestMatchers(HttpMethod.POST, "/api/orders/**").hasRole("USER")
                .requestMatchers("/api/admin/**").hasRole("ADMIN")
                .anyRequest().authenticated())
            .oauth2ResourceServer(oauth2 -> oauth2.jwt())
            .build();
    }
}

// Method-level security
@PreAuthorize("hasRole('USER') and #userId == authentication.name")
public List<Order> getUserOrders(String userId) {
    return orderRepository.findByUserId(userId);
}
```

---

## 📈 Phase 5: Operations & Scaling (10-15 minutes)

### 📊 Capacity Planning

#### Calculate Required Infrastructure
```java
// Given requirements
int dailyActiveUsers = 1_000_000;
double avgRequestsPerUser = 10.0;
int peakMultiplier = 3;
double targetResponseTime = 0.2; // 200ms

// Calculate RPS
double avgRps = (dailyActiveUsers * avgRequestsPerUser) / (24 * 60 * 60);
double peakRps = avgRps * peakMultiplier;

// Calculate required instances
double requestsPerInstancePerSecond = 100; // Based on load testing
int requiredInstances = (int) Math.ceil(peakRps / requestsPerInstancePerSecond);

System.out.println("Average RPS: " + avgRps);
System.out.println("Peak RPS: " + peakRps);
System.out.println("Required instances: " + requiredInstances);
```

### 🎯 Monitoring Strategy
```java
// Custom metrics
@Component
public class OrderMetrics {
    
    private final Counter orderCreatedCounter;
    private final Timer orderProcessingTimer;
    private final Gauge pendingOrdersGauge;
    
    public OrderMetrics(MeterRegistry meterRegistry) {
        this.orderCreatedCounter = Counter.builder("orders.created")
            .description("Number of orders created")
            .register(meterRegistry);
            
        this.orderProcessingTimer = Timer.builder("orders.processing.time")
            .description("Order processing time")
            .register(meterRegistry);
            
        this.pendingOrdersGauge = Gauge.builder("orders.pending")
            .description("Number of pending orders")
            .register(meterRegistry, this, OrderMetrics::getPendingOrderCount);
    }
}

// Health checks
@Component
public class OrderServiceHealthIndicator implements HealthIndicator {
    
    @Override
    public Health health() {
        try {
            // Check database connectivity
            orderRepository.count();
            
            // Check external dependencies
            paymentServiceClient.healthCheck();
            
            return Health.up()
                .withDetail("database", "Available")
                .withDetail("payment-service", "Available")
                .build();
                
        } catch (Exception e) {
            return Health.down()
                .withDetail("error", e.getMessage())
                .build();
        }
    }
}
```

### 🔄 Scaling Patterns

#### Horizontal Scaling
```yaml
# Kubernetes HPA
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: order-service-hpa
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: order-service
  minReplicas: 3
  maxReplicas: 50
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70
  - type: Resource
    resource:
      name: memory
      target:
        type: Utilization
        averageUtilization: 80
```

#### Database Scaling
```java
// Read replica configuration
@Configuration
public class DatabaseConfig {
    
    @Bean
    @Primary
    public DataSource writeDataSource() {
        return DataSourceBuilder.create()
            .url("jdbc:postgresql://write-db:5432/orders")
            .build();
    }
    
    @Bean
    public DataSource readDataSource() {
        return DataSourceBuilder.create()
            .url("jdbc:postgresql://read-db:5432/orders")
            .build();
    }
    
    @Bean
    public DataSource routingDataSource() {
        RoutingDataSource routingDataSource = new RoutingDataSource();
        Map<Object, Object> dataSourceMap = new HashMap<>();
        dataSourceMap.put("write", writeDataSource());
        dataSourceMap.put("read", readDataSource());
        routingDataSource.setTargetDataSources(dataSourceMap);
        routingDataSource.setDefaultTargetDataSource(writeDataSource());
        return routingDataSource;
    }
}

// Usage with @Transactional
@Transactional(readOnly = true)
public List<Order> getOrders() {
    // Routes to read replica
    return orderRepository.findAll();
}

@Transactional
public Order createOrder(Order order) {
    // Routes to write database
    return orderRepository.save(order);
}
```

---

## 🎭 Common Interview Scenarios

### 🏪 E-commerce Platform
**Key Focus Areas:**
- Inventory management with consistency
- Payment processing with reliability
- Order workflow with state management
- Search and recommendations
- Cart management with session handling

**Java-Specific Patterns:**
```java
// Pessimistic locking for inventory
@Lock(LockModeType.PESSIMISTIC_WRITE)
public Product reserveInventory(String productId, int quantity) {
    Product product = productRepository.findById(productId);
    if (product.getAvailableQuantity() >= quantity) {
        product.setAvailableQuantity(product.getAvailableQuantity() - quantity);
        return productRepository.save(product);
    }
    throw new InsufficientInventoryException();
}

// Saga pattern for order processing
@SagaOrchestrationStart
public void processOrder(OrderCreatedEvent event) {
    sagaOrchestrator
        .step("reserve-inventory")
        .invokeParticipant("inventory-service")
        .withCompensation("release-inventory")
        
        .step("process-payment")
        .invokeParticipant("payment-service")
        .withCompensation("refund-payment")
        
        .step("create-shipment")
        .invokeParticipant("shipping-service")
        .withCompensation("cancel-shipment");
}
```

### 💬 Chat System
**Key Focus Areas:**
- Real-time messaging with WebSockets
- Message delivery guarantees
- Presence and typing indicators
- Message history and search
- Group chat with permissions

**Java-Specific Patterns:**
```java
// WebSocket configuration
@Configuration
@EnableWebSocket
public class WebSocketConfig implements WebSocketConfigurer {
    
    @Override
    public void registerWebSocketHandlers(WebSocketHandlerRegistry registry) {
        registry.addHandler(new ChatWebSocketHandler(), "/chat")
                .setAllowedOrigins("*")
                .withSockJS();
    }
}

// Message handling with Spring WebSocket
@Component
public class ChatWebSocketHandler extends TextWebSocketHandler {
    
    @Override
    public void afterConnectionEstablished(WebSocketSession session) {
        // Handle user connection
        chatSessionManager.addSession(session);
    }
    
    @Override
    protected void handleTextMessage(WebSocketSession session, TextMessage message) {
        // Process incoming message
        ChatMessage chatMessage = objectMapper.readValue(message.getPayload(), ChatMessage.class);
        chatService.processMessage(chatMessage);
    }
}

// Message persistence with eventual consistency
@Service
public class ChatService {
    
    @Async
    public void processMessage(ChatMessage message) {
        // Save to database
        messageRepository.save(message);
        
        // Publish to all connected clients
        messagingTemplate.convertAndSend("/topic/chat/" + message.getRoomId(), message);
        
        // Update search index
        messageSearchService.indexMessage(message);
    }
}
```

### 🔗 URL Shortener
**Key Focus Areas:**
- URL encoding/decoding algorithms
- High read throughput optimization
- Analytics and click tracking
- Cache strategies
- Rate limiting and abuse prevention

**Java-Specific Patterns:**
```java
// Base62 encoding for URL shortening
@Service
public class UrlShortenerService {
    
    private static final String BASE62 = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    
    public String shortenUrl(String longUrl) {
        // Generate unique ID
        long id = idGenerator.generateId();
        
        // Convert to base62
        String shortCode = toBase62(id);
        
        // Store mapping
        UrlMapping mapping = new UrlMapping(shortCode, longUrl);
        urlRepository.save(mapping);
        
        // Cache for fast access
        redisTemplate.opsForValue().set("url:" + shortCode, longUrl, Duration.ofHours(24));
        
        return "https://short.ly/" + shortCode;
    }
    
    @Cacheable("urls")
    public String expandUrl(String shortCode) {
        return urlRepository.findByShortCode(shortCode)
            .map(UrlMapping::getLongUrl)
            .orElseThrow(() -> new UrlNotFoundException(shortCode));
    }
    
    private String toBase62(long num) {
        StringBuilder sb = new StringBuilder();
        while (num > 0) {
            sb.append(BASE62.charAt((int) (num % 62)));
            num /= 62;
        }
        return sb.reverse().toString();
    }
}
```

---

## 🎯 Interview Success Tips

### ✅ Do's
- **Start with clarifying questions** - Show you understand the problem space
- **Draw diagrams** - Visual communication is powerful
- **Discuss trade-offs** - Every decision has pros/cons
- **Consider non-functional requirements** - Scalability, reliability, consistency
- **Use specific technologies** - Mention Spring Boot, Kafka, PostgreSQL, etc.
- **Talk about monitoring** - Show production awareness
- **Consider edge cases** - What happens when things fail?

### ❌ Don'ts
- **Don't jump into implementation** - Understand requirements first
- **Don't ignore constraints** - Budget, timeline, team size matter
- **Don't over-engineer** - Start simple, then scale
- **Don't forget about operations** - How do you deploy, monitor, debug?
- **Don't ignore data consistency** - Think about ACID vs BASE
- **Don't forget security** - Authentication, authorization, data protection

### 🎭 Communication Framework

#### 1. Problem Understanding (2-3 minutes)
"Let me make sure I understand the requirements..."
- Repeat back what you heard
- Ask clarifying questions
- Confirm assumptions

#### 2. High-Level Design (5-7 minutes)
"Let me start with a high-level architecture..."
- Draw major components
- Show data flow
- Identify key services

#### 3. Deep Dive (10-15 minutes)
"Let me dive deeper into [specific component]..."
- Choose 1-2 components to detail
- Discuss data models
- Show API contracts
- Consider implementation details

#### 4. Scale and Optimize (5-10 minutes)
"Now let's discuss how this scales..."
- Identify bottlenecks
- Propose solutions
- Calculate capacity
- Discuss monitoring

#### 5. Wrap Up (2-3 minutes)
"Let me summarize the key decisions..."
- Recap architecture
- Highlight trade-offs
- Mention next steps

---

## 📚 Final Preparation Checklist

### 🔧 Technical Knowledge
- [ ] Java 21 features and performance characteristics
- [ ] Spring Boot patterns and best practices
- [ ] Database design (SQL and NoSQL)
- [ ] Caching strategies (Redis, CDN)
- [ ] Message queues (Kafka, RabbitMQ)
- [ ] Microservices patterns
- [ ] API design principles
- [ ] Security best practices

### 📊 System Design Concepts
- [ ] CAP theorem and consistency models
- [ ] Horizontal vs vertical scaling
- [ ] Load balancing strategies
- [ ] Circuit breaker pattern
- [ ] Database sharding and partitioning
- [ ] Event-driven architecture
- [ ] CQRS and Event Sourcing
- [ ] Monitoring and observability

### 🎯 Practice Areas
- [ ] Draw architecture diagrams quickly
- [ ] Calculate capacity requirements
- [ ] Estimate storage and bandwidth needs
- [ ] Design APIs and data models
- [ ] Discuss trade-offs confidently
- [ ] Handle follow-up questions

**Remember: The goal is to demonstrate your thinking process, not to find the "perfect" solution. Show how you approach complex problems systematically!**
