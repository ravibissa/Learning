# Distributed Systems Patterns Cheat Sheet

## 🌐 Essential Patterns for Building Scalable Systems

### 🏗️ Architectural Patterns

#### 1. Microservices Architecture
```java
// Service Discovery with Spring Cloud
@SpringBootApplication
@EnableEurekaClient
public class UserServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(UserServiceApplication.class, args);
    }
}

// Service-to-service communication
@FeignClient(name = "order-service", fallback = OrderServiceFallback.class)
public interface OrderServiceClient {
    
    @GetMapping("/api/orders/user/{userId}")
    List<Order> getOrdersByUserId(@PathVariable String userId);
    
    @PostMapping("/api/orders")
    Order createOrder(@RequestBody CreateOrderRequest request);
}

// Fallback implementation for resilience
@Component
public class OrderServiceFallback implements OrderServiceClient {
    
    @Override
    public List<Order> getOrdersByUserId(String userId) {
        return Collections.emptyList();
    }
    
    @Override
    public Order createOrder(CreateOrderRequest request) {
        throw new ServiceUnavailableException("Order service is currently unavailable");
    }
}
```

#### 2. API Gateway Pattern
```java
// Spring Cloud Gateway configuration
@Configuration
public class GatewayConfig {
    
    @Bean
    public RouteLocator customRoutes(RouteLocatorBuilder builder) {
        return builder.routes()
            // User service routes
            .route("user-service", r -> r.path("/api/users/**")
                .filters(f -> f
                    .circuitBreaker(c -> c
                        .setName("user-service-cb")
                        .setFallbackUri("/fallback/users"))
                    .retry(retryConfig -> retryConfig
                        .setRetries(3)
                        .setBackoff(Duration.ofMillis(100), Duration.ofMillis(500), 2, true))
                    .requestRateLimiter(config -> config
                        .setRateLimiter(redisRateLimiter())
                        .setKeyResolver(userKeyResolver())))
                .uri("lb://user-service"))
            
            // Order service routes with authentication
            .route("order-service", r -> r.path("/api/orders/**")
                .filters(f -> f
                    .addRequestHeader("X-Gateway", "spring-cloud-gateway")
                    .removeRequestHeader("X-Internal-Secret"))
                .uri("lb://order-service"))
            
            // Public API routes
            .route("public-api", r -> r.path("/public/**")
                .filters(f -> f
                    .stripPrefix(1)
                    .addResponseHeader("X-Public-API", "true"))
                .uri("lb://public-service"))
            .build();
    }
    
    @Bean
    public RedisRateLimiter redisRateLimiter() {
        return new RedisRateLimiter(10, 20); // replenishRate, burstCapacity
    }
    
    @Bean
    public KeyResolver userKeyResolver() {
        return exchange -> exchange.getRequest().getHeaders()
            .getFirst("X-User-ID") != null ? 
            Mono.just(exchange.getRequest().getHeaders().getFirst("X-User-ID")) :
            Mono.just("anonymous");
    }
}
```

#### 3. Service Mesh Pattern
```yaml
# Istio service mesh configuration
apiVersion: networking.istio.io/v1beta1
kind: VirtualService
metadata:
  name: user-service
spec:
  http:
  - match:
    - headers:
        canary:
          exact: "true"
    route:
    - destination:
        host: user-service
        subset: canary
      weight: 100
  - route:
    - destination:
        host: user-service
        subset: stable
      weight: 100
    fault:
      delay:
        percentage:
          value: 0.1
        fixedDelay: 5s
    retries:
      attempts: 3
      perTryTimeout: 2s
```

---

### 🔄 Communication Patterns

#### 1. Request-Response Pattern
```java
// Synchronous communication with circuit breaker
@Service
public class OrderService {
    
    @Autowired
    private PaymentServiceClient paymentClient;
    
    @CircuitBreaker(name = "payment-service", fallbackMethod = "fallbackPayment")
    @TimeLimiter(name = "payment-service")
    @Retry(name = "payment-service")
    public CompletableFuture<PaymentResponse> processPayment(PaymentRequest request) {
        return CompletableFuture.supplyAsync(() -> {
            // Add correlation ID for tracing
            String correlationId = UUID.randomUUID().toString();
            request.setCorrelationId(correlationId);
            
            log.info("Processing payment with correlation ID: {}", correlationId);
            return paymentClient.processPayment(request);
        });
    }
    
    public CompletableFuture<PaymentResponse> fallbackPayment(PaymentRequest request, Exception ex) {
        log.warn("Payment service unavailable, using fallback: {}", ex.getMessage());
        return CompletableFuture.completedFuture(
            PaymentResponse.builder()
                .status("PENDING")
                .message("Payment queued for later processing")
                .correlationId(request.getCorrelationId())
                .build()
        );
    }
}

// Async request-response with callbacks
@RestController
public class AsyncOrderController {
    
    @PostMapping("/orders/async")
    public ResponseEntity<AsyncOrderResponse> createOrderAsync(@RequestBody CreateOrderRequest request) {
        String correlationId = UUID.randomUUID().toString();
        
        // Process order asynchronously
        orderService.createOrderAsync(request, correlationId);
        
        return ResponseEntity.accepted()
            .body(AsyncOrderResponse.builder()
                .correlationId(correlationId)
                .status("PROCESSING")
                .estimatedCompletionTime(Instant.now().plus(30, ChronoUnit.SECONDS))
                .build());
    }
    
    @GetMapping("/orders/status/{correlationId}")
    public ResponseEntity<OrderStatusResponse> getOrderStatus(@PathVariable String correlationId) {
        return orderStatusService.getStatus(correlationId)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }
}
```

#### 2. Event-Driven Pattern
```java
// Event publisher
@Service
public class OrderEventPublisher {
    
    @Autowired
    private ApplicationEventPublisher applicationEventPublisher;
    
    @Autowired
    private KafkaTemplate<String, Object> kafkaTemplate;
    
    public void publishOrderCreated(Order order) {
        // Local event for same-service consumers
        OrderCreatedEvent localEvent = new OrderCreatedEvent(order);
        applicationEventPublisher.publishEvent(localEvent);
        
        // External event for other services
        OrderCreatedMessage externalEvent = OrderCreatedMessage.builder()
            .orderId(order.getId())
            .userId(order.getUserId())
            .amount(order.getTotalAmount())
            .timestamp(order.getCreatedAt())
            .version(1)
            .build();
            
        kafkaTemplate.send("order-events", order.getId(), externalEvent);
    }
}

// Event consumer with idempotency
@KafkaListener(topics = "order-events", groupId = "notification-service")
public class OrderEventConsumer {
    
    @Autowired
    private NotificationService notificationService;
    
    @Autowired
    private EventProcessingRepository eventRepository;
    
    @Retryable(value = {Exception.class}, maxAttempts = 3, backoff = @Backoff(delay = 1000))
    public void handleOrderCreated(OrderCreatedMessage message) {
        // Check if already processed (idempotency)
        if (eventRepository.existsByEventIdAndType(message.getOrderId(), "ORDER_CREATED")) {
            log.info("Event already processed: {}", message.getOrderId());
            return;
        }
        
        try {
            // Process the event
            notificationService.sendOrderConfirmation(message);
            
            // Mark as processed
            eventRepository.save(new EventProcessingRecord(
                message.getOrderId(), 
                "ORDER_CREATED", 
                Instant.now()
            ));
            
        } catch (Exception e) {
            log.error("Failed to process order event: {}", message.getOrderId(), e);
            // Event will be retried due to @Retryable
            throw e;
        }
    }
}

// Saga pattern for distributed transactions
@Component
public class OrderSaga {
    
    @SagaOrchestrationStart
    public void processOrder(OrderCreatedEvent event) {
        SagaTransaction.builder()
            .step("reserve-inventory")
                .invokeParticipant("inventory-service")
                .withCompensation("release-inventory")
                .withTimeout(Duration.ofSeconds(30))
            .step("process-payment")
                .invokeParticipant("payment-service")
                .withCompensation("refund-payment")
                .withTimeout(Duration.ofSeconds(60))
            .step("create-shipment")
                .invokeParticipant("shipping-service")
                .withCompensation("cancel-shipment")
                .withTimeout(Duration.ofSeconds(45))
            .execute();
    }
    
    @SagaOrchestrationEnd
    public void orderCompleted(OrderCompletedEvent event) {
        log.info("Order {} completed successfully", event.getOrderId());
        // Send completion notification
        notificationService.sendOrderCompletionNotification(event.getOrderId());
    }
    
    @SagaOrchestrationError
    public void orderFailed(OrderFailedEvent event) {
        log.error("Order {} failed: {}", event.getOrderId(), event.getReason());
        // Trigger all compensations in reverse order
        sagaCompensationManager.compensateAll(event.getSagaId());
    }
}
```

#### 3. CQRS (Command Query Responsibility Segregation)
```java
// Command side
@Service
@Transactional
public class OrderCommandService {
    
    @Autowired
    private OrderWriteRepository writeRepository;
    
    @Autowired
    private DomainEventPublisher eventPublisher;
    
    public OrderCommandResult createOrder(CreateOrderCommand command) {
        // Validate command
        validateCreateOrderCommand(command);
        
        // Create domain entity
        Order order = Order.create(
            command.getUserId(),
            command.getItems(),
            command.getShippingAddress()
        );
        
        // Save to write store
        Order savedOrder = writeRepository.save(order);
        
        // Publish domain events
        eventPublisher.publish(new OrderCreatedEvent(savedOrder));
        
        return OrderCommandResult.success(savedOrder.getId());
    }
    
    public OrderCommandResult updateOrderStatus(UpdateOrderStatusCommand command) {
        Order order = writeRepository.findById(command.getOrderId())
            .orElseThrow(() -> new OrderNotFoundException(command.getOrderId()));
        
        order.updateStatus(command.getNewStatus(), command.getReason());
        writeRepository.save(order);
        
        eventPublisher.publish(new OrderStatusUpdatedEvent(order));
        
        return OrderCommandResult.success(order.getId());
    }
}

// Query side
@Service
@Transactional(readOnly = true)
public class OrderQueryService {
    
    @Autowired
    private OrderReadRepository readRepository;
    
    @Autowired
    private OrderViewRepository viewRepository;
    
    @Cacheable("order-details")
    public OrderDetailView getOrderDetail(String orderId) {
        return viewRepository.findOrderDetailById(orderId)
            .orElseThrow(() -> new OrderNotFoundException(orderId));
    }
    
    public Page<OrderSummaryView> getUserOrders(String userId, Pageable pageable) {
        return viewRepository.findUserOrderSummaries(userId, pageable);
    }
    
    public OrderAnalyticsView getOrderAnalytics(String userId, LocalDate from, LocalDate to) {
        return viewRepository.getOrderAnalytics(userId, from, to);
    }
}

// Event projection handler
@EventListener
@Async
public class OrderProjectionHandler {
    
    @Autowired
    private OrderViewRepository viewRepository;
    
    @EventListener
    public void handleOrderCreated(OrderCreatedEvent event) {
        OrderDetailView view = OrderDetailView.builder()
            .orderId(event.getOrderId())
            .userId(event.getUserId())
            .status(event.getStatus())
            .totalAmount(event.getTotalAmount())
            .createdAt(event.getCreatedAt())
            .items(buildItemViews(event.getItems()))
            .build();
            
        viewRepository.save(view);
    }
    
    @EventListener
    public void handleOrderStatusUpdated(OrderStatusUpdatedEvent event) {
        viewRepository.updateOrderStatus(
            event.getOrderId(),
            event.getNewStatus(),
            event.getUpdatedAt()
        );
    }
}
```

---

### 🗄️ Data Patterns

#### 1. Database per Service
```java
// User service database configuration
@Configuration
public class UserServiceDatabaseConfig {
    
    @Bean
    @Primary
    public DataSource userDataSource() {
        return DataSourceBuilder.create()
            .url("jdbc:postgresql://user-db:5432/users")
            .username("user_service")
            .password("user_password")
            .build();
    }
    
    @Bean
    @Primary
    public JpaTransactionManager userTransactionManager() {
        return new JpaTransactionManager(userEntityManagerFactory().getObject());
    }
}

// Order service database configuration
@Configuration
public class OrderServiceDatabaseConfig {
    
    @Bean
    public DataSource orderDataSource() {
        return DataSourceBuilder.create()
            .url("jdbc:postgresql://order-db:5432/orders")
            .username("order_service")
            .password("order_password")
            .build();
    }
}
```

#### 2. Event Sourcing
```java
// Event store
@Entity
@Table(name = "event_store")
public class EventStore {
    
    @Id
    private String eventId;
    
    @Column(name = "aggregate_id")
    private String aggregateId;
    
    @Column(name = "aggregate_type")
    private String aggregateType;
    
    @Column(name = "event_type")
    private String eventType;
    
    @Column(name = "event_data", columnDefinition = "jsonb")
    private String eventData;
    
    @Column(name = "event_version")
    private Long eventVersion;
    
    @Column(name = "occurred_at")
    private Instant occurredAt;
    
    // constructors, getters, setters
}

// Aggregate root with event sourcing
@Entity
public class Order implements AggregateRoot {
    
    @Id
    private String id;
    private String userId;
    private OrderStatus status;
    private BigDecimal totalAmount;
    private List<OrderItem> items;
    
    @Transient
    private List<DomainEvent> uncommittedEvents = new ArrayList<>();
    
    public static Order create(String userId, List<OrderItem> items, Address shippingAddress) {
        Order order = new Order();
        order.apply(new OrderCreatedEvent(
            UUID.randomUUID().toString(),
            userId,
            items,
            shippingAddress,
            Instant.now()
        ));
        return order;
    }
    
    public void updateStatus(OrderStatus newStatus, String reason) {
        if (canTransitionTo(newStatus)) {
            apply(new OrderStatusUpdatedEvent(
                this.id,
                this.status,
                newStatus,
                reason,
                Instant.now()
            ));
        } else {
            throw new InvalidOrderStatusTransitionException(this.status, newStatus);
        }
    }
    
    private void apply(DomainEvent event) {
        // Update state based on event
        when(event);
        // Add to uncommitted events
        uncommittedEvents.add(event);
    }
    
    private void when(DomainEvent event) {
        switch (event.getEventType()) {
            case "OrderCreated":
                when((OrderCreatedEvent) event);
                break;
            case "OrderStatusUpdated":
                when((OrderStatusUpdatedEvent) event);
                break;
            // Handle other events
        }
    }
    
    private void when(OrderCreatedEvent event) {
        this.id = event.getOrderId();
        this.userId = event.getUserId();
        this.status = OrderStatus.CREATED;
        this.items = event.getItems();
        this.totalAmount = calculateTotal(event.getItems());
    }
    
    private void when(OrderStatusUpdatedEvent event) {
        this.status = event.getNewStatus();
    }
    
    @Override
    public List<DomainEvent> getUncommittedEvents() {
        return new ArrayList<>(uncommittedEvents);
    }
    
    @Override
    public void markEventsAsCommitted() {
        uncommittedEvents.clear();
    }
}

// Event sourcing repository
@Repository
public class EventSourcedOrderRepository {
    
    @Autowired
    private EventStoreRepository eventStoreRepository;
    
    @Autowired
    private ObjectMapper objectMapper;
    
    public void save(Order order) {
        List<DomainEvent> events = order.getUncommittedEvents();
        
        for (DomainEvent event : events) {
            EventStore eventStore = new EventStore(
                UUID.randomUUID().toString(),
                order.getId(),
                "Order",
                event.getEventType(),
                serializeEvent(event),
                getNextVersion(order.getId()),
                event.getOccurredAt()
            );
            
            eventStoreRepository.save(eventStore);
        }
        
        order.markEventsAsCommitted();
    }
    
    public Optional<Order> findById(String orderId) {
        List<EventStore> events = eventStoreRepository
            .findByAggregateIdOrderByEventVersion(orderId);
        
        if (events.isEmpty()) {
            return Optional.empty();
        }
        
        Order order = new Order();
        for (EventStore eventStore : events) {
            DomainEvent event = deserializeEvent(eventStore);
            order.replay(event);
        }
        
        return Optional.of(order);
    }
}
```

#### 3. Distributed Cache Pattern
```java
// Multi-level cache implementation
@Service
public class DistributedCacheService {
    
    @Autowired
    private RedisTemplate<String, Object> redisTemplate;
    
    @Autowired
    private CacheManager localCacheManager;
    
    // L1: Local cache, L2: Redis, L3: Database
    public <T> Optional<T> get(String key, Class<T> type) {
        // Check L1 cache (local)
        Cache localCache = localCacheManager.getCache("local");
        T value = localCache.get(key, type);
        if (value != null) {
            return Optional.of(value);
        }
        
        // Check L2 cache (Redis)
        value = (T) redisTemplate.opsForValue().get(key);
        if (value != null) {
            // Populate L1 cache
            localCache.put(key, value);
            return Optional.of(value);
        }
        
        return Optional.empty();
    }
    
    public <T> void put(String key, T value, Duration ttl) {
        // Store in L2 cache (Redis)
        redisTemplate.opsForValue().set(key, value, ttl);
        
        // Store in L1 cache (local) with shorter TTL
        Duration localTtl = ttl.compareTo(Duration.ofMinutes(5)) > 0 ? 
            Duration.ofMinutes(5) : ttl;
        localCacheManager.getCache("local").put(key, value);
    }
    
    public void evict(String key) {
        // Evict from both levels
        redisTemplate.delete(key);
        localCacheManager.getCache("local").evict(key);
    }
}

// Cache-aside pattern with Spring
@Service
public class ProductService {
    
    @Autowired
    private ProductRepository productRepository;
    
    @Autowired
    private DistributedCacheService cacheService;
    
    public Product getProduct(String productId) {
        // Try cache first
        Optional<Product> cached = cacheService.get("product:" + productId, Product.class);
        if (cached.isPresent()) {
            return cached.get();
        }
        
        // Fetch from database
        Product product = productRepository.findById(productId)
            .orElseThrow(() -> new ProductNotFoundException(productId));
        
        // Store in cache
        cacheService.put("product:" + productId, product, Duration.ofHours(1));
        
        return product;
    }
    
    @CacheEvict(value = "products", key = "#product.id")
    public Product updateProduct(Product product) {
        Product updated = productRepository.save(product);
        
        // Update distributed cache
        cacheService.put("product:" + product.getId(), updated, Duration.ofHours(1));
        
        return updated;
    }
}
```

---

### 🔒 Security Patterns

#### 1. OAuth2/JWT Authentication
```java
// JWT token service
@Service
public class JwtTokenService {
    
    @Value("${jwt.secret}")
    private String secret;
    
    @Value("${jwt.expiration}")
    private Long expiration;
    
    public String generateToken(Authentication authentication) {
        UserPrincipal userPrincipal = (UserPrincipal) authentication.getPrincipal();
        
        Date expiryDate = new Date(System.currentTimeMillis() + expiration);
        
        return Jwts.builder()
            .setSubject(userPrincipal.getId())
            .setIssuedAt(new Date())
            .setExpiration(expiryDate)
            .claim("roles", userPrincipal.getAuthorities().stream()
                .map(GrantedAuthority::getAuthority)
                .collect(Collectors.toList()))
            .claim("email", userPrincipal.getEmail())
            .signWith(SignatureAlgorithm.HS512, secret)
            .compact();
    }
    
    public String getUserIdFromToken(String token) {
        Claims claims = Jwts.parser()
            .setSigningKey(secret)
            .parseClaimsJws(token)
            .getBody();
        
        return claims.getSubject();
    }
    
    public boolean validateToken(String authToken) {
        try {
            Jwts.parser().setSigningKey(secret).parseClaimsJws(authToken);
            return true;
        } catch (SignatureException ex) {
            log.error("Invalid JWT signature");
        } catch (MalformedJwtException ex) {
            log.error("Invalid JWT token");
        } catch (ExpiredJwtException ex) {
            log.error("Expired JWT token");
        } catch (UnsupportedJwtException ex) {
            log.error("Unsupported JWT token");
        } catch (IllegalArgumentException ex) {
            log.error("JWT claims string is empty");
        }
        return false;
    }
}

// Security configuration
@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class SecurityConfig {
    
    @Autowired
    private JwtAuthenticationEntryPoint unauthorizedHandler;
    
    @Bean
    public JwtAuthenticationFilter jwtAuthenticationFilter() {
        return new JwtAuthenticationFilter();
    }
    
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http.cors().and().csrf().disable()
            .exceptionHandling().authenticationEntryPoint(unauthorizedHandler).and()
            .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS).and()
            .authorizeHttpRequests(authz -> authz
                .requestMatchers("/api/auth/**").permitAll()
                .requestMatchers("/api/public/**").permitAll()
                .requestMatchers(HttpMethod.GET, "/api/products/**").permitAll()
                .requestMatchers("/actuator/health").permitAll()
                .requestMatchers("/api/admin/**").hasRole("ADMIN")
                .anyRequest().authenticated()
            );
        
        http.addFilterBefore(jwtAuthenticationFilter(), UsernamePasswordAuthenticationFilter.class);
        
        return http.build();
    }
}
```

#### 2. API Rate Limiting
```java
// Rate limiting with Redis
@Component
public class RateLimitingService {
    
    @Autowired
    private StringRedisTemplate redisTemplate;
    
    public boolean isAllowed(String clientId, String endpoint, int maxRequests, Duration window) {
        String key = "rate_limit:" + clientId + ":" + endpoint;
        String script = 
            "local key = KEYS[1] " +
            "local window = ARGV[1] " +
            "local limit = tonumber(ARGV[2]) " +
            "local current = redis.call('incr', key) " +
            "if current == 1 then " +
            "  redis.call('expire', key, window) " +
            "end " +
            "return current <= limit";
        
        Long result = redisTemplate.execute(
            RedisScript.of(script, Long.class),
            Collections.singletonList(key),
            String.valueOf(window.getSeconds()),
            String.valueOf(maxRequests)
        );
        
        return result != null && result <= maxRequests;
    }
}

// Rate limiting interceptor
@Component
public class RateLimitingInterceptor implements HandlerInterceptor {
    
    @Autowired
    private RateLimitingService rateLimitingService;
    
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
        String clientId = getClientId(request);
        String endpoint = request.getRequestURI();
        
        // Different limits for different endpoints
        RateLimit rateLimit = getRateLimitForEndpoint(endpoint);
        
        if (!rateLimitingService.isAllowed(clientId, endpoint, rateLimit.maxRequests(), rateLimit.window())) {
            response.setStatus(HttpStatus.TOO_MANY_REQUESTS.value());
            response.setHeader("X-RateLimit-Limit", String.valueOf(rateLimit.maxRequests()));
            response.setHeader("X-RateLimit-Window", rateLimit.window().toString());
            return false;
        }
        
        return true;
    }
    
    private String getClientId(HttpServletRequest request) {
        // Extract from JWT token, API key, or IP address
        String authHeader = request.getHeader("Authorization");
        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            return extractUserIdFromToken(authHeader.substring(7));
        }
        return request.getRemoteAddr();
    }
}
```

---

### 📊 Monitoring Patterns

#### 1. Health Checks
```java
// Comprehensive health check
@Component
public class ApplicationHealthIndicator implements HealthIndicator {
    
    @Autowired
    private DataSource dataSource;
    
    @Autowired
    private RedisTemplate<String, String> redisTemplate;
    
    @Autowired
    private KafkaTemplate<String, Object> kafkaTemplate;
    
    @Override
    public Health health() {
        Health.Builder status = Health.up();
        
        // Database health
        checkDatabase(status);
        
        // Redis health
        checkRedis(status);
        
        // Kafka health
        checkKafka(status);
        
        // External services health
        checkExternalServices(status);
        
        return status.build();
    }
    
    private void checkDatabase(Health.Builder status) {
        try (Connection connection = dataSource.getConnection()) {
            boolean isValid = connection.isValid(1);
            if (isValid) {
                status.withDetail("database", "UP");
            } else {
                status.down().withDetail("database", "Connection invalid");
            }
        } catch (SQLException e) {
            status.down().withDetail("database", "Connection failed: " + e.getMessage());
        }
    }
    
    private void checkRedis(Health.Builder status) {
        try {
            String response = redisTemplate.opsForValue().get("health-check");
            status.withDetail("redis", "UP");
        } catch (Exception e) {
            status.down().withDetail("redis", "Connection failed: " + e.getMessage());
        }
    }
}

// Custom metrics
@Component
public class ApplicationMetrics {
    
    private final Counter requestCounter;
    private final Timer responseTimer;
    private final Gauge activeConnections;
    
    public ApplicationMetrics(MeterRegistry meterRegistry) {
        this.requestCounter = Counter.builder("http.requests.total")
            .description("Total HTTP requests")
            .register(meterRegistry);
            
        this.responseTimer = Timer.builder("http.request.duration")
            .description("HTTP request duration")
            .register(meterRegistry);
            
        this.activeConnections = Gauge.builder("db.connections.active")
            .description("Active database connections")
            .register(meterRegistry, this, ApplicationMetrics::getActiveConnections);
    }
    
    public void recordRequest(String method, String endpoint, int statusCode, Duration duration) {
        requestCounter.increment(
            Tags.of(
                "method", method,
                "endpoint", endpoint,
                "status", String.valueOf(statusCode)
            )
        );
        
        responseTimer.record(duration,
            Tags.of(
                "method", method,
                "endpoint", endpoint
            )
        );
    }
    
    private double getActiveConnections() {
        // Return current active connection count
        return connectionPoolMetrics.getActive();
    }
}
```

#### 2. Distributed Tracing
```java
// Tracing configuration
@Configuration
public class TracingConfig {
    
    @Bean
    public Sender sender() {
        return OkHttpSender.create("http://jaeger:14268/api/traces");
    }
    
    @Bean
    public AsyncReporter<Span> spanReporter() {
        return AsyncReporter.create(sender());
    }
    
    @Bean
    public Tracing tracing() {
        return Tracing.newBuilder()
            .localServiceName("user-service")
            .spanReporter(spanReporter())
            .build();
    }
}

// Manual span creation
@Service
public class UserService {
    
    @Autowired
    private Tracing tracing;
    
    public User createUser(CreateUserRequest request) {
        Span span = tracing.tracer().nextSpan()
            .name("create-user")
            .tag("user.email", request.getEmail())
            .start();
        
        try (Tracer.SpanInScope ws = tracing.tracer().withSpanInScope(span)) {
            // Validate user
            Span validationSpan = tracing.tracer().nextSpan()
                .name("validate-user")
                .start();
            
            try (Tracer.SpanInScope vs = tracing.tracer().withSpanInScope(validationSpan)) {
                validateUser(request);
            } finally {
                validationSpan.end();
            }
            
            // Save user
            User user = userRepository.save(new User(request));
            span.tag("user.id", user.getId());
            
            return user;
            
        } catch (Exception e) {
            span.tag("error", e.getMessage());
            throw e;
        } finally {
            span.end();
        }
    }
}
```

---

### 🎯 Interview Quick Reference

#### Common Patterns by Use Case

**High Availability:**
- Circuit breaker pattern
- Bulkhead pattern
- Health checks and monitoring
- Multi-region deployment

**Scalability:**
- Load balancing
- Database sharding
- Caching strategies
- Async processing

**Consistency:**
- Event sourcing
- CQRS
- Saga pattern
- Two-phase commit

**Security:**
- OAuth2/JWT
- API gateway authentication
- Rate limiting
- Input validation

**Performance:**
- Caching (multi-level)
- Connection pooling
- Async processing
- Database optimization

**This comprehensive pattern guide provides the foundation for designing scalable, resilient distributed systems using Java and Spring Boot!**
