# System Design Patterns Cheat Sheet

## 📋 Quick Reference for System Design Interviews

### 🏗️ Architectural Patterns

#### 1. Microservices Architecture
```
✅ When to Use:
- Large, complex applications
- Multiple teams working independently
- Need for technology diversity
- Scalability requirements vary by service

❌ When NOT to Use:
- Small applications
- Single team
- Tight coupling between components
- Network latency critical

🛠️ Implementation:
- Service discovery (Eureka, Consul)
- API Gateway (Spring Cloud Gateway)
- Circuit breakers (Resilience4j)
- Distributed tracing (Jaeger)
```

#### 2. Event-Driven Architecture
```
✅ When to Use:
- Loosely coupled systems
- Real-time processing needs
- Scalable data pipelines
- Asynchronous workflows

🛠️ Components:
- Event bus (Kafka, RabbitMQ)
- Event sourcing
- CQRS (Command Query Responsibility Segregation)
- Saga pattern for transactions
```

#### 3. Layered Architecture
```
Presentation Layer (Controllers)
    ↓
Business Layer (Services)
    ↓
Data Access Layer (Repositories)
    ↓
Database Layer

Benefits: Separation of concerns, testability
Drawbacks: Can become monolithic
```

---

### 🎯 Design Patterns for Scale

#### 1. Database Patterns

**Sharding (Horizontal Partitioning)**
```sql
-- User ID based sharding
Shard 1: user_id % 4 = 0
Shard 2: user_id % 4 = 1
Shard 3: user_id % 4 = 2
Shard 4: user_id % 4 = 3

-- Geographic sharding
US_EAST: users in Eastern US
US_WEST: users in Western US
EU: users in Europe
ASIA: users in Asia
```

**Read Replicas**
```
Master DB (Writes) → Replica 1 (Reads)
                  → Replica 2 (Reads)
                  → Replica 3 (Reads)

Benefits: Read scalability, load distribution
Considerations: Eventual consistency, lag
```

**Database per Service**
```
User Service → User DB
Order Service → Order DB
Payment Service → Payment DB
Inventory Service → Inventory DB

Benefits: Service independence, technology choice
Challenges: Distributed transactions, data consistency
```

#### 2. Caching Patterns

**Cache-Aside (Lazy Loading)**
```java
public User getUser(String id) {
    User user = cache.get(id);
    if (user == null) {
        user = database.findById(id);
        cache.put(id, user);
    }
    return user;
}
```

**Write-Through**
```java
public void saveUser(User user) {
    database.save(user);
    cache.put(user.getId(), user);
}
```

**Write-Behind (Write-Back)**
```java
public void saveUser(User user) {
    cache.put(user.getId(), user);
    // Async write to database later
    asyncWriter.schedule(() -> database.save(user));
}
```

**Cache Levels**
```
Browser Cache (Client)
    ↓
CDN (Edge)
    ↓
Load Balancer Cache
    ↓
Application Cache (Redis)
    ↓
Database Query Cache
    ↓
Database
```

#### 3. Load Balancing Patterns

**Round Robin**
```
Request 1 → Server A
Request 2 → Server B
Request 3 → Server C
Request 4 → Server A (cycle repeats)
```

**Weighted Round Robin**
```
Server A (weight: 3) → Gets 3 requests
Server B (weight: 2) → Gets 2 requests
Server C (weight: 1) → Gets 1 request
```

**Least Connections**
```
Route to server with fewest active connections
Best for: Long-lived connections
```

**IP Hash**
```
hash(client_ip) % server_count = server_index
Benefits: Session affinity
Drawbacks: Uneven distribution
```

---

### 🔄 Messaging Patterns

#### 1. Publish-Subscribe
```
Publisher → Topic → Subscriber 1
                 → Subscriber 2
                 → Subscriber 3

Use Cases: Event notifications, real-time updates
Technologies: Kafka, RabbitMQ, AWS SNS
```

#### 2. Request-Response
```
Client → Request → Service
       ← Response ←

Synchronous communication
Technologies: HTTP REST, gRPC
```

#### 3. Fire and Forget
```
Client → Message → Queue → Consumer

Asynchronous communication
No response expected
```

#### 4. Message Queue Patterns

**Point-to-Point**
```
Producer → Queue → Consumer
Only one consumer receives each message
```

**Work Queue (Competing Consumers)**
```
Producer → Queue → Consumer 1
                → Consumer 2
                → Consumer 3
Load distribution among consumers
```

---

### 🛡️ Resilience Patterns

#### 1. Circuit Breaker
```
States: CLOSED → OPEN → HALF_OPEN → CLOSED

CLOSED: Normal operation
OPEN: Failing fast (errors above threshold)
HALF_OPEN: Testing if service recovered
```

#### 2. Retry with Exponential Backoff
```
Attempt 1: Immediate
Attempt 2: Wait 1s
Attempt 3: Wait 2s
Attempt 4: Wait 4s
Attempt 5: Wait 8s

Add jitter to prevent thundering herd
```

#### 3. Bulkhead
```
Isolate resources to prevent cascading failures

Thread Pool 1: Critical operations
Thread Pool 2: Non-critical operations
Thread Pool 3: Background tasks
```

#### 4. Timeout
```
Set timeouts for all external calls
Fail fast rather than hang indefinitely
Different timeouts for different operations
```

---

### 📊 Data Consistency Patterns

#### 1. ACID Transactions
```
Atomicity: All or nothing
Consistency: Valid state transitions
Isolation: Concurrent transaction isolation
Durability: Committed data survives failures

Use: Single database operations
```

#### 2. Eventual Consistency
```
System becomes consistent over time
Immediate consistency not guaranteed
Suitable for distributed systems

Example: DNS propagation, social media feeds
```

#### 3. Saga Pattern
```
Distributed transaction as sequence of local transactions
Each step has compensating action

Order Saga:
1. Reserve inventory
2. Process payment
3. Ship order

Compensation:
1. Release inventory
2. Refund payment
3. Cancel shipment
```

#### 4. Two-Phase Commit (2PC)
```
Phase 1: Prepare (voting)
- Coordinator asks all participants: "Can you commit?"
- Participants respond: "Yes" or "No"

Phase 2: Commit/Abort
- If all "Yes": Coordinator sends "Commit"
- If any "No": Coordinator sends "Abort"

Drawbacks: Blocking protocol, single point of failure
```

---

### 🔍 Search and Indexing Patterns

#### 1. Full-Text Search
```
Inverted Index:
"hello world" → Document 1, Position 1-2
"world peace" → Document 2, Position 1-2

Technologies: Elasticsearch, Solr, Lucene
```

#### 2. Autocomplete/Typeahead
```
Trie (Prefix Tree):
    a
   / \
  p   u
 /     \
ple    to
|       |
apple  auto

Strategies: Prefix matching, fuzzy search, ranking
```

#### 3. Geospatial Search
```
QuadTree: Divide 2D space into quadrants
Geohash: Base32 encoding of lat/lng
S2: Google's spherical geometry library

Use Cases: Location-based services, geo-fencing
```

---

### 🎨 API Design Patterns

#### 1. RESTful APIs
```
GET    /users           # List users
GET    /users/{id}      # Get user
POST   /users           # Create user
PUT    /users/{id}      # Update user
DELETE /users/{id}      # Delete user

Principles: Stateless, cacheable, uniform interface
```

#### 2. GraphQL
```
query {
  user(id: "123") {
    name
    email
    posts {
      title
      content
    }
  }
}

Benefits: Single endpoint, client-specified data
Challenges: N+1 problem, complexity
```

#### 3. gRPC
```
service UserService {
  rpc GetUser(GetUserRequest) returns (UserResponse);
  rpc ListUsers(ListUsersRequest) returns (stream UserResponse);
}

Benefits: Performance, type safety, streaming
Challenges: Debugging, limited browser support
```

---

### 📈 Monitoring and Observability Patterns

#### 1. The Three Pillars

**Metrics**
```
Business Metrics: Orders/sec, Revenue/hour
Application Metrics: Response time, throughput
Infrastructure Metrics: CPU, memory, disk

Tools: Prometheus, Grafana, DataDog
```

**Logs**
```
Structured Logging (JSON):
{
  "timestamp": "2024-01-15T10:30:00Z",
  "level": "ERROR",
  "service": "user-service",
  "trace_id": "abc123",
  "message": "User not found",
  "user_id": "user123"
}

Tools: ELK Stack, Fluentd, Splunk
```

**Traces**
```
Distributed tracing across services:
Request → API Gateway → User Service → Database
       ↘ Order Service → Payment Service

Tools: Jaeger, Zipkin, AWS X-Ray
```

#### 2. SLI/SLO/SLA
```
SLI (Service Level Indicator): Actual measurement
- Latency: 95% of requests < 200ms
- Availability: 99.9% uptime
- Error rate: < 0.1% of requests fail

SLO (Service Level Objective): Target value
- 99.9% availability over 30 days
- 95% of requests complete in < 200ms

SLA (Service Level Agreement): Contract with users
- 99.9% availability or credits issued
```

---

### 🔐 Security Patterns

#### 1. Authentication Patterns

**JWT (JSON Web Tokens)**
```
Header.Payload.Signature

Claims:
{
  "sub": "user123",
  "name": "John Doe",
  "iat": 1516239022,
  "exp": 1516242622
}

Benefits: Stateless, cross-domain, scalable
Considerations: Token size, revocation challenges
```

**OAuth 2.0 Flows**
```
Authorization Code: Web applications
Implicit: Single-page applications (deprecated)
Client Credentials: Service-to-service
Resource Owner Password: Legacy (not recommended)
```

#### 2. Authorization Patterns

**RBAC (Role-Based Access Control)**
```
Users → Roles → Permissions
John → Admin → [create, read, update, delete]
Jane → Editor → [create, read, update]
Bob → Viewer → [read]
```

**ABAC (Attribute-Based Access Control)**
```
if (user.department == "Finance" AND 
    resource.type == "budget" AND 
    action == "read" AND
    time.hour >= 9 AND time.hour <= 17) {
    allow();
}
```

---

### 🧪 Testing Patterns

#### 1. Test Pyramid
```
    E2E Tests (Few)
         /\
        /  \
   Integration Tests (Some)
      /        \
     /          \
Unit Tests (Many)

70% Unit, 20% Integration, 10% E2E
```

#### 2. Testing in Microservices

**Contract Testing**
```
Consumer-driven contracts
API compatibility testing
Schema validation

Tools: Pact, Spring Cloud Contract
```

**Service Virtualization**
```
Mock external dependencies
Simulate error conditions
Performance testing

Tools: WireMock, Testcontainers
```

---

### 📋 Quick Decision Matrix

| Requirement | Pattern | Technology |
|-------------|---------|------------|
| High throughput | Event-driven + Kafka | Kafka, Pulsar |
| Strong consistency | ACID transactions | PostgreSQL, MySQL |
| Global scale | CDN + Edge computing | CloudFlare, AWS CloudFront |
| Real-time features | WebSockets + Message queues | Socket.IO, Server-Sent Events |
| Search capabilities | Full-text search | Elasticsearch, Solr |
| File storage | Object storage | AWS S3, MinIO |
| Session management | Distributed cache | Redis, Hazelcast |
| API rate limiting | Token bucket + Redis | Redis, API Gateway |

---

### 🎯 Common Interview Scenarios

#### System Design Approach
1. **Clarify requirements** (5 minutes)
2. **Estimate scale** (5 minutes)
3. **Design high-level architecture** (10 minutes)
4. **Design detailed components** (15 minutes)
5. **Scale the design** (10 minutes)

#### Red Flags to Avoid
- ❌ Jumping into details too quickly
- ❌ Not asking clarifying questions
- ❌ Ignoring scalability
- ❌ Not considering failure scenarios
- ❌ Overengineering the solution

#### Green Flags to Hit
- ✅ Ask clarifying questions
- ✅ Start with simple design
- ✅ Consider trade-offs
- ✅ Address scalability
- ✅ Discuss monitoring and alerts

---

**Remember: There's no perfect solution in system design. Every decision involves trade-offs. Focus on understanding requirements and making informed decisions based on constraints.**
