# Java 21 Features Cheat Sheet for System Design

## 🚀 Key Features for System Design Applications

### 🧵 Virtual Threads (Project Loom)

**Perfect for I/O-heavy applications like web services**

```java
// Traditional thread pool (limited scalability)
ExecutorService executor = Executors.newFixedThreadPool(200);

// Virtual threads (millions of threads possible)
ExecutorService virtualExecutor = Executors.newVirtualThreadPerTaskExecutor();

// Example: Handle millions of concurrent requests
@RestController
public class HighThroughputController {
    
    private final ExecutorService virtualExecutor = 
        Executors.newVirtualThreadPerTaskExecutor();
    
    @GetMapping("/process")
    public CompletableFuture<String> processRequest() {
        return CompletableFuture.supplyAsync(() -> {
            // This can be blocking I/O - no problem with virtual threads!
            return callExternalService();
        }, virtualExecutor);
    }
    
    // Database queries with virtual threads
    public List<User> getUsers() {
        // Each query runs in a virtual thread
        var futures = IntStream.range(0, 1000)
            .mapToObj(i -> CompletableFuture.supplyAsync(() -> 
                userRepository.findByRegion(i), virtualExecutor))
            .toList();
            
        return futures.stream()
            .map(CompletableFuture::join)
            .flatMap(List::stream)
            .toList();
    }
}

// Kafka consumer with virtual threads
@KafkaListener(topics = "events")
public void processEvent(String event) {
    // Each message processed in virtual thread
    Thread.startVirtualThread(() -> {
        // Heavy processing without blocking platform threads
        processHeavyWorkload(event);
    });
}
```

**Benefits for System Design:**
- Handle millions of concurrent connections
- No thread pool tuning needed
- Perfect for microservices with many I/O operations
- Simplified reactive programming

---

### 🔤 String Templates (Preview)

**Safer and more readable string composition**

```java
// Traditional concatenation (error-prone)
String query = "SELECT * FROM users WHERE id = " + userId + " AND status = '" + status + "'";

// String templates (safe and readable)
String query = STR."SELECT * FROM users WHERE id = \{userId} AND status = '\{status}'";

// Multi-line templates for complex queries
String complexQuery = STR."""
    SELECT u.id, u.name, p.title
    FROM users u
    JOIN posts p ON u.id = p.user_id
    WHERE u.created_at > '\{startDate}'
    AND u.region = '\{region}'
    ORDER BY u.created_at DESC
    LIMIT \{limit}
    """;

// JSON API responses
@GetMapping("/users/{id}")
public String getUserJson(@PathVariable String id) {
    User user = userService.findById(id);
    return STR."""
        {
            "id": "\{user.getId()}",
            "name": "\{user.getName()}",
            "email": "\{user.getEmail()}",
            "created_at": "\{user.getCreatedAt()}"
        }
        """;
}

// Log messages with context
public void logError(String operation, Exception e) {
    log.error(STR."Operation \{operation} failed for user \{getCurrentUser()}: \{e.getMessage()}");
}

// Configuration templates
public String buildDatabaseUrl(String host, int port, String database) {
    return STR."jdbc:postgresql://\{host}:\{port}/\{database}?ssl=true&connectTimeout=30";
}
```

---

### 🔢 Pattern Matching for Switch

**Cleaner conditional logic for system design scenarios**

```java
// API response handling
public ResponseEntity<String> handleApiResponse(Object response) {
    return switch (response) {
        case null -> ResponseEntity.badRequest().body("Invalid response");
        case String s when s.isEmpty() -> ResponseEntity.noContent().build();
        case String s -> ResponseEntity.ok(s);
        case List<?> list when list.isEmpty() -> ResponseEntity.noContent().build();
        case List<?> list -> ResponseEntity.ok(toJson(list));
        case ErrorResponse(var code, var message) -> 
            ResponseEntity.status(code).body(message);
        default -> ResponseEntity.internalServerError().build();
    };
}

// Event processing with pattern matching
public void processEvent(Event event) {
    switch (event) {
        case UserCreatedEvent(var userId, var timestamp) -> {
            userMetrics.incrementCreations();
            sendWelcomeEmail(userId);
        }
        case UserDeletedEvent(var userId, var reason) -> {
            userMetrics.incrementDeletions();
            cleanupUserData(userId, reason);
        }
        case OrderPlacedEvent(var orderId, var amount) when amount.compareTo(LARGE_ORDER_THRESHOLD) > 0 -> {
            fraudDetectionService.checkLargeOrder(orderId);
            notifyVipTeam(orderId);
        }
        case OrderPlacedEvent(var orderId, var amount) -> {
            orderMetrics.recordOrder(amount);
            processNormalOrder(orderId);
        }
        default -> log.warn("Unknown event type: {}", event.getClass());
    }
}

// HTTP status code handling
public String getStatusMessage(int statusCode) {
    return switch (statusCode) {
        case 200, 201, 202 -> "Success";
        case 400, 401, 403 -> "Client Error";
        case 404 -> "Not Found";
        case 500, 502, 503 -> "Server Error";
        case int code when code >= 200 && code < 300 -> "Success Range";
        case int code when code >= 400 && code < 500 -> "Client Error Range";
        case int code when code >= 500 -> "Server Error Range";
        default -> "Unknown Status";
    };
}

// Circuit breaker state handling
public void handleCircuitBreakerState(CircuitBreaker.State state) {
    switch (state) {
        case CircuitBreaker.State.CLOSED -> {
            log.info("Circuit breaker closed - normal operation");
            metrics.recordCircuitBreakerState("closed");
        }
        case CircuitBreaker.State.OPEN -> {
            log.warn("Circuit breaker open - failing fast");
            metrics.recordCircuitBreakerState("open");
            alertService.sendAlert("Circuit breaker opened");
        }
        case CircuitBreaker.State.HALF_OPEN -> {
            log.info("Circuit breaker half-open - testing recovery");
            metrics.recordCircuitBreakerState("half_open");
        }
    }
}
```

---

### 📝 Record Patterns

**Perfect for DTOs and data transfer in microservices**

```java
// API request/response records
public record CreateUserRequest(
    String username,
    String email,
    String firstName,
    String lastName
) {
    // Compact constructor with validation
    public CreateUserRequest {
        if (username == null || username.isBlank()) {
            throw new IllegalArgumentException("Username cannot be blank");
        }
        if (email == null || !email.contains("@")) {
            throw new IllegalArgumentException("Invalid email format");
        }
        // Normalize data
        username = username.trim().toLowerCase();
        email = email.trim().toLowerCase();
    }
}

// Database result mapping
public record UserStats(
    String userId,
    long totalOrders,
    BigDecimal totalSpent,
    LocalDateTime lastActivity
) {}

// Event records for messaging
public record OrderEvent(
    String orderId,
    String userId,
    BigDecimal amount,
    OrderStatus status,
    Instant timestamp
) implements Serializable {}

// Decomposing records in pattern matching
public void processApiRequest(Object request) {
    switch (request) {
        case CreateUserRequest(var username, var email, var firstName, var lastName) -> {
            log.info("Creating user: {} with email: {}", username, email);
            userService.createUser(username, email, firstName, lastName);
        }
        case UpdateUserRequest(var id, var updates) when updates.isEmpty() -> {
            log.warn("Empty update request for user: {}", id);
        }
        case UpdateUserRequest(var id, var updates) -> {
            userService.updateUser(id, updates);
        }
    }
}

// Configuration records
public record DatabaseConfig(
    String host,
    int port,
    String database,
    String username,
    String password,
    int maxConnections,
    Duration connectionTimeout
) {
    public String toJdbcUrl() {
        return STR."jdbc:postgresql://\{host}:\{port}/\{database}";
    }
}

// Metrics records
public record ServiceMetrics(
    String serviceName,
    long requestCount,
    double averageResponseTime,
    double errorRate,
    Instant timestamp
) {}
```

---

### 🔒 Sequenced Collections

**Better collection APIs for system design data structures**

```java
// Queue operations with clear semantics
public class MessageProcessor {
    private final SequencedSet<String> processedMessages = new LinkedHashSet<>();
    private final SequencedCollection<Task> taskQueue = new ArrayDeque<>();
    
    public void addTask(Task task) {
        taskQueue.addLast(task);  // Clear intention - add to end
    }
    
    public Task getNextTask() {
        return taskQueue.removeFirst();  // Clear intention - remove from front
    }
    
    public Task getLastTask() {
        return taskQueue.getLast();  // No more awkward workarounds
    }
    
    // LRU cache implementation
    public class LRUCache<K, V> {
        private final SequencedMap<K, V> cache = new LinkedHashMap<>();
        private final int maxSize;
        
        public LRUCache(int maxSize) {
            this.maxSize = maxSize;
        }
        
        public V get(K key) {
            V value = cache.remove(key);  // Remove to reorder
            if (value != null) {
                cache.putLast(key, value);  // Add to end (most recent)
            }
            return value;
        }
        
        public void put(K key, V value) {
            cache.remove(key);  // Remove if exists
            cache.putLast(key, value);  // Add to end
            
            if (cache.size() > maxSize) {
                cache.removeFirst();  // Remove oldest entry
            }
        }
    }
}

// Rate limiting with sliding window
public class SlidingWindowRateLimiter {
    private final SequencedMap<Instant, Integer> requestCounts = new LinkedHashMap<>();
    private final Duration windowSize;
    private final int maxRequests;
    
    public boolean allowRequest() {
        Instant now = Instant.now();
        Instant windowStart = now.minus(windowSize);
        
        // Remove old entries
        while (!requestCounts.isEmpty() && 
               requestCounts.firstEntry().getKey().isBefore(windowStart)) {
            requestCounts.removeFirst();
        }
        
        // Count current requests
        int currentRequests = requestCounts.values().stream()
            .mapToInt(Integer::intValue)
            .sum();
            
        if (currentRequests < maxRequests) {
            requestCounts.put(now, 1);
            return true;
        }
        
        return false;
    }
}
```

---

### 🛠️ Practical Applications in System Design

#### 1. High-Performance Web Services

```java
@RestController
public class HighPerformanceController {
    
    private final ExecutorService virtualExecutor = 
        Executors.newVirtualThreadPerTaskExecutor();
    
    @GetMapping("/dashboard/{userId}")
    public CompletableFuture<DashboardData> getDashboard(@PathVariable String userId) {
        return CompletableFuture.supplyAsync(() -> {
            // Parallel data fetching with virtual threads
            var userFuture = CompletableFuture.supplyAsync(
                () -> userService.getUser(userId), virtualExecutor);
            var ordersFuture = CompletableFuture.supplyAsync(
                () -> orderService.getRecentOrders(userId), virtualExecutor);
            var recommendationsFuture = CompletableFuture.supplyAsync(
                () -> recommendationService.getRecommendations(userId), virtualExecutor);
            
            // Wait for all and combine
            var user = userFuture.join();
            var orders = ordersFuture.join();
            var recommendations = recommendationsFuture.join();
            
            return new DashboardData(user, orders, recommendations);
        }, virtualExecutor);
    }
}
```

#### 2. Event Processing Pipeline

```java
@Component
public class EventProcessor {
    
    public void processEvents(List<Event> events) {
        // Virtual threads for each event
        var futures = events.stream()
            .map(event -> CompletableFuture.runAsync(() -> {
                switch (event) {
                    case UserEvent(var userId, var action) -> {
                        log.info(STR."Processing user event: \{action} for user \{userId}");
                        userEventHandler.handle(userId, action);
                    }
                    case OrderEvent(var orderId, var status) -> {
                        log.info(STR."Processing order event: \{status} for order \{orderId}");
                        orderEventHandler.handle(orderId, status);
                    }
                    default -> log.warn(STR."Unknown event type: \{event.getClass()}");
                }
            }, Executors.newVirtualThreadPerTaskExecutor()))
            .toList();
        
        // Wait for all events to complete
        CompletableFuture.allOf(futures.toArray(new CompletableFuture[0])).join();
    }
}
```

#### 3. Advanced Error Handling

```java
public class ErrorHandler {
    
    public ResponseEntity<?> handleError(Exception error) {
        return switch (error) {
            case ValidationException(var field, var message) -> 
                ResponseEntity.badRequest()
                    .body(STR."Validation failed for \{field}: \{message}");
                    
            case NotFoundException(var resource, var id) -> 
                ResponseEntity.notFound()
                    .header("X-Error", STR."\{resource} not found: \{id}")
                    .build();
                    
            case TimeoutException timeout when timeout.getMessage().contains("database") -> 
                ResponseEntity.status(503)
                    .body("Database temporarily unavailable");
                    
            case CircuitBreakerOpenException breaker -> 
                ResponseEntity.status(503)
                    .body(STR."Service \{breaker.getServiceName()} temporarily unavailable");
                    
            default -> {
                log.error("Unexpected error: {}", error.getMessage(), error);
                yield ResponseEntity.internalServerError()
                    .body("An unexpected error occurred");
            }
        };
    }
}
```

---

### ⚡ Performance Benefits

#### Virtual Threads vs Traditional Threads

```java
// Performance comparison example
@Component
public class PerformanceComparison {
    
    // Traditional approach - limited by thread pool size
    private final ExecutorService traditionalExecutor = 
        Executors.newFixedThreadPool(200);
    
    // Virtual threads - can handle millions
    private final ExecutorService virtualExecutor = 
        Executors.newVirtualThreadPerTaskExecutor();
    
    @Benchmark
    public void traditionalThreads() {
        List<CompletableFuture<String>> futures = IntStream.range(0, 10000)
            .mapToObj(i -> CompletableFuture.supplyAsync(() -> {
                // Simulate I/O operation
                try {
                    Thread.sleep(100);
                    return STR."Result \{i}";
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    return "Error";
                }
            }, traditionalExecutor))
            .toList();
        
        // This will be limited by thread pool size (200)
        CompletableFuture.allOf(futures.toArray(new CompletableFuture[0])).join();
    }
    
    @Benchmark
    public void virtualThreads() {
        List<CompletableFuture<String>> futures = IntStream.range(0, 10000)
            .mapToObj(i -> CompletableFuture.supplyAsync(() -> {
                // Same I/O operation
                try {
                    Thread.sleep(100);
                    return STR."Result \{i}";
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    return "Error";
                }
            }, virtualExecutor))
            .toList();
        
        // This can handle all 10,000 concurrent operations
        CompletableFuture.allOf(futures.toArray(new CompletableFuture[0])).join();
    }
}
```

---

### 🎯 Best Practices for System Design

#### 1. Use Virtual Threads for I/O-Heavy Operations
```java
// ✅ Good - I/O heavy operations
CompletableFuture.supplyAsync(() -> {
    return databaseService.query(sql);  // Blocking I/O
}, virtualExecutor);

// ❌ Avoid - CPU intensive operations
CompletableFuture.supplyAsync(() -> {
    return computeHeavyCalculation();  // CPU bound
}, virtualExecutor);
```

#### 2. Leverage Pattern Matching for Clean Code
```java
// ✅ Good - Clean and readable
public void handleRequest(Request request) {
    switch (request) {
        case GetRequest(var path) -> handleGet(path);
        case PostRequest(var path, var body) -> handlePost(path, body);
        case PutRequest(var path, var body) -> handlePut(path, body);
        default -> throw new UnsupportedOperationException();
    }
}

// ❌ Avoid - Verbose instanceof chains
public void handleRequestOld(Request request) {
    if (request instanceof GetRequest getReq) {
        handleGet(getReq.path());
    } else if (request instanceof PostRequest postReq) {
        handlePost(postReq.path(), postReq.body());
    }
    // ... more verbose code
}
```

#### 3. Use Records for Data Transfer
```java
// ✅ Good - Clear, immutable data transfer
public record ApiResponse(
    int statusCode,
    String message,
    Object data,
    Instant timestamp
) {}

// ❌ Avoid - Mutable DTOs with boilerplate
public class ApiResponseOld {
    private int statusCode;
    private String message;
    private Object data;
    // ... lots of getters/setters/equals/hashCode
}
```

---

### 📋 Migration Checklist

#### From Java 17 to Java 21
- [ ] **Virtual Threads**: Replace traditional thread pools for I/O operations
- [ ] **String Templates**: Replace string concatenation with templates
- [ ] **Pattern Matching**: Simplify switch statements and instanceof checks
- [ ] **Records**: Convert DTOs to records where appropriate
- [ ] **Sequenced Collections**: Use new collection methods for clearer intent

#### Performance Monitoring
- [ ] **Thread Usage**: Monitor virtual thread creation/destruction
- [ ] **Memory Usage**: Virtual threads use less memory per thread
- [ ] **Throughput**: Expect significant improvements in I/O-heavy applications
- [ ] **Latency**: Monitor for any regression in CPU-bound operations

---

**Java 21 provides significant improvements for system design applications, particularly in handling concurrent I/O operations and writing cleaner, more maintainable code. Virtual threads alone can transform the scalability characteristics of your microservices.**
