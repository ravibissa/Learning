package com.systemdesign.ratelimiter.algorithm;

import java.time.Duration;
import java.time.Instant;

/**
 * Result of a rate limit check
 */
public class RateLimitResult {
    
    private final boolean allowed;
    private final long remainingTokens;
    private final Duration retryAfter;
    private final Duration refillTime;
    private final Instant timestamp;
    private final String reason;
    
    private RateLimitResult(Builder builder) {
        this.allowed = builder.allowed;
        this.remainingTokens = builder.remainingTokens;
        this.retryAfter = builder.retryAfter;
        this.refillTime = builder.refillTime;
        this.timestamp = builder.timestamp != null ? builder.timestamp : Instant.now();
        this.reason = builder.reason;
    }
    
    public static RateLimitResult allowed() {
        return new Builder(true).build();
    }
    
    public static RateLimitResult denied() {
        return new Builder(false).build();
    }
    
    public static Builder builder(boolean allowed) {
        return new Builder(allowed);
    }
    
    public boolean isAllowed() {
        return allowed;
    }
    
    public long getRemainingTokens() {
        return remainingTokens;
    }
    
    public Duration getRetryAfter() {
        return retryAfter;
    }
    
    public Duration getRefillTime() {
        return refillTime;
    }
    
    public Instant getTimestamp() {
        return timestamp;
    }
    
    public String getReason() {
        return reason;
    }
    
    public RateLimitResult withRemainingTokens(long tokens) {
        return new Builder(this.allowed)
            .remainingTokens(tokens)
            .retryAfter(this.retryAfter)
            .refillTime(this.refillTime)
            .timestamp(this.timestamp)
            .reason(this.reason)
            .build();
    }
    
    public RateLimitResult withRetryAfter(Duration retryAfter) {
        return new Builder(this.allowed)
            .remainingTokens(this.remainingTokens)
            .retryAfter(retryAfter)
            .refillTime(this.refillTime)
            .timestamp(this.timestamp)
            .reason(this.reason)
            .build();
    }
    
    public RateLimitResult withRefillTime(Duration refillTime) {
        return new Builder(this.allowed)
            .remainingTokens(this.remainingTokens)
            .retryAfter(this.retryAfter)
            .refillTime(refillTime)
            .timestamp(this.timestamp)
            .reason(this.reason)
            .build();
    }
    
    public static class Builder {
        private final boolean allowed;
        private long remainingTokens = 0;
        private Duration retryAfter = Duration.ZERO;
        private Duration refillTime = Duration.ZERO;
        private Instant timestamp;
        private String reason;
        
        private Builder(boolean allowed) {
            this.allowed = allowed;
        }
        
        public Builder remainingTokens(long tokens) {
            this.remainingTokens = tokens;
            return this;
        }
        
        public Builder retryAfter(Duration retryAfter) {
            this.retryAfter = retryAfter;
            return this;
        }
        
        public Builder refillTime(Duration refillTime) {
            this.refillTime = refillTime;
            return this;
        }
        
        public Builder timestamp(Instant timestamp) {
            this.timestamp = timestamp;
            return this;
        }
        
        public Builder reason(String reason) {
            this.reason = reason;
            return this;
        }
        
        public RateLimitResult build() {
            return new RateLimitResult(this);
        }
    }
    
    @Override
    public String toString() {
        return String.format(
            "RateLimitResult{allowed=%s, remainingTokens=%d, retryAfter=%s, refillTime=%s, timestamp=%s, reason='%s'}",
            allowed, remainingTokens, retryAfter, refillTime, timestamp, reason
        );
    }
}
