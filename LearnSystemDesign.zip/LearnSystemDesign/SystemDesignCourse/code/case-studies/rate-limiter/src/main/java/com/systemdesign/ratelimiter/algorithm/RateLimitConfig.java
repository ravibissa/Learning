package com.systemdesign.ratelimiter.algorithm;

import java.time.Duration;

/**
 * Configuration for rate limiting
 */
public class RateLimitConfig {
    
    private final long capacity;
    private final double refillRate;
    private final Duration window;
    private final long tokensRequested;
    private final boolean local;
    private final String algorithm;
    
    private RateLimitConfig(Builder builder) {
        this.capacity = builder.capacity;
        this.refillRate = builder.refillRate;
        this.window = builder.window;
        this.tokensRequested = builder.tokensRequested;
        this.local = builder.local;
        this.algorithm = builder.algorithm;
    }
    
    public static Builder builder() {
        return new Builder();
    }
    
    public long getCapacity() {
        return capacity;
    }
    
    public double getRefillRate() {
        return refillRate;
    }
    
    public Duration getWindow() {
        return window;
    }
    
    public long getTokensRequested() {
        return tokensRequested;
    }
    
    public boolean isLocal() {
        return local;
    }
    
    public String getAlgorithm() {
        return algorithm;
    }
    
    public static class Builder {
        private long capacity = 100;
        private double refillRate = 10.0; // tokens per second
        private Duration window = Duration.ofMinutes(1);
        private long tokensRequested = 1;
        private boolean local = false;
        private String algorithm = "TOKEN_BUCKET";
        
        public Builder capacity(long capacity) {
            this.capacity = capacity;
            return this;
        }
        
        public Builder refillRate(double refillRate) {
            this.refillRate = refillRate;
            return this;
        }
        
        public Builder window(Duration window) {
            this.window = window;
            return this;
        }
        
        public Builder tokensRequested(long tokens) {
            this.tokensRequested = tokens;
            return this;
        }
        
        public Builder local(boolean local) {
            this.local = local;
            return this;
        }
        
        public Builder algorithm(String algorithm) {
            this.algorithm = algorithm;
            return this;
        }
        
        // Convenience methods for common configurations
        public Builder apiLimiting() {
            return capacity(1000)
                .refillRate(100.0)
                .window(Duration.ofMinutes(1))
                .algorithm("TOKEN_BUCKET");
        }
        
        public Builder ddosProtection() {
            return capacity(10)
                .refillRate(1.0)
                .window(Duration.ofSeconds(10))
                .algorithm("SLIDING_WINDOW_LOG");
        }
        
        public Builder bulkOperations() {
            return capacity(50)
                .refillRate(5.0)
                .window(Duration.ofMinutes(5))
                .algorithm("SLIDING_WINDOW_COUNTER");
        }
        
        public RateLimitConfig build() {
            return new RateLimitConfig(this);
        }
    }
    
    @Override
    public String toString() {
        return String.format(
            "RateLimitConfig{capacity=%d, refillRate=%.2f, window=%s, tokensRequested=%d, local=%s, algorithm='%s'}",
            capacity, refillRate, window, tokensRequested, local, algorithm
        );
    }
}
