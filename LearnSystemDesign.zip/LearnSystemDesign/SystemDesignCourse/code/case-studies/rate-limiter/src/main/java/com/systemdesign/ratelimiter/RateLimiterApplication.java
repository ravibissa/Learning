package com.systemdesign.ratelimiter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.data.redis.repository.configuration.EnableRedisRepositories;
import org.springframework.scheduling.annotation.EnableAsync;

/**
 * Rate Limiter Service Application
 * 
 * Demonstrates various rate limiting algorithms:
 * - Token Bucket
 * - Sliding Window Log
 * - Sliding Window Counter
 * - Fixed Window Counter
 * 
 * Use cases:
 * - API rate limiting
 * - DDoS protection
 * - Resource throttling
 * - Fair usage enforcement
 */
@SpringBootApplication
@EnableCaching
@EnableRedisRepositories
@EnableAsync
public class RateLimiterApplication {
    
    public static void main(String[] args) {
        SpringApplication.run(RateLimiterApplication.class, args);
    }
}
