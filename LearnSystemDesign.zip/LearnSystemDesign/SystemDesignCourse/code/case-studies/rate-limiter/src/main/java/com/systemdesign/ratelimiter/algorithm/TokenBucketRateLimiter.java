package com.systemdesign.ratelimiter.algorithm;

import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.script.RedisScript;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.time.Instant;
import java.util.Collections;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

/**
 * Token Bucket Rate Limiter Implementation
 * 
 * Algorithm: Maintains a bucket with tokens that are refilled at a constant rate.
 * Each request consumes tokens. If no tokens available, request is denied.
 * 
 * Pros:
 * - Allows burst traffic up to bucket capacity
 * - Smooth token refill rate
 * - Memory efficient
 * 
 * Cons:
 * - Complex implementation
 * - Requires accurate timing
 */
@Component
public class TokenBucketRateLimiter implements RateLimiter {
    
    private final StringRedisTemplate redisTemplate;
    private final ConcurrentMap<String, LocalTokenBucket> localBuckets = new ConcurrentHashMap<>();
    
    public TokenBucketRateLimiter(StringRedisTemplate redisTemplate) {
        this.redisTemplate = redisTemplate;
    }
    
    @Override
    public RateLimitResult isAllowed(String key, RateLimitConfig config) {
        // For high-performance local buckets
        if (config.isLocal()) {
            return checkLocalBucket(key, config);
        }
        
        // For distributed buckets using Redis
        return checkDistributedBucket(key, config);
    }
    
    private RateLimitResult checkLocalBucket(String key, RateLimitConfig config) {
        LocalTokenBucket bucket = localBuckets.computeIfAbsent(key, 
            k -> new LocalTokenBucket(config.getCapacity(), config.getRefillRate()));
        
        synchronized (bucket) {
            bucket.refill();
            
            if (bucket.tryConsume(config.getTokensRequested())) {
                return RateLimitResult.allowed()
                    .withRemainingTokens(bucket.getAvailableTokens())
                    .withRefillTime(bucket.getNextRefillTime());
            } else {
                return RateLimitResult.denied()
                    .withRemainingTokens(bucket.getAvailableTokens())
                    .withRetryAfter(bucket.getTimeToNextToken());
            }
        }
    }
    
    private RateLimitResult checkDistributedBucket(String key, RateLimitConfig config) {
        String script = """
            local bucket_key = KEYS[1]
            local capacity = tonumber(ARGV[1])
            local refill_rate = tonumber(ARGV[2])
            local tokens_requested = tonumber(ARGV[3])
            local current_time = tonumber(ARGV[4])
            
            -- Get current bucket state
            local bucket_data = redis.call('HMGET', bucket_key, 'tokens', 'last_refill')
            local current_tokens = tonumber(bucket_data[1]) or capacity
            local last_refill = tonumber(bucket_data[2]) or current_time
            
            -- Calculate tokens to add based on time elapsed
            local time_elapsed = current_time - last_refill
            local tokens_to_add = math.floor(time_elapsed * refill_rate / 1000)
            
            -- Update token count (don't exceed capacity)
            current_tokens = math.min(capacity, current_tokens + tokens_to_add)
            
            -- Check if request can be satisfied
            if current_tokens >= tokens_requested then
                current_tokens = current_tokens - tokens_requested
                
                -- Update bucket state
                redis.call('HMSET', bucket_key, 
                    'tokens', current_tokens,
                    'last_refill', current_time)
                redis.call('EXPIRE', bucket_key, 3600) -- 1 hour TTL
                
                return {1, current_tokens, 0} -- allowed, remaining, retry_after
            else
                -- Update last refill time even if request denied
                redis.call('HMSET', bucket_key, 
                    'tokens', current_tokens,
                    'last_refill', current_time)
                redis.call('EXPIRE', bucket_key, 3600)
                
                -- Calculate retry after time
                local tokens_needed = tokens_requested - current_tokens
                local retry_after = math.ceil(tokens_needed * 1000 / refill_rate)
                
                return {0, current_tokens, retry_after} -- denied, remaining, retry_after
            end
            """;
        
        Long currentTime = Instant.now().toEpochMilli();
        
        @SuppressWarnings("unchecked")
        java.util.List<Long> result = (java.util.List<Long>) redisTemplate.execute(
            RedisScript.of(script, java.util.List.class),
            Collections.singletonList("rate_limit:token_bucket:" + key),
            String.valueOf(config.getCapacity()),
            String.valueOf(config.getRefillRate()),
            String.valueOf(config.getTokensRequested()),
            String.valueOf(currentTime)
        );
        
        boolean allowed = result.get(0) == 1;
        long remainingTokens = result.get(1);
        long retryAfter = result.get(2);
        
        if (allowed) {
            return RateLimitResult.allowed()
                .withRemainingTokens(remainingTokens)
                .withRefillTime(Duration.ofMillis(1000 / config.getRefillRate()));
        } else {
            return RateLimitResult.denied()
                .withRemainingTokens(remainingTokens)
                .withRetryAfter(Duration.ofMillis(retryAfter));
        }
    }
    
    /**
     * Local token bucket implementation for single-instance scenarios
     */
    private static class LocalTokenBucket {
        private final long capacity;
        private final double refillRate; // tokens per second
        private long availableTokens;
        private long lastRefillTime;
        
        public LocalTokenBucket(long capacity, double refillRate) {
            this.capacity = capacity;
            this.refillRate = refillRate;
            this.availableTokens = capacity;
            this.lastRefillTime = System.currentTimeMillis();
        }
        
        public void refill() {
            long now = System.currentTimeMillis();
            long timeElapsed = now - lastRefillTime;
            
            long tokensToAdd = (long) (timeElapsed * refillRate / 1000.0);
            
            if (tokensToAdd > 0) {
                availableTokens = Math.min(capacity, availableTokens + tokensToAdd);
                lastRefillTime = now;
            }
        }
        
        public boolean tryConsume(long tokens) {
            if (availableTokens >= tokens) {
                availableTokens -= tokens;
                return true;
            }
            return false;
        }
        
        public long getAvailableTokens() {
            return availableTokens;
        }
        
        public Duration getNextRefillTime() {
            if (availableTokens < capacity) {
                long timeToNextToken = (long) (1000.0 / refillRate);
                return Duration.ofMillis(timeToNextToken);
            }
            return Duration.ZERO;
        }
        
        public Duration getTimeToNextToken() {
            return Duration.ofMillis((long) (1000.0 / refillRate));
        }
    }
    
    @Override
    public String getAlgorithmName() {
        return "TOKEN_BUCKET";
    }
    
    @Override
    public RateLimitStats getStats(String key) {
        LocalTokenBucket bucket = localBuckets.get(key);
        if (bucket != null) {
            return RateLimitStats.builder()
                .algorithm(getAlgorithmName())
                .key(key)
                .currentTokens(bucket.getAvailableTokens())
                .capacity(bucket.capacity)
                .refillRate(bucket.refillRate)
                .lastRefillTime(Instant.ofEpochMilli(bucket.lastRefillTime))
                .build();
        }
        
        return RateLimitStats.builder()
            .algorithm(getAlgorithmName())
            .key(key)
            .build();
    }
    
    @Override
    public void reset(String key) {
        localBuckets.remove(key);
        redisTemplate.delete("rate_limit:token_bucket:" + key);
    }
}
