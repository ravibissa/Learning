package com.systemdesign.ratelimiter.algorithm;

/**
 * Rate Limiter interface for different algorithms
 */
public interface RateLimiter {
    
    /**
     * Check if a request is allowed based on the rate limit configuration
     * 
     * @param key Unique identifier for the rate limit (e.g., user ID, IP address)
     * @param config Rate limit configuration
     * @return Rate limit result
     */
    RateLimitResult isAllowed(String key, RateLimitConfig config);
    
    /**
     * Get the algorithm name
     * 
     * @return Algorithm name
     */
    String getAlgorithmName();
    
    /**
     * Get statistics for a specific key
     * 
     * @param key Rate limit key
     * @return Statistics
     */
    RateLimitStats getStats(String key);
    
    /**
     * Reset rate limit for a specific key
     * 
     * @param key Rate limit key
     */
    void reset(String key);
}
