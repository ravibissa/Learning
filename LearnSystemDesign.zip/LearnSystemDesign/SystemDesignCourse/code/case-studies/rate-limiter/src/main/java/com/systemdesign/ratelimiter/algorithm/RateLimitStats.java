package com.systemdesign.ratelimiter.algorithm;

import java.time.Instant;

/**
 * Statistics for rate limiting
 */
public class RateLimitStats {
    
    private final String algorithm;
    private final String key;
    private final long currentTokens;
    private final long capacity;
    private final double refillRate;
    private final Instant lastRefillTime;
    private final long totalRequests;
    private final long allowedRequests;
    private final long deniedRequests;
    private final double allowanceRate;
    
    private RateLimitStats(Builder builder) {
        this.algorithm = builder.algorithm;
        this.key = builder.key;
        this.currentTokens = builder.currentTokens;
        this.capacity = builder.capacity;
        this.refillRate = builder.refillRate;
        this.lastRefillTime = builder.lastRefillTime;
        this.totalRequests = builder.totalRequests;
        this.allowedRequests = builder.allowedRequests;
        this.deniedRequests = builder.deniedRequests;
        this.allowanceRate = builder.totalRequests > 0 ? 
            (double) builder.allowedRequests / builder.totalRequests : 0.0;
    }
    
    public static Builder builder() {
        return new Builder();
    }
    
    public String getAlgorithm() {
        return algorithm;
    }
    
    public String getKey() {
        return key;
    }
    
    public long getCurrentTokens() {
        return currentTokens;
    }
    
    public long getCapacity() {
        return capacity;
    }
    
    public double getRefillRate() {
        return refillRate;
    }
    
    public Instant getLastRefillTime() {
        return lastRefillTime;
    }
    
    public long getTotalRequests() {
        return totalRequests;
    }
    
    public long getAllowedRequests() {
        return allowedRequests;
    }
    
    public long getDeniedRequests() {
        return deniedRequests;
    }
    
    public double getAllowanceRate() {
        return allowanceRate;
    }
    
    public static class Builder {
        private String algorithm;
        private String key;
        private long currentTokens = 0;
        private long capacity = 0;
        private double refillRate = 0.0;
        private Instant lastRefillTime;
        private long totalRequests = 0;
        private long allowedRequests = 0;
        private long deniedRequests = 0;
        
        public Builder algorithm(String algorithm) {
            this.algorithm = algorithm;
            return this;
        }
        
        public Builder key(String key) {
            this.key = key;
            return this;
        }
        
        public Builder currentTokens(long currentTokens) {
            this.currentTokens = currentTokens;
            return this;
        }
        
        public Builder capacity(long capacity) {
            this.capacity = capacity;
            return this;
        }
        
        public Builder refillRate(double refillRate) {
            this.refillRate = refillRate;
            return this;
        }
        
        public Builder lastRefillTime(Instant lastRefillTime) {
            this.lastRefillTime = lastRefillTime;
            return this;
        }
        
        public Builder totalRequests(long totalRequests) {
            this.totalRequests = totalRequests;
            return this;
        }
        
        public Builder allowedRequests(long allowedRequests) {
            this.allowedRequests = allowedRequests;
            return this;
        }
        
        public Builder deniedRequests(long deniedRequests) {
            this.deniedRequests = deniedRequests;
            return this;
        }
        
        public RateLimitStats build() {
            return new RateLimitStats(this);
        }
    }
    
    @Override
    public String toString() {
        return String.format(
            "RateLimitStats{algorithm='%s', key='%s', currentTokens=%d, capacity=%d, " +
            "refillRate=%.2f, lastRefillTime=%s, totalRequests=%d, allowedRequests=%d, " +
            "deniedRequests=%d, allowanceRate=%.2f%%}",
            algorithm, key, currentTokens, capacity, refillRate, lastRefillTime,
            totalRequests, allowedRequests, deniedRequests, allowanceRate * 100
        );
    }
}
