package com.systemdesign.chat.websocket;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.systemdesign.chat.model.ChatMessage;
import com.systemdesign.chat.model.UserSession;
import com.systemdesign.chat.service.ChatService;
import com.systemdesign.chat.service.PresenceService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.*;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import java.io.IOException;
import java.time.Instant;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * WebSocket handler for real-time chat functionality
 */
@Component
public class ChatWebSocketHandler extends TextWebSocketHandler {
    
    private static final Logger log = LoggerFactory.getLogger(ChatWebSocketHandler.class);
    
    private final Map<String, WebSocketSession> sessions = new ConcurrentHashMap<>();
    private final Map<String, String> sessionToUser = new ConcurrentHashMap<>();
    
    @Autowired
    private ChatService chatService;
    
    @Autowired
    private PresenceService presenceService;
    
    @Autowired
    private ObjectMapper objectMapper;
    
    @Override
    public void afterConnectionEstablished(WebSocketSession session) throws Exception {
        log.info("WebSocket connection established: {}", session.getId());
        
        // Extract user ID from session attributes or headers
        String userId = extractUserId(session);
        if (userId != null) {
            sessions.put(session.getId(), session);
            sessionToUser.put(session.getId(), userId);
            
            // Update user presence
            presenceService.setUserOnline(userId);
            
            // Send connection acknowledgment
            sendMessage(session, new ConnectionMessage("CONNECTED", "Successfully connected to chat"));
            
            // Send recent messages for user's rooms
            chatService.sendRecentMessages(userId, session);
            
        } else {
            log.warn("No user ID found in session, closing connection");
            session.close(CloseStatus.BAD_DATA.withReason("Authentication required"));
        }
    }
    
    @Override
    public void afterConnectionClosed(WebSocketSession session, CloseStatus status) throws Exception {
        log.info("WebSocket connection closed: {} with status: {}", session.getId(), status);
        
        String userId = sessionToUser.remove(session.getId());
        sessions.remove(session.getId());
        
        if (userId != null) {
            // Update user presence
            presenceService.setUserOffline(userId);
            
            // Notify other users in the same rooms
            chatService.notifyUserDisconnected(userId);
        }
    }
    
    @Override
    protected void handleTextMessage(WebSocketSession session, TextMessage message) throws Exception {
        try {
            String payload = message.getPayload();
            log.debug("Received message: {}", payload);
            
            // Parse incoming message
            Map<String, Object> messageData = objectMapper.readValue(payload, Map.class);
            String messageType = (String) messageData.get("type");
            
            String userId = sessionToUser.get(session.getId());
            if (userId == null) {
                log.warn("No user ID found for session: {}", session.getId());
                return;
            }
            
            switch (messageType) {
                case "CHAT_MESSAGE":
                    handleChatMessage(userId, messageData, session);
                    break;
                    
                case "TYPING_START":
                    handleTypingStart(userId, messageData);
                    break;
                    
                case "TYPING_STOP":
                    handleTypingStop(userId, messageData);
                    break;
                    
                case "JOIN_ROOM":
                    handleJoinRoom(userId, messageData, session);
                    break;
                    
                case "LEAVE_ROOM":
                    handleLeaveRoom(userId, messageData);
                    break;
                    
                case "GET_ROOM_MEMBERS":
                    handleGetRoomMembers(userId, messageData, session);
                    break;
                    
                case "MARK_AS_READ":
                    handleMarkAsRead(userId, messageData);
                    break;
                    
                default:
                    log.warn("Unknown message type: {}", messageType);
                    sendError(session, "Unknown message type: " + messageType);
            }
            
        } catch (Exception e) {
            log.error("Error handling WebSocket message", e);
            sendError(session, "Error processing message: " + e.getMessage());
        }
    }
    
    @Override
    public void handleTransportError(WebSocketSession session, Throwable exception) throws Exception {
        log.error("WebSocket transport error for session: {}", session.getId(), exception);
        
        String userId = sessionToUser.get(session.getId());
        if (userId != null) {
            presenceService.setUserOffline(userId);
        }
        
        sessions.remove(session.getId());
        sessionToUser.remove(session.getId());
    }
    
    private void handleChatMessage(String userId, Map<String, Object> messageData, WebSocketSession session) {
        try {
            String roomId = (String) messageData.get("roomId");
            String content = (String) messageData.get("content");
            String messageId = (String) messageData.get("messageId"); // For idempotency
            
            if (roomId == null || content == null) {
                sendError(session, "Room ID and content are required");
                return;
            }
            
            // Create chat message
            ChatMessage chatMessage = ChatMessage.builder()
                .id(messageId)
                .roomId(roomId)
                .senderId(userId)
                .content(content)
                .timestamp(Instant.now())
                .messageType("TEXT")
                .build();
            
            // Process and broadcast message
            ChatMessage savedMessage = chatService.sendMessage(chatMessage);
            
            // Send confirmation to sender
            sendMessage(session, MessageAck.builder()
                .type("MESSAGE_ACK")
                .messageId(savedMessage.getId())
                .timestamp(savedMessage.getTimestamp())
                .build());
            
        } catch (Exception e) {
            log.error("Error handling chat message", e);
            sendError(session, "Failed to send message: " + e.getMessage());
        }
    }
    
    private void handleTypingStart(String userId, Map<String, Object> messageData) {
        String roomId = (String) messageData.get("roomId");
        if (roomId != null) {
            presenceService.setUserTyping(userId, roomId);
            
            // Broadcast typing indicator to other users in the room
            broadcastToRoom(roomId, TypingIndicator.builder()
                .type("TYPING_START")
                .userId(userId)
                .roomId(roomId)
                .timestamp(Instant.now())
                .build(), userId);
        }
    }
    
    private void handleTypingStop(String userId, Map<String, Object> messageData) {
        String roomId = (String) messageData.get("roomId");
        if (roomId != null) {
            presenceService.setUserStoppedTyping(userId, roomId);
            
            // Broadcast typing stop to other users in the room
            broadcastToRoom(roomId, TypingIndicator.builder()
                .type("TYPING_STOP")
                .userId(userId)
                .roomId(roomId)
                .timestamp(Instant.now())
                .build(), userId);
        }
    }
    
    private void handleJoinRoom(String userId, Map<String, Object> messageData, WebSocketSession session) {
        String roomId = (String) messageData.get("roomId");
        if (roomId != null) {
            boolean success = chatService.joinRoom(userId, roomId);
            
            if (success) {
                sendMessage(session, RoomJoinedMessage.builder()
                    .type("ROOM_JOINED")
                    .roomId(roomId)
                    .timestamp(Instant.now())
                    .build());
                
                // Notify other room members
                broadcastToRoom(roomId, UserJoinedMessage.builder()
                    .type("USER_JOINED")
                    .userId(userId)
                    .roomId(roomId)
                    .timestamp(Instant.now())
                    .build(), userId);
                    
            } else {
                sendError(session, "Failed to join room: " + roomId);
            }
        }
    }
    
    private void handleLeaveRoom(String userId, Map<String, Object> messageData) {
        String roomId = (String) messageData.get("roomId");
        if (roomId != null) {
            chatService.leaveRoom(userId, roomId);
            
            // Notify other room members
            broadcastToRoom(roomId, UserLeftMessage.builder()
                .type("USER_LEFT")
                .userId(userId)
                .roomId(roomId)
                .timestamp(Instant.now())
                .build(), userId);
        }
    }
    
    private void handleGetRoomMembers(String userId, Map<String, Object> messageData, WebSocketSession session) {
        String roomId = (String) messageData.get("roomId");
        if (roomId != null) {
            var members = chatService.getRoomMembers(roomId);
            
            sendMessage(session, RoomMembersMessage.builder()
                .type("ROOM_MEMBERS")
                .roomId(roomId)
                .members(members)
                .timestamp(Instant.now())
                .build());
        }
    }
    
    private void handleMarkAsRead(String userId, Map<String, Object> messageData) {
        String messageId = (String) messageData.get("messageId");
        String roomId = (String) messageData.get("roomId");
        
        if (messageId != null && roomId != null) {
            chatService.markMessageAsRead(userId, messageId, roomId);
        }
    }
    
    private String extractUserId(WebSocketSession session) {
        // Extract from query parameters or headers
        String query = session.getUri().getQuery();
        if (query != null && query.contains("userId=")) {
            return query.split("userId=")[1].split("&")[0];
        }
        
        // Alternative: extract from JWT token in headers
        return session.getHandshakeHeaders().getFirst("X-User-ID");
    }
    
    private void sendMessage(WebSocketSession session, Object message) {
        try {
            if (session.isOpen()) {
                String json = objectMapper.writeValueAsString(message);
                session.sendMessage(new TextMessage(json));
            }
        } catch (IOException e) {
            log.error("Error sending message to session: {}", session.getId(), e);
        }
    }
    
    private void sendError(WebSocketSession session, String error) {
        sendMessage(session, ErrorMessage.builder()
            .type("ERROR")
            .message(error)
            .timestamp(Instant.now())
            .build());
    }
    
    private void broadcastToRoom(String roomId, Object message, String excludeUserId) {
        // Get all users in the room and send message to their active sessions
        var roomMembers = chatService.getRoomMembers(roomId);
        
        for (var member : roomMembers) {
            if (!member.getUserId().equals(excludeUserId)) {
                // Find active session for this user
                sessionToUser.entrySet().stream()
                    .filter(entry -> entry.getValue().equals(member.getUserId()))
                    .forEach(entry -> {
                        WebSocketSession session = sessions.get(entry.getKey());
                        if (session != null) {
                            sendMessage(session, message);
                        }
                    });
            }
        }
    }
    
    // Message DTOs
    public record ConnectionMessage(String type, String message) {}
    
    public static class MessageAck {
        private String type;
        private String messageId;
        private Instant timestamp;
        
        public static Builder builder() { return new Builder(); }
        
        public static class Builder {
            private MessageAck ack = new MessageAck();
            public Builder type(String type) { ack.type = type; return this; }
            public Builder messageId(String messageId) { ack.messageId = messageId; return this; }
            public Builder timestamp(Instant timestamp) { ack.timestamp = timestamp; return this; }
            public MessageAck build() { return ack; }
        }
        
        public String getType() { return type; }
        public String getMessageId() { return messageId; }
        public Instant getTimestamp() { return timestamp; }
    }
    
    public static class TypingIndicator {
        private String type;
        private String userId;
        private String roomId;
        private Instant timestamp;
        
        public static Builder builder() { return new Builder(); }
        
        public static class Builder {
            private TypingIndicator indicator = new TypingIndicator();
            public Builder type(String type) { indicator.type = type; return this; }
            public Builder userId(String userId) { indicator.userId = userId; return this; }
            public Builder roomId(String roomId) { indicator.roomId = roomId; return this; }
            public Builder timestamp(Instant timestamp) { indicator.timestamp = timestamp; return this; }
            public TypingIndicator build() { return indicator; }
        }
        
        public String getType() { return type; }
        public String getUserId() { return userId; }
        public String getRoomId() { return roomId; }
        public Instant getTimestamp() { return timestamp; }
    }
    
    public static class RoomJoinedMessage {
        private String type;
        private String roomId;
        private Instant timestamp;
        
        public static Builder builder() { return new Builder(); }
        
        public static class Builder {
            private RoomJoinedMessage message = new RoomJoinedMessage();
            public Builder type(String type) { message.type = type; return this; }
            public Builder roomId(String roomId) { message.roomId = roomId; return this; }
            public Builder timestamp(Instant timestamp) { message.timestamp = timestamp; return this; }
            public RoomJoinedMessage build() { return message; }
        }
        
        public String getType() { return type; }
        public String getRoomId() { return roomId; }
        public Instant getTimestamp() { return timestamp; }
    }
    
    public static class UserJoinedMessage {
        private String type;
        private String userId;
        private String roomId;
        private Instant timestamp;
        
        public static Builder builder() { return new Builder(); }
        
        public static class Builder {
            private UserJoinedMessage message = new UserJoinedMessage();
            public Builder type(String type) { message.type = type; return this; }
            public Builder userId(String userId) { message.userId = userId; return this; }
            public Builder roomId(String roomId) { message.roomId = roomId; return this; }
            public Builder timestamp(Instant timestamp) { message.timestamp = timestamp; return this; }
            public UserJoinedMessage build() { return message; }
        }
        
        public String getType() { return type; }
        public String getUserId() { return userId; }
        public String getRoomId() { return roomId; }
        public Instant getTimestamp() { return timestamp; }
    }
    
    public static class UserLeftMessage {
        private String type;
        private String userId;
        private String roomId;
        private Instant timestamp;
        
        public static Builder builder() { return new Builder(); }
        
        public static class Builder {
            private UserLeftMessage message = new UserLeftMessage();
            public Builder type(String type) { message.type = type; return this; }
            public Builder userId(String userId) { message.userId = userId; return this; }
            public Builder roomId(String roomId) { message.roomId = roomId; return this; }
            public Builder timestamp(Instant timestamp) { message.timestamp = timestamp; return this; }
            public UserLeftMessage build() { return message; }
        }
        
        public String getType() { return type; }
        public String getUserId() { return userId; }
        public String getRoomId() { return roomId; }
        public Instant getTimestamp() { return timestamp; }
    }
    
    public static class RoomMembersMessage {
        private String type;
        private String roomId;
        private java.util.List<Object> members;
        private Instant timestamp;
        
        public static Builder builder() { return new Builder(); }
        
        public static class Builder {
            private RoomMembersMessage message = new RoomMembersMessage();
            public Builder type(String type) { message.type = type; return this; }
            public Builder roomId(String roomId) { message.roomId = roomId; return this; }
            public Builder members(java.util.List<Object> members) { message.members = members; return this; }
            public Builder timestamp(Instant timestamp) { message.timestamp = timestamp; return this; }
            public RoomMembersMessage build() { return message; }
        }
        
        public String getType() { return type; }
        public String getRoomId() { return roomId; }
        public java.util.List<Object> getMembers() { return members; }
        public Instant getTimestamp() { return timestamp; }
    }
    
    public static class ErrorMessage {
        private String type;
        private String message;
        private Instant timestamp;
        
        public static Builder builder() { return new Builder(); }
        
        public static class Builder {
            private ErrorMessage error = new ErrorMessage();
            public Builder type(String type) { error.type = type; return this; }
            public Builder message(String message) { error.message = message; return this; }
            public Builder timestamp(Instant timestamp) { error.timestamp = timestamp; return this; }
            public ErrorMessage build() { return error; }
        }
        
        public String getType() { return type; }
        public String getMessage() { return message; }
        public Instant getTimestamp() { return timestamp; }
    }
}
