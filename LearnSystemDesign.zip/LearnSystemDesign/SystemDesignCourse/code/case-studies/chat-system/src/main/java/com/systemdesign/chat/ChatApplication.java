package com.systemdesign.chat;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.web.socket.config.annotation.EnableWebSocket;

/**
 * Real-time Chat System Application
 * 
 * Demonstrates:
 * - WebSocket communication for real-time messaging
 * - Message persistence and delivery guarantees
 * - Presence tracking and typing indicators
 * - Group chat with permissions
 * - Message history and search
 * - Scalable architecture with Redis pub/sub
 * 
 * Key patterns:
 * - Event-driven messaging
 * - CQRS for read/write separation
 * - Eventual consistency
 * - Connection pooling
 * - Circuit breaker for external services
 */
@SpringBootApplication
@EnableWebSocket
@EnableJpaRepositories
@EnableCaching
@EnableAsync
public class ChatApplication {
    
    public static void main(String[] args) {
        SpringApplication.run(ChatApplication.class, args);
    }
}
