# Capstone Project: Multi-Tenant Notification Platform

## 🎯 Project Overview

Build a production-ready, multi-tenant notification platform that demonstrates mastery of all system design concepts learned throughout the course. This platform will handle millions of notifications across multiple channels with advanced features like retry mechanisms, dead letter queues, A/B testing, and global deployment.

## 📋 Project Requirements

### Core Features
- ✅ **Multi-Tenant Architecture** - Complete tenant isolation
- ✅ **Multi-Channel Delivery** - Email, SMS, Push, Slack, Teams, Webhooks
- ✅ **Template Management** - Dynamic templates with variables
- ✅ **Retry Mechanisms** - Exponential backoff with circuit breakers
- ✅ **Dead Letter Queues** - Failed message handling and analysis
- ✅ **Real-Time Analytics** - Delivery metrics and reporting
- ✅ **A/B Testing Framework** - Template and timing optimization
- ✅ **Global Deployment** - Multi-region with data residency

### Advanced Features
- ✅ **Smart Routing** - Optimal channel selection based on user preferences
- ✅ **Rate Limiting** - Per-tenant and global rate limits
- ✅ **Content Personalization** - ML-driven content optimization
- ✅ **Delivery Scheduling** - Time zone aware scheduling
- ✅ **Compliance Framework** - GDPR, CCPA, opt-out management
- ✅ **Audit Logging** - Complete audit trail for compliance

## 🏗️ System Architecture

```mermaid
graph TB
    subgraph "Client Applications"
        WebApp[Web Application]
        MobileApp[Mobile App]
        API[API Clients]
    end
    
    subgraph "API Gateway Layer"
        Gateway[API Gateway<br/>Kong + OAuth2]
        RateLimit[Rate Limiter<br/>Redis]
        WAF[Web Application Firewall]
    end
    
    subgraph "Core Services"
        NotificationAPI[Notification API<br/>Spring Boot]
        TemplateService[Template Service<br/>Spring Boot]
        DeliveryService[Delivery Service<br/>Spring Boot]
        AnalyticsService[Analytics Service<br/>Spring Boot]
        TenantService[Tenant Service<br/>Spring Boot]
    end
    
    subgraph "Processing Layer"
        EventProcessor[Event Processor<br/>Kafka Streams]
        DeliveryWorkers[Delivery Workers<br/>Virtual Threads]
        RetryProcessor[Retry Processor<br/>Scheduled Jobs]
        AnalyticsProcessor[Analytics Processor<br/>Real-time ETL]
    end
    
    subgraph "Message Queue"
        Kafka[Apache Kafka<br/>Multi-partition]
        DLQ[Dead Letter Queue<br/>Failed Messages]
        PriorityQueue[Priority Queue<br/>Urgent Messages]
    end
    
    subgraph "External Channels"
        EmailProvider[Email<br/>SendGrid/SES]
        SMSProvider[SMS<br/>Twilio]
        PushProvider[Push<br/>FCM/APNS]
        SlackAPI[Slack API]
        TeamsAPI[Microsoft Teams]
        Webhooks[Custom Webhooks]
    end
    
    subgraph "Data Layer"
        PostgresMain[(PostgreSQL<br/>Main Database)]
        PostgresAnalytics[(PostgreSQL<br/>Analytics DB)]
        Redis[(Redis<br/>Cache + Sessions)]
        ClickHouse[(ClickHouse<br/>Time Series)]
        S3[(S3<br/>Templates + Logs)]
    end
    
    subgraph "Monitoring & Observability"
        Prometheus[Prometheus<br/>Metrics]
        Grafana[Grafana<br/>Dashboards]
        ELK[ELK Stack<br/>Logs]
        Jaeger[Jaeger<br/>Tracing]
        AlertManager[Alert Manager<br/>Incidents]
    end
    
    %% Connections
    WebApp --> Gateway
    MobileApp --> Gateway
    API --> Gateway
    
    Gateway --> RateLimit
    Gateway --> NotificationAPI
    Gateway --> TemplateService
    Gateway --> AnalyticsService
    
    NotificationAPI --> Kafka
    DeliveryService --> Kafka
    Kafka --> EventProcessor
    EventProcessor --> DeliveryWorkers
    
    DeliveryWorkers --> EmailProvider
    DeliveryWorkers --> SMSProvider
    DeliveryWorkers --> PushProvider
    DeliveryWorkers --> SlackAPI
    DeliveryWorkers --> TeamsAPI
    DeliveryWorkers --> Webhooks
    
    DeliveryWorkers --> DLQ
    RetryProcessor --> DLQ
    
    NotificationAPI --> PostgresMain
    TemplateService --> PostgresMain
    AnalyticsService --> PostgresAnalytics
    AnalyticsProcessor --> ClickHouse
    
    Gateway --> Redis
    DeliveryService --> Redis
    
    TemplateService --> S3
    
    %% Monitoring connections
    NotificationAPI --> Prometheus
    DeliveryService --> Prometheus
    Kafka --> Prometheus
    PostgresMain --> Prometheus
```

## 🗄️ Data Model

### Core Entities
```sql
-- Tenant management
CREATE TABLE tenants (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    slug VARCHAR(100) UNIQUE NOT NULL,
    plan_type VARCHAR(50) NOT NULL DEFAULT 'free',
    rate_limit_per_hour INTEGER DEFAULT 1000,
    created_at TIMESTAMP DEFAULT NOW(),
    is_active BOOLEAN DEFAULT true,
    settings JSONB DEFAULT '{}'
);

-- Notification templates
CREATE TABLE notification_templates (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID REFERENCES tenants(id),
    name VARCHAR(255) NOT NULL,
    channel VARCHAR(50) NOT NULL, -- email, sms, push, slack, teams, webhook
    subject_template TEXT,
    body_template TEXT NOT NULL,
    variables JSONB DEFAULT '[]',
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    version INTEGER DEFAULT 1,
    
    UNIQUE(tenant_id, name, version)
);

-- Notification requests
CREATE TABLE notification_requests (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID REFERENCES tenants(id),
    template_id UUID REFERENCES notification_templates(id),
    recipient JSONB NOT NULL, -- {email, phone, push_token, etc}
    variables JSONB DEFAULT '{}',
    channel VARCHAR(50) NOT NULL,
    priority VARCHAR(20) DEFAULT 'normal', -- urgent, high, normal, low
    scheduled_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW(),
    status VARCHAR(50) DEFAULT 'pending'
);

-- Delivery attempts
CREATE TABLE delivery_attempts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    notification_request_id UUID REFERENCES notification_requests(id),
    attempt_number INTEGER NOT NULL,
    channel VARCHAR(50) NOT NULL,
    provider VARCHAR(100),
    status VARCHAR(50) NOT NULL, -- sent, delivered, failed, bounced
    error_message TEXT,
    external_id VARCHAR(255),
    attempted_at TIMESTAMP DEFAULT NOW(),
    delivered_at TIMESTAMP,
    cost_cents INTEGER DEFAULT 0,
    
    INDEX idx_notification_request_id (notification_request_id),
    INDEX idx_attempted_at (attempted_at),
    INDEX idx_status (status)
);

-- A/B test campaigns
CREATE TABLE ab_test_campaigns (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID REFERENCES tenants(id),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    template_a_id UUID REFERENCES notification_templates(id),
    template_b_id UUID REFERENCES notification_templates(id),
    traffic_split_percent INTEGER DEFAULT 50,
    start_date TIMESTAMP NOT NULL,
    end_date TIMESTAMP,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW()
);

-- User preferences
CREATE TABLE user_preferences (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID REFERENCES tenants(id),
    user_identifier VARCHAR(255) NOT NULL,
    channel VARCHAR(50) NOT NULL,
    is_enabled BOOLEAN DEFAULT true,
    time_zone VARCHAR(100) DEFAULT 'UTC',
    quiet_hours_start TIME,
    quiet_hours_end TIME,
    frequency_limit_per_day INTEGER,
    updated_at TIMESTAMP DEFAULT NOW(),
    
    UNIQUE(tenant_id, user_identifier, channel)
);

-- Analytics tables (ClickHouse)
CREATE TABLE notification_events (
    id UUID,
    tenant_id UUID,
    notification_request_id UUID,
    event_type String, -- sent, delivered, opened, clicked, bounced, failed
    channel String,
    provider String,
    recipient_hash String,
    country String,
    device_type String,
    timestamp DateTime,
    properties String -- JSON
) ENGINE = MergeTree()
ORDER BY timestamp
PARTITION BY toYYYYMM(timestamp);
```

## 🚀 Core Implementation

### Multi-Tenant Notification Service

```java
@RestController
@RequestMapping("/api/v1/notifications")
@Validated
public class NotificationController {
    
    private final NotificationService notificationService;
    private final TenantContext tenantContext;
    
    @PostMapping("/send")
    public ResponseEntity<NotificationResponse> sendNotification(
            @Valid @RequestBody SendNotificationRequest request) {
        
        UUID tenantId = tenantContext.getCurrentTenantId();
        
        NotificationRequest notification = NotificationRequest.builder()
            .tenantId(tenantId)
            .templateId(request.templateId())
            .recipient(request.recipient())
            .variables(request.variables())
            .channel(request.channel())
            .priority(request.priority())
            .scheduledAt(request.scheduledAt())
            .build();
        
        NotificationResponse response = notificationService.sendNotification(notification);
        
        return ResponseEntity.accepted().body(response);
    }
    
    @PostMapping("/bulk")
    public ResponseEntity<BulkNotificationResponse> sendBulkNotifications(
            @Valid @RequestBody BulkNotificationRequest request) {
        
        UUID tenantId = tenantContext.getCurrentTenantId();
        
        BulkNotificationResponse response = notificationService.sendBulkNotifications(
            tenantId, request
        );
        
        return ResponseEntity.accepted().body(response);
    }
    
    @GetMapping("/{notificationId}/status")
    public ResponseEntity<NotificationStatus> getNotificationStatus(
            @PathVariable UUID notificationId) {
        
        UUID tenantId = tenantContext.getCurrentTenantId();
        NotificationStatus status = notificationService.getNotificationStatus(
            tenantId, notificationId
        );
        
        return ResponseEntity.ok(status);
    }
}

@Service
@Transactional
public class NotificationService {
    
    private final NotificationRepository notificationRepository;
    private final TemplateService templateService;
    private final ABTestService abTestService;
    private final RateLimitService rateLimitService;
    private final KafkaTemplate<String, Object> kafkaTemplate;
    private final TenantService tenantService;
    
    public NotificationResponse sendNotification(NotificationRequest request) {
        // 1. Validate tenant and rate limits
        Tenant tenant = tenantService.getTenant(request.getTenantId());
        rateLimitService.checkRateLimit(tenant);
        
        // 2. Resolve template (with A/B testing)
        NotificationTemplate template = resolveTemplate(request);
        
        // 3. Validate recipient and preferences
        validateRecipient(request, template);
        
        // 4. Create notification record
        Notification notification = createNotification(request, template);
        
        // 5. Send to processing queue
        NotificationEvent event = NotificationEvent.builder()
            .notificationId(notification.getId())
            .tenantId(request.getTenantId())
            .channel(template.getChannel())
            .priority(request.getPriority())
            .scheduledAt(request.getScheduledAt())
            .build();
            
        kafkaTemplate.send("notification-requests", event);
        
        return NotificationResponse.builder()
            .notificationId(notification.getId())
            .status("queued")
            .estimatedDelivery(calculateEstimatedDelivery(request))
            .build();
    }
    
    private NotificationTemplate resolveTemplate(NotificationRequest request) {
        // Check if template is part of A/B test
        Optional<ABTestCampaign> activeTest = abTestService
            .getActiveTest(request.getTenantId(), request.getTemplateId());
        
        if (activeTest.isPresent()) {
            return abTestService.selectTemplate(activeTest.get(), request);
        }
        
        return templateService.getTemplate(request.getTenantId(), request.getTemplateId());
    }
    
    private void validateRecipient(NotificationRequest request, NotificationTemplate template) {
        // Check user preferences
        UserPreferences prefs = userPreferencesService.getPreferences(
            request.getTenantId(),
            request.getRecipient().getUserId(),
            template.getChannel()
        );
        
        if (!prefs.isEnabled()) {
            throw new NotificationBlockedException("User has opted out of " + template.getChannel());
        }
        
        // Check quiet hours
        if (isInQuietHours(prefs, request.getScheduledAt())) {
            // Reschedule outside quiet hours
            request.setScheduledAt(calculateNextAllowedTime(prefs));
        }
        
        // Check frequency limits
        if (exceedsFrequencyLimit(prefs, request)) {
            throw new FrequencyLimitExceededException("Daily limit exceeded");
        }
    }
}
```

### Delivery Engine with Virtual Threads

```java
@Component
public class DeliveryEngine {
    
    private final List<ChannelProvider> channelProviders;
    private final CircuitBreakerRegistry circuitBreakerRegistry;
    private final RetryRegistry retryRegistry;
    private final ExecutorService virtualThreadExecutor;
    
    @PostConstruct
    public void initializeVirtualThreads() {
        // Java 21 Virtual Threads for massive concurrency
        this.virtualThreadExecutor = Executors.newVirtualThreadPerTaskExecutor();
    }
    
    @KafkaListener(topics = "notification-requests", concurrency = "10")
    public void processNotification(NotificationEvent event) {
        // Submit to virtual thread for processing
        virtualThreadExecutor.submit(() -> {
            try {
                deliverNotification(event);
            } catch (Exception e) {
                log.error("Failed to process notification: {}", event.getNotificationId(), e);
                handleDeliveryFailure(event, e);
            }
        });
    }
    
    private void deliverNotification(NotificationEvent event) {
        Notification notification = getNotification(event.getNotificationId());
        ChannelProvider provider = getChannelProvider(notification.getChannel());
        
        // Create circuit breaker for this provider
        CircuitBreaker circuitBreaker = circuitBreakerRegistry
            .circuitBreaker(provider.getName());
        
        // Create retry mechanism
        Retry retry = retryRegistry.retry(provider.getName());
        
        // Combine circuit breaker and retry
        Supplier<DeliveryResult> decoratedSupplier = CircuitBreaker
            .decorateSupplier(circuitBreaker, () -> 
                provider.deliver(notification)
            );
        
        decoratedSupplier = Retry.decorateSupplier(retry, decoratedSupplier);
        
        try {
            DeliveryResult result = decoratedSupplier.get();
            handleDeliverySuccess(notification, result);
        } catch (Exception e) {
            handleDeliveryFailure(event, e);
        }
    }
    
    private void handleDeliverySuccess(Notification notification, DeliveryResult result) {
        // Update delivery status
        deliveryAttemptService.recordSuccess(notification.getId(), result);
        
        // Send analytics event
        analyticsService.recordDeliveryEvent(notification.getId(), "delivered", result);
        
        // Update notification status
        notificationService.updateStatus(notification.getId(), "delivered");
    }
    
    private void handleDeliveryFailure(NotificationEvent event, Exception error) {
        // Record failed attempt
        deliveryAttemptService.recordFailure(event.getNotificationId(), error);
        
        // Check if should retry
        if (shouldRetry(event, error)) {
            scheduleRetry(event);
        } else {
            // Send to dead letter queue
            sendToDeadLetterQueue(event, error);
        }
    }
    
    private boolean shouldRetry(NotificationEvent event, Exception error) {
        // Don't retry for certain errors
        if (error instanceof InvalidRecipientException ||
            error instanceof UnsubscribedException) {
            return false;
        }
        
        // Check attempt count
        int attemptCount = deliveryAttemptService.getAttemptCount(event.getNotificationId());
        return attemptCount < getMaxRetries(event.getPriority());
    }
    
    private void scheduleRetry(NotificationEvent event) {
        int attemptCount = deliveryAttemptService.getAttemptCount(event.getNotificationId());
        
        // Exponential backoff: 2^attempt * 30 seconds
        Duration delay = Duration.ofSeconds(30 * (long) Math.pow(2, attemptCount));
        
        // Add jitter to prevent thundering herd
        Duration jitter = Duration.ofSeconds(ThreadLocalRandom.current().nextInt(0, 30));
        Duration totalDelay = delay.plus(jitter);
        
        // Schedule retry
        retryScheduler.schedule(event, Instant.now().plus(totalDelay));
    }
    
    private void sendToDeadLetterQueue(NotificationEvent event, Exception error) {
        DeadLetterEvent dlqEvent = DeadLetterEvent.builder()
            .originalEvent(event)
            .error(error.getMessage())
            .stackTrace(getStackTrace(error))
            .failedAt(Instant.now())
            .build();
            
        kafkaTemplate.send("notification-dlq", dlqEvent);
        
        // Update notification status
        notificationService.updateStatus(event.getNotificationId(), "failed");
    }
}
```

### Channel Providers

```java
public interface ChannelProvider {
    String getName();
    boolean supports(String channel);
    DeliveryResult deliver(Notification notification) throws DeliveryException;
    DeliveryStatus getDeliveryStatus(String externalId);
}

@Component
public class EmailChannelProvider implements ChannelProvider {
    
    private final SendGridClient sendGridClient;
    private final SESClient sesClient;
    private final LoadBalancer providerLoadBalancer;
    
    @Override
    public DeliveryResult deliver(Notification notification) throws DeliveryException {
        EmailProvider provider = providerLoadBalancer.selectProvider();
        
        EmailMessage email = EmailMessage.builder()
            .to(notification.getRecipient().getEmail())
            .subject(notification.getSubject())
            .body(notification.getBody())
            .template(notification.getTemplate())
            .variables(notification.getVariables())
            .build();
        
        return switch (provider.getType()) {
            case SENDGRID -> deliverViaSendGrid(email);
            case SES -> deliverViaSES(email);
            case MAILGUN -> deliverViaMailgun(email);
        };
    }
    
    private DeliveryResult deliverViaSendGrid(EmailMessage email) {
        try {
            SendGridResponse response = sendGridClient.send(email);
            
            return DeliveryResult.builder()
                .success(true)
                .externalId(response.getMessageId())
                .provider("sendgrid")
                .deliveredAt(Instant.now())
                .cost(calculateCost("sendgrid"))
                .build();
                
        } catch (SendGridException e) {
            throw new DeliveryException("SendGrid delivery failed", e);
        }
    }
}

@Component
public class SMSChannelProvider implements ChannelProvider {
    
    private final TwilioClient twilioClient;
    private final SNSClient snsClient;
    
    @Override
    public DeliveryResult deliver(Notification notification) throws DeliveryException {
        SMSMessage sms = SMSMessage.builder()
            .to(notification.getRecipient().getPhone())
            .body(notification.getBody())
            .build();
        
        try {
            TwilioResponse response = twilioClient.sendSMS(sms);
            
            return DeliveryResult.builder()
                .success(true)
                .externalId(response.getSid())
                .provider("twilio")
                .deliveredAt(Instant.now())
                .cost(calculateSMSCost(sms.getBody().length()))
                .build();
                
        } catch (TwilioException e) {
            throw new DeliveryException("Twilio SMS delivery failed", e);
        }
    }
}
```

## 📊 Real-Time Analytics

### Analytics Service

```java
@Service
public class AnalyticsService {
    
    private final ClickHouseTemplate clickHouseTemplate;
    private final KafkaTemplate<String, Object> kafkaTemplate;
    private final RedisTemplate<String, Object> redisTemplate;
    
    public void recordDeliveryEvent(UUID notificationId, String eventType, DeliveryResult result) {
        NotificationEvent event = NotificationEvent.builder()
            .id(UUID.randomUUID())
            .notificationId(notificationId)
            .eventType(eventType)
            .channel(result.getChannel())
            .provider(result.getProvider())
            .timestamp(Instant.now())
            .cost(result.getCost())
            .build();
        
        // Real-time stream for immediate dashboards
        kafkaTemplate.send("analytics-events", event);
        
        // Update real-time counters in Redis
        updateRealTimeMetrics(event);
    }
    
    private void updateRealTimeMetrics(NotificationEvent event) {
        String tenantKey = STR."metrics:tenant:\{event.getTenantId()}";
        
        // Increment counters
        redisTemplate.opsForHash().increment(tenantKey, "total_sent", 1);
        redisTemplate.opsForHash().increment(tenantKey, STR."sent_\{event.getChannel()}", 1);
        
        if ("delivered".equals(event.getEventType())) {
            redisTemplate.opsForHash().increment(tenantKey, "total_delivered", 1);
            redisTemplate.opsForHash().increment(tenantKey, STR."delivered_\{event.getChannel()}", 1);
        }
        
        // Add to time series for charts
        String timeSeriesKey = STR."timeseries:tenant:\{event.getTenantId()}:hour:\{getCurrentHour()}";
        redisTemplate.opsForValue().increment(timeSeriesKey);
        redisTemplate.expire(timeSeriesKey, Duration.ofHours(48));
    }
    
    @KafkaListener(topics = "analytics-events")
    public void processAnalyticsEvent(NotificationEvent event) {
        // Batch insert to ClickHouse for historical analytics
        String sql = """
            INSERT INTO notification_events 
            (id, tenant_id, notification_id, event_type, channel, provider, 
             recipient_hash, country, device_type, timestamp, properties)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """;
        
        clickHouseTemplate.update(sql,
            event.getId(),
            event.getTenantId(),
            event.getNotificationId(),
            event.getEventType(),
            event.getChannel(),
            event.getProvider(),
            hashRecipient(event.getRecipient()),
            event.getCountry(),
            event.getDeviceType(),
            event.getTimestamp(),
            event.getProperties()
        );
    }
    
    public DeliveryMetrics getDeliveryMetrics(UUID tenantId, TimeRange timeRange) {
        String sql = """
            SELECT 
                channel,
                provider,
                count(*) as total_sent,
                countIf(event_type = 'delivered') as total_delivered,
                countIf(event_type = 'failed') as total_failed,
                avg(cost_cents) as avg_cost,
                quantile(0.95)(delivery_time_ms) as p95_delivery_time
            FROM notification_events
            WHERE tenant_id = ? 
              AND timestamp BETWEEN ? AND ?
            GROUP BY channel, provider
            ORDER BY total_sent DESC
            """;
        
        return clickHouseTemplate.query(sql, 
            new DeliveryMetricsResultSetExtractor(),
            tenantId, timeRange.getStart(), timeRange.getEnd()
        );
    }
}
```

## 🧪 Testing Strategy

### Integration Tests with TestContainers

```java
@SpringBootTest
@Testcontainers
class NotificationPlatformIntegrationTest {
    
    @Container
    static PostgreSQLContainer<?> postgres = new PostgreSQLContainer<>("postgres:15")
            .withDatabaseName("notifications")
            .withUsername("test")
            .withPassword("test");
    
    @Container
    static KafkaContainer kafka = new KafkaContainer(DockerImageName.parse("confluentinc/cp-kafka:latest"));
    
    @Container
    static GenericContainer<?> redis = new GenericContainer<>("redis:7-alpine")
            .withExposedPorts(6379);
    
    @Autowired
    private NotificationService notificationService;
    
    @Autowired
    private TestKafkaTemplate kafkaTemplate;
    
    @Test
    void shouldDeliverNotificationEndToEnd() {
        // Given
        UUID tenantId = createTestTenant();
        NotificationTemplate template = createTestTemplate(tenantId);
        
        NotificationRequest request = NotificationRequest.builder()
            .tenantId(tenantId)
            .templateId(template.getId())
            .recipient(Recipient.builder()
                .email("test@example.com")
                .build())
            .variables(Map.of("name", "John Doe"))
            .channel("email")
            .build();
        
        // When
        NotificationResponse response = notificationService.sendNotification(request);
        
        // Then
        assertThat(response.getStatus()).isEqualTo("queued");
        
        // Wait for processing
        await().atMost(Duration.ofSeconds(10))
            .until(() -> getNotificationStatus(response.getNotificationId())
                .equals("delivered"));
    }
    
    @Test
    void shouldHandleFailureAndRetry() {
        // Given
        configureProviderToFail("email", 2); // Fail first 2 attempts
        
        NotificationRequest request = createTestRequest();
        
        // When
        notificationService.sendNotification(request);
        
        // Then
        await().atMost(Duration.ofMinutes(2))
            .until(() -> {
                List<DeliveryAttempt> attempts = getDeliveryAttempts(request.getId());
                return attempts.size() == 3 && 
                       attempts.get(2).getStatus().equals("delivered");
            });
    }
}
```

### Load Testing

```java
@Component
public class NotificationLoadTester {
    
    public void runLoadTest(LoadTestConfig config) {
        ExecutorService executor = Executors.newVirtualThreadPerTaskExecutor();
        CountDownLatch latch = new CountDownLatch(config.getConcurrentUsers());
        AtomicInteger successCount = new AtomicInteger(0);
        AtomicInteger errorCount = new AtomicInteger(0);
        
        Instant startTime = Instant.now();
        
        for (int i = 0; i < config.getConcurrentUsers(); i++) {
            final int userId = i;
            executor.submit(() -> {
                try {
                    for (int j = 0; j < config.getRequestsPerUser(); j++) {
                        sendTestNotification(userId, j);
                        successCount.incrementAndGet();
                        
                        // Add realistic delay
                        Thread.sleep(config.getDelayBetweenRequests().toMillis());
                    }
                } catch (Exception e) {
                    errorCount.incrementAndGet();
                    log.error("Load test error for user {}: {}", userId, e.getMessage());
                } finally {
                    latch.countDown();
                }
            });
        }
        
        try {
            latch.await(config.getTimeout().toSeconds(), TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        
        Instant endTime = Instant.now();
        Duration totalTime = Duration.between(startTime, endTime);
        
        LoadTestResults results = LoadTestResults.builder()
            .totalRequests(config.getConcurrentUsers() * config.getRequestsPerUser())
            .successfulRequests(successCount.get())
            .failedRequests(errorCount.get())
            .totalDuration(totalTime)
            .requestsPerSecond(calculateRPS(successCount.get(), totalTime))
            .build();
        
        log.info("Load test completed: {}", results);
    }
}
```

## 🚀 Deployment Configuration

### Docker Compose for Local Development

```yaml
version: '3.8'
services:
  postgres:
    image: postgres:15
    environment:
      POSTGRES_DB: notifications
      POSTGRES_USER: notifications
      POSTGRES_PASSWORD: password
    volumes:
      - postgres_data:/var/lib/postgresql/data
      - ./sql/init.sql:/docker-entrypoint-initdb.d/init.sql
    ports:
      - "5432:5432"
  
  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"
    command: redis-server --appendonly yes
    volumes:
      - redis_data:/data
  
  kafka:
    image: confluentinc/cp-kafka:latest
    environment:
      KAFKA_ZOOKEEPER_CONNECT: zookeeper:2181
      KAFKA_ADVERTISED_LISTENERS: PLAINTEXT://localhost:9092
      KAFKA_OFFSETS_TOPIC_REPLICATION_FACTOR: 1
    ports:
      - "9092:9092"
    depends_on:
      - zookeeper
  
  zookeeper:
    image: confluentinc/cp-zookeeper:latest
    environment:
      ZOOKEEPER_CLIENT_PORT: 2181
      ZOOKEEPER_TICK_TIME: 2000
    ports:
      - "2181:2181"
  
  clickhouse:
    image: clickhouse/clickhouse-server:latest
    ports:
      - "8123:8123"
      - "9000:9000"
    volumes:
      - clickhouse_data:/var/lib/clickhouse
      - ./clickhouse/init.sql:/docker-entrypoint-initdb.d/init.sql
  
  notification-api:
    build: .
    environment:
      SPRING_PROFILES_ACTIVE: docker
      SPRING_DATASOURCE_URL: jdbc:postgresql://postgres:5432/notifications
      SPRING_REDIS_HOST: redis
      SPRING_KAFKA_BOOTSTRAP_SERVERS: kafka:9092
      CLICKHOUSE_URL: http://clickhouse:8123
    ports:
      - "8080:8080"
    depends_on:
      - postgres
      - redis
      - kafka
      - clickhouse
  
  prometheus:
    image: prom/prometheus:latest
    ports:
      - "9090:9090"
    volumes:
      - ./monitoring/prometheus.yml:/etc/prometheus/prometheus.yml
  
  grafana:
    image: grafana/grafana:latest
    ports:
      - "3000:3000"
    environment:
      GF_SECURITY_ADMIN_PASSWORD: admin
    volumes:
      - ./monitoring/grafana/dashboards:/var/lib/grafana/dashboards
      - ./monitoring/grafana/provisioning:/etc/grafana/provisioning

volumes:
  postgres_data:
  redis_data:
  clickhouse_data:
```

### Kubernetes Deployment

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: notification-api
  namespace: notifications
spec:
  replicas: 3
  selector:
    matchLabels:
      app: notification-api
  template:
    metadata:
      labels:
        app: notification-api
    spec:
      containers:
      - name: notification-api
        image: notification-platform:latest
        ports:
        - containerPort: 8080
        env:
        - name: SPRING_PROFILES_ACTIVE
          value: "kubernetes"
        - name: SPRING_DATASOURCE_URL
          valueFrom:
            secretKeyRef:
              name: database-secret
              key: url
        - name: SPRING_REDIS_HOST
          value: "redis-service"
        - name: SPRING_KAFKA_BOOTSTRAP_SERVERS
          value: "kafka-service:9092"
        resources:
          requests:
            memory: "512Mi"
            cpu: "500m"
          limits:
            memory: "1Gi"
            cpu: "1000m"
        livenessProbe:
          httpGet:
            path: /actuator/health
            port: 8080
          initialDelaySeconds: 60
          periodSeconds: 30
        readinessProbe:
          httpGet:
            path: /actuator/health/readiness
            port: 8080
          initialDelaySeconds: 30
          periodSeconds: 10
---
apiVersion: v1
kind: Service
metadata:
  name: notification-api-service
  namespace: notifications
spec:
  selector:
    app: notification-api
  ports:
  - port: 80
    targetPort: 8080
  type: LoadBalancer
```

## 📊 Monitoring and Observability

### Custom Metrics

```java
@Component
public class NotificationMetrics {
    
    private final Counter notificationsTotal;
    private final Counter deliveryAttemptsTotal;
    private final Timer deliveryDuration;
    private final Gauge activeNotifications;
    private final Counter costsTotal;
    
    public NotificationMetrics(MeterRegistry meterRegistry) {
        this.notificationsTotal = Counter.builder("notifications.total")
            .description("Total notifications processed")
            .tag("status", "")
            .tag("channel", "")
            .register(meterRegistry);
            
        this.deliveryAttemptsTotal = Counter.builder("delivery.attempts.total")
            .description("Total delivery attempts")
            .tag("provider", "")
            .tag("result", "")
            .register(meterRegistry);
            
        this.deliveryDuration = Timer.builder("delivery.duration")
            .description("Delivery duration")
            .tag("channel", "")
            .register(meterRegistry);
            
        this.activeNotifications = Gauge.builder("notifications.active")
            .description("Currently active notifications")
            .register(meterRegistry, this, NotificationMetrics::getActiveCount);
            
        this.costsTotal = Counter.builder("delivery.cost.total")
            .description("Total delivery costs in cents")
            .tag("provider", "")
            .register(meterRegistry);
    }
    
    public void recordNotification(String status, String channel) {
        notificationsTotal.increment(
            Tags.of("status", status, "channel", channel)
        );
    }
    
    public void recordDeliveryAttempt(String provider, String result, Duration duration, int costCents) {
        deliveryAttemptsTotal.increment(
            Tags.of("provider", provider, "result", result)
        );
        
        deliveryDuration.record(duration);
        
        costsTotal.increment(
            Tags.of("provider", provider),
            costCents
        );
    }
    
    private double getActiveCount() {
        return notificationService.getActiveNotificationCount();
    }
}
```

### Grafana Dashboard Configuration

```json
{
  "dashboard": {
    "title": "Notification Platform Dashboard",
    "panels": [
      {
        "title": "Notifications per Second",
        "type": "graph",
        "targets": [
          {
            "expr": "rate(notifications_total[5m])",
            "legendFormat": "{{status}} - {{channel}}"
          }
        ]
      },
      {
        "title": "Delivery Success Rate",
        "type": "stat",
        "targets": [
          {
            "expr": "rate(delivery_attempts_total{result=\"success\"}[5m]) / rate(delivery_attempts_total[5m]) * 100"
          }
        ]
      },
      {
        "title": "Average Delivery Time",
        "type": "stat",
        "targets": [
          {
            "expr": "avg(delivery_duration_seconds)"
          }
        ]
      },
      {
        "title": "Cost per Channel",
        "type": "piechart",
        "targets": [
          {
            "expr": "sum by (provider) (delivery_cost_total)"
          }
        ]
      }
    ]
  }
}
```

## 🎯 Project Deliverables

### 1. Complete Implementation
- [ ] All microservices implemented with Java 21
- [ ] Multi-tenant architecture with complete isolation
- [ ] All channel providers (Email, SMS, Push, Slack, Teams, Webhooks)
- [ ] Retry mechanisms with exponential backoff
- [ ] Dead letter queue handling
- [ ] Real-time analytics with ClickHouse

### 2. Testing Suite
- [ ] Unit tests with 80%+ coverage
- [ ] Integration tests with TestContainers
- [ ] Load testing with virtual threads
- [ ] Chaos engineering scenarios
- [ ] Contract testing for external APIs

### 3. Documentation
- [ ] Architecture decision records (ADRs)
- [ ] API documentation with OpenAPI
- [ ] Deployment guides for local and production
- [ ] Monitoring and troubleshooting runbooks
- [ ] Performance benchmarks and capacity planning

### 4. Production Readiness
- [ ] Docker images and Kubernetes manifests
- [ ] Monitoring dashboards and alerting rules
- [ ] Security audit and penetration testing
- [ ] Disaster recovery procedures
- [ ] Cost analysis and optimization recommendations

### 5. Presentation
- [ ] Technical presentation (30 minutes)
- [ ] Live demo of key features
- [ ] Q&A session with technical reviewers
- [ ] Code review with peers

## 🏆 Success Criteria

### Technical Excellence
- **Performance**: Handle 10K+ notifications per second
- **Reliability**: 99.9% uptime with automatic failover
- **Scalability**: Horizontal scaling demonstrated under load
- **Security**: Pass security audit with no critical vulnerabilities

### Code Quality
- **Architecture**: Clean, maintainable, and well-documented code
- **Testing**: Comprehensive test coverage with meaningful tests
- **Observability**: Complete monitoring and alerting setup
- **Best Practices**: Following Java 21 and Spring Boot best practices

### Business Value
- **Multi-tenancy**: Complete tenant isolation and resource management
- **Analytics**: Actionable insights from delivery metrics
- **Cost Optimization**: Efficient provider routing and cost tracking
- **User Experience**: Intuitive APIs and comprehensive error handling

---

**This capstone project represents the culmination of your system design learning journey. By completing it successfully, you'll have built a production-ready, enterprise-grade notification platform that demonstrates mastery of all key system design concepts.**

## 📚 Additional Resources

- **Code Repository**: Complete implementation with detailed comments
- **Video Tutorials**: Step-by-step implementation guides
- **Peer Review**: Code review sessions with experienced architects
- **Industry Mentorship**: Connect with notification platform engineers

**Ready to build the future of notifications? Let's get started!**
