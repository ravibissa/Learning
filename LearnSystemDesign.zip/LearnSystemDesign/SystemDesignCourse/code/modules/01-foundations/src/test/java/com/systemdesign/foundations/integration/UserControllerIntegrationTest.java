package com.systemdesign.foundations.integration;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.systemdesign.foundations.dto.CreateUserRequest;
import com.systemdesign.foundations.model.User;
import com.systemdesign.foundations.repository.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureWebMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
import org.testcontainers.containers.PostgreSQLContainer;
import org.testcontainers.containers.GenericContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;

import java.util.Optional;
import java.util.UUID;

import static org.hamcrest.Matchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Integration tests for UserController using TestContainers
 * Demonstrates testing patterns for system design applications
 */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureWebMvc
@ActiveProfiles("test")
@Testcontainers
class UserControllerIntegrationTest {
    
    @Container
    static PostgreSQLContainer<?> postgres = new PostgreSQLContainer<>("postgres:15-alpine")
            .withDatabaseName("testdb")
            .withUsername("test")
            .withPassword("test");
    
    @Container
    static GenericContainer<?> redis = new GenericContainer<>("redis:7-alpine")
            .withExposedPorts(6379);
    
    @Autowired
    private WebApplicationContext webApplicationContext;
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private ObjectMapper objectMapper;
    
    private MockMvc mockMvc;
    
    @BeforeEach
    void setUp() {
        mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
        userRepository.deleteAll(); // Clean state for each test
    }
    
    @Test
    void createUser_WithValidData_ShouldReturnCreated() throws Exception {
        // Given
        CreateUserRequest request = new CreateUserRequest(
            "testuser",
            "test@example.com",
            "Test",
            "User"
        );
        
        // When & Then
        mockMvc.perform(post("/api/v1/users")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.username", is("testuser")))
                .andExpect(jsonPath("$.email", is("test@example.com")))
                .andExpect(jsonPath("$.firstName", is("Test")))
                .andExpect(jsonPath("$.lastName", is("User")))
                .andExpect(jsonPath("$.status", is("ACTIVE")))
                .andExpect(jsonPath("$.id", notNullValue()))
                .andExpect(jsonPath("$.createdAt", notNullValue()));
    }
    
    @Test
    void createUser_WithInvalidData_ShouldReturnBadRequest() throws Exception {
        // Given - empty username
        CreateUserRequest request = new CreateUserRequest(
            "",
            "test@example.com",
            "Test",
            "User"
        );
        
        // When & Then
        mockMvc.perform(post("/api/v1/users")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest());
    }
    
    @Test
    void createUser_WithDuplicateUsername_ShouldReturnBadRequest() throws Exception {
        // Given - create first user
        User existingUser = User.builder()
            .username("testuser")
            .email("existing@example.com")
            .build();
        userRepository.save(existingUser);
        
        CreateUserRequest request = new CreateUserRequest(
            "testuser", // Same username
            "test@example.com",
            "Test",
            "User"
        );
        
        // When & Then
        mockMvc.perform(post("/api/v1/users")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest());
    }
    
    @Test
    void getUser_WhenExists_ShouldReturnUser() throws Exception {
        // Given
        User user = User.builder()
            .username("testuser")
            .email("test@example.com")
            .firstName("Test")
            .lastName("User")
            .build();
        User savedUser = userRepository.save(user);
        
        // When & Then
        mockMvc.perform(get("/api/v1/users/{id}", savedUser.getId()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id", is(savedUser.getId().toString())))
                .andExpect(jsonPath("$.username", is("testuser")))
                .andExpect(jsonPath("$.email", is("test@example.com")));
    }
    
    @Test
    void getUser_WhenNotExists_ShouldReturnNotFound() throws Exception {
        // Given
        UUID nonExistentId = UUID.randomUUID();
        
        // When & Then
        mockMvc.perform(get("/api/v1/users/{id}", nonExistentId))
                .andExpect(status().isNotFound());
    }
    
    @Test
    void getUserByUsername_WhenExists_ShouldReturnUser() throws Exception {
        // Given
        User user = User.builder()
            .username("testuser")
            .email("test@example.com")
            .build();
        userRepository.save(user);
        
        // When & Then
        mockMvc.perform(get("/api/v1/users/username/{username}", "testuser"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.username", is("testuser")))
                .andExpect(jsonPath("$.email", is("test@example.com")));
    }
    
    @Test
    void getUsers_ShouldReturnPagedResults() throws Exception {
        // Given - create multiple users
        for (int i = 0; i < 5; i++) {
            User user = User.builder()
                .username("user" + i)
                .email("user" + i + "@example.com")
                .build();
            userRepository.save(user);
        }
        
        // When & Then
        mockMvc.perform(get("/api/v1/users")
                .param("page", "0")
                .param("size", "3"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content", hasSize(3)))
                .andExpect(jsonPath("$.totalElements", is(5)))
                .andExpect(jsonPath("$.totalPages", is(2)))
                .andExpect(jsonPath("$.first", is(true)))
                .andExpect(jsonPath("$.last", is(false)));
    }
    
    @Test
    void updateUser_WhenExists_ShouldUpdateAndReturn() throws Exception {
        // Given
        User user = User.builder()
            .username("testuser")
            .email("test@example.com")
            .firstName("Test")
            .lastName("User")
            .build();
        User savedUser = userRepository.save(user);
        
        CreateUserRequest updateRequest = new CreateUserRequest(
            "updateduser",
            "updated@example.com",
            "Updated",
            "User"
        );
        
        // When & Then
        mockMvc.perform(put("/api/v1/users/{id}", savedUser.getId())
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(updateRequest)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.username", is("updateduser")))
                .andExpected(jsonPath("$.email", is("updated@example.com")))
                .andExpect(jsonPath("$.firstName", is("Updated")));
    }
    
    @Test
    void deleteUser_WhenExists_ShouldReturnNoContent() throws Exception {
        // Given
        User user = User.builder()
            .username("testuser")
            .email("test@example.com")
            .build();
        User savedUser = userRepository.save(user);
        
        // When & Then
        mockMvc.perform(delete("/api/v1/users/{id}", savedUser.getId()))
                .andExpect(status().isNoContent());
        
        // Verify user is marked as deleted
        Optional<User> deletedUser = userRepository.findById(savedUser.getId());
        assert deletedUser.isPresent();
        assert deletedUser.get().getStatus() == User.UserStatus.DELETED;
    }
    
    @Test
    void searchUsers_WithQuery_ShouldReturnMatchingResults() throws Exception {
        // Given
        User user1 = User.builder()
            .username("john.doe")
            .email("john@example.com")
            .build();
        User user2 = User.builder()
            .username("jane.smith")
            .email("jane@example.com")
            .build();
        User user3 = User.builder()
            .username("bob.jones")
            .email("bob@company.com")
            .build();
        
        userRepository.save(user1);
        userRepository.save(user2);
        userRepository.save(user3);
        
        // When & Then - search by username
        mockMvc.perform(get("/api/v1/users/search")
                .param("query", "john"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content", hasSize(1)))
                .andExpect(jsonPath("$.content[0].username", is("john.doe")));
        
        // Search by email domain
        mockMvc.perform(get("/api/v1/users/search")
                .param("query", "example.com"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content", hasSize(2)));
    }
    
    @Test
    void searchUsers_WithShortQuery_ShouldReturnBadRequest() throws Exception {
        // Given
        String shortQuery = "a";
        
        // When & Then
        mockMvc.perform(get("/api/v1/users/search")
                .param("query", shortQuery))
                .andExpect(status().isBadRequest());
    }
    
    @Test
    void batchCreateUsers_WithValidCount_ShouldCreateUsers() throws Exception {
        // Given
        int count = 10;
        
        // When & Then
        mockMvc.perform(post("/api/v1/users/batch")
                .param("count", String.valueOf(count)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success", is(true)))
                .andExpect(jsonPath("$.processedCount", is(count)))
                .andExpect(jsonPath("$.message", containsString("Successfully created")));
        
        // Verify users were created
        long userCount = userRepository.count();
        assert userCount == count;
    }
    
    @Test
    void batchCreateUsers_WithInvalidCount_ShouldReturnBadRequest() throws Exception {
        // Given
        int invalidCount = 2000; // Exceeds limit
        
        // When & Then
        mockMvc.perform(post("/api/v1/users/batch")
                .param("count", String.valueOf(invalidCount)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.success", is(false)))
                .andExpect(jsonPath("$.message", containsString("Count must be between")));
    }
    
    @Test
    void health_ShouldReturnHealthStatus() throws Exception {
        // When & Then
        mockMvc.perform(get("/api/v1/users/health"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status", is("UP")))
                .andExpect(jsonPath("$.message", notNullValue()))
                .andExpect(jsonPath("$.activeUsers", greaterThanOrEqualTo(0)))
                .andExpect(jsonPath("$.timestamp", notNullValue()));
    }
    
    @Test
    void concurrentUserCreation_ShouldHandleMultipleRequests() throws Exception {
        // Given
        int numberOfThreads = 10;
        CreateUserRequest[] requests = new CreateUserRequest[numberOfThreads];
        
        for (int i = 0; i < numberOfThreads; i++) {
            requests[i] = new CreateUserRequest(
                "user" + i,
                "user" + i + "@example.com",
                "User",
                String.valueOf(i)
            );
        }
        
        // When - simulate concurrent requests
        Thread[] threads = new Thread[numberOfThreads];
        boolean[] results = new boolean[numberOfThreads];
        
        for (int i = 0; i < numberOfThreads; i++) {
            final int index = i;
            threads[i] = new Thread(() -> {
                try {
                    mockMvc.perform(post("/api/v1/users")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(requests[index])))
                            .andExpect(status().isCreated());
                    results[index] = true;
                } catch (Exception e) {
                    results[index] = false;
                }
            });
        }
        
        // Start all threads
        for (Thread thread : threads) {
            thread.start();
        }
        
        // Wait for all threads to complete
        for (Thread thread : threads) {
            thread.join();
        }
        
        // Then - verify all requests succeeded
        for (boolean result : results) {
            assert result : "One or more concurrent requests failed";
        }
        
        // Verify correct number of users created
        long userCount = userRepository.count();
        assert userCount == numberOfThreads;
    }
}
