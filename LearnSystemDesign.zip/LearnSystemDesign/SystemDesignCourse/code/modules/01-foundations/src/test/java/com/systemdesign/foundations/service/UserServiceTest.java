package com.systemdesign.foundations.service;

import com.systemdesign.foundations.dto.CreateUserRequest;
import com.systemdesign.foundations.exception.UserNotFoundException;
import com.systemdesign.foundations.metrics.UserMetrics;
import com.systemdesign.foundations.model.User;
import com.systemdesign.foundations.repository.UserRepository;
import com.systemdesign.foundations.resilience.RetryHandler;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * Unit tests for UserService demonstrating testing patterns for system design
 */
@ExtendWith(MockitoExtension.class)
class UserServiceTest {
    
    @Mock
    private UserRepository userRepository;
    
    @Mock
    private RetryHandler retryHandler;
    
    @Mock
    private UserMetrics userMetrics;
    
    @InjectMocks
    private UserService userService;
    
    private User testUser;
    private CreateUserRequest testRequest;
    private UUID testUserId;
    
    @BeforeEach
    void setUp() {
        testUserId = UUID.randomUUID();
        testUser = User.builder()
            .id(testUserId)
            .username("testuser")
            .email("test@example.com")
            .firstName("Test")
            .lastName("User")
            .build();
            
        testRequest = new CreateUserRequest(
            "testuser",
            "test@example.com",
            "Test",
            "User"
        );
    }
    
    @Test
    void findById_WhenUserExists_ShouldReturnUser() {
        // Given
        when(retryHandler.executeWithRetry(any(), eq(3), eq(Duration.ofMillis(100))))
            .thenAnswer(invocation -> {
                // Simulate the retry handler executing the operation
                return userRepository.findById(testUserId).orElseThrow();
            });
        when(userRepository.findById(testUserId)).thenReturn(Optional.of(testUser));
        when(userMetrics.startLookupTimer()).thenReturn(mock(io.micrometer.core.instrument.Timer.Sample.class));
        when(userMetrics.getUserLookupTimer()).thenReturn(mock(io.micrometer.core.instrument.Timer.class));
        
        // When
        User result = userService.findById(testUserId);
        
        // Then
        assertNotNull(result);
        assertEquals(testUser.getId(), result.getId());
        assertEquals(testUser.getUsername(), result.getUsername());
        verify(userRepository).findById(testUserId);
        verify(userMetrics).startLookupTimer();
    }
    
    @Test
    void findById_WhenUserNotExists_ShouldThrowException() {
        // Given
        when(retryHandler.executeWithRetry(any(), eq(3), eq(Duration.ofMillis(100))))
            .thenAnswer(invocation -> {
                return userRepository.findById(testUserId).orElseThrow(
                    () -> new UserNotFoundException("User not found with id: " + testUserId)
                );
            });
        when(userRepository.findById(testUserId)).thenReturn(Optional.empty());
        when(userMetrics.startLookupTimer()).thenReturn(mock(io.micrometer.core.instrument.Timer.Sample.class));
        when(userMetrics.getUserLookupTimer()).thenReturn(mock(io.micrometer.core.instrument.Timer.class));
        
        // When & Then
        assertThrows(UserNotFoundException.class, () -> userService.findById(testUserId));
        verify(userRepository).findById(testUserId);
    }
    
    @Test
    void createUser_WhenValidRequest_ShouldCreateUser() {
        // Given
        when(userRepository.existsByUsername(testRequest.username())).thenReturn(false);
        when(userRepository.existsByEmail(testRequest.email())).thenReturn(false);
        when(userRepository.save(any(User.class))).thenReturn(testUser);
        
        // When
        User result = userService.createUser(testRequest);
        
        // Then
        assertNotNull(result);
        assertEquals(testUser.getUsername(), result.getUsername());
        assertEquals(testUser.getEmail(), result.getEmail());
        verify(userRepository).existsByUsername(testRequest.username());
        verify(userRepository).existsByEmail(testRequest.email());
        verify(userRepository).save(any(User.class));
        verify(userMetrics).recordUserCreation();
    }
    
    @Test
    void createUser_WhenUsernameExists_ShouldThrowException() {
        // Given
        when(userRepository.existsByUsername(testRequest.username())).thenReturn(true);
        
        // When & Then
        IllegalArgumentException exception = assertThrows(
            IllegalArgumentException.class,
            () -> userService.createUser(testRequest)
        );
        
        assertTrue(exception.getMessage().contains("Username already exists"));
        verify(userRepository).existsByUsername(testRequest.username());
        verify(userRepository, never()).save(any());
        verify(userMetrics, never()).recordUserCreation();
    }
    
    @Test
    void createUser_WhenEmailExists_ShouldThrowException() {
        // Given
        when(userRepository.existsByUsername(testRequest.username())).thenReturn(false);
        when(userRepository.existsByEmail(testRequest.email())).thenReturn(true);
        
        // When & Then
        IllegalArgumentException exception = assertThrows(
            IllegalArgumentException.class,
            () -> userService.createUser(testRequest)
        );
        
        assertTrue(exception.getMessage().contains("Email already exists"));
        verify(userRepository).existsByEmail(testRequest.email());
        verify(userRepository, never()).save(any());
    }
    
    @Test
    void getUsers_ShouldReturnPagedResults() {
        // Given
        Pageable pageable = PageRequest.of(0, 20);
        List<User> users = List.of(testUser);
        Page<User> userPage = new PageImpl<>(users, pageable, 1);
        
        when(userRepository.findByStatusNot(User.UserStatus.DELETED, pageable))
            .thenReturn(userPage);
        
        // When
        Page<User> result = userService.getUsers(pageable);
        
        // Then
        assertNotNull(result);
        assertEquals(1, result.getTotalElements());
        assertEquals(testUser.getId(), result.getContent().get(0).getId());
        verify(userRepository).findByStatusNot(User.UserStatus.DELETED, pageable);
    }
    
    @Test
    void updateUser_WhenUserExists_ShouldUpdateUser() {
        // Given
        CreateUserRequest updateRequest = new CreateUserRequest(
            "updateduser",
            "updated@example.com",
            "Updated",
            "User"
        );
        
        User updatedUser = User.builder()
            .id(testUserId)
            .username("updateduser")
            .email("updated@example.com")
            .firstName("Updated")
            .lastName("User")
            .build();
        
        when(retryHandler.executeWithRetry(any(), eq(3), eq(Duration.ofMillis(100))))
            .thenAnswer(invocation -> userRepository.findById(testUserId).orElseThrow());
        when(userRepository.findById(testUserId)).thenReturn(Optional.of(testUser));
        when(userRepository.save(any(User.class))).thenReturn(updatedUser);
        when(userMetrics.startLookupTimer()).thenReturn(mock(io.micrometer.core.instrument.Timer.Sample.class));
        when(userMetrics.getUserLookupTimer()).thenReturn(mock(io.micrometer.core.instrument.Timer.class));
        
        // When
        User result = userService.updateUser(testUserId, updateRequest);
        
        // Then
        assertNotNull(result);
        assertEquals("updateduser", result.getUsername());
        assertEquals("updated@example.com", result.getEmail());
        verify(userRepository).save(any(User.class));
    }
    
    @Test
    void deleteUser_WhenUserExists_ShouldMarkAsDeleted() {
        // Given
        when(retryHandler.executeWithRetry(any(), eq(3), eq(Duration.ofMillis(100))))
            .thenAnswer(invocation -> userRepository.findById(testUserId).orElseThrow());
        when(userRepository.findById(testUserId)).thenReturn(Optional.of(testUser));
        when(userRepository.save(any(User.class))).thenReturn(testUser);
        when(userMetrics.startLookupTimer()).thenReturn(mock(io.micrometer.core.instrument.Timer.Sample.class));
        when(userMetrics.getUserLookupTimer()).thenReturn(mock(io.micrometer.core.instrument.Timer.class));
        
        // When
        userService.deleteUser(testUserId);
        
        // Then
        verify(userRepository).save(argThat(user -> 
            user.getStatus() == User.UserStatus.DELETED
        ));
    }
    
    @Test
    void searchUsers_WithValidQuery_ShouldReturnResults() {
        // Given
        String query = "test";
        Pageable pageable = PageRequest.of(0, 20);
        List<User> users = List.of(testUser);
        Page<User> userPage = new PageImpl<>(users, pageable, 1);
        
        when(userRepository.findByUsernameContainingIgnoreCaseOrEmailContainingIgnoreCase(
            query, query, pageable)).thenReturn(userPage);
        
        // When
        Page<User> result = userService.searchUsers(query, pageable);
        
        // Then
        assertNotNull(result);
        assertEquals(1, result.getTotalElements());
        verify(userRepository).findByUsernameContainingIgnoreCaseOrEmailContainingIgnoreCase(
            query, query, pageable);
    }
    
    @Test
    void searchUsers_WithEmptyQuery_ShouldReturnAllUsers() {
        // Given
        String query = "";
        Pageable pageable = PageRequest.of(0, 20);
        List<User> users = List.of(testUser);
        Page<User> userPage = new PageImpl<>(users, pageable, 1);
        
        when(userRepository.findByStatusNot(User.UserStatus.DELETED, pageable))
            .thenReturn(userPage);
        
        // When
        Page<User> result = userService.searchUsers(query, pageable);
        
        // Then
        assertNotNull(result);
        assertEquals(1, result.getTotalElements());
        verify(userRepository).findByStatusNot(User.UserStatus.DELETED, pageable);
    }
    
    @Test
    void countActiveUsers_ShouldReturnCount() {
        // Given
        long expectedCount = 42L;
        when(userRepository.countByStatus(User.UserStatus.ACTIVE)).thenReturn(expectedCount);
        
        // When
        long result = userService.countActiveUsers();
        
        // Then
        assertEquals(expectedCount, result);
        verify(userRepository).countByStatus(User.UserStatus.ACTIVE);
    }
    
    @Test
    void createUsersInBatch_ShouldCreateMultipleUsers() {
        // Given
        int count = 5;
        when(userRepository.existsByUsername(anyString())).thenReturn(false);
        when(userRepository.existsByEmail(anyString())).thenReturn(false);
        when(userRepository.save(any(User.class))).thenReturn(testUser);
        
        // When
        userService.createUsersInBatch(count);
        
        // Then
        verify(userRepository, times(count)).save(any(User.class));
        verify(userMetrics, times(count)).recordUserCreation();
    }
    
    @Test
    void findByUsername_WhenUserExists_ShouldReturnUser() {
        // Given
        String username = "testuser";
        when(userRepository.findByUsername(username)).thenReturn(Optional.of(testUser));
        
        // When
        User result = userService.findByUsername(username);
        
        // Then
        assertNotNull(result);
        assertEquals(testUser.getUsername(), result.getUsername());
        verify(userRepository).findByUsername(username);
    }
    
    @Test
    void findByUsername_WhenUserNotExists_ShouldThrowException() {
        // Given
        String username = "nonexistent";
        when(userRepository.findByUsername(username)).thenReturn(Optional.empty());
        
        // When & Then
        assertThrows(UserNotFoundException.class, () -> userService.findByUsername(username));
        verify(userRepository).findByUsername(username);
    }
}
