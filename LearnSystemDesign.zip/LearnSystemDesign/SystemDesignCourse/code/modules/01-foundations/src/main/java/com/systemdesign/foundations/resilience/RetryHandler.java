package com.systemdesign.foundations.resilience;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.Supplier;

/**
 * Retry handler with exponential backoff and jitter
 * Demonstrates resilience patterns for system design
 */
@Component
public class RetryHandler {
    
    private static final Logger log = LoggerFactory.getLogger(RetryHandler.class);
    
    /**
     * Execute operation with retry and exponential backoff
     */
    public <T> T executeWithRetry(
            Supplier<T> operation,
            int maxRetries,
            Duration initialDelay) {
        
        return executeWithRetry(operation, maxRetries, initialDelay, 2.0, 0.1);
    }
    
    /**
     * Execute operation with configurable retry parameters
     */
    public <T> T executeWithRetry(
            Supplier<T> operation,
            int maxRetries,
            Duration initialDelay,
            double multiplier,
            double jitterFactor) {
        
        Exception lastException = null;
        
        for (int attempt = 0; attempt <= maxRetries; attempt++) {
            try {
                T result = operation.get();
                
                if (attempt > 0) {
                    log.info("Operation succeeded on attempt {}/{}", attempt + 1, maxRetries + 1);
                }
                
                return result;
                
            } catch (Exception e) {
                lastException = e;
                
                if (attempt == maxRetries) {
                    log.error("Operation failed after {} attempts", maxRetries + 1, e);
                    break; // Last attempt failed
                }
                
                // Calculate delay with exponential backoff and jitter
                Duration delay = calculateDelay(initialDelay, attempt, multiplier, jitterFactor);
                
                log.warn("Operation failed on attempt {}/{}. Retrying in {}ms: {}", 
                    attempt + 1, maxRetries + 1, delay.toMillis(), e.getMessage());
                
                try {
                    Thread.sleep(delay.toMillis());
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    throw new RuntimeException("Retry interrupted", ie);
                }
            }
        }
        
        throw new RetryExhaustedException(
            STR."Operation failed after \{maxRetries + 1} attempts", lastException);
    }
    
    /**
     * Calculate delay with exponential backoff and jitter
     */
    private Duration calculateDelay(Duration initialDelay, int attempt, double multiplier, double jitterFactor) {
        // Exponential backoff: initialDelay * multiplier^attempt
        long baseDelayMs = (long) (initialDelay.toMillis() * Math.pow(multiplier, attempt));
        
        // Add jitter to prevent thundering herd
        double jitter = 1.0 + (ThreadLocalRandom.current().nextDouble() - 0.5) * 2 * jitterFactor;
        long finalDelayMs = (long) (baseDelayMs * jitter);
        
        // Cap the maximum delay to prevent extremely long waits
        long maxDelayMs = Duration.ofMinutes(5).toMillis();
        return Duration.ofMillis(Math.min(finalDelayMs, maxDelayMs));
    }
    
    /**
     * Retry with specific exception handling
     */
    public <T> T executeWithRetryOnException(
            Supplier<T> operation,
            Class<? extends Exception> retryableException,
            int maxRetries,
            Duration initialDelay) {
        
        Exception lastException = null;
        
        for (int attempt = 0; attempt <= maxRetries; attempt++) {
            try {
                return operation.get();
            } catch (Exception e) {
                lastException = e;
                
                // Only retry on specific exceptions
                if (!retryableException.isInstance(e)) {
                    throw new RuntimeException("Non-retryable exception", e);
                }
                
                if (attempt == maxRetries) {
                    break;
                }
                
                Duration delay = calculateDelay(initialDelay, attempt, 2.0, 0.1);
                
                try {
                    Thread.sleep(delay.toMillis());
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    throw new RuntimeException("Retry interrupted", ie);
                }
            }
        }
        
        throw new RetryExhaustedException(
            STR."Operation failed after \{maxRetries + 1} attempts", lastException);
    }
    
    /**
     * Async retry with CompletableFuture
     */
    public <T> java.util.concurrent.CompletableFuture<T> executeAsyncWithRetry(
            Supplier<T> operation,
            int maxRetries,
            Duration initialDelay) {
        
        return java.util.concurrent.CompletableFuture.supplyAsync(() -> 
            executeWithRetry(operation, maxRetries, initialDelay)
        );
    }
    
    /**
     * Custom exception for retry exhaustion
     */
    public static class RetryExhaustedException extends RuntimeException {
        public RetryExhaustedException(String message, Throwable cause) {
            super(message, cause);
        }
    }
    
    /**
     * Builder pattern for retry configuration
     */
    public static class RetryConfig {
        private int maxRetries = 3;
        private Duration initialDelay = Duration.ofMillis(100);
        private double multiplier = 2.0;
        private double jitterFactor = 0.1;
        private Class<? extends Exception> retryableException = Exception.class;
        
        public static RetryConfig builder() {
            return new RetryConfig();
        }
        
        public RetryConfig maxRetries(int maxRetries) {
            this.maxRetries = maxRetries;
            return this;
        }
        
        public RetryConfig initialDelay(Duration initialDelay) {
            this.initialDelay = initialDelay;
            return this;
        }
        
        public RetryConfig multiplier(double multiplier) {
            this.multiplier = multiplier;
            return this;
        }
        
        public RetryConfig jitterFactor(double jitterFactor) {
            this.jitterFactor = jitterFactor;
            return this;
        }
        
        public RetryConfig retryOn(Class<? extends Exception> exception) {
            this.retryableException = exception;
            return this;
        }
        
        public <T> T execute(Supplier<T> operation, RetryHandler retryHandler) {
            if (retryableException == Exception.class) {
                return retryHandler.executeWithRetry(operation, maxRetries, initialDelay, multiplier, jitterFactor);
            } else {
                return retryHandler.executeWithRetryOnException(operation, retryableException, maxRetries, initialDelay);
            }
        }
    }
}
