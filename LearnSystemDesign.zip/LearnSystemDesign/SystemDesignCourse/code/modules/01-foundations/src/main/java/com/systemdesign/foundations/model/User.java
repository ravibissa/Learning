package com.systemdesign.foundations.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

import java.time.Instant;
import java.util.UUID;

/**
 * User entity demonstrating Java 21 features and JPA patterns
 */
@Entity
@Table(name = "users", indexes = {
    @Index(name = "idx_username", columnList = "username", unique = true),
    @Index(name = "idx_email", columnList = "email", unique = true),
    @Index(name = "idx_created_at", columnList = "created_at")
})
public class User {
    
    @Id
    private UUID id;
    
    @NotBlank(message = "Username is required")
    @Size(min = 3, max = 50, message = "Username must be between 3 and 50 characters")
    @Column(nullable = false, unique = true, length = 50)
    private String username;
    
    @Email(message = "Email must be valid")
    @NotBlank(message = "Email is required")
    @Column(nullable = false, unique = true, length = 255)
    private String email;
    
    @Column(name = "first_name", length = 100)
    private String firstName;
    
    @Column(name = "last_name", length = 100)
    private String lastName;
    
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private UserStatus status = UserStatus.ACTIVE;
    
    @Column(name = "created_at", nullable = false)
    private Instant createdAt;
    
    @Column(name = "updated_at")
    private Instant updatedAt;
    
    @Version
    private Long version;
    
    // Java 21 enum with enhanced features
    public enum UserStatus {
        ACTIVE("User is active and can use the system"),
        INACTIVE("User is temporarily inactive"),
        SUSPENDED("User is suspended due to violations"),
        DELETED("User account is marked for deletion");
        
        private final String description;
        
        UserStatus(String description) {
            this.description = description;
        }
        
        public String getDescription() {
            return description;
        }
        
        public boolean isActive() {
            return this == ACTIVE;
        }
    }
    
    // Constructors
    public User() {
        this.id = UUID.randomUUID();
        this.createdAt = Instant.now();
    }
    
    public User(String username, String email) {
        this();
        this.username = username;
        this.email = email;
    }
    
    // Builder pattern using Java 21 features
    public static Builder builder() {
        return new Builder();
    }
    
    public static class Builder {
        private final User user = new User();
        
        public Builder id(UUID id) {
            user.id = id;
            return this;
        }
        
        public Builder username(String username) {
            user.username = username;
            return this;
        }
        
        public Builder email(String email) {
            user.email = email;
            return this;
        }
        
        public Builder firstName(String firstName) {
            user.firstName = firstName;
            return this;
        }
        
        public Builder lastName(String lastName) {
            user.lastName = lastName;
            return this;
        }
        
        public Builder status(UserStatus status) {
            user.status = status;
            return this;
        }
        
        public User build() {
            return user;
        }
    }
    
    // JPA lifecycle callbacks
    @PrePersist
    protected void onCreate() {
        if (createdAt == null) {
            createdAt = Instant.now();
        }
        updatedAt = Instant.now();
    }
    
    @PreUpdate
    protected void onUpdate() {
        updatedAt = Instant.now();
    }
    
    // Business methods
    public void activate() {
        this.status = UserStatus.ACTIVE;
    }
    
    public void suspend(String reason) {
        this.status = UserStatus.SUSPENDED;
        // Log suspension reason
    }
    
    public void markDeleted() {
        this.status = UserStatus.DELETED;
    }
    
    public boolean canLogin() {
        return status.isActive();
    }
    
    public String getFullName() {
        return STR."\{firstName != null ? firstName : ""} \{lastName != null ? lastName : ""}".trim();
    }
    
    // Getters and Setters
    public UUID getId() { return id; }
    public void setId(UUID id) { this.id = id; }
    
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    
    public String getFirstName() { return firstName; }
    public void setFirstName(String firstName) { this.firstName = firstName; }
    
    public String getLastName() { return lastName; }
    public void setLastName(String lastName) { this.lastName = lastName; }
    
    public UserStatus getStatus() { return status; }
    public void setStatus(UserStatus status) { this.status = status; }
    
    public Instant getCreatedAt() { return createdAt; }
    public void setCreatedAt(Instant createdAt) { this.createdAt = createdAt; }
    
    public Instant getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(Instant updatedAt) { this.updatedAt = updatedAt; }
    
    public Long getVersion() { return version; }
    public void setVersion(Long version) { this.version = version; }
    
    @Override
    public String toString() {
        return STR."User{id=\{id}, username='\{username}', email='\{email}', status=\{status}}";
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        User user = (User) obj;
        return id != null && id.equals(user.id);
    }
    
    @Override
    public int hashCode() {
        return getClass().hashCode();
    }
}
