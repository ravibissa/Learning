package com.systemdesign.foundations.metrics;

import io.micrometer.core.instrument.*;
import io.micrometer.core.instrument.Timer;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.util.concurrent.atomic.AtomicLong;

/**
 * User service metrics for monitoring and observability
 * Demonstrates metrics patterns for system design
 */
@Component
public class UserMetrics {
    
    private final Counter userCreations;
    private final Counter userDeletions;
    private final Counter userLogins;
    private final Counter userLoginFailures;
    private final Timer userLookupTimer;
    private final Timer userCreationTimer;
    private final Gauge activeUsersGauge;
    private final DistributionSummary userOperationSummary;
    
    // For gauge tracking
    private final AtomicLong activeUserCount = new AtomicLong(0);
    
    public UserMetrics(MeterRegistry meterRegistry) {
        // Counters for business metrics
        this.userCreations = Counter.builder("users.created.total")
            .description("Total number of users created")
            .tag("service", "user-service")
            .register(meterRegistry);
        
        this.userDeletions = Counter.builder("users.deleted.total")
            .description("Total number of users deleted")
            .tag("service", "user-service")
            .register(meterRegistry);
        
        this.userLogins = Counter.builder("users.logins.total")
            .description("Total number of successful user logins")
            .tag("service", "user-service")
            .tag("status", "success")
            .register(meterRegistry);
        
        this.userLoginFailures = Counter.builder("users.logins.total")
            .description("Total number of failed user logins")
            .tag("service", "user-service")
            .tag("status", "failure")
            .register(meterRegistry);
        
        // Timers for performance metrics
        this.userLookupTimer = Timer.builder("users.lookup.duration")
            .description("Time taken to lookup users")
            .tag("service", "user-service")
            .register(meterRegistry);
        
        this.userCreationTimer = Timer.builder("users.creation.duration")
            .description("Time taken to create users")
            .tag("service", "user-service")
            .register(meterRegistry);
        
        // Gauge for current state
        this.activeUsersGauge = Gauge.builder("users.active.current")
            .description("Current number of active users")
            .tag("service", "user-service")
            .register(meterRegistry, this, UserMetrics::getActiveUserCount);
        
        // Distribution summary for operation analysis
        this.userOperationSummary = DistributionSummary.builder("users.operation.size")
            .description("Distribution of user operation sizes")
            .tag("service", "user-service")
            .register(meterRegistry);
    }
    
    // Counter methods
    public void recordUserCreation() {
        userCreations.increment();
        activeUserCount.incrementAndGet();
    }
    
    public void recordUserCreation(String userType) {
        Counter.builder("users.created.total")
            .tag("service", "user-service")
            .tag("type", userType)
            .register(Metrics.globalRegistry)
            .increment();
    }
    
    public void recordUserDeletion() {
        userDeletions.increment();
        activeUserCount.decrementAndGet();
    }
    
    public void recordUserLogin(boolean successful) {
        if (successful) {
            userLogins.increment();
        } else {
            userLoginFailures.increment();
        }
    }
    
    // Timer methods
    public Timer.Sample startLookupTimer() {
        return Timer.start();
    }
    
    public Timer getUserLookupTimer() {
        return userLookupTimer;
    }
    
    public Timer.Sample startCreationTimer() {
        return Timer.start();
    }
    
    public Timer getUserCreationTimer() {
        return userCreationTimer;
    }
    
    // Timed operation helpers
    public <T> T timeUserLookup(java.util.function.Supplier<T> operation) {
        return userLookupTimer.recordCallable(operation::get);
    }
    
    public <T> T timeUserCreation(java.util.function.Supplier<T> operation) {
        return userCreationTimer.recordCallable(operation::get);
    }
    
    // Distribution summary
    public void recordOperationSize(int size) {
        userOperationSummary.record(size);
    }
    
    // Gauge support
    public double getActiveUserCount() {
        return activeUserCount.get();
    }
    
    public void setActiveUserCount(long count) {
        activeUserCount.set(count);
    }
    
    // Custom metrics for specific business use cases
    public void recordUserRegistrationSource(String source) {
        Counter.builder("users.registration.source")
            .tag("source", source)
            .tag("service", "user-service")
            .register(Metrics.globalRegistry)
            .increment();
    }
    
    public void recordUserSessionDuration(Duration duration) {
        Timer.builder("users.session.duration")
            .tag("service", "user-service")
            .register(Metrics.globalRegistry)
            .record(duration);
    }
    
    public void recordUserErrorRate(String errorType) {
        Counter.builder("users.errors.total")
            .tag("error_type", errorType)
            .tag("service", "user-service")
            .register(Metrics.globalRegistry)
            .increment();
    }
    
    // Batch operation metrics
    public void recordBatchOperation(String operation, int batchSize, Duration duration) {
        Timer.builder("users.batch.duration")
            .tag("operation", operation)
            .tag("service", "user-service")
            .register(Metrics.globalRegistry)
            .record(duration);
        
        Gauge.builder("users.batch.size")
            .tag("operation", operation)
            .tag("service", "user-service")
            .register(Metrics.globalRegistry, batchSize, size -> size);
    }
    
    // Health check metrics
    public void recordHealthCheck(boolean healthy) {
        Gauge.builder("users.health.status")
            .tag("service", "user-service")
            .register(Metrics.globalRegistry, healthy ? 1 : 0, status -> status);
    }
    
    // SLA metrics
    public void recordSLAViolation(String slaType) {
        Counter.builder("users.sla.violations")
            .tag("sla_type", slaType)
            .tag("service", "user-service")
            .register(Metrics.globalRegistry)
            .increment();
    }
    
    // Cache metrics
    public void recordCacheHit() {
        Counter.builder("users.cache.hits")
            .tag("service", "user-service")
            .register(Metrics.globalRegistry)
            .increment();
    }
    
    public void recordCacheMiss() {
        Counter.builder("users.cache.misses")
            .tag("service", "user-service")
            .register(Metrics.globalRegistry)
            .increment();
    }
    
    public double getCacheHitRatio() {
        Counter hits = Metrics.globalRegistry.find("users.cache.hits").counter();
        Counter misses = Metrics.globalRegistry.find("users.cache.misses").counter();
        
        if (hits == null || misses == null) return 0.0;
        
        double totalHits = hits.count();
        double totalMisses = misses.count();
        double total = totalHits + totalMisses;
        
        return total > 0 ? totalHits / total : 0.0;
    }
    
    // Database metrics
    public void recordDatabaseOperation(String operation, Duration duration, boolean successful) {
        Timer.builder("users.database.operation.duration")
            .tag("operation", operation)
            .tag("service", "user-service")
            .register(Metrics.globalRegistry)
            .record(duration);
        
        Counter.builder("users.database.operations.total")
            .tag("operation", operation)
            .tag("status", successful ? "success" : "failure")
            .tag("service", "user-service")
            .register(Metrics.globalRegistry)
            .increment();
    }
}
