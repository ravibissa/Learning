package com.systemdesign.foundations.service;

import com.systemdesign.foundations.dto.CreateUserRequest;
import com.systemdesign.foundations.exception.UserNotFoundException;
import com.systemdesign.foundations.model.User;
import com.systemdesign.foundations.repository.UserRepository;
import com.systemdesign.foundations.resilience.RetryHandler;
import com.systemdesign.foundations.metrics.UserMetrics;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Duration;
import java.util.UUID;

/**
 * User service demonstrating scalability patterns and Java 21 features
 */
@Service
public class UserService {
    
    private static final Logger log = LoggerFactory.getLogger(UserService.class);
    
    private final UserRepository userRepository;
    private final RetryHandler retryHandler;
    private final UserMetrics userMetrics;
    
    @Autowired
    public UserService(UserRepository userRepository, 
                      RetryHandler retryHandler,
                      UserMetrics userMetrics) {
        this.userRepository = userRepository;
        this.retryHandler = retryHandler;
        this.userMetrics = userMetrics;
    }
    
    /**
     * Find user by ID with caching and retry logic
     */
    @Cacheable(value = "users", key = "#id")
    public User findById(UUID id) {
        log.debug("Finding user by id: {}", id);
        
        var timer = userMetrics.startLookupTimer();
        
        try {
            return retryHandler.executeWithRetry(
                () -> userRepository.findById(id)
                    .orElseThrow(() -> new UserNotFoundException(STR."User not found with id: \{id}")),
                3, // max retries
                Duration.ofMillis(100) // initial delay
            );
        } finally {
            timer.stop(userMetrics.getUserLookupTimer());
        }
    }
    
    /**
     * Find user by username with caching
     */
    @Cacheable(value = "users", key = "#username")
    public User findByUsername(String username) {
        log.debug("Finding user by username: {}", username);
        
        return userRepository.findByUsername(username)
            .orElseThrow(() -> new UserNotFoundException(STR."User not found with username: \{username}"));
    }
    
    /**
     * Create new user with validation and metrics
     */
    @Transactional
    public User createUser(CreateUserRequest request) {
        log.info("Creating user with username: {}", request.username());
        
        // Check for existing user
        if (userRepository.existsByUsername(request.username())) {
            throw new IllegalArgumentException(STR."Username already exists: \{request.username()}");
        }
        
        if (userRepository.existsByEmail(request.email())) {
            throw new IllegalArgumentException(STR."Email already exists: \{request.email()}");
        }
        
        // Create user entity
        User user = User.builder()
            .username(request.username())
            .email(request.email())
            .firstName(request.firstName())
            .lastName(request.lastName())
            .build();
        
        // Save user
        User savedUser = userRepository.save(user);
        
        // Record metrics
        userMetrics.recordUserCreation();
        
        log.info("User created successfully: {}", savedUser);
        return savedUser;
    }
    
    /**
     * Update user and invalidate cache
     */
    @Transactional
    @CacheEvict(value = "users", allEntries = true)
    public User updateUser(UUID id, CreateUserRequest request) {
        log.info("Updating user: {}", id);
        
        User user = findById(id);
        
        // Update fields
        user.setUsername(request.username());
        user.setEmail(request.email());
        user.setFirstName(request.firstName());
        user.setLastName(request.lastName());
        
        return userRepository.save(user);
    }
    
    /**
     * Delete user (soft delete)
     */
    @Transactional
    @CacheEvict(value = "users", key = "#id")
    public void deleteUser(UUID id) {
        log.info("Deleting user: {}", id);
        
        User user = findById(id);
        user.markDeleted();
        userRepository.save(user);
    }
    
    /**
     * Get paginated users
     */
    public Page<User> getUsers(Pageable pageable) {
        log.debug("Getting users with pagination: {}", pageable);
        return userRepository.findByStatusNot(User.UserStatus.DELETED, pageable);
    }
    
    /**
     * Get active user count for metrics
     */
    public long countActiveUsers() {
        return userRepository.countByStatus(User.UserStatus.ACTIVE);
    }
    
    /**
     * Batch user creation for load testing
     */
    @Transactional
    public void createUsersInBatch(int count) {
        log.info("Creating {} users in batch", count);
        
        for (int i = 0; i < count; i++) {
            try {
                CreateUserRequest request = new CreateUserRequest(
                    STR."user\{i}",
                    STR."user\{i}@example.com",
                    STR."First\{i}",
                    STR."Last\{i}"
                );
                createUser(request);
            } catch (Exception e) {
                log.warn("Failed to create user {}: {}", i, e.getMessage());
            }
        }
    }
    
    /**
     * Search users by partial name match
     */
    public Page<User> searchUsers(String query, Pageable pageable) {
        log.debug("Searching users with query: {}", query);
        
        if (query == null || query.trim().isEmpty()) {
            return getUsers(pageable);
        }
        
        String searchPattern = STR."%\{query.toLowerCase()}%";
        return userRepository.findByUsernameContainingIgnoreCaseOrEmailContainingIgnoreCase(
            query, query, pageable
        );
    }
}
