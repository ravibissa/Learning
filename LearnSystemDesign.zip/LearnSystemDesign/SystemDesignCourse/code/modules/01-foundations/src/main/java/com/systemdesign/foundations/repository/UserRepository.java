package com.systemdesign.foundations.repository;

import com.systemdesign.foundations.model.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;

/**
 * User repository with optimized queries for system design patterns
 */
@Repository
public interface UserRepository extends JpaRepository<User, UUID> {
    
    /**
     * Find user by username (used for authentication)
     */
    Optional<User> findByUsername(String username);
    
    /**
     * Find user by email (used for login and notifications)
     */
    Optional<User> findByEmail(String email);
    
    /**
     * Check if username already exists (for validation)
     */
    boolean existsByUsername(String username);
    
    /**
     * Check if email already exists (for validation)
     */
    boolean existsByEmail(String email);
    
    /**
     * Find users by status with pagination (for admin operations)
     */
    Page<User> findByStatusNot(User.UserStatus status, Pageable pageable);
    
    /**
     * Count active users (for metrics)
     */
    long countByStatus(User.UserStatus status);
    
    /**
     * Find users created in a time range (for analytics)
     */
    @Query("SELECT u FROM User u WHERE u.createdAt BETWEEN :startDate AND :endDate")
    Page<User> findByCreatedAtBetween(
        @Param("startDate") java.time.Instant startDate,
        @Param("endDate") java.time.Instant endDate,
        Pageable pageable
    );
    
    /**
     * Search users by partial name or email match (for search functionality)
     */
    Page<User> findByUsernameContainingIgnoreCaseOrEmailContainingIgnoreCase(
        String username, String email, Pageable pageable
    );
    
    /**
     * Find users by status for bulk operations
     */
    @Query("SELECT u FROM User u WHERE u.status = :status")
    Page<User> findByStatus(@Param("status") User.UserStatus status, Pageable pageable);
    
    /**
     * Update user status in bulk (for admin operations)
     */
    @Modifying
    @Query("UPDATE User u SET u.status = :newStatus WHERE u.status = :oldStatus")
    int updateStatusBulk(@Param("oldStatus") User.UserStatus oldStatus, 
                        @Param("newStatus") User.UserStatus newStatus);
    
    /**
     * Delete inactive users older than specified days
     */
    @Modifying
    @Query("DELETE FROM User u WHERE u.status = 'INACTIVE' AND u.updatedAt < :cutoffDate")
    int deleteInactiveUsersOlderThan(@Param("cutoffDate") java.time.Instant cutoffDate);
    
    /**
     * Get user statistics for dashboard
     */
    @Query("""
        SELECT 
            COUNT(*) as totalUsers,
            COUNT(CASE WHEN u.status = 'ACTIVE' THEN 1 END) as activeUsers,
            COUNT(CASE WHEN u.status = 'SUSPENDED' THEN 1 END) as suspendedUsers,
            COUNT(CASE WHEN u.createdAt > :sinceDate THEN 1 END) as newUsers
        FROM User u
        """)
    UserStats getUserStats(@Param("sinceDate") java.time.Instant sinceDate);
    
    /**
     * Interface for user statistics projection
     */
    interface UserStats {
        long getTotalUsers();
        long getActiveUsers(); 
        long getSuspendedUsers();
        long getNewUsers();
    }
}
