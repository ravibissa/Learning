package com.systemdesign.foundations;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * System Design Foundations Application
 * 
 * Demonstrates core concepts:
 * - Scalability patterns
 * - Reliability mechanisms
 * - Performance monitoring
 * - Java 21 features
 */
@SpringBootApplication
@EnableCaching
@EnableScheduling
public class FoundationsApplication {
    
    public static void main(String[] args) {
        SpringApplication.run(FoundationsApplication.class, args);
    }
}
