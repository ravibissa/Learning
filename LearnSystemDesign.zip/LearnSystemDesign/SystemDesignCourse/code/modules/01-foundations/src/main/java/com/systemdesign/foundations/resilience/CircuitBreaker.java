package com.systemdesign.foundations.resilience;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Supplier;

/**
 * Circuit Breaker implementation demonstrating fault tolerance patterns
 * States: CLOSED -> OPEN -> HALF_OPEN -> CLOSED
 */
@Component
public class CircuitBreaker {
    
    private static final Logger log = LoggerFactory.getLogger(CircuitBreaker.class);
    
    public enum State {
        CLOSED,    // Normal operation - requests flow through
        OPEN,      // Circuit is open - failing fast
        HALF_OPEN  // Testing if service has recovered
    }
    
    private final AtomicReference<State> state = new AtomicReference<>(State.CLOSED);
    private final AtomicInteger failureCount = new AtomicInteger(0);
    private final AtomicInteger successCount = new AtomicInteger(0);
    private final AtomicLong lastFailureTime = new AtomicLong(0);
    
    // Configuration
    private final int failureThreshold;
    private final long timeoutMillis;
    private final int halfOpenMaxCalls;
    
    public CircuitBreaker() {
        this(5, 60_000, 3); // Default: 5 failures, 60s timeout, 3 half-open calls
    }
    
    public CircuitBreaker(int failureThreshold, long timeoutMillis, int halfOpenMaxCalls) {
        this.failureThreshold = failureThreshold;
        this.timeoutMillis = timeoutMillis;
        this.halfOpenMaxCalls = halfOpenMaxCalls;
    }
    
    /**
     * Execute operation with circuit breaker protection
     */
    public <T> T execute(Supplier<T> operation) throws Exception {
        State currentState = state.get();
        
        // Check if we should attempt the operation
        switch (currentState) {
            case OPEN -> {
                if (shouldAttemptReset()) {
                    return executeInHalfOpenState(operation);
                } else {
                    throw new CircuitBreakerOpenException(
                        STR."Circuit breaker is OPEN. Failing fast. Last failure: \{Instant.ofEpochMilli(lastFailureTime.get())}"
                    );
                }
            }
            case HALF_OPEN -> {
                return executeInHalfOpenState(operation);
            }
            case CLOSED -> {
                return executeInClosedState(operation);
            }
        }
        
        throw new IllegalStateException(STR."Unknown circuit breaker state: \{currentState}");
    }
    
    private <T> T executeInClosedState(Supplier<T> operation) throws Exception {
        try {
            T result = operation.get();
            onSuccess();
            return result;
        } catch (Exception e) {
            onFailure();
            throw e;
        }
    }
    
    private <T> T executeInHalfOpenState(Supplier<T> operation) throws Exception {
        if (successCount.get() >= halfOpenMaxCalls) {
            // Transition to CLOSED if we've had enough successful calls
            transitionToClosed();
            return executeInClosedState(operation);
        }
        
        try {
            T result = operation.get();
            onSuccessInHalfOpen();
            return result;
        } catch (Exception e) {
            onFailureInHalfOpen();
            throw e;
        }
    }
    
    private boolean shouldAttemptReset() {
        long currentTime = System.currentTimeMillis();
        long timeSinceLastFailure = currentTime - lastFailureTime.get();
        boolean shouldReset = timeSinceLastFailure >= timeoutMillis;
        
        if (shouldReset && state.compareAndSet(State.OPEN, State.HALF_OPEN)) {
            log.info("Circuit breaker transitioning from OPEN to HALF_OPEN");
            successCount.set(0);
            return true;
        }
        
        return false;
    }
    
    private void onSuccess() {
        failureCount.set(0);
        if (state.get() == State.HALF_OPEN) {
            successCount.incrementAndGet();
        }
    }
    
    private void onSuccessInHalfOpen() {
        int currentSuccessCount = successCount.incrementAndGet();
        log.debug("Half-open state success count: {}/{}", currentSuccessCount, halfOpenMaxCalls);
        
        if (currentSuccessCount >= halfOpenMaxCalls) {
            transitionToClosed();
        }
    }
    
    private void onFailure() {
        int currentFailureCount = failureCount.incrementAndGet();
        lastFailureTime.set(System.currentTimeMillis());
        
        log.warn("Circuit breaker failure count: {}/{}", currentFailureCount, failureThreshold);
        
        if (currentFailureCount >= failureThreshold) {
            transitionToOpen();
        }
    }
    
    private void onFailureInHalfOpen() {
        lastFailureTime.set(System.currentTimeMillis());
        transitionToOpen();
    }
    
    private void transitionToOpen() {
        if (state.compareAndSet(State.CLOSED, State.OPEN) || 
            state.compareAndSet(State.HALF_OPEN, State.OPEN)) {
            log.warn("Circuit breaker transitioned to OPEN state");
        }
    }
    
    private void transitionToClosed() {
        if (state.compareAndSet(State.HALF_OPEN, State.CLOSED)) {
            log.info("Circuit breaker transitioned to CLOSED state");
            failureCount.set(0);
            successCount.set(0);
        }
    }
    
    // Monitoring methods
    public State getState() {
        return state.get();
    }
    
    public int getFailureCount() {
        return failureCount.get();
    }
    
    public int getSuccessCount() {
        return successCount.get();
    }
    
    public long getLastFailureTime() {
        return lastFailureTime.get();
    }
    
    public CircuitBreakerMetrics getMetrics() {
        return new CircuitBreakerMetrics(
            state.get(),
            failureCount.get(),
            successCount.get(),
            lastFailureTime.get(),
            failureThreshold,
            timeoutMillis
        );
    }
    
    // Metrics record
    public record CircuitBreakerMetrics(
        State state,
        int failureCount,
        int successCount,
        long lastFailureTime,
        int failureThreshold,
        long timeoutMillis
    ) {
        public boolean isHealthy() {
            return state == State.CLOSED;
        }
        
        public double getFailureRate() {
            int total = failureCount + successCount;
            return total == 0 ? 0.0 : (double) failureCount / total;
        }
    }
    
    public static class CircuitBreakerOpenException extends RuntimeException {
        public CircuitBreakerOpenException(String message) {
            super(message);
        }
    }
}
