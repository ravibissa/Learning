package com.systemdesign.foundations.controller;

import com.systemdesign.foundations.dto.CreateUserRequest;
import com.systemdesign.foundations.exception.UserNotFoundException;
import com.systemdesign.foundations.model.User;
import com.systemdesign.foundations.resilience.CircuitBreaker;
import com.systemdesign.foundations.service.UserService;
import io.micrometer.core.annotation.Counted;
import io.micrometer.core.annotation.Timed;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

/**
 * User REST Controller demonstrating system design patterns
 * - Circuit breaker for resilience
 * - Metrics and monitoring
 * - Proper error handling
 * - Pagination and sorting
 */
@RestController
@RequestMapping("/api/v1/users")
@CrossOrigin(origins = "*", maxAge = 3600)
public class UserController {
    
    private static final Logger log = LoggerFactory.getLogger(UserController.class);
    
    private final UserService userService;
    private final CircuitBreaker circuitBreaker;
    
    @Autowired
    public UserController(UserService userService, CircuitBreaker circuitBreaker) {
        this.userService = userService;
        this.circuitBreaker = circuitBreaker;
    }
    
    /**
     * Get user by ID with circuit breaker protection
     */
    @GetMapping("/{id}")
    @Timed(value = "user.get.duration", description = "Time taken to get user")
    @Counted(value = "user.get.requests", description = "Number of get user requests")
    public ResponseEntity<User> getUser(@PathVariable UUID id) {
        log.debug("Getting user with id: {}", id);
        
        try {
            User user = circuitBreaker.execute(() -> userService.findById(id));
            return ResponseEntity.ok(user);
            
        } catch (CircuitBreaker.CircuitBreakerOpenException e) {
            log.warn("Circuit breaker is open for user service: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE)
                .header("Retry-After", "60")
                .build();
                
        } catch (UserNotFoundException e) {
            log.info("User not found: {}", id);
            return ResponseEntity.notFound().build();
            
        } catch (Exception e) {
            log.error("Error getting user {}: {}", id, e.getMessage(), e);
            return ResponseEntity.internalServerError().build();
        }
    }
    
    /**
     * Create new user
     */
    @PostMapping
    @Timed(value = "user.create.duration", description = "Time taken to create user")
    @Counted(value = "user.create.requests", description = "Number of create user requests")
    public ResponseEntity<User> createUser(@Valid @RequestBody CreateUserRequest request) {
        log.info("Creating user with username: {}", request.username());
        
        try {
            User user = userService.createUser(request);
            return ResponseEntity.status(HttpStatus.CREATED).body(user);
            
        } catch (IllegalArgumentException e) {
            log.warn("Invalid user creation request: {}", e.getMessage());
            return ResponseEntity.badRequest().build();
            
        } catch (Exception e) {
            log.error("Error creating user: {}", e.getMessage(), e);
            return ResponseEntity.internalServerError().build();
        }
    }
    
    /**
     * Update user
     */
    @PutMapping("/{id}")
    @Timed(value = "user.update.duration", description = "Time taken to update user")
    public ResponseEntity<User> updateUser(
            @PathVariable UUID id,
            @Valid @RequestBody CreateUserRequest request) {
        
        log.info("Updating user: {}", id);
        
        try {
            User user = userService.updateUser(id, request);
            return ResponseEntity.ok(user);
            
        } catch (UserNotFoundException e) {
            return ResponseEntity.notFound().build();
            
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().build();
            
        } catch (Exception e) {
            log.error("Error updating user {}: {}", id, e.getMessage(), e);
            return ResponseEntity.internalServerError().build();
        }
    }
    
    /**
     * Delete user (soft delete)
     */
    @DeleteMapping("/{id}")
    @Timed(value = "user.delete.duration", description = "Time taken to delete user")
    public ResponseEntity<Void> deleteUser(@PathVariable UUID id) {
        log.info("Deleting user: {}", id);
        
        try {
            userService.deleteUser(id);
            return ResponseEntity.noContent().build();
            
        } catch (UserNotFoundException e) {
            return ResponseEntity.notFound().build();
            
        } catch (Exception e) {
            log.error("Error deleting user {}: {}", id, e.getMessage(), e);
            return ResponseEntity.internalServerError().build();
        }
    }
    
    /**
     * Get paginated list of users
     */
    @GetMapping
    @Timed(value = "user.list.duration", description = "Time taken to list users")
    public ResponseEntity<Page<User>> getUsers(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size,
            @RequestParam(defaultValue = "createdAt") String sortBy,
            @RequestParam(defaultValue = "desc") String sortDir) {
        
        log.debug("Getting users - page: {}, size: {}, sortBy: {}, sortDir: {}", 
            page, size, sortBy, sortDir);
        
        try {
            // Validate pagination parameters
            if (page < 0) page = 0;
            if (size <= 0 || size > 100) size = 20; // Cap at 100 for performance
            
            Sort.Direction direction = sortDir.equalsIgnoreCase("desc") ? 
                Sort.Direction.DESC : Sort.Direction.ASC;
            
            Pageable pageable = PageRequest.of(page, size, Sort.by(direction, sortBy));
            Page<User> users = userService.getUsers(pageable);
            
            return ResponseEntity.ok(users);
            
        } catch (Exception e) {
            log.error("Error getting users: {}", e.getMessage(), e);
            return ResponseEntity.internalServerError().build();
        }
    }
    
    /**
     * Search users by query
     */
    @GetMapping("/search")
    @Timed(value = "user.search.duration", description = "Time taken to search users")
    public ResponseEntity<Page<User>> searchUsers(
            @RequestParam String query,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        
        log.debug("Searching users with query: '{}', page: {}, size: {}", query, page, size);
        
        try {
            if (query == null || query.trim().length() < 2) {
                return ResponseEntity.badRequest().build();
            }
            
            Pageable pageable = PageRequest.of(page, size);
            Page<User> users = userService.searchUsers(query.trim(), pageable);
            
            return ResponseEntity.ok(users);
            
        } catch (Exception e) {
            log.error("Error searching users: {}", e.getMessage(), e);
            return ResponseEntity.internalServerError().build();
        }
    }
    
    /**
     * Get user by username (for authentication)
     */
    @GetMapping("/username/{username}")
    @Timed(value = "user.get.by.username.duration", description = "Time taken to get user by username")
    public ResponseEntity<User> getUserByUsername(@PathVariable String username) {
        log.debug("Getting user by username: {}", username);
        
        try {
            User user = userService.findByUsername(username);
            return ResponseEntity.ok(user);
            
        } catch (UserNotFoundException e) {
            return ResponseEntity.notFound().build();
            
        } catch (Exception e) {
            log.error("Error getting user by username {}: {}", username, e.getMessage(), e);
            return ResponseEntity.internalServerError().build();
        }
    }
    
    /**
     * Health check endpoint
     */
    @GetMapping("/health")
    public ResponseEntity<HealthStatus> health() {
        try {
            long activeUsers = userService.countActiveUsers();
            
            HealthStatus status = new HealthStatus(
                "UP",
                "User service is healthy",
                activeUsers,
                System.currentTimeMillis()
            );
            
            return ResponseEntity.ok(status);
            
        } catch (Exception e) {
            log.error("Health check failed: {}", e.getMessage(), e);
            
            HealthStatus status = new HealthStatus(
                "DOWN", 
                e.getMessage(),
                0L,
                System.currentTimeMillis()
            );
            
            return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body(status);
        }
    }
    
    /**
     * Batch create users (for testing/bulk operations)
     */
    @PostMapping("/batch")
    @Timed(value = "user.batch.create.duration", description = "Time taken to batch create users")
    public ResponseEntity<BatchResult> createUsersBatch(@RequestParam int count) {
        log.info("Creating {} users in batch", count);
        
        if (count <= 0 || count > 1000) {
            return ResponseEntity.badRequest().body(
                new BatchResult(false, "Count must be between 1 and 1000", 0)
            );
        }
        
        try {
            userService.createUsersInBatch(count);
            
            BatchResult result = new BatchResult(
                true, 
                STR."Successfully created \{count} users", 
                count
            );
            
            return ResponseEntity.ok(result);
            
        } catch (Exception e) {
            log.error("Error in batch user creation: {}", e.getMessage(), e);
            
            BatchResult result = new BatchResult(
                false, 
                e.getMessage(), 
                0
            );
            
            return ResponseEntity.internalServerError().body(result);
        }
    }
    
    // DTOs for responses
    public record HealthStatus(
        String status,
        String message,
        long activeUsers,
        long timestamp
    ) {}
    
    public record BatchResult(
        boolean success,
        String message,
        int processedCount
    ) {}
}
