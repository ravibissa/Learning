package com.systemdesign.foundations.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

/**
 * Java 21 Record for user creation request
 * Demonstrates modern Java features and validation
 */
public record CreateUserRequest(
    @NotBlank(message = "Username is required")
    @Size(min = 3, max = 50, message = "Username must be between 3 and 50 characters")
    String username,
    
    @Email(message = "Email must be valid")
    @NotBlank(message = "Email is required")
    String email,
    
    @Size(max = 100, message = "First name cannot exceed 100 characters")
    String firstName,
    
    @Size(max = 100, message = "Last name cannot exceed 100 characters")
    String lastName
) {
    
    // Compact constructor with validation
    public CreateUserRequest {
        // Trim whitespace
        if (username != null) {
            username = username.trim();
        }
        if (email != null) {
            email = email.trim().toLowerCase();
        }
        if (firstName != null) {
            firstName = firstName.trim();
        }
        if (lastName != null) {
            lastName = lastName.trim();
        }
    }
    
    // Helper methods
    public String getFullName() {
        return STR."\{firstName != null ? firstName : ""} \{lastName != null ? lastName : ""}".trim();
    }
    
    public boolean hasFullName() {
        return firstName != null && !firstName.isEmpty() && 
               lastName != null && !lastName.isEmpty();
    }
}
