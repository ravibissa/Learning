package com.systemdesign.common.config;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.cache.RedisCacheConfiguration;
import org.springframework.data.redis.cache.RedisCacheManager;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.GenericJackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.RedisSerializationContext;
import org.springframework.data.redis.serializer.StringRedisSerializer;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

/**
 * Redis cache configuration for system design applications
 * Provides optimized caching strategies for different use cases
 */
@Configuration
@EnableCaching
@ConditionalOnProperty(name = "app.features.caching-enabled", havingValue = "true", matchIfMissing = true)
public class CacheConfig {
    
    @Bean
    public CacheManager cacheManager(RedisConnectionFactory redisConnectionFactory) {
        RedisCacheConfiguration defaultCacheConfig = RedisCacheConfiguration.defaultCacheConfig()
            .entryTtl(Duration.ofMinutes(10))
            .disableCachingNullValues()
            .serializeKeysWith(RedisSerializationContext.SerializationPair
                .fromSerializer(new StringRedisSerializer()))
            .serializeValuesWith(RedisSerializationContext.SerializationPair
                .fromSerializer(new GenericJackson2JsonRedisSerializer()));
        
        // Configure different TTL for different caches
        Map<String, RedisCacheConfiguration> cacheConfigurations = new HashMap<>();
        
        // User cache - longer TTL for user data
        cacheConfigurations.put("users", defaultCacheConfig
            .entryTtl(Duration.ofMinutes(30)));
        
        // Session cache - shorter TTL for session data
        cacheConfigurations.put("sessions", defaultCacheConfig
            .entryTtl(Duration.ofMinutes(15)));
        
        // Metadata cache - very long TTL for rarely changing data
        cacheConfigurations.put("metadata", defaultCacheConfig
            .entryTtl(Duration.ofHours(6)));
        
        // Configuration cache - long TTL
        cacheConfigurations.put("configuration", defaultCacheConfig
            .entryTtl(Duration.ofHours(1)));
        
        // Statistics cache - medium TTL
        cacheConfigurations.put("statistics", defaultCacheConfig
            .entryTtl(Duration.ofMinutes(5)));
        
        // Rate limiting cache - very short TTL
        cacheConfigurations.put("rate-limits", defaultCacheConfig
            .entryTtl(Duration.ofMinutes(1)));
        
        // Search results cache - short TTL as data changes frequently
        cacheConfigurations.put("search-results", defaultCacheConfig
            .entryTtl(Duration.ofMinutes(2)));
        
        // Authentication tokens - secure short TTL
        cacheConfigurations.put("auth-tokens", defaultCacheConfig
            .entryTtl(Duration.ofMinutes(5)));
        
        return RedisCacheManager.builder(redisConnectionFactory)
            .cacheDefaults(defaultCacheConfig)
            .withInitialCacheConfigurations(cacheConfigurations)
            .build();
    }
    
    @Bean
    public RedisTemplate<String, Object> redisTemplate(RedisConnectionFactory redisConnectionFactory) {
        RedisTemplate<String, Object> template = new RedisTemplate<>();
        template.setConnectionFactory(redisConnectionFactory);
        
        // Use String serializer for keys
        template.setKeySerializer(new StringRedisSerializer());
        template.setHashKeySerializer(new StringRedisSerializer());
        
        // Use JSON serializer for values
        template.setValueSerializer(new GenericJackson2JsonRedisSerializer());
        template.setHashValueSerializer(new GenericJackson2JsonRedisSerializer());
        
        template.afterPropertiesSet();
        return template;
    }
    
    @Bean
    public RedisTemplate<String, String> stringRedisTemplate(RedisConnectionFactory redisConnectionFactory) {
        RedisTemplate<String, String> template = new RedisTemplate<>();
        template.setConnectionFactory(redisConnectionFactory);
        
        // Use String serializer for both keys and values
        template.setKeySerializer(new StringRedisSerializer());
        template.setValueSerializer(new StringRedisSerializer());
        template.setHashKeySerializer(new StringRedisSerializer());
        template.setHashValueSerializer(new StringRedisSerializer());
        
        template.afterPropertiesSet();
        return template;
    }
    
    /**
     * Custom cache configurations for specific patterns
     */
    @Configuration
    public static class CustomCacheConfigurations {
        
        /**
         * Cache configuration for frequently accessed, rarely changed data
         */
        public static RedisCacheConfiguration longTermCache() {
            return RedisCacheConfiguration.defaultCacheConfig()
                .entryTtl(Duration.ofHours(24))
                .disableCachingNullValues()
                .serializeKeysWith(RedisSerializationContext.SerializationPair
                    .fromSerializer(new StringRedisSerializer()))
                .serializeValuesWith(RedisSerializationContext.SerializationPair
                    .fromSerializer(new GenericJackson2JsonRedisSerializer()));
        }
        
        /**
         * Cache configuration for session-like data
         */
        public static RedisCacheConfiguration sessionCache() {
            return RedisCacheConfiguration.defaultCacheConfig()
                .entryTtl(Duration.ofMinutes(30))
                .disableCachingNullValues()
                .serializeKeysWith(RedisSerializationContext.SerializationPair
                    .fromSerializer(new StringRedisSerializer()))
                .serializeValuesWith(RedisSerializationContext.SerializationPair
                    .fromSerializer(new GenericJackson2JsonRedisSerializer()));
        }
        
        /**
         * Cache configuration for real-time data
         */
        public static RedisCacheConfiguration realTimeCache() {
            return RedisCacheConfiguration.defaultCacheConfig()
                .entryTtl(Duration.ofSeconds(30))
                .disableCachingNullValues()
                .serializeKeysWith(RedisSerializationContext.SerializationPair
                    .fromSerializer(new StringRedisSerializer()))
                .serializeValuesWith(RedisSerializationContext.SerializationPair
                    .fromSerializer(new GenericJackson2JsonRedisSerializer()));
        }
        
        /**
         * Cache configuration for analytics data
         */
        public static RedisCacheConfiguration analyticsCache() {
            return RedisCacheConfiguration.defaultCacheConfig()
                .entryTtl(Duration.ofMinutes(5))
                .disableCachingNullValues()
                .serializeKeysWith(RedisSerializationContext.SerializationPair
                    .fromSerializer(new StringRedisSerializer()))
                .serializeValuesWith(RedisSerializationContext.SerializationPair
                    .fromSerializer(new GenericJackson2JsonRedisSerializer()));
        }
    }
    
    /**
     * Cache key generators for consistent naming
     */
    public static class CacheKeys {
        
        public static String userKey(String userId) {
            return "user:" + userId;
        }
        
        public static String sessionKey(String sessionId) {
            return "session:" + sessionId;
        }
        
        public static String tokenKey(String token) {
            return "token:" + token;
        }
        
        public static String rateLimitKey(String clientId, String endpoint) {
            return "rate_limit:" + clientId + ":" + endpoint;
        }
        
        public static String searchKey(String query, int page, int size) {
            return "search:" + query.hashCode() + ":" + page + ":" + size;
        }
        
        public static String configKey(String configName) {
            return "config:" + configName;
        }
        
        public static String metricKey(String metricName, String timeWindow) {
            return "metric:" + metricName + ":" + timeWindow;
        }
    }
    
    /**
     * Cache utilities for common operations
     */
    public static class CacheUtils {
        
        /**
         * Generate cache key with timestamp for time-based caching
         */
        public static String timeBasedKey(String baseKey, Duration granularity) {
            long timeUnit = System.currentTimeMillis() / granularity.toMillis();
            return baseKey + ":" + timeUnit;
        }
        
        /**
         * Generate cache key with user context
         */
        public static String userContextKey(String userId, String operation) {
            return "user:" + userId + ":" + operation;
        }
        
        /**
         * Generate cache key for paginated results
         */
        public static String paginatedKey(String baseKey, int page, int size, String sortBy) {
            return baseKey + ":page:" + page + ":size:" + size + ":sort:" + sortBy;
        }
        
        /**
         * Generate cache key with multiple parameters
         */
        public static String multiParamKey(String baseKey, Object... params) {
            StringBuilder key = new StringBuilder(baseKey);
            for (Object param : params) {
                key.append(":").append(param);
            }
            return key.toString();
        }
    }
}
