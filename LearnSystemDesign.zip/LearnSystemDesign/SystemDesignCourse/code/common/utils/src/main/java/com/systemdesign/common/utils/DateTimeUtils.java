package com.systemdesign.common.utils;

import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.TimeZone;

/**
 * Utility class for date and time operations in distributed systems
 * Provides timezone-aware operations and common formatting patterns
 */
public final class DateTimeUtils {
    
    private DateTimeUtils() {
        // Utility class - prevent instantiation
    }
    
    // Common formatters
    public static final DateTimeFormatter ISO_INSTANT = DateTimeFormatter.ISO_INSTANT;
    public static final DateTimeFormatter ISO_LOCAL_DATE = DateTimeFormatter.ISO_LOCAL_DATE;
    public static final DateTimeFormatter ISO_LOCAL_DATE_TIME = DateTimeFormatter.ISO_LOCAL_DATE_TIME;
    public static final DateTimeFormatter HUMAN_READABLE = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    public static final DateTimeFormatter FILE_SAFE = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss");
    
    /**
     * Get current UTC instant
     */
    public static Instant nowUtc() {
        return Instant.now();
    }
    
    /**
     * Get current time in specified timezone
     */
    public static ZonedDateTime nowInTimezone(String timezoneId) {
        return ZonedDateTime.now(ZoneId.of(timezoneId));
    }
    
    /**
     * Convert instant to timezone-aware datetime
     */
    public static ZonedDateTime toTimezone(Instant instant, String timezoneId) {
        return instant.atZone(ZoneId.of(timezoneId));
    }
    
    /**
     * Parse ISO instant string to Instant
     */
    public static Instant parseInstant(String instantString) {
        return Instant.parse(instantString);
    }
    
    /**
     * Format instant as ISO string
     */
    public static String formatInstant(Instant instant) {
        return instant.toString();
    }
    
    /**
     * Format instant for human reading
     */
    public static String formatHumanReadable(Instant instant) {
        return HUMAN_READABLE.format(instant.atZone(ZoneId.systemDefault()));
    }
    
    /**
     * Format instant for human reading in specific timezone
     */
    public static String formatHumanReadable(Instant instant, String timezoneId) {
        return HUMAN_READABLE.format(instant.atZone(ZoneId.of(timezoneId)));
    }
    
    /**
     * Calculate duration between two instants
     */
    public static Duration durationBetween(Instant start, Instant end) {
        return Duration.between(start, end);
    }
    
    /**
     * Calculate duration in human-readable format
     */
    public static String formatDuration(Duration duration) {
        long hours = duration.toHours();
        long minutes = duration.toMinutesPart();
        long seconds = duration.toSecondsPart();
        long millis = duration.toMillisPart();
        
        if (hours > 0) {
            return String.format("%dh %dm %ds", hours, minutes, seconds);
        } else if (minutes > 0) {
            return String.format("%dm %ds", minutes, seconds);
        } else if (seconds > 0) {
            return String.format("%d.%03ds", seconds, millis);
        } else {
            return String.format("%dms", millis);
        }
    }
    
    /**
     * Check if instant is within the last N minutes
     */
    public static boolean isWithinLastMinutes(Instant instant, int minutes) {
        Instant cutoff = nowUtc().minus(minutes, ChronoUnit.MINUTES);
        return instant.isAfter(cutoff);
    }
    
    /**
     * Check if instant is within the last N hours
     */
    public static boolean isWithinLastHours(Instant instant, int hours) {
        Instant cutoff = nowUtc().minus(hours, ChronoUnit.HOURS);
        return instant.isAfter(cutoff);
    }
    
    /**
     * Check if instant is within the last N days
     */
    public static boolean isWithinLastDays(Instant instant, int days) {
        Instant cutoff = nowUtc().minus(days, ChronoUnit.DAYS);
        return instant.isAfter(cutoff);
    }
    
    /**
     * Get start of day in UTC
     */
    public static Instant startOfDayUtc(LocalDate date) {
        return date.atStartOfDay(ZoneOffset.UTC).toInstant();
    }
    
    /**
     * Get end of day in UTC
     */
    public static Instant endOfDayUtc(LocalDate date) {
        return date.atTime(23, 59, 59, 999_999_999).atZone(ZoneOffset.UTC).toInstant();
    }
    
    /**
     * Get start of day in specific timezone
     */
    public static Instant startOfDay(LocalDate date, String timezoneId) {
        return date.atStartOfDay(ZoneId.of(timezoneId)).toInstant();
    }
    
    /**
     * Get end of day in specific timezone
     */
    public static Instant endOfDay(LocalDate date, String timezoneId) {
        return date.atTime(23, 59, 59, 999_999_999).atZone(ZoneId.of(timezoneId)).toInstant();
    }
    
    /**
     * Convert timezone ID to offset for given instant
     */
    public static ZoneOffset getOffset(String timezoneId, Instant instant) {
        return ZoneId.of(timezoneId).getRules().getOffset(instant);
    }
    
    /**
     * Check if two instants are on the same day in UTC
     */
    public static boolean isSameDayUtc(Instant instant1, Instant instant2) {
        LocalDate date1 = instant1.atZone(ZoneOffset.UTC).toLocalDate();
        LocalDate date2 = instant2.atZone(ZoneOffset.UTC).toLocalDate();
        return date1.equals(date2);
    }
    
    /**
     * Check if two instants are on the same day in specified timezone
     */
    public static boolean isSameDay(Instant instant1, Instant instant2, String timezoneId) {
        ZoneId zone = ZoneId.of(timezoneId);
        LocalDate date1 = instant1.atZone(zone).toLocalDate();
        LocalDate date2 = instant2.atZone(zone).toLocalDate();
        return date1.equals(date2);
    }
    
    /**
     * Get epoch seconds for instant
     */
    public static long toEpochSeconds(Instant instant) {
        return instant.getEpochSecond();
    }
    
    /**
     * Get epoch milliseconds for instant
     */
    public static long toEpochMillis(Instant instant) {
        return instant.toEpochMilli();
    }
    
    /**
     * Create instant from epoch seconds
     */
    public static Instant fromEpochSeconds(long epochSeconds) {
        return Instant.ofEpochSecond(epochSeconds);
    }
    
    /**
     * Create instant from epoch milliseconds
     */
    public static Instant fromEpochMillis(long epochMillis) {
        return Instant.ofEpochMilli(epochMillis);
    }
    
    /**
     * Add duration to instant
     */
    public static Instant addDuration(Instant instant, Duration duration) {
        return instant.plus(duration);
    }
    
    /**
     * Subtract duration from instant
     */
    public static Instant subtractDuration(Instant instant, Duration duration) {
        return instant.minus(duration);
    }
    
    /**
     * Round instant to nearest hour
     */
    public static Instant roundToHour(Instant instant) {
        return instant.truncatedTo(ChronoUnit.HOURS);
    }
    
    /**
     * Round instant to nearest minute
     */
    public static Instant roundToMinute(Instant instant) {
        return instant.truncatedTo(ChronoUnit.MINUTES);
    }
    
    /**
     * Round instant to nearest second
     */
    public static Instant roundToSecond(Instant instant) {
        return instant.truncatedTo(ChronoUnit.SECONDS);
    }
    
    /**
     * Get all supported timezone IDs
     */
    public static java.util.Set<String> getAllTimezoneIds() {
        return ZoneId.getAvailableZoneIds();
    }
    
    /**
     * Validate timezone ID
     */
    public static boolean isValidTimezone(String timezoneId) {
        try {
            ZoneId.of(timezoneId);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
    
    /**
     * Get system default timezone
     */
    public static String getSystemTimezone() {
        return ZoneId.systemDefault().getId();
    }
    
    /**
     * Time range utility class
     */
    public static class TimeRange {
        private final Instant start;
        private final Instant end;
        
        public TimeRange(Instant start, Instant end) {
            if (start.isAfter(end)) {
                throw new IllegalArgumentException("Start time must be before end time");
            }
            this.start = start;
            this.end = end;
        }
        
        public static TimeRange of(Instant start, Instant end) {
            return new TimeRange(start, end);
        }
        
        public static TimeRange lastHours(int hours) {
            Instant end = nowUtc();
            Instant start = end.minus(hours, ChronoUnit.HOURS);
            return new TimeRange(start, end);
        }
        
        public static TimeRange lastDays(int days) {
            Instant end = nowUtc();
            Instant start = end.minus(days, ChronoUnit.DAYS);
            return new TimeRange(start, end);
        }
        
        public static TimeRange today() {
            LocalDate today = LocalDate.now();
            return new TimeRange(startOfDayUtc(today), endOfDayUtc(today));
        }
        
        public static TimeRange yesterday() {
            LocalDate yesterday = LocalDate.now().minusDays(1);
            return new TimeRange(startOfDayUtc(yesterday), endOfDayUtc(yesterday));
        }
        
        public Instant getStart() {
            return start;
        }
        
        public Instant getEnd() {
            return end;
        }
        
        public Duration getDuration() {
            return Duration.between(start, end);
        }
        
        public boolean contains(Instant instant) {
            return !instant.isBefore(start) && !instant.isAfter(end);
        }
        
        public boolean overlaps(TimeRange other) {
            return !this.end.isBefore(other.start) && !this.start.isAfter(other.end);
        }
        
        @Override
        public String toString() {
            return String.format("TimeRange{start=%s, end=%s, duration=%s}", 
                start, end, formatDuration(getDuration()));
        }
    }
}
