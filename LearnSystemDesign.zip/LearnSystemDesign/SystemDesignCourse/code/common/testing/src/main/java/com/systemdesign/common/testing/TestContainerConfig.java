package com.systemdesign.common.testing;

import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.test.context.DynamicPropertySource;
import org.testcontainers.containers.GenericContainer;
import org.testcontainers.containers.KafkaContainer;
import org.testcontainers.containers.PostgreSQLContainer;
import org.testcontainers.utility.DockerImageName;

import javax.sql.DataSource;
import org.springframework.boot.jdbc.DataSourceBuilder;

/**
 * TestContainers configuration for integration tests
 * Provides containerized infrastructure for testing
 */
@TestConfiguration
public class TestContainerConfig {
    
    // PostgreSQL Test Container
    public static final PostgreSQLContainer<?> POSTGRES_CONTAINER = 
        new PostgreSQLContainer<>("postgres:15-alpine")
            .withDatabaseName("testdb")
            .withUsername("test")
            .withPassword("test")
            .withReuse(true);
    
    // Redis Test Container
    public static final GenericContainer<?> REDIS_CONTAINER = 
        new GenericContainer<>("redis:7-alpine")
            .withExposedPorts(6379)
            .withReuse(true);
    
    // Kafka Test Container
    public static final KafkaContainer KAFKA_CONTAINER = 
        new KafkaContainer(DockerImageName.parse("confluentinc/cp-kafka:latest"))
            .withReuse(true);
    
    // Elasticsearch Test Container
    public static final GenericContainer<?> ELASTICSEARCH_CONTAINER = 
        new GenericContainer<>("docker.elastic.co/elasticsearch/elasticsearch:8.11.0")
            .withExposedPorts(9200)
            .withEnv("discovery.type", "single-node")
            .withEnv("xpack.security.enabled", "false")
            .withEnv("ES_JAVA_OPTS", "-Xms512m -Xmx512m")
            .withReuse(true);
    
    // Zipkin Test Container for tracing
    public static final GenericContainer<?> ZIPKIN_CONTAINER = 
        new GenericContainer<>("openzipkin/zipkin:latest")
            .withExposedPorts(9411)
            .withReuse(true);
    
    // Prometheus Test Container
    public static final GenericContainer<?> PROMETHEUS_CONTAINER = 
        new GenericContainer<>("prom/prometheus:latest")
            .withExposedPorts(9090)
            .withReuse(true);
    
    static {
        // Start all containers
        POSTGRES_CONTAINER.start();
        REDIS_CONTAINER.start();
        KAFKA_CONTAINER.start();
        ELASTICSEARCH_CONTAINER.start();
        ZIPKIN_CONTAINER.start();
        PROMETHEUS_CONTAINER.start();
    }
    
    @Bean
    @Primary
    public DataSource testDataSource() {
        return DataSourceBuilder.create()
            .url(POSTGRES_CONTAINER.getJdbcUrl())
            .username(POSTGRES_CONTAINER.getUsername())
            .password(POSTGRES_CONTAINER.getPassword())
            .driverClassName(POSTGRES_CONTAINER.getDriverClassName())
            .build();
    }
    
    /**
     * Configure test properties dynamically
     */
    @DynamicPropertySource
    public static void configureProperties(org.springframework.test.context.DynamicPropertyRegistry registry) {
        // Database properties
        registry.add("spring.datasource.url", POSTGRES_CONTAINER::getJdbcUrl);
        registry.add("spring.datasource.username", POSTGRES_CONTAINER::getUsername);
        registry.add("spring.datasource.password", POSTGRES_CONTAINER::getPassword);
        
        // Redis properties
        registry.add("spring.redis.host", REDIS_CONTAINER::getHost);
        registry.add("spring.redis.port", REDIS_CONTAINER::getFirstMappedPort);
        
        // Kafka properties
        registry.add("spring.kafka.bootstrap-servers", KAFKA_CONTAINER::getBootstrapServers);
        
        // Elasticsearch properties
        registry.add("spring.elasticsearch.uris", () -> 
            "http://" + ELASTICSEARCH_CONTAINER.getHost() + ":" + ELASTICSEARCH_CONTAINER.getFirstMappedPort());
        
        // Zipkin properties
        registry.add("spring.zipkin.base-url", () -> 
            "http://" + ZIPKIN_CONTAINER.getHost() + ":" + ZIPKIN_CONTAINER.getFirstMappedPort());
        
        // Test-specific properties
        registry.add("spring.jpa.hibernate.ddl-auto", () -> "create-drop");
        registry.add("spring.jpa.show-sql", () -> "true");
        registry.add("logging.level.org.testcontainers", () -> "INFO");
        registry.add("logging.level.com.github.dockerjava", () -> "WARN");
    }
    
    /**
     * Utility methods for test setup
     */
    public static class TestHelper {
        
        public static String getPostgresJdbcUrl() {
            return POSTGRES_CONTAINER.getJdbcUrl();
        }
        
        public static String getRedisHost() {
            return REDIS_CONTAINER.getHost();
        }
        
        public static Integer getRedisPort() {
            return REDIS_CONTAINER.getFirstMappedPort();
        }
        
        public static String getKafkaBootstrapServers() {
            return KAFKA_CONTAINER.getBootstrapServers();
        }
        
        public static String getElasticsearchUrl() {
            return "http://" + ELASTICSEARCH_CONTAINER.getHost() + ":" + 
                   ELASTICSEARCH_CONTAINER.getFirstMappedPort();
        }
        
        public static String getZipkinUrl() {
            return "http://" + ZIPKIN_CONTAINER.getHost() + ":" + 
                   ZIPKIN_CONTAINER.getFirstMappedPort();
        }
        
        public static void waitForContainers() {
            // Additional health checks if needed
            try {
                Thread.sleep(2000); // Allow containers to fully start
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
        
        public static void cleanupDatabase() {
            // Cleanup operations between tests if needed
        }
    }
}
