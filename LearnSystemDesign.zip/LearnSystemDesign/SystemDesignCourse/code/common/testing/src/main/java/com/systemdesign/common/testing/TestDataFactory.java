package com.systemdesign.common.testing;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.IntStream;

/**
 * Factory for creating test data
 * Provides realistic test data for various entities
 */
@Component
public class TestDataFactory {
    
    private static final List<String> FIRST_NAMES = List.of(
        "John", "Jane", "Michael", "Sarah", "David", "Emily", "James", "Ashley",
        "Robert", "Jessica", "William", "Amanda", "Christopher", "Stephanie", 
        "Matthew", "Melissa", "Anthony", "Nicole", "Mark", "Elizabeth"
    );
    
    private static final List<String> LAST_NAMES = List.of(
        "Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller",
        "Davis", "Rodriguez", "Martinez", "Hernandez", "Lopez", "Gonzalez",
        "Wilson", "Anderson", "Thomas", "Taylor", "Moore", "Jackson", "Martin"
    );
    
    private static final List<String> EMAIL_DOMAINS = List.of(
        "gmail.com", "yahoo.com", "hotmail.com", "outlook.com", "company.com",
        "test.com", "example.org", "mail.com", "email.com", "domain.net"
    );
    
    private static final List<String> PRODUCT_CATEGORIES = List.of(
        "Electronics", "Clothing", "Books", "Home & Garden", "Sports",
        "Automotive", "Health & Beauty", "Food & Grocery", "Toys", "Music"
    );
    
    private static final List<String> PRODUCT_ADJECTIVES = List.of(
        "Premium", "Professional", "Deluxe", "Standard", "Basic", "Advanced",
        "Ultra", "Super", "Mega", "Pro", "Elite", "Classic", "Modern", "Smart"
    );
    
    private final Random random = new Random();
    private final ObjectMapper objectMapper = new ObjectMapper();
    
    /**
     * Generate test user data
     */
    public TestUser createUser() {
        String firstName = randomElement(FIRST_NAMES);
        String lastName = randomElement(LAST_NAMES);
        String username = (firstName + "." + lastName + random.nextInt(1000)).toLowerCase();
        String email = username + "@" + randomElement(EMAIL_DOMAINS);
        
        return TestUser.builder()
            .id(UUID.randomUUID().toString())
            .username(username)
            .email(email)
            .firstName(firstName)
            .lastName(lastName)
            .status("ACTIVE")
            .createdAt(randomPastInstant())
            .build();
    }
    
    /**
     * Generate multiple test users
     */
    public List<TestUser> createUsers(int count) {
        return IntStream.range(0, count)
            .mapToObj(i -> createUser())
            .toList();
    }
    
    /**
     * Generate test product data
     */
    public TestProduct createProduct() {
        String adjective = randomElement(PRODUCT_ADJECTIVES);
        String category = randomElement(PRODUCT_CATEGORIES);
        String name = adjective + " " + category + " Item";
        
        return TestProduct.builder()
            .id(UUID.randomUUID().toString())
            .name(name)
            .description("High quality " + name.toLowerCase() + " for all your needs")
            .category(category)
            .price(randomPrice())
            .inStock(random.nextBoolean())
            .stockQuantity(random.nextInt(1000))
            .createdAt(randomPastInstant())
            .build();
    }
    
    /**
     * Generate test order data
     */
    public TestOrder createOrder(String userId) {
        int itemCount = random.nextInt(5) + 1;
        List<TestOrderItem> items = IntStream.range(0, itemCount)
            .mapToObj(i -> createOrderItem())
            .toList();
        
        double totalAmount = items.stream()
            .mapToDouble(item -> item.getPrice() * item.getQuantity())
            .sum();
        
        return TestOrder.builder()
            .id(UUID.randomUUID().toString())
            .userId(userId)
            .items(items)
            .totalAmount(totalAmount)
            .status(randomOrderStatus())
            .createdAt(randomPastInstant())
            .build();
    }
    
    /**
     * Generate test order item
     */
    public TestOrderItem createOrderItem() {
        TestProduct product = createProduct();
        int quantity = random.nextInt(10) + 1;
        
        return TestOrderItem.builder()
            .productId(product.getId())
            .productName(product.getName())
            .quantity(quantity)
            .price(product.getPrice())
            .build();
    }
    
    /**
     * Generate test event data
     */
    public TestEvent createEvent(String aggregateId, String eventType) {
        Map<String, Object> eventData = Map.of(
            "timestamp", Instant.now().toString(),
            "version", random.nextInt(10) + 1,
            "metadata", Map.of(
                "source", "test-service",
                "correlationId", UUID.randomUUID().toString()
            )
        );
        
        return TestEvent.builder()
            .id(UUID.randomUUID().toString())
            .aggregateId(aggregateId)
            .eventType(eventType)
            .eventData(eventData)
            .version(random.nextLong())
            .occurredAt(Instant.now())
            .build();
    }
    
    /**
     * Generate test metrics data
     */
    public TestMetric createMetric(String metricName) {
        return TestMetric.builder()
            .name(metricName)
            .value(random.nextDouble() * 100)
            .timestamp(Instant.now())
            .tags(Map.of(
                "service", "test-service",
                "environment", "test",
                "instance", "test-" + random.nextInt(10)
            ))
            .build();
    }
    
    /**
     * Generate load test data
     */
    public List<TestRequest> createLoadTestRequests(int count, String endpoint) {
        return IntStream.range(0, count)
            .mapToObj(i -> TestRequest.builder()
                .id(UUID.randomUUID().toString())
                .endpoint(endpoint)
                .method("GET")
                .userId("user-" + random.nextInt(1000))
                .timestamp(Instant.now().plusMillis(i * 10)) // Spread over time
                .responseTime(random.nextInt(500) + 50) // 50-550ms
                .statusCode(randomStatusCode())
                .build())
            .toList();
    }
    
    /**
     * Create test data for specific scenarios
     */
    public TestScenario createConcurrencyTestScenario() {
        return TestScenario.builder()
            .name("Concurrency Test")
            .users(createUsers(100))
            .products(createProducts(50))
            .concurrentRequests(50)
            .testDuration(60) // seconds
            .build();
    }
    
    public TestScenario createPerformanceTestScenario() {
        return TestScenario.builder()
            .name("Performance Test")
            .users(createUsers(1000))
            .products(createProducts(200))
            .concurrentRequests(200)
            .testDuration(300) // 5 minutes
            .build();
    }
    
    /**
     * Generate synthetic data for machine learning tests
     */
    public List<TestDataPoint> createMLTestData(int count) {
        return IntStream.range(0, count)
            .mapToObj(i -> TestDataPoint.builder()
                .features(generateFeatureVector())
                .label(random.nextDouble() > 0.5 ? "positive" : "negative")
                .confidence(random.nextDouble())
                .build())
            .toList();
    }
    
    // Helper methods
    private <T> T randomElement(List<T> list) {
        return list.get(random.nextInt(list.size()));
    }
    
    private Instant randomPastInstant() {
        long daysBack = random.nextInt(365);
        return Instant.now().minusSeconds(daysBack * 24 * 60 * 60);
    }
    
    private double randomPrice() {
        return Math.round((random.nextDouble() * 1000 + 10) * 100.0) / 100.0;
    }
    
    private String randomOrderStatus() {
        List<String> statuses = List.of("CREATED", "PAID", "SHIPPED", "DELIVERED", "CANCELLED");
        return randomElement(statuses);
    }
    
    private int randomStatusCode() {
        List<Integer> codes = List.of(200, 200, 200, 201, 400, 404, 500); // Weighted towards success
        return randomElement(codes);
    }
    
    private List<TestProduct> createProducts(int count) {
        return IntStream.range(0, count)
            .mapToObj(i -> createProduct())
            .toList();
    }
    
    private Map<String, Double> generateFeatureVector() {
        Map<String, Double> features = new HashMap<>();
        for (int i = 0; i < 10; i++) {
            features.put("feature_" + i, random.nextGaussian());
        }
        return features;
    }
    
    // Data classes for testing
    public static class TestUser {
        private String id;
        private String username;
        private String email;
        private String firstName;
        private String lastName;
        private String status;
        private Instant createdAt;
        
        // Builder pattern implementation
        public static Builder builder() { return new Builder(); }
        
        public static class Builder {
            private TestUser user = new TestUser();
            public Builder id(String id) { user.id = id; return this; }
            public Builder username(String username) { user.username = username; return this; }
            public Builder email(String email) { user.email = email; return this; }
            public Builder firstName(String firstName) { user.firstName = firstName; return this; }
            public Builder lastName(String lastName) { user.lastName = lastName; return this; }
            public Builder status(String status) { user.status = status; return this; }
            public Builder createdAt(Instant createdAt) { user.createdAt = createdAt; return this; }
            public TestUser build() { return user; }
        }
        
        // Getters
        public String getId() { return id; }
        public String getUsername() { return username; }
        public String getEmail() { return email; }
        public String getFirstName() { return firstName; }
        public String getLastName() { return lastName; }
        public String getStatus() { return status; }
        public Instant getCreatedAt() { return createdAt; }
    }
    
    public static class TestProduct {
        private String id;
        private String name;
        private String description;
        private String category;
        private double price;
        private boolean inStock;
        private int stockQuantity;
        private Instant createdAt;
        
        public static Builder builder() { return new Builder(); }
        
        public static class Builder {
            private TestProduct product = new TestProduct();
            public Builder id(String id) { product.id = id; return this; }
            public Builder name(String name) { product.name = name; return this; }
            public Builder description(String description) { product.description = description; return this; }
            public Builder category(String category) { product.category = category; return this; }
            public Builder price(double price) { product.price = price; return this; }
            public Builder inStock(boolean inStock) { product.inStock = inStock; return this; }
            public Builder stockQuantity(int stockQuantity) { product.stockQuantity = stockQuantity; return this; }
            public Builder createdAt(Instant createdAt) { product.createdAt = createdAt; return this; }
            public TestProduct build() { return product; }
        }
        
        public String getId() { return id; }
        public String getName() { return name; }
        public String getDescription() { return description; }
        public String getCategory() { return category; }
        public double getPrice() { return price; }
        public boolean isInStock() { return inStock; }
        public int getStockQuantity() { return stockQuantity; }
        public Instant getCreatedAt() { return createdAt; }
    }
    
    public static class TestOrder {
        private String id;
        private String userId;
        private List<TestOrderItem> items;
        private double totalAmount;
        private String status;
        private Instant createdAt;
        
        public static Builder builder() { return new Builder(); }
        
        public static class Builder {
            private TestOrder order = new TestOrder();
            public Builder id(String id) { order.id = id; return this; }
            public Builder userId(String userId) { order.userId = userId; return this; }
            public Builder items(List<TestOrderItem> items) { order.items = items; return this; }
            public Builder totalAmount(double totalAmount) { order.totalAmount = totalAmount; return this; }
            public Builder status(String status) { order.status = status; return this; }
            public Builder createdAt(Instant createdAt) { order.createdAt = createdAt; return this; }
            public TestOrder build() { return order; }
        }
        
        public String getId() { return id; }
        public String getUserId() { return userId; }
        public List<TestOrderItem> getItems() { return items; }
        public double getTotalAmount() { return totalAmount; }
        public String getStatus() { return status; }
        public Instant getCreatedAt() { return createdAt; }
    }
    
    public static class TestOrderItem {
        private String productId;
        private String productName;
        private int quantity;
        private double price;
        
        public static Builder builder() { return new Builder(); }
        
        public static class Builder {
            private TestOrderItem item = new TestOrderItem();
            public Builder productId(String productId) { item.productId = productId; return this; }
            public Builder productName(String productName) { item.productName = productName; return this; }
            public Builder quantity(int quantity) { item.quantity = quantity; return this; }
            public Builder price(double price) { item.price = price; return this; }
            public TestOrderItem build() { return item; }
        }
        
        public String getProductId() { return productId; }
        public String getProductName() { return productName; }
        public int getQuantity() { return quantity; }
        public double getPrice() { return price; }
    }
    
    public static class TestEvent {
        private String id;
        private String aggregateId;
        private String eventType;
        private Map<String, Object> eventData;
        private long version;
        private Instant occurredAt;
        
        public static Builder builder() { return new Builder(); }
        
        public static class Builder {
            private TestEvent event = new TestEvent();
            public Builder id(String id) { event.id = id; return this; }
            public Builder aggregateId(String aggregateId) { event.aggregateId = aggregateId; return this; }
            public Builder eventType(String eventType) { event.eventType = eventType; return this; }
            public Builder eventData(Map<String, Object> eventData) { event.eventData = eventData; return this; }
            public Builder version(long version) { event.version = version; return this; }
            public Builder occurredAt(Instant occurredAt) { event.occurredAt = occurredAt; return this; }
            public TestEvent build() { return event; }
        }
        
        public String getId() { return id; }
        public String getAggregateId() { return aggregateId; }
        public String getEventType() { return eventType; }
        public Map<String, Object> getEventData() { return eventData; }
        public long getVersion() { return version; }
        public Instant getOccurredAt() { return occurredAt; }
    }
    
    public static class TestMetric {
        private String name;
        private double value;
        private Instant timestamp;
        private Map<String, String> tags;
        
        public static Builder builder() { return new Builder(); }
        
        public static class Builder {
            private TestMetric metric = new TestMetric();
            public Builder name(String name) { metric.name = name; return this; }
            public Builder value(double value) { metric.value = value; return this; }
            public Builder timestamp(Instant timestamp) { metric.timestamp = timestamp; return this; }
            public Builder tags(Map<String, String> tags) { metric.tags = tags; return this; }
            public TestMetric build() { return metric; }
        }
        
        public String getName() { return name; }
        public double getValue() { return value; }
        public Instant getTimestamp() { return timestamp; }
        public Map<String, String> getTags() { return tags; }
    }
    
    public static class TestRequest {
        private String id;
        private String endpoint;
        private String method;
        private String userId;
        private Instant timestamp;
        private int responseTime;
        private int statusCode;
        
        public static Builder builder() { return new Builder(); }
        
        public static class Builder {
            private TestRequest request = new TestRequest();
            public Builder id(String id) { request.id = id; return this; }
            public Builder endpoint(String endpoint) { request.endpoint = endpoint; return this; }
            public Builder method(String method) { request.method = method; return this; }
            public Builder userId(String userId) { request.userId = userId; return this; }
            public Builder timestamp(Instant timestamp) { request.timestamp = timestamp; return this; }
            public Builder responseTime(int responseTime) { request.responseTime = responseTime; return this; }
            public Builder statusCode(int statusCode) { request.statusCode = statusCode; return this; }
            public TestRequest build() { return request; }
        }
        
        public String getId() { return id; }
        public String getEndpoint() { return endpoint; }
        public String getMethod() { return method; }
        public String getUserId() { return userId; }
        public Instant getTimestamp() { return timestamp; }
        public int getResponseTime() { return responseTime; }
        public int getStatusCode() { return statusCode; }
    }
    
    public static class TestScenario {
        private String name;
        private List<TestUser> users;
        private List<TestProduct> products;
        private int concurrentRequests;
        private int testDuration;
        
        public static Builder builder() { return new Builder(); }
        
        public static class Builder {
            private TestScenario scenario = new TestScenario();
            public Builder name(String name) { scenario.name = name; return this; }
            public Builder users(List<TestUser> users) { scenario.users = users; return this; }
            public Builder products(List<TestProduct> products) { scenario.products = products; return this; }
            public Builder concurrentRequests(int concurrentRequests) { scenario.concurrentRequests = concurrentRequests; return this; }
            public Builder testDuration(int testDuration) { scenario.testDuration = testDuration; return this; }
            public TestScenario build() { return scenario; }
        }
        
        public String getName() { return name; }
        public List<TestUser> getUsers() { return users; }
        public List<TestProduct> getProducts() { return products; }
        public int getConcurrentRequests() { return concurrentRequests; }
        public int getTestDuration() { return testDuration; }
    }
    
    public static class TestDataPoint {
        private Map<String, Double> features;
        private String label;
        private double confidence;
        
        public static Builder builder() { return new Builder(); }
        
        public static class Builder {
            private TestDataPoint dataPoint = new TestDataPoint();
            public Builder features(Map<String, Double> features) { dataPoint.features = features; return this; }
            public Builder label(String label) { dataPoint.label = label; return this; }
            public Builder confidence(double confidence) { dataPoint.confidence = confidence; return this; }
            public TestDataPoint build() { return dataPoint; }
        }
        
        public Map<String, Double> getFeatures() { return features; }
        public String getLabel() { return label; }
        public double getConfidence() { return confidence; }
    }
}
