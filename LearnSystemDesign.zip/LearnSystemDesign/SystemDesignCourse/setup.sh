#!/bin/bash

# System Design Mastery Course Setup Script
# This script sets up the complete learning environment

set -e  # Exit on any error

echo "🚀 Setting up System Design Mastery Course Environment"
echo "=================================================="

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_header() {
    echo -e "${BLUE}$1${NC}"
}

# Check if running on supported OS
check_os() {
    print_header "🔍 Checking Operating System..."
    
    if [[ "$OSTYPE" == "linux-gnu"* ]]; then
        OS="linux"
        print_status "Detected Linux"
    elif [[ "$OSTYPE" == "darwin"* ]]; then
        OS="macos"
        print_status "Detected macOS"
    elif [[ "$OSTYPE" == "msys" || "$OSTYPE" == "cygwin" ]]; then
        OS="windows"
        print_status "Detected Windows (WSL/Cygwin)"
    else
        print_error "Unsupported operating system: $OSTYPE"
        exit 1
    fi
}

# Check for required tools
check_prerequisites() {
    print_header "📋 Checking Prerequisites..."
    
    local missing_tools=()
    
    # Check for essential tools
    if ! command -v java &> /dev/null; then
        missing_tools+=("java")
    else
        java_version=$(java -version 2>&1 | head -n 1 | cut -d'"' -f2)
        if [[ "$java_version" < "21" ]]; then
            print_warning "Java version $java_version detected. Java 21+ recommended."
        else
            print_status "Java $java_version detected ✓"
        fi
    fi
    
    if ! command -v mvn &> /dev/null; then
        missing_tools+=("maven")
    else
        print_status "Maven detected ✓"
    fi
    
    if ! command -v docker &> /dev/null; then
        missing_tools+=("docker")
    else
        print_status "Docker detected ✓"
    fi
    
    if ! command -v docker-compose &> /dev/null; then
        missing_tools+=("docker-compose")
    else
        print_status "Docker Compose detected ✓"
    fi
    
    if ! command -v git &> /dev/null; then
        missing_tools+=("git")
    else
        print_status "Git detected ✓"
    fi
    
    if [ ${#missing_tools[@]} -ne 0 ]; then
        print_error "Missing required tools: ${missing_tools[*]}"
        print_error "Please install the missing tools and run this script again."
        echo ""
        echo "Installation instructions:"
        echo "- Java 21: https://adoptium.net/"
        echo "- Maven: https://maven.apache.org/install.html"
        echo "- Docker: https://docs.docker.com/get-docker/"
        echo "- Git: https://git-scm.com/downloads"
        exit 1
    fi
    
    print_status "All prerequisites satisfied ✓"
}

# Create directory structure
setup_directories() {
    print_header "📁 Setting up Directory Structure..."
    
    # Create additional directories if they don't exist
    local dirs=(
        "logs"
        "data"
        "temp"
        "output"
        "scripts/utils"
        "scripts/load-tests"
        "scripts/monitoring"
    )
    
    for dir in "${dirs[@]}"; do
        if [ ! -d "$dir" ]; then
            mkdir -p "$dir"
            print_status "Created directory: $dir"
        fi
    done
}

# Setup Docker environment
setup_docker() {
    print_header "🐳 Setting up Docker Environment..."
    
    # Check if Docker is running
    if ! docker info &> /dev/null; then
        print_error "Docker is not running. Please start Docker and try again."
        exit 1
    fi
    
    # Pull required images
    print_status "Pulling Docker images..."
    docker-compose -f infra/docker/local-stack.yml pull
    
    print_status "Docker environment ready ✓"
}

# Setup Java projects
setup_java_projects() {
    print_header "☕ Setting up Java Projects..."
    
    # Find all pom.xml files and build projects
    find . -name "pom.xml" -type f | while read pom_file; do
        project_dir=$(dirname "$pom_file")
        project_name=$(basename "$project_dir")
        
        print_status "Building project: $project_name"
        
        cd "$project_dir"
        
        # Clean and compile
        if mvn clean compile &> /dev/null; then
            print_status "✓ Built $project_name successfully"
        else
            print_warning "⚠ Failed to build $project_name (check dependencies)"
        fi
        
        cd - > /dev/null
    done
}

# Create useful scripts
create_scripts() {
    print_header "📜 Creating Utility Scripts..."
    
    # Start infrastructure script
    cat > scripts/start-infra.sh << 'EOF'
#!/bin/bash
echo "🚀 Starting System Design Course Infrastructure..."
docker-compose -f infra/docker/local-stack.yml up -d
echo "✅ Infrastructure started!"
echo ""
echo "🌐 Access URLs:"
echo "- Grafana: http://localhost:3000 (admin/admin)"
echo "- Prometheus: http://localhost:9090"
echo "- Kafka UI: http://localhost:8081"
echo "- MinIO Console: http://localhost:9001 (admin/admin123)"
echo "- MailHog: http://localhost:8025"
echo "- Jaeger: http://localhost:16686"
EOF
    
    # Stop infrastructure script
    cat > scripts/stop-infra.sh << 'EOF'
#!/bin/bash
echo "🛑 Stopping System Design Course Infrastructure..."
docker-compose -f infra/docker/local-stack.yml down
echo "✅ Infrastructure stopped!"
EOF
    
    # Reset environment script
    cat > scripts/reset-env.sh << 'EOF'
#!/bin/bash
echo "🔄 Resetting System Design Course Environment..."
docker-compose -f infra/docker/local-stack.yml down -v
docker-compose -f infra/docker/local-stack.yml up -d
echo "✅ Environment reset complete!"
EOF
    
    # Make scripts executable
    chmod +x scripts/*.sh
    
    print_status "Utility scripts created ✓"
}

# Setup development environment
setup_dev_environment() {
    print_header "🛠️ Setting up Development Environment..."
    
    # Create .gitignore if it doesn't exist
    if [ ! -f .gitignore ]; then
        cat > .gitignore << 'EOF'
# Compiled class files
*.class

# Log files
*.log
logs/

# Package files
*.jar
*.war
*.nar
*.ear
*.zip
*.tar.gz
*.rar

# Maven
target/
pom.xml.tag
pom.xml.releaseBackup
pom.xml.versionsBackup
pom.xml.next
release.properties
dependency-reduced-pom.xml
buildNumber.properties
.mvn/timing.properties
.mvn/wrapper/maven-wrapper.jar

# IDE files
.idea/
*.iws
*.iml
*.ipr
.vscode/
*.swp
*.swo

# OS files
.DS_Store
.DS_Store?
._*
.Spotlight-V100
.Trashes
ehthumbs.db
Thumbs.db

# Docker
.env

# Application
data/
temp/
output/
EOF
        print_status "Created .gitignore file"
    fi
    
    # Create environment file template
    if [ ! -f .env.template ]; then
        cat > .env.template << 'EOF'
# System Design Course Environment Variables
# Copy this file to .env and customize values

# Database Configuration
POSTGRES_HOST=localhost
POSTGRES_PORT=5432
POSTGRES_DB=systemdesign
POSTGRES_USER=dev
POSTGRES_PASSWORD=devpassword

# Redis Configuration
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_PASSWORD=devpassword

# Kafka Configuration
KAFKA_BOOTSTRAP_SERVERS=localhost:9092

# Monitoring
PROMETHEUS_URL=http://localhost:9090
GRAFANA_URL=http://localhost:3000

# External Services (for testing)
SENDGRID_API_KEY=your_sendgrid_key_here
TWILIO_ACCOUNT_SID=your_twilio_sid_here
TWILIO_AUTH_TOKEN=your_twilio_token_here

# Application Settings
LOG_LEVEL=INFO
PROFILE=local
EOF
        print_status "Created .env.template file"
    fi
}

# Run basic health checks
run_health_checks() {
    print_header "🏥 Running Health Checks..."
    
    # Start infrastructure for testing
    print_status "Starting infrastructure for health checks..."
    docker-compose -f infra/docker/local-stack.yml up -d > /dev/null 2>&1
    
    # Wait for services to start
    print_status "Waiting for services to start..."
    sleep 30
    
    # Check service health
    local services=(
        "PostgreSQL:localhost:5432"
        "Redis:localhost:6379"
        "Kafka:localhost:9092"
        "Prometheus:localhost:9090"
        "Grafana:localhost:3000"
    )
    
    for service_info in "${services[@]}"; do
        IFS=':' read -r service host port <<< "$service_info"
        
        if nc -z "$host" "$port" 2>/dev/null; then
            print_status "✓ $service is healthy"
        else
            print_warning "⚠ $service is not responding (this is normal on first run)"
        fi
    done
    
    # Stop infrastructure
    print_status "Stopping test infrastructure..."
    docker-compose -f infra/docker/local-stack.yml down > /dev/null 2>&1
}

# Print success message and next steps
print_success() {
    print_header "🎉 Setup Complete!"
    echo ""
    echo "System Design Mastery Course environment is ready!"
    echo ""
    echo "📚 Next Steps:"
    echo "1. Start the infrastructure: ./scripts/start-infra.sh"
    echo "2. Begin with Module 01: cd docs/01-foundations"
    echo "3. Follow the README for each module"
    echo "4. Run the code examples: cd code/modules/01-foundations && mvn spring-boot:run"
    echo ""
    echo "🛠️ Useful Commands:"
    echo "- Start infrastructure: ./scripts/start-infra.sh"
    echo "- Stop infrastructure: ./scripts/stop-infra.sh"
    echo "- Reset environment: ./scripts/reset-env.sh"
    echo ""
    echo "🌐 Access URLs (after starting infrastructure):"
    echo "- Grafana: http://localhost:3000 (admin/admin)"
    echo "- Prometheus: http://localhost:9090"
    echo "- Kafka UI: http://localhost:8081"
    echo "- Jaeger Tracing: http://localhost:16686"
    echo ""
    echo "📖 Documentation:"
    echo "- Course Overview: README.md"
    echo "- Module List: docs/"
    echo "- Case Studies: docs/13-case-studies/"
    echo "- Cheat Sheets: cheatsheets/"
    echo ""
    echo "Happy learning! 🚀"
}

# Main execution
main() {
    echo ""
    check_os
    echo ""
    check_prerequisites
    echo ""
    setup_directories
    echo ""
    setup_docker
    echo ""
    setup_java_projects
    echo ""
    create_scripts
    echo ""
    setup_dev_environment
    echo ""
    run_health_checks
    echo ""
    print_success
}

# Run main function
main "$@"
