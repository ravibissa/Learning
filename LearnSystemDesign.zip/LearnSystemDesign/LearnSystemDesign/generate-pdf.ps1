# Sanctions Screening Architecture PDF Generator
# PowerShell script to convert HTML to PDF

Write-Host "============================================" -ForegroundColor Cyan
Write-Host "Sanctions Screening Architecture PDF Generator" -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan
Write-Host ""

$htmlFile = Join-Path $PSScriptRoot "Sanctions-Screening-Architecture.html"
$pdfFile = Join-Path $PSScriptRoot "Sanctions-Screening-Architecture.pdf"

# Check if HTML file exists
if (-not (Test-Path $htmlFile)) {
    Write-Host "Error: HTML file not found: $htmlFile" -ForegroundColor Red
    exit 1
}

# Try Chrome first
$chrome = Get-Command "chrome" -ErrorAction SilentlyContinue
if ($chrome) {
    Write-Host "Using Chrome to generate PDF..." -ForegroundColor Green
    $fileUri = "file:///" + $htmlFile.Replace('\', '/')
    & chrome --headless --disable-gpu --print-to-pdf="$pdfFile" "$fileUri"
    if (Test-Path $pdfFile) {
        Write-Host "PDF generated successfully: $pdfFile" -ForegroundColor Green
        exit 0
    }
}

# Try Microsoft Edge
$edge = Get-Command "msedge" -ErrorAction SilentlyContinue
if ($edge) {
    Write-Host "Using Microsoft Edge to generate PDF..." -ForegroundColor Green
    $fileUri = "file:///" + $htmlFile.Replace('\', '/')
    & msedge --headless --disable-gpu --print-to-pdf="$pdfFile" "$fileUri"
    if (Test-Path $pdfFile) {
        Write-Host "PDF generated successfully: $pdfFile" -ForegroundColor Green
        exit 0
    }
}

# Try wkhtmltopdf
$wkhtmltopdf = Get-Command "wkhtmltopdf" -ErrorAction SilentlyContinue
if ($wkhtmltopdf) {
    Write-Host "Using wkhtmltopdf to generate PDF..." -ForegroundColor Green
    & wkhtmltopdf --page-size A4 --margin-top 0.75in --margin-right 0.75in --margin-bottom 0.75in --margin-left 0.75in --enable-local-file-access "$htmlFile" "$pdfFile"
    if (Test-Path $pdfFile) {
        Write-Host "PDF generated successfully: $pdfFile" -ForegroundColor Green
        exit 0
    }
}

# If no tools available, provide instructions
Write-Host "No PDF generation tools found on this system." -ForegroundColor Yellow
Write-Host ""
Write-Host "Please use one of these methods:" -ForegroundColor White
Write-Host "1. Open Sanctions-Screening-Architecture.html in your browser and print to PDF" -ForegroundColor White
Write-Host "2. Install Chrome or Edge and run this script again" -ForegroundColor White
Write-Host "3. Install wkhtmltopdf and run this script again" -ForegroundColor White
Write-Host ""
Write-Host "For manual conversion:" -ForegroundColor Cyan
Write-Host "- Open: Sanctions-Screening-Architecture.html" -ForegroundColor White
Write-Host "- Press: Ctrl+P" -ForegroundColor White
Write-Host "- Select: Save as PDF" -ForegroundColor White
Write-Host "- Settings: A4 paper, minimum margins, background graphics enabled" -ForegroundColor White

Write-Host ""
Write-Host "Opening HTML file in default browser..." -ForegroundColor Green
Start-Process $htmlFile

Write-Host ""
Read-Host "Press Enter to continue"
