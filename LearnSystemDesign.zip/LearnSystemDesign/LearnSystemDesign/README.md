# Sanctions Screening & Partner Notification Platform Architecture

This directory contains a comprehensive HIGH-LEVEL architecture design for a Sanctions Screening & Partner Notification platform for Booking.com.

## 📁 Files Overview

### 📄 Main Documents
- **`Sanctions-Screening-Architecture.md`** - Complete architecture documentation in Markdown format
- **`Sanctions-Screening-Architecture.html`** - Beautifully formatted HTML version with embedded CSS
- **`README.md`** - This file with usage instructions

### 📊 Architecture Diagrams
All diagrams are in Mermaid format and can be rendered using various tools:

- **`diagrams/container-architecture.mmd`** - C4-style Container diagram showing all microservices and data stores
- **`diagrams/business-onboarding-flow.mmd`** - Sequence diagram for new business onboarding workflow
- **`diagrams/sanctions-update-flow.mmd`** - Sequence diagram for sanctions list update workflow
- **`diagrams/data-model-erd.mmd`** - Entity Relationship Diagram with all database entities

## 🖨️ How to Generate PDF

### Method 1: Browser Print (Recommended)
1. Open `Sanctions-Screening-Architecture.html` in your web browser
2. Press `Ctrl+P` (Windows) or `Cmd+P` (Mac)
3. Select "Save as PDF" as the destination
4. Choose "More settings" and set:
   - Paper size: A4 or Letter
   - Margins: Minimum
   - Options: ✓ Background graphics
5. Click "Save" to generate the PDF

### Method 2: Using Pandoc (if available)
```bash
pandoc Sanctions-Screening-Architecture.md -o Sanctions-Screening-Architecture.pdf --pdf-engine=wkhtmltopdf
```

### Method 3: Online Converters
- Upload the HTML file to online HTML-to-PDF converters like:
  - https://www.sejda.com/html-to-pdf
  - https://smallpdf.com/html-to-pdf

## 📊 Viewing Diagrams

### Online Mermaid Editors
1. Copy the content from any `.mmd` file
2. Paste into one of these online editors:
   - https://mermaid.live/
   - https://mermaid-js.github.io/mermaid-live-editor/

### VS Code Extension
1. Install "Mermaid Preview" extension
2. Open any `.mmd` file
3. Press `Ctrl+Shift+P` and search for "Mermaid: Preview"

### GitHub/GitLab
The `.mmd` files will render automatically when viewed on GitHub or GitLab.

## 🏗️ Architecture Overview

This design covers:

- **Executive Summary** - High-level platform overview
- **Architecture Overview** - C4-style container diagram and technology stack
- **Key Workflows** - Business onboarding and sanctions list updates
- **Screening Design** - Multi-tier matching algorithms and strategies
- **APIs & Contracts** - OpenAPI specs and Kafka event schemas
- **Data Model** - Complete ERD with performance optimizations
- **Non-Functional Requirements** - Scale targets, SLOs, and resilience patterns
- **Security & Compliance** - GDPR, access controls, and audit trails
- **Partner Notifications** - Multi-channel delivery with retry logic
- **Operations & Testing** - Deployment strategies and testing approaches
- **Roadmap** - Phased implementation plan
- **Risk Register** - Identified risks with mitigation strategies

## 🎯 Key Features

- **Scale**: 5M+ businesses, 100K+ daily screenings
- **Performance**: <100ms p95 latency for real-time screening
- **Reliability**: 99.9% availability with circuit breakers and fallbacks
- **Compliance**: GDPR-compliant with tamper-evident audit trails
- **Technology**: Java 21, Spring Boot, Kafka, PostgreSQL, OpenSearch, Redis

## 📞 Support

This architecture was designed by a Principal Systems Architect and reviewed by Compliance & Engineering teams.

For questions or clarifications about the architecture, please refer to the detailed documentation in the main files.

---

**Document Version**: 1.0  
**Last Updated**: January 2024  
**Format**: Markdown, HTML, Mermaid Diagrams
