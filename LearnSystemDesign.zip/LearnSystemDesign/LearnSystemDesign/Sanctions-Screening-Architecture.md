# Sanctions Screening & Partner Notification Platform Architecture

**Booking.com - Principal Systems Architect Design**

---

## Table of Contents

1. [Executive Summary](#executive-summary)
2. [Architecture Overview](#architecture-overview)
3. [Key Workflows](#key-workflows)
4. [Screening Design](#screening-design)
5. [APIs & Contracts](#apis--contracts)
6. [Data Model](#data-model)
7. [Non-Functional Requirements](#non-functional-requirements)
8. [Security, Risk & Compliance](#security-risk--compliance)
9. [Partner Notification Strategy](#partner-notification-strategy)
10. [Operations & Testing](#operations--testing)
11. [Roadmap](#roadmap)
12. [Risk Register](#risk-register)

---

## Executive Summary

The proposed architecture delivers a scalable, compliant, and resilient sanctions screening platform for Booking.com's 5M+ business partners. The system provides:

- **Real-time screening** with <100ms p95 latency for new business onboarding and transaction processing
- **Batch processing** capabilities for full rescreening of the entire business registry within 4-hour windows
- **Advanced matching algorithms** using phonetic, fuzzy, and ML-enhanced name matching with transliteration support
- **Human-in-the-loop workflows** for analyst review and false positive management
- **Tamper-evident audit trails** ensuring regulatory compliance and forensic capabilities
- **Multi-channel notifications** with guaranteed delivery to partner systems

The microservices architecture leverages Java 21/Spring Boot, Kafka event streaming, PostgreSQL for transactional data, OpenSearch for fuzzy matching, and Redis for high-performance caching. The system targets 99.9% availability with automatic failover, circuit breakers, and comprehensive observability.

---

## Architecture Overview

### Technology Stack

**Core Technologies:**
- **Runtime**: Java 21, Spring Boot 3.x
- **Event Streaming**: Apache Kafka with Schema Registry
- **Databases**: PostgreSQL 15 (RDS), Redis 7 (Cluster Mode)
- **Search**: Amazon OpenSearch for fuzzy matching
- **Storage**: AWS S3 for sanctions lists and audit artifacts
- **Container Platform**: Kubernetes with Helm charts
- **API Gateway**: Kong/Envoy with OAuth2/OIDC
- **Observability**: OpenTelemetry, Prometheus, Grafana, ELK Stack

**See Container Diagram:** `diagrams/container-architecture.mmd`

### Core Services

1. **Ingestion Service** - Fetches and validates sanctions lists from multiple sources
2. **Screening Service** - Performs name/entity matching with multiple algorithms  
3. **Decision Engine** - Applies business rules and risk scoring
4. **Business Registry** - CRUD operations for business entities
5. **Notification Service** - Multi-channel alerts with retry logic
6. **Case Management** - Analyst workflows and override capabilities
7. **Audit Service** - Immutable logging with hash chains

---

## Key Workflows

### New Business Onboarding

**See Sequence Diagram:** `diagrams/business-onboarding-flow.mmd`

**Process Flow:**
1. Partner submits business registration via API Gateway
2. Business Registry validates and stores entity data
3. BusinessCreated event published to Kafka
4. Screening Service performs multi-algorithm matching against sanctions lists
5. Decision Engine applies rules based on match confidence scores
6. Notification Service alerts partners based on decision outcome
7. Audit Service records complete decision trail

**Decision Thresholds:**
- **>90% confidence**: Automatic block with immediate notification
- **70-90% confidence**: Manual review queue for analyst
- **<70% confidence**: Automatic clearance with notification

### Sanctions List Update

**See Sequence Diagram:** `diagrams/sanctions-update-flow.mmd`

**Process Flow:**
1. Scheduled job triggers list updates from external sources (OFAC, EU, UN)
2. Ingestion Service validates checksums and digital signatures
3. New/updated entries indexed in OpenSearch
4. SanctionsUpdated event triggers delta or full rescreen
5. Affected businesses re-evaluated against updated lists
6. Status changes generate immediate partner notifications
7. Evidence bundles created for audit compliance

---

## Screening Design

### Multi-Tier Matching Strategy

**Tier 1: Exact Matching**
- Direct string comparison after normalization
- LEI, VAT, and national ID exact matches
- Performance: O(1) with Redis hash lookups

**Tier 2: Phonetic Matching**
- Double Metaphone for English names
- Custom algorithms for Arabic, Chinese, Cyrillic scripts
- Handles transliteration variations (Mohammed/Muhammad/Mohammad)

**Tier 3: Fuzzy String Matching**
- **Levenshtein Distance**: Character-level edits (threshold: 2-3)
- **Jaro-Winkler**: Transposition-aware similarity (threshold: 0.85)
- **Cosine Similarity**: Token-based matching for multi-word names
- **N-gram Analysis**: Sub-string matching for partial names

### Name Normalization Pipeline

```java
@Service
public class NameNormalizationService {
    
    @Autowired
    private ICUTransliterator transliterator;
    
    public NormalizedName normalize(String rawName, Locale locale) {
        return NormalizedName.builder()
            .original(rawName)
            .lowercased(rawName.toLowerCase(locale))
            .diacriticsRemoved(removeDiacritics(rawName))
            .transliterated(transliterator.transliterate(rawName, locale))
            .tokensRemoved(removeStopwords(rawName, locale))
            .phoneticCode(generatePhoneticCode(rawName, locale))
            .build();
    }
}
```

### Idempotency & Deduplication

- **Screening Request Deduplication**: SHA-256 hash of normalized business data
- **Result Caching**: Redis TTL-based caching with business data fingerprints
- **Correlation IDs**: UUIDs for tracking async screening workflows

---

## APIs & Contracts

### Business Registry API

```yaml
openapi: 3.0.3
info:
  title: Business Registry API
  version: 1.0.0

paths:
  /businesses:
    post:
      summary: Create new business entity
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/BusinessCreateRequest'
      responses:
        '202':
          description: Business creation accepted
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/BusinessResponse'
```

### Kafka Event Schemas

**BusinessCreated Event (Avro):**
```json
{
  "type": "record",
  "name": "BusinessCreated",
  "namespace": "com.booking.sanctions.events",
  "fields": [
    {"name": "eventId", "type": "string"},
    {"name": "timestamp", "type": {"type": "long", "logicalType": "timestamp-millis"}},
    {"name": "businessId", "type": "string"},
    {"name": "legalName", "type": "string"},
    {"name": "registrationCountry", "type": "string"},
    {"name": "businessType", "type": {"type": "enum", "name": "BusinessType", 
                                     "symbols": ["HOTEL", "TOUR_OPERATOR", "VENDOR", "PROPERTY_MANAGER"]}}
  ]
}
```

**ScreeningCompleted Event:**
```json
{
  "type": "record", 
  "name": "ScreeningCompleted",
  "fields": [
    {"name": "correlationId", "type": "string"},
    {"name": "businessId", "type": "string"},
    {"name": "matches", "type": {"type": "array", "items": "MatchCandidate"}},
    {"name": "highestScore", "type": "double"},
    {"name": "algorithmVersion", "type": "string"}
  ]
}
```

---

## Data Model

**See Entity Relationship Diagram:** `diagrams/data-model-erd.mmd`

### Key Entities

**Business Registry:**
- `BUSINESS` - Core business entity with legal name, country, type
- `BUSINESS_ALIAS` - Alternative names and trading names
- `BUSINESS_ADDRESS` - Physical addresses for matching
- `ULTIMATE_BENEFICIAL_OWNER` - UBO details for enhanced screening

**Screening & Decisions:**
- `SCREENING_JOB` - Async screening requests with correlation IDs
- `SCREENING_RESULT` - Algorithm outputs with confidence scores
- `MATCH_CANDIDATE` - Individual matches against sanctions entries
- `DECISION` - Business rules outcomes with analyst overrides

**Sanctions Data:**
- `SANCTIONS_SOURCE` - External list sources with versioning
- `SANCTIONS_ENTRY` - Individual sanctioned entities with search tokens

**Audit & Compliance:**
- `AUDIT_EVENT` - Immutable event log with hash chains
- `ANALYST_CASE` - Manual review workflows
- `NOTIFICATION` - Multi-channel alert delivery tracking

### Database Performance Optimizations

**Key Indexes:**
```sql
-- High-performance name searching
CREATE INDEX CONCURRENTLY business_legal_name_gin 
ON business USING gin(to_tsvector('english', legal_name));

-- Fuzzy matching optimization  
CREATE INDEX CONCURRENTLY sanctions_search_tokens_gin 
ON sanctions_entry USING gin(search_tokens gin_trgm_ops);

-- Time-series optimization
CREATE INDEX CONCURRENTLY screening_job_time_series 
ON screening_job (requested_at DESC, status) 
WHERE status IN ('PENDING', 'IN_PROGRESS');
```

**Partitioning Strategy:**
- `AUDIT_EVENT`: Monthly partitions for archival
- `SCREENING_JOB`: Date-based partitioning for query optimization
- `SANCTIONS_ENTRY`: Source-based partitioning for isolation

---

## Non-Functional Requirements

### Scale Targets & Performance

**Capacity Planning:**
- **Business Registry**: 5M active businesses, 50K new registrations/day
- **Screening Volume**: 
  - Real-time: 100K screenings/day (peak: 500 req/sec)
  - Batch: 5M full rescreens in 4-hour windows
- **Sanctions Data**: 1M+ sanctioned entities across 15+ global lists

**Performance SLOs:**
- **Real-time Screening**: p95 latency <100ms, p99 <250ms
- **Batch Processing**: 5M businesses in <4 hours
- **API Response Times**: Business CRUD p95 <50ms
- **Availability**: 99.9% (43.8 minutes/month downtime)

### Resilience Patterns

**Circuit Breakers:**
```java
@CircuitBreaker(name = "ofac-api", fallbackMethod = "fallbackToCache")
@TimeLimiter(name = "ofac-api")
@Retry(name = "ofac-api")
public CompletableFuture<SanctionsList> fetchLatestList() {
    return ofacApiClient.getLatestSanctions();
}
```

**Retry Policies:**
- Exponential backoff: 100ms → 200ms → 400ms → 800ms → 1.6s
- Max retries: 5 for external APIs, 3 for internal services
- Dead letter queues for failed messages
- Jitter: ±25% to prevent thundering herd

---

## Security, Risk & Compliance

### GDPR & Data Protection

**Lawful Basis:**
- Article 6(1)(c): Legal obligation for sanctions compliance
- Article 6(1)(f): Legitimate interests for business relationships
- Data minimization and purpose limitation enforced

**Retention Schedules:**
- Active business data: While relationship exists
- Screening results: 7 years (regulatory requirement)
- Audit logs: 10 years (tamper-evident)
- Personal data: Auto-anonymization after 2 years inactivity

### Access Controls (RBAC)

```yaml
roles:
  sanctions_analyst:
    permissions:
      - read:cases
      - write:case_decisions
      - read:screening_results
    constraints:
      - geography: assigned_regions
      
  compliance_manager:
    permissions:
      - read:all_cases
      - write:overrides
      - admin:system_config
    constraints:
      - clearance_level: L3
```

### Tamper-Evident Audit Logs

```java
@Service
public class TamperEvidentAuditService {
    
    public void recordEvent(AuditEvent event) {
        var previousHash = getLastEventHash();
        var eventHash = computeHash(event, previousHash);
        
        var auditRecord = AuditRecord.builder()
            .eventData(event)
            .previousHash(previousHash)
            .currentHash(eventHash)
            .signature(digitalSignatureService.sign(eventHash))
            .build();
            
        auditRepository.save(auditRecord);
    }
}
```

---

## Partner Notification Strategy

### Multi-Channel Delivery

**Primary: Webhooks with HMAC Signatures**
```java
@Async
@Retryable(maxAttempts = 5, backoff = @Backoff(delay = 1000, multiplier = 2))
public void sendWebhookNotification(NotificationRequest request) {
    var payload = createSignedPayload(request);
    var response = restTemplate.postForEntity(
        request.getWebhookUrl(), payload, NotificationResponse.class);
    
    auditService.recordDelivery(request.getId(), response);
}
```

**Fallback Channels:**
- Email alerts for critical sanctions
- Slack/Teams integration for compliance teams
- Partner polling API for reliability
- SMS for urgent escalations

### Retry Logic & State Management

**Exponential Backoff Configuration:**
```yaml
notifications:
  webhook:
    max_attempts: 5
    initial_delay: 1000ms
    max_delay: 30000ms
    multiplier: 2.0
    jitter: 0.25
```

**Critical Alert Template:**
```json
{
  "notification_id": "ntf_abc123",
  "event_type": "BUSINESS_SANCTIONED",
  "severity": "CRITICAL",
  "action_required": "IMMEDIATE_BLOCK",
  "evidence_url": "https://sanctions.booking.com/evidence/ntf_abc123",
  "acknowledgment_required": true,
  "expires_at": "2024-01-15T16:30:00Z"
}
```

---

## Operations & Testing

### Deployment Strategy

**Blue/Green with Canary:**
```yaml
deployment:
  strategy: blue_green
  phases:
    green_deployment:
      - health_check: /actuator/health
      - smoke_tests: [business_crud, screening_accuracy, notifications]
    traffic_switch:
      canary: 5%    # 5 minutes
      gradual: 25%  # 10 minutes  
      full: 100%    # If metrics green
    rollback_triggers:
      - error_rate > 0.1%
      - response_time_p95 > 200ms
```

### Critical Operations Runbooks

**Sanctions List Ingestion Failure:**
1. Check external API health and authentication
2. Enable fallback mode to cached lists
3. Manual data validation and checksum verification
4. Escalate to external provider if >4 hour outage

**Screening Backlog Spike:**
1. Scale screening service horizontally
2. Increase Kafka consumer threads
3. Triage by priority (URGENT first)
4. Monitor OpenSearch and database resources

### Testing Strategy

**Synthetic Test Data:**
- Phonetic variations and transliteration challenges
- Corporate structure obfuscation patterns
- Adversarial cases designed to trigger false positives

**Precision/Recall Targets:**
- High confidence matches (>90%): Precision >99.5%, Recall >95%
- Medium confidence (70-90%): Precision >90%, Recall >98%
- Overall false positive rate: <0.1%

---

## Roadmap

### Phase 1: MVP (Months 1-4)
- ✅ Core microservices architecture
- ✅ OFAC, EU, UN sanctions list ingestion
- ✅ Basic name matching (exact + Levenshtein)
- ✅ Webhook notifications to primary partners
- ✅ PostgreSQL + Redis + Kafka infrastructure

### Phase 2: Enhanced Screening (Months 5-8)  
- 🔄 Advanced fuzzy matching algorithms
- 🔄 Phonetic matching for international names
- 🔄 ML-enhanced confidence scoring
- 🔄 Analyst workflow optimization
- 🔄 Additional sanctions sources (UK HMT, AUSTRAC)

### Phase 3: Intelligence & Automation (Months 9-12)
- 📋 Ultimate Beneficial Owner graph expansion
- 📋 Real-time payment transaction holds
- 📋 Continuous monitoring & re-screening triggers
- 📋 Advanced analytics and risk scoring
- 📋 Multi-region deployment for global scale

### Phase 4: AI & Advanced Features (Year 2)
- 📋 Graph neural networks for entity relationships
- 📋 NLP for sanction reason analysis
- 📋 Predictive modeling for emerging risks
- 📋 Automated false positive classification

---

## Risk Register

| Risk | Impact | Probability | Mitigation |
|------|---------|-------------|------------|
| **False Negative (Missed Sanction)** | Critical | Low | Multi-algorithm approach, human review, continuous monitoring |
| **High False Positive Rate** | High | Medium | ML model tuning, analyst feedback loop, allowlisting |
| **External API Outage** | Medium | Medium | Cached fallbacks, multiple data sources, SLA monitoring |
| **Data Corruption** | High | Low | Checksums, digital signatures, backup/restore procedures |
| **Scale Bottlenecks** | Medium | Medium | Horizontal scaling, performance testing, capacity planning |
| **Compliance Violation** | Critical | Low | Audit trails, access controls, regular compliance reviews |

---

## Architecture Diagrams

- **Container Architecture**: See `diagrams/container-architecture.mmd`
- **Business Onboarding Flow**: See `diagrams/business-onboarding-flow.mmd`  
- **Sanctions Update Flow**: See `diagrams/sanctions-update-flow.mmd`
- **Data Model ERD**: See `diagrams/data-model-erd.mmd`

---

**Document Version**: 1.0  
**Last Updated**: January 2024  
**Author**: Principal Systems Architect  
**Review**: Compliance & Engineering Teams
