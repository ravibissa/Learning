package com.enterprise.order;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * Main application class for the Order Service.
 * 
 * This microservice handles order management including:
 * - Order creation and lifecycle management
 * - Event sourcing for order state changes
 * - Integration with payment and notification services
 * - Document storage in AWS S3
 * - PostgreSQL for order data persistence
 * 
 * Key Features:
 * - Event-driven architecture with Kafka
 * - Circuit breaker patterns for resilience
 * - Comprehensive audit logging
 * - REST API with OpenAPI documentation
 * - Health checks and metrics
 * 
 * @author Enterprise Platform Team
 * @version 1.0.0
 * @since 2024-01-01
 */
@SpringBootApplication(scanBasePackages = {
    "com.enterprise.order",
    "com.enterprise.common"
})
@EnableKafka
@EnableCaching
@EnableAsync
@EnableTransactionManagement
public class OrderServiceApplication {

    /**
     * Main entry point for the Order Service application.
     * 
     * @param args command line arguments
     */
    public static void main(String[] args) {
        SpringApplication.run(OrderServiceApplication.class, args);
    }
}
