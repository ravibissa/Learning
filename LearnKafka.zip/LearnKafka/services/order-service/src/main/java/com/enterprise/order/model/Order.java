package com.enterprise.order.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * Order entity representing a customer order in the system.
 * 
 * This entity uses JPA for persistence and includes:
 * - Order lifecycle management
 * - Customer and address information
 * - Order items with pricing
 * - Audit fields for tracking changes
 * - Optimistic locking for concurrent updates
 * 
 * The entity follows DDD principles with rich domain behavior
 * and maintains consistency through business rules.
 * 
 * @author Enterprise Platform Team
 * @version 1.0.0
 * @since 2024-01-01
 */
@Entity
@Table(name = "orders", indexes = {
    @Index(name = "idx_order_customer_id", columnList = "customerId"),
    @Index(name = "idx_order_status", columnList = "status"),
    @Index(name = "idx_order_created_at", columnList = "createdAt")
})
public class Order {

    @Id
    @Column(name = "id", length = 36)
    private String id;

    @Column(name = "customer_id", nullable = false, length = 36)
    @NotBlank
    private String customerId;

    @Column(name = "customer_email", nullable = false)
    @NotBlank
    private String customerEmail;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 20)
    @NotNull
    private OrderStatus status;

    @Column(name = "total_amount", nullable = false, precision = 19, scale = 2)
    @NotNull
    @Positive
    private BigDecimal totalAmount;

    @Column(name = "currency", nullable = false, length = 3)
    @NotBlank
    private String currency;

    @Column(name = "payment_method", length = 50)
    private String paymentMethod;

    @Embedded
    @AttributeOverrides({
        @AttributeOverride(name = "street", column = @Column(name = "shipping_street")),
        @AttributeOverride(name = "city", column = @Column(name = "shipping_city")),
        @AttributeOverride(name = "state", column = @Column(name = "shipping_state")),
        @AttributeOverride(name = "zipCode", column = @Column(name = "shipping_zip_code")),
        @AttributeOverride(name = "country", column = @Column(name = "shipping_country"))
    })
    private Address shippingAddress;

    @Embedded
    @AttributeOverrides({
        @AttributeOverride(name = "street", column = @Column(name = "billing_street")),
        @AttributeOverride(name = "city", column = @Column(name = "billing_city")),
        @AttributeOverride(name = "state", column = @Column(name = "billing_state")),
        @AttributeOverride(name = "zipCode", column = @Column(name = "billing_zip_code")),
        @AttributeOverride(name = "country", column = @Column(name = "billing_country"))
    })
    private Address billingAddress;

    @OneToMany(mappedBy = "order", cascade = CascadeType.ALL, fetch = FetchType.LAZY, orphanRemoval = true)
    private List<OrderItem> items = new ArrayList<>();

    @Column(name = "notes", length = 1000)
    private String notes;

    @Column(name = "version", nullable = false)
    @Version
    private Long version = 0L;

    @Column(name = "created_at", nullable = false, updatable = false)
    @CreationTimestamp
    private Instant createdAt;

    @Column(name = "updated_at", nullable = false)
    @UpdateTimestamp
    private Instant updatedAt;

    @Column(name = "created_by", length = 36)
    private String createdBy;

    @Column(name = "updated_by", length = 36)
    private String updatedBy;

    /**
     * Default constructor for JPA.
     */
    protected Order() {
    }

    /**
     * Constructor for creating a new order.
     * 
     * @param id the unique order identifier
     * @param customerId the customer placing the order
     * @param customerEmail the customer's email address
     * @param shippingAddress the shipping address
     * @param billingAddress the billing address
     * @param currency the currency for the order
     */
    public Order(String id, String customerId, String customerEmail, 
                Address shippingAddress, Address billingAddress, String currency) {
        this.id = id;
        this.customerId = customerId;
        this.customerEmail = customerEmail;
        this.shippingAddress = shippingAddress;
        this.billingAddress = billingAddress;
        this.currency = currency;
        this.status = OrderStatus.PENDING;
        this.totalAmount = BigDecimal.ZERO;
    }

    /**
     * Adds an item to the order and recalculates the total amount.
     * 
     * @param item the order item to add
     * @throws IllegalArgumentException if item is null or invalid
     */
    public void addItem(OrderItem item) {
        if (item == null) {
            throw new IllegalArgumentException("Order item cannot be null");
        }
        
        if (items.size() >= 50) { // Business rule: max 50 items per order
            throw new IllegalArgumentException("Cannot add more than 50 items to an order");
        }
        
        item.setOrder(this);
        items.add(item);
        recalculateTotal();
    }

    /**
     * Removes an item from the order and recalculates the total amount.
     * 
     * @param item the order item to remove
     */
    public void removeItem(OrderItem item) {
        if (items.remove(item)) {
            item.setOrder(null);
            recalculateTotal();
        }
    }

    /**
     * Updates the order status with validation.
     * 
     * @param newStatus the new status
     * @param updatedBy the user making the update
     * @throws IllegalArgumentException if status transition is invalid
     */
    public void updateStatus(OrderStatus newStatus, String updatedBy) {
        if (!isValidStatusTransition(this.status, newStatus)) {
            throw new IllegalArgumentException(
                String.format("Invalid status transition from %s to %s", this.status, newStatus)
            );
        }
        
        this.status = newStatus;
        this.updatedBy = updatedBy;
    }

    /**
     * Validates if a status transition is allowed.
     * 
     * @param currentStatus the current status
     * @param newStatus the proposed new status
     * @return true if transition is valid
     */
    private boolean isValidStatusTransition(OrderStatus currentStatus, OrderStatus newStatus) {
        if (currentStatus == newStatus) {
            return true;
        }
        
        return switch (currentStatus) {
            case PENDING -> newStatus == OrderStatus.CONFIRMED || 
                           newStatus == OrderStatus.CANCELLED;
            case CONFIRMED -> newStatus == OrderStatus.PROCESSING || 
                             newStatus == OrderStatus.CANCELLED;
            case PROCESSING -> newStatus == OrderStatus.SHIPPED || 
                              newStatus == OrderStatus.CANCELLED;
            case SHIPPED -> newStatus == OrderStatus.DELIVERED;
            case DELIVERED, CANCELLED -> false; // Terminal states
        };
    }

    /**
     * Recalculates the total amount based on order items.
     */
    private void recalculateTotal() {
        this.totalAmount = items.stream()
            .map(OrderItem::getTotalPrice)
            .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    /**
     * Checks if the order can be cancelled.
     * 
     * @return true if order can be cancelled
     */
    public boolean canBeCancelled() {
        return status == OrderStatus.PENDING || 
               status == OrderStatus.CONFIRMED || 
               status == OrderStatus.PROCESSING;
    }

    /**
     * Checks if the order is in a terminal state.
     * 
     * @return true if order is completed or cancelled
     */
    public boolean isTerminal() {
        return status == OrderStatus.DELIVERED || status == OrderStatus.CANCELLED;
    }

    // Getters and Setters

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getCustomerEmail() {
        return customerEmail;
    }

    public void setCustomerEmail(String customerEmail) {
        this.customerEmail = customerEmail;
    }

    public OrderStatus getStatus() {
        return status;
    }

    public void setStatus(OrderStatus status) {
        this.status = status;
    }

    public BigDecimal getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(BigDecimal totalAmount) {
        this.totalAmount = totalAmount;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public Address getShippingAddress() {
        return shippingAddress;
    }

    public void setShippingAddress(Address shippingAddress) {
        this.shippingAddress = shippingAddress;
    }

    public Address getBillingAddress() {
        return billingAddress;
    }

    public void setBillingAddress(Address billingAddress) {
        this.billingAddress = billingAddress;
    }

    public List<OrderItem> getItems() {
        return new ArrayList<>(items);
    }

    public void setItems(List<OrderItem> items) {
        this.items.clear();
        if (items != null) {
            items.forEach(this::addItem);
        }
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public Long getVersion() {
        return version;
    }

    public void setVersion(Long version) {
        this.version = version;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Instant createdAt) {
        this.createdAt = createdAt;
    }

    public Instant getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Instant updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Order order = (Order) o;
        return Objects.equals(id, order.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return "Order{" +
                "id='" + id + '\'' +
                ", customerId='" + customerId + '\'' +
                ", status=" + status +
                ", totalAmount=" + totalAmount +
                ", currency='" + currency + '\'' +
                ", version=" + version +
                '}';
    }
}
