package com.enterprise.order.model;

/**
 * Enumeration representing the various states of an order lifecycle.
 * 
 * Order Status Flow:
 * PENDING -> CONFIRMED -> PROCESSING -> SHIPPED -> DELIVERED
 *     |         |            |
 *     v         v            v
 * CANCELLED  CANCELLED   CANCELLED
 * 
 * @author Enterprise Platform Team
 * @version 1.0.0
 * @since 2024-01-01
 */
public enum OrderStatus {
    /**
     * Order has been created but not yet confirmed.
     * Payment may still be pending.
     */
    PENDING,
    
    /**
     * Order has been confirmed and payment processed.
     * Ready for fulfillment.
     */
    CONFIRMED,
    
    /**
     * Order is being processed/prepared for shipment.
     */
    PROCESSING,
    
    /**
     * Order has been shipped to the customer.
     */
    SHIPPED,
    
    /**
     * Order has been delivered to the customer.
     * Terminal state.
     */
    DELIVERED,
    
    /**
     * Order has been cancelled.
     * Terminal state.
     */
    CANCELLED
}
