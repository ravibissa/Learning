# Kafka + Spring Boot Interview Preparation Guide
## From Beginner to Expert Level

*Complete interview preparation for Java, Spring Boot, Kafka, and System Design*  
*Author: Senior Software Engineer with 15+ years experience*

---

## Table of Contents

1. [Interview Roadmap](#1-interview-roadmap)
2. [Core Java Fundamentals](#2-core-java-fundamentals)
3. [Spring Boot Mastery](#3-spring-boot-mastery)
4. [Kafka Deep Dive](#4-kafka-deep-dive)
5. [System Design](#5-system-design)
6. [Practical Exercises](#6-practical-exercises)
7. [Cheat Sheets](#7-cheat-sheets)
8. [Mock Interview Questions](#8-mock-interview-questions)
9. [Expert-Level Scenarios](#9-expert-level-scenarios)
10. [Final Preparation](#10-final-preparation)

---

## 1. Interview Roadmap

### Skill Progression Path

```mermaid
graph TD
    A[Beginner Level<br/>0-2 years] --> B[Intermediate Level<br/>2-5 years]
    B --> C[Senior Level<br/>5-8 years]
    C --> D[Expert Level<br/>8+ years]
    
    A --> A1[Core Java<br/>Collections, Concurrency]
    A --> A2[Spring Basics<br/>DI, AOP, MVC]
    A --> A3[Kafka Basics<br/>Producer/Consumer]
    
    B --> B1[Advanced Java<br/>JVM, Performance]
    B --> B2[Spring Boot<br/>Auto-config, Testing]
    B --> B3[Kafka Internals<br/>Partitions, Replication]
    
    C --> C1[System Design<br/>Scalability, Patterns]
    C --> C2[Microservices<br/>Event-driven Architecture]
    C --> C3[Performance Tuning<br/>Monitoring, Optimization]
    
    D --> D1[Architecture<br/>Enterprise Patterns]
    D --> D2[Leadership<br/>Technical Strategy]
    D --> D3[Innovation<br/>Emerging Technologies]
```

### Assessment Criteria by Level

| Level | Technical Knowledge | Problem Solving | Communication | Leadership |
|-------|-------------------|-----------------|---------------|------------|
| **Beginner** | Basic concepts, syntax | Simple algorithms | Clear explanations | Individual contributor |
| **Intermediate** | Framework knowledge | Complex problems | Technical discussions | Mentoring juniors |
| **Senior** | Architecture patterns | System design | Stakeholder communication | Team leadership |
| **Expert** | Industry expertise | Innovation | Strategic communication | Organizational impact |

---

## 2. Core Java Fundamentals

### 2.1 Essential Concepts (Beginner Level)

#### Q1: Explain the difference between `==` and `.equals()` in Java
**Model Answer:**
```java
// == compares references for objects, values for primitives
String s1 = new String("hello");
String s2 = new String("hello");
System.out.println(s1 == s2);        // false - different objects
System.out.println(s1.equals(s2));   // true - same content

// For primitives, == compares values
int a = 5, b = 5;
System.out.println(a == b);          // true

// String literals are interned
String s3 = "hello";
String s4 = "hello";
System.out.println(s3 == s4);        // true - same object in string pool
```

**Key Points:**
- `==` compares memory addresses for objects
- `.equals()` compares content (if properly overridden)
- String literals are stored in string pool
- Always override `equals()` and `hashCode()` together

#### Q2: What is the difference between `HashMap` and `ConcurrentHashMap`?
**Model Answer:**
```java
// HashMap - not thread-safe
Map<String, String> hashMap = new HashMap<>();
// Concurrent access can lead to infinite loops, data corruption

// ConcurrentHashMap - thread-safe
Map<String, String> concurrentMap = new ConcurrentHashMap<>();
// Uses segment-based locking (Java 7) or CAS operations (Java 8+)

// Performance comparison
public class MapPerformanceTest {
    private static final int THREADS = 10;
    private static final int OPERATIONS = 100_000;
    
    public void testHashMapWithSynchronization() {
        Map<String, String> map = Collections.synchronizedMap(new HashMap<>());
        // Synchronized wrapper - poor performance due to full synchronization
    }
    
    public void testConcurrentHashMap() {
        Map<String, String> map = new ConcurrentHashMap<>();
        // Better performance - fine-grained locking
    }
}
```

**Key Points:**
- HashMap: Fast but not thread-safe
- ConcurrentHashMap: Thread-safe with better performance than synchronized wrappers
- Java 8+ ConcurrentHashMap uses CAS operations for better concurrency
- Choose based on concurrency requirements

#### Q3: Explain Java Memory Model and Garbage Collection
**Model Answer:**
```java
public class MemoryExample {
    // Stored in Method Area (Metaspace in Java 8+)
    private static final String CONSTANT = "constant";
    
    // Instance variable - stored in Heap
    private List<String> instanceList = new ArrayList<>();
    
    public void demonstrateMemoryAreas() {
        // Local variables and method parameters - stored in Stack
        int localVar = 10;
        String localString = "local";
        
        // Objects created - stored in Heap
        List<String> localList = new ArrayList<>();
        localList.add("item");
        
        // When method ends, localVar and localString references are removed from stack
        // Objects in heap are eligible for GC if no references exist
    }
    
    // Demonstration of memory leak
    private static List<String> staticList = new ArrayList<>();
    
    public void memoryLeak() {
        // This creates a memory leak - objects never eligible for GC
        staticList.add("This will never be garbage collected");
    }
}

// GC Tuning Example
// JVM Arguments:
// -Xms512m -Xmx2g              // Heap size
// -XX:+UseG1GC                 // G1 Garbage Collector
// -XX:MaxGCPauseMillis=200     // Target pause time
// -XX:+PrintGCDetails          // GC logging
```

**Key Points:**
- **Stack**: Method calls, local variables, primitive values
- **Heap**: Objects, instance variables
- **Method Area**: Class metadata, constants, static variables
- **GC Types**: Serial, Parallel, G1, ZGC, Shenandoah

### 2.2 Advanced Java (Intermediate Level)

#### Q4: Implement a thread-safe Singleton pattern
**Model Answer:**
```java
// 1. Enum Singleton (Recommended - Joshua Bloch)
public enum SingletonEnum {
    INSTANCE;
    
    private String value;
    
    public String getValue() {
        return value;
    }
    
    public void setValue(String value) {
        this.value = value;
    }
}

// 2. Double-checked locking
public class DoubleCheckedSingleton {
    private static volatile DoubleCheckedSingleton instance;
    
    private DoubleCheckedSingleton() {}
    
    public static DoubleCheckedSingleton getInstance() {
        if (instance == null) {
            synchronized (DoubleCheckedSingleton.class) {
                if (instance == null) {
                    instance = new DoubleCheckedSingleton();
                }
            }
        }
        return instance;
    }
}

// 3. Initialization-on-demand holder
public class HolderSingleton {
    private HolderSingleton() {}
    
    private static class SingletonHolder {
        private static final HolderSingleton INSTANCE = new HolderSingleton();
    }
    
    public static HolderSingleton getInstance() {
        return SingletonHolder.INSTANCE;
    }
}
```

**Key Points:**
- Enum singleton is the best approach (thread-safe, serialization-safe)
- Double-checked locking requires `volatile` keyword
- Holder pattern uses class loading mechanism for lazy initialization
- Consider using dependency injection instead of singletons

#### Q5: Explain CompletableFuture and asynchronous programming
**Model Answer:**
```java
public class AsyncProgrammingExample {
    
    private final ExecutorService executor = Executors.newFixedThreadPool(10);
    
    public CompletableFuture<String> fetchUserData(String userId) {
        return CompletableFuture
            .supplyAsync(() -> {
                // Simulate API call
                try {
                    Thread.sleep(1000);
                    return "User data for " + userId;
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }, executor);
    }
    
    public CompletableFuture<String> fetchUserPreferences(String userId) {
        return CompletableFuture
            .supplyAsync(() -> {
                try {
                    Thread.sleep(800);
                    return "Preferences for " + userId;
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }, executor);
    }
    
    public CompletableFuture<String> combineUserInfo(String userId) {
        CompletableFuture<String> userData = fetchUserData(userId);
        CompletableFuture<String> userPrefs = fetchUserPreferences(userId);
        
        return userData.thenCombine(userPrefs, (data, prefs) -> {
            return "Combined: " + data + " | " + prefs;
        });
    }
    
    public void demonstrateErrorHandling() {
        CompletableFuture<String> future = CompletableFuture
            .supplyAsync(() -> {
                if (Math.random() > 0.5) {
                    throw new RuntimeException("Random failure");
                }
                return "Success";
            })
            .handle((result, throwable) -> {
                if (throwable != null) {
                    return "Error: " + throwable.getMessage();
                }
                return result;
            });
    }
    
    public void demonstrateChaining() {
        CompletableFuture<String> result = CompletableFuture
            .supplyAsync(() -> "Step 1")
            .thenApply(s -> s + " -> Step 2")
            .thenCompose(s -> CompletableFuture.supplyAsync(() -> s + " -> Step 3"))
            .thenAccept(System.out::println);
    }
}
```

**Key Points:**
- `supplyAsync()`: Returns a value
- `runAsync()`: No return value
- `thenApply()`: Transform result synchronously
- `thenCompose()`: Chain asynchronous operations
- `thenCombine()`: Combine two independent futures
- Always handle exceptions with `handle()` or `exceptionally()`

---

## 3. Spring Boot Mastery

### 3.1 Core Spring Concepts (Beginner Level)

#### Q6: Explain Dependency Injection and different types
**Model Answer:**
```java
// 1. Constructor Injection (Recommended)
@Service
public class UserService {
    
    private final UserRepository userRepository;
    private final EmailService emailService;
    
    // Single constructor - @Autowired is optional
    public UserService(UserRepository userRepository, EmailService emailService) {
        this.userRepository = userRepository;
        this.emailService = emailService;
    }
}

// 2. Field Injection (Not recommended)
@Service
public class OrderService {
    
    @Autowired
    private PaymentService paymentService; // Hard to test, can't make final
}

// 3. Setter Injection
@Service
public class ProductService {
    
    private InventoryService inventoryService;
    
    @Autowired
    public void setInventoryService(InventoryService inventoryService) {
        this.inventoryService = inventoryService;
    }
}

// Configuration class
@Configuration
public class AppConfig {
    
    @Bean
    @Primary
    public DataSource primaryDataSource() {
        return DataSourceBuilder.create()
            .url("jdbc:h2:mem:primary")
            .build();
    }
    
    @Bean
    @Qualifier("secondary")
    public DataSource secondaryDataSource() {
        return DataSourceBuilder.create()
            .url("jdbc:h2:mem:secondary")
            .build();
    }
}

// Using qualifiers
@Service
public class DatabaseService {
    
    private final DataSource primaryDataSource;
    private final DataSource secondaryDataSource;
    
    public DatabaseService(
            DataSource primaryDataSource,
            @Qualifier("secondary") DataSource secondaryDataSource) {
        this.primaryDataSource = primaryDataSource;
        this.secondaryDataSource = secondaryDataSource;
    }
}
```

**Key Points:**
- Constructor injection ensures immutability and required dependencies
- Field injection makes testing difficult
- Use `@Primary` and `@Qualifier` for multiple beans of same type
- Spring creates singleton beans by default

#### Q7: Explain Spring Boot Auto-Configuration
**Model Answer:**
```java
// Custom Auto-Configuration
@Configuration
@ConditionalOnClass(KafkaTemplate.class)
@ConditionalOnProperty(name = "app.kafka.enabled", havingValue = "true", matchIfMissing = true)
@EnableConfigurationProperties(KafkaProperties.class)
public class KafkaAutoConfiguration {
    
    @Bean
    @ConditionalOnMissingBean
    public KafkaTemplate<String, Object> kafkaTemplate(
            ProducerFactory<String, Object> producerFactory) {
        return new KafkaTemplate<>(producerFactory);
    }
    
    @Bean
    @ConditionalOnMissingBean
    public ProducerFactory<String, Object> producerFactory(KafkaProperties properties) {
        Map<String, Object> props = new HashMap<>();
        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, properties.getBootstrapServers());
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);
        return new DefaultKafkaProducerFactory<>(props);
    }
}

// Configuration Properties
@ConfigurationProperties(prefix = "app.kafka")
@Data
public class KafkaProperties {
    private String bootstrapServers = "localhost:9092";
    private boolean enabled = true;
    private Producer producer = new Producer();
    private Consumer consumer = new Consumer();
    
    @Data
    public static class Producer {
        private int batchSize = 16384;
        private int lingerMs = 5;
        private String acks = "all";
    }
    
    @Data
    public static class Consumer {
        private String groupId = "default-group";
        private String autoOffsetReset = "earliest";
        private int maxPollRecords = 500;
    }
}

// Register auto-configuration
// META-INF/spring.factories
org.springframework.boot.autoconfigure.EnableAutoConfiguration=\
com.example.autoconfigure.KafkaAutoConfiguration
```

**Key Points:**
- Auto-configuration reduces boilerplate code
- Conditional annotations control when beans are created
- Configuration properties provide type-safe configuration
- Custom auto-configurations should be well-tested

### 3.2 Advanced Spring Boot (Intermediate Level)

#### Q8: Implement custom Spring Boot Starter
**Model Answer:**
```java
// 1. Starter module structure
// my-spring-boot-starter/
// ├── pom.xml
// └── src/main/java/com/example/starter/
//     ├── MyAutoConfiguration.java
//     ├── MyProperties.java
//     └── MyService.java

// 2. Auto-configuration class
@Configuration
@EnableConfigurationProperties(MyProperties.class)
@ConditionalOnClass(MyService.class)
@ConditionalOnProperty(name = "my.starter.enabled", havingValue = "true", matchIfMissing = true)
public class MyAutoConfiguration {
    
    @Bean
    @ConditionalOnMissingBean
    public MyService myService(MyProperties properties) {
        return new MyService(properties);
    }
}

// 3. Configuration properties
@ConfigurationProperties(prefix = "my.starter")
@Data
public class MyProperties {
    
    /**
     * Whether to enable my starter
     */
    private boolean enabled = true;
    
    /**
     * Service timeout in milliseconds
     */
    private int timeout = 5000;
    
    /**
     * Service endpoint URL
     */
    private String endpoint = "http://localhost:8080";
    
    /**
     * Retry configuration
     */
    private Retry retry = new Retry();
    
    @Data
    public static class Retry {
        private int maxAttempts = 3;
        private long backoffMs = 1000;
    }
}

// 4. Service implementation
public class MyService {
    
    private final MyProperties properties;
    private final RestTemplate restTemplate;
    
    public MyService(MyProperties properties) {
        this.properties = properties;
        this.restTemplate = new RestTemplate();
        
        // Configure timeout
        HttpComponentsClientHttpRequestFactory factory = 
            new HttpComponentsClientHttpRequestFactory();
        factory.setConnectTimeout(properties.getTimeout());
        factory.setReadTimeout(properties.getTimeout());
        restTemplate.setRequestFactory(factory);
    }
    
    public String callService(String data) {
        RetryTemplate retryTemplate = RetryTemplate.builder()
            .maxAttempts(properties.getRetry().getMaxAttempts())
            .fixedBackoff(properties.getRetry().getBackoffMs())
            .build();
            
        return retryTemplate.execute(context -> {
            return restTemplate.postForObject(
                properties.getEndpoint() + "/api/process",
                data,
                String.class
            );
        });
    }
}

// 5. Configuration metadata for IDE support
// META-INF/spring-configuration-metadata.json
{
  "groups": [
    {
      "name": "my.starter",
      "type": "com.example.starter.MyProperties",
      "sourceType": "com.example.starter.MyProperties"
    }
  ],
  "properties": [
    {
      "name": "my.starter.enabled",
      "type": "java.lang.Boolean",
      "defaultValue": true,
      "description": "Whether to enable my starter"
    }
  ]
}
```

**Key Points:**
- Separate configuration from implementation
- Use conditional annotations appropriately
- Provide configuration metadata for IDE support
- Follow Spring Boot naming conventions

#### Q9: Implement comprehensive error handling
**Model Answer:**
```java
// 1. Custom Exception Classes
@ResponseStatus(HttpStatus.NOT_FOUND)
public class ResourceNotFoundException extends RuntimeException {
    public ResourceNotFoundException(String message) {
        super(message);
    }
}

@ResponseStatus(HttpStatus.BAD_REQUEST)
public class InvalidRequestException extends RuntimeException {
    public InvalidRequestException(String message) {
        super(message);
    }
}

// 2. Global Exception Handler
@ControllerAdvice
@Slf4j
public class GlobalExceptionHandler {
    
    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<ErrorResponse> handleResourceNotFound(
            ResourceNotFoundException ex, HttpServletRequest request) {
        
        ErrorResponse error = ErrorResponse.builder()
            .timestamp(Instant.now())
            .status(HttpStatus.NOT_FOUND.value())
            .error("Resource Not Found")
            .message(ex.getMessage())
            .path(request.getRequestURI())
            .build();
            
        log.warn("Resource not found: {}", ex.getMessage());
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(error);
    }
    
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ErrorResponse> handleValidationErrors(
            MethodArgumentNotValidException ex, HttpServletRequest request) {
        
        Map<String, String> errors = new HashMap<>();
        ex.getBindingResult().getFieldErrors().forEach(error -> 
            errors.put(error.getField(), error.getDefaultMessage())
        );
        
        ErrorResponse error = ErrorResponse.builder()
            .timestamp(Instant.now())
            .status(HttpStatus.BAD_REQUEST.value())
            .error("Validation Failed")
            .message("Invalid input parameters")
            .path(request.getRequestURI())
            .validationErrors(errors)
            .build();
            
        log.warn("Validation failed: {}", errors);
        return ResponseEntity.badRequest().body(error);
    }
    
    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> handleGenericException(
            Exception ex, HttpServletRequest request) {
        
        ErrorResponse error = ErrorResponse.builder()
            .timestamp(Instant.now())
            .status(HttpStatus.INTERNAL_SERVER_ERROR.value())
            .error("Internal Server Error")
            .message("An unexpected error occurred")
            .path(request.getRequestURI())
            .build();
            
        log.error("Unexpected error: ", ex);
        return ResponseEntity.internalServerError().body(error);
    }
}

// 3. Error Response DTO
@Data
@Builder
public class ErrorResponse {
    private Instant timestamp;
    private int status;
    private String error;
    private String message;
    private String path;
    private Map<String, String> validationErrors;
}

// 4. Service Layer Error Handling
@Service
@Transactional
public class UserService {
    
    private final UserRepository userRepository;
    
    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }
    
    public User findById(Long id) {
        return userRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + id));
    }
    
    public User createUser(CreateUserRequest request) {
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new InvalidRequestException("User already exists with email: " + request.getEmail());
        }
        
        User user = User.builder()
            .name(request.getName())
            .email(request.getEmail())
            .build();
            
        return userRepository.save(user);
    }
}
```

**Key Points:**
- Use `@ControllerAdvice` for global exception handling
- Create specific exception classes with appropriate HTTP status codes
- Provide meaningful error messages and validation details
- Log exceptions at appropriate levels

---

## 4. Kafka Deep Dive

### 4.1 Core Kafka Concepts (Beginner Level)

#### Q10: Explain Kafka architecture and key components
**Model Answer:**
```
Kafka Architecture:

┌─────────────────────────────────────────────────────────────┐
│                        Kafka Cluster                        │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐         │
│  │   Broker 1  │  │   Broker 2  │  │   Broker 3  │         │
│  │             │  │             │  │             │         │
│  │ Topic A     │  │ Topic A     │  │ Topic A     │         │
│  │ Partition 0 │  │ Partition 1 │  │ Partition 2 │         │
│  │ (Leader)    │  │ (Follower)  │  │ (Leader)    │         │
│  │             │  │             │  │             │         │
│  │ Topic B     │  │ Topic B     │  │ Topic B     │         │
│  │ Partition 0 │  │ Partition 0 │  │ Partition 1 │         │
│  │ (Follower)  │  │ (Leader)    │  │ (Follower)  │         │
│  └─────────────┘  └─────────────┘  └─────────────┘         │
└─────────────────────────────────────────────────────────────┘
         │                    │                    │
         └────────────────────┼────────────────────┘
                              │
                    ┌─────────────┐
                    │  ZooKeeper  │
                    │   Cluster   │
                    └─────────────┘

Producers ──────────────────────────────────────────────► Kafka Cluster
                                                                │
                                                                ▼
                                                        Consumer Groups
```

**Key Components:**
1. **Broker**: Kafka server that stores and serves data
2. **Topic**: Category/feed name to which messages are published
3. **Partition**: Ordered, immutable sequence of messages
4. **Producer**: Publishes messages to topics
5. **Consumer**: Reads messages from topics
6. **Consumer Group**: Set of consumers working together
7. **ZooKeeper**: Coordination service (being replaced by KRaft)

#### Q11: How does Kafka ensure message ordering and delivery guarantees?
**Model Answer:**
```java
// 1. Message Ordering
public class MessageOrderingExample {
    
    private final KafkaTemplate<String, Object> kafkaTemplate;
    
    // Ordering within partition is guaranteed
    public void sendOrderedMessages(String userId, List<UserEvent> events) {
        for (UserEvent event : events) {
            // Using userId as key ensures all events for same user go to same partition
            kafkaTemplate.send("user-events", userId, event);
        }
        // Messages will be ordered within the partition for this user
    }
    
    // Custom partitioner for better control
    public static class UserPartitioner implements Partitioner {
        @Override
        public int partition(String topic, Object key, byte[] keyBytes, 
                           Object value, byte[] valueBytes, Cluster cluster) {
            
            if (key == null) {
                return 0; // Default partition for null keys
            }
            
            // Hash user ID to ensure consistent partitioning
            return Math.abs(key.hashCode()) % cluster.partitionCountForTopic(topic);
        }
    }
}

// 2. Delivery Guarantees
public class DeliveryGuaranteesExample {
    
    // At-most-once delivery (may lose messages)
    @Bean
    public KafkaTemplate<String, Object> atMostOnceProducer() {
        Map<String, Object> props = new HashMap<>();
        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
        props.put(ProducerConfig.ACKS_CONFIG, "0"); // No acknowledgment
        props.put(ProducerConfig.RETRIES_CONFIG, 0); // No retries
        return new KafkaTemplate<>(new DefaultKafkaProducerFactory<>(props));
    }
    
    // At-least-once delivery (may duplicate messages)
    @Bean
    public KafkaTemplate<String, Object> atLeastOnceProducer() {
        Map<String, Object> props = new HashMap<>();
        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
        props.put(ProducerConfig.ACKS_CONFIG, "all"); // Wait for all replicas
        props.put(ProducerConfig.RETRIES_CONFIG, Integer.MAX_VALUE);
        props.put(ProducerConfig.ENABLE_IDEMPOTENCE_CONFIG, false);
        return new KafkaTemplate<>(new DefaultKafkaProducerFactory<>(props));
    }
    
    // Exactly-once delivery (idempotent producer + transactional consumer)
    @Bean
    public KafkaTemplate<String, Object> exactlyOnceProducer() {
        Map<String, Object> props = new HashMap<>();
        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
        props.put(ProducerConfig.ACKS_CONFIG, "all");
        props.put(ProducerConfig.RETRIES_CONFIG, Integer.MAX_VALUE);
        props.put(ProducerConfig.ENABLE_IDEMPOTENCE_CONFIG, true);
        props.put(ProducerConfig.TRANSACTIONAL_ID_CONFIG, "my-transactional-id");
        return new KafkaTemplate<>(new DefaultKafkaProducerFactory<>(props));
    }
}
```

**Key Points:**
- **Ordering**: Guaranteed within partition, not across partitions
- **At-most-once**: acks=0, retries=0 (fast but may lose data)
- **At-least-once**: acks=all, retries>0 (may duplicate)
- **Exactly-once**: Idempotent producer + transactions

### 4.2 Advanced Kafka (Intermediate Level)

#### Q12: Explain consumer group rebalancing and partition assignment strategies
**Model Answer:**
```java
// 1. Consumer Group Configuration
@Configuration
public class ConsumerGroupConfig {
    
    @Bean
    public ConsumerFactory<String, Object> consumerFactory() {
        Map<String, Object> props = new HashMap<>();
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
        props.put(ConsumerConfig.GROUP_ID_CONFIG, "my-consumer-group");
        
        // Rebalancing configuration
        props.put(ConsumerConfig.SESSION_TIMEOUT_MS_CONFIG, 30000); // 30 seconds
        props.put(ConsumerConfig.HEARTBEAT_INTERVAL_MS_CONFIG, 10000); // 10 seconds
        props.put(ConsumerConfig.MAX_POLL_INTERVAL_MS_CONFIG, 300000); // 5 minutes
        
        // Partition assignment strategy
        props.put(ConsumerConfig.PARTITION_ASSIGNMENT_STRATEGY_CONFIG, 
                 "org.apache.kafka.clients.consumer.RangeAssignor," +
                 "org.apache.kafka.clients.consumer.RoundRobinAssignor," +
                 "org.apache.kafka.clients.consumer.StickyAssignor");
        
        return new DefaultKafkaConsumerFactory<>(props);
    }
}

// 2. Custom Partition Assignment Strategy
public class PriorityAssignor implements ConsumerPartitionAssignor {
    
    @Override
    public String name() {
        return "priority";
    }
    
    @Override
    public GroupAssignment assign(Cluster metadata, GroupSubscription groupSubscription) {
        Map<String, Assignment> assignments = new HashMap<>();
        
        // Get all partitions to assign
        List<TopicPartition> allPartitions = new ArrayList<>();
        for (String topic : groupSubscription.groupSubscription().values().iterator().next().topics()) {
            List<PartitionInfo> partitionInfos = metadata.partitionsForTopic(topic);
            if (partitionInfos != null) {
                for (PartitionInfo partition : partitionInfos) {
                    allPartitions.add(new TopicPartition(partition.topic(), partition.partition()));
                }
            }
        }
        
        // Sort consumers by priority (from user data)
        List<String> sortedConsumers = groupSubscription.groupSubscription().keySet()
            .stream()
            .sorted((c1, c2) -> {
                int priority1 = getPriority(groupSubscription.groupSubscription().get(c1));
                int priority2 = getPriority(groupSubscription.groupSubscription().get(c2));
                return Integer.compare(priority2, priority1); // Higher priority first
            })
            .collect(Collectors.toList());
        
        // Assign partitions round-robin to sorted consumers
        Map<String, List<TopicPartition>> consumerAssignments = new HashMap<>();
        for (String consumer : sortedConsumers) {
            consumerAssignments.put(consumer, new ArrayList<>());
        }
        
        for (int i = 0; i < allPartitions.size(); i++) {
            String consumer = sortedConsumers.get(i % sortedConsumers.size());
            consumerAssignments.get(consumer).add(allPartitions.get(i));
        }
        
        // Create assignments
        for (Map.Entry<String, List<TopicPartition>> entry : consumerAssignments.entrySet()) {
            assignments.put(entry.getKey(), new Assignment(entry.getValue()));
        }
        
        return new GroupAssignment(assignments);
    }
    
    private int getPriority(Subscription subscription) {
        byte[] userData = subscription.userData();
        return (userData != null && userData.length > 0) ? userData[0] : 0;
    }
}

// 3. Rebalance Listener
@Component
public class RebalanceAwareConsumer {
    
    private static final Logger logger = LoggerFactory.getLogger(RebalanceAwareConsumer.class);
    
    @KafkaListener(
        topics = "my-topic",
        groupId = "rebalance-aware-group",
        containerFactory = "kafkaListenerContainerFactory"
    )
    public void consume(ConsumerRecord<String, Object> record) {
        logger.info("Processing message: {}", record.value());
    }
    
    @EventListener
    public void handleRebalance(ConsumerPartitionsAssignedEvent event) {
        logger.info("Partitions assigned: {}", event.getPartitions());
        // Initialize resources, reset metrics, etc.
    }
    
    @EventListener
    public void handleRebalance(ConsumerPartitionsRevokedEvent event) {
        logger.info("Partitions revoked: {}", event.getPartitions());
        // Cleanup resources, commit offsets, etc.
    }
}
```

**Assignment Strategies:**
1. **Range**: Assigns consecutive partitions to each consumer
2. **Round-Robin**: Distributes partitions evenly across consumers
3. **Sticky**: Minimizes partition movement during rebalancing
4. **Cooperative Sticky**: Allows incremental rebalancing (Kafka 2.4+)

#### Q13: Implement Kafka Streams for real-time processing
**Model Answer:**
```java
// 1. Kafka Streams Configuration
@Configuration
@EnableKafka
@EnableKafkaStreams
public class KafkaStreamsConfig {
    
    @Bean(name = KafkaStreamsDefaultConfiguration.DEFAULT_STREAMS_CONFIG_BEAN_NAME)
    public KafkaStreamsConfiguration kStreamsConfig() {
        Map<String, Object> props = new HashMap<>();
        props.put(StreamsConfig.APPLICATION_ID_CONFIG, "user-activity-processor");
        props.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
        props.put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG, Serdes.String().getClass());
        props.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, Serdes.String().getClass());
        
        // Performance tuning
        props.put(StreamsConfig.NUM_STREAM_THREADS_CONFIG, 4);
        props.put(StreamsConfig.COMMIT_INTERVAL_MS_CONFIG, 1000);
        props.put(StreamsConfig.CACHE_MAX_BYTES_BUFFERING_CONFIG, 10 * 1024 * 1024); // 10MB
        
        return new KafkaStreamsConfiguration(props);
    }
}

// 2. Stream Processing Topology
@Component
public class UserActivityProcessor {
    
    private static final Logger logger = LoggerFactory.getLogger(UserActivityProcessor.class);
    
    @Autowired
    public void buildPipeline(StreamsBuilder streamsBuilder) {
        
        // Input stream
        KStream<String, String> userEvents = streamsBuilder.stream("user-events");
        
        // 1. Filter and transform events
        KStream<String, UserActivity> activities = userEvents
            .filter((key, value) -> value != null && !value.isEmpty())
            .mapValues(this::parseUserEvent)
            .filter((key, activity) -> activity != null);
        
        // 2. Group by user and create session windows
        KTable<Windowed<String>, Long> sessionCounts = activities
            .groupByKey()
            .windowedBy(SessionWindows.ofInactivityGapWithNoGrace(Duration.ofMinutes(30)))
            .count();
        
        // 3. Detect high-activity users
        KStream<String, String> highActivityAlerts = sessionCounts
            .toStream()
            .filter((windowedKey, count) -> count > 100) // More than 100 activities in session
            .map((windowedKey, count) -> KeyValue.pair(
                windowedKey.key(),
                String.format("High activity detected for user %s: %d activities", 
                             windowedKey.key(), count)
            ));
        
        // 4. Aggregate user statistics
        KTable<String, UserStats> userStats = activities
            .groupByKey()
            .aggregate(
                UserStats::new,
                (key, activity, stats) -> stats.update(activity),
                Materialized.<String, UserStats, KeyValueStore<Bytes, byte[]>>as("user-stats-store")
                    .withKeySerde(Serdes.String())
                    .withValueSerde(new JsonSerde<>(UserStats.class))
            );
        
        // 5. Join streams for enriched events
        KStream<String, EnrichedActivity> enrichedActivities = activities
            .join(userStats, 
                  (activity, stats) -> new EnrichedActivity(activity, stats),
                  Joined.with(Serdes.String(), 
                             new JsonSerde<>(UserActivity.class),
                             new JsonSerde<>(UserStats.class)));
        
        // Output streams
        highActivityAlerts.to("high-activity-alerts");
        enrichedActivities.mapValues(this::toJson).to("enriched-activities");
        
        // Log processing
        activities.foreach((key, value) -> 
            logger.debug("Processed activity for user {}: {}", key, value));
    }
    
    private UserActivity parseUserEvent(String eventJson) {
        try {
            ObjectMapper mapper = new ObjectMapper();
            return mapper.readValue(eventJson, UserActivity.class);
        } catch (Exception e) {
            logger.error("Failed to parse user event: {}", eventJson, e);
            return null;
        }
    }
    
    private String toJson(Object object) {
        try {
            ObjectMapper mapper = new ObjectMapper();
            return mapper.writeValueAsString(object);
        } catch (Exception e) {
            logger.error("Failed to serialize object: {}", object, e);
            return "{}";
        }
    }
}

// 3. Data Models
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserActivity {
    private String userId;
    private String activityType;
    private Instant timestamp;
    private Map<String, Object> data;
}

@Data
@NoArgsConstructor
public class UserStats {
    private long totalActivities = 0;
    private Map<String, Long> activityCounts = new HashMap<>();
    private Instant lastActivity;
    private Instant firstActivity;
    
    public UserStats update(UserActivity activity) {
        totalActivities++;
        activityCounts.merge(activity.getActivityType(), 1L, Long::sum);
        lastActivity = activity.getTimestamp();
        if (firstActivity == null) {
            firstActivity = activity.getTimestamp();
        }
        return this;
    }
}

@Data
@AllArgsConstructor
public class EnrichedActivity {
    private UserActivity activity;
    private UserStats userStats;
}

// 4. Interactive Queries
@RestController
@RequestMapping("/api/user-stats")
public class UserStatsController {
    
    private final KafkaStreams kafkaStreams;
    
    public UserStatsController(KafkaStreams kafkaStreams) {
        this.kafkaStreams = kafkaStreams;
    }
    
    @GetMapping("/{userId}")
    public ResponseEntity<UserStats> getUserStats(@PathVariable String userId) {
        ReadOnlyKeyValueStore<String, UserStats> store = kafkaStreams
            .store(StoreQueryParameters.fromNameAndType("user-stats-store", 
                   QueryableStoreTypes.keyValueStore()));
        
        UserStats stats = store.get(userId);
        if (stats != null) {
            return ResponseEntity.ok(stats);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
    
    @GetMapping("/top-users")
    public ResponseEntity<List<TopUser>> getTopUsers(@RequestParam(defaultValue = "10") int limit) {
        ReadOnlyKeyValueStore<String, UserStats> store = kafkaStreams
            .store(StoreQueryParameters.fromNameAndType("user-stats-store", 
                   QueryableStoreTypes.keyValueStore()));
        
        List<TopUser> topUsers = new ArrayList<>();
        KeyValueIterator<String, UserStats> iterator = store.all();
        
        while (iterator.hasNext()) {
            KeyValue<String, UserStats> kv = iterator.next();
            topUsers.add(new TopUser(kv.key, kv.value.getTotalActivities()));
        }
        
        iterator.close();
        
        return ResponseEntity.ok(
            topUsers.stream()
                .sorted((a, b) -> Long.compare(b.getActivityCount(), a.getActivityCount()))
                .limit(limit)
                .collect(Collectors.toList())
        );
    }
    
    @Data
    @AllArgsConstructor
    public static class TopUser {
        private String userId;
        private long activityCount;
    }
}
```

**Key Points:**
- **Stateless Operations**: filter, map, flatMap
- **Stateful Operations**: aggregate, join, windowing
- **Time Windows**: Tumbling, hopping, session windows
- **Interactive Queries**: Query stream processing state in real-time

---

## 5. System Design

### 5.1 Scalability Patterns (Senior Level)

#### Q14: Design a scalable event-driven e-commerce system
**Model Answer:**

```mermaid
graph TB
    subgraph "Client Layer"
        WEB[Web App]
        MOBILE[Mobile App]
        API[API Gateway]
    end
    
    subgraph "Service Layer"
        USER[User Service]
        PRODUCT[Product Service]
        ORDER[Order Service]
        PAYMENT[Payment Service]
        INVENTORY[Inventory Service]
        NOTIFICATION[Notification Service]
    end
    
    subgraph "Event Streaming"
        KAFKA[Kafka Cluster]
    end
    
    subgraph "Data Layer"
        USERDB[(User DB)]
        PRODUCTDB[(Product DB)]
        ORDERDB[(Order DB)]
        CACHE[Redis Cache]
    end
    
    subgraph "External Services"
        PAYMENTGW[Payment Gateway]
        EMAIL[Email Service]
        SMS[SMS Service]
    end
    
    WEB --> API
    MOBILE --> API
    API --> USER
    API --> PRODUCT
    API --> ORDER
    
    USER --> KAFKA
    PRODUCT --> KAFKA
    ORDER --> KAFKA
    PAYMENT --> KAFKA
    INVENTORY --> KAFKA
    
    KAFKA --> USER
    KAFKA --> PRODUCT
    KAFKA --> ORDER
    KAFKA --> PAYMENT
    KAFKA --> INVENTORY
    KAFKA --> NOTIFICATION
    
    USER --> USERDB
    PRODUCT --> PRODUCTDB
    ORDER --> ORDERDB
    
    PRODUCT --> CACHE
    USER --> CACHE
    
    PAYMENT --> PAYMENTGW
    NOTIFICATION --> EMAIL
    NOTIFICATION --> SMS
```

**Implementation Strategy:**

```java
// 1. Event-Driven Architecture
public enum EventType {
    USER_REGISTERED,
    USER_UPDATED,
    PRODUCT_CREATED,
    PRODUCT_UPDATED,
    ORDER_PLACED,
    ORDER_CONFIRMED,
    ORDER_SHIPPED,
    ORDER_DELIVERED,
    PAYMENT_INITIATED,
    PAYMENT_COMPLETED,
    PAYMENT_FAILED,
    INVENTORY_RESERVED,
    INVENTORY_RELEASED
}

// 2. Domain Events
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, property = "eventType")
@JsonSubTypes({
    @JsonSubTypes.Type(value = OrderPlacedEvent.class, name = "ORDER_PLACED"),
    @JsonSubTypes.Type(value = PaymentCompletedEvent.class, name = "PAYMENT_COMPLETED"),
    @JsonSubTypes.Type(value = InventoryReservedEvent.class, name = "INVENTORY_RESERVED")
})
public abstract class DomainEvent {
    private final String eventId = UUID.randomUUID().toString();
    private final Instant timestamp = Instant.now();
    private final String eventType;
    
    protected DomainEvent(String eventType) {
        this.eventType = eventType;
    }
    
    // Getters...
}

// 3. Saga Orchestrator Pattern
@Service
public class OrderSagaOrchestrator {
    
    private final KafkaTemplate<String, Object> kafkaTemplate;
    private final SagaStateRepository sagaStateRepository;
    
    @KafkaListener(topics = "order-events")
    public void handleOrderPlaced(OrderPlacedEvent event) {
        SagaState saga = SagaState.builder()
            .sagaId(event.getOrderId())
            .currentStep(SagaStep.ORDER_PLACED)
            .status(SagaStatus.IN_PROGRESS)
            .build();
            
        sagaStateRepository.save(saga);
        
        // Step 1: Reserve inventory
        InventoryReservationCommand command = new InventoryReservationCommand(
            event.getOrderId(),
            event.getProductId(),
            event.getQuantity()
        );
        
        kafkaTemplate.send("inventory-commands", event.getOrderId(), command);
    }
    
    @KafkaListener(topics = "inventory-events")
    public void handleInventoryReserved(InventoryReservedEvent event) {
        SagaState saga = sagaStateRepository.findBySagaId(event.getOrderId());
        saga.setCurrentStep(SagaStep.INVENTORY_RESERVED);
        sagaStateRepository.save(saga);
        
        // Step 2: Process payment
        PaymentProcessingCommand command = new PaymentProcessingCommand(
            event.getOrderId(),
            event.getUserId(),
            event.getAmount()
        );
        
        kafkaTemplate.send("payment-commands", event.getOrderId(), command);
    }
    
    @KafkaListener(topics = "payment-events")
    public void handlePaymentCompleted(PaymentCompletedEvent event) {
        SagaState saga = sagaStateRepository.findBySagaId(event.getOrderId());
        saga.setCurrentStep(SagaStep.PAYMENT_COMPLETED);
        saga.setStatus(SagaStatus.COMPLETED);
        sagaStateRepository.save(saga);
        
        // Step 3: Confirm order
        OrderConfirmationCommand command = new OrderConfirmationCommand(
            event.getOrderId(),
            "Order completed successfully"
        );
        
        kafkaTemplate.send("order-commands", event.getOrderId(), command);
    }
    
    // Compensation handlers for failures...
}

// 4. CQRS Implementation
@Service
public class ProductQueryService {
    
    private final ProductReadModelRepository repository;
    private final RedisTemplate<String, Object> redisTemplate;
    
    public ProductReadModel getProduct(String productId) {
        // Try cache first
        String cacheKey = "product:" + productId;
        ProductReadModel cached = (ProductReadModel) redisTemplate.opsForValue().get(cacheKey);
        
        if (cached != null) {
            return cached;
        }
        
        // Fallback to database
        ProductReadModel product = repository.findById(productId)
            .orElseThrow(() -> new ProductNotFoundException(productId));
            
        // Cache for future requests
        redisTemplate.opsForValue().set(cacheKey, product, Duration.ofMinutes(15));
        
        return product;
    }
    
    public List<ProductReadModel> searchProducts(ProductSearchCriteria criteria) {
        // Implement search with caching, pagination, etc.
        return repository.findByCriteria(criteria);
    }
}

// 5. Event Projector for Read Models
@Service
public class ProductReadModelProjector {
    
    private final ProductReadModelRepository repository;
    private final RedisTemplate<String, Object> redisTemplate;
    
    @KafkaListener(topics = "product-events")
    public void handleProductCreated(ProductCreatedEvent event) {
        ProductReadModel readModel = ProductReadModel.builder()
            .productId(event.getProductId())
            .name(event.getName())
            .description(event.getDescription())
            .price(event.getPrice())
            .category(event.getCategory())
            .createdAt(event.getTimestamp())
            .updatedAt(event.getTimestamp())
            .build();
            
        repository.save(readModel);
        
        // Invalidate cache
        redisTemplate.delete("product:" + event.getProductId());
    }
    
    @KafkaListener(topics = "inventory-events")
    public void handleInventoryUpdated(InventoryUpdatedEvent event) {
        repository.updateInventory(event.getProductId(), event.getQuantity());
        redisTemplate.delete("product:" + event.getProductId());
    }
}
```

**Scalability Considerations:**
1. **Horizontal Scaling**: Stateless services, database sharding
2. **Caching Strategy**: Redis for read-heavy operations
3. **Event Sourcing**: Audit trail and state reconstruction
4. **Circuit Breakers**: Prevent cascading failures
5. **Load Balancing**: Distribute traffic across instances

#### Q15: Design a real-time analytics system using Kafka
**Model Answer:**

```java
// 1. Real-time Analytics Architecture
@Component
public class RealTimeAnalyticsProcessor {
    
    @Autowired
    public void buildAnalyticsPipeline(StreamsBuilder streamsBuilder) {
        
        // Input streams
        KStream<String, UserEvent> userEvents = streamsBuilder
            .stream("user-events", Consumed.with(Serdes.String(), new JsonSerde<>(UserEvent.class)));
            
        KStream<String, OrderEvent> orderEvents = streamsBuilder
            .stream("order-events", Consumed.with(Serdes.String(), new JsonSerde<>(OrderEvent.class)));
        
        // 1. Real-time user activity metrics
        KTable<Windowed<String>, Long> activeUsers = userEvents
            .filter((key, event) -> "PAGE_VIEW".equals(event.getEventType()))
            .groupBy((key, event) -> event.getUserId())
            .windowedBy(TimeWindows.ofSizeWithNoGrace(Duration.ofMinutes(5)))
            .count(Materialized.as("active-users-store"));
        
        // 2. Revenue metrics by time window
        KTable<Windowed<String>, Double> revenueByWindow = orderEvents
            .filter((key, event) -> "ORDER_COMPLETED".equals(event.getEventType()))
            .groupBy((key, event) -> "revenue") // Single key for global aggregation
            .windowedBy(TimeWindows.ofSizeWithNoGrace(Duration.ofMinutes(1)))
            .aggregate(
                () -> 0.0,
                (key, event, aggregate) -> aggregate + event.getAmount(),
                Materialized.<String, Double, WindowStore<Bytes, byte[]>>as("revenue-store")
                    .withValueSerde(Serdes.Double())
            );
        
        // 3. Top products by sales
        KTable<String, Long> productSales = orderEvents
            .filter((key, event) -> "ORDER_COMPLETED".equals(event.getEventType()))
            .groupBy((key, event) -> event.getProductId())
            .count(Materialized.as("product-sales-store"));
        
        // 4. Anomaly detection
        KStream<String, AnomalyAlert> anomalies = orderEvents
            .filter((key, event) -> "ORDER_COMPLETED".equals(event.getEventType()))
            .groupByKey()
            .windowedBy(TimeWindows.ofSizeWithNoGrace(Duration.ofMinutes(10)))
            .aggregate(
                OrderStats::new,
                (key, event, stats) -> stats.addOrder(event),
                Materialized.<String, OrderStats, WindowStore<Bytes, byte[]>>as("order-stats")
                    .withValueSerde(new JsonSerde<>(OrderStats.class))
            )
            .toStream()
            .filter((windowedKey, stats) -> stats.isAnomalous())
            .map((windowedKey, stats) -> KeyValue.pair(
                windowedKey.key(),
                new AnomalyAlert(windowedKey.key(), "High order frequency", stats)
            ));
        
        // 5. Customer segmentation
        KTable<String, CustomerSegment> customerSegments = userEvents
            .join(orderEvents,
                  (userEvent, orderEvent) -> new CustomerActivity(userEvent, orderEvent),
                  JoinWindows.ofTimeDifferenceWithNoGrace(Duration.ofHours(1)))
            .groupBy((key, activity) -> activity.getUserId())
            .aggregate(
                CustomerProfile::new,
                (key, activity, profile) -> profile.update(activity),
                Materialized.<String, CustomerProfile, KeyValueStore<Bytes, byte[]>>as("customer-profiles")
                    .withValueSerde(new JsonSerde<>(CustomerProfile.class))
            )
            .mapValues(CustomerSegment::fromProfile);
        
        // Output processed data
        activeUsers.toStream().to("analytics-active-users");
        revenueByWindow.toStream().to("analytics-revenue");
        productSales.toStream().to("analytics-product-sales");
        anomalies.to("analytics-anomalies");
        customerSegments.toStream().to("analytics-customer-segments");
    }
}

// 2. Analytics Dashboard API
@RestController
@RequestMapping("/api/analytics")
public class AnalyticsDashboardController {
    
    private final KafkaStreams kafkaStreams;
    
    @GetMapping("/active-users")
    public ResponseEntity<Map<String, Long>> getActiveUsers() {
        ReadOnlyWindowStore<String, Long> store = kafkaStreams.store(
            StoreQueryParameters.fromNameAndType("active-users-store", 
                                                 QueryableStoreTypes.windowStore()));
        
        Map<String, Long> activeUsers = new HashMap<>();
        Instant now = Instant.now();
        Instant from = now.minus(Duration.ofMinutes(5));
        
        try (WindowStoreIterator<Long> iterator = store.fetch("", from, now)) {
            while (iterator.hasNext()) {
                KeyValue<Long, Long> kv = iterator.next();
                activeUsers.put(Instant.ofEpochMilli(kv.key).toString(), kv.value);
            }
        }
        
        return ResponseEntity.ok(activeUsers);
    }
    
    @GetMapping("/revenue/current")
    public ResponseEntity<RevenueMetrics> getCurrentRevenue() {
        ReadOnlyWindowStore<String, Double> store = kafkaStreams.store(
            StoreQueryParameters.fromNameAndType("revenue-store", 
                                                 QueryableStoreTypes.windowStore()));
        
        Instant now = Instant.now();
        Instant from = now.minus(Duration.ofMinutes(1));
        
        double currentRevenue = 0.0;
        try (WindowStoreIterator<Double> iterator = store.fetch("revenue", from, now)) {
            while (iterator.hasNext()) {
                currentRevenue += iterator.next().value;
            }
        }
        
        RevenueMetrics metrics = RevenueMetrics.builder()
            .currentMinuteRevenue(currentRevenue)
            .timestamp(now)
            .build();
            
        return ResponseEntity.ok(metrics);
    }
    
    @GetMapping("/products/top")
    public ResponseEntity<List<ProductSalesMetric>> getTopProducts(
            @RequestParam(defaultValue = "10") int limit) {
        
        ReadOnlyKeyValueStore<String, Long> store = kafkaStreams.store(
            StoreQueryParameters.fromNameAndType("product-sales-store", 
                                                 QueryableStoreTypes.keyValueStore()));
        
        List<ProductSalesMetric> topProducts = new ArrayList<>();
        KeyValueIterator<String, Long> iterator = store.all();
        
        while (iterator.hasNext()) {
            KeyValue<String, Long> kv = iterator.next();
            topProducts.add(new ProductSalesMetric(kv.key, kv.value));
        }
        
        iterator.close();
        
        return ResponseEntity.ok(
            topProducts.stream()
                .sorted((a, b) -> Long.compare(b.getSalesCount(), a.getSalesCount()))
                .limit(limit)
                .collect(Collectors.toList())
        );
    }
}

// 3. Real-time Alerting
@Service
public class AlertingService {
    
    private final NotificationService notificationService;
    
    @KafkaListener(topics = "analytics-anomalies")
    public void handleAnomalyAlert(AnomalyAlert alert) {
        // Send immediate alert to operations team
        AlertMessage message = AlertMessage.builder()
            .severity(AlertSeverity.HIGH)
            .title("Order Anomaly Detected")
            .description(alert.getDescription())
            .timestamp(Instant.now())
            .metadata(Map.of(
                "customerId", alert.getCustomerId(),
                "orderStats", alert.getOrderStats()
            ))
            .build();
            
        notificationService.sendAlert(message);
    }
    
    @KafkaListener(topics = "analytics-revenue")
    public void handleRevenueUpdate(ConsumerRecord<String, Double> record) {
        double revenue = record.value();
        
        // Check for revenue thresholds
        if (revenue > 10000) { // $10k per minute threshold
            AlertMessage message = AlertMessage.builder()
                .severity(AlertSeverity.INFO)
                .title("High Revenue Period")
                .description(String.format("Revenue of $%.2f in the last minute", revenue))
                .timestamp(Instant.now())
                .build();
                
            notificationService.sendAlert(message);
        }
    }
}
```

**Key Components:**
1. **Stream Processing**: Real-time aggregations and transformations
2. **Windowing**: Time-based analytics (tumbling, hopping, session windows)
3. **State Stores**: Queryable state for interactive queries
4. **Anomaly Detection**: Statistical analysis for unusual patterns
5. **Real-time Dashboards**: Live metrics and KPIs

---

*[The document continues with the remaining sections covering more interview questions, exercises, cheat sheets, and expert-level scenarios...]*
