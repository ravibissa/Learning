# Kafka + Spring Boot Complete Tutorial
## From Fundamentals to Production

*A comprehensive guide for developers and architects*  
*Author: Senior Software Engineer with 15+ years experience*

---

## Table of Contents

1. [Introduction & Setup](#1-introduction--setup)
2. [Kafka Fundamentals](#2-kafka-fundamentals)
3. [Spring Boot Integration](#3-spring-boot-integration)
4. [Kafka Internals Deep Dive](#4-kafka-internals-deep-dive)
5. [Microservices Architecture](#5-microservices-architecture)
6. [Performance Tuning](#6-performance-tuning)
7. [Security Implementation](#7-security-implementation)
8. [Monitoring & Observability](#8-monitoring--observability)
9. [Testing Strategies](#9-testing-strategies)
10. [Resilience Patterns](#10-resilience-patterns)
11. [Deployment & Operations](#11-deployment--operations)
12. [CI/CD Pipeline](#12-cicd-pipeline)

---

## 1. Introduction & Setup

### Prerequisites
- Java 21 (LTS)
- Spring Boot 3.2+
- Apache Kafka 2.8+ (Latest stable: 3.6)
- Docker & Docker Compose
- Maven/Gradle
- IDE (IntelliJ IDEA recommended)

### Project Setup

#### 1.1 Maven Dependencies

```xml
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 
         http://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>
    
    <parent>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-parent</artifactId>
        <version>3.2.1</version>
        <relativePath/>
    </parent>
    
    <groupId>com.example</groupId>
    <artifactId>kafka-spring-tutorial</artifactId>
    <version>1.0.0</version>
    <packaging>jar</packaging>
    
    <properties>
        <java.version>21</java.version>
        <kafka.version>3.6.1</kafka.version>
        <testcontainers.version>1.19.3</testcontainers.version>
    </properties>
    
    <dependencies>
        <!-- Spring Boot Starters -->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-web</artifactId>
        </dependency>
        
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-actuator</artifactId>
        </dependency>
        
        <!-- Kafka Dependencies -->
        <dependency>
            <groupId>org.springframework.kafka</groupId>
            <artifactId>spring-kafka</artifactId>
        </dependency>
        
        <dependency>
            <groupId>org.apache.kafka</groupId>
            <artifactId>kafka-streams</artifactId>
        </dependency>
        
        <!-- JSON Processing -->
        <dependency>
            <groupId>com.fasterxml.jackson.core</groupId>
            <artifactId>jackson-databind</artifactId>
        </dependency>
        
        <!-- Validation -->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-validation</artifactId>
        </dependency>
        
        <!-- Monitoring -->
        <dependency>
            <groupId>io.micrometer</groupId>
            <artifactId>micrometer-registry-prometheus</artifactId>
        </dependency>
        
        <!-- Testing -->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-test</artifactId>
            <scope>test</scope>
        </dependency>
        
        <dependency>
            <groupId>org.springframework.kafka</groupId>
            <artifactId>spring-kafka-test</artifactId>
            <scope>test</scope>
        </dependency>
        
        <dependency>
            <groupId>org.testcontainers</groupId>
            <artifactId>kafka</artifactId>
            <version>${testcontainers.version}</version>
            <scope>test</scope>
        </dependency>
        
        <dependency>
            <groupId>org.testcontainers</groupId>
            <artifactId>junit-jupiter</artifactId>
            <version>${testcontainers.version}</version>
            <scope>test</scope>
        </dependency>
    </dependencies>
    
    <build>
        <plugins>
            <plugin>
                <groupId>org.springframework.boot</groupId>
                <artifactId>spring-boot-maven-plugin</artifactId>
            </plugin>
        </plugins>
    </build>
</project>
```

#### 1.2 Docker Compose Setup

```yaml
# docker-compose.yml
version: '3.8'
services:
  zookeeper:
    image: confluentinc/cp-zookeeper:7.5.0
    hostname: zookeeper
    container_name: zookeeper
    ports:
      - "2181:2181"
    environment:
      ZOOKEEPER_CLIENT_PORT: 2181
      ZOOKEEPER_TICK_TIME: 2000
    volumes:
      - zookeeper-data:/var/lib/zookeeper/data
      - zookeeper-logs:/var/lib/zookeeper/log

  kafka:
    image: confluentinc/cp-kafka:7.5.0
    hostname: kafka
    container_name: kafka
    depends_on:
      - zookeeper
    ports:
      - "9092:9092"
      - "9101:9101"
    environment:
      KAFKA_BROKER_ID: 1
      KAFKA_ZOOKEEPER_CONNECT: 'zookeeper:2181'
      KAFKA_LISTENER_SECURITY_PROTOCOL_MAP: PLAINTEXT:PLAINTEXT,PLAINTEXT_HOST:PLAINTEXT
      KAFKA_ADVERTISED_LISTENERS: PLAINTEXT://kafka:29092,PLAINTEXT_HOST://localhost:9092
      KAFKA_METRIC_REPORTERS: io.confluent.metrics.reporter.ConfluentMetricsReporter
      KAFKA_OFFSETS_TOPIC_REPLICATION_FACTOR: 1
      KAFKA_GROUP_INITIAL_REBALANCE_DELAY_MS: 0
      KAFKA_CONFLUENT_METRICS_REPORTER_BOOTSTRAP_SERVERS: kafka:29092
      KAFKA_CONFLUENT_METRICS_REPORTER_TOPIC_REPLICAS: 1
      KAFKA_CONFLUENT_METRICS_ENABLE: 'true'
      KAFKA_CONFLUENT_SUPPORT_CUSTOMER_ID: anonymous
      KAFKA_AUTO_CREATE_TOPICS_ENABLE: 'false'
      KAFKA_JMX_PORT: 9101
      KAFKA_JMX_HOSTNAME: localhost
    volumes:
      - kafka-data:/var/lib/kafka/data

  schema-registry:
    image: confluentinc/cp-schema-registry:7.5.0
    hostname: schema-registry
    container_name: schema-registry
    depends_on:
      - kafka
    ports:
      - "8081:8081"
    environment:
      SCHEMA_REGISTRY_HOST_NAME: schema-registry
      SCHEMA_REGISTRY_KAFKASTORE_BOOTSTRAP_SERVERS: 'kafka:29092'
      SCHEMA_REGISTRY_LISTENERS: http://0.0.0.0:8081

  kafka-ui:
    image: provectuslabs/kafka-ui:latest
    container_name: kafka-ui
    depends_on:
      - kafka
      - schema-registry
    ports:
      - "8080:8080"
    environment:
      KAFKA_CLUSTERS_0_NAME: local
      KAFKA_CLUSTERS_0_BOOTSTRAPSERVERS: kafka:29092
      KAFKA_CLUSTERS_0_SCHEMAREGISTRY: http://schema-registry:8081

volumes:
  zookeeper-data:
  zookeeper-logs:
  kafka-data:
```

### Key Takeaways - Setup
- Java 21 provides performance improvements and modern language features
- Spring Boot 3.2+ offers native compilation and improved observability
- Docker Compose simplifies local development environment
- Kafka UI provides excellent visualization and management capabilities

---

## 2. Kafka Fundamentals

### 2.1 Core Concepts

#### Topics and Partitions
```mermaid
graph TB
    T[Topic: user-events] --> P1[Partition 0]
    T --> P2[Partition 1]
    T --> P3[Partition 2]
    
    P1 --> M1[Message 0]
    P1 --> M2[Message 3]
    P1 --> M3[Message 6]
    
    P2 --> M4[Message 1]
    P2 --> M5[Message 4]
    P2 --> M6[Message 7]
    
    P3 --> M7[Message 2]
    P3 --> M8[Message 5]
    P3 --> M9[Message 8]
```

#### Producer Architecture
```java
package com.example.kafka.config;

import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.support.serializer.JsonSerializer;

import java.util.HashMap;
import java.util.Map;

/**
 * Kafka Producer Configuration
 * Optimized for high throughput and reliability
 */
@Configuration
public class KafkaProducerConfig {

    @Value("${spring.kafka.bootstrap-servers:localhost:9092}")
    private String bootstrapServers;

    @Bean
    public ProducerFactory<String, Object> producerFactory() {
        Map<String, Object> configProps = new HashMap<>();
        
        // Connection Properties
        configProps.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
        configProps.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        configProps.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);
        
        // Performance Tuning
        configProps.put(ProducerConfig.ACKS_CONFIG, "all"); // Wait for all replicas
        configProps.put(ProducerConfig.RETRIES_CONFIG, 3);
        configProps.put(ProducerConfig.BATCH_SIZE_CONFIG, 16384); // 16KB batches
        configProps.put(ProducerConfig.LINGER_MS_CONFIG, 5); // Wait 5ms for batching
        configProps.put(ProducerConfig.BUFFER_MEMORY_CONFIG, 33554432); // 32MB buffer
        
        // Reliability
        configProps.put(ProducerConfig.ENABLE_IDEMPOTENCE_CONFIG, true);
        configProps.put(ProducerConfig.MAX_IN_FLIGHT_REQUESTS_PER_CONNECTION, 5);
        
        // Compression
        configProps.put(ProducerConfig.COMPRESSION_TYPE_CONFIG, "snappy");
        
        return new DefaultKafkaProducerFactory<>(configProps);
    }

    @Bean
    public KafkaTemplate<String, Object> kafkaTemplate() {
        return new KafkaTemplate<>(producerFactory());
    }
}
```

#### Consumer Configuration
```java
package com.example.kafka.config;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.listener.ContainerProperties;
import org.springframework.kafka.support.serializer.JsonDeserializer;

import java.util.HashMap;
import java.util.Map;

/**
 * Kafka Consumer Configuration
 * Optimized for reliability and error handling
 */
@Configuration
@EnableKafka
public class KafkaConsumerConfig {

    @Value("${spring.kafka.bootstrap-servers:localhost:9092}")
    private String bootstrapServers;

    @Bean
    public ConsumerFactory<String, Object> consumerFactory() {
        Map<String, Object> props = new HashMap<>();
        
        // Connection Properties
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, JsonDeserializer.class);
        
        // Consumer Group Configuration
        props.put(ConsumerConfig.GROUP_ID_CONFIG, "default-group");
        props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
        
        // Performance Tuning
        props.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, 500);
        props.put(ConsumerConfig.MAX_POLL_INTERVAL_MS_CONFIG, 300000); // 5 minutes
        props.put(ConsumerConfig.SESSION_TIMEOUT_MS_CONFIG, 30000); // 30 seconds
        props.put(ConsumerConfig.HEARTBEAT_INTERVAL_MS_CONFIG, 10000); // 10 seconds
        
        // Reliability
        props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, false); // Manual commit
        props.put(ConsumerConfig.FETCH_MIN_BYTES_CONFIG, 1024); // 1KB minimum fetch
        props.put(ConsumerConfig.FETCH_MAX_WAIT_MS_CONFIG, 500); // 500ms max wait
        
        // JSON Deserializer Configuration
        props.put(JsonDeserializer.TRUSTED_PACKAGES, "com.example.kafka.model");
        props.put(JsonDeserializer.USE_TYPE_INFO_HEADERS, false);
        props.put(JsonDeserializer.VALUE_DEFAULT_TYPE, "com.example.kafka.model.GenericMessage");
        
        return new DefaultKafkaConsumerFactory<>(props);
    }

    @Bean
    public ConcurrentKafkaListenerContainerFactory<String, Object> kafkaListenerContainerFactory() {
        ConcurrentKafkaListenerContainerFactory<String, Object> factory = 
            new ConcurrentKafkaListenerContainerFactory<>();
        
        factory.setConsumerFactory(consumerFactory());
        
        // Concurrency Configuration
        factory.setConcurrency(3); // 3 consumer threads per partition
        
        // Acknowledgment Configuration
        factory.getContainerProperties().setAckMode(ContainerProperties.AckMode.MANUAL_IMMEDIATE);
        
        // Error Handling
        factory.setCommonErrorHandler(new DefaultErrorHandler());
        
        return factory;
    }
}
```

### 2.2 Message Models

#### Base Message Interface
```java
package com.example.kafka.model;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;

import java.time.Instant;
import java.util.Map;

/**
 * Base interface for all Kafka messages
 * Provides common fields and type information for polymorphic deserialization
 */
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, property = "type")
@JsonSubTypes({
    @JsonSubTypes.Type(value = UserEvent.class, name = "USER_EVENT"),
    @JsonSubTypes.Type(value = OrderEvent.class, name = "ORDER_EVENT"),
    @JsonSubTypes.Type(value = PaymentEvent.class, name = "PAYMENT_EVENT")
})
public interface KafkaMessage {
    String getId();
    String getType();
    Instant getTimestamp();
    Map<String, Object> getMetadata();
}
```

#### User Event Model
```java
package com.example.kafka.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.time.Instant;
import java.util.Map;
import java.util.UUID;

/**
 * User Event Message
 * Represents user actions in the system
 */
public record UserEvent(
    @JsonProperty("id") @NotBlank String id,
    @JsonProperty("type") String type,
    @JsonProperty("timestamp") @NotNull Instant timestamp,
    @JsonProperty("userId") @NotBlank String userId,
    @JsonProperty("action") @NotBlank String action,
    @JsonProperty("data") Map<String, Object> data,
    @JsonProperty("metadata") Map<String, Object> metadata
) implements KafkaMessage {

    @JsonCreator
    public UserEvent(
            @JsonProperty("id") String id,
            @JsonProperty("timestamp") Instant timestamp,
            @JsonProperty("userId") String userId,
            @JsonProperty("action") String action,
            @JsonProperty("data") Map<String, Object> data,
            @JsonProperty("metadata") Map<String, Object> metadata) {
        this(
            id != null ? id : UUID.randomUUID().toString(),
            "USER_EVENT",
            timestamp != null ? timestamp : Instant.now(),
            userId,
            action,
            data != null ? data : Map.of(),
            metadata != null ? metadata : Map.of()
        );
    }

    public static UserEvent create(String userId, String action, Map<String, Object> data) {
        return new UserEvent(null, null, userId, action, data, null);
    }

    @Override
    public String getId() {
        return id;
    }

    @Override
    public String getType() {
        return type;
    }

    @Override
    public Instant getTimestamp() {
        return timestamp;
    }

    @Override
    public Map<String, Object> getMetadata() {
        return metadata;
    }
}
```

### 2.3 Producer Implementation

```java
package com.example.kafka.service;

import com.example.kafka.model.KafkaMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Service;

import java.util.concurrent.CompletableFuture;

/**
 * Generic Kafka Message Producer
 * Handles message publishing with proper error handling and monitoring
 */
@Service
public class KafkaMessageProducer {

    private static final Logger logger = LoggerFactory.getLogger(KafkaMessageProducer.class);
    
    private final KafkaTemplate<String, Object> kafkaTemplate;

    public KafkaMessageProducer(KafkaTemplate<String, Object> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    /**
     * Send message asynchronously with callback handling
     */
    public CompletableFuture<SendResult<String, Object>> sendMessage(
            String topic, 
            String key, 
            KafkaMessage message) {
        
        logger.info("Sending message to topic: {}, key: {}, messageId: {}", 
                   topic, key, message.getId());
        
        return kafkaTemplate.send(topic, key, message)
            .whenComplete((result, ex) -> {
                if (ex == null) {
                    logger.info("Successfully sent message to topic: {}, partition: {}, offset: {}", 
                               result.getRecordMetadata().topic(),
                               result.getRecordMetadata().partition(),
                               result.getRecordMetadata().offset());
                } else {
                    logger.error("Failed to send message to topic: {}, key: {}, error: {}", 
                                topic, key, ex.getMessage(), ex);
                }
            });
    }

    /**
     * Send message synchronously (blocking)
     * Use sparingly - prefer async for better performance
     */
    public SendResult<String, Object> sendMessageSync(
            String topic, 
            String key, 
            KafkaMessage message) {
        try {
            logger.info("Sending message synchronously to topic: {}, key: {}", topic, key);
            return kafkaTemplate.send(topic, key, message).get();
        } catch (Exception e) {
            logger.error("Failed to send message synchronously", e);
            throw new RuntimeException("Failed to send message", e);
        }
    }

    /**
     * Send message with custom partition
     */
    public CompletableFuture<SendResult<String, Object>> sendMessageToPartition(
            String topic, 
            int partition,
            String key, 
            KafkaMessage message) {
        
        logger.info("Sending message to topic: {}, partition: {}, key: {}", 
                   topic, partition, key);
        
        return kafkaTemplate.send(topic, partition, key, message)
            .whenComplete((result, ex) -> {
                if (ex == null) {
                    logger.info("Successfully sent message to specific partition: {}", partition);
                } else {
                    logger.error("Failed to send message to specific partition: {}", partition, ex);
                }
            });
    }
}
```

### 2.4 Consumer Implementation

```java
package com.example.kafka.service;

import com.example.kafka.model.KafkaMessage;
import com.example.kafka.model.UserEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

/**
 * Kafka Message Consumer
 * Handles message consumption with proper acknowledgment and error handling
 */
@Service
public class KafkaMessageConsumer {

    private static final Logger logger = LoggerFactory.getLogger(KafkaMessageConsumer.class);

    /**
     * Generic message consumer with manual acknowledgment
     */
    @KafkaListener(
        topics = "${app.kafka.topics.user-events:user-events}",
        groupId = "${app.kafka.consumer.group-id:user-service}",
        containerFactory = "kafkaListenerContainerFactory"
    )
    public void consumeUserEvent(
            @Payload UserEvent message,
            @Header(KafkaHeaders.RECEIVED_TOPIC) String topic,
            @Header(KafkaHeaders.RECEIVED_PARTITION) int partition,
            @Header(KafkaHeaders.OFFSET) long offset,
            @Header(KafkaHeaders.RECEIVED_KEY) String key,
            Acknowledgment acknowledgment) {
        
        try {
            logger.info("Received message from topic: {}, partition: {}, offset: {}, key: {}, messageId: {}", 
                       topic, partition, offset, key, message.getId());
            
            // Process the message
            processUserEvent(message);
            
            // Manually acknowledge the message
            acknowledgment.acknowledge();
            
            logger.info("Successfully processed and acknowledged message: {}", message.getId());
            
        } catch (Exception e) {
            logger.error("Failed to process message: {}, error: {}", message.getId(), e.getMessage(), e);
            // Don't acknowledge - message will be redelivered
            throw e; // Let error handler deal with it
        }
    }

    /**
     * Batch consumer for high-throughput scenarios
     */
    @KafkaListener(
        topics = "${app.kafka.topics.batch-events:batch-events}",
        groupId = "${app.kafka.consumer.batch-group:batch-service}",
        containerFactory = "kafkaListenerContainerFactory"
    )
    public void consumeMessagesBatch(
            @Payload List<KafkaMessage> messages,
            @Header(KafkaHeaders.RECEIVED_TOPIC) List<String> topics,
            @Header(KafkaHeaders.RECEIVED_PARTITION) List<Integer> partitions,
            @Header(KafkaHeaders.OFFSET) List<Long> offsets,
            Acknowledgment acknowledgment) {
        
        try {
            logger.info("Received batch of {} messages", messages.size());
            
            // Process all messages in the batch
            for (int i = 0; i < messages.size(); i++) {
                KafkaMessage message = messages.get(i);
                logger.debug("Processing message {} of {}: {}", 
                           i + 1, messages.size(), message.getId());
                
                processMessage(message);
            }
            
            // Acknowledge the entire batch
            acknowledgment.acknowledge();
            
            logger.info("Successfully processed and acknowledged batch of {} messages", 
                       messages.size());
            
        } catch (Exception e) {
            logger.error("Failed to process message batch", e);
            throw e;
        }
    }

    private void processUserEvent(UserEvent event) {
        // Business logic for processing user events
        switch (event.action()) {
            case "LOGIN" -> handleUserLogin(event);
            case "LOGOUT" -> handleUserLogout(event);
            case "PROFILE_UPDATE" -> handleProfileUpdate(event);
            default -> logger.warn("Unknown user action: {}", event.action());
        }
    }

    private void processMessage(KafkaMessage message) {
        // Generic message processing
        logger.info("Processing message of type: {}", message.getType());
        
        // Add your business logic here
        switch (message.getType()) {
            case "USER_EVENT" -> processUserEvent((UserEvent) message);
            case "ORDER_EVENT" -> processOrderEvent(message);
            case "PAYMENT_EVENT" -> processPaymentEvent(message);
            default -> logger.warn("Unknown message type: {}", message.getType());
        }
    }

    private void handleUserLogin(UserEvent event) {
        logger.info("User logged in: {}", event.userId());
        // Implement login handling logic
    }

    private void handleUserLogout(UserEvent event) {
        logger.info("User logged out: {}", event.userId());
        // Implement logout handling logic
    }

    private void handleProfileUpdate(UserEvent event) {
        logger.info("User profile updated: {}", event.userId());
        // Implement profile update logic
    }

    private void processOrderEvent(KafkaMessage message) {
        logger.info("Processing order event: {}", message.getId());
        // Implement order event processing
    }

    private void processPaymentEvent(KafkaMessage message) {
        logger.info("Processing payment event: {}", message.getId());
        // Implement payment event processing
    }
}
```

### Key Takeaways - Fundamentals
- **Partitioning Strategy**: Choose partition keys carefully for even distribution
- **Serialization**: Use JSON for flexibility, Avro for schema evolution
- **Acknowledgment**: Manual acknowledgment provides better control over message processing
- **Error Handling**: Implement proper exception handling to avoid message loss
- **Performance**: Batch processing can significantly improve throughput

---

## 3. Spring Boot Integration

### 3.1 Application Configuration

```java
package com.example.kafka;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * Main Spring Boot Application
 * Enables Kafka, Async processing, and Scheduling
 */
@SpringBootApplication
@EnableKafka
@EnableAsync
@EnableScheduling
public class KafkaSpringBootApplication {

    public static void main(String[] args) {
        SpringApplication.run(KafkaSpringBootApplication.class, args);
    }
}
```

### 3.2 Application Properties

```yaml
# application.yml
spring:
  application:
    name: kafka-spring-tutorial
  
  kafka:
    bootstrap-servers: ${KAFKA_BOOTSTRAP_SERVERS:localhost:9092}
    
    producer:
      acks: all
      retries: 3
      batch-size: 16384
      linger-ms: 5
      buffer-memory: 33554432
      key-serializer: org.apache.kafka.common.serialization.StringSerializer
      value-serializer: org.springframework.kafka.support.serializer.JsonSerializer
      properties:
        enable.idempotence: true
        max.in.flight.requests.per.connection: 5
        compression.type: snappy
    
    consumer:
      bootstrap-servers: ${KAFKA_BOOTSTRAP_SERVERS:localhost:9092}
      group-id: ${KAFKA_CONSUMER_GROUP_ID:default-group}
      auto-offset-reset: earliest
      key-deserializer: org.apache.kafka.common.serialization.StringDeserializer
      value-deserializer: org.springframework.kafka.support.serializer.JsonDeserializer
      properties:
        spring.json.trusted.packages: com.example.kafka.model
        spring.json.use.type.info.headers: false
        spring.json.value.default.type: com.example.kafka.model.GenericMessage
        max.poll.records: 500
        max.poll.interval.ms: 300000
        session.timeout.ms: 30000
        heartbeat.interval.ms: 10000
        enable.auto.commit: false
        fetch.min.bytes: 1024
        fetch.max.wait.ms: 500

  # Actuator Configuration
  management:
    endpoints:
      web:
        exposure:
          include: health,info,metrics,prometheus,kafka
    endpoint:
      health:
        show-details: always
    metrics:
      export:
        prometheus:
          enabled: true

# Application specific properties
app:
  kafka:
    topics:
      user-events: user-events
      order-events: order-events
      payment-events: payment-events
      dlq: dlq-events
    consumer:
      group-id: ${spring.application.name}
      concurrency: 3
    producer:
      retry:
        attempts: 3
        backoff: 1000

# Logging Configuration
logging:
  level:
    com.example.kafka: DEBUG
    org.springframework.kafka: INFO
    org.apache.kafka: WARN
  pattern:
    console: "%d{HH:mm:ss.SSS} [%thread] %-5level %logger{36} - %msg%n"
    file: "%d{yyyy-MM-dd HH:mm:ss.SSS} [%thread] %-5level %logger{36} - %msg%n"
  file:
    name: logs/kafka-spring-tutorial.log

# Server Configuration
server:
  port: 8080
  shutdown: graceful

# Async Configuration
spring:
  task:
    execution:
      pool:
        core-size: 5
        max-size: 10
        queue-capacity: 100
      thread-name-prefix: async-
```

### 3.3 REST Controller for Message Publishing

```java
package com.example.kafka.controller;

import com.example.kafka.model.UserEvent;
import com.example.kafka.service.KafkaMessageProducer;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.concurrent.CompletableFuture;

/**
 * REST Controller for Kafka Message Operations
 * Provides endpoints for publishing messages to Kafka topics
 */
@RestController
@RequestMapping("/api/v1/messages")
@CrossOrigin(origins = "*")
public class KafkaController {

    private static final Logger logger = LoggerFactory.getLogger(KafkaController.class);
    
    private final KafkaMessageProducer messageProducer;

    public KafkaController(KafkaMessageProducer messageProducer) {
        this.messageProducer = messageProducer;
    }

    /**
     * Publish user event asynchronously
     */
    @PostMapping("/user-events")
    public ResponseEntity<Map<String, String>> publishUserEvent(
            @Valid @RequestBody UserEventRequest request) {
        
        try {
            UserEvent event = UserEvent.create(
                request.userId(),
                request.action(),
                request.data()
            );
            
            // Send message asynchronously
            CompletableFuture<Void> future = messageProducer
                .sendMessage("user-events", request.userId(), event)
                .thenAccept(result -> 
                    logger.info("Message published successfully: {}", event.getId())
                );
            
            return ResponseEntity.ok(Map.of(
                "status", "ACCEPTED",
                "messageId", event.getId(),
                "message", "Event published successfully"
            ));
            
        } catch (Exception e) {
            logger.error("Failed to publish user event", e);
            return ResponseEntity.internalServerError()
                .body(Map.of(
                    "status", "ERROR",
                    "message", "Failed to publish event: " + e.getMessage()
                ));
        }
    }

    /**
     * Publish user event synchronously
     */
    @PostMapping("/user-events/sync")
    public ResponseEntity<Map<String, Object>> publishUserEventSync(
            @Valid @RequestBody UserEventRequest request) {
        
        try {
            UserEvent event = UserEvent.create(
                request.userId(),
                request.action(),
                request.data()
            );
            
            // Send message synchronously
            var result = messageProducer.sendMessageSync("user-events", request.userId(), event);
            
            return ResponseEntity.ok(Map.of(
                "status", "SUCCESS",
                "messageId", event.getId(),
                "topic", result.getRecordMetadata().topic(),
                "partition", result.getRecordMetadata().partition(),
                "offset", result.getRecordMetadata().offset(),
                "message", "Event published successfully"
            ));
            
        } catch (Exception e) {
            logger.error("Failed to publish user event synchronously", e);
            return ResponseEntity.internalServerError()
                .body(Map.of(
                    "status", "ERROR",
                    "message", "Failed to publish event: " + e.getMessage()
                ));
        }
    }

    /**
     * Bulk publish user events
     */
    @PostMapping("/user-events/bulk")
    public ResponseEntity<Map<String, Object>> publishUserEventsBulk(
            @Valid @RequestBody BulkUserEventRequest request) {
        
        try {
            var futures = request.events().stream()
                .map(eventReq -> {
                    UserEvent event = UserEvent.create(
                        eventReq.userId(),
                        eventReq.action(),
                        eventReq.data()
                    );
                    return messageProducer.sendMessage("user-events", eventReq.userId(), event);
                })
                .toList();
            
            // Wait for all messages to be sent
            CompletableFuture.allOf(futures.toArray(new CompletableFuture[0]))
                .thenRun(() -> logger.info("All {} events published successfully", futures.size()));
            
            return ResponseEntity.ok(Map.of(
                "status", "ACCEPTED",
                "count", futures.size(),
                "message", "All events published successfully"
            ));
            
        } catch (Exception e) {
            logger.error("Failed to publish bulk user events", e);
            return ResponseEntity.internalServerError()
                .body(Map.of(
                    "status", "ERROR",
                    "message", "Failed to publish events: " + e.getMessage()
                ));
        }
    }

    // Request DTOs
    public record UserEventRequest(
        String userId,
        String action,
        Map<String, Object> data
    ) {}

    public record BulkUserEventRequest(
        java.util.List<UserEventRequest> events
    ) {}
}
```

### 3.4 Health Check and Metrics

```java
package com.example.kafka.health;

import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.DescribeClusterResult;
import org.springframework.boot.actuator.health.Health;
import org.springframework.boot.actuator.health.HealthIndicator;
import org.springframework.kafka.core.KafkaAdmin;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

/**
 * Kafka Health Indicator
 * Provides health check information for Kafka connectivity
 */
@Component
public class KafkaHealthIndicator implements HealthIndicator {

    private final KafkaAdmin kafkaAdmin;

    public KafkaHealthIndicator(KafkaAdmin kafkaAdmin) {
        this.kafkaAdmin = kafkaAdmin;
    }

    @Override
    public Health health() {
        try (AdminClient adminClient = AdminClient.create(kafkaAdmin.getConfigurationProperties())) {
            
            DescribeClusterResult clusterResult = adminClient.describeCluster();
            
            // Wait for result with timeout
            String clusterId = clusterResult.clusterId().get(5, TimeUnit.SECONDS);
            int nodeCount = clusterResult.nodes().get(5, TimeUnit.SECONDS).size();
            
            return Health.up()
                .withDetail("clusterId", clusterId)
                .withDetail("nodeCount", nodeCount)
                .withDetail("status", "Connected")
                .build();
                
        } catch (Exception e) {
            return Health.down()
                .withDetail("error", e.getMessage())
                .withDetail("status", "Disconnected")
                .build();
        }
    }
}
```

### 3.5 Custom Metrics

```java
package com.example.kafka.metrics;

import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Timer;
import org.springframework.stereotype.Component;

/**
 * Kafka Custom Metrics
 * Provides application-specific metrics for monitoring
 */
@Component
public class KafkaMetrics {

    private final Counter messagesProduced;
    private final Counter messagesConsumed;
    private final Counter messagesFailed;
    private final Timer messageProcessingTime;

    public KafkaMetrics(MeterRegistry meterRegistry) {
        this.messagesProduced = Counter.builder("kafka.messages.produced")
            .description("Total number of messages produced")
            .tag("application", "kafka-spring-tutorial")
            .register(meterRegistry);
            
        this.messagesConsumed = Counter.builder("kafka.messages.consumed")
            .description("Total number of messages consumed")
            .tag("application", "kafka-spring-tutorial")
            .register(meterRegistry);
            
        this.messagesFailed = Counter.builder("kafka.messages.failed")
            .description("Total number of failed messages")
            .tag("application", "kafka-spring-tutorial")
            .register(meterRegistry);
            
        this.messageProcessingTime = Timer.builder("kafka.message.processing.time")
            .description("Time taken to process messages")
            .tag("application", "kafka-spring-tutorial")
            .register(meterRegistry);
    }

    public void incrementMessagesProduced() {
        messagesProduced.increment();
    }

    public void incrementMessagesConsumed() {
        messagesConsumed.increment();
    }

    public void incrementMessagesFailed() {
        messagesFailed.increment();
    }

    public Timer.Sample startProcessingTimer() {
        return Timer.start();
    }

    public void recordProcessingTime(Timer.Sample sample) {
        sample.stop(messageProcessingTime);
    }
}
```

### Key Takeaways - Spring Boot Integration
- **Configuration**: Use YAML for complex configurations with profiles
- **Health Checks**: Implement custom health indicators for Kafka connectivity
- **Metrics**: Add custom metrics for business-specific monitoring
- **REST APIs**: Provide both sync and async endpoints for different use cases
- **Error Handling**: Implement comprehensive error handling and logging

---

*[Document continues with remaining sections...]*

This is the beginning of the comprehensive tutorial. The document would continue with all the remaining sections covering Kafka internals, microservices architecture, performance tuning, security, monitoring, testing, resilience patterns, deployment, and CI/CD. Each section would maintain the same level of detail with practical code examples, configurations, and explanations.

Would you like me to continue with specific sections or create the interview preparation guide (Document B)?
