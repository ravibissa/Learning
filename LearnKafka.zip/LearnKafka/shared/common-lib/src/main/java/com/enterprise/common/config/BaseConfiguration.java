package com.enterprise.common.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import io.github.resilience4j.circuitbreaker.CircuitBreakerConfig;
import io.github.resilience4j.retry.RetryConfig;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import java.time.Duration;

/**
 * Base configuration class providing common beans and settings
 * for all microservices in the enterprise system.
 * 
 * This configuration includes:
 * - JSON serialization/deserialization settings
 * - Circuit breaker configurations
 * - Retry policies
 * - Common utilities
 * 
 * @author Enterprise Platform Team
 * @version 1.0.0
 * @since 2024-01-01
 */
@Configuration
@EnableConfigurationProperties
public class BaseConfiguration {

    /**
     * Primary ObjectMapper bean with standardized configuration
     * for consistent JSON processing across all services.
     * 
     * Features:
     * - Java 8 Time API support
     * - ISO-8601 date formatting
     * - Fail on unknown properties disabled for forward compatibility
     * - Write dates as timestamps disabled for readability
     * 
     * @return configured ObjectMapper instance
     */
    @Bean
    @Primary
    public ObjectMapper objectMapper() {
        ObjectMapper mapper = new ObjectMapper();
        
        // Register Java 8 Time module for proper date/time handling
        mapper.registerModule(new JavaTimeModule());
        
        // Configure serialization features
        mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
        mapper.disable(SerializationFeature.FAIL_ON_EMPTY_BEANS);
        
        // Configure deserialization features
        mapper.configure(
            com.fasterxml.jackson.databind.DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, 
            false
        );
        mapper.configure(
            com.fasterxml.jackson.databind.DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_AS_NULL, 
            true
        );
        
        return mapper;
    }

    /**
     * Default circuit breaker configuration for external service calls.
     * 
     * Configuration:
     * - Failure rate threshold: 50%
     * - Wait duration in open state: 30 seconds
     * - Sliding window size: 10 requests
     * - Minimum number of calls: 5
     * - Permitted calls in half-open: 3
     * 
     * @return CircuitBreakerConfig with default settings
     */
    @Bean
    public CircuitBreakerConfig defaultCircuitBreakerConfig() {
        return CircuitBreakerConfig.custom()
            .failureRateThreshold(50.0f)
            .waitDurationInOpenState(Duration.ofSeconds(30))
            .slidingWindowSize(10)
            .minimumNumberOfCalls(5)
            .permittedNumberOfCallsInHalfOpenState(3)
            .slowCallRateThreshold(50.0f)
            .slowCallDurationThreshold(Duration.ofSeconds(2))
            .build();
    }

    /**
     * Default retry configuration for transient failures.
     * 
     * Configuration:
     * - Maximum attempts: 3
     * - Wait duration: 1 second
     * - Exponential backoff multiplier: 2.0
     * - Maximum wait duration: 10 seconds
     * 
     * @return RetryConfig with default settings
     */
    @Bean
    public RetryConfig defaultRetryConfig() {
        return RetryConfig.custom()
            .maxAttempts(3)
            .waitDuration(Duration.ofSeconds(1))
            .exponentialBackoffMultiplier(2.0)
            .maxWaitDuration(Duration.ofSeconds(10))
            .retryOnException(throwable -> 
                throwable instanceof RuntimeException && 
                !(throwable instanceof IllegalArgumentException))
            .build();
    }
}
