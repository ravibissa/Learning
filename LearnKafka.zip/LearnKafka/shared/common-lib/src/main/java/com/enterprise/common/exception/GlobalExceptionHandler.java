package com.enterprise.common.exception;

import com.enterprise.common.model.ErrorResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.ConstraintViolationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Global exception handler for all REST controllers in the application.
 * Provides consistent error responses and proper logging for all exceptions.
 * 
 * Features:
 * - Standardized error response format
 * - Correlation ID tracking
 * - Appropriate HTTP status codes
 * - Detailed logging with context
 * - Validation error handling
 * - Security-conscious error messages
 * 
 * @author Enterprise Platform Team
 * @version 1.0.0
 * @since 2024-01-01
 */
@RestControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    /**
     * Handles business logic exceptions with appropriate HTTP status codes.
     * 
     * @param ex the business exception
     * @param request the HTTP request
     * @return error response with BAD_REQUEST status
     */
    @ExceptionHandler(BusinessException.class)
    public ResponseEntity<ErrorResponse> handleBusinessException(
            BusinessException ex, HttpServletRequest request) {
        
        String correlationId = generateCorrelationId();
        
        ErrorResponse errorResponse = ErrorResponse.builder()
            .timestamp(Instant.now())
            .status(HttpStatus.BAD_REQUEST.value())
            .error("Business Logic Error")
            .message(ex.getMessage())
            .path(request.getRequestURI())
            .correlationId(correlationId)
            .build();
        
        logger.warn("Business exception occurred - CorrelationId: {}, Message: {}, Path: {}", 
                   correlationId, ex.getMessage(), request.getRequestURI());
        
        return ResponseEntity.badRequest().body(errorResponse);
    }

    /**
     * Handles resource not found exceptions.
     * 
     * @param ex the resource not found exception
     * @param request the HTTP request
     * @return error response with NOT_FOUND status
     */
    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<ErrorResponse> handleResourceNotFoundException(
            ResourceNotFoundException ex, HttpServletRequest request) {
        
        String correlationId = generateCorrelationId();
        
        ErrorResponse errorResponse = ErrorResponse.builder()
            .timestamp(Instant.now())
            .status(HttpStatus.NOT_FOUND.value())
            .error("Resource Not Found")
            .message(ex.getMessage())
            .path(request.getRequestURI())
            .correlationId(correlationId)
            .build();
        
        logger.info("Resource not found - CorrelationId: {}, Message: {}, Path: {}", 
                   correlationId, ex.getMessage(), request.getRequestURI());
        
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(errorResponse);
    }

    /**
     * Handles validation errors from request body validation.
     * 
     * @param ex the method argument not valid exception
     * @param request the HTTP request
     * @return error response with BAD_REQUEST status and field errors
     */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ErrorResponse> handleValidationException(
            MethodArgumentNotValidException ex, HttpServletRequest request) {
        
        String correlationId = generateCorrelationId();
        
        Map<String, String> fieldErrors = new HashMap<>();
        ex.getBindingResult().getFieldErrors().forEach(error -> 
            fieldErrors.put(error.getField(), error.getDefaultMessage())
        );
        
        ErrorResponse errorResponse = ErrorResponse.builder()
            .timestamp(Instant.now())
            .status(HttpStatus.BAD_REQUEST.value())
            .error("Validation Failed")
            .message("Invalid input parameters")
            .path(request.getRequestURI())
            .correlationId(correlationId)
            .validationErrors(fieldErrors)
            .build();
        
        logger.warn("Validation failed - CorrelationId: {}, Errors: {}, Path: {}", 
                   correlationId, fieldErrors, request.getRequestURI());
        
        return ResponseEntity.badRequest().body(errorResponse);
    }

    /**
     * Handles constraint violation exceptions from path variable/request parameter validation.
     * 
     * @param ex the constraint violation exception
     * @param request the HTTP request
     * @return error response with BAD_REQUEST status
     */
    @ExceptionHandler(ConstraintViolationException.class)
    public ResponseEntity<ErrorResponse> handleConstraintViolationException(
            ConstraintViolationException ex, HttpServletRequest request) {
        
        String correlationId = generateCorrelationId();
        
        Map<String, String> violations = new HashMap<>();
        ex.getConstraintViolations().forEach(violation -> {
            String propertyPath = violation.getPropertyPath().toString();
            String message = violation.getMessage();
            violations.put(propertyPath, message);
        });
        
        ErrorResponse errorResponse = ErrorResponse.builder()
            .timestamp(Instant.now())
            .status(HttpStatus.BAD_REQUEST.value())
            .error("Constraint Violation")
            .message("Invalid request parameters")
            .path(request.getRequestURI())
            .correlationId(correlationId)
            .validationErrors(violations)
            .build();
        
        logger.warn("Constraint violation - CorrelationId: {}, Violations: {}, Path: {}", 
                   correlationId, violations, request.getRequestURI());
        
        return ResponseEntity.badRequest().body(errorResponse);
    }

    /**
     * Handles external service exceptions (circuit breaker, timeout, etc.).
     * 
     * @param ex the external service exception
     * @param request the HTTP request
     * @return error response with SERVICE_UNAVAILABLE status
     */
    @ExceptionHandler(ExternalServiceException.class)
    public ResponseEntity<ErrorResponse> handleExternalServiceException(
            ExternalServiceException ex, HttpServletRequest request) {
        
        String correlationId = generateCorrelationId();
        
        ErrorResponse errorResponse = ErrorResponse.builder()
            .timestamp(Instant.now())
            .status(HttpStatus.SERVICE_UNAVAILABLE.value())
            .error("External Service Error")
            .message("External service is temporarily unavailable")
            .path(request.getRequestURI())
            .correlationId(correlationId)
            .build();
        
        logger.error("External service exception - CorrelationId: {}, Service: {}, Path: {}", 
                    correlationId, ex.getServiceName(), request.getRequestURI(), ex);
        
        return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body(errorResponse);
    }

    /**
     * Handles all other unexpected exceptions.
     * 
     * @param ex the generic exception
     * @param request the HTTP request
     * @return error response with INTERNAL_SERVER_ERROR status
     */
    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> handleGenericException(
            Exception ex, HttpServletRequest request) {
        
        String correlationId = generateCorrelationId();
        
        ErrorResponse errorResponse = ErrorResponse.builder()
            .timestamp(Instant.now())
            .status(HttpStatus.INTERNAL_SERVER_ERROR.value())
            .error("Internal Server Error")
            .message("An unexpected error occurred")
            .path(request.getRequestURI())
            .correlationId(correlationId)
            .build();
        
        logger.error("Unexpected exception - CorrelationId: {}, Path: {}", 
                    correlationId, request.getRequestURI(), ex);
        
        return ResponseEntity.internalServerError().body(errorResponse);
    }

    /**
     * Generates a unique correlation ID for tracking requests across services.
     * First tries to get existing correlation ID from MDC, then from request headers,
     * finally generates a new one if none exists.
     * 
     * @return correlation ID string
     */
    private String generateCorrelationId() {
        // Try to get existing correlation ID from MDC
        String correlationId = MDC.get("correlationId");
        
        if (correlationId == null) {
            // Try to get from request headers
            ServletRequestAttributes attributes = 
                (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
            
            if (attributes != null) {
                HttpServletRequest request = attributes.getRequest();
                correlationId = request.getHeader("X-Correlation-ID");
            }
            
            // Generate new correlation ID if none exists
            if (correlationId == null) {
                correlationId = UUID.randomUUID().toString();
            }
            
            // Set in MDC for downstream processing
            MDC.put("correlationId", correlationId);
        }
        
        return correlationId;
    }
}
