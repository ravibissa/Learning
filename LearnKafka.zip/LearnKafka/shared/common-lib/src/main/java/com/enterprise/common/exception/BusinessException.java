package com.enterprise.common.exception;

/**
 * Base exception class for business logic errors.
 * 
 * This exception should be thrown when business rules are violated
 * or when the requested operation cannot be completed due to
 * business constraints.
 * 
 * Examples:
 * - Insufficient inventory for order
 * - Invalid payment method
 * - User not authorized for operation
 * - Order already processed
 * 
 * @author Enterprise Platform Team
 * @version 1.0.0
 * @since 2024-01-01
 */
public class BusinessException extends RuntimeException {

    private final String errorCode;

    /**
     * Creates a new business exception with the specified message.
     * 
     * @param message the detail message
     */
    public BusinessException(String message) {
        super(message);
        this.errorCode = "BUSINESS_ERROR";
    }

    /**
     * Creates a new business exception with the specified message and error code.
     * 
     * @param message the detail message
     * @param errorCode the specific error code for categorization
     */
    public BusinessException(String message, String errorCode) {
        super(message);
        this.errorCode = errorCode;
    }

    /**
     * Creates a new business exception with the specified message and cause.
     * 
     * @param message the detail message
     * @param cause the underlying cause
     */
    public BusinessException(String message, Throwable cause) {
        super(message, cause);
        this.errorCode = "BUSINESS_ERROR";
    }

    /**
     * Creates a new business exception with message, error code, and cause.
     * 
     * @param message the detail message
     * @param errorCode the specific error code for categorization
     * @param cause the underlying cause
     */
    public BusinessException(String message, String errorCode, Throwable cause) {
        super(message, cause);
        this.errorCode = errorCode;
    }

    /**
     * Gets the error code associated with this exception.
     * 
     * @return the error code
     */
    public String getErrorCode() {
        return errorCode;
    }
}
