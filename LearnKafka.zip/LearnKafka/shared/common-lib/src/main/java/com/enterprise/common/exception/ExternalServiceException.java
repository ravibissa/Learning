package com.enterprise.common.exception;

/**
 * Exception thrown when external service calls fail.
 * 
 * This exception should be thrown when:
 * - External API calls timeout
 * - Circuit breaker is open
 * - Network connectivity issues
 * - External service returns error responses
 * - Authentication/authorization failures with external services
 * 
 * @author Enterprise Platform Team
 * @version 1.0.0
 * @since 2024-01-01
 */
public class ExternalServiceException extends RuntimeException {

    private final String serviceName;
    private final String operation;
    private final int statusCode;

    /**
     * Creates a new external service exception with the specified message.
     * 
     * @param message the detail message
     */
    public ExternalServiceException(String message) {
        super(message);
        this.serviceName = "Unknown";
        this.operation = "Unknown";
        this.statusCode = -1;
    }

    /**
     * Creates a new external service exception with service details.
     * 
     * @param message the detail message
     * @param serviceName the name of the external service
     */
    public ExternalServiceException(String message, String serviceName) {
        super(message);
        this.serviceName = serviceName;
        this.operation = "Unknown";
        this.statusCode = -1;
    }

    /**
     * Creates a new external service exception with full details.
     * 
     * @param message the detail message
     * @param serviceName the name of the external service
     * @param operation the operation that failed
     * @param statusCode the HTTP status code returned (if applicable)
     */
    public ExternalServiceException(String message, String serviceName, String operation, int statusCode) {
        super(message);
        this.serviceName = serviceName;
        this.operation = operation;
        this.statusCode = statusCode;
    }

    /**
     * Creates a new external service exception with message and cause.
     * 
     * @param message the detail message
     * @param serviceName the name of the external service
     * @param cause the underlying cause
     */
    public ExternalServiceException(String message, String serviceName, Throwable cause) {
        super(message, cause);
        this.serviceName = serviceName;
        this.operation = "Unknown";
        this.statusCode = -1;
    }

    /**
     * Creates a new external service exception with full details and cause.
     * 
     * @param message the detail message
     * @param serviceName the name of the external service
     * @param operation the operation that failed
     * @param statusCode the HTTP status code returned
     * @param cause the underlying cause
     */
    public ExternalServiceException(String message, String serviceName, String operation, int statusCode, Throwable cause) {
        super(message, cause);
        this.serviceName = serviceName;
        this.operation = operation;
        this.statusCode = statusCode;
    }

    /**
     * Gets the name of the external service that failed.
     * 
     * @return the service name
     */
    public String getServiceName() {
        return serviceName;
    }

    /**
     * Gets the operation that failed.
     * 
     * @return the operation name
     */
    public String getOperation() {
        return operation;
    }

    /**
     * Gets the HTTP status code returned by the external service.
     * 
     * @return the status code, or -1 if not applicable
     */
    public int getStatusCode() {
        return statusCode;
    }
}
