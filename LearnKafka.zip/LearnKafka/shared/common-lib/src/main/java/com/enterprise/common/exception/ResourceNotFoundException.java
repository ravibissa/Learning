package com.enterprise.common.exception;

/**
 * Exception thrown when a requested resource cannot be found.
 * 
 * This exception should be thrown when:
 * - Entity with given ID doesn't exist
 * - Resource has been deleted
 * - User doesn't have access to the resource
 * - File or document cannot be located
 * 
 * @author Enterprise Platform Team
 * @version 1.0.0
 * @since 2024-01-01
 */
public class ResourceNotFoundException extends RuntimeException {

    private final String resourceType;
    private final String resourceId;

    /**
     * Creates a new resource not found exception with the specified message.
     * 
     * @param message the detail message
     */
    public ResourceNotFoundException(String message) {
        super(message);
        this.resourceType = "Unknown";
        this.resourceId = "Unknown";
    }

    /**
     * Creates a new resource not found exception with resource details.
     * 
     * @param resourceType the type of resource (e.g., "Order", "User", "Product")
     * @param resourceId the identifier of the resource
     */
    public ResourceNotFoundException(String resourceType, String resourceId) {
        super(String.format("%s with ID '%s' not found", resourceType, resourceId));
        this.resourceType = resourceType;
        this.resourceId = resourceId;
    }

    /**
     * Creates a new resource not found exception with custom message and resource details.
     * 
     * @param message the detail message
     * @param resourceType the type of resource
     * @param resourceId the identifier of the resource
     */
    public ResourceNotFoundException(String message, String resourceType, String resourceId) {
        super(message);
        this.resourceType = resourceType;
        this.resourceId = resourceId;
    }

    /**
     * Creates a new resource not found exception with message and cause.
     * 
     * @param message the detail message
     * @param cause the underlying cause
     */
    public ResourceNotFoundException(String message, Throwable cause) {
        super(message, cause);
        this.resourceType = "Unknown";
        this.resourceId = "Unknown";
    }

    /**
     * Gets the type of resource that was not found.
     * 
     * @return the resource type
     */
    public String getResourceType() {
        return resourceType;
    }

    /**
     * Gets the identifier of the resource that was not found.
     * 
     * @return the resource identifier
     */
    public String getResourceId() {
        return resourceId;
    }
}
