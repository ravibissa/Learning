package com.enterprise.events;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotBlank;

/**
 * Event published when an order is cancelled.
 * 
 * This event triggers compensating actions including:
 * - Payment refund processing
 * - Inventory release
 * - Customer notification
 * - Audit logging
 * 
 * @author Enterprise Platform Team
 * @version 1.0.0
 * @since 2024-01-01
 */
public class OrderCancelledEvent extends BaseEvent {

    @JsonProperty("customerId")
    @NotBlank
    private String customerId;

    @JsonProperty("customerEmail")
    @NotBlank
    private String customerEmail;

    @JsonProperty("cancellationReason")
    @NotBlank
    private String cancellationReason;

    @JsonProperty("cancelledBy")
    private String cancelledBy;

    @JsonProperty("refundRequired")
    private Boolean refundRequired;

    @JsonProperty("refundAmount")
    private String refundAmount;

    /**
     * Constructor for creating an order cancelled event.
     * 
     * @param orderId the unique order identifier
     * @param version the order version
     * @param customerId the customer who owns the order
     * @param customerEmail the customer's email address
     * @param cancellationReason the reason for cancellation
     * @param cancelledBy the user or system that cancelled the order
     * @param refundRequired whether a refund is required
     * @param refundAmount the amount to refund (if applicable)
     */
    public OrderCancelledEvent(String orderId, Long version, String customerId, String customerEmail,
                             String cancellationReason, String cancelledBy, Boolean refundRequired,
                             String refundAmount) {
        super("ORDER_CANCELLED", orderId, "Order", version);
        this.customerId = customerId;
        this.customerEmail = customerEmail;
        this.cancellationReason = cancellationReason;
        this.cancelledBy = cancelledBy;
        this.refundRequired = refundRequired;
        this.refundAmount = refundAmount;
    }

    /**
     * Default constructor for JSON deserialization.
     */
    public OrderCancelledEvent() {
        super();
    }

    // Getters and Setters

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getCustomerEmail() {
        return customerEmail;
    }

    public void setCustomerEmail(String customerEmail) {
        this.customerEmail = customerEmail;
    }

    public String getCancellationReason() {
        return cancellationReason;
    }

    public void setCancellationReason(String cancellationReason) {
        this.cancellationReason = cancellationReason;
    }

    public String getCancelledBy() {
        return cancelledBy;
    }

    public void setCancelledBy(String cancelledBy) {
        this.cancelledBy = cancelledBy;
    }

    public Boolean getRefundRequired() {
        return refundRequired;
    }

    public void setRefundRequired(Boolean refundRequired) {
        this.refundRequired = refundRequired;
    }

    public String getRefundAmount() {
        return refundAmount;
    }

    public void setRefundAmount(String refundAmount) {
        this.refundAmount = refundAmount;
    }

    @Override
    public String toString() {
        return "OrderCancelledEvent{" +
                "customerId='" + customerId + '\'' +
                ", customerEmail='" + customerEmail + '\'' +
                ", cancellationReason='" + cancellationReason + '\'' +
                ", cancelledBy='" + cancelledBy + '\'' +
                ", refundRequired=" + refundRequired +
                ", refundAmount='" + refundAmount + '\'' +
                "} " + super.toString();
    }
}
