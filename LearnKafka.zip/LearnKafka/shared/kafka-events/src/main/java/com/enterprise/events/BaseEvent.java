package com.enterprise.events;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.time.Instant;
import java.util.Map;
import java.util.UUID;

/**
 * Base class for all domain events in the enterprise system.
 * 
 * Provides common fields and functionality for event sourcing and messaging:
 * - Unique event identification
 * - Timestamp tracking
 * - Correlation ID for distributed tracing
 * - Metadata for extensibility
 * - Polymorphic JSON serialization support
 * 
 * All concrete events should extend this class to ensure consistency
 * across the microservices architecture.
 * 
 * @author Enterprise Platform Team
 * @version 1.0.0
 * @since 2024-01-01
 */
@JsonTypeInfo(
    use = JsonTypeInfo.Id.NAME,
    include = JsonTypeInfo.As.PROPERTY,
    property = "eventType"
)
@JsonSubTypes({
    @JsonSubTypes.Type(value = OrderCreatedEvent.class, name = "ORDER_CREATED"),
    @JsonSubTypes.Type(value = OrderUpdatedEvent.class, name = "ORDER_UPDATED"),
    @JsonSubTypes.Type(value = OrderCancelledEvent.class, name = "ORDER_CANCELLED"),
    @JsonSubTypes.Type(value = PaymentInitiatedEvent.class, name = "PAYMENT_INITIATED"),
    @JsonSubTypes.Type(value = PaymentCompletedEvent.class, name = "PAYMENT_COMPLETED"),
    @JsonSubTypes.Type(value = PaymentFailedEvent.class, name = "PAYMENT_FAILED"),
    @JsonSubTypes.Type(value = NotificationSentEvent.class, name = "NOTIFICATION_SENT"),
    @JsonSubTypes.Type(value = AuditLogCreatedEvent.class, name = "AUDIT_LOG_CREATED")
})
public abstract class BaseEvent {

    @JsonProperty("eventId")
    @NotBlank
    private String eventId;

    @JsonProperty("eventType")
    @NotBlank
    private String eventType;

    @JsonProperty("aggregateId")
    @NotBlank
    private String aggregateId;

    @JsonProperty("aggregateType")
    @NotBlank
    private String aggregateType;

    @JsonProperty("version")
    @NotNull
    private Long version;

    @JsonProperty("timestamp")
    @NotNull
    private Instant timestamp;

    @JsonProperty("correlationId")
    private String correlationId;

    @JsonProperty("causationId")
    private String causationId;

    @JsonProperty("userId")
    private String userId;

    @JsonProperty("metadata")
    private Map<String, Object> metadata;

    /**
     * Protected constructor for subclasses.
     * Automatically generates event ID and timestamp.
     * 
     * @param eventType the type of event
     * @param aggregateId the ID of the aggregate that generated this event
     * @param aggregateType the type of aggregate
     * @param version the version of the aggregate after this event
     */
    protected BaseEvent(String eventType, String aggregateId, String aggregateType, Long version) {
        this.eventId = UUID.randomUUID().toString();
        this.eventType = eventType;
        this.aggregateId = aggregateId;
        this.aggregateType = aggregateType;
        this.version = version;
        this.timestamp = Instant.now();
    }

    /**
     * Default constructor for JSON deserialization.
     */
    protected BaseEvent() {
    }

    /**
     * Gets the unique identifier for this event.
     * 
     * @return the event ID
     */
    public String getEventId() {
        return eventId;
    }

    public void setEventId(String eventId) {
        this.eventId = eventId;
    }

    /**
     * Gets the type of this event.
     * 
     * @return the event type
     */
    public String getEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    /**
     * Gets the ID of the aggregate that generated this event.
     * 
     * @return the aggregate ID
     */
    public String getAggregateId() {
        return aggregateId;
    }

    public void setAggregateId(String aggregateId) {
        this.aggregateId = aggregateId;
    }

    /**
     * Gets the type of the aggregate that generated this event.
     * 
     * @return the aggregate type
     */
    public String getAggregateType() {
        return aggregateType;
    }

    public void setAggregateType(String aggregateType) {
        this.aggregateType = aggregateType;
    }

    /**
     * Gets the version of the aggregate after this event was applied.
     * 
     * @return the aggregate version
     */
    public Long getVersion() {
        return version;
    }

    public void setVersion(Long version) {
        this.version = version;
    }

    /**
     * Gets the timestamp when this event was created.
     * 
     * @return the event timestamp
     */
    public Instant getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Instant timestamp) {
        this.timestamp = timestamp;
    }

    /**
     * Gets the correlation ID for tracking related events across services.
     * 
     * @return the correlation ID
     */
    public String getCorrelationId() {
        return correlationId;
    }

    public void setCorrelationId(String correlationId) {
        this.correlationId = correlationId;
    }

    /**
     * Gets the causation ID - the ID of the event that caused this event.
     * 
     * @return the causation ID
     */
    public String getCausationId() {
        return causationId;
    }

    public void setCausationId(String causationId) {
        this.causationId = causationId;
    }

    /**
     * Gets the ID of the user who triggered this event.
     * 
     * @return the user ID
     */
    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    /**
     * Gets additional metadata associated with this event.
     * 
     * @return the metadata map
     */
    public Map<String, Object> getMetadata() {
        return metadata;
    }

    public void setMetadata(Map<String, Object> metadata) {
        this.metadata = metadata;
    }

    @Override
    public String toString() {
        return "BaseEvent{" +
                "eventId='" + eventId + '\'' +
                ", eventType='" + eventType + '\'' +
                ", aggregateId='" + aggregateId + '\'' +
                ", aggregateType='" + aggregateType + '\'' +
                ", version=" + version +
                ", timestamp=" + timestamp +
                ", correlationId='" + correlationId + '\'' +
                ", causationId='" + causationId + '\'' +
                ", userId='" + userId + '\'' +
                '}';
    }
}
