package com.enterprise.events;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.util.Map;

/**
 * Event published when an existing order is updated.
 * 
 * This event is triggered when order details change, such as:
 * - Status updates (processing, shipped, delivered)
 * - Address changes
 * - Item modifications
 * - Payment updates
 * 
 * @author Enterprise Platform Team
 * @version 1.0.0
 * @since 2024-01-01
 */
public class OrderUpdatedEvent extends BaseEvent {

    @JsonProperty("customerId")
    @NotBlank
    private String customerId;

    @JsonProperty("previousStatus")
    @NotBlank
    private String previousStatus;

    @JsonProperty("newStatus")
    @NotBlank
    private String newStatus;

    @JsonProperty("updateReason")
    private String updateReason;

    @JsonProperty("updatedFields")
    @NotNull
    private Map<String, Object> updatedFields;

    @JsonProperty("updatedBy")
    private String updatedBy;

    /**
     * Constructor for creating an order updated event.
     * 
     * @param orderId the unique order identifier
     * @param version the new order version
     * @param customerId the customer who owns the order
     * @param previousStatus the previous order status
     * @param newStatus the new order status
     * @param updateReason the reason for the update
     * @param updatedFields map of field names to their new values
     * @param updatedBy the user or system that made the update
     */
    public OrderUpdatedEvent(String orderId, Long version, String customerId,
                           String previousStatus, String newStatus, String updateReason,
                           Map<String, Object> updatedFields, String updatedBy) {
        super("ORDER_UPDATED", orderId, "Order", version);
        this.customerId = customerId;
        this.previousStatus = previousStatus;
        this.newStatus = newStatus;
        this.updateReason = updateReason;
        this.updatedFields = updatedFields;
        this.updatedBy = updatedBy;
    }

    /**
     * Default constructor for JSON deserialization.
     */
    public OrderUpdatedEvent() {
        super();
    }

    // Getters and Setters

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getPreviousStatus() {
        return previousStatus;
    }

    public void setPreviousStatus(String previousStatus) {
        this.previousStatus = previousStatus;
    }

    public String getNewStatus() {
        return newStatus;
    }

    public void setNewStatus(String newStatus) {
        this.newStatus = newStatus;
    }

    public String getUpdateReason() {
        return updateReason;
    }

    public void setUpdateReason(String updateReason) {
        this.updateReason = updateReason;
    }

    public Map<String, Object> getUpdatedFields() {
        return updatedFields;
    }

    public void setUpdatedFields(Map<String, Object> updatedFields) {
        this.updatedFields = updatedFields;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    @Override
    public String toString() {
        return "OrderUpdatedEvent{" +
                "customerId='" + customerId + '\'' +
                ", previousStatus='" + previousStatus + '\'' +
                ", newStatus='" + newStatus + '\'' +
                ", updateReason='" + updateReason + '\'' +
                ", updatedFields=" + updatedFields +
                ", updatedBy='" + updatedBy + '\'' +
                "} " + super.toString();
    }
}
