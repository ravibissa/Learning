package com.enterprise.events;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

/**
 * Event published when a new order is created in the system.
 * 
 * This event triggers downstream processing including:
 * - Payment processing
 * - Inventory reservation
 * - Notification sending
 * - Audit logging
 * 
 * @author Enterprise Platform Team
 * @version 1.0.0
 * @since 2024-01-01
 */
public class OrderCreatedEvent extends BaseEvent {

    @JsonProperty("customerId")
    @NotBlank
    private String customerId;

    @JsonProperty("customerEmail")
    @NotBlank
    private String customerEmail;

    @JsonProperty("orderItems")
    @NotNull
    private List<OrderItem> orderItems;

    @JsonProperty("totalAmount")
    @NotNull
    @Positive
    private BigDecimal totalAmount;

    @JsonProperty("currency")
    @NotBlank
    private String currency;

    @JsonProperty("shippingAddress")
    @NotNull
    private Address shippingAddress;

    @JsonProperty("billingAddress")
    @NotNull
    private Address billingAddress;

    @JsonProperty("orderStatus")
    @NotBlank
    private String orderStatus;

    @JsonProperty("paymentMethod")
    private String paymentMethod;

    /**
     * Constructor for creating a new order created event.
     * 
     * @param orderId the unique order identifier
     * @param version the order version
     * @param customerId the customer who placed the order
     * @param customerEmail the customer's email address
     * @param orderItems the list of items in the order
     * @param totalAmount the total order amount
     * @param currency the currency code (e.g., USD, EUR)
     * @param shippingAddress the shipping address
     * @param billingAddress the billing address
     * @param orderStatus the initial order status
     */
    public OrderCreatedEvent(String orderId, Long version, String customerId, String customerEmail,
                           List<OrderItem> orderItems, BigDecimal totalAmount, String currency,
                           Address shippingAddress, Address billingAddress, String orderStatus) {
        super("ORDER_CREATED", orderId, "Order", version);
        this.customerId = customerId;
        this.customerEmail = customerEmail;
        this.orderItems = orderItems;
        this.totalAmount = totalAmount;
        this.currency = currency;
        this.shippingAddress = shippingAddress;
        this.billingAddress = billingAddress;
        this.orderStatus = orderStatus;
    }

    /**
     * Default constructor for JSON deserialization.
     */
    public OrderCreatedEvent() {
        super();
    }

    // Getters and Setters

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getCustomerEmail() {
        return customerEmail;
    }

    public void setCustomerEmail(String customerEmail) {
        this.customerEmail = customerEmail;
    }

    public List<OrderItem> getOrderItems() {
        return orderItems;
    }

    public void setOrderItems(List<OrderItem> orderItems) {
        this.orderItems = orderItems;
    }

    public BigDecimal getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(BigDecimal totalAmount) {
        this.totalAmount = totalAmount;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public Address getShippingAddress() {
        return shippingAddress;
    }

    public void setShippingAddress(Address shippingAddress) {
        this.shippingAddress = shippingAddress;
    }

    public Address getBillingAddress() {
        return billingAddress;
    }

    public void setBillingAddress(Address billingAddress) {
        this.billingAddress = billingAddress;
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    /**
     * Represents an item in an order.
     */
    public static class OrderItem {
        
        @JsonProperty("productId")
        @NotBlank
        private String productId;

        @JsonProperty("productName")
        @NotBlank
        private String productName;

        @JsonProperty("quantity")
        @Positive
        private Integer quantity;

        @JsonProperty("unitPrice")
        @NotNull
        @Positive
        private BigDecimal unitPrice;

        @JsonProperty("totalPrice")
        @NotNull
        @Positive
        private BigDecimal totalPrice;

        @JsonProperty("attributes")
        private Map<String, String> attributes;

        public OrderItem() {}

        public OrderItem(String productId, String productName, Integer quantity, 
                        BigDecimal unitPrice, BigDecimal totalPrice) {
            this.productId = productId;
            this.productName = productName;
            this.quantity = quantity;
            this.unitPrice = unitPrice;
            this.totalPrice = totalPrice;
        }

        // Getters and Setters
        public String getProductId() { return productId; }
        public void setProductId(String productId) { this.productId = productId; }

        public String getProductName() { return productName; }
        public void setProductName(String productName) { this.productName = productName; }

        public Integer getQuantity() { return quantity; }
        public void setQuantity(Integer quantity) { this.quantity = quantity; }

        public BigDecimal getUnitPrice() { return unitPrice; }
        public void setUnitPrice(BigDecimal unitPrice) { this.unitPrice = unitPrice; }

        public BigDecimal getTotalPrice() { return totalPrice; }
        public void setTotalPrice(BigDecimal totalPrice) { this.totalPrice = totalPrice; }

        public Map<String, String> getAttributes() { return attributes; }
        public void setAttributes(Map<String, String> attributes) { this.attributes = attributes; }
    }

    /**
     * Represents an address.
     */
    public static class Address {
        
        @JsonProperty("street")
        @NotBlank
        private String street;

        @JsonProperty("city")
        @NotBlank
        private String city;

        @JsonProperty("state")
        @NotBlank
        private String state;

        @JsonProperty("zipCode")
        @NotBlank
        private String zipCode;

        @JsonProperty("country")
        @NotBlank
        private String country;

        public Address() {}

        public Address(String street, String city, String state, String zipCode, String country) {
            this.street = street;
            this.city = city;
            this.state = state;
            this.zipCode = zipCode;
            this.country = country;
        }

        // Getters and Setters
        public String getStreet() { return street; }
        public void setStreet(String street) { this.street = street; }

        public String getCity() { return city; }
        public void setCity(String city) { this.city = city; }

        public String getState() { return state; }
        public void setState(String state) { this.state = state; }

        public String getZipCode() { return zipCode; }
        public void setZipCode(String zipCode) { this.zipCode = zipCode; }

        public String getCountry() { return country; }
        public void setCountry(String country) { this.country = country; }
    }

    @Override
    public String toString() {
        return "OrderCreatedEvent{" +
                "customerId='" + customerId + '\'' +
                ", customerEmail='" + customerEmail + '\'' +
                ", orderItems=" + orderItems +
                ", totalAmount=" + totalAmount +
                ", currency='" + currency + '\'' +
                ", orderStatus='" + orderStatus + '\'' +
                ", paymentMethod='" + paymentMethod + '\'' +
                "} " + super.toString();
    }
}
