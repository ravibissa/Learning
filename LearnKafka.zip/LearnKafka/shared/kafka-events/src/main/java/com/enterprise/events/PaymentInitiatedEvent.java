package com.enterprise.events;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

import java.math.BigDecimal;

/**
 * Event published when a payment process is initiated.
 * 
 * This event is triggered when:
 * - An order requires payment processing
 * - A refund process is started
 * - A subscription payment is due
 * 
 * @author Enterprise Platform Team
 * @version 1.0.0
 * @since 2024-01-01
 */
public class PaymentInitiatedEvent extends BaseEvent {

    @JsonProperty("orderId")
    @NotBlank
    private String orderId;

    @JsonProperty("customerId")
    @NotBlank
    private String customerId;

    @JsonProperty("amount")
    @NotNull
    @Positive
    private BigDecimal amount;

    @JsonProperty("currency")
    @NotBlank
    private String currency;

    @JsonProperty("paymentMethod")
    @NotBlank
    private String paymentMethod;

    @JsonProperty("paymentProvider")
    private String paymentProvider;

    @JsonProperty("merchantId")
    private String merchantId;

    @JsonProperty("paymentType")
    @NotBlank
    private String paymentType; // PURCHASE, REFUND, SUBSCRIPTION

    /**
     * Constructor for creating a payment initiated event.
     * 
     * @param paymentId the unique payment identifier
     * @param version the payment version
     * @param orderId the associated order ID
     * @param customerId the customer making the payment
     * @param amount the payment amount
     * @param currency the currency code
     * @param paymentMethod the payment method (CREDIT_CARD, PAYPAL, etc.)
     * @param paymentType the type of payment (PURCHASE, REFUND, SUBSCRIPTION)
     */
    public PaymentInitiatedEvent(String paymentId, Long version, String orderId, String customerId,
                               BigDecimal amount, String currency, String paymentMethod, String paymentType) {
        super("PAYMENT_INITIATED", paymentId, "Payment", version);
        this.orderId = orderId;
        this.customerId = customerId;
        this.amount = amount;
        this.currency = currency;
        this.paymentMethod = paymentMethod;
        this.paymentType = paymentType;
    }

    /**
     * Default constructor for JSON deserialization.
     */
    public PaymentInitiatedEvent() {
        super();
    }

    // Getters and Setters

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public String getPaymentProvider() {
        return paymentProvider;
    }

    public void setPaymentProvider(String paymentProvider) {
        this.paymentProvider = paymentProvider;
    }

    public String getMerchantId() {
        return merchantId;
    }

    public void setMerchantId(String merchantId) {
        this.merchantId = merchantId;
    }

    public String getPaymentType() {
        return paymentType;
    }

    public void setPaymentType(String paymentType) {
        this.paymentType = paymentType;
    }

    @Override
    public String toString() {
        return "PaymentInitiatedEvent{" +
                "orderId='" + orderId + '\'' +
                ", customerId='" + customerId + '\'' +
                ", amount=" + amount +
                ", currency='" + currency + '\'' +
                ", paymentMethod='" + paymentMethod + '\'' +
                ", paymentProvider='" + paymentProvider + '\'' +
                ", paymentType='" + paymentType + '\'' +
                "} " + super.toString();
    }
}
