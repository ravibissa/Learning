package com.enterprise.events;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

import java.math.BigDecimal;
import java.time.Instant;

/**
 * Event published when a payment is successfully completed.
 * 
 * This event triggers downstream processing including:
 * - Order fulfillment
 * - Receipt generation
 * - Customer notification
 * - Audit logging
 * 
 * @author Enterprise Platform Team
 * @version 1.0.0
 * @since 2024-01-01
 */
public class PaymentCompletedEvent extends BaseEvent {

    @JsonProperty("orderId")
    @NotBlank
    private String orderId;

    @JsonProperty("customerId")
    @NotBlank
    private String customerId;

    @JsonProperty("amount")
    @NotNull
    @Positive
    private BigDecimal amount;

    @JsonProperty("currency")
    @NotBlank
    private String currency;

    @JsonProperty("paymentMethod")
    @NotBlank
    private String paymentMethod;

    @JsonProperty("transactionId")
    @NotBlank
    private String transactionId;

    @JsonProperty("providerTransactionId")
    private String providerTransactionId;

    @JsonProperty("paymentProvider")
    private String paymentProvider;

    @JsonProperty("processingFee")
    private BigDecimal processingFee;

    @JsonProperty("completedAt")
    @NotNull
    private Instant completedAt;

    @JsonProperty("receiptUrl")
    private String receiptUrl;

    /**
     * Constructor for creating a payment completed event.
     * 
     * @param paymentId the unique payment identifier
     * @param version the payment version
     * @param orderId the associated order ID
     * @param customerId the customer who made the payment
     * @param amount the payment amount
     * @param currency the currency code
     * @param paymentMethod the payment method used
     * @param transactionId the internal transaction ID
     * @param providerTransactionId the payment provider's transaction ID
     */
    public PaymentCompletedEvent(String paymentId, Long version, String orderId, String customerId,
                               BigDecimal amount, String currency, String paymentMethod,
                               String transactionId, String providerTransactionId) {
        super("PAYMENT_COMPLETED", paymentId, "Payment", version);
        this.orderId = orderId;
        this.customerId = customerId;
        this.amount = amount;
        this.currency = currency;
        this.paymentMethod = paymentMethod;
        this.transactionId = transactionId;
        this.providerTransactionId = providerTransactionId;
        this.completedAt = Instant.now();
    }

    /**
     * Default constructor for JSON deserialization.
     */
    public PaymentCompletedEvent() {
        super();
    }

    // Getters and Setters

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getProviderTransactionId() {
        return providerTransactionId;
    }

    public void setProviderTransactionId(String providerTransactionId) {
        this.providerTransactionId = providerTransactionId;
    }

    public String getPaymentProvider() {
        return paymentProvider;
    }

    public void setPaymentProvider(String paymentProvider) {
        this.paymentProvider = paymentProvider;
    }

    public BigDecimal getProcessingFee() {
        return processingFee;
    }

    public void setProcessingFee(BigDecimal processingFee) {
        this.processingFee = processingFee;
    }

    public Instant getCompletedAt() {
        return completedAt;
    }

    public void setCompletedAt(Instant completedAt) {
        this.completedAt = completedAt;
    }

    public String getReceiptUrl() {
        return receiptUrl;
    }

    public void setReceiptUrl(String receiptUrl) {
        this.receiptUrl = receiptUrl;
    }

    @Override
    public String toString() {
        return "PaymentCompletedEvent{" +
                "orderId='" + orderId + '\'' +
                ", customerId='" + customerId + '\'' +
                ", amount=" + amount +
                ", currency='" + currency + '\'' +
                ", paymentMethod='" + paymentMethod + '\'' +
                ", transactionId='" + transactionId + '\'' +
                ", providerTransactionId='" + providerTransactionId + '\'' +
                ", completedAt=" + completedAt +
                "} " + super.toString();
    }
}
