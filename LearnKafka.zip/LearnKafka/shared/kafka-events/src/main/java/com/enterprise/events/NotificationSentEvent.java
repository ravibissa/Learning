package com.enterprise.events;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotBlank;

/**
 * Event published when a notification is successfully sent.
 */
public class NotificationSentEvent extends BaseEvent {

    @JsonProperty("recipientId")
    @NotBlank
    private String recipientId;

    @JsonProperty("notificationType")
    @NotBlank
    private String notificationType;

    @JsonProperty("channel")
    @NotBlank
    private String channel; // EMAIL, SMS, PUSH

    @JsonProperty("templateId")
    private String templateId;

    @JsonProperty("subject")
    private String subject;

    public NotificationSentEvent(String notificationId, Long version, String recipientId,
                               String notificationType, String channel) {
        super("NOTIFICATION_SENT", notificationId, "Notification", version);
        this.recipientId = recipientId;
        this.notificationType = notificationType;
        this.channel = channel;
    }

    public NotificationSentEvent() {
        super();
    }

    // Getters and Setters
    public String getRecipientId() { return recipientId; }
    public void setRecipientId(String recipientId) { this.recipientId = recipientId; }

    public String getNotificationType() { return notificationType; }
    public void setNotificationType(String notificationType) { this.notificationType = notificationType; }

    public String getChannel() { return channel; }
    public void setChannel(String channel) { this.channel = channel; }

    public String getTemplateId() { return templateId; }
    public void setTemplateId(String templateId) { this.templateId = templateId; }

    public String getSubject() { return subject; }
    public void setSubject(String subject) { this.subject = subject; }
}
