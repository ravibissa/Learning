package com.enterprise.events;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;

/**
 * Event published when a payment fails.
 * 
 * This event triggers compensating actions including:
 * - Order cancellation or retry logic
 * - Customer notification
 * - Fraud detection analysis
 * - Audit logging
 * 
 * @author Enterprise Platform Team
 * @version 1.0.0
 * @since 2024-01-01
 */
public class PaymentFailedEvent extends BaseEvent {

    @JsonProperty("orderId")
    @NotBlank
    private String orderId;

    @JsonProperty("customerId")
    @NotBlank
    private String customerId;

    @JsonProperty("amount")
    @NotNull
    private BigDecimal amount;

    @JsonProperty("currency")
    @NotBlank
    private String currency;

    @JsonProperty("paymentMethod")
    @NotBlank
    private String paymentMethod;

    @JsonProperty("failureReason")
    @NotBlank
    private String failureReason;

    @JsonProperty("errorCode")
    private String errorCode;

    @JsonProperty("providerErrorCode")
    private String providerErrorCode;

    @JsonProperty("retryable")
    private Boolean retryable;

    @JsonProperty("attemptNumber")
    private Integer attemptNumber;

    public PaymentFailedEvent(String paymentId, Long version, String orderId, String customerId,
                            BigDecimal amount, String currency, String paymentMethod,
                            String failureReason, String errorCode, Boolean retryable) {
        super("PAYMENT_FAILED", paymentId, "Payment", version);
        this.orderId = orderId;
        this.customerId = customerId;
        this.amount = amount;
        this.currency = currency;
        this.paymentMethod = paymentMethod;
        this.failureReason = failureReason;
        this.errorCode = errorCode;
        this.retryable = retryable;
    }

    public PaymentFailedEvent() {
        super();
    }

    // Getters and Setters (abbreviated for space)
    public String getOrderId() { return orderId; }
    public void setOrderId(String orderId) { this.orderId = orderId; }

    public String getCustomerId() { return customerId; }
    public void setCustomerId(String customerId) { this.customerId = customerId; }

    public BigDecimal getAmount() { return amount; }
    public void setAmount(BigDecimal amount) { this.amount = amount; }

    public String getCurrency() { return currency; }
    public void setCurrency(String currency) { this.currency = currency; }

    public String getPaymentMethod() { return paymentMethod; }
    public void setPaymentMethod(String paymentMethod) { this.paymentMethod = paymentMethod; }

    public String getFailureReason() { return failureReason; }
    public void setFailureReason(String failureReason) { this.failureReason = failureReason; }

    public String getErrorCode() { return errorCode; }
    public void setErrorCode(String errorCode) { this.errorCode = errorCode; }

    public String getProviderErrorCode() { return providerErrorCode; }
    public void setProviderErrorCode(String providerErrorCode) { this.providerErrorCode = providerErrorCode; }

    public Boolean getRetryable() { return retryable; }
    public void setRetryable(Boolean retryable) { this.retryable = retryable; }

    public Integer getAttemptNumber() { return attemptNumber; }
    public void setAttemptNumber(Integer attemptNumber) { this.attemptNumber = attemptNumber; }
}
