package com.enterprise.events;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotBlank;

import java.util.Map;

/**
 * Event published when an audit log entry is created.
 */
public class AuditLogCreatedEvent extends BaseEvent {

    @JsonProperty("entityType")
    @NotBlank
    private String entityType;

    @JsonProperty("entityId")
    @NotBlank
    private String entityId;

    @JsonProperty("action")
    @NotBlank
    private String action;

    @JsonProperty("actorId")
    private String actorId;

    @JsonProperty("actorType")
    private String actorType;

    @JsonProperty("changes")
    private Map<String, Object> changes;

    public AuditLogCreatedEvent(String auditId, Long version, String entityType, String entityId,
                              String action, String actorId) {
        super("AUDIT_LOG_CREATED", auditId, "AuditLog", version);
        this.entityType = entityType;
        this.entityId = entityId;
        this.action = action;
        this.actorId = actorId;
    }

    public AuditLogCreatedEvent() {
        super();
    }

    // Getters and Setters
    public String getEntityType() { return entityType; }
    public void setEntityType(String entityType) { this.entityType = entityType; }

    public String getEntityId() { return entityId; }
    public void setEntityId(String entityId) { this.entityId = entityId; }

    public String getAction() { return action; }
    public void setAction(String action) { this.action = action; }

    public String getActorId() { return actorId; }
    public void setActorId(String actorId) { this.actorId = actorId; }

    public String getActorType() { return actorType; }
    public void setActorType(String actorType) { this.actorType = actorType; }

    public Map<String, Object> getChanges() { return changes; }
    public void setChanges(Map<String, Object> changes) { this.changes = changes; }
}
