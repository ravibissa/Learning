# Enterprise Microservices System with Kafka and AWS

A production-ready microservices architecture built with Java 21, Spring Boot 3.2+, Apache Kafka, and AWS services, deployed on Amazon EKS.

## Architecture Overview

```mermaid
graph TB
    subgraph "Client Layer"
        WEB[Web Application]
        MOBILE[Mobile App]
        API_GW[API Gateway / ALB]
    end
    
    subgraph "EKS Cluster"
        subgraph "Order Service"
            ORDER_SVC[Order Service]
            ORDER_DB[(RDS PostgreSQL)]
        end
        
        subgraph "Payment Service"
            PAYMENT_SVC[Payment Service]
            PAYMENT_DB[(DynamoDB)]
        end
        
        subgraph "Notification Service"
            NOTIFICATION_SVC[Notification Service]
            NOTIFICATION_CACHE[(Redis)]
        end
        
        subgraph "Audit Service"
            AUDIT_SVC[Audit Service]
            AUDIT_DB[(DynamoDB)]
        end
        
        subgraph "Infrastructure"
            KAFKA[Kafka Cluster]
            ZOOKEEPER[ZooKeeper]
            SCHEMA_REGISTRY[Schema Registry]
        end
    end
    
    subgraph "AWS Services"
        S3[S3 Storage]
        LAMBDA[Lambda Functions]
        SES[SES Email]
        SNS[SNS Notifications]
        SECRETS[Secrets Manager]
        CLOUDWATCH[CloudWatch]
        PARAMETER_STORE[Parameter Store]
    end
    
    WEB --> API_GW
    MOBILE --> API_GW
    API_GW --> ORDER_SVC
    API_GW --> PAYMENT_SVC
    
    ORDER_SVC --> KAFKA
    PAYMENT_SVC --> KAFKA
    NOTIFICATION_SVC --> KAFKA
    AUDIT_SVC --> KAFKA
    
    ORDER_SVC --> ORDER_DB
    PAYMENT_SVC --> PAYMENT_DB
    AUDIT_SVC --> AUDIT_DB
    
    NOTIFICATION_SVC --> SES
    NOTIFICATION_SVC --> SNS
    ORDER_SVC --> S3
    PAYMENT_SVC --> S3
    
    KAFKA --> LAMBDA
    LAMBDA --> CLOUDWATCH
    
    ORDER_SVC --> SECRETS
    PAYMENT_SVC --> SECRETS
    NOTIFICATION_SVC --> PARAMETER_STORE
    AUDIT_SVC --> PARAMETER_STORE
```

## Services Overview

### 1. Order Service
- **Technology**: Spring Boot 3.2, PostgreSQL (RDS), Kafka Producer/Consumer
- **Responsibilities**: Order management, inventory validation, order lifecycle
- **AWS Integrations**: RDS, S3 (document storage), Secrets Manager
- **Patterns**: Event Sourcing, CQRS, Saga Orchestration

### 2. Payment Service
- **Technology**: Spring Boot 3.2, DynamoDB, Kafka Producer/Consumer
- **Responsibilities**: Payment processing, fraud detection, transaction management
- **AWS Integrations**: DynamoDB, S3 (receipt storage), Secrets Manager
- **Patterns**: Circuit Breaker, Retry with Exponential Backoff, DLQ

### 3. Notification Service
- **Technology**: Spring Boot 3.2, Redis Cache, Kafka Consumer
- **Responsibilities**: Email/SMS notifications, push notifications, notification preferences
- **AWS Integrations**: SES, SNS, Parameter Store
- **Patterns**: Template Engine, Batch Processing, Rate Limiting

### 4. Audit Service
- **Technology**: Spring Boot 3.2, DynamoDB, Kafka Consumer
- **Responsibilities**: Event logging, compliance tracking, audit trails
- **AWS Integrations**: DynamoDB, Lambda (async processing), CloudWatch
- **Patterns**: Event Sourcing, Time-series Data, Data Archiving

## Technology Stack

### Core Technologies
- **Java 21** (LTS)
- **Spring Boot 3.2+**
- **Apache Kafka 3.6+**
- **Docker & Docker Compose**
- **Kubernetes 1.28+**
- **Helm 3.12+**

### AWS Services
- **Amazon EKS** (Kubernetes)
- **Amazon RDS** (PostgreSQL)
- **Amazon DynamoDB**
- **Amazon S3**
- **AWS Lambda**
- **Amazon SES**
- **Amazon SNS**
- **AWS Secrets Manager**
- **AWS Systems Manager Parameter Store**
- **Amazon CloudWatch**
- **Application Load Balancer (ALB)**

### Monitoring & Observability
- **Micrometer** with Prometheus
- **OpenTelemetry** for distributed tracing
- **CloudWatch** for AWS metrics
- **Grafana** for dashboards
- **ELK Stack** for logging

### Testing
- **JUnit 5**
- **Testcontainers**
- **WireMock**
- **Spring Boot Test**
- **Kafka Test Utils**

## Project Structure

```
enterprise-microservices/
├── services/
│   ├── order-service/
│   ├── payment-service/
│   ├── notification-service/
│   └── audit-service/
├── shared/
│   ├── common-lib/
│   ├── kafka-events/
│   └── aws-config/
├── infrastructure/
│   ├── docker/
│   ├── kubernetes/
│   ├── helm-charts/
│   └── terraform/
├── ci-cd/
│   ├── github-actions/
│   └── aws-codepipeline/
├── docker-compose.yml
├── docker-compose.aws.yml
└── README.md
```

## Quick Start

### Prerequisites
- Java 21
- Docker & Docker Compose
- AWS CLI configured
- kubectl and helm installed
- Maven 3.9+

### Local Development Setup

1. **Clone the repository**
```bash
git clone <repository-url>
cd enterprise-microservices
```

2. **Start local infrastructure**
```bash
docker-compose up -d kafka zookeeper postgres redis localstack
```

3. **Build all services**
```bash
mvn clean install
```

4. **Start all services**
```bash
docker-compose up
```

5. **Verify services are running**
```bash
curl http://localhost:8081/actuator/health  # Order Service
curl http://localhost:8082/actuator/health  # Payment Service
curl http://localhost:8083/actuator/health  # Notification Service
curl http://localhost:8084/actuator/health  # Audit Service
```

### AWS Deployment

1. **Create EKS cluster**
```bash
cd infrastructure/terraform
terraform init
terraform apply
```

2. **Deploy using Helm**
```bash
cd infrastructure/helm-charts
helm install microservices-stack ./microservices-stack
```

3. **Configure auto-scaling**
```bash
kubectl apply -f infrastructure/kubernetes/hpa/
kubectl apply -f infrastructure/kubernetes/vpa/
```

## Configuration

### Environment Variables
Each service supports the following configuration approaches:
- **Local Development**: `application-local.yml`
- **AWS Development**: `application-dev.yml` with AWS Parameter Store
- **AWS Production**: `application-prod.yml` with AWS Secrets Manager

### Key Configuration Properties
```yaml
# Kafka Configuration
spring.kafka.bootstrap-servers: ${KAFKA_BOOTSTRAP_SERVERS}
spring.kafka.security.protocol: ${KAFKA_SECURITY_PROTOCOL:PLAINTEXT}

# AWS Configuration
aws.region: ${AWS_REGION:us-east-1}
aws.s3.bucket: ${S3_BUCKET_NAME}
aws.secrets-manager.enabled: ${SECRETS_MANAGER_ENABLED:true}

# Database Configuration
spring.datasource.url: ${DATABASE_URL}
spring.datasource.username: ${DATABASE_USERNAME}
spring.datasource.password: ${DATABASE_PASSWORD}
```

## Monitoring and Observability

### Metrics
- **Application Metrics**: Micrometer → Prometheus → Grafana
- **Infrastructure Metrics**: CloudWatch
- **Business Metrics**: Custom metrics per service

### Logging
- **Structured Logging**: JSON format with correlation IDs
- **Log Aggregation**: CloudWatch Logs
- **Log Analysis**: ELK Stack (optional)

### Tracing
- **Distributed Tracing**: OpenTelemetry
- **Trace Storage**: AWS X-Ray
- **Trace Analysis**: Jaeger (local), X-Ray Console (AWS)

### Health Checks
- **Kubernetes**: Liveness and readiness probes
- **Application**: Spring Boot Actuator endpoints
- **Dependencies**: Custom health indicators

## Security

### Authentication & Authorization
- **Service-to-Service**: mTLS with certificates from AWS Certificate Manager
- **API Gateway**: AWS Cognito or custom JWT validation
- **Database**: IAM database authentication where supported

### Secrets Management
- **AWS Secrets Manager**: Database credentials, API keys
- **AWS Parameter Store**: Configuration parameters
- **Kubernetes Secrets**: Service account tokens, certificates

### Network Security
- **VPC**: Private subnets for services, public subnets for load balancers
- **Security Groups**: Restrictive ingress/egress rules
- **Network Policies**: Kubernetes network policies for pod-to-pod communication

## CI/CD Pipeline

### GitHub Actions Workflow
1. **Code Quality**: SonarQube analysis, dependency check
2. **Testing**: Unit tests, integration tests, contract tests
3. **Building**: Maven build, Docker image creation
4. **Security**: Container scanning, vulnerability assessment
5. **Deployment**: Helm deployment to EKS

### AWS CodePipeline (Alternative)
1. **Source**: CodeCommit or GitHub integration
2. **Build**: CodeBuild with Maven and Docker
3. **Test**: Automated testing with CodeBuild
4. **Deploy**: CodeDeploy with EKS integration

## Testing Strategy

### Unit Tests
- **Coverage**: Minimum 80% code coverage
- **Frameworks**: JUnit 5, Mockito, AssertJ
- **Patterns**: Test slices, mock external dependencies

### Integration Tests
- **Testcontainers**: Real databases and Kafka for integration tests
- **Spring Boot Test**: Full application context testing
- **WireMock**: External service mocking

### Contract Tests
- **Spring Cloud Contract**: Consumer-driven contract testing
- **Pact**: Alternative contract testing framework

### End-to-End Tests
- **Kubernetes**: Tests running against actual EKS cluster
- **AWS Services**: Tests using real AWS services in test environment

## Performance and Scalability

### Auto-scaling
- **HPA**: CPU and memory-based scaling
- **VPA**: Vertical pod autoscaling for resource optimization
- **Cluster Autoscaler**: Node-level scaling

### Performance Tuning
- **JVM Tuning**: G1GC, heap sizing, container-aware settings
- **Kafka Tuning**: Producer/consumer optimization
- **Database Tuning**: Connection pooling, query optimization

### Load Testing
- **Tools**: JMeter, Gatling, or k6
- **Scenarios**: Peak load, stress testing, endurance testing
- **Metrics**: Throughput, latency, error rates

## Disaster Recovery

### Backup Strategy
- **Databases**: Automated backups with point-in-time recovery
- **Kafka**: Topic replication across availability zones
- **Configuration**: Infrastructure as Code for reproducibility

### Recovery Procedures
- **Service Recovery**: Rolling deployments with health checks
- **Data Recovery**: Database restore procedures
- **Infrastructure Recovery**: Terraform-based infrastructure recreation

## Contributing

### Development Guidelines
1. Follow Java coding standards and best practices
2. Write comprehensive tests for all new features
3. Update documentation for API changes
4. Use conventional commits for clear history

### Code Review Process
1. All changes require pull request review
2. Automated checks must pass (tests, quality gates)
3. Manual testing in development environment
4. Security review for sensitive changes

## Support and Documentation

### API Documentation
- **OpenAPI 3.0**: Auto-generated API documentation
- **Swagger UI**: Interactive API explorer
- **Postman Collections**: Ready-to-use API collections

### Runbooks
- **Deployment**: Step-by-step deployment procedures
- **Troubleshooting**: Common issues and solutions
- **Monitoring**: Alert response procedures

### Training Materials
- **Architecture Decision Records (ADRs)**: Design decisions and rationale
- **Service Documentation**: Per-service README files
- **Onboarding Guide**: New developer setup instructions

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Contact

- **Team**: Platform Engineering Team
- **Email**: platform-team@company.com
- **Slack**: #platform-engineering
- **Documentation**: [Internal Wiki](https://wiki.company.com/platform)
