# 🐳 Docker, Kubernetes & Infrastructure Deep Dive

This comprehensive guide explains Docker containerization, Kubernetes orchestration, and Infrastructure as Code for the microservices platform. Every command, keyword, and concept is explained in detail with step-by-step flows.

## 📚 Table of Contents

1. [Docker Fundamentals](#1-docker-fundamentals)
2. [Dockerfile Deep Analysis](#2-dockerfile-deep-analysis)
3. [Docker Compose Orchestration](#3-docker-compose-orchestration)
4. [Kubernetes Architecture](#4-kubernetes-architecture)
5. [Kubernetes Manifests Explained](#5-kubernetes-manifests-explained)
6. [Kustomize Configuration Management](#6-kustomize-configuration-management)
7. [Infrastructure as Code (SAM)](#7-infrastructure-as-code-sam)
8. [CI/CD Pipeline Integration](#8-cicd-pipeline-integration)
9. [Monitoring & Observability](#9-monitoring--observability)
10. [Production Deployment Strategies](#10-production-deployment-strategies)

---

## 1. Docker Fundamentals

### 1.1: What is Docker?

Docker is a containerization platform that packages applications with their dependencies into lightweight, portable containers.

```
Traditional Deployment:
┌─────────────────────────────────────┐
│           Physical Server           │
│ ┌─────────────────────────────────┐ │
│ │        Operating System         │ │
│ │ ┌─────────────────────────────┐ │ │
│ │ │         Runtime             │ │ │
│ │ │ ┌─────────────────────────┐ │ │ │
│ │ │ │      Application        │ │ │ │
│ │ │ └─────────────────────────┘ │ │ │
│ │ └─────────────────────────────┘ │ │
│ └─────────────────────────────────┘ │
└─────────────────────────────────────┘

Docker Deployment:
┌─────────────────────────────────────┐
│           Docker Host               │
│ ┌─────────────────────────────────┐ │
│ │        Docker Engine           │ │
│ │ ┌─────────┐ ┌─────────┐ ┌─────┐ │ │
│ │ │Container│ │Container│ │ ... │ │ │
│ │ │   App   │ │   App   │ │     │ │ │
│ │ │Runtime  │ │Runtime  │ │     │ │ │
│ │ └─────────┘ └─────────┘ └─────┘ │ │
│ └─────────────────────────────────┘ │
└─────────────────────────────────────┘
```

### 1.2: Docker Core Concepts

#### Images vs Containers
```bash
# Image: Blueprint/Template (like a class)
docker images

# Container: Running instance (like an object)
docker ps

# Relationship
docker run <image> → creates → <container>
```

#### Docker Commands Explained

**Building Images:**
```bash
# Build image from Dockerfile
docker build -t organization-service:latest -f organization-service/Dockerfile .

# Command breakdown:
# docker build    : Build command
# -t              : Tag (name:version)
# organization-service:latest : Image name and tag
# -f              : Dockerfile path
# .               : Build context (current directory)
```

**Running Containers:**
```bash
# Run container interactively
docker run -it --rm \
  -p 8081:8081 \
  -e SPRING_PROFILES_ACTIVE=local \
  -e DYNAMODB_ENDPOINT=http://localstack:4566 \
  organization-service:latest

# Command breakdown:
# docker run      : Run command
# -it             : Interactive terminal
# --rm            : Remove container when stopped
# -p 8081:8081    : Port mapping (host:container)
# -e              : Environment variable
# organization-service:latest : Image to run
```

**Container Management:**
```bash
# List running containers
docker ps

# List all containers (including stopped)
docker ps -a

# Stop container
docker stop <container-id>

# Remove container
docker rm <container-id>

# View container logs
docker logs <container-id>

# Execute command in running container
docker exec -it <container-id> /bin/bash
```

### 1.3: Docker Networking

#### Network Types
```bash
# List networks
docker network ls

# Create custom network
docker network create microservices-network

# Connect container to network
docker run --network microservices-network nginx
```

#### Container Communication
```yaml
# In docker-compose.yml
networks:
  microservices:        # Custom network name
    driver: bridge      # Network driver

services:
  organization-service:
    networks:
      - microservices   # Connect to custom network
    
  employee-service:
    networks:
      - microservices   # Same network for communication
    environment:
      # Use service name as hostname
      - ORGANIZATION_SERVICE_URL=http://organization-service:8081
```

---

## 2. Dockerfile Deep Analysis

### 2.1: Multi-Stage Build Strategy

Our Dockerfile uses multi-stage builds for optimization:

```dockerfile
# Stage 1: Build Stage
FROM openjdk:11-jdk-slim as builder

# Install Maven
RUN apt-get update && apt-get install -y maven && rm -rf /var/lib/apt/lists/*

# Set working directory
WORKDIR /app

# Copy source code
COPY pom.xml .
COPY common/ common/
COPY organization-service/pom.xml organization-service/
COPY organization-service/src/ organization-service/src/

# Build application
RUN mvn clean package -pl organization-service -am -DskipTests

# Stage 2: Runtime Stage
FROM openjdk:11-jre-slim

# Create non-root user for security
RUN groupadd -r appuser && useradd -r -g appuser appuser

# Install curl for health checks
RUN apt-get update && apt-get install -y curl && rm -rf /var/lib/apt/lists/*

WORKDIR /app

# Copy built JAR from build stage
COPY --from=builder /app/organization-service/target/organization-service-*.jar app.jar

# Set ownership
RUN chown -R appuser:appuser /app

# Switch to non-root user
USER appuser

# Expose port
EXPOSE 8081

# Health check
HEALTHCHECK --interval=30s --timeout=3s --start-period=60s --retries=3 \
    CMD curl -f http://localhost:8081/actuator/health || exit 1

# Application startup
ENTRYPOINT ["java", "-Djava.security.egd=file:/dev/./urandom", "-jar", "app.jar"]
```

### 2.2: Dockerfile Instructions Explained

#### FROM Instruction
```dockerfile
FROM openjdk:11-jdk-slim as builder
# FROM: Base image
# openjdk:11-jdk-slim: OpenJDK 11 with minimal OS
# as builder: Stage name for multi-stage build
```

#### RUN Instruction
```dockerfile
RUN apt-get update && apt-get install -y maven && rm -rf /var/lib/apt/lists/*
# RUN: Execute command during image build
# &&: Chain commands (fail if any fails)
# rm -rf /var/lib/apt/lists/*: Clean package cache to reduce image size
```

#### COPY Instruction
```dockerfile
COPY pom.xml .
# COPY: Copy files from host to container
# pom.xml: Source file on host
# .: Destination in container (current WORKDIR)

COPY --from=builder /app/organization-service/target/organization-service-*.jar app.jar
# --from=builder: Copy from previous build stage
# *.jar: Wildcard for JAR file
# app.jar: Rename to standard name
```

#### USER Instruction
```dockerfile
RUN groupadd -r appuser && useradd -r -g appuser appuser
USER appuser
# Security best practice: Don't run as root
# -r: System user (no login shell)
# -g: Primary group
```

#### EXPOSE Instruction
```dockerfile
EXPOSE 8081
# Documents which port the container listens on
# Does NOT actually publish the port
# Use -p flag in docker run to publish
```

#### HEALTHCHECK Instruction
```dockerfile
HEALTHCHECK --interval=30s --timeout=3s --start-period=60s --retries=3 \
    CMD curl -f http://localhost:8081/actuator/health || exit 1

# --interval=30s: Check every 30 seconds
# --timeout=3s: Timeout after 3 seconds
# --start-period=60s: Grace period for app startup
# --retries=3: Mark unhealthy after 3 failures
# CMD: Command to run for health check
# || exit 1: Return error code if curl fails
```

#### ENTRYPOINT vs CMD
```dockerfile
ENTRYPOINT ["java", "-Djava.security.egd=file:/dev/./urandom", "-jar", "app.jar"]
# ENTRYPOINT: Always executed, cannot be overridden
# CMD: Default arguments, can be overridden
# -Djava.security.egd=file:/dev/./urandom: Faster random number generation
```

### 2.3: Image Optimization Techniques

#### Layer Caching Strategy
```dockerfile
# Copy dependency files first (changes less frequently)
COPY pom.xml .
COPY common/pom.xml common/

# Copy source code last (changes more frequently)
COPY organization-service/src/ organization-service/src/

# Build (this layer will be cached if dependencies don't change)
RUN mvn dependency:go-offline
RUN mvn clean package -DskipTests
```

#### .dockerignore File
```bash
# Create .dockerignore to exclude unnecessary files
echo "target/
.git/
.gitignore
README.md
Dockerfile
.dockerignore
*.md" > .dockerignore
```

---

## 3. Docker Compose Orchestration

### 3.1: Docker Compose Structure

Docker Compose manages multi-container applications using YAML configuration:

```yaml
version: '3.8'                    # Compose file version

services:                         # Define services (containers)
  service-name:                   # Service identifier
    image: image-name             # Pre-built image
    build:                        # Build from Dockerfile
      context: .                  # Build context
      dockerfile: path/Dockerfile # Dockerfile location
    ports:                        # Port mapping
      - "host:container"          
    environment:                  # Environment variables
      - VAR=value                 
    volumes:                      # Volume mounts
      - host-path:container-path  
    networks:                     # Network connections
      - network-name              
    depends_on:                   # Service dependencies
      - other-service             

volumes:                          # Named volumes
  volume-name:                    

networks:                         # Custom networks
  network-name:                   
    driver: bridge                # Network driver
```

### 3.2: Service Configuration Deep Dive

#### LocalStack Service
```yaml
localstack:
  image: localstack/localstack:3.0    # AWS services emulator
  container_name: localstack          # Custom container name
  ports:
    - "4566:4566"                     # Main LocalStack port
    - "4571:4571"                     # Legacy port
  environment:
    - SERVICES=dynamodb,s3,lambda,apigateway,logs,cloudformation
    # SERVICES: Which AWS services to emulate
    - DEBUG=1                         # Enable debug logging
    - DATA_DIR=/tmp/localstack/data   # Data persistence directory
    - DOCKER_HOST=unix:///var/run/docker.sock  # Docker socket access
    - HOST_TMP_FOLDER=/tmp/localstack # Host temp folder
  volumes:
    - "/tmp/localstack:/tmp/localstack"           # Data persistence
    - "/var/run/docker.sock:/var/run/docker.sock" # Docker socket mount
  networks:
    - microservices                   # Custom network
```

#### Application Service Configuration
```yaml
organization-service:
  build:                              # Build from source
    context: .                        # Build context (project root)
    dockerfile: organization-service/Dockerfile  # Dockerfile path
  container_name: organization-service # Container name
  ports:
    - "8081:8081"                     # Port mapping (host:container)
  environment:
    - SPRING_PROFILES_ACTIVE=local    # Spring profile
    - DYNAMODB_ENDPOINT=http://localstack:4566  # LocalStack endpoint
    - AWS_REGION=us-east-1            # AWS region
    - AWS_ACCESS_KEY_ID=test          # Test credentials
    - AWS_SECRET_ACCESS_KEY=test      # Test credentials
  depends_on:                         # Service dependencies
    - localstack                      # Wait for LocalStack
  restart: unless-stopped             # Restart policy
  networks:
    - microservices                   # Custom network
  healthcheck:                        # Health check configuration
    test: ["CMD", "curl", "-f", "http://localhost:8081/actuator/health"]
    interval: 30s                     # Check every 30 seconds
    timeout: 10s                      # Timeout after 10 seconds
    retries: 3                        # Retry 3 times
    start_period: 60s                 # Grace period for startup
```

#### Monitoring Stack
```yaml
prometheus:
  image: prom/prometheus:v2.47.2      # Prometheus metrics collector
  container_name: prometheus          
  ports:
    - "9090:9090"                     # Prometheus UI port
  volumes:
    - ./monitoring/prometheus.yml:/etc/prometheus/prometheus.yml  # Config
    - prometheus_data:/prometheus     # Data persistence
  command:                            # Override default command
    - '--config.file=/etc/prometheus/prometheus.yml'
    - '--storage.tsdb.path=/prometheus'
    - '--web.console.libraries=/etc/prometheus/console_libraries'
    - '--web.console.templates=/etc/prometheus/consoles'
    - '--storage.tsdb.retention.time=200h'  # Keep data for 200 hours
    - '--web.enable-lifecycle'        # Enable API for config reload
  networks:
    - microservices

grafana:
  image: grafana/grafana:10.2.0       # Grafana visualization
  container_name: grafana
  ports:
    - "3000:3000"                     # Grafana UI port
  environment:
    - GF_SECURITY_ADMIN_PASSWORD=admin  # Admin password
    - GF_USERS_ALLOW_SIGN_UP=false   # Disable user registration
  volumes:
    - grafana_data:/var/lib/grafana   # Data persistence
    - ./monitoring/grafana/provisioning:/etc/grafana/provisioning  # Config
    - ./monitoring/grafana/dashboards:/var/lib/grafana/dashboards  # Dashboards
  depends_on:
    - prometheus                      # Wait for Prometheus
  networks:
    - microservices
```

### 3.3: Docker Compose Commands

#### Basic Operations
```bash
# Start all services in background
docker-compose up -d

# Command breakdown:
# docker-compose: Compose command
# up: Start services
# -d: Detached mode (background)

# View service status
docker-compose ps

# View logs from all services
docker-compose logs

# View logs from specific service
docker-compose logs -f organization-service

# Options:
# -f: Follow logs (tail -f equivalent)

# Stop all services
docker-compose down

# Stop and remove volumes
docker-compose down -v

# Options:
# -v: Remove named volumes
```

#### Service Management
```bash
# Start specific service
docker-compose up organization-service

# Stop specific service
docker-compose stop organization-service

# Restart specific service
docker-compose restart organization-service

# Rebuild and start service
docker-compose up --build organization-service

# Scale service (run multiple instances)
docker-compose up --scale organization-service=3

# Execute command in running service
docker-compose exec organization-service /bin/bash

# View service configuration
docker-compose config
```

#### Development Workflow
```bash
# Build images without starting
docker-compose build

# Pull latest images
docker-compose pull

# Remove stopped containers
docker-compose rm

# View resource usage
docker-compose top
```

### 3.4: Network Communication Flow

```mermaid
graph TB
    subgraph "Docker Host"
        subgraph "microservices network (bridge)"
            LS[LocalStack<br/>:4566]
            ORG[Organization Service<br/>:8081]
            EMP[Employee Service<br/>:8080]
            PROM[Prometheus<br/>:9090]
            GRAF[Grafana<br/>:3000]
            NGINX[Nginx<br/>:80]
        end
    end
    
    subgraph "Host Network"
        HOST[Host Machine]
    end
    
    HOST -->|Port 4566| LS
    HOST -->|Port 8081| ORG
    HOST -->|Port 8080| EMP
    HOST -->|Port 9090| PROM
    HOST -->|Port 3000| GRAF
    HOST -->|Port 80| NGINX
    
    EMP -.->|http://organization-service:8081| ORG
    PROM -.->|Scrape metrics| ORG
    PROM -.->|Scrape metrics| EMP
    GRAF -.->|Query metrics| PROM
    NGINX -.->|Proxy requests| ORG
    NGINX -.->|Proxy requests| EMP
    ORG -.->|DynamoDB API| LS
    EMP -.->|DynamoDB API| LS
```

---

## 4. Kubernetes Architecture

### 4.1: Kubernetes Overview

Kubernetes is a container orchestration platform that automates deployment, scaling, and management of containerized applications.

```
Kubernetes Cluster Architecture:

┌─────────────────────────────────────────────────────────────┐
│                    Control Plane                           │
│ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────┐ │
│ │ API Server  │ │   etcd      │ │ Scheduler   │ │Controller│ │
│ │             │ │             │ │             │ │ Manager │ │
│ └─────────────┘ └─────────────┘ └─────────────┘ └─────────┘ │
└─────────────────────────────────────────────────────────────┘
                              │
                              │ kubectl
                              │
┌─────────────────────────────────────────────────────────────┐
│                    Worker Nodes                            │
│ ┌─────────────────────────┐ ┌─────────────────────────┐     │
│ │       Node 1            │ │       Node 2            │     │
│ │ ┌─────────┐ ┌─────────┐ │ │ ┌─────────┐ ┌─────────┐ │     │
│ │ │   Pod   │ │   Pod   │ │ │ │   Pod   │ │   Pod   │ │     │
│ │ │Container│ │Container│ │ │ │Container│ │Container│ │     │
│ │ └─────────┘ └─────────┘ │ │ └─────────┘ └─────────┘ │     │
│ │      kubelet            │ │      kubelet            │     │
│ └─────────────────────────┘ └─────────────────────────┘     │
└─────────────────────────────────────────────────────────────┘
```

### 4.2: Kubernetes Core Components

#### Control Plane Components
- **API Server**: REST API interface for Kubernetes
- **etcd**: Distributed key-value store for cluster data
- **Scheduler**: Assigns pods to nodes
- **Controller Manager**: Runs controller processes

#### Node Components
- **kubelet**: Node agent that manages pods
- **kube-proxy**: Network proxy for services
- **Container Runtime**: Runs containers (Docker, containerd)

#### Kubernetes Objects
- **Pod**: Smallest deployable unit (one or more containers)
- **Deployment**: Manages replica sets and rolling updates
- **Service**: Network abstraction for accessing pods
- **ConfigMap**: Configuration data
- **Secret**: Sensitive data (passwords, tokens)
- **Namespace**: Virtual cluster isolation

### 4.3: Kubernetes Resource Types

#### Workload Resources
```yaml
# Pod: Basic execution unit
apiVersion: v1
kind: Pod
metadata:
  name: my-pod
spec:
  containers:
  - name: my-container
    image: nginx

# Deployment: Manages pods with replicas
apiVersion: apps/v1
kind: Deployment
metadata:
  name: my-deployment
spec:
  replicas: 3
  selector:
    matchLabels:
      app: my-app
  template:
    metadata:
      labels:
        app: my-app
    spec:
      containers:
      - name: my-container
        image: nginx
```

#### Service Resources
```yaml
# Service: Network access to pods
apiVersion: v1
kind: Service
metadata:
  name: my-service
spec:
  selector:
    app: my-app
  ports:
  - port: 80
    targetPort: 8080
  type: ClusterIP
```

#### Configuration Resources
```yaml
# ConfigMap: Non-sensitive configuration
apiVersion: v1
kind: ConfigMap
metadata:
  name: my-config
data:
  database_url: "postgres://localhost:5432/mydb"
  debug_mode: "true"

# Secret: Sensitive data
apiVersion: v1
kind: Secret
metadata:
  name: my-secret
type: Opaque
data:
  username: YWRtaW4=  # base64 encoded
  password: MWYyZDFlMmU2N2Rm  # base64 encoded
```

---

## 5. Kubernetes Manifests Explained

### 5.1: Namespace Configuration

```yaml
apiVersion: v1              # API version for this resource type
kind: Namespace             # Resource type
metadata:                   # Resource metadata
  name: microservices       # Namespace name
  labels:                   # Labels for organization
    name: microservices     # Label key-value pair
    environment: base       # Environment identifier
```

**Namespace Purpose:**
- **Isolation**: Separate environments (dev, staging, prod)
- **Resource Quotas**: Limit resource usage per namespace
- **Access Control**: RBAC policies per namespace
- **Organization**: Group related resources

### 5.2: ConfigMap Deep Dive

```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: microservices-config    # ConfigMap name
  namespace: microservices      # Target namespace
data:                           # Configuration data (key-value pairs)
  AWS_REGION: "us-east-1"       # String values (no quotes needed in data)
  SPRING_PROFILES_ACTIVE: "k8s" # Spring profile for Kubernetes
  ORGANIZATION_SERVICE_URL: "http://organization-service:8081"  # Service URL
  ORGANIZATION_SERVICE_TIMEOUT: "5"      # Timeout in seconds
  LOGGING_LEVEL_ROOT: "INFO"             # Root logging level
  LOGGING_LEVEL_COM_EXAMPLE: "DEBUG"     # Application logging level
```

**ConfigMap Usage in Pods:**
```yaml
# Environment variable from ConfigMap
env:
- name: SPRING_PROFILES_ACTIVE
  valueFrom:
    configMapKeyRef:
      name: microservices-config    # ConfigMap name
      key: SPRING_PROFILES_ACTIVE   # Key in ConfigMap

# Volume mount from ConfigMap
volumes:
- name: config-volume
  configMap:
    name: microservices-config
volumeMounts:
- name: config-volume
  mountPath: /app/config
```

### 5.3: Secret Configuration

```yaml
apiVersion: v1
kind: Secret
metadata:
  name: microservices-secret
  namespace: microservices
type: Opaque                    # Secret type (generic key-value)
data:                           # Base64 encoded values
  AWS_ACCESS_KEY_ID: dGVzdA==   # echo -n "test" | base64
  AWS_SECRET_ACCESS_KEY: dGVzdA== # echo -n "test" | base64
  DYNAMODB_ENDPOINT: ""         # Empty for AWS, set for local
```

**Secret Types:**
- **Opaque**: Generic secret (default)
- **kubernetes.io/tls**: TLS certificates
- **kubernetes.io/dockerconfigjson**: Docker registry credentials
- **kubernetes.io/service-account-token**: Service account tokens

**Secret Usage:**
```yaml
env:
- name: AWS_ACCESS_KEY_ID
  valueFrom:
    secretKeyRef:
      name: microservices-secret
      key: AWS_ACCESS_KEY_ID
```

### 5.4: Deployment Analysis

```yaml
apiVersion: apps/v1         # API version for Deployment
kind: Deployment            # Resource type
metadata:
  name: organization-service    # Deployment name
  namespace: microservices      # Target namespace
  labels:                       # Deployment labels
    app: organization-service   # Application identifier
    version: v1                 # Version label
spec:                          # Deployment specification
  replicas: 2                  # Number of pod replicas
  selector:                    # Pod selector
    matchLabels:               # Must match template labels
      app: organization-service
  template:                    # Pod template
    metadata:
      labels:                  # Pod labels (must match selector)
        app: organization-service
        version: v1
    spec:                      # Pod specification
      containers:              # Container specifications
      - name: organization-service    # Container name
        image: organization-service:latest  # Container image
        imagePullPolicy: IfNotPresent      # Image pull policy
        ports:                 # Container ports
        - containerPort: 8081  # Port the container listens on
          name: http           # Port name
        env:                   # Environment variables
        - name: SPRING_PROFILES_ACTIVE
          valueFrom:
            configMapKeyRef:
              name: microservices-config
              key: SPRING_PROFILES_ACTIVE
        resources:             # Resource requirements
          requests:            # Minimum resources
            memory: "512Mi"    # 512 MiB memory
            cpu: "250m"        # 250 millicores (0.25 CPU)
          limits:              # Maximum resources
            memory: "1Gi"      # 1 GiB memory
            cpu: "500m"        # 500 millicores (0.5 CPU)
        livenessProbe:         # Container health check
          httpGet:
            path: /actuator/health/liveness
            port: 8081
          initialDelaySeconds: 60    # Wait 60s before first check
          periodSeconds: 30          # Check every 30s
          timeoutSeconds: 10         # Timeout after 10s
          failureThreshold: 3        # Restart after 3 failures
        readinessProbe:        # Ready to receive traffic
          httpGet:
            path: /actuator/health/readiness
            port: 8081
          initialDelaySeconds: 30    # Wait 30s before first check
          periodSeconds: 10          # Check every 10s
          timeoutSeconds: 5          # Timeout after 5s
          failureThreshold: 3        # Mark unready after 3 failures
        securityContext:       # Security settings
          runAsNonRoot: true         # Don't run as root
          runAsUser: 1000            # Run as user ID 1000
          readOnlyRootFilesystem: true  # Read-only root filesystem
          allowPrivilegeEscalation: false  # No privilege escalation
        volumeMounts:          # Volume mounts
        - name: tmp
          mountPath: /tmp      # Mount writable temp directory
      volumes:                 # Volume definitions
      - name: tmp
        emptyDir: {}           # Temporary volume
      securityContext:         # Pod security context
        fsGroup: 1000          # File system group ID
```

### 5.5: Service Configuration

```yaml
apiVersion: v1
kind: Service
metadata:
  name: organization-service       # Service name (DNS name)
  namespace: microservices
  labels:
    app: organization-service
spec:
  selector:                        # Pod selector
    app: organization-service      # Matches deployment labels
  ports:                           # Port configuration
  - port: 8081                     # Service port (cluster internal)
    targetPort: 8081               # Pod port
    protocol: TCP                  # Protocol (TCP/UDP)
    name: http                     # Port name
  type: ClusterIP                  # Service type
```

**Service Types:**
- **ClusterIP**: Internal cluster access only (default)
- **NodePort**: External access via node IP and port
- **LoadBalancer**: Cloud provider load balancer
- **ExternalName**: DNS CNAME record

### 5.6: Ingress Configuration

```yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: microservices-ingress
  namespace: microservices
  annotations:                     # Ingress controller specific settings
    nginx.ingress.kubernetes.io/rewrite-target: /$2
    nginx.ingress.kubernetes.io/use-regex: "true"
    nginx.ingress.kubernetes.io/proxy-body-size: "10m"
    nginx.ingress.kubernetes.io/proxy-connect-timeout: "10"
    nginx.ingress.kubernetes.io/proxy-send-timeout: "60"
    nginx.ingress.kubernetes.io/proxy-read-timeout: "60"
spec:
  ingressClassName: nginx          # Ingress controller class
  rules:                          # Routing rules
  - host: microservices.local     # Host header matching
    http:
      paths:                      # Path-based routing
      - path: /api/v1/employees(/|$)(.*)  # Regex path matching
        pathType: Prefix          # Path matching type
        backend:
          service:
            name: employee-service    # Target service
            port:
              number: 8080       # Service port
      - path: /api/v1/organizations(/|$)(.*)
        pathType: Prefix
        backend:
          service:
            name: organization-service
            port:
              number: 8081
```

### 5.7: HorizontalPodAutoscaler (HPA)

```yaml
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: organization-service-hpa
  namespace: microservices
spec:
  scaleTargetRef:                  # Target to scale
    apiVersion: apps/v1
    kind: Deployment
    name: organization-service
  minReplicas: 2                   # Minimum pods
  maxReplicas: 10                  # Maximum pods
  metrics:                         # Scaling metrics
  - type: Resource
    resource:
      name: cpu                    # CPU utilization
      target:
        type: Utilization
        averageUtilization: 70     # Scale at 70% CPU
  - type: Resource
    resource:
      name: memory                 # Memory utilization
      target:
        type: Utilization
        averageUtilization: 80     # Scale at 80% memory
  behavior:                        # Scaling behavior
    scaleDown:
      stabilizationWindowSeconds: 300  # Wait 5min before scaling down
      policies:
      - type: Percent
        value: 10                  # Scale down by 10% max
        periodSeconds: 60          # Every minute
    scaleUp:
      stabilizationWindowSeconds: 60   # Wait 1min before scaling up
      policies:
      - type: Percent
        value: 100                 # Scale up by 100% max
        periodSeconds: 15          # Every 15 seconds
```

---

## 6. Kustomize Configuration Management

### 6.1: Kustomize Overview

Kustomize manages Kubernetes configuration without templates. It uses a declarative approach to customize YAML manifests.

```
Kustomize Structure:
├── base/                    # Base configuration
│   ├── kustomization.yaml   # Base kustomization
│   ├── deployment.yaml      # Base deployment
│   ├── service.yaml         # Base service
│   └── configmap.yaml       # Base config
└── overlays/                # Environment-specific customizations
    ├── dev/                 # Development environment
    │   ├── kustomization.yaml
    │   ├── configmap-patch.yaml
    │   └── resource-patch.yaml
    └── prod/                # Production environment
        ├── kustomization.yaml
        └── resource-patch.yaml
```

### 6.2: Base Kustomization

```yaml
# k8s/base/kustomization.yaml
apiVersion: kustomize.config.k8s.io/v1beta1
kind: Kustomization

namespace: microservices       # Default namespace for all resources

resources:                     # List of resource files
  - namespace.yaml             # Namespace definition
  - configmap.yaml             # ConfigMap
  - secret.yaml                # Secret
  - organization-service.yaml  # Organization service manifests
  - employee-service.yaml      # Employee service manifests
  - ingress.yaml               # Ingress configuration
  - hpa.yaml                   # HorizontalPodAutoscaler

commonLabels:                  # Labels applied to all resources
  app.kubernetes.io/name: microservices
  app.kubernetes.io/part-of: microservices-platform

images:                        # Image name/tag management
  - name: organization-service
    newTag: latest             # Default tag
  - name: employee-service
    newTag: latest
```

### 6.3: Development Overlay

```yaml
# k8s/overlays/dev/kustomization.yaml
apiVersion: kustomize.config.k8s.io/v1beta1
kind: Kustomization

namespace: microservices-dev   # Override namespace

namePrefix: dev-               # Add prefix to resource names

resources:                     # Include base configuration
  - ../../base                 # Relative path to base

commonLabels:                  # Additional labels
  environment: dev

patchesStrategicMerge:         # Strategic merge patches
  - configmap-patch.yaml       # Override ConfigMap values
  - secret-patch.yaml          # Override Secret values
  - organization-service-patch.yaml  # Resource adjustments
  - employee-service-patch.yaml

images:                        # Override image tags
  - name: organization-service
    newTag: dev                # Development tag
  - name: employee-service
    newTag: dev

replicas:                      # Override replica counts
  - name: organization-service
    count: 1                   # Single replica for dev
  - name: employee-service
    count: 1
```

### 6.4: Strategic Merge Patches

#### ConfigMap Patch
```yaml
# k8s/overlays/dev/configmap-patch.yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: microservices-config
  namespace: microservices-dev
data:
  SPRING_PROFILES_ACTIVE: "dev"    # Override to dev profile
  LOGGING_LEVEL_ROOT: "DEBUG"      # More verbose logging
  LOGGING_LEVEL_COM_EXAMPLE: "TRACE"  # Trace level for app
```

#### Resource Patch
```yaml
# k8s/overlays/dev/organization-service-patch.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: organization-service
spec:
  template:
    spec:
      containers:
      - name: organization-service
        resources:
          requests:
            memory: "256Mi"        # Reduced memory for dev
            cpu: "100m"            # Reduced CPU for dev
          limits:
            memory: "512Mi"
            cpu: "250m"
```

### 6.5: Production Overlay

```yaml
# k8s/overlays/prod/kustomization.yaml
apiVersion: kustomize.config.k8s.io/v1beta1
kind: Kustomization

namespace: microservices-prod

namePrefix: prod-

resources:
  - ../../base

commonLabels:
  environment: prod

patchesStrategicMerge:
  - configmap-patch.yaml
  - organization-service-patch.yaml
  - employee-service-patch.yaml

images:
  - name: organization-service
    newTag: prod
  - name: employee-service
    newTag: prod

replicas:
  - name: organization-service
    count: 3                       # High availability
  - name: employee-service
    count: 3
```

#### Production Resource Patch
```yaml
# k8s/overlays/prod/organization-service-patch.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: organization-service
spec:
  template:
    spec:
      containers:
      - name: organization-service
        resources:
          requests:
            memory: "1Gi"          # Production memory requirements
            cpu: "500m"            # Production CPU requirements
          limits:
            memory: "2Gi"
            cpu: "1000m"
```

### 6.6: Kustomize Commands

```bash
# Build configuration (dry-run)
kustomize build k8s/overlays/dev

# Apply configuration
kubectl apply -k k8s/overlays/dev

# View differences
kustomize build k8s/overlays/dev | kubectl diff -f -

# Edit image tags
cd k8s/overlays/dev
kustomize edit set image organization-service=org-service:v1.2.3

# Add resources
kustomize edit add resource new-service.yaml

# Add patches
kustomize edit add patch --path service-patch.yaml

# Validate configuration
kustomize build k8s/overlays/prod | kubeval
```

---

## 7. Infrastructure as Code (SAM)

### 7.1: SAM Template Structure

AWS SAM (Serverless Application Model) extends CloudFormation to define serverless applications:

```yaml
AWSTemplateFormatVersion: '2010-09-09'    # CloudFormation version
Transform: AWS::Serverless-2016-10-31     # SAM transform
Description: 'Employee and Organization microservices'

Parameters:                                # Template parameters
  Environment:
    Type: String
    Default: dev
    AllowedValues: [dev, staging, prod]
    Description: Environment name

Globals:                                   # Global settings
  Function:                                # Default function settings
    Timeout: 30                            # 30 second timeout
    MemorySize: 512                        # 512 MB memory
    Runtime: java11                        # Java 11 runtime
    Environment:
      Variables:
        ENVIRONMENT: !Ref Environment      # CloudFormation reference
        AWS_REGION: !Ref AWS::Region       # Pseudo parameter

Resources:                                 # AWS resources
  # DynamoDB, Lambda, API Gateway, etc.

Outputs:                                   # Template outputs
  ApiGatewayUrl:
    Description: "API Gateway endpoint URL"
    Value: !Sub "https://${MicroservicesApi}.execute-api.${AWS::Region}.amazonaws.com/${Environment}"
```

### 7.2: DynamoDB Table Definition

```yaml
OrganizationsTable:
  Type: AWS::DynamoDB::Table               # Resource type
  Properties:
    TableName: !Sub "${Environment}-organizations"  # Dynamic name
    BillingMode: !Ref TableBillingMode     # Parameter reference
    AttributeDefinitions:                  # Table schema
      - AttributeName: id                  # Primary key
        AttributeType: S                   # String type
      - AttributeName: domain              # GSI key
        AttributeType: S
    KeySchema:                             # Primary key schema
      - AttributeName: id
        KeyType: HASH                      # Partition key
    GlobalSecondaryIndexes:                # GSI definition
      - IndexName: DomainIndex
        KeySchema:
          - AttributeName: domain
            KeyType: HASH
        Projection:
          ProjectionType: ALL              # Project all attributes
    StreamSpecification:                   # DynamoDB Streams
      StreamViewType: NEW_AND_OLD_IMAGES   # Include before/after images
    PointInTimeRecoverySpecification:      # Backup configuration
      PointInTimeRecoveryEnabled: true
    DeletionProtectionEnabled: !If [IsProduction, true, false]  # Conditional
    Tags:                                  # Resource tags
      - Key: Environment
        Value: !Ref Environment
      - Key: Service
        Value: organization-service
```

### 7.3: Lambda Function Definition

```yaml
OrganizationServiceFunction:
  Type: AWS::Serverless::Function          # SAM function type
  Properties:
    FunctionName: !Sub "${Environment}-organization-service"
    CodeUri: ../organization-service/target/organization-service-aws.jar
    Handler: com.example.organization.handler.OrganizationLambdaHandler::handleRequest
    Role: !GetAtt LambdaExecutionRole.Arn  # IAM role reference
    Environment:
      Variables:
        SPRING_PROFILES_ACTIVE: aws        # AWS profile
        DYNAMODB_TABLE_NAME: !Ref OrganizationsTable  # Table reference
    Events:                                # Event sources
      ApiGateway:
        Type: Api                          # API Gateway event
        Properties:
          RestApiId: !Ref MicroservicesApi # API reference
          Path: /organizations/{proxy+}    # Path pattern
          Method: ANY                      # All HTTP methods
    DeadLetterQueue:                       # Error handling
      Type: SQS
      TargetArn: !GetAtt OrganizationServiceDLQ.Arn
    Tags:
      Environment: !Ref Environment
      Service: organization-service
```

### 7.4: API Gateway Configuration

```yaml
MicroservicesApi:
  Type: AWS::Serverless::Api
  Properties:
    Name: !Sub "${Environment}-microservices-api"
    StageName: !Ref Environment            # Stage name from parameter
    Cors:                                  # CORS configuration
      AllowMethods: "'GET,POST,PUT,DELETE,OPTIONS'"
      AllowHeaders: "'Content-Type,X-Amz-Date,Authorization,X-Api-Key'"
      AllowOrigin: "'*'"
    Auth:                                  # Authorization
      DefaultAuthorizer: AWS_IAM           # IAM-based auth
    GatewayResponses:                      # Custom error responses
      BAD_REQUEST_BODY:
        ResponseTemplates:
          application/json: |
            {
              "timestamp": "$context.requestTime",
              "status": 400,
              "error": "Bad Request",
              "message": "$context.error.validationErrorString",
              "path": "$context.path"
            }
    RequestValidators:                     # Request validation
      RequestValidator:
        ValidateRequestBody: true
        ValidateRequestParameters: true
    Models:                                # Request/response models
      EmployeeModel:
        type: object
        required:
          - firstName
          - lastName
          - email
          - organizationId
        properties:
          firstName:
            type: string
            minLength: 1
            maxLength: 100
          email:
            type: string
            format: email
```

### 7.5: IAM Roles and Policies

```yaml
LambdaExecutionRole:
  Type: AWS::IAM::Role
  Properties:
    RoleName: !Sub "${Environment}-microservices-lambda-role"
    AssumeRolePolicyDocument:              # Trust policy
      Version: '2012-10-17'
      Statement:
        - Effect: Allow
          Principal:
            Service: lambda.amazonaws.com  # Lambda service principal
          Action: sts:AssumeRole
    ManagedPolicyArns:                     # AWS managed policies
      - arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole
      - arn:aws:iam::aws:policy/AWSXRayDaemonWriteAccess
    Policies:                              # Inline policies
      - PolicyName: DynamoDBAccess
        PolicyDocument:
          Version: '2012-10-17'
          Statement:
            - Effect: Allow
              Action:                      # Least privilege permissions
                - dynamodb:GetItem
                - dynamodb:PutItem
                - dynamodb:UpdateItem
                - dynamodb:DeleteItem
                - dynamodb:Query
                - dynamodb:Scan
              Resource:                    # Specific resource ARNs
                - !GetAtt OrganizationsTable.Arn
                - !Sub "${OrganizationsTable.Arn}/index/*"
                - !GetAtt EmployeesTable.Arn
                - !Sub "${EmployeesTable.Arn}/index/*"
```

### 7.6: CloudWatch Monitoring

```yaml
OrganizationServiceErrorAlarm:
  Type: AWS::CloudWatch::Alarm
  Properties:
    AlarmName: !Sub "${Environment}-organization-service-errors"
    AlarmDescription: "High error rate for organization service"
    MetricName: Errors                     # Lambda metric
    Namespace: AWS/Lambda                  # Metric namespace
    Statistic: Sum                         # Aggregation method
    Period: 300                            # 5 minute periods
    EvaluationPeriods: 2                   # 2 consecutive periods
    Threshold: 10                          # Error threshold
    ComparisonOperator: GreaterThanThreshold
    Dimensions:
      - Name: FunctionName
        Value: !Ref OrganizationServiceFunction
```

### 7.7: SAM CLI Commands

```bash
# Build SAM application
sam build --config-env dev

# Command options:
# --config-env: Use environment-specific config
# --parallel: Build functions in parallel
# --cached: Use cached dependencies

# Deploy application
sam deploy --config-env dev --guided

# Options:
# --guided: Interactive deployment
# --confirm-changeset: Review changes before deploy
# --no-fail-on-empty-changeset: Don't fail if no changes

# Local testing
sam local start-api --config-env dev

# Local Lambda invocation
sam local invoke OrganizationServiceFunction --event events/test-event.json

# Generate sample events
sam local generate-event apigateway aws-proxy > events/api-event.json

# Validate template
sam validate --template template.yaml

# Package for deployment
sam package --s3-bucket my-deployment-bucket

# Delete stack
sam delete --stack-name microservices-dev-stack
```

### 7.8: SAM Configuration File

```toml
# samconfig.toml
version = 0.1

[default]
[default.global.parameters]
stack_name = "microservices-stack"

[default.build.parameters]
cached = true                    # Use cached builds
parallel = true                  # Parallel builds

[default.deploy.parameters]
capabilities = "CAPABILITY_IAM"  # Allow IAM resource creation
confirm_changeset = true         # Review changes
resolve_s3 = true               # Auto-create S3 bucket
s3_prefix = "microservices"     # S3 prefix for artifacts
region = "us-east-1"            # AWS region
parameter_overrides = [
    "Environment=dev"
]

# Environment-specific configurations
[dev]
[dev.deploy.parameters]
stack_name = "microservices-dev-stack"
parameter_overrides = [
    "Environment=dev",
    "TableBillingMode=PAY_PER_REQUEST"
]

[prod]
[prod.deploy.parameters]
stack_name = "microservices-prod-stack"
parameter_overrides = [
    "Environment=prod",
    "TableBillingMode=PROVISIONED"
]
confirm_changeset = true
fail_on_empty_changeset = false
```

---

## 8. CI/CD Pipeline Integration

### 8.1: GitHub Actions Workflow Structure

```yaml
# .github/workflows/ci.yml
name: CI Pipeline

on:                                # Trigger events
  push:
    branches: [ main, develop ]    # Branch triggers
  pull_request:
    branches: [ main ]             # PR triggers

env:                               # Environment variables
  JAVA_VERSION: '11'
  JAVA_DISTRIBUTION: 'temurin'

jobs:
  test:                            # Job definition
    name: Test and Coverage
    runs-on: ubuntu-latest         # Runner OS
    
    services:                      # Service containers
      localstack:
        image: localstack/localstack:3.0
        ports:
          - 4566:4566              # Port mapping
        env:
          SERVICES: dynamodb,s3,lambda
          DEBUG: 1
        options: >-                # Health check
          --health-cmd="curl -f http://localhost:4566/_localstack/health"
          --health-interval=10s
          --health-timeout=5s
          --health-retries=3

    steps:                         # Job steps
    - name: Checkout code          # Step name
      uses: actions/checkout@v4    # Predefined action
      
    - name: Set up JDK ${{ env.JAVA_VERSION }}
      uses: actions/setup-java@v3  # Java setup action
      with:                        # Action inputs
        java-version: ${{ env.JAVA_VERSION }}
        distribution: ${{ env.JAVA_DISTRIBUTION }}

    - name: Cache Maven dependencies
      uses: actions/cache@v3       # Cache action
      with:
        path: ~/.m2                # Cache path
        key: ${{ runner.os }}-m2-${{ hashFiles('**/pom.xml') }}
        restore-keys: ${{ runner.os }}-m2

    - name: Run tests
      run: mvn clean test          # Shell command
      env:                         # Step environment
        DYNAMODB_ENDPOINT: http://localhost:4566
        AWS_REGION: us-east-1
```

### 8.2: Docker Build and Push

```yaml
docker-build:
  name: Build Docker Images
  runs-on: ubuntu-latest
  needs: test                      # Job dependency

  steps:
  - name: Set up Docker Buildx
    uses: docker/setup-buildx-action@v3

  - name: Log in to Docker Hub
    uses: docker/login-action@v3
    with:
      username: ${{ secrets.DOCKER_USERNAME }}    # GitHub secret
      password: ${{ secrets.DOCKER_PASSWORD }}

  - name: Extract metadata
    id: meta                       # Step ID for output
    uses: docker/metadata-action@v5
    with:
      images: ${{ secrets.DOCKER_USERNAME }}/organization-service
      tags: |                      # Tag strategy
        type=ref,event=branch      # Branch name
        type=ref,event=pr          # PR number
        type=sha,prefix={{branch}}- # Git SHA
        type=raw,value=latest,enable={{is_default_branch}}

  - name: Build and push image
    uses: docker/build-push-action@v5
    with:
      context: .                   # Build context
      file: ./organization-service/Dockerfile
      push: true                   # Push to registry
      tags: ${{ steps.meta.outputs.tags }}    # Use extracted tags
      labels: ${{ steps.meta.outputs.labels }}
      cache-from: type=gha         # GitHub Actions cache
      cache-to: type=gha,mode=max
```

### 8.3: AWS Deployment

```yaml
# .github/workflows/deploy-aws.yml
deploy-aws:
  name: Deploy to AWS
  runs-on: ubuntu-latest
  environment: ${{ github.event.inputs.environment || 'dev' }}

  steps:
  - name: Configure AWS credentials
    uses: aws-actions/configure-aws-credentials@v4
    with:
      aws-access-key-id: ${{ secrets.AWS_ACCESS_KEY_ID }}
      aws-secret-access-key: ${{ secrets.AWS_SECRET_ACCESS_KEY }}
      aws-region: ${{ env.AWS_REGION }}
      role-to-assume: ${{ secrets.AWS_DEPLOYMENT_ROLE_ARN }}  # Cross-account role
      role-session-name: GitHubActions-Deploy
      role-duration-seconds: 3600

  - name: Install SAM CLI
    run: |
      pip install aws-sam-cli==${{ env.SAM_CLI_VERSION }}

  - name: SAM build
    run: |
      cd infra
      sam build --config-env ${{ env.ENVIRONMENT }}

  - name: SAM deploy
    run: |
      cd infra
      sam deploy \
        --config-env ${{ env.ENVIRONMENT }} \
        --no-confirm-changeset \
        --no-fail-on-empty-changeset \
        --parameter-overrides Environment=${{ env.ENVIRONMENT }} \
        --tags Environment=${{ env.ENVIRONMENT }} \
               GitCommit=${{ github.sha }} \
               DeployedBy=GitHubActions

  - name: Run smoke tests
    run: |
      API_URL=$(aws cloudformation describe-stacks \
        --stack-name microservices-${{ env.ENVIRONMENT }}-stack \
        --query 'Stacks[0].Outputs[?OutputKey==`ApiGatewayUrl`].OutputValue' \
        --output text)
      
      # Test endpoints
      curl -f $API_URL/organizations/health
      curl -f $API_URL/employees/health
```

### 8.4: Kubernetes Deployment

```yaml
# .github/workflows/deploy-k8s.yml
deploy-k8s:
  name: Deploy to Kubernetes
  runs-on: ubuntu-latest

  steps:
  - name: Install kubectl
    uses: azure/setup-kubectl@v3
    with:
      version: 'v1.28.3'

  - name: Install Kustomize
    run: |
      curl -s "https://raw.githubusercontent.com/kubernetes-sigs/kustomize/master/hack/install_kustomize.sh" | bash
      sudo mv kustomize /usr/local/bin/

  - name: Configure kubeconfig
    run: |
      mkdir -p ~/.kube
      echo "${{ secrets.KUBECONFIG }}" | base64 -d > ~/.kube/config
      chmod 600 ~/.kube/config

  - name: Update image tags
    run: |
      cd k8s/overlays/${{ env.ENVIRONMENT }}
      kustomize edit set image \
        organization-service=${{ env.REGISTRY }}/organization-service:${{ github.sha }} \
        employee-service=${{ env.REGISTRY }}/employee-service:${{ github.sha }}

  - name: Deploy to Kubernetes
    run: |
      cd k8s/overlays/${{ env.ENVIRONMENT }}
      kustomize build . | kubectl apply -f -
      
      # Wait for deployment
      kubectl wait --for=condition=available --timeout=600s \
        deployment/${{ env.ENVIRONMENT }}-organization-service \
        -n microservices-${{ env.ENVIRONMENT }}
```

---

## 9. Monitoring & Observability

### 9.1: Prometheus Configuration

```yaml
# monitoring/prometheus.yml
global:
  scrape_interval: 15s             # How often to scrape targets
  evaluation_interval: 15s         # How often to evaluate rules

rule_files:                        # Alert rule files
  - "alert_rules.yml"

scrape_configs:                    # Scrape configurations
  - job_name: 'prometheus'         # Job name
    static_configs:
      - targets: ['localhost:9090'] # Prometheus itself

  - job_name: 'organization-service'
    metrics_path: '/actuator/prometheus'  # Metrics endpoint
    static_configs:
      - targets: ['organization-service:8081']
    scrape_interval: 5s            # Override global interval

  - job_name: 'employee-service'
    metrics_path: '/actuator/prometheus'
    static_configs:
      - targets: ['employee-service:8080']
    scrape_interval: 5s

  - job_name: 'kubernetes-pods'     # Kubernetes pod discovery
    kubernetes_sd_configs:
      - role: pod                  # Discover pods
    relabel_configs:               # Relabeling rules
      - source_labels: [__meta_kubernetes_pod_annotation_prometheus_io_scrape]
        action: keep
        regex: true                # Only scrape annotated pods
      - source_labels: [__meta_kubernetes_pod_annotation_prometheus_io_path]
        action: replace
        target_label: __metrics_path__
        regex: (.+)
```

### 9.2: Grafana Provisioning

```yaml
# monitoring/grafana/provisioning/datasources/prometheus.yml
apiVersion: 1

datasources:
  - name: Prometheus               # Datasource name
    type: prometheus               # Datasource type
    access: proxy                  # Access mode
    url: http://prometheus:9090    # Prometheus URL
    isDefault: true                # Default datasource
    editable: false                # Read-only
```

### 9.3: Custom Metrics in Application

```java
// Custom metrics implementation
@Component
public class MetricsConfiguration {
    
    @Bean
    public Counter organizationsCreated() {
        return Counter.builder("organizations_created_total")
            .description("Total organizations created")
            .tag("service", "organization")
            .register(Metrics.globalRegistry);
    }
    
    @Bean
    public Timer organizationCreationTime() {
        return Timer.builder("organization_creation_duration_seconds")
            .description("Time to create organization")
            .tag("service", "organization")
            .register(Metrics.globalRegistry);
    }
    
    @Bean
    public Gauge organizationsActive() {
        return Gauge.builder("organizations_active")
            .description("Active organizations count")
            .tag("service", "organization")
            .register(Metrics.globalRegistry, this, MetricsConfiguration::getActiveOrganizations);
    }
    
    private double getActiveOrganizations(MetricsConfiguration config) {
        // Implementation to count active organizations
        return organizationRepository.countByDeletedFalse();
    }
}
```

### 9.4: Health Check Implementation

```java
// Custom health indicator
@Component
public class DynamoDbHealthIndicator implements HealthIndicator {
    
    private final DynamoDbClient dynamoDbClient;
    
    @Override
    public Health health() {
        try {
            // Test DynamoDB connectivity
            ListTablesResponse response = dynamoDbClient.listTables();
            
            return Health.up()
                .withDetail("database", "DynamoDB")
                .withDetail("tables", response.tableNames().size())
                .withDetail("status", "Connected")
                .build();
                
        } catch (Exception e) {
            return Health.down()
                .withDetail("database", "DynamoDB")
                .withDetail("error", e.getMessage())
                .withDetail("status", "Disconnected")
                .build();
        }
    }
}
```

---

## 10. Production Deployment Strategies

### 10.1: Blue-Green Deployment

```yaml
# Blue-Green deployment strategy
apiVersion: argoproj.io/v1alpha1
kind: Rollout
metadata:
  name: organization-service
spec:
  replicas: 5
  strategy:
    blueGreen:                     # Blue-Green strategy
      activeService: organization-service-active
      previewService: organization-service-preview
      autoPromotionEnabled: false  # Manual promotion
      scaleDownDelaySeconds: 30    # Keep old version for 30s
      prePromotionAnalysis:        # Pre-promotion checks
        templates:
        - templateName: success-rate
        args:
        - name: service-name
          value: organization-service-preview
      postPromotionAnalysis:       # Post-promotion checks
        templates:
        - templateName: success-rate
        args:
        - name: service-name
          value: organization-service-active
  selector:
    matchLabels:
      app: organization-service
  template:
    metadata:
      labels:
        app: organization-service
    spec:
      containers:
      - name: organization-service
        image: organization-service:latest
```

### 10.2: Canary Deployment

```yaml
# Canary deployment with Istio
apiVersion: argoproj.io/v1alpha1
kind: Rollout
metadata:
  name: employee-service
spec:
  replicas: 10
  strategy:
    canary:                        # Canary strategy
      canaryService: employee-service-canary
      stableService: employee-service-stable
      trafficRouting:
        istio:                     # Istio traffic splitting
          virtualService:
            name: employee-service-vs
          destinationRule:
            name: employee-service-dr
            canarySubsetName: canary
            stableSubsetName: stable
      steps:                       # Canary steps
      - setWeight: 5              # 5% traffic to canary
      - pause: {duration: 2m}     # Wait 2 minutes
      - setWeight: 10             # 10% traffic
      - pause: {duration: 2m}
      - setWeight: 20             # 20% traffic
      - pause: {duration: 2m}
      - setWeight: 50             # 50% traffic
      - pause: {duration: 2m}
      - setWeight: 100            # Full traffic (promotion)
```

### 10.3: Rolling Update Strategy

```yaml
# Standard rolling update
apiVersion: apps/v1
kind: Deployment
metadata:
  name: organization-service
spec:
  replicas: 6
  strategy:
    type: RollingUpdate           # Rolling update strategy
    rollingUpdate:
      maxUnavailable: 1           # Max 1 pod unavailable
      maxSurge: 2                 # Max 2 extra pods during update
  template:
    spec:
      containers:
      - name: organization-service
        image: organization-service:v1.2.3
        readinessProbe:           # Ensure pod ready before routing traffic
          httpGet:
            path: /actuator/health/readiness
            port: 8081
          initialDelaySeconds: 30
          periodSeconds: 10
        livenessProbe:            # Restart unhealthy pods
          httpGet:
            path: /actuator/health/liveness
            port: 8081
          initialDelaySeconds: 60
          periodSeconds: 30
```

### 10.4: Database Migration Strategy

```bash
#!/bin/bash
# Database migration script for DynamoDB

set -e  # Exit on any error

ENVIRONMENT=${1:-dev}
AWS_REGION=${2:-us-east-1}

echo "Starting database migration for environment: $ENVIRONMENT"

# Create tables if they don't exist
aws dynamodb describe-table \
  --table-name "${ENVIRONMENT}-organizations" \
  --region "$AWS_REGION" 2>/dev/null || {
    
    echo "Creating organizations table..."
    aws dynamodb create-table \
      --table-name "${ENVIRONMENT}-organizations" \
      --attribute-definitions \
        AttributeName=id,AttributeType=S \
        AttributeName=domain,AttributeType=S \
      --key-schema AttributeName=id,KeyType=HASH \
      --global-secondary-indexes \
        IndexName=DomainIndex,KeySchema=[{AttributeName=domain,KeyType=HASH}],Projection={ProjectionType=ALL} \
      --billing-mode PAY_PER_REQUEST \
      --region "$AWS_REGION"
    
    echo "Waiting for table to be active..."
    aws dynamodb wait table-exists \
      --table-name "${ENVIRONMENT}-organizations" \
      --region "$AWS_REGION"
}

# Apply data migrations
echo "Applying data migrations..."
python3 scripts/migrate_data.py --environment "$ENVIRONMENT" --region "$AWS_REGION"

echo "Migration completed successfully"
```

### 10.5: Disaster Recovery

```yaml
# Backup and restore configuration
apiVersion: v1
kind: ConfigMap
metadata:
  name: backup-config
data:
  backup-script.sh: |
    #!/bin/bash
    # Automated backup script
    
    TIMESTAMP=$(date +%Y%m%d-%H%M%S)
    BACKUP_BUCKET="microservices-backups-${ENVIRONMENT}"
    
    # Export DynamoDB tables
    aws dynamodb create-backup \
      --table-name "${ENVIRONMENT}-organizations" \
      --backup-name "organizations-${TIMESTAMP}"
    
    aws dynamodb create-backup \
      --table-name "${ENVIRONMENT}-employees" \
      --backup-name "employees-${TIMESTAMP}"
    
    # Export application configs
    kubectl get configmap -n microservices-${ENVIRONMENT} -o yaml > configs-${TIMESTAMP}.yaml
    kubectl get secret -n microservices-${ENVIRONMENT} -o yaml > secrets-${TIMESTAMP}.yaml
    
    # Upload to S3
    aws s3 cp configs-${TIMESTAMP}.yaml s3://${BACKUP_BUCKET}/configs/
    aws s3 cp secrets-${TIMESTAMP}.yaml s3://${BACKUP_BUCKET}/secrets/
    
    echo "Backup completed: ${TIMESTAMP}"

  restore-script.sh: |
    #!/bin/bash
    # Disaster recovery script
    
    BACKUP_TIMESTAMP=${1:-latest}
    SOURCE_ENVIRONMENT=${2:-prod}
    TARGET_ENVIRONMENT=${3:-dr}
    
    echo "Starting disaster recovery from ${SOURCE_ENVIRONMENT} to ${TARGET_ENVIRONMENT}"
    
    # Restore DynamoDB from backup
    aws dynamodb restore-table-from-backup \
      --target-table-name "${TARGET_ENVIRONMENT}-organizations" \
      --backup-arn "arn:aws:dynamodb:region:account:table/organizations/backup/backup-id"
    
    # Restore Kubernetes resources
    sed "s/${SOURCE_ENVIRONMENT}/${TARGET_ENVIRONMENT}/g" configs-${BACKUP_TIMESTAMP}.yaml | kubectl apply -f -
    
    echo "Disaster recovery completed"
```

---

## 🎯 Summary

This comprehensive guide covers:

### **Docker Deep Dive** ✅
- **Container fundamentals** and architecture
- **Multi-stage Dockerfile** optimization
- **Docker Compose** orchestration
- **Networking and communication** patterns

### **Kubernetes Mastery** ✅
- **Core concepts** and architecture
- **Manifest deep analysis** with every field explained
- **Kustomize configuration** management
- **Production deployment** strategies

### **Infrastructure as Code** ✅
- **SAM template** structure and components
- **AWS resource** definitions and relationships
- **IAM security** and least-privilege access
- **Monitoring and alerting** setup

### **CI/CD Integration** ✅
- **GitHub Actions** workflows
- **Automated testing** and quality gates
- **Multi-environment** deployment
- **Security scanning** and compliance

### **Production Operations** ✅
- **Monitoring stack** configuration
- **Custom metrics** and health checks
- **Deployment strategies** (Blue-Green, Canary, Rolling)
- **Disaster recovery** and backup procedures

### **Key Learning Outcomes:**

**For Developers:**
- Understand containerization benefits and implementation
- Master Kubernetes deployment and management
- Implement Infrastructure as Code practices
- Build robust CI/CD pipelines

**For DevOps Engineers:**
- Design scalable container orchestration
- Implement production-grade monitoring
- Manage multi-environment deployments
- Ensure security and compliance

**For Architects:**
- Design cloud-native architectures
- Implement observability and reliability
- Plan disaster recovery strategies
- Optimize costs and performance

Every command, keyword, and configuration option is explained with practical examples and real-world applications. This guide serves as both a learning resource and a reference manual for building production-ready microservices platforms.

---

**Next Steps:**
1. **Practice** with the provided examples
2. **Implement** monitoring dashboards
3. **Set up** automated deployments
4. **Test** disaster recovery procedures
5. **Scale** the platform based on requirements

**Happy Deploying! 🚀**
