# 🔍 Code Walkthrough: Complete Project Analysis & Testing Guide

This document provides a comprehensive step-by-step explanation of how the microservices project was created, how the code works, the application flow, and detailed testing procedures.

## 📚 Table of Contents

1. [Project Creation Process](#1-project-creation-process)
2. [Architecture Overview](#2-architecture-overview)
3. [Code Structure Analysis](#3-code-structure-analysis)
4. [Application Flow Deep Dive](#4-application-flow-deep-dive)
5. [Inter-Service Communication](#5-inter-service-communication)
6. [Data Layer Implementation](#6-data-layer-implementation)
7. [Testing Strategy](#7-testing-strategy)
8. [Developer Testing Guide](#8-developer-testing-guide)
9. [Deployment & DevOps](#9-deployment--devops)
10. [Performance & Monitoring](#10-performance--monitoring)

---

## 1. Project Creation Process

### Step 1.1: Project Initialization

The project was created using Maven multi-module structure:

```bash
# 1. Create parent project
mvn archetype:generate \
  -DgroupId=com.example \
  -DartifactId=microservices-parent \
  -DarchetypeArtifactId=maven-archetype-pom

# 2. Create modules
cd microservices-parent
mvn archetype:generate -DgroupId=com.example -DartifactId=common
mvn archetype:generate -DgroupId=com.example -DartifactId=organization-service
mvn archetype:generate -DgroupId=com.example -DartifactId=employee-service
mvn archetype:generate -DgroupId=com.example -DartifactId=infra
```

### Step 1.2: Dependency Management Setup

**Parent POM Configuration:**
```xml
<properties>
    <spring-boot.version>2.7.18</spring-boot.version>
    <aws-sdk.version>2.21.29</aws-sdk.version>
    <lombok.version>1.18.30</lombok.version>
    <mapstruct.version>1.5.5.Final</mapstruct.version>
</properties>

<dependencyManagement>
    <dependencies>
        <!-- Spring Boot BOM for version management -->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-dependencies</artifactId>
            <version>${spring-boot.version}</version>
            <type>pom</type>
            <scope>import</scope>
        </dependency>
    </dependencies>
</dependencyManagement>
```

**Why this approach:**
- **Centralized dependency management**: All versions defined in one place
- **Consistency**: All modules use same dependency versions
- **Easy upgrades**: Change version in parent, affects all modules

### Step 1.3: Module Structure Creation

```
microservices-parent/
├── common/                    # Shared components
│   ├── dto/                   # Data Transfer Objects
│   ├── exception/             # Custom exceptions
│   └── util/                  # Utility classes
├── organization-service/      # Organization domain
├── employee-service/          # Employee domain
└── infra/                     # Infrastructure as Code
```

---

## 2. Architecture Overview

### 2.1: Layered Architecture Pattern

Each service follows a clean layered architecture:

```
┌─────────────────────────────────────┐
│              Client Layer           │ ← REST clients, web apps
├─────────────────────────────────────┤
│           Controller Layer          │ ← HTTP endpoints, validation
├─────────────────────────────────────┤
│            Service Layer            │ ← Business logic
├─────────────────────────────────────┤
│          Repository Layer           │ ← Data access
├─────────────────────────────────────┤
│            Database Layer           │ ← DynamoDB
└─────────────────────────────────────┘
```

### 2.2: Microservices Design Principles

**Single Responsibility Principle:**
- **Organization Service**: Manages company data
- **Employee Service**: Manages employee data + links to organizations

**Database per Service:**
- Each service has its own DynamoDB table
- No direct database sharing between services
- Data consistency through API calls

**Technology Stack Rationale:**

| Technology | Why Chosen | Benefits |
|------------|------------|----------|
| **Spring Boot** | Rapid development, auto-configuration | Reduces boilerplate, production-ready features |
| **DynamoDB** | NoSQL, serverless, fast | Scales automatically, low latency |
| **AWS Lambda** | Serverless computing | Pay-per-use, auto-scaling |
| **Docker** | Containerization | Consistent environments |
| **Kubernetes** | Container orchestration | Production scalability |

---

## 3. Code Structure Analysis

### 3.1: Common Module Deep Dive

**Purpose**: Shared components to avoid code duplication

#### BaseDto.java - Foundation for all DTOs
```java
@Data
@SuperBuilder
@JsonInclude(JsonInclude.Include.NON_NULL)
public abstract class BaseDto {
    private String id;
    
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
    private Instant createdAt;
    
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
    private Instant updatedAt;
    
    private Boolean deleted;
}
```

**Code Explanation:**
- **@Data**: Lombok generates getters, setters, toString, equals, hashCode
- **@SuperBuilder**: Enables builder pattern for inheritance
- **@JsonInclude(NON_NULL)**: Only include non-null fields in JSON
- **@JsonFormat**: Standardizes date format across all APIs

#### Custom Exception Hierarchy
```java
// Base exception with HTTP status mapping
@Getter
public abstract class BaseException extends RuntimeException {
    private final HttpStatus httpStatus;
    private final String errorCode;
}

// Specific exceptions
public class ResourceNotFoundException extends BaseException {
    public ResourceNotFoundException(String resourceType, String resourceId) {
        super(String.format("%s with id '%s' not found", resourceType, resourceId), 
              HttpStatus.NOT_FOUND, "RESOURCE_NOT_FOUND");
    }
}
```

**Benefits:**
- **Consistent error handling**: All exceptions follow same pattern
- **HTTP status mapping**: Automatic conversion to proper HTTP responses
- **Structured error responses**: Client-friendly error messages

### 3.2: Organization Service Code Analysis

#### Controller Layer - HTTP Interface
```java
@Slf4j
@RestController
@RequestMapping("/api/v1/organizations")
@RequiredArgsConstructor
@Validated
public class OrganizationController {
    
    private final OrganizationService organizationService;
    
    @PostMapping
    public ResponseEntity<OrganizationDto> createOrganization(@Valid @RequestBody OrganizationDto dto) {
        log.info("POST /api/v1/organizations - Creating organization");
        OrganizationDto created = organizationService.createOrganization(dto);
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }
}
```

**Code Breakdown:**
- **@Slf4j**: Lombok provides logger field automatically
- **@RestController**: Combines @Controller + @ResponseBody
- **@RequestMapping**: Base path for all endpoints
- **@RequiredArgsConstructor**: Lombok generates constructor for final fields
- **@Validated**: Enables method-level validation
- **@Valid**: Triggers validation on request body
- **ResponseEntity**: Provides full control over HTTP response

#### Service Layer - Business Logic
```java
@Slf4j
@Service
@RequiredArgsConstructor
public class OrganizationService {
    
    private final OrganizationRepository repository;
    private final OrganizationMapper mapper;
    
    public OrganizationDto createOrganization(OrganizationDto dto) {
        log.info("Creating organization with domain: {}", dto.getDomain());
        
        // Business rule validation
        if (repository.existsByDomain(dto.getDomain())) {
            throw new ValidationException("Organization with domain '" + dto.getDomain() + "' already exists");
        }
        
        // Convert DTO to Entity
        Organization organization = mapper.toEntity(dto);
        
        // Set system fields
        organization.setId(IdGenerator.generateId("org"));
        organization.setCreatedAt(Instant.now());
        organization.setUpdatedAt(Instant.now());
        organization.setDeleted(false);
        
        // Save to database
        Organization saved = repository.save(organization);
        log.info("Created organization with id: {}", saved.getId());
        
        // Convert back to DTO
        return mapper.toDto(saved);
    }
}
```

**Service Layer Responsibilities:**
1. **Business Logic**: Domain rules and validation
2. **Transaction Management**: Data consistency
3. **DTO-Entity Conversion**: Using MapStruct mappers
4. **Logging**: Audit trail and debugging
5. **Exception Handling**: Business rule violations

#### Repository Layer - Data Access
```java
@Repository
public class OrganizationRepository {
    
    @Autowired
    private DynamoDbEnhancedClient dynamoDbEnhancedClient;
    
    private DynamoDbTable<Organization> table;
    private DynamoDbIndex<Organization> domainIndex;
    
    @PostConstruct
    public void init() {
        this.table = dynamoDbEnhancedClient.table("organizations", 
            TableSchema.fromBean(Organization.class));
        this.domainIndex = table.index("DomainIndex");
    }
    
    public Organization save(Organization organization) {
        table.putItem(organization);
        return organization;
    }
    
    public Optional<Organization> findById(String id) {
        Key key = Key.builder().partitionValue(id).build();
        Organization organization = table.getItem(key);
        
        if (organization != null && !Boolean.TRUE.equals(organization.getDeleted())) {
            return Optional.of(organization);
        }
        return Optional.empty();
    }
}
```

**Repository Pattern Benefits:**
- **Abstraction**: Hides DynamoDB complexity from service layer
- **Testability**: Easy to mock for unit tests
- **Data Access Logic**: Centralized query logic
- **Soft Delete**: Implements logical deletion

### 3.3: Employee Service - Inter-Service Communication

#### Organization Client - HTTP Communication
```java
@Component
@RequiredArgsConstructor
public class OrganizationClient {
    
    private final WebClient.Builder webClientBuilder;
    
    @Value("${organization.service.url:http://localhost:8081}")
    private String organizationServiceUrl;
    
    public Mono<OrganizationDto> getOrganizationById(String organizationId) {
        log.debug("Fetching organization with id: {}", organizationId);
        
        return webClientBuilder.build()
            .get()
            .uri(organizationServiceUrl + "/api/v1/organizations/{id}", organizationId)
            .retrieve()
            .bodyToMono(OrganizationDto.class)
            .timeout(Duration.ofSeconds(timeoutSeconds))
            .onErrorMap(WebClientResponseException.NotFound.class, 
                ex -> new ServiceCommunicationException("Organization not found"))
            .onErrorMap(Exception.class, 
                ex -> new ServiceCommunicationException("Service communication failed"));
    }
}
```

**Reactive Programming Pattern:**
- **Mono<T>**: Represents 0 or 1 item
- **Non-blocking**: Doesn't block threads
- **Error Handling**: Graceful degradation
- **Timeout**: Prevents hanging requests

#### Employee Service with Reactive Flow
```java
public Mono<EmployeeDto> createEmployee(EmployeeDto dto) {
    // Check if email already exists (synchronous)
    if (repository.existsByEmail(dto.getEmail())) {
        return Mono.error(new ValidationException("Email already exists"));
    }
    
    // Verify organization exists (asynchronous)
    return organizationClient.getOrganizationById(dto.getOrganizationId())
        .map(org -> {
            // Create and save employee
            Employee employee = mapper.toEntity(dto);
            employee.setId(IdGenerator.generateId("emp"));
            employee.setCreatedAt(Instant.now());
            
            Employee saved = repository.save(employee);
            
            // Build response with organization details
            EmployeeDto result = mapper.toDto(saved);
            result.setOrganization(org);
            return result;
        });
}
```

**Flow Explanation:**
1. **Synchronous Validation**: Check email uniqueness locally
2. **Asynchronous Call**: Verify organization exists
3. **Reactive Mapping**: Transform response with organization data
4. **Error Propagation**: Any failures bubble up automatically

---

## 4. Application Flow Deep Dive

### 4.1: Complete Request Flow for Employee Creation

```mermaid
sequenceDiagram
    participant Client
    participant EmployeeController
    participant EmployeeService
    participant OrganizationClient
    participant OrganizationService
    participant EmployeeRepository
    participant DynamoDB

    Client->>EmployeeController: POST /api/v1/employees
    Note over EmployeeController: 1. Validate request body
    EmployeeController->>EmployeeService: createEmployee(dto)
    
    Note over EmployeeService: 2. Check email uniqueness
    EmployeeService->>EmployeeRepository: existsByEmail(email)
    EmployeeRepository->>DynamoDB: Scan employees table
    DynamoDB-->>EmployeeRepository: No matching email
    EmployeeRepository-->>EmployeeService: false
    
    Note over EmployeeService: 3. Verify organization exists
    EmployeeService->>OrganizationClient: getOrganizationById(orgId)
    OrganizationClient->>OrganizationService: HTTP GET /organizations/{id}
    OrganizationService-->>OrganizationClient: OrganizationDto
    OrganizationClient-->>EmployeeService: Mono<OrganizationDto>
    
    Note over EmployeeService: 4. Create employee
    EmployeeService->>EmployeeRepository: save(employee)
    EmployeeRepository->>DynamoDB: PutItem
    DynamoDB-->>EmployeeRepository: Success
    EmployeeRepository-->>EmployeeService: Employee
    
    Note over EmployeeService: 5. Build response
    EmployeeService-->>EmployeeController: EmployeeDto with Organization
    EmployeeController-->>Client: HTTP 201 Created
```

### 4.2: Error Handling Flow

```java
// Global Exception Handler
@RestControllerAdvice
public class GlobalExceptionHandler {
    
    @ExceptionHandler(BaseException.class)
    public ResponseEntity<ErrorResponse> handleBaseException(BaseException ex, WebRequest request) {
        ErrorResponse errorResponse = ErrorResponse.builder()
            .timestamp(Instant.now())
            .status(ex.getHttpStatus().value())
            .error(ex.getHttpStatus().getReasonPhrase())
            .message(ex.getMessage())
            .errorCode(ex.getErrorCode())
            .path(request.getDescription(false).replace("uri=", ""))
            .build();
        
        return ResponseEntity.status(ex.getHttpStatus()).body(errorResponse);
    }
    
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ErrorResponse> handleValidationExceptions(MethodArgumentNotValidException ex) {
        List<ValidationError> validationErrors = ex.getBindingResult()
            .getFieldErrors()
            .stream()
            .map(this::mapFieldError)
            .collect(Collectors.toList());
        
        ErrorResponse errorResponse = ErrorResponse.builder()
            .status(HttpStatus.BAD_REQUEST.value())
            .message("Validation failed")
            .validationErrors(validationErrors)
            .build();
        
        return ResponseEntity.badRequest().body(errorResponse);
    }
}
```

**Error Response Structure:**
```json
{
  "timestamp": "2023-12-07T10:30:00.000Z",
  "status": 400,
  "error": "Bad Request",
  "message": "Validation failed",
  "errorCode": "VALIDATION_ERROR",
  "path": "/api/v1/employees",
  "validationErrors": [
    {
      "field": "email",
      "rejectedValue": "invalid-email",
      "message": "Email must be valid"
    }
  ]
}
```

### 4.3: Data Mapping Strategy

#### MapStruct Configuration
```java
@Mapper(componentModel = "spring", nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface OrganizationMapper {
    
    // Entity to DTO
    OrganizationDto toDto(Organization organization);
    
    // DTO to Entity (ignore system fields)
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "createdAt", ignore = true)
    @Mapping(target = "updatedAt", ignore = true)
    @Mapping(target = "deleted", ignore = true)
    Organization toEntity(OrganizationDto dto);
    
    // Update existing entity (ignore system fields)
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "createdAt", ignore = true)
    @Mapping(target = "updatedAt", ignore = true)
    @Mapping(target = "deleted", ignore = true)
    void updateEntity(OrganizationDto dto, @MappingTarget Organization organization);
}
```

**MapStruct Benefits:**
- **Compile-time generation**: No reflection overhead
- **Type safety**: Compile-time error checking
- **Null-safe**: Handles null values gracefully
- **Customizable**: Fine-grained control over mapping

---

## 5. Inter-Service Communication

### 5.1: Communication Patterns

#### Synchronous Communication (HTTP)
```java
// Employee Service calls Organization Service
return organizationClient.getOrganizationById(dto.getOrganizationId())
    .map(org -> {
        // Process with organization data
        EmployeeDto result = mapper.toDto(saved);
        result.setOrganization(org);
        return result;
    })
    .onErrorReturn(mapper.toDto(saved)); // Graceful degradation
```

**When to use:**
- **Real-time data**: Need immediate consistency
- **Small payloads**: Quick request/response
- **Critical dependencies**: Must have data to proceed

#### Graceful Degradation Strategy
```java
public Mono<EmployeeDto> getEmployeeById(String id) {
    Employee employee = repository.findById(id)
        .orElseThrow(() -> new ResourceNotFoundException("Employee", id));
    
    EmployeeDto dto = mapper.toDto(employee);
    
    // Try to fetch organization details, but continue if fails
    return organizationClient.getOrganizationById(employee.getOrganizationId())
        .map(org -> {
            dto.setOrganization(org);  // Success: enrich with org data
            return dto;
        })
        .onErrorReturn(dto);  // Failure: return employee without org data
}
```

**Benefits:**
- **Resilience**: Service continues working if dependencies fail
- **Better UX**: Partial data better than complete failure
- **Faster response**: Don't wait for slow services

### 5.2: Circuit Breaker Pattern (Future Enhancement)

```java
// Example of circuit breaker implementation
@Component
public class OrganizationClientWithCircuitBreaker {
    
    @CircuitBreaker(name = "organization-service", fallbackMethod = "fallbackGetOrganization")
    public Mono<OrganizationDto> getOrganizationById(String id) {
        return organizationClient.getOrganizationById(id);
    }
    
    public Mono<OrganizationDto> fallbackGetOrganization(String id, Exception ex) {
        // Return cached data or minimal organization info
        return Mono.just(OrganizationDto.builder()
            .id(id)
            .name("Organization temporarily unavailable")
            .build());
    }
}
```

---

## 6. Data Layer Implementation

### 6.1: DynamoDB Table Design

#### Organizations Table
```
Table: organizations
Partition Key: id (String)
Global Secondary Index: DomainIndex
  - Partition Key: domain (String)

Sample Item:
{
  "id": "org-123e4567-e89b-12d3-a456-426614174000",
  "name": "Tech Innovations Inc",
  "domain": "techinnovations.com",
  "description": "Leading technology solutions",
  "website": "https://techinnovations.com",
  "createdAt": "2023-12-07T10:30:00.000Z",
  "updatedAt": "2023-12-07T10:30:00.000Z",
  "deleted": false
}
```

#### Employees Table
```
Table: employees
Partition Key: id (String)
Global Secondary Index: OrganizationIndex
  - Partition Key: organizationId (String)

Sample Item:
{
  "id": "emp-456f7890-f12c-34e5-b678-901234567890",
  "firstName": "John",
  "lastName": "Doe",
  "email": "john.doe@techinnovations.com",
  "position": "Senior Software Engineer",
  "organizationId": "org-123e4567-e89b-12d3-a456-426614174000",
  "createdAt": "2023-12-07T11:00:00.000Z",
  "updatedAt": "2023-12-07T11:00:00.000Z",
  "deleted": false
}
```

### 6.2: Query Patterns

#### Single Item Retrieval
```java
public Optional<Organization> findById(String id) {
    Key key = Key.builder().partitionValue(id).build();
    Organization organization = table.getItem(key);
    
    // Check for soft delete
    if (organization != null && !Boolean.TRUE.equals(organization.getDeleted())) {
        return Optional.of(organization);
    }
    return Optional.empty();
}
```

#### GSI Query (Organizations by Domain)
```java
public List<Organization> findByDomain(String domain) {
    QueryConditional queryConditional = QueryConditional.keyEqualTo(
        Key.builder().partitionValue(domain).build()
    );
    
    PageIterable<Organization> results = domainIndex.query(queryConditional);
    
    return results.stream()
        .flatMap(page -> page.items().stream())
        .filter(org -> !Boolean.TRUE.equals(org.getDeleted()))
        .collect(Collectors.toList());
}
```

#### Scan with Filter (All Organizations)
```java
public List<Organization> findAll(int limit, Map<String, AttributeValue> exclusiveStartKey) {
    ScanEnhancedRequest.Builder requestBuilder = ScanEnhancedRequest.builder()
        .limit(limit)
        .filterExpression(Expression.builder()
            .expression("attribute_not_exists(deleted) OR deleted = :deleted")
            .putExpressionValue(":deleted", AttributeValue.builder().bool(false).build())
            .build());
    
    if (exclusiveStartKey != null && !exclusiveStartKey.isEmpty()) {
        requestBuilder.exclusiveStartKey(exclusiveStartKey);
    }
    
    PageIterable<Organization> results = table.scan(requestBuilder.build());
    return results.iterator().next().items();
}
```

### 6.3: Soft Delete Implementation

```java
public void deleteById(String id) {
    Optional<Organization> existingOrg = findById(id);
    if (existingOrg.isPresent()) {
        Organization organization = existingOrg.get();
        organization.setDeleted(true);           // Mark as deleted
        organization.setUpdatedAt(Instant.now()); // Update timestamp
        save(organization);                       // Save changes
    }
}
```

**Benefits of Soft Delete:**
- **Data Recovery**: Can restore accidentally deleted records
- **Audit Trail**: Maintain history of deletions
- **Referential Integrity**: Dependent records remain valid
- **Analytics**: Include deleted records in historical analysis

---

## 7. Testing Strategy

### 7.1: Testing Pyramid

```
                    /\
                   /  \
                  / E2E \     ← End-to-End Tests (Few, Slow, High Confidence)
                 /______\
                /        \
               / Integration \  ← Integration Tests (Some, Medium Speed)
              /______________\
             /                \
            /    Unit Tests    \   ← Unit Tests (Many, Fast, Focused)
           /____________________\
```

### 7.2: Unit Testing Examples

#### Service Layer Unit Test
```java
@ExtendWith(MockitoExtension.class)
class OrganizationServiceTest {

    @Mock
    private OrganizationRepository repository;
    
    @Mock
    private OrganizationMapper mapper;
    
    @InjectMocks
    private OrganizationService organizationService;

    @Test
    void createOrganization_Success() {
        // Given
        OrganizationDto inputDto = OrganizationDto.builder()
            .name("Test Corp")
            .domain("test.com")
            .build();
            
        Organization entity = Organization.builder()
            .name("Test Corp")
            .domain("test.com")
            .build();
            
        Organization savedEntity = Organization.builder()
            .id("org-123")
            .name("Test Corp")
            .domain("test.com")
            .createdAt(Instant.now())
            .build();
            
        OrganizationDto expectedResult = OrganizationDto.builder()
            .id("org-123")
            .name("Test Corp")
            .domain("test.com")
            .build();

        // When
        when(repository.existsByDomain("test.com")).thenReturn(false);
        when(mapper.toEntity(inputDto)).thenReturn(entity);
        when(repository.save(any(Organization.class))).thenReturn(savedEntity);
        when(mapper.toDto(savedEntity)).thenReturn(expectedResult);

        OrganizationDto result = organizationService.createOrganization(inputDto);

        // Then
        assertThat(result.getId()).isEqualTo("org-123");
        assertThat(result.getName()).isEqualTo("Test Corp");
        verify(repository).existsByDomain("test.com");
        verify(repository).save(any(Organization.class));
    }

    @Test
    void createOrganization_DomainExists_ThrowsValidationException() {
        // Given
        OrganizationDto inputDto = OrganizationDto.builder()
            .domain("existing.com")
            .build();

        when(repository.existsByDomain("existing.com")).thenReturn(true);

        // When & Then
        assertThatThrownBy(() -> organizationService.createOrganization(inputDto))
            .isInstanceOf(ValidationException.class)
            .hasMessageContaining("Organization with domain 'existing.com' already exists");

        verify(repository).existsByDomain("existing.com");
        verify(repository, never()).save(any());
    }
}
```

### 7.3: Integration Testing with Testcontainers

```java
@SpringBootTest
@Testcontainers
@ActiveProfiles("test")
class OrganizationServiceIntegrationTest {

    @Container
    static LocalStackContainer localstack = new LocalStackContainer(DockerImageName.parse("localstack/localstack:3.0"))
        .withServices(DYNAMODB);

    @DynamicPropertySource
    static void configureProperties(DynamicPropertyRegistry registry) {
        registry.add("aws.dynamodb.endpoint", localstack::getEndpoint);
    }

    @Test
    void createAndRetrieveOrganization_Success() {
        // Given
        OrganizationDto createDto = OrganizationDto.builder()
            .name("Integration Test Corp")
            .domain("integration.com")
            .build();

        // When - Create
        String response = mockMvc.perform(post("/api/v1/organizations")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(createDto)))
            .andExpect(status().isCreated())
            .andReturn()
            .getResponse()
            .getContentAsString();

        OrganizationDto createdOrg = objectMapper.readValue(response, OrganizationDto.class);

        // Then - Retrieve
        mockMvc.perform(get("/api/v1/organizations/" + createdOrg.getId()))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.name").value("Integration Test Corp"))
            .andExpect(jsonPath("$.domain").value("integration.com"));
    }
}
```

### 7.4: Contract Testing with REST Assured

```java
class EmployeeOrganizationContractTest {

    @Test
    void completeWorkflow_CreateOrganizationAndEmployee_Success() {
        // Create organization
        String organizationId = given()
            .contentType(ContentType.JSON)
            .body(organizationDto)
        .when()
            .post(organizationServiceUrl + "/api/v1/organizations")
        .then()
            .statusCode(201)
            .body("name", equalTo("Tech Corp"))
            .extract()
            .path("id");

        // Create employee
        String employeeId = given()
            .contentType(ContentType.JSON)
            .body(employeeDto.toBuilder().organizationId(organizationId).build())
        .when()
            .post("/api/v1/employees")
        .then()
            .statusCode(201)
            .body("organization.name", equalTo("Tech Corp"))
            .extract()
            .path("id");

        // Verify employee includes organization details
        given()
        .when()
            .get("/api/v1/employees/{id}", employeeId)
        .then()
            .statusCode(200)
            .body("organization.id", equalTo(organizationId));
    }
}
```

---

## 8. Developer Testing Guide

### 8.1: Local Development Setup

#### Step 1: Environment Preparation
```bash
# 1. Clone repository
git clone <repository-url>
cd microservices-platform

# 2. Build project
mvn clean compile package -DskipTests

# 3. Start infrastructure
docker-compose up -d localstack
```

#### Step 2: Create DynamoDB Tables
```bash
# Organizations table
aws dynamodb create-table \
  --endpoint-url http://localhost:4566 \
  --table-name organizations \
  --attribute-definitions \
    AttributeName=id,AttributeType=S \
    AttributeName=domain,AttributeType=S \
  --key-schema AttributeName=id,KeyType=HASH \
  --global-secondary-indexes \
    IndexName=DomainIndex,KeySchema=[{AttributeName=domain,KeyType=HASH}],Projection={ProjectionType=ALL} \
  --billing-mode PAY_PER_REQUEST

# Employees table
aws dynamodb create-table \
  --endpoint-url http://localhost:4566 \
  --table-name employees \
  --attribute-definitions \
    AttributeName=id,AttributeType=S \
    AttributeName=organizationId,AttributeType=S \
  --key-schema AttributeName=id,KeyType=HASH \
  --global-secondary-indexes \
    IndexName=OrganizationIndex,KeySchema=[{AttributeName=organizationId,KeyType=HASH}],Projection={ProjectionType=ALL} \
  --billing-mode PAY_PER_REQUEST
```

#### Step 3: Start Services
```bash
# Terminal 1 - Organization Service
cd organization-service
mvn spring-boot:run -Dspring-boot.run.profiles=local

# Terminal 2 - Employee Service
cd employee-service
export ORGANIZATION_SERVICE_URL=http://localhost:8081
mvn spring-boot:run -Dspring-boot.run.profiles=local
```

### 8.2: API Testing Scenarios

#### Scenario 1: Basic CRUD Operations
```bash
# 1. Create Organization
curl -X POST http://localhost:8081/api/v1/organizations \
  -H "Content-Type: application/json" \
  -d '{
    "name": "TechStart Inc",
    "domain": "techstart.com",
    "description": "A innovative startup",
    "website": "https://techstart.com"
  }'

# Expected Response (save the ID):
{
  "id": "org-550e8400-e29b-41d4-a716-446655440000",
  "name": "TechStart Inc",
  "domain": "techstart.com",
  "description": "A innovative startup",
  "website": "https://techstart.com",
  "createdAt": "2023-12-07T10:30:00.000Z",
  "updatedAt": "2023-12-07T10:30:00.000Z",
  "deleted": false
}
```

```bash
# 2. Create Employee (use organization ID from above)
curl -X POST http://localhost:8080/api/v1/employees \
  -H "Content-Type: application/json" \
  -d '{
    "firstName": "Alice",
    "lastName": "Johnson",
    "email": "alice.johnson@techstart.com",
    "position": "Software Engineer",
    "organizationId": "org-550e8400-e29b-41d4-a716-446655440000"
  }'

# Expected Response:
{
  "id": "emp-123e4567-e89b-12d3-a456-426614174000",
  "firstName": "Alice",
  "lastName": "Johnson",
  "email": "alice.johnson@techstart.com",
  "position": "Software Engineer",
  "organizationId": "org-550e8400-e29b-41d4-a716-446655440000",
  "organization": {
    "id": "org-550e8400-e29b-41d4-a716-446655440000",
    "name": "TechStart Inc",
    "domain": "techstart.com"
  },
  "createdAt": "2023-12-07T11:00:00.000Z",
  "updatedAt": "2023-12-07T11:00:00.000Z",
  "deleted": false
}
```

```bash
# 3. Get Employee (includes organization details)
curl http://localhost:8080/api/v1/employees/emp-123e4567-e89b-12d3-a456-426614174000

# 4. Get Employees by Organization
curl http://localhost:8080/api/v1/employees/organization/org-550e8400-e29b-41d4-a716-446655440000

# 5. Update Employee
curl -X PUT http://localhost:8080/api/v1/employees/emp-123e4567-e89b-12d3-a456-426614174000 \
  -H "Content-Type: application/json" \
  -d '{
    "firstName": "Alice",
    "lastName": "Johnson-Smith",
    "email": "alice.johnson@techstart.com",
    "position": "Senior Software Engineer",
    "organizationId": "org-550e8400-e29b-41d4-a716-446655440000"
  }'
```

#### Scenario 2: Error Handling Testing
```bash
# 1. Test validation errors
curl -X POST http://localhost:8081/api/v1/organizations \
  -H "Content-Type: application/json" \
  -d '{
    "name": "",
    "domain": "invalid-domain"
  }'

# Expected Response:
{
  "timestamp": "2023-12-07T10:30:00.000Z",
  "status": 400,
  "error": "Bad Request",
  "message": "Validation failed",
  "errorCode": "VALIDATION_ERROR",
  "path": "/api/v1/organizations",
  "validationErrors": [
    {
      "field": "name",
      "rejectedValue": "",
      "message": "Name is required"
    }
  ]
}
```

```bash
# 2. Test duplicate domain
curl -X POST http://localhost:8081/api/v1/organizations \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Another Company",
    "domain": "techstart.com"
  }'

# Expected Response:
{
  "timestamp": "2023-12-07T10:30:00.000Z",
  "status": 400,
  "error": "Bad Request",
  "message": "Organization with domain 'techstart.com' already exists",
  "errorCode": "VALIDATION_ERROR",
  "path": "/api/v1/organizations"
}
```

```bash
# 3. Test resource not found
curl http://localhost:8081/api/v1/organizations/non-existent-id

# Expected Response:
{
  "timestamp": "2023-12-07T10:30:00.000Z",
  "status": 404,
  "error": "Not Found",
  "message": "Organization with id 'non-existent-id' not found",
  "errorCode": "RESOURCE_NOT_FOUND",
  "path": "/api/v1/organizations/non-existent-id"
}
```

#### Scenario 3: Service Communication Testing
```bash
# 1. Test employee creation with invalid organization
curl -X POST http://localhost:8080/api/v1/employees \
  -H "Content-Type: application/json" \
  -d '{
    "firstName": "Bob",
    "lastName": "Wilson",
    "email": "bob@nowhere.com",
    "organizationId": "non-existent-org"
  }'

# Expected Response:
{
  "status": 503,
  "error": "Service Unavailable",
  "message": "Organization with id 'non-existent-org' not found",
  "errorCode": "SERVICE_COMMUNICATION_ERROR"
}
```

### 8.3: Database Verification

#### Using DynamoDB Admin UI
1. **Access**: http://localhost:8001
2. **Browse Tables**: Click on `organizations` or `employees`
3. **View Items**: See created records
4. **Verify Data**: Check if API calls created correct records

#### Using AWS CLI
```bash
# List all organizations
aws dynamodb scan \
  --endpoint-url http://localhost:4566 \
  --table-name organizations

# Get specific organization
aws dynamodb get-item \
  --endpoint-url http://localhost:4566 \
  --table-name organizations \
  --key '{"id":{"S":"org-550e8400-e29b-41d4-a716-446655440000"}}'

# Query employees by organization
aws dynamodb query \
  --endpoint-url http://localhost:4566 \
  --table-name employees \
  --index-name OrganizationIndex \
  --key-condition-expression "organizationId = :orgId" \
  --expression-attribute-values '{
    ":orgId": {"S": "org-550e8400-e29b-41d4-a716-446655440000"}
  }'
```

### 8.4: Performance Testing

#### Load Testing with Apache Bench
```bash
# Install Apache Bench
# Ubuntu: sudo apt-get install apache2-utils
# macOS: brew install httpie

# Create test data file
echo '{
  "name": "Load Test Corp",
  "domain": "loadtest.com"
}' > org-create.json

# Run load test
ab -n 100 -c 10 -p org-create.json -T application/json \
  http://localhost:8081/api/v1/organizations
```

#### Response Time Verification
```bash
# Test response times
for i in {1..10}; do
  time curl -s http://localhost:8081/api/v1/organizations/org-550e8400-e29b-41d4-a716-446655440000 > /dev/null
done
```

### 8.5: Monitoring During Testing

#### Application Metrics
- **Access Prometheus**: http://localhost:9090
- **Key Queries**:
  ```
  # Request rate
  rate(http_requests_total[5m])
  
  # Response time 95th percentile
  histogram_quantile(0.95, rate(http_request_duration_seconds_bucket[5m]))
  
  # Error rate
  rate(http_requests_total{status=~"5.."}[5m])
  ```

#### Application Logs
```bash
# View real-time logs
docker-compose logs -f organization-service
docker-compose logs -f employee-service

# Filter for specific log levels
docker-compose logs organization-service | grep ERROR
docker-compose logs employee-service | grep WARN
```

#### Grafana Dashboards
- **Access Grafana**: http://localhost:3000 (admin/admin)
- **Pre-configured dashboards**:
  - JVM metrics (memory, GC, threads)
  - HTTP request metrics (rate, duration, errors)
  - Business metrics (organizations created, employees created)

---

## 9. Deployment & DevOps

### 9.1: Docker Deployment

#### Build Images
```bash
# Build organization service
docker build -t organization-service:latest -f organization-service/Dockerfile .

# Build employee service
docker build -t employee-service:latest -f employee-service/Dockerfile .

# Verify images
docker images | grep -E "(organization|employee)-service"
```

#### Run with Docker Compose
```bash
# Full stack deployment
docker-compose up -d

# Verify all services are healthy
docker-compose ps

# Check service health
curl http://localhost:8081/actuator/health
curl http://localhost:8080/actuator/health
```

### 9.2: AWS Lambda Deployment

#### SAM Build and Deploy
```bash
# Navigate to infra directory
cd infra

# Build Lambda packages
sam build --config-env dev

# Deploy to AWS
sam deploy --config-env dev --guided

# Test deployed endpoints
API_URL=$(aws cloudformation describe-stacks \
  --stack-name microservices-dev-stack \
  --query 'Stacks[0].Outputs[?OutputKey==`ApiGatewayUrl`].OutputValue' \
  --output text)

curl $API_URL/organizations/health
```

### 9.3: Kubernetes Deployment

#### Deploy to Development
```bash
# Apply development configuration
kubectl apply -k k8s/overlays/dev

# Verify deployments
kubectl get pods -n microservices-dev
kubectl get services -n microservices-dev

# Check deployment status
kubectl rollout status deployment/dev-organization-service -n microservices-dev
kubectl rollout status deployment/dev-employee-service -n microservices-dev
```

#### Port Forward for Testing
```bash
# Forward organization service
kubectl port-forward -n microservices-dev svc/dev-organization-service 8081:8081 &

# Forward employee service
kubectl port-forward -n microservices-dev svc/dev-employee-service 8080:8080 &

# Test services
curl http://localhost:8081/actuator/health
curl http://localhost:8080/actuator/health
```

---

## 10. Performance & Monitoring

### 10.1: Key Performance Indicators

#### Response Time Targets
- **GET requests**: < 100ms (95th percentile)
- **POST/PUT requests**: < 200ms (95th percentile)
- **Inter-service calls**: < 50ms (95th percentile)

#### Throughput Targets
- **Organization Service**: 1000 requests/second
- **Employee Service**: 2000 requests/second
- **Database operations**: < 10ms (99th percentile)

#### Error Rate Targets
- **HTTP 5xx errors**: < 0.1%
- **HTTP 4xx errors**: < 1%
- **Service communication failures**: < 0.5%

### 10.2: Monitoring Setup

#### Custom Metrics
```java
@Component
public class BusinessMetrics {
    
    private final Counter organizationsCreated = Counter.builder("organizations_created_total")
        .description("Total number of organizations created")
        .register(Metrics.globalRegistry);
    
    private final Timer organizationCreationTime = Timer.builder("organization_creation_duration")
        .description("Time taken to create an organization")
        .register(Metrics.globalRegistry);
    
    public void recordOrganizationCreated() {
        organizationsCreated.increment();
    }
    
    public Timer.Sample startOrganizationCreationTimer() {
        return Timer.start(Metrics.globalRegistry);
    }
}
```

#### Health Checks
```java
@Component
public class DynamoDbHealthIndicator implements HealthIndicator {
    
    private final DynamoDbClient dynamoDbClient;
    
    @Override
    public Health health() {
        try {
            dynamoDbClient.listTables();
            return Health.up()
                .withDetail("database", "DynamoDB")
                .withDetail("status", "Connected")
                .build();
        } catch (Exception e) {
            return Health.down()
                .withDetail("database", "DynamoDB")
                .withDetail("error", e.getMessage())
                .build();
        }
    }
}
```

### 10.3: Alerting Rules

#### Prometheus Alert Rules
```yaml
groups:
  - name: microservices-alerts
    rules:
      - alert: HighErrorRate
        expr: rate(http_requests_total{status=~"5.."}[5m]) > 0.05
        for: 2m
        labels:
          severity: critical
        annotations:
          summary: "High error rate detected"
          description: "Error rate is {{ $value }} for service {{ $labels.service }}"
      
      - alert: HighResponseTime
        expr: histogram_quantile(0.95, rate(http_request_duration_seconds_bucket[5m])) > 0.2
        for: 5m
        labels:
          severity: warning
        annotations:
          summary: "High response time detected"
          description: "95th percentile response time is {{ $value }}s"
      
      - alert: ServiceDown
        expr: up == 0
        for: 1m
        labels:
          severity: critical
        annotations:
          summary: "Service is down"
          description: "Service {{ $labels.instance }} is down"
```

---

## 🎯 Summary

This comprehensive code walkthrough covers:

### ✅ **Project Creation Process**
- Multi-module Maven setup
- Dependency management strategy
- Architecture decisions and rationale

### ✅ **Code Structure & Flow**
- Layer-by-layer analysis
- Request/response flow
- Error handling patterns
- Data mapping strategies

### ✅ **Testing Comprehensive Guide**
- Unit testing with Mockito
- Integration testing with Testcontainers
- Contract testing with REST Assured
- Performance testing approaches

### ✅ **Developer Testing Procedures**
- Local environment setup
- API testing scenarios
- Database verification methods
- Monitoring and debugging

### ✅ **Deployment & Operations**
- Docker containerization
- AWS Lambda serverless deployment
- Kubernetes orchestration
- Performance monitoring

This guide enables developers to:
- **Understand the codebase** thoroughly
- **Test effectively** at all levels
- **Deploy confidently** to different environments
- **Monitor proactively** for issues
- **Maintain and extend** the system

Each section includes practical examples, code snippets, and step-by-step instructions that developers can follow to work with this microservices platform successfully.

---

**Next Steps for Developers:**
1. Follow the testing guide to verify the system works
2. Implement the practice exercises in the learning guide
3. Contribute improvements using the established patterns
4. Monitor the system using the provided tools and metrics

**Happy Coding! 🚀**
