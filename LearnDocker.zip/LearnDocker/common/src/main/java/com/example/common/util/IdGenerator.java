package com.example.common.util;

import java.util.UUID;

public class IdGenerator {
    
    private IdGenerator() {
        // Utility class
    }
    
    public static String generateId() {
        return UUID.randomUUID().toString();
    }
    
    public static String generateId(String prefix) {
        return prefix + "-" + generateId();
    }
}
