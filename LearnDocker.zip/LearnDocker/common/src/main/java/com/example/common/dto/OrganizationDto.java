package com.example.common.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.SuperBuilder;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@Data
@SuperBuilder
@EqualsAndHashCode(callSuper = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class OrganizationDto extends BaseDto {
    
    @NotBlank(message = "Name is required")
    @Size(min = 1, max = 255, message = "Name must be between 1 and 255 characters")
    private String name;
    
    @Size(max = 1000, message = "Description must not exceed 1000 characters")
    private String description;
    
    @NotBlank(message = "Domain is required")
    @Size(min = 1, max = 255, message = "Domain must be between 1 and 255 characters")
    private String domain;
    
    @Size(max = 255, message = "Website must not exceed 255 characters")
    private String website;
    
    public OrganizationDto() {
        super();
    }
}
