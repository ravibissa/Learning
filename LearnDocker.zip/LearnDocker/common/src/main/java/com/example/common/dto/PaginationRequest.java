package com.example.common.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PaginationRequest {
    
    @Min(value = 0, message = "Page must be greater than or equal to 0")
    @Builder.Default
    private Integer page = 0;
    
    @Min(value = 1, message = "Size must be greater than 0")
    @Max(value = 100, message = "Size must not exceed 100")
    @Builder.Default
    private Integer size = 20;
    
    private String sortBy;
    
    @Builder.Default
    private String sortDirection = "ASC";
}
