package com.example.common.util;

import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;

public class DateTimeUtil {
    
    private static final DateTimeFormatter ISO_FORMATTER = 
        DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").withZone(ZoneOffset.UTC);
    
    private DateTimeUtil() {
        // Utility class
    }
    
    public static Instant now() {
        return Instant.now();
    }
    
    public static String formatToIso(Instant instant) {
        if (instant == null) {
            return null;
        }
        return ISO_FORMATTER.format(instant);
    }
    
    public static Instant parseFromIso(String isoString) {
        if (isoString == null || isoString.trim().isEmpty()) {
            return null;
        }
        return Instant.from(ISO_FORMATTER.parse(isoString));
    }
}
