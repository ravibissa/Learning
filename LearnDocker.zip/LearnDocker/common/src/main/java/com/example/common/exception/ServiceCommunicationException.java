package com.example.common.exception;

import org.springframework.http.HttpStatus;

public class ServiceCommunicationException extends BaseException {
    
    private static final String ERROR_CODE = "SERVICE_COMMUNICATION_ERROR";
    
    public ServiceCommunicationException(String message) {
        super(message, HttpStatus.SERVICE_UNAVAILABLE, ERROR_CODE);
    }
    
    public ServiceCommunicationException(String message, Throwable cause) {
        super(message, cause, HttpStatus.SERVICE_UNAVAILABLE, ERROR_CODE);
    }
}
