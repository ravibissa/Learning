package com.example.employee.service;

import com.example.common.dto.EmployeeDto;
import com.example.common.dto.OrganizationDto;
import com.example.common.dto.PaginatedResponse;
import com.example.common.dto.PaginationRequest;
import com.example.common.exception.ResourceNotFoundException;
import com.example.common.exception.ServiceCommunicationException;
import com.example.common.exception.ValidationException;
import com.example.employee.client.OrganizationClient;
import com.example.employee.mapper.EmployeeMapper;
import com.example.employee.model.Employee;
import com.example.employee.repository.EmployeeRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.time.Instant;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class EmployeeServiceTest {

    @Mock
    private EmployeeRepository repository;

    @Mock
    private EmployeeMapper mapper;

    @Mock
    private OrganizationClient organizationClient;

    @InjectMocks
    private EmployeeService employeeService;

    private EmployeeDto testEmployeeDto;
    private Employee testEmployee;
    private OrganizationDto testOrganizationDto;

    @BeforeEach
    void setUp() {
        testOrganizationDto = OrganizationDto.builder()
            .id("org-123")
            .name("Test Organization")
            .domain("test.com")
            .build();

        testEmployeeDto = EmployeeDto.builder()
            .firstName("John")
            .lastName("Doe")
            .email("john.doe@test.com")
            .position("Software Engineer")
            .organizationId("org-123")
            .build();

        testEmployee = Employee.builder()
            .id("emp-123")
            .firstName("John")
            .lastName("Doe")
            .email("john.doe@test.com")
            .position("Software Engineer")
            .organizationId("org-123")
            .createdAt(Instant.now())
            .updatedAt(Instant.now())
            .deleted(false)
            .build();
    }

    @Test
    void createEmployee_Success() {
        // Given
        when(repository.existsByEmail(testEmployeeDto.getEmail())).thenReturn(false);
        when(organizationClient.getOrganizationById("org-123")).thenReturn(Mono.just(testOrganizationDto));
        when(mapper.toEntity(testEmployeeDto)).thenReturn(testEmployee);
        when(repository.save(any(Employee.class))).thenReturn(testEmployee);
        when(mapper.toDto(testEmployee)).thenReturn(testEmployeeDto);

        // When
        Mono<EmployeeDto> result = employeeService.createEmployee(testEmployeeDto);

        // Then
        StepVerifier.create(result)
            .assertNext(dto -> {
                assertThat(dto.getFirstName()).isEqualTo("John");
                assertThat(dto.getLastName()).isEqualTo("Doe");
                assertThat(dto.getEmail()).isEqualTo("john.doe@test.com");
                assertThat(dto.getOrganization()).isNotNull();
                assertThat(dto.getOrganization().getName()).isEqualTo("Test Organization");
            })
            .verifyComplete();

        verify(repository).existsByEmail(testEmployeeDto.getEmail());
        verify(organizationClient).getOrganizationById("org-123");
        verify(repository).save(any(Employee.class));
    }

    @Test
    void createEmployee_EmailAlreadyExists_ThrowsValidationException() {
        // Given
        when(repository.existsByEmail(testEmployeeDto.getEmail())).thenReturn(true);

        // When
        Mono<EmployeeDto> result = employeeService.createEmployee(testEmployeeDto);

        // Then
        StepVerifier.create(result)
            .expectError(ValidationException.class)
            .verify();

        verify(repository).existsByEmail(testEmployeeDto.getEmail());
        verify(organizationClient, never()).getOrganizationById(any());
        verify(repository, never()).save(any());
    }

    @Test
    void createEmployee_OrganizationNotFound_ThrowsServiceCommunicationException() {
        // Given
        when(repository.existsByEmail(testEmployeeDto.getEmail())).thenReturn(false);
        when(organizationClient.getOrganizationById("org-123"))
            .thenReturn(Mono.error(new ServiceCommunicationException("Organization not found")));

        // When
        Mono<EmployeeDto> result = employeeService.createEmployee(testEmployeeDto);

        // Then
        StepVerifier.create(result)
            .expectError(ServiceCommunicationException.class)
            .verify();

        verify(repository).existsByEmail(testEmployeeDto.getEmail());
        verify(organizationClient).getOrganizationById("org-123");
        verify(repository, never()).save(any());
    }

    @Test
    void getEmployeeById_Success() {
        // Given
        String employeeId = "emp-123";
        when(repository.findById(employeeId)).thenReturn(Optional.of(testEmployee));
        when(mapper.toDto(testEmployee)).thenReturn(testEmployeeDto);
        when(organizationClient.getOrganizationById("org-123")).thenReturn(Mono.just(testOrganizationDto));

        // When
        Mono<EmployeeDto> result = employeeService.getEmployeeById(employeeId);

        // Then
        StepVerifier.create(result)
            .assertNext(dto -> {
                assertThat(dto.getFirstName()).isEqualTo("John");
                assertThat(dto.getOrganization()).isNotNull();
                assertThat(dto.getOrganization().getName()).isEqualTo("Test Organization");
            })
            .verifyComplete();

        verify(repository).findById(employeeId);
        verify(organizationClient).getOrganizationById("org-123");
    }

    @Test
    void getEmployeeById_NotFound_ThrowsResourceNotFoundException() {
        // Given
        String employeeId = "non-existent";
        when(repository.findById(employeeId)).thenReturn(Optional.empty());

        // When & Then
        assertThatThrownBy(() -> employeeService.getEmployeeById(employeeId).block())
            .isInstanceOf(ResourceNotFoundException.class)
            .hasMessageContaining("Employee with id 'non-existent' not found");

        verify(repository).findById(employeeId);
        verify(organizationClient, never()).getOrganizationById(any());
    }

    @Test
    void getEmployeeById_OrganizationServiceDown_ReturnsEmployeeWithoutOrganization() {
        // Given
        String employeeId = "emp-123";
        when(repository.findById(employeeId)).thenReturn(Optional.of(testEmployee));
        when(mapper.toDto(testEmployee)).thenReturn(testEmployeeDto);
        when(organizationClient.getOrganizationById("org-123"))
            .thenReturn(Mono.error(new ServiceCommunicationException("Service down")));

        // When
        Mono<EmployeeDto> result = employeeService.getEmployeeById(employeeId);

        // Then
        StepVerifier.create(result)
            .assertNext(dto -> {
                assertThat(dto.getFirstName()).isEqualTo("John");
                assertThat(dto.getOrganization()).isNull(); // Organization service is down
            })
            .verifyComplete();

        verify(repository).findById(employeeId);
        verify(organizationClient).getOrganizationById("org-123");
    }

    @Test
    void getEmployeesByOrganizationId_Success() {
        // Given
        String organizationId = "org-123";
        List<Employee> employees = Arrays.asList(testEmployee);
        when(repository.findByOrganizationId(organizationId)).thenReturn(employees);
        when(mapper.toDto(testEmployee)).thenReturn(testEmployeeDto);
        when(organizationClient.getOrganizationById(organizationId)).thenReturn(Mono.just(testOrganizationDto));

        // When
        Mono<List<EmployeeDto>> result = employeeService.getEmployeesByOrganizationId(organizationId);

        // Then
        StepVerifier.create(result)
            .assertNext(dtos -> {
                assertThat(dtos).hasSize(1);
                assertThat(dtos.get(0).getOrganization()).isNotNull();
                assertThat(dtos.get(0).getOrganization().getName()).isEqualTo("Test Organization");
            })
            .verifyComplete();

        verify(repository).findByOrganizationId(organizationId);
        verify(organizationClient).getOrganizationById(organizationId);
    }

    @Test
    void getAllEmployees_Success() {
        // Given
        PaginationRequest paginationRequest = PaginationRequest.builder()
            .page(0)
            .size(20)
            .build();

        List<Employee> employees = Arrays.asList(testEmployee);
        when(repository.findAll(20, null)).thenReturn(employees);
        when(mapper.toDto(testEmployee)).thenReturn(testEmployeeDto);
        when(organizationClient.getOrganizationById("org-123")).thenReturn(Mono.just(testOrganizationDto));

        // When
        Mono<PaginatedResponse<EmployeeDto>> result = employeeService.getAllEmployees(paginationRequest);

        // Then
        StepVerifier.create(result)
            .assertNext(response -> {
                assertThat(response.getContent()).hasSize(1);
                assertThat(response.getPage()).isEqualTo(0);
                assertThat(response.getSize()).isEqualTo(20);
                assertThat(response.getContent().get(0).getOrganization()).isNotNull();
            })
            .verifyComplete();

        verify(repository).findAll(20, null);
        verify(organizationClient).getOrganizationById("org-123");
    }

    @Test
    void updateEmployee_Success() {
        // Given
        String employeeId = "emp-123";
        EmployeeDto updateDto = EmployeeDto.builder()
            .firstName("Jane")
            .lastName("Smith")
            .email("jane.smith@test.com")
            .organizationId("org-123")
            .build();

        when(repository.findById(employeeId)).thenReturn(Optional.of(testEmployee));
        when(repository.existsByEmail(updateDto.getEmail())).thenReturn(false);
        when(organizationClient.getOrganizationById("org-123")).thenReturn(Mono.just(testOrganizationDto));
        when(repository.save(any(Employee.class))).thenReturn(testEmployee);
        when(mapper.toDto(testEmployee)).thenReturn(updateDto);

        // When
        Mono<EmployeeDto> result = employeeService.updateEmployee(employeeId, updateDto);

        // Then
        StepVerifier.create(result)
            .assertNext(dto -> {
                assertThat(dto.getFirstName()).isEqualTo("Jane");
                assertThat(dto.getOrganization()).isNotNull();
            })
            .verifyComplete();

        verify(repository).findById(employeeId);
        verify(mapper).updateEntity(updateDto, testEmployee);
        verify(repository).save(testEmployee);
    }

    @Test
    void updateEmployee_NotFound_ThrowsResourceNotFoundException() {
        // Given
        String employeeId = "non-existent";
        when(repository.findById(employeeId)).thenReturn(Optional.empty());

        // When & Then
        assertThatThrownBy(() -> employeeService.updateEmployee(employeeId, testEmployeeDto).block())
            .isInstanceOf(ResourceNotFoundException.class)
            .hasMessageContaining("Employee with id 'non-existent' not found");

        verify(repository).findById(employeeId);
        verify(repository, never()).save(any());
    }

    @Test
    void updateEmployee_EmailAlreadyExists_ThrowsValidationException() {
        // Given
        String employeeId = "emp-123";
        EmployeeDto updateDto = EmployeeDto.builder()
            .email("existing@test.com")
            .organizationId("org-123")
            .build();

        when(repository.findById(employeeId)).thenReturn(Optional.of(testEmployee));
        when(repository.existsByEmail(updateDto.getEmail())).thenReturn(true);

        // When
        Mono<EmployeeDto> result = employeeService.updateEmployee(employeeId, updateDto);

        // Then
        StepVerifier.create(result)
            .expectError(ValidationException.class)
            .verify();

        verify(repository).findById(employeeId);
        verify(repository, never()).save(any());
    }

    @Test
    void deleteEmployee_Success() {
        // Given
        String employeeId = "emp-123";
        when(repository.findById(employeeId)).thenReturn(Optional.of(testEmployee));

        // When
        employeeService.deleteEmployee(employeeId);

        // Then
        verify(repository).findById(employeeId);
        verify(repository).deleteById(employeeId);
    }

    @Test
    void deleteEmployee_NotFound_ThrowsResourceNotFoundException() {
        // Given
        String employeeId = "non-existent";
        when(repository.findById(employeeId)).thenReturn(Optional.empty());

        // When & Then
        assertThatThrownBy(() -> employeeService.deleteEmployee(employeeId))
            .isInstanceOf(ResourceNotFoundException.class)
            .hasMessageContaining("Employee with id 'non-existent' not found");

        verify(repository).findById(employeeId);
        verify(repository, never()).deleteById(any());
    }
}
