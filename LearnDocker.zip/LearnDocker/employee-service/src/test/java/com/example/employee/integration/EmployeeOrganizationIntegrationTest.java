package com.example.employee.integration;

import com.example.common.dto.EmployeeDto;
import com.example.common.dto.OrganizationDto;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.testcontainers.containers.GenericContainer;
import org.testcontainers.containers.localstack.LocalStackContainer;
import org.testcontainers.containers.wait.strategy.Wait;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;
import org.testcontainers.utility.DockerImageName;
import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.dynamodb.DynamoDbClient;
import software.amazon.awssdk.services.dynamodb.model.*;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;
import static org.testcontainers.containers.localstack.LocalStackContainer.Service.DYNAMODB;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@Testcontainers
@ActiveProfiles("test")
class EmployeeOrganizationIntegrationTest {

    @Container
    static LocalStackContainer localstack = new LocalStackContainer(DockerImageName.parse("localstack/localstack:3.0"))
        .withServices(DYNAMODB);

    @Container
    static GenericContainer<?> organizationService = new GenericContainer<>("organization-service:test")
        .withExposedPorts(8081)
        .withEnv("SPRING_PROFILES_ACTIVE", "test")
        .withEnv("DYNAMODB_ENDPOINT", "http://localstack:4566")
        .withEnv("AWS_REGION", "us-east-1")
        .withEnv("AWS_ACCESS_KEY_ID", "test")
        .withEnv("AWS_SECRET_ACCESS_KEY", "test")
        .waitingFor(Wait.forHttp("/actuator/health").forPort(8081))
        .dependsOn(localstack);

    @LocalServerPort
    private int port;

    @Autowired
    private ObjectMapper objectMapper;

    private DynamoDbClient dynamoDbClient;
    private String organizationServiceUrl;

    @DynamicPropertySource
    static void configureProperties(DynamicPropertyRegistry registry) {
        registry.add("aws.dynamodb.endpoint", localstack::getEndpoint);
        registry.add("aws.region", () -> localstack.getRegion());
        registry.add("organization.service.url", () -> 
            "http://localhost:" + organizationService.getMappedPort(8081));
    }

    @BeforeEach
    void setUp() {
        RestAssured.port = port;
        organizationServiceUrl = "http://localhost:" + organizationService.getMappedPort(8081);
        
        dynamoDbClient = DynamoDbClient.builder()
            .endpointOverride(localstack.getEndpoint())
            .credentialsProvider(StaticCredentialsProvider.create(
                AwsBasicCredentials.create("test", "test")))
            .region(Region.of(localstack.getRegion()))
            .build();

        createTables();
    }

    private void createTables() {
        createOrganizationsTable();
        createEmployeesTable();
    }

    private void createOrganizationsTable() {
        try {
            CreateTableRequest request = CreateTableRequest.builder()
                .tableName("organizations")
                .keySchema(KeySchemaElement.builder()
                    .attributeName("id")
                    .keyType(KeyType.HASH)
                    .build())
                .attributeDefinitions(
                    AttributeDefinition.builder()
                        .attributeName("id")
                        .attributeType(ScalarAttributeType.S)
                        .build(),
                    AttributeDefinition.builder()
                        .attributeName("domain")
                        .attributeType(ScalarAttributeType.S)
                        .build())
                .globalSecondaryIndexes(GlobalSecondaryIndex.builder()
                    .indexName("DomainIndex")
                    .keySchema(KeySchemaElement.builder()
                        .attributeName("domain")
                        .keyType(KeyType.HASH)
                        .build())
                    .projection(Projection.builder()
                        .projectionType(ProjectionType.ALL)
                        .build())
                    .billingMode(BillingMode.PAY_PER_REQUEST)
                    .build())
                .billingMode(BillingMode.PAY_PER_REQUEST)
                .build();

            dynamoDbClient.createTable(request);
        } catch (ResourceInUseException e) {
            // Table already exists
        }
    }

    private void createEmployeesTable() {
        try {
            CreateTableRequest request = CreateTableRequest.builder()
                .tableName("employees")
                .keySchema(KeySchemaElement.builder()
                    .attributeName("id")
                    .keyType(KeyType.HASH)
                    .build())
                .attributeDefinitions(
                    AttributeDefinition.builder()
                        .attributeName("id")
                        .attributeType(ScalarAttributeType.S)
                        .build(),
                    AttributeDefinition.builder()
                        .attributeName("organizationId")
                        .attributeType(ScalarAttributeType.S)
                        .build())
                .globalSecondaryIndexes(GlobalSecondaryIndex.builder()
                    .indexName("OrganizationIndex")
                    .keySchema(KeySchemaElement.builder()
                        .attributeName("organizationId")
                        .keyType(KeyType.HASH)
                        .build())
                    .projection(Projection.builder()
                        .projectionType(ProjectionType.ALL)
                        .build())
                    .billingMode(BillingMode.PAY_PER_REQUEST)
                    .build())
                .billingMode(BillingMode.PAY_PER_REQUEST)
                .build();

            dynamoDbClient.createTable(request);
        } catch (ResourceInUseException e) {
            // Table already exists
        }
    }

    @Test
    void completeWorkflow_CreateOrganizationAndEmployee_Success() {
        // Step 1: Create organization
        OrganizationDto organizationDto = OrganizationDto.builder()
            .name("Tech Corp")
            .domain("techcorp.com")
            .description("A technology company")
            .website("https://techcorp.com")
            .build();

        String organizationId = given()
            .contentType(ContentType.JSON)
            .body(organizationDto)
        .when()
            .post(organizationServiceUrl + "/api/v1/organizations")
        .then()
            .statusCode(201)
            .body("name", equalTo("Tech Corp"))
            .body("domain", equalTo("techcorp.com"))
            .extract()
            .path("id");

        // Step 2: Create employee for the organization
        EmployeeDto employeeDto = EmployeeDto.builder()
            .firstName("Alice")
            .lastName("Johnson")
            .email("alice.johnson@techcorp.com")
            .position("Senior Developer")
            .organizationId(organizationId)
            .build();

        String employeeId = given()
            .contentType(ContentType.JSON)
            .body(employeeDto)
        .when()
            .post("/api/v1/employees")
        .then()
            .statusCode(201)
            .body("firstName", equalTo("Alice"))
            .body("lastName", equalTo("Johnson"))
            .body("email", equalTo("alice.johnson@techcorp.com"))
            .body("organization.name", equalTo("Tech Corp"))
            .body("organization.domain", equalTo("techcorp.com"))
            .extract()
            .path("id");

        // Step 3: Get employee by ID and verify organization details are populated
        given()
        .when()
            .get("/api/v1/employees/{id}", employeeId)
        .then()
            .statusCode(200)
            .body("id", equalTo(employeeId))
            .body("firstName", equalTo("Alice"))
            .body("organization.id", equalTo(organizationId))
            .body("organization.name", equalTo("Tech Corp"));

        // Step 4: Get employees by organization
        given()
        .when()
            .get("/api/v1/employees/organization/{organizationId}", organizationId)
        .then()
            .statusCode(200)
            .body("size()", equalTo(1))
            .body("[0].firstName", equalTo("Alice"))
            .body("[0].organization.name", equalTo("Tech Corp"));

        // Step 5: Update employee
        EmployeeDto updateDto = EmployeeDto.builder()
            .firstName("Alice")
            .lastName("Johnson-Smith")
            .email("alice.johnson@techcorp.com")
            .position("Lead Developer")
            .organizationId(organizationId)
            .build();

        given()
            .contentType(ContentType.JSON)
            .body(updateDto)
        .when()
            .put("/api/v1/employees/{id}", employeeId)
        .then()
            .statusCode(200)
            .body("lastName", equalTo("Johnson-Smith"))
            .body("position", equalTo("Lead Developer"));

        // Step 6: Delete employee
        given()
        .when()
            .delete("/api/v1/employees/{id}", employeeId)
        .then()
            .statusCode(204);

        // Step 7: Verify employee is deleted
        given()
        .when()
            .get("/api/v1/employees/{id}", employeeId)
        .then()
            .statusCode(404);

        // Step 8: Delete organization
        given()
        .when()
            .delete(organizationServiceUrl + "/api/v1/organizations/{id}", organizationId)
        .then()
            .statusCode(204);
    }

    @Test
    void createEmployee_OrganizationNotFound_Returns400() {
        // Given - Non-existent organization ID
        EmployeeDto employeeDto = EmployeeDto.builder()
            .firstName("Bob")
            .lastName("Wilson")
            .email("bob.wilson@nowhere.com")
            .organizationId("non-existent-org")
            .build();

        // When & Then
        given()
            .contentType(ContentType.JSON)
            .body(employeeDto)
        .when()
            .post("/api/v1/employees")
        .then()
            .statusCode(503) // Service communication error
            .body("message", containsString("Failed to communicate with organization service"));
    }

    @Test
    void createEmployee_DuplicateEmail_Returns400() {
        // Step 1: Create organization
        OrganizationDto organizationDto = OrganizationDto.builder()
            .name("Duplicate Test Corp")
            .domain("duplicate.com")
            .build();

        String organizationId = given()
            .contentType(ContentType.JSON)
            .body(organizationDto)
        .when()
            .post(organizationServiceUrl + "/api/v1/organizations")
        .then()
            .statusCode(201)
            .extract()
            .path("id");

        // Step 2: Create first employee
        EmployeeDto firstEmployee = EmployeeDto.builder()
            .firstName("First")
            .lastName("Employee")
            .email("duplicate@test.com")
            .organizationId(organizationId)
            .build();

        given()
            .contentType(ContentType.JSON)
            .body(firstEmployee)
        .when()
            .post("/api/v1/employees")
        .then()
            .statusCode(201);

        // Step 3: Try to create second employee with same email
        EmployeeDto secondEmployee = EmployeeDto.builder()
            .firstName("Second")
            .lastName("Employee")
            .email("duplicate@test.com")
            .organizationId(organizationId)
            .build();

        given()
            .contentType(ContentType.JSON)
            .body(secondEmployee)
        .when()
            .post("/api/v1/employees")
        .then()
            .statusCode(400)
            .body("message", containsString("Employee with email 'duplicate@test.com' already exists"));
    }

    @Test
    void getAllEmployees_WithPagination_Success() {
        // Step 1: Create organization
        OrganizationDto organizationDto = OrganizationDto.builder()
            .name("Pagination Test Corp")
            .domain("pagination.com")
            .build();

        String organizationId = given()
            .contentType(ContentType.JSON)
            .body(organizationDto)
        .when()
            .post(organizationServiceUrl + "/api/v1/organizations")
        .then()
            .statusCode(201)
            .extract()
            .path("id");

        // Step 2: Create multiple employees
        for (int i = 1; i <= 5; i++) {
            EmployeeDto employee = EmployeeDto.builder()
                .firstName("Employee" + i)
                .lastName("Test")
                .email("employee" + i + "@pagination.com")
                .organizationId(organizationId)
                .build();

            given()
                .contentType(ContentType.JSON)
                .body(employee)
            .when()
                .post("/api/v1/employees")
            .then()
                .statusCode(201);
        }

        // Step 3: Get all employees with pagination
        given()
            .queryParam("page", 0)
            .queryParam("size", 3)
        .when()
            .get("/api/v1/employees")
        .then()
            .statusCode(200)
            .body("content.size()", lessThanOrEqualTo(3))
            .body("page", equalTo(0))
            .body("size", equalTo(3));
    }
}
