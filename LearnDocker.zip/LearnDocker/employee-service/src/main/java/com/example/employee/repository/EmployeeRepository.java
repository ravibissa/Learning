package com.example.employee.repository;

import com.example.employee.model.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbEnhancedClient;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbIndex;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.Key;
import software.amazon.awssdk.enhanced.dynamodb.model.Page;
import software.amazon.awssdk.enhanced.dynamodb.model.PageIterable;
import software.amazon.awssdk.enhanced.dynamodb.model.QueryConditional;
import software.amazon.awssdk.enhanced.dynamodb.model.ScanEnhancedRequest;
import software.amazon.awssdk.services.dynamodb.model.AttributeValue;

import javax.annotation.PostConstruct;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@Repository
public class EmployeeRepository {
    
    @Autowired
    private DynamoDbEnhancedClient dynamoDbEnhancedClient;
    
    private DynamoDbTable<Employee> table;
    private DynamoDbIndex<Employee> organizationIndex;
    
    @PostConstruct
    public void init() {
        this.table = dynamoDbEnhancedClient.table("employees", 
            software.amazon.awssdk.enhanced.dynamodb.TableSchema.fromBean(Employee.class));
        this.organizationIndex = table.index("OrganizationIndex");
    }
    
    public Employee save(Employee employee) {
        table.putItem(employee);
        return employee;
    }
    
    public Optional<Employee> findById(String id) {
        Key key = Key.builder().partitionValue(id).build();
        Employee employee = table.getItem(key);
        
        if (employee != null && !Boolean.TRUE.equals(employee.getDeleted())) {
            return Optional.of(employee);
        }
        return Optional.empty();
    }
    
    public List<Employee> findByOrganizationId(String organizationId) {
        QueryConditional queryConditional = QueryConditional.keyEqualTo(
            Key.builder().partitionValue(organizationId).build()
        );
        
        PageIterable<Employee> results = organizationIndex.query(queryConditional);
        
        return results.stream()
            .flatMap(page -> page.items().stream())
            .filter(emp -> !Boolean.TRUE.equals(emp.getDeleted()))
            .collect(Collectors.toList());
    }
    
    public List<Employee> findAll(int limit, Map<String, AttributeValue> exclusiveStartKey) {
        ScanEnhancedRequest.Builder requestBuilder = ScanEnhancedRequest.builder()
            .limit(limit)
            .filterExpression(software.amazon.awssdk.enhanced.dynamodb.Expression.builder()
                .expression("attribute_not_exists(deleted) OR deleted = :deleted")
                .putExpressionValue(":deleted", AttributeValue.builder().bool(false).build())
                .build());
        
        if (exclusiveStartKey != null && !exclusiveStartKey.isEmpty()) {
            requestBuilder.exclusiveStartKey(exclusiveStartKey);
        }
        
        PageIterable<Employee> results = table.scan(requestBuilder.build());
        Page<Employee> firstPage = results.iterator().next();
        
        return firstPage.items();
    }
    
    public void deleteById(String id) {
        Optional<Employee> existingEmployee = findById(id);
        if (existingEmployee.isPresent()) {
            Employee employee = existingEmployee.get();
            employee.setDeleted(true);
            employee.setUpdatedAt(java.time.Instant.now());
            save(employee);
        }
    }
    
    public boolean existsByEmail(String email) {
        // For simplicity, we'll scan for email - in production, consider adding a GSI
        ScanEnhancedRequest request = ScanEnhancedRequest.builder()
            .filterExpression(software.amazon.awssdk.enhanced.dynamodb.Expression.builder()
                .expression("email = :email AND (attribute_not_exists(deleted) OR deleted = :deleted)")
                .putExpressionValue(":email", AttributeValue.builder().s(email).build())
                .putExpressionValue(":deleted", AttributeValue.builder().bool(false).build())
                .build())
            .limit(1)
            .build();
        
        PageIterable<Employee> results = table.scan(request);
        return results.stream().flatMap(page -> page.items().stream()).findFirst().isPresent();
    }
}
