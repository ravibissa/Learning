package com.example.employee.client;

import com.example.common.dto.OrganizationDto;
import com.example.common.exception.ServiceCommunicationException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;

import java.time.Duration;

@Slf4j
@Component
@RequiredArgsConstructor
public class OrganizationClient {
    
    private final WebClient.Builder webClientBuilder;
    
    @Value("${organization.service.url:http://localhost:8081}")
    private String organizationServiceUrl;
    
    @Value("${organization.service.timeout:5}")
    private int timeoutSeconds;
    
    public Mono<OrganizationDto> getOrganizationById(String organizationId) {
        log.debug("Fetching organization with id: {}", organizationId);
        
        return webClientBuilder.build()
            .get()
            .uri(organizationServiceUrl + "/api/v1/organizations/{id}", organizationId)
            .retrieve()
            .bodyToMono(OrganizationDto.class)
            .timeout(Duration.ofSeconds(timeoutSeconds))
            .doOnSuccess(org -> log.debug("Successfully fetched organization: {}", org.getName()))
            .doOnError(error -> log.error("Failed to fetch organization with id {}: {}", organizationId, error.getMessage()))
            .onErrorMap(WebClientResponseException.NotFound.class, 
                ex -> new ServiceCommunicationException("Organization with id '" + organizationId + "' not found"))
            .onErrorMap(Exception.class, 
                ex -> new ServiceCommunicationException("Failed to communicate with organization service: " + ex.getMessage(), ex));
    }
}
