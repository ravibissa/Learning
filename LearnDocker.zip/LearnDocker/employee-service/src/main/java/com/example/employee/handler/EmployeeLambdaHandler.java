package com.example.employee.handler;

import com.example.employee.EmployeeServiceApplication;
import org.springframework.cloud.function.adapter.aws.SpringBootRequestHandler;

public class EmployeeLambdaHandler extends SpringBootRequestHandler<Object, Object> {
    
    public EmployeeLambdaHandler() {
        super(EmployeeServiceApplication.class);
    }
}
