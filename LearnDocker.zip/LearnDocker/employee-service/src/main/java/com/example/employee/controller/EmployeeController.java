package com.example.employee.controller;

import com.example.common.dto.EmployeeDto;
import com.example.common.dto.PaginatedResponse;
import com.example.common.dto.PaginationRequest;
import com.example.employee.service.EmployeeService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import java.util.List;

@Slf4j
@RestController
@RequestMapping("/api/v1/employees")
@RequiredArgsConstructor
@Validated
public class EmployeeController {
    
    private final EmployeeService employeeService;
    
    @PostMapping
    public Mono<ResponseEntity<EmployeeDto>> createEmployee(@Valid @RequestBody EmployeeDto dto) {
        log.info("POST /api/v1/employees - Creating employee");
        return employeeService.createEmployee(dto)
            .map(created -> ResponseEntity.status(HttpStatus.CREATED).body(created));
    }
    
    @GetMapping("/{id}")
    public Mono<ResponseEntity<EmployeeDto>> getEmployee(@PathVariable @NotBlank String id) {
        log.info("GET /api/v1/employees/{} - Fetching employee", id);
        return employeeService.getEmployeeById(id)
            .map(ResponseEntity::ok);
    }
    
    @GetMapping
    public Mono<ResponseEntity<PaginatedResponse<EmployeeDto>>> getAllEmployees(
            @RequestParam(defaultValue = "0") Integer page,
            @RequestParam(defaultValue = "20") Integer size,
            @RequestParam(required = false) String sortBy,
            @RequestParam(defaultValue = "ASC") String sortDirection) {
        
        log.info("GET /api/v1/employees - Fetching all employees");
        
        PaginationRequest paginationRequest = PaginationRequest.builder()
            .page(page)
            .size(size)
            .sortBy(sortBy)
            .sortDirection(sortDirection)
            .build();
        
        return employeeService.getAllEmployees(paginationRequest)
            .map(ResponseEntity::ok);
    }
    
    @GetMapping("/organization/{organizationId}")
    public Mono<ResponseEntity<List<EmployeeDto>>> getEmployeesByOrganization(@PathVariable @NotBlank String organizationId) {
        log.info("GET /api/v1/employees/organization/{} - Fetching employees by organization", organizationId);
        return employeeService.getEmployeesByOrganizationId(organizationId)
            .map(ResponseEntity::ok);
    }
    
    @PutMapping("/{id}")
    public Mono<ResponseEntity<EmployeeDto>> updateEmployee(
            @PathVariable @NotBlank String id,
            @Valid @RequestBody EmployeeDto dto) {
        log.info("PUT /api/v1/employees/{} - Updating employee", id);
        return employeeService.updateEmployee(id, dto)
            .map(ResponseEntity::ok);
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteEmployee(@PathVariable @NotBlank String id) {
        log.info("DELETE /api/v1/employees/{} - Deleting employee", id);
        employeeService.deleteEmployee(id);
        return ResponseEntity.noContent().build();
    }
}
