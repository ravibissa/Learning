package com.example.employee.service;

import com.example.common.dto.EmployeeDto;
import com.example.common.dto.OrganizationDto;
import com.example.common.dto.PaginatedResponse;
import com.example.common.dto.PaginationRequest;
import com.example.common.exception.ResourceNotFoundException;
import com.example.common.exception.ValidationException;
import com.example.common.util.IdGenerator;
import com.example.employee.client.OrganizationClient;
import com.example.employee.mapper.EmployeeMapper;
import com.example.employee.model.Employee;
import com.example.employee.repository.EmployeeRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.Instant;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class EmployeeService {
    
    private final EmployeeRepository repository;
    private final EmployeeMapper mapper;
    private final OrganizationClient organizationClient;
    
    public Mono<EmployeeDto> createEmployee(EmployeeDto dto) {
        log.info("Creating employee with email: {}", dto.getEmail());
        
        // Check if email already exists
        if (repository.existsByEmail(dto.getEmail())) {
            return Mono.error(new ValidationException("Employee with email '" + dto.getEmail() + "' already exists"));
        }
        
        // Verify organization exists
        return organizationClient.getOrganizationById(dto.getOrganizationId())
            .map(org -> {
                Employee employee = mapper.toEntity(dto);
                employee.setId(IdGenerator.generateId("emp"));
                employee.setCreatedAt(Instant.now());
                employee.setUpdatedAt(Instant.now());
                employee.setDeleted(false);
                
                Employee saved = repository.save(employee);
                log.info("Created employee with id: {}", saved.getId());
                
                EmployeeDto result = mapper.toDto(saved);
                result.setOrganization(org);
                return result;
            });
    }
    
    public Mono<EmployeeDto> getEmployeeById(String id) {
        log.info("Fetching employee by id: {}", id);
        
        Employee employee = repository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Employee", id));
        
        EmployeeDto dto = mapper.toDto(employee);
        
        // Fetch organization details
        return organizationClient.getOrganizationById(employee.getOrganizationId())
            .map(org -> {
                dto.setOrganization(org);
                return dto;
            })
            .onErrorReturn(dto); // Return without organization if service is down
    }
    
    public Mono<List<EmployeeDto>> getEmployeesByOrganizationId(String organizationId) {
        log.info("Fetching employees by organization id: {}", organizationId);
        
        List<Employee> employees = repository.findByOrganizationId(organizationId);
        List<EmployeeDto> dtos = employees.stream()
            .map(mapper::toDto)
            .collect(Collectors.toList());
        
        // Fetch organization details for all employees
        return organizationClient.getOrganizationById(organizationId)
            .map(org -> {
                dtos.forEach(dto -> dto.setOrganization(org));
                return dtos;
            })
            .onErrorReturn(dtos); // Return without organization if service is down
    }
    
    public Mono<PaginatedResponse<EmployeeDto>> getAllEmployees(PaginationRequest paginationRequest) {
        log.info("Fetching all employees with pagination: {}", paginationRequest);
        
        // For simplicity, using basic pagination with DynamoDB scan
        List<Employee> employees = repository.findAll(paginationRequest.getSize(), null);
        
        List<EmployeeDto> dtos = employees.stream()
            .map(mapper::toDto)
            .collect(Collectors.toList());
        
        // Fetch organization details for all employees
        return Flux.fromIterable(dtos)
            .flatMap(dto -> organizationClient.getOrganizationById(dto.getOrganizationId())
                .map(org -> {
                    dto.setOrganization(org);
                    return dto;
                })
                .onErrorReturn(dto)) // Continue if organization service is down
            .collectList()
            .map(enrichedDtos -> PaginatedResponse.<EmployeeDto>builder()
                .content(enrichedDtos)
                .page(paginationRequest.getPage())
                .size(paginationRequest.getSize())
                .totalElements((long) enrichedDtos.size())
                .totalPages(1) // Simplified for this example
                .first(true)
                .last(true)
                .hasNext(false)
                .hasPrevious(false)
                .build());
    }
    
    public Mono<EmployeeDto> updateEmployee(String id, EmployeeDto dto) {
        log.info("Updating employee with id: {}", id);
        
        Employee existingEmployee = repository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Employee", id));
        
        // Check if email is being changed and if new email already exists
        if (!existingEmployee.getEmail().equals(dto.getEmail()) && 
            repository.existsByEmail(dto.getEmail())) {
            return Mono.error(new ValidationException("Employee with email '" + dto.getEmail() + "' already exists"));
        }
        
        // If organization is being changed, verify new organization exists
        Mono<OrganizationDto> orgMono;
        if (!existingEmployee.getOrganizationId().equals(dto.getOrganizationId())) {
            orgMono = organizationClient.getOrganizationById(dto.getOrganizationId());
        } else {
            orgMono = organizationClient.getOrganizationById(existingEmployee.getOrganizationId())
                .onErrorReturn(null); // Allow update even if org service is down
        }
        
        return orgMono.map(org -> {
            mapper.updateEntity(dto, existingEmployee);
            existingEmployee.setUpdatedAt(Instant.now());
            
            Employee updated = repository.save(existingEmployee);
            log.info("Updated employee with id: {}", updated.getId());
            
            EmployeeDto result = mapper.toDto(updated);
            if (org != null) {
                result.setOrganization(org);
            }
            return result;
        });
    }
    
    public void deleteEmployee(String id) {
        log.info("Deleting employee with id: {}", id);
        
        repository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Employee", id));
        
        repository.deleteById(id);
        log.info("Deleted employee with id: {}", id);
    }
}
