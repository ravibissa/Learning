package com.example.employee.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.*;

import java.time.Instant;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@DynamoDbBean
public class Employee {
    
    @DynamoDbPartitionKey
    private String id;
    
    private String firstName;
    private String lastName;
    private String email;
    private String position;
    
    @DynamoDbSecondaryPartitionKey(indexNames = "OrganizationIndex")
    private String organizationId;
    
    private Instant createdAt;
    private Instant updatedAt;
    
    @Builder.Default
    private Boolean deleted = false;
}
