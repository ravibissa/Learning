package com.example.organization.integration;

import com.example.common.dto.OrganizationDto;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureWebMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
import org.testcontainers.containers.localstack.LocalStackContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;
import org.testcontainers.utility.DockerImageName;
import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.dynamodb.DynamoDbClient;
import software.amazon.awssdk.services.dynamodb.model.*;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.testcontainers.containers.localstack.LocalStackContainer.Service.DYNAMODB;

@SpringBootTest
@AutoConfigureWebMvc
@Testcontainers
@ActiveProfiles("test")
class OrganizationServiceIntegrationTest {

    @Container
    static LocalStackContainer localstack = new LocalStackContainer(DockerImageName.parse("localstack/localstack:3.0"))
        .withServices(DYNAMODB);

    @Autowired
    private WebApplicationContext webApplicationContext;

    @Autowired
    private ObjectMapper objectMapper;

    private MockMvc mockMvc;
    private DynamoDbClient dynamoDbClient;

    @DynamicPropertySource
    static void configureProperties(DynamicPropertyRegistry registry) {
        registry.add("aws.dynamodb.endpoint", localstack::getEndpoint);
        registry.add("aws.region", () -> localstack.getRegion());
    }

    @BeforeEach
    void setUp() {
        mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
        
        dynamoDbClient = DynamoDbClient.builder()
            .endpointOverride(localstack.getEndpoint())
            .credentialsProvider(StaticCredentialsProvider.create(
                AwsBasicCredentials.create("test", "test")))
            .region(Region.of(localstack.getRegion()))
            .build();

        createTable();
    }

    private void createTable() {
        try {
            CreateTableRequest request = CreateTableRequest.builder()
                .tableName("organizations")
                .keySchema(KeySchemaElement.builder()
                    .attributeName("id")
                    .keyType(KeyType.HASH)
                    .build())
                .attributeDefinitions(
                    AttributeDefinition.builder()
                        .attributeName("id")
                        .attributeType(ScalarAttributeType.S)
                        .build(),
                    AttributeDefinition.builder()
                        .attributeName("domain")
                        .attributeType(ScalarAttributeType.S)
                        .build())
                .globalSecondaryIndexes(GlobalSecondaryIndex.builder()
                    .indexName("DomainIndex")
                    .keySchema(KeySchemaElement.builder()
                        .attributeName("domain")
                        .keyType(KeyType.HASH)
                        .build())
                    .projection(Projection.builder()
                        .projectionType(ProjectionType.ALL)
                        .build())
                    .billingMode(BillingMode.PAY_PER_REQUEST)
                    .build())
                .billingMode(BillingMode.PAY_PER_REQUEST)
                .build();

            dynamoDbClient.createTable(request);
        } catch (ResourceInUseException e) {
            // Table already exists
        }
    }

    @Test
    void createAndGetOrganization_Success() throws Exception {
        // Given
        OrganizationDto createDto = OrganizationDto.builder()
            .name("Test Organization")
            .domain("test.com")
            .description("Test Description")
            .website("https://test.com")
            .build();

        // When - Create organization
        String response = mockMvc.perform(post("/api/v1/organizations")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(createDto)))
            .andExpect(status().isCreated())
            .andExpect(jsonPath("$.name").value("Test Organization"))
            .andExpect(jsonPath("$.domain").value("test.com"))
            .andReturn()
            .getResponse()
            .getContentAsString();

        OrganizationDto createdOrg = objectMapper.readValue(response, OrganizationDto.class);

        // Then - Get organization
        mockMvc.perform(get("/api/v1/organizations/" + createdOrg.getId()))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.id").value(createdOrg.getId()))
            .andExpect(jsonPath("$.name").value("Test Organization"))
            .andExpect(jsonPath("$.domain").value("test.com"));
    }

    @Test
    void createOrganization_DuplicateDomain_ReturnsBadRequest() throws Exception {
        // Given
        OrganizationDto firstOrg = OrganizationDto.builder()
            .name("First Organization")
            .domain("duplicate.com")
            .build();

        OrganizationDto secondOrg = OrganizationDto.builder()
            .name("Second Organization")
            .domain("duplicate.com")
            .build();

        // When - Create first organization
        mockMvc.perform(post("/api/v1/organizations")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(firstOrg)))
            .andExpect(status().isCreated());

        // Then - Try to create second organization with same domain
        mockMvc.perform(post("/api/v1/organizations")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(secondOrg)))
            .andExpect(status().isBadRequest())
            .andExpect(jsonPath("$.message").value("Organization with domain 'duplicate.com' already exists"));
    }

    @Test
    void getOrganizationsByDomain_Success() throws Exception {
        // Given
        OrganizationDto orgDto = OrganizationDto.builder()
            .name("Domain Test Organization")
            .domain("domain-test.com")
            .build();

        // Create organization
        mockMvc.perform(post("/api/v1/organizations")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(orgDto)))
            .andExpect(status().isCreated());

        // When & Then - Get by domain
        mockMvc.perform(get("/api/v1/organizations/domain/domain-test.com"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$").isArray())
            .andExpect(jsonPath("$[0].name").value("Domain Test Organization"))
            .andExpect(jsonPath("$[0].domain").value("domain-test.com"));
    }

    @Test
    void updateOrganization_Success() throws Exception {
        // Given
        OrganizationDto createDto = OrganizationDto.builder()
            .name("Original Organization")
            .domain("original.com")
            .build();

        // Create organization
        String response = mockMvc.perform(post("/api/v1/organizations")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(createDto)))
            .andExpect(status().isCreated())
            .andReturn()
            .getResponse()
            .getContentAsString();

        OrganizationDto createdOrg = objectMapper.readValue(response, OrganizationDto.class);

        // Update DTO
        OrganizationDto updateDto = OrganizationDto.builder()
            .name("Updated Organization")
            .domain("original.com")
            .description("Updated Description")
            .build();

        // When & Then - Update organization
        mockMvc.perform(put("/api/v1/organizations/" + createdOrg.getId())
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(updateDto)))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.name").value("Updated Organization"))
            .andExpect(jsonPath("$.description").value("Updated Description"));
    }

    @Test
    void deleteOrganization_Success() throws Exception {
        // Given
        OrganizationDto createDto = OrganizationDto.builder()
            .name("To Delete Organization")
            .domain("todelete.com")
            .build();

        // Create organization
        String response = mockMvc.perform(post("/api/v1/organizations")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(createDto)))
            .andExpect(status().isCreated())
            .andReturn()
            .getResponse()
            .getContentAsString();

        OrganizationDto createdOrg = objectMapper.readValue(response, OrganizationDto.class);

        // When - Delete organization
        mockMvc.perform(delete("/api/v1/organizations/" + createdOrg.getId()))
            .andExpect(status().isNoContent());

        // Then - Verify deletion (should return 404)
        mockMvc.perform(get("/api/v1/organizations/" + createdOrg.getId()))
            .andExpect(status().isNotFound());
    }

    @Test
    void getAllOrganizations_Success() throws Exception {
        // Given - Create multiple organizations
        for (int i = 1; i <= 3; i++) {
            OrganizationDto orgDto = OrganizationDto.builder()
                .name("Organization " + i)
                .domain("org" + i + ".com")
                .build();

            mockMvc.perform(post("/api/v1/organizations")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(objectMapper.writeValueAsString(orgDto)))
                .andExpect(status().isCreated());
        }

        // When & Then - Get all organizations
        mockMvc.perform(get("/api/v1/organizations")
                .param("page", "0")
                .param("size", "10"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.content").isArray())
            .andExpect(jsonPath("$.page").value(0))
            .andExpect(jsonPath("$.size").value(10));
    }
}
