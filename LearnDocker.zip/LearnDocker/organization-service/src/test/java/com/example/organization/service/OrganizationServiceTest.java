package com.example.organization.service;

import com.example.common.dto.OrganizationDto;
import com.example.common.dto.PaginatedResponse;
import com.example.common.dto.PaginationRequest;
import com.example.common.exception.ResourceNotFoundException;
import com.example.common.exception.ValidationException;
import com.example.organization.mapper.OrganizationMapper;
import com.example.organization.model.Organization;
import com.example.organization.repository.OrganizationRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Instant;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class OrganizationServiceTest {

    @Mock
    private OrganizationRepository repository;

    @Mock
    private OrganizationMapper mapper;

    @InjectMocks
    private OrganizationService organizationService;

    private OrganizationDto testDto;
    private Organization testEntity;

    @BeforeEach
    void setUp() {
        testDto = OrganizationDto.builder()
            .name("Test Organization")
            .domain("test.com")
            .description("Test Description")
            .website("https://test.com")
            .build();

        testEntity = Organization.builder()
            .id("org-123")
            .name("Test Organization")
            .domain("test.com")
            .description("Test Description")
            .website("https://test.com")
            .createdAt(Instant.now())
            .updatedAt(Instant.now())
            .deleted(false)
            .build();
    }

    @Test
    void createOrganization_Success() {
        // Given
        when(repository.existsByDomain(testDto.getDomain())).thenReturn(false);
        when(mapper.toEntity(testDto)).thenReturn(testEntity);
        when(repository.save(any(Organization.class))).thenReturn(testEntity);
        when(mapper.toDto(testEntity)).thenReturn(testDto);

        // When
        OrganizationDto result = organizationService.createOrganization(testDto);

        // Then
        assertThat(result).isNotNull();
        assertThat(result.getName()).isEqualTo(testDto.getName());
        assertThat(result.getDomain()).isEqualTo(testDto.getDomain());

        verify(repository).existsByDomain(testDto.getDomain());
        verify(repository).save(any(Organization.class));
    }

    @Test
    void createOrganization_DomainAlreadyExists_ThrowsValidationException() {
        // Given
        when(repository.existsByDomain(testDto.getDomain())).thenReturn(true);

        // When & Then
        assertThatThrownBy(() -> organizationService.createOrganization(testDto))
            .isInstanceOf(ValidationException.class)
            .hasMessageContaining("Organization with domain 'test.com' already exists");

        verify(repository).existsByDomain(testDto.getDomain());
        verify(repository, never()).save(any());
    }

    @Test
    void getOrganizationById_Success() {
        // Given
        String organizationId = "org-123";
        when(repository.findById(organizationId)).thenReturn(Optional.of(testEntity));
        when(mapper.toDto(testEntity)).thenReturn(testDto);

        // When
        OrganizationDto result = organizationService.getOrganizationById(organizationId);

        // Then
        assertThat(result).isNotNull();
        assertThat(result.getName()).isEqualTo(testDto.getName());

        verify(repository).findById(organizationId);
    }

    @Test
    void getOrganizationById_NotFound_ThrowsResourceNotFoundException() {
        // Given
        String organizationId = "non-existent";
        when(repository.findById(organizationId)).thenReturn(Optional.empty());

        // When & Then
        assertThatThrownBy(() -> organizationService.getOrganizationById(organizationId))
            .isInstanceOf(ResourceNotFoundException.class)
            .hasMessageContaining("Organization with id 'non-existent' not found");

        verify(repository).findById(organizationId);
    }

    @Test
    void getOrganizationsByDomain_Success() {
        // Given
        String domain = "test.com";
        List<Organization> organizations = Arrays.asList(testEntity);
        when(repository.findByDomain(domain)).thenReturn(organizations);
        when(mapper.toDto(testEntity)).thenReturn(testDto);

        // When
        List<OrganizationDto> result = organizationService.getOrganizationsByDomain(domain);

        // Then
        assertThat(result).hasSize(1);
        assertThat(result.get(0).getDomain()).isEqualTo(domain);

        verify(repository).findByDomain(domain);
    }

    @Test
    void getAllOrganizations_Success() {
        // Given
        PaginationRequest paginationRequest = PaginationRequest.builder()
            .page(0)
            .size(20)
            .build();

        List<Organization> organizations = Arrays.asList(testEntity);
        when(repository.findAll(20, null)).thenReturn(organizations);
        when(mapper.toDto(testEntity)).thenReturn(testDto);

        // When
        PaginatedResponse<OrganizationDto> result = organizationService.getAllOrganizations(paginationRequest);

        // Then
        assertThat(result).isNotNull();
        assertThat(result.getContent()).hasSize(1);
        assertThat(result.getPage()).isEqualTo(0);
        assertThat(result.getSize()).isEqualTo(20);

        verify(repository).findAll(20, null);
    }

    @Test
    void updateOrganization_Success() {
        // Given
        String organizationId = "org-123";
        OrganizationDto updateDto = OrganizationDto.builder()
            .name("Updated Organization")
            .domain("test.com")
            .description("Updated Description")
            .build();

        when(repository.findById(organizationId)).thenReturn(Optional.of(testEntity));
        when(repository.existsByDomain(updateDto.getDomain())).thenReturn(false);
        when(repository.save(any(Organization.class))).thenReturn(testEntity);
        when(mapper.toDto(testEntity)).thenReturn(updateDto);

        // When
        OrganizationDto result = organizationService.updateOrganization(organizationId, updateDto);

        // Then
        assertThat(result).isNotNull();
        assertThat(result.getName()).isEqualTo(updateDto.getName());

        verify(repository).findById(organizationId);
        verify(mapper).updateEntity(updateDto, testEntity);
        verify(repository).save(testEntity);
    }

    @Test
    void updateOrganization_NotFound_ThrowsResourceNotFoundException() {
        // Given
        String organizationId = "non-existent";
        when(repository.findById(organizationId)).thenReturn(Optional.empty());

        // When & Then
        assertThatThrownBy(() -> organizationService.updateOrganization(organizationId, testDto))
            .isInstanceOf(ResourceNotFoundException.class)
            .hasMessageContaining("Organization with id 'non-existent' not found");

        verify(repository).findById(organizationId);
        verify(repository, never()).save(any());
    }

    @Test
    void updateOrganization_DomainAlreadyExists_ThrowsValidationException() {
        // Given
        String organizationId = "org-123";
        OrganizationDto updateDto = OrganizationDto.builder()
            .name("Updated Organization")
            .domain("existing.com")
            .build();

        when(repository.findById(organizationId)).thenReturn(Optional.of(testEntity));
        when(repository.existsByDomain(updateDto.getDomain())).thenReturn(true);

        // When & Then
        assertThatThrownBy(() -> organizationService.updateOrganization(organizationId, updateDto))
            .isInstanceOf(ValidationException.class)
            .hasMessageContaining("Organization with domain 'existing.com' already exists");

        verify(repository).findById(organizationId);
        verify(repository, never()).save(any());
    }

    @Test
    void deleteOrganization_Success() {
        // Given
        String organizationId = "org-123";
        when(repository.findById(organizationId)).thenReturn(Optional.of(testEntity));

        // When
        organizationService.deleteOrganization(organizationId);

        // Then
        verify(repository).findById(organizationId);
        verify(repository).deleteById(organizationId);
    }

    @Test
    void deleteOrganization_NotFound_ThrowsResourceNotFoundException() {
        // Given
        String organizationId = "non-existent";
        when(repository.findById(organizationId)).thenReturn(Optional.empty());

        // When & Then
        assertThatThrownBy(() -> organizationService.deleteOrganization(organizationId))
            .isInstanceOf(ResourceNotFoundException.class)
            .hasMessageContaining("Organization with id 'non-existent' not found");

        verify(repository).findById(organizationId);
        verify(repository, never()).deleteById(any());
    }
}
