package com.example.organization.controller;

import com.example.common.dto.OrganizationDto;
import com.example.common.dto.PaginatedResponse;
import com.example.common.exception.ResourceNotFoundException;
import com.example.common.exception.ValidationException;
import com.example.organization.service.OrganizationService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;
import java.util.List;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(OrganizationController.class)
class OrganizationControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private OrganizationService organizationService;

    @Autowired
    private ObjectMapper objectMapper;

    private OrganizationDto testDto;

    @BeforeEach
    void setUp() {
        testDto = OrganizationDto.builder()
            .id("org-123")
            .name("Test Organization")
            .domain("test.com")
            .description("Test Description")
            .website("https://test.com")
            .build();
    }

    @Test
    void createOrganization_Success() throws Exception {
        // Given
        when(organizationService.createOrganization(any(OrganizationDto.class))).thenReturn(testDto);

        // When & Then
        mockMvc.perform(post("/api/v1/organizations")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(testDto)))
            .andExpect(status().isCreated())
            .andExpect(jsonPath("$.id").value("org-123"))
            .andExpect(jsonPath("$.name").value("Test Organization"))
            .andExpect(jsonPath("$.domain").value("test.com"));

        verify(organizationService).createOrganization(any(OrganizationDto.class));
    }

    @Test
    void createOrganization_ValidationError() throws Exception {
        // Given
        OrganizationDto invalidDto = OrganizationDto.builder()
            .name("")  // Invalid: empty name
            .domain("test.com")
            .build();

        // When & Then
        mockMvc.perform(post("/api/v1/organizations")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(invalidDto)))
            .andExpect(status().isBadRequest())
            .andExpect(jsonPath("$.message").value("Validation failed"));

        verify(organizationService, never()).createOrganization(any());
    }

    @Test
    void createOrganization_DomainAlreadyExists() throws Exception {
        // Given
        when(organizationService.createOrganization(any(OrganizationDto.class)))
            .thenThrow(new ValidationException("Organization with domain 'test.com' already exists"));

        // When & Then
        mockMvc.perform(post("/api/v1/organizations")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(testDto)))
            .andExpect(status().isBadRequest())
            .andExpect(jsonPath("$.message").value("Organization with domain 'test.com' already exists"));
    }

    @Test
    void getOrganization_Success() throws Exception {
        // Given
        when(organizationService.getOrganizationById("org-123")).thenReturn(testDto);

        // When & Then
        mockMvc.perform(get("/api/v1/organizations/org-123"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.id").value("org-123"))
            .andExpect(jsonPath("$.name").value("Test Organization"));

        verify(organizationService).getOrganizationById("org-123");
    }

    @Test
    void getOrganization_NotFound() throws Exception {
        // Given
        when(organizationService.getOrganizationById("non-existent"))
            .thenThrow(new ResourceNotFoundException("Organization", "non-existent"));

        // When & Then
        mockMvc.perform(get("/api/v1/organizations/non-existent"))
            .andExpect(status().isNotFound())
            .andExpect(jsonPath("$.message").value("Organization with id 'non-existent' not found"));
    }

    @Test
    void getAllOrganizations_Success() throws Exception {
        // Given
        PaginatedResponse<OrganizationDto> response = PaginatedResponse.<OrganizationDto>builder()
            .content(Arrays.asList(testDto))
            .page(0)
            .size(20)
            .totalElements(1L)
            .totalPages(1)
            .first(true)
            .last(true)
            .hasNext(false)
            .hasPrevious(false)
            .build();

        when(organizationService.getAllOrganizations(any())).thenReturn(response);

        // When & Then
        mockMvc.perform(get("/api/v1/organizations")
                .param("page", "0")
                .param("size", "20"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.content").isArray())
            .andExpect(jsonPath("$.content[0].id").value("org-123"))
            .andExpect(jsonPath("$.page").value(0))
            .andExpect(jsonPath("$.size").value(20))
            .andExpect(jsonPath("$.totalElements").value(1));

        verify(organizationService).getAllOrganizations(any());
    }

    @Test
    void getOrganizationsByDomain_Success() throws Exception {
        // Given
        List<OrganizationDto> organizations = Arrays.asList(testDto);
        when(organizationService.getOrganizationsByDomain("test.com")).thenReturn(organizations);

        // When & Then
        mockMvc.perform(get("/api/v1/organizations/domain/test.com"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$").isArray())
            .andExpect(jsonPath("$[0].id").value("org-123"))
            .andExpect(jsonPath("$[0].domain").value("test.com"));

        verify(organizationService).getOrganizationsByDomain("test.com");
    }

    @Test
    void updateOrganization_Success() throws Exception {
        // Given
        OrganizationDto updatedDto = OrganizationDto.builder()
            .id("org-123")
            .name("Updated Organization")
            .domain("test.com")
            .build();

        when(organizationService.updateOrganization(eq("org-123"), any(OrganizationDto.class)))
            .thenReturn(updatedDto);

        // When & Then
        mockMvc.perform(put("/api/v1/organizations/org-123")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(updatedDto)))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.id").value("org-123"))
            .andExpect(jsonPath("$.name").value("Updated Organization"));

        verify(organizationService).updateOrganization(eq("org-123"), any(OrganizationDto.class));
    }

    @Test
    void deleteOrganization_Success() throws Exception {
        // Given
        doNothing().when(organizationService).deleteOrganization("org-123");

        // When & Then
        mockMvc.perform(delete("/api/v1/organizations/org-123"))
            .andExpect(status().isNoContent());

        verify(organizationService).deleteOrganization("org-123");
    }
}
