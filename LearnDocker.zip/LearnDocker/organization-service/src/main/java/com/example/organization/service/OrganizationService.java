package com.example.organization.service;

import com.example.common.dto.OrganizationDto;
import com.example.common.dto.PaginatedResponse;
import com.example.common.dto.PaginationRequest;
import com.example.common.exception.ResourceNotFoundException;
import com.example.common.exception.ValidationException;
import com.example.common.util.IdGenerator;
import com.example.organization.mapper.OrganizationMapper;
import com.example.organization.model.Organization;
import com.example.organization.repository.OrganizationRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.services.dynamodb.model.AttributeValue;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class OrganizationService {
    
    private final OrganizationRepository repository;
    private final OrganizationMapper mapper;
    
    public OrganizationDto createOrganization(OrganizationDto dto) {
        log.info("Creating organization with domain: {}", dto.getDomain());
        
        // Check if domain already exists
        if (repository.existsByDomain(dto.getDomain())) {
            throw new ValidationException("Organization with domain '" + dto.getDomain() + "' already exists");
        }
        
        Organization organization = mapper.toEntity(dto);
        organization.setId(IdGenerator.generateId("org"));
        organization.setCreatedAt(Instant.now());
        organization.setUpdatedAt(Instant.now());
        organization.setDeleted(false);
        
        Organization saved = repository.save(organization);
        log.info("Created organization with id: {}", saved.getId());
        
        return mapper.toDto(saved);
    }
    
    public OrganizationDto getOrganizationById(String id) {
        log.info("Fetching organization by id: {}", id);
        
        Organization organization = repository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Organization", id));
        
        return mapper.toDto(organization);
    }
    
    public List<OrganizationDto> getOrganizationsByDomain(String domain) {
        log.info("Fetching organizations by domain: {}", domain);
        
        List<Organization> organizations = repository.findByDomain(domain);
        
        return organizations.stream()
            .map(mapper::toDto)
            .collect(Collectors.toList());
    }
    
    public PaginatedResponse<OrganizationDto> getAllOrganizations(PaginationRequest paginationRequest) {
        log.info("Fetching all organizations with pagination: {}", paginationRequest);
        
        // For simplicity, using basic pagination with DynamoDB scan
        List<Organization> organizations = repository.findAll(paginationRequest.getSize(), null);
        
        List<OrganizationDto> dtos = organizations.stream()
            .map(mapper::toDto)
            .collect(Collectors.toList());
        
        return PaginatedResponse.<OrganizationDto>builder()
            .content(dtos)
            .page(paginationRequest.getPage())
            .size(paginationRequest.getSize())
            .totalElements((long) dtos.size())
            .totalPages(1) // Simplified for this example
            .first(true)
            .last(true)
            .hasNext(false)
            .hasPrevious(false)
            .build();
    }
    
    public OrganizationDto updateOrganization(String id, OrganizationDto dto) {
        log.info("Updating organization with id: {}", id);
        
        Organization existingOrganization = repository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Organization", id));
        
        // Check if domain is being changed and if new domain already exists
        if (!existingOrganization.getDomain().equals(dto.getDomain()) && 
            repository.existsByDomain(dto.getDomain())) {
            throw new ValidationException("Organization with domain '" + dto.getDomain() + "' already exists");
        }
        
        mapper.updateEntity(dto, existingOrganization);
        existingOrganization.setUpdatedAt(Instant.now());
        
        Organization updated = repository.save(existingOrganization);
        log.info("Updated organization with id: {}", updated.getId());
        
        return mapper.toDto(updated);
    }
    
    public void deleteOrganization(String id) {
        log.info("Deleting organization with id: {}", id);
        
        repository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Organization", id));
        
        repository.deleteById(id);
        log.info("Deleted organization with id: {}", id);
    }
}
