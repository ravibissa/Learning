package com.example.organization.handler;

import com.example.organization.OrganizationServiceApplication;
import org.springframework.cloud.function.adapter.aws.SpringBootRequestHandler;

public class OrganizationLambdaHandler extends SpringBootRequestHandler<Object, Object> {
    
    public OrganizationLambdaHandler() {
        super(OrganizationServiceApplication.class);
    }
}
