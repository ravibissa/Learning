package com.example.organization.repository;

import com.example.organization.model.Organization;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbEnhancedClient;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbIndex;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.Key;
import software.amazon.awssdk.enhanced.dynamodb.model.Page;
import software.amazon.awssdk.enhanced.dynamodb.model.PageIterable;
import software.amazon.awssdk.enhanced.dynamodb.model.QueryConditional;
import software.amazon.awssdk.enhanced.dynamodb.model.ScanEnhancedRequest;
import software.amazon.awssdk.services.dynamodb.model.AttributeValue;

import javax.annotation.PostConstruct;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@Repository
public class OrganizationRepository {
    
    @Autowired
    private DynamoDbEnhancedClient dynamoDbEnhancedClient;
    
    private DynamoDbTable<Organization> table;
    private DynamoDbIndex<Organization> domainIndex;
    
    @PostConstruct
    public void init() {
        this.table = dynamoDbEnhancedClient.table("organizations", 
            software.amazon.awssdk.enhanced.dynamodb.TableSchema.fromBean(Organization.class));
        this.domainIndex = table.index("DomainIndex");
    }
    
    public Organization save(Organization organization) {
        table.putItem(organization);
        return organization;
    }
    
    public Optional<Organization> findById(String id) {
        Key key = Key.builder().partitionValue(id).build();
        Organization organization = table.getItem(key);
        
        if (organization != null && !Boolean.TRUE.equals(organization.getDeleted())) {
            return Optional.of(organization);
        }
        return Optional.empty();
    }
    
    public List<Organization> findByDomain(String domain) {
        QueryConditional queryConditional = QueryConditional.keyEqualTo(
            Key.builder().partitionValue(domain).build()
        );
        
        PageIterable<Organization> results = domainIndex.query(queryConditional);
        
        return results.stream()
            .flatMap(page -> page.items().stream())
            .filter(org -> !Boolean.TRUE.equals(org.getDeleted()))
            .collect(Collectors.toList());
    }
    
    public List<Organization> findAll(int limit, Map<String, AttributeValue> exclusiveStartKey) {
        ScanEnhancedRequest.Builder requestBuilder = ScanEnhancedRequest.builder()
            .limit(limit)
            .filterExpression(software.amazon.awssdk.enhanced.dynamodb.Expression.builder()
                .expression("attribute_not_exists(deleted) OR deleted = :deleted")
                .putExpressionValue(":deleted", AttributeValue.builder().bool(false).build())
                .build());
        
        if (exclusiveStartKey != null && !exclusiveStartKey.isEmpty()) {
            requestBuilder.exclusiveStartKey(exclusiveStartKey);
        }
        
        PageIterable<Organization> results = table.scan(requestBuilder.build());
        Page<Organization> firstPage = results.iterator().next();
        
        return firstPage.items();
    }
    
    public void deleteById(String id) {
        Optional<Organization> existingOrg = findById(id);
        if (existingOrg.isPresent()) {
            Organization organization = existingOrg.get();
            organization.setDeleted(true);
            organization.setUpdatedAt(java.time.Instant.now());
            save(organization);
        }
    }
    
    public boolean existsByDomain(String domain) {
        return !findByDomain(domain).isEmpty();
    }
}
