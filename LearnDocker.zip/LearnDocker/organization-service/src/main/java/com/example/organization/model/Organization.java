package com.example.organization.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.*;

import java.time.Instant;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@DynamoDbBean
public class Organization {
    
    @DynamoDbPartitionKey
    private String id;
    
    private String name;
    private String description;
    
    @DynamoDbSecondaryPartitionKey(indexNames = "DomainIndex")
    private String domain;
    
    private String website;
    private Instant createdAt;
    private Instant updatedAt;
    
    @Builder.Default
    private Boolean deleted = false;
}
