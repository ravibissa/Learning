package com.example.organization.controller;

import com.example.common.dto.OrganizationDto;
import com.example.common.dto.PaginatedResponse;
import com.example.common.dto.PaginationRequest;
import com.example.organization.service.OrganizationService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import java.util.List;

@Slf4j
@RestController
@RequestMapping("/api/v1/organizations")
@RequiredArgsConstructor
@Validated
public class OrganizationController {
    
    private final OrganizationService organizationService;
    
    @PostMapping
    public ResponseEntity<OrganizationDto> createOrganization(@Valid @RequestBody OrganizationDto dto) {
        log.info("POST /api/v1/organizations - Creating organization");
        OrganizationDto created = organizationService.createOrganization(dto);
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<OrganizationDto> getOrganization(@PathVariable @NotBlank String id) {
        log.info("GET /api/v1/organizations/{} - Fetching organization", id);
        OrganizationDto organization = organizationService.getOrganizationById(id);
        return ResponseEntity.ok(organization);
    }
    
    @GetMapping
    public ResponseEntity<PaginatedResponse<OrganizationDto>> getAllOrganizations(
            @RequestParam(defaultValue = "0") Integer page,
            @RequestParam(defaultValue = "20") Integer size,
            @RequestParam(required = false) String sortBy,
            @RequestParam(defaultValue = "ASC") String sortDirection) {
        
        log.info("GET /api/v1/organizations - Fetching all organizations");
        
        PaginationRequest paginationRequest = PaginationRequest.builder()
            .page(page)
            .size(size)
            .sortBy(sortBy)
            .sortDirection(sortDirection)
            .build();
        
        PaginatedResponse<OrganizationDto> response = organizationService.getAllOrganizations(paginationRequest);
        return ResponseEntity.ok(response);
    }
    
    @GetMapping("/domain/{domain}")
    public ResponseEntity<List<OrganizationDto>> getOrganizationsByDomain(@PathVariable @NotBlank String domain) {
        log.info("GET /api/v1/organizations/domain/{} - Fetching organizations by domain", domain);
        List<OrganizationDto> organizations = organizationService.getOrganizationsByDomain(domain);
        return ResponseEntity.ok(organizations);
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<OrganizationDto> updateOrganization(
            @PathVariable @NotBlank String id,
            @Valid @RequestBody OrganizationDto dto) {
        log.info("PUT /api/v1/organizations/{} - Updating organization", id);
        OrganizationDto updated = organizationService.updateOrganization(id, dto);
        return ResponseEntity.ok(updated);
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteOrganization(@PathVariable @NotBlank String id) {
        log.info("DELETE /api/v1/organizations/{} - Deleting organization", id);
        organizationService.deleteOrganization(id);
        return ResponseEntity.noContent().build();
    }
}
