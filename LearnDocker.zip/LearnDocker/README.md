# Microservices Platform - Employee and Organization Management

A comprehensive Java 11 Spring Boot microservices platform for managing employees and organizations, designed to run both as traditional HTTP services and AWS Lambda functions.

## 🏗️ Architecture Overview

```mermaid
graph TB
    subgraph "Client Layer"
        WEB[Web Application]
        MOBILE[Mobile App]
        API_CLIENT[API Client]
    end

    subgraph "API Gateway"
        NGINX[Nginx/Load Balancer]
        AWS_APIGW[AWS API Gateway]
    end

    subgraph "Microservices"
        subgraph "Employee Service"
            EMP_APP[Employee Service<br/>Spring Boot App]
            EMP_LAMBDA[Employee Lambda<br/>Function]
        end
        
        subgraph "Organization Service"
            ORG_APP[Organization Service<br/>Spring Boot App]
            ORG_LAMBDA[Organization Lambda<br/>Function]
        end
    end

    subgraph "Data Layer"
        EMP_DB[(Employees<br/>DynamoDB)]
        ORG_DB[(Organizations<br/>DynamoDB)]
    end

    subgraph "Observability"
        PROMETHEUS[Prometheus]
        GRAFANA[Grafana]
        LOGS[CloudWatch Logs]
    end

    subgraph "Container Orchestration"
        K8S[Kubernetes Cluster]
        DOCKER[Docker Containers]
    end

    subgraph "CI/CD"
        GITHUB[GitHub Actions]
        SAM[AWS SAM]
        KUSTOMIZE[Kustomize]
    end

    %% Client connections
    WEB --> NGINX
    MOBILE --> AWS_APIGW
    API_CLIENT --> NGINX

    %% Gateway routing
    NGINX --> EMP_APP
    NGINX --> ORG_APP
    AWS_APIGW --> EMP_LAMBDA
    AWS_APIGW --> ORG_LAMBDA

    %% Service communication
    EMP_APP -.->|HTTP| ORG_APP
    EMP_LAMBDA -.->|HTTP| ORG_LAMBDA

    %% Data access
    EMP_APP --> EMP_DB
    EMP_LAMBDA --> EMP_DB
    ORG_APP --> ORG_DB
    ORG_LAMBDA --> ORG_DB

    %% DynamoDB GSI
    EMP_DB --> |GSI: orgId| EMP_DB
    ORG_DB --> |GSI: domain| ORG_DB

    %% Monitoring
    EMP_APP --> PROMETHEUS
    ORG_APP --> PROMETHEUS
    PROMETHEUS --> GRAFANA
    EMP_LAMBDA --> LOGS
    ORG_LAMBDA --> LOGS

    %% Deployment
    K8S --> EMP_APP
    K8S --> ORG_APP
    DOCKER --> K8S
    GITHUB --> SAM
    GITHUB --> KUSTOMIZE
    SAM --> EMP_LAMBDA
    SAM --> ORG_LAMBDA
    KUSTOMIZE --> K8S

    style EMP_APP fill:#e1f5fe
    style ORG_APP fill:#e8f5e8
    style EMP_LAMBDA fill:#fff3e0
    style ORG_LAMBDA fill:#fce4ec
    style EMP_DB fill:#f3e5f5
    style ORG_DB fill:#f3e5f5
```

## 📋 Table of Contents

- [Features](#-features)
- [Technology Stack](#-technology-stack)
- [Project Structure](#-project-structure)
- [Quick Start](#-quick-start)
- [Local Development](#-local-development)
- [Testing](#-testing)
- [Deployment](#-deployment)
- [API Documentation](#-api-documentation)
- [Monitoring](#-monitoring)
- [Troubleshooting](#-troubleshooting)
- [Contributing](#-contributing)

## ✨ Features

### Core Functionality
- **Employee Management**: Complete CRUD operations with soft delete
- **Organization Management**: Domain-based organization management
- **Data Relationships**: Employees linked to organizations with foreign key constraints
- **Pagination**: Built-in pagination support for all list endpoints
- **Validation**: Comprehensive input validation with custom error messages

### Technical Features
- **Dual Deployment**: Services run as both Spring Boot apps and AWS Lambda functions
- **DynamoDB Integration**: AWS SDK v2 Enhanced Client for optimal performance
- **Service Communication**: Reactive HTTP client for inter-service communication
- **Error Handling**: Centralized exception handling with detailed error responses
- **Health Checks**: Comprehensive health endpoints for Kubernetes readiness/liveness probes
- **Metrics**: Prometheus metrics integration for monitoring

### DevOps & Infrastructure
- **Multi-stage Docker builds** for optimized container images
- **Kubernetes manifests** with Kustomize overlays for environment-specific configurations
- **AWS SAM templates** for serverless deployment
- **GitHub Actions CI/CD** pipelines with automated testing and deployment
- **Security scanning** with Trivy and Snyk
- **Code quality** checks with SonarCloud, SpotBugs, and Checkstyle

## 🛠️ Technology Stack

### Backend
- **Java 11** - Programming language
- **Spring Boot 2.7.x** - Application framework
- **Spring Cloud Function** - Serverless support
- **Spring WebFlux** - Reactive programming
- **DynamoDB** - NoSQL database
- **AWS SDK v2** - AWS service integration

### Development & Testing
- **Maven** - Build tool and dependency management
- **JUnit 5** - Testing framework
- **Mockito** - Mocking framework
- **Testcontainers** - Integration testing with real dependencies
- **REST Assured** - API testing
- **JaCoCo** - Code coverage (85% minimum)

### DevOps & Infrastructure
- **Docker** - Containerization
- **Kubernetes** - Container orchestration
- **AWS Lambda** - Serverless computing
- **AWS API Gateway** - API management
- **LocalStack** - Local AWS services emulation
- **Prometheus & Grafana** - Monitoring and visualization
- **GitHub Actions** - CI/CD automation

### Code Quality & Utilities
- **Lombok** - Boilerplate code reduction
- **MapStruct** - Bean mapping
- **Bean Validation** - Input validation
- **SLF4J + Logback** - Logging

## 📁 Project Structure

```
microservices-parent/
├── common/                          # Shared DTOs, exceptions, utilities
│   ├── src/main/java/com/example/common/
│   │   ├── dto/                     # Data Transfer Objects
│   │   ├── exception/               # Custom exceptions
│   │   └── util/                    # Utility classes
│   └── pom.xml
├── employee-service/                # Employee microservice
│   ├── src/main/java/com/example/employee/
│   │   ├── controller/              # REST controllers
│   │   ├── service/                 # Business logic
│   │   ├── repository/              # Data access layer
│   │   ├── model/                   # DynamoDB entities
│   │   ├── mapper/                  # MapStruct mappers
│   │   ├── client/                  # External service clients
│   │   ├── config/                  # Configuration classes
│   │   ├── handler/                 # Lambda handlers
│   │   └── exception/               # Exception handlers
│   ├── src/test/                    # Unit and integration tests
│   ├── Dockerfile                   # Multi-stage Docker build
│   └── pom.xml
├── organization-service/            # Organization microservice
│   └── [similar structure to employee-service]
├── infra/                          # Infrastructure as Code
│   ├── template.yaml               # SAM template
│   └── samconfig.toml              # SAM configuration
├── k8s/                           # Kubernetes manifests
│   ├── base/                      # Base Kubernetes resources
│   └── overlays/                  # Environment-specific overlays
│       ├── dev/                   # Development environment
│       └── prod/                  # Production environment
├── monitoring/                    # Monitoring configuration
│   ├── prometheus.yml
│   └── grafana/
├── .github/workflows/             # CI/CD pipelines
├── docker-compose.yml             # Local development setup
└── pom.xml                       # Parent POM
```

## 🚀 Quick Start

### Prerequisites
- **Java 11** or later
- **Maven 3.6+**
- **Docker** and **Docker Compose**
- **Git**

### Clone and Build
```bash
git clone https://github.com/your-username/microservices-platform.git
cd microservices-platform

# Build all modules
mvn clean compile package -DskipTests
```

### Run with Docker Compose (Recommended)
```bash
# Start all services including LocalStack, Prometheus, and Grafana
docker-compose up -d

# Wait for services to be healthy
docker-compose ps

# Access the services
curl http://localhost/api/v1/organizations/health
curl http://localhost/api/v1/employees/health
```

### Access Points
- **Employee Service**: http://localhost/api/v1/employees
- **Organization Service**: http://localhost/api/v1/organizations
- **Prometheus**: http://localhost:9090
- **Grafana**: http://localhost:3000 (admin/admin)
- **DynamoDB Admin**: http://localhost:8001

## 💻 Local Development

### Running Individual Services

#### Organization Service
```bash
cd organization-service
mvn spring-boot:run -Dspring-boot.run.profiles=local
```

#### Employee Service
```bash
cd employee-service
export ORGANIZATION_SERVICE_URL=http://localhost:8081
mvn spring-boot:run -Dspring-boot.run.profiles=local
```

### Setting Up LocalStack
```bash
# Start LocalStack for local AWS services
docker run --rm -it -p 4566:4566 -p 4571:4571 \
  -e SERVICES=dynamodb,s3,lambda,apigateway \
  localstack/localstack:3.0
```

### Creating DynamoDB Tables
```bash
# Create organizations table
aws dynamodb create-table \
  --endpoint-url http://localhost:4566 \
  --table-name organizations \
  --attribute-definitions \
    AttributeName=id,AttributeType=S \
    AttributeName=domain,AttributeType=S \
  --key-schema AttributeName=id,KeyType=HASH \
  --global-secondary-indexes \
    IndexName=DomainIndex,KeySchema=[{AttributeName=domain,KeyType=HASH}],Projection={ProjectionType=ALL} \
  --billing-mode PAY_PER_REQUEST

# Create employees table
aws dynamodb create-table \
  --endpoint-url http://localhost:4566 \
  --table-name employees \
  --attribute-definitions \
    AttributeName=id,AttributeType=S \
    AttributeName=organizationId,AttributeType=S \
  --key-schema AttributeName=id,KeyType=HASH \
  --global-secondary-indexes \
    IndexName=OrganizationIndex,KeySchema=[{AttributeName=organizationId,KeyType=HASH}],Projection={ProjectionType=ALL} \
  --billing-mode PAY_PER_REQUEST
```

## 🧪 Testing

### Running Tests
```bash
# Unit tests
mvn test

# Integration tests
mvn verify -P integration-tests

# All tests with coverage
mvn clean verify

# Generate coverage report
mvn jacoco:report
```

### Test Coverage Requirements
- **Minimum coverage**: 85%
- **Build fails** if coverage is below threshold
- **Coverage reports** available in `target/site/jacoco/`

### Test Categories
- **Unit Tests**: Service logic, controllers, repositories
- **Integration Tests**: Database integration with Testcontainers
- **Contract Tests**: API contracts with REST Assured
- **End-to-End Tests**: Complete workflow testing

### Example API Testing
```bash
# Create organization
curl -X POST http://localhost/api/v1/organizations \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Tech Corp",
    "domain": "techcorp.com",
    "description": "A technology company"
  }'

# Create employee
curl -X POST http://localhost/api/v1/employees \
  -H "Content-Type: application/json" \
  -d '{
    "firstName": "John",
    "lastName": "Doe",
    "email": "john.doe@techcorp.com",
    "position": "Software Engineer",
    "organizationId": "org-123"
  }'
```

## 🚀 Deployment

### AWS Lambda Deployment with SAM

#### Prerequisites
- AWS CLI configured
- SAM CLI installed
- Docker running

#### Deploy to Development
```bash
cd infra

# Build Lambda packages
sam build --config-env dev

# Deploy
sam deploy --config-env dev
```

#### Deploy to Production
```bash
# Build for production
sam build --config-env prod

# Deploy with confirmation
sam deploy --config-env prod --confirm-changeset
```

### Kubernetes Deployment

#### Prerequisites
- Kubernetes cluster running
- kubectl configured
- Kustomize installed

#### Deploy to Development
```bash
# Apply development configuration
kubectl apply -k k8s/overlays/dev

# Check deployment status
kubectl get pods -n microservices-dev
```

#### Deploy to Production
```bash
# Apply production configuration
kubectl apply -k k8s/overlays/prod

# Monitor rollout
kubectl rollout status deployment/prod-employee-service -n microservices-prod
kubectl rollout status deployment/prod-organization-service -n microservices-prod
```

### Docker Image Management
```bash
# Build images locally
docker build -t employee-service:latest -f employee-service/Dockerfile .
docker build -t organization-service:latest -f organization-service/Dockerfile .

# Tag for registry
docker tag employee-service:latest your-registry/employee-service:v1.0.0

# Push to registry
docker push your-registry/employee-service:v1.0.0
```

## 📚 API Documentation

### Organization Service Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/v1/organizations` | Create organization |
| GET | `/api/v1/organizations/{id}` | Get organization by ID |
| GET | `/api/v1/organizations` | List all organizations (paginated) |
| GET | `/api/v1/organizations/domain/{domain}` | Find organizations by domain |
| PUT | `/api/v1/organizations/{id}` | Update organization |
| DELETE | `/api/v1/organizations/{id}` | Delete organization (soft delete) |

### Employee Service Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/v1/employees` | Create employee |
| GET | `/api/v1/employees/{id}` | Get employee by ID |
| GET | `/api/v1/employees` | List all employees (paginated) |
| GET | `/api/v1/employees/organization/{orgId}` | Find employees by organization |
| PUT | `/api/v1/employees/{id}` | Update employee |
| DELETE | `/api/v1/employees/{id}` | Delete employee (soft delete) |

### Request/Response Examples

#### Create Organization
```bash
POST /api/v1/organizations
Content-Type: application/json

{
  "name": "Tech Innovations Inc",
  "domain": "techinnovations.com",
  "description": "Leading technology solutions provider",
  "website": "https://techinnovations.com"
}
```

#### Response
```json
{
  "id": "org-123e4567-e89b-12d3-a456-426614174000",
  "name": "Tech Innovations Inc",
  "domain": "techinnovations.com",
  "description": "Leading technology solutions provider",
  "website": "https://techinnovations.com",
  "createdAt": "2023-12-07T10:30:00.000Z",
  "updatedAt": "2023-12-07T10:30:00.000Z",
  "deleted": false
}
```

### Health Check Endpoints
- **Employee Service**: `/actuator/health`
- **Organization Service**: `/actuator/health`
- **Detailed Health**: `/actuator/health/liveness`, `/actuator/health/readiness`

## 📊 Monitoring

### Metrics Collection
- **Prometheus** scrapes metrics from `/actuator/prometheus` endpoints
- **Custom metrics** for business operations
- **JVM metrics** including memory, GC, threads
- **HTTP request metrics** with timing and status codes

### Dashboards
Access Grafana at http://localhost:3000 (admin/admin) for:
- **Application metrics**: Request rates, response times, error rates
- **JVM metrics**: Memory usage, garbage collection
- **DynamoDB metrics**: Read/write capacity, throttling
- **Custom business metrics**: Employee creation rates, organization distribution

### Alerting
Configure alerts for:
- High error rates (>5% over 5 minutes)
- High response times (>2s 95th percentile)
- Memory usage (>80% heap utilization)
- DynamoDB throttling events

### Log Management
- **Application logs**: Structured JSON logging with correlation IDs
- **AWS CloudWatch**: Centralized log collection for Lambda functions
- **Log levels**: Configurable per environment (DEBUG for dev, WARN for prod)

## 🔍 Troubleshooting

### Common Issues

#### Service Won't Start
```bash
# Check if ports are available
netstat -tulpn | grep :8080
netstat -tulpn | grep :8081

# Check Docker container logs
docker-compose logs employee-service
docker-compose logs organization-service
```

#### Database Connection Issues
```bash
# Verify LocalStack is running
curl http://localhost:4566/_localstack/health

# Check DynamoDB tables
aws dynamodb list-tables --endpoint-url http://localhost:4566

# Verify table structure
aws dynamodb describe-table --table-name employees --endpoint-url http://localhost:4566
```

#### Inter-Service Communication
```bash
# Test organization service directly
curl http://localhost:8081/api/v1/organizations/health

# Check employee service can reach organization service
kubectl exec -it pod/employee-service-xxx -- curl http://organization-service:8081/actuator/health
```

### Performance Issues

#### High Memory Usage
```bash
# Check JVM memory settings
docker exec container_name java -XX:+PrintFlagsFinal -version | grep HeapSize

# Monitor memory usage
kubectl top pods -n microservices-dev
```

#### Slow Database Queries
```bash
# Check DynamoDB metrics in CloudWatch
aws cloudwatch get-metric-statistics \
  --namespace AWS/DynamoDB \
  --metric-name ConsumedReadCapacityUnits \
  --dimensions Name=TableName,Value=employees

# Enable DynamoDB insights for detailed query analysis
```

### Debugging

#### Enable Debug Logging
```yaml
# application-debug.yml
logging:
  level:
    com.example: DEBUG
    software.amazon.awssdk: DEBUG
    org.springframework.web: DEBUG
```

#### Health Check Details
```bash
# Detailed health information
curl http://localhost:8080/actuator/health | jq .

# Individual health indicators
curl http://localhost:8080/actuator/health/dynamodb
curl http://localhost:8080/actuator/health/diskSpace
```

### AWS Lambda Specific Issues

#### Cold Start Optimization
- Use **AWS Lambda Provisioned Concurrency** for production
- **Optimize** startup time with GraalVM native images (future enhancement)
- **Monitor** cold start metrics in CloudWatch

#### Lambda Timeout Issues
```bash
# Check CloudWatch logs for timeout errors
aws logs filter-log-events \
  --log-group-name /aws/lambda/dev-employee-service \
  --filter-pattern "Task timed out"
```

## 🤝 Contributing

### Development Workflow
1. **Fork** the repository
2. **Create** a feature branch: `git checkout -b feature/amazing-feature`
3. **Commit** changes: `git commit -m 'Add amazing feature'`
4. **Push** to branch: `git push origin feature/amazing-feature`
5. **Open** a Pull Request

### Code Standards
- **Java Code Style**: Follow Google Java Style Guide
- **Test Coverage**: Maintain minimum 85% coverage
- **Documentation**: Update README for new features
- **Commit Messages**: Use conventional commit format

### Pull Request Requirements
- [ ] All tests pass
- [ ] Code coverage maintained
- [ ] Documentation updated
- [ ] No security vulnerabilities
- [ ] Performance impact assessed

### Setting Up Development Environment
```bash
# Install pre-commit hooks
pip install pre-commit
pre-commit install

# Run code formatting
mvn spotless:apply

# Run full quality checks
mvn clean verify -P quality-checks
```

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 📞 Support

- **Issues**: [GitHub Issues](https://github.com/your-username/microservices-platform/issues)
- **Documentation**: [Wiki](https://github.com/your-username/microservices-platform/wiki)
- **Discussions**: [GitHub Discussions](https://github.com/your-username/microservices-platform/discussions)

## 🙏 Acknowledgments

- **Spring Boot Team** for the excellent framework
- **AWS** for comprehensive cloud services
- **Testcontainers** for integration testing
- **Community** for various open-source tools and libraries

---

**Happy Coding! 🚀**
